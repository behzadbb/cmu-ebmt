#!/bin/csh -f
# Last Edit: 11apr10
##	by Ralf Brown <ralf@cs.cmu.edu>					##
##									##
##  (c) Copyright 2005,2006,2007,2008,2009,2010 Ralf Brown		##
##	This program is free software; you can redistribute it and/or	##
##	modify it under the terms of the GNU General Public License as	##
##	published by the Free Software Foundation, version 3.		##
##									##
##	This program is distributed in the hope that it will be		##
##	useful, but WITHOUT ANY WARRANTY; without even the implied	##
##	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		##
##	PURPOSE.  See the GNU General Public License for more details.	##
##									##
##	You should have received a copy of the GNU General Public	##
##	License (file COPYING) along with this program.  If not, see	##
##	http://www.gnu.org/licenses/					##

## many of the operations of this script can be overridden with environment
## variables:
##   TUNE_PANLITE_DIR		directory for temporary files
##   TUNE_PANLITE_METRIC	name of evaluation metric
##   TUNE_PANLITE_NGRAM		ngram length for NIST/BLEU metrics
##   TUNE_PANLITE_NORM		name of normalization script
##   TUNE_PANLITE_MER		Min-Error-Rate training
##   TUNE_PANLITE_CUNEI		use Cunei Optimize (if nonblank, name of script)
##   TUNE_PANLITE_KEEPTMP	do not remove temporary files when done
##   TUNE_REFERENCES		directory for ref files instead of ./refs

## select which MERT program to use: STTK OptimizeNBest (default), MOSES cmert,
##   new C++ MOSES mert, or Joshua ZMERT
setenv TUNE_PANLITE_NEWMERT
#setenv TUNE_PANLITE_CMERT
#setenv TUNE_PANLITE_ZMERT  ## not yet implemented

## select default evaluation metric if the script's name does not indicate one
set evalmetric=mteval		# BLEU computed with NIST mteval script
#set evalmetric=modBLEU		# linear BLEU computed with bleu-cmu script
#set evalmetric=NIST-BLEU
#set evalmetric=TER		# TER computed with Evaluate
#set evalmetric=TERcom		# TER computed with tercom script

## select whether to ignore upper/lower case
set uncased

## select whether to output progress messages
#set showbest			# show current best point
set showprogress		# show all progress messages, incl best point

# select the scoring metric for the MER training
set metric=IBMBLEU	# corresponds to score computed by bleu_v1.04.pl
#set metric=NISTBLEU	# corresponds to score computed by bleu-cmu.pl

# select default ngram length for NIST/BLEU (non-mteval version only)
set ngramlen=4

# set default directory in which to look for programs when all else fails
set defdir=~ralf/pnp/bin

# set default directory in which to look for MOSES cmert when all else fails
set cmert_dir="/usr10/jdkim/pharaoh/mosesdecoder/scripts/training/cmert-0.5"

# set default directory in which to look for new MOSES mert when all else fails
set newmert_dir="/usr/ralf/pnp/bin"

# set default directory in which to look for Joshua ZMERT when all else fails
set zmert_dir=""

# set default directory in which to look for Cunei when all else fails
set cunei_dir="/usr/jdkim/tools/cunei/bin"

# initialize other variables
set cunei=""
set cunei_nbest=250

################### END OF CONFIGURATION SECTION ###################

# if we were invoked via the cluster scheduler, get the caller's
#   working directory rather than the temporary directory in which we
#   were invoked
set cd="."
if ($?PBS_O_WORKDIR) then
   if ("x$PBS_O_WORKDIR" != "x") set cd="$PBS_O_WORKDIR"
   chdir $cd
endif

## handle the end-of-tuning cleanup request
if ($1 == "--cleanup") then
   if ($?TUNE_PANLITE_DIR && ! $?TUNE_PANLITE_KEEPTMP) then
      rm -f $TUNE_PANLITE_DIR/{chart,prevcfg,tmpeval*.sed,mer*.err,mer*.result}
      if ("$TUNE_PANLITE_DIR" != "" && "$TUNE_PANLITE_DIR" != ".") then
         rmdir $TUNE_PANLITE_DIR >&/dev/null
      endif
   endif
   echo OK
   exit 0
endif

## check whether this is a valid invocation
if ($#argv != 2 && $#argv != 3) then
   echo "Given args: $*"
   echo "  are incorrect"
   echo ""
   echo "Usage:	$0:t cfgfile testfile [--final|--mer|--opt]"
   echo "  or"
   echo "       $0:t cfgfile paramname --test"
   echo "  or"
   echo "	$0:t --cleanup"
   echo "The second form will return SINGLE if the first run with that parameter"
   echo "  must complete before additional ones may be started, or MULTI if"
   echo "  all runs with that parameter can be performed in parallel."
   echo "Set environment variable TUNE_MER_ALWAYS to run MER on every iteration"
   exit 1
endif

## figure out which evaluation metric to use for scoring output
if ($?TUNE_PANLITE_METRIC) then
   set basename=$TUNE_PANLITE_METRIC
else
   set basename=$0:t:r
endif
if ( $basename =~ *NISTBLEU* || $basename =~ *NIST-BLEU* ) then
   set evalmetric=NIST-BLEU
else if ( $basename =~ *TER* ) then
   set evalmetric=TER
else if ( $basename =~ *tercom* ) then
   set evalmetric=TERcom
### current Evaluate executable does not actually support PER
#else if ( $basename =~ *PER* ) then
#   set evalmetric=PER
else if ( $basename =~ *CER* ) then
   set evalmetric=PER
else if ( $basename =~ *WER* ) then
   set evalmetric=WER
else if ( $basename =~ *modBLEU* ) then
   set evalmetric=modBLEU
else if ( $basename =~ *BLEU* ) then
   set evalmetric=BLEU
else if ( $basename =~ *NIST* ) then
   set evalmetric=NIST
else if ( $basename =~ *mteval* ) then
   set evalmetric=mteval
endif

## parse command line
set cfgfile=$1
set test=$2
if ( "x$3" == "x--final" ) set final_run
if ( "x$3" == "x--mer" ) then
   set final_run
   if ( $?TUNE_PANLITE_MER ) then
      setenv TUNE_MER $TUNE_PANLITE_MER
   else if ( $?TUNE_PANLITE_NEWMERT ) then
      setenv TUNE_MER 400
   else if ( $?TUNE_PANLITE_CMERT ) then
      setenv TUNE_MER 200
   else
      setenv TUNE_MER 350
   endif
endif
if ( "x$3" == "x--opt" ) then
   set run_optimizer
endif
set refdir=${cd}/refs
if ( $?TUNE_REFERENCES ) then
   set refdir=$TUNE_REFERENCES
endif
if ( ${refdir} !~ /* ) then
   # convert relative path to absolute path
   set refdir=${cwd}/${refdir}
endif

# verify that the configuration file exists
if ( ! -e $cfgfile ) then
   echo Config file not found
   exit 1
endif

# find the executables we'll need
set mtprog=`where panlite|head -1`
if ("$mtprog" == "" && -e ${0:h}/panlite) set mtprog=${0:h}/panlite
if ("$mtprog" == "") set mtprog="${defdir}/panlite"

set lmprog=`where lm|head -1`
if ("$lmprog" == "" && -e ${0:h}/lm) set lmprog=${0:h}/lm
if ("$lmprog" == "") set lmprog="${defdir}/lm"

set lmout2hyp=`where lmout2hyp|head -1`
if ("$lmout2hyp" == "" && -e ${0:h}/lmout2hyp) set lmout2hyp=${0:h}/lmout2hyp
if ("$lmout2hyp" == "" && -e ${defdir}/lmout2hyp) set lmout2hyp="${defdir}/lmout2hyp"

if ( $?TUNE_PANLITE_CUNEI && $?run_optimizer ) then
   set cunei=`where cunei.sh|head -1`
   if ("x$TUNE_PANLITE_CUNEI" != "x") then
      if (-x $TUNE_PANLITE_CUNEI) \
	set cunei="$TUNE_PANLITE_CUNEI"
   endif
   if ("$cunei" == "") then
      if ( -x ${0:h}/cunei.sh ) then
         set cunei=${0:h}/cunei.sh
      else if ( -x ${cunei_dir}/cunei.sh ) then
         set cunei="${cunei_dir}/cunei.sh"
      endif
   endif
   if ("$cunei" != "") then
      if ("$cunei:h" != "$cunei") then
         setenv CUNEI_HOME "$cunei:h"
         if (${CUNEI_HOME:t} == "bin") setenv CUNEI_HOME ${CUNEI_HOME:h}
      else
         setenv CUNEI_HOME "."
      endif
   endif
endif

set merprog=""
if ( $?TUNE_PANLITE_NEWMERT ) then
   set merextract=`where extractor|head -1`
   if ("x$merextract" == "" ) then
      if ( -e ${0:h}/extractor ) then
         set merextract="${0:h}/extractor"
      else if ( -e ${newmert_dir}/extractor ) then
         set merextract="${newmert_dir}/extractor"
      endif
   endif
   if ( "$merextract" != "" ) then
      if ( -e "${merextract:h}/new-mert" ) then
         set merprog="${merextract:h}/new-mert"
      else
         set merprog="${merextract:h}/mert"
      endif
   endif
   if ( $?TUNE_MER ) then
      if { grep -i -q -s '^[ 	]*MOSES_MERT' $cfgfile } then
         #nothing
      else if { grep -i -q -s '^[ 	]*CUNEI' $cfgfile } then
         #nothing
      else
         echo You requested NEWMERT but did not enable either Output-Options:MOSES_MERT
	 echo or Output-Options:CUNEI
	 exit 2
      endif
   endif
else if ( $?TUNE_PANLITE_CMERT ) then
   set merprog=`where mert|head -1`
   set merscore=`where score-nbest.py|head -1`
   if ("$merprog" == "") then
      if ( -e ${0:h}/mert ) then
         set merprog="${0:h}/mert"
	 set merscore="${0:h}/score-nbest.py"
      else if ( -e ${cmert_dir}/mert ) then
         set merprog="${cmert_dir}/mert"
	 set merscore="${cmert_dir}/score-nbest.py"
      endif
   endif
   if ("$merscore" != "") then
      set PYTHONPATH="${merscore}:h/python"
   endif
   if ( $?TUNE_MER ) then
      if { grep -i -q -s '^[ 	]*MOSES_MERT' $cfgfile } then
         #nothing
      else
         echo You requested MOSES CMERT but did not enable Output-Options:MOSES_MERT
	 exit 2
      endif
   endif
else
   set merprog=`where OptimizeNBest|head -1`
   if ("$merprog" == "") then
      if ( -e ${0:h}/OptimizeNBest) then
         set merprog=${0:h}/OptimizeNBest
      else
        set merprog="${defdir}/OptimizeNBest"
      endif
   endif
endif
# if the MER training program can't be found, disable MER training
if ("$merprog" == "" || "$lmout2hyp" == "") unsetenv TUNE_MER

set interleave=`where interleave|head -1`
if ("$interleave" == "") then
   if ( -e ${0:h}/interleave ) then
      set interleave=${0:h}/interleave
   else
      set interleave=${defdir}/interleave
   endif
endif

if ($?TUNE_PANLITE_NORM) then
   set normscript=$TUNE_PANLITE_NORM
else
   set normscript=`where NormalizeTranslationsBLEU.pl|head -1`
endif
if ("$normscript" == "" ) then
   if ( x$merprog != x ) then
      set normscript=${merprog:h}/NormalizeTranslationsBLEU.pl
   else if ( -e ${0:h}/NormalizeTranslationsBLEU.pl) then
      set normscript=${0:h}/NormalizeTranslationsBLEU.pl
   else
      set normscript="${defdir}/NormalizeTranslationsBLEU.pl"
   endif
endif
if (! -e $normscript || ! -x $normscript) then
   set normscript=cat
endif

if ($?run_optimizer) then
   if ("$cunei" != "") then
      set evalname=cat
      set datafmt=text1
   else
      set evalname=cat
      set datafmt=interleave
   endif
else if ($evalmetric == mteval) then
   set evalname=mteval-v11b.pl
   set datafmt=sgml
else if ($evalmetric == modBLEU || $evalmetric == cmuBLEU) then
   set evalname=bleu-cmu.pl
   set datafmt=text1
else if ($evalmetric == TERcom) then
   set evalname=tercom_v5.pl
   set datafmt=tercom
else
   set evalname=Evaluate
   set datafmt=text
endif
set evalprog=`where $evalname|head -1`
if ("$evalprog" == "") then
   if ( -e $refdir/$evalname ) then
      set evalprog="$refdir/$evalname"
   else
      set evalprog="${defdir}/$evalname"
   endif
endif
if ( $evalname =~ *[.]pl ) set evalprog="perl $evalprog"

# set up our working directory
if ( ! $?TUNE_PANLITE_DIR ) then
   setenv TUNE_PANLITE_DIR tmp_0
endif
# convert relative to absolute path
if ( $TUNE_PANLITE_DIR !~ /* ) then
   setenv TUNE_PANLITE_DIR "${cwd}/$TUNE_PANLITE_DIR"
endif

# create the working directory
mkdir $TUNE_PANLITE_DIR >&/dev/null

# set the alias for whether to print out debugging messages
if ( $?showprogress ) then
   set message=echo
else
   # pick a program that ignores its command line and does nothing
   set message=true
endif
if ( $?showbest || $?showprogress ) then
   set msgbest=echo
else
   set msgbest=true
endif

# allow caller to override default ngram length for NIST/BLEU
if ($?TUNE_PANLITE_NGRAM) then
   set ngramlen=$TUNE_PANLITE_NGRAM
endif

if ( $?uncased ) then
   set recase='tr A-Z a-z'
else
   set recase=cat
endif

########################################################################
## check whether the parameter being changed permits us to use a cached
##   chart or not
##
unset lm_only
unset must_singletask
set chart="$TUNE_PANLITE_DIR/chart"
set mkchart="-c${chart}$$"
set prevcfg="$TUNE_PANLITE_DIR/prevcfg"
set prevtest="$TUNE_PANLITE_DIR/previnput"
if ( -e $prevcfg && -e ${chart} && ! -z ${chart} && $lmout2hyp != "" ) then
   # check whether the only differences between the previous and current
   # configuration files are in the language modeler section; if so, we
   # can re-use the stored chart
   set tmpcfg="$TUNE_PANLITE_DIR/cfg$$_"
   sed -e '/^\[LanguageModeler\]/,$d' $cfgfile >${tmpcfg}1
   sed -e '/^\[LanguageModeler\]/,$d' $prevcfg >${tmpcfg}2
   set nonLMdiffs=`diff ${tmpcfg}1 ${tmpcfg}2 | wc -l`
   if ( $nonLMdiffs == 0 ) set lm_only=yes
   # if the active parameter is in the LM section but there are differences
   #   outside the LM section, we can't fully parallelize
   if ( "x$3" == "x--test" ) then
      if ( `grep -ic "^${test} *[:=]" <${tmpcfg}1` == 0 ) then
         if ( $nonLMdiffs != 0 ) set must_singletask
      endif
   endif
   rm ${tmpcfg}1 ${tmpcfg}2
   # but we can't reuse the stored chart if the input file has changed
   if ( -e ${prevtest} && \
       `diff ${test} ${prevtest} |& wc -c` != 0 ) unset lm_only
endif
if ( "x$3" == "x--test" ) then
   if ( $?must_singletask ) then
      echo "SINGLE"
   else
      echo "MULTI"
   endif
   exit 0
endif

########################################################################
## set up the reference files in the proper format
##
@ numrefs = 0
set ref_files=""
set reflines=0
set cunei_refs=""
set refs_list=""
if ($datafmt == text || $datafmt == text1) then
   set refs=$TUNE_PANLITE_DIR/refs$$.txt
   set refs_int=$TUNE_PANLITE_DIR/refs_int$$.txt
   set test_sgm=""
   rm -f $refs
   foreach i (1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16)
      set r=${refdir}/ref${test:t:r}_${i}.txt
      if ( -e $r ) then
         if ("x$ref_files" == "x") set reflines=`wc -l <$r`
	 set ref_files="${ref_files} ${r}"
	 set cunei_refs="${cunei_refs} -ref ${r}"
	 if ( "x${refs_list}" != "x" ) set refs_list="${refs_list},"
	 set refs_list="${refs_list}${r}"
	 $normscript <$r | $recase >>$refs
         echo >>$refs
         @ numrefs = $numrefs + 1
      endif
   end # foreach
   # Evaluate wants the reference files interleaved
   if ($datafmt == text) \
      $interleave -n $ref_files | $normscript | $recase >$refs_int

else if ( $datafmt == tercom ) then
   set convert='{ printf "%s (Line%05d)\n", $0, FNR }'
   set ref_file=tmpref$$
   if ( -e $refdir/ref${test:t:r}_1.txt ) then
      awk "$convert" $refdir/ref${test:t:r}_1.txt >$ref_file
      foreach i (2 3 4 5 6 7 8 9 10 11 12 13 14 15 16)
         set r=$refdir/ref${test:t:r}_${i}.txt
         if ( -e $r ) then
            awk "$convert" $r >>$ref_file
	    if ( "x${refs_list}" != "x" ) set refs_list="${refs_list},"
	    set refs_list="${refs_list}${r}"
         endif
      end
   else
      echo No reference translations found
      exit 2
   endif

else if ( $datafmt == interleave ) then
   set ref_file=$TUNE_PANLITE_DIR/tmpref$$
   if ( -e $refdir/ref${test:t:r}_1.txt ) then
      set reflines=`wc -l <$refdir/ref${test:t:r}_1.txt`
      yes :REFS | head -n $reflines >/tmp/ref$$
      yes :END | head -n $reflines >/tmp/end$$
      interleave /tmp/ref$$ $refdir/ref${test:t:r}_*.txt /tmp/end$$ $test \
		>$ref_file
      rm /tmp/ref$$ /tmp/end$$
   else
      echo No reference translations found
      exit 2
   endif
else # datafmt == sgml
   # collect the reference translation files, and convert both them and the
   #   input text into the SGML format required by the scoring program (if not
   #   already in SGML format)
   #
   if ( -e $refdir/ref${test:t:r}.sgm ) then
      set refs=$refdir/ref${test:t:r}.sgm
      set reflines=`sed -e '/[<]seg /{' -e 's/[<]seg \([^>]*\)[>].*$/\1/' \
			-e 'p' -e '}' -e 'D' $refs | sort -u | wc -l`
      if ( $?TUNE_MER ) then
         if ( ! -e $refdir/ref${test:t:r}_1.txt ) then
            echo No plain-text reference translations found, MER disabled
            unsetenv TUNE_MER
         else
            foreach i (1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16)
               set r=${refdir}/ref${test:t:r}_${i}.txt
               if ( -e $r ) then
      	          set ref_files="${ref_files} ${r}"
	          @ numrefs = $numrefs + 1
	          if ( "x${refs_list}" != "x" ) set refs_list="${refs_list},"
	          set refs_list="${refs_list}${r}"
	       endif
	    end
         endif
      endif
   else if ( ! -e $refdir/ref${test:t:r}_1.txt ) then
      echo No reference translations found
      exit 2
   else
      set refs=$TUNE_PANLITE_DIR/refs$$.sgm
      set test_sgm=$TUNE_PANLITE_DIR/input$$.sgm
      echo '<refset setid="sentences" srclang="source" trglang="target">' >$refs
      echo '<srcset setid="sentences" srclang="source">' >$test_sgm
      grep -v '^:' ${test} | \
        perl	-e 'my $i = 1 ;' \
	-e 'print "<DOC docid=\"testdoc\">\n" ;' \
	-e 'while (<>) {' \
	-e '  $_ =~ s/\n// ; ' \
	-e '  print "<seg id=" . $i . "> " . $_ . " </seg>\n" ;' \
	-e '  $i += 1 ; }' >>$test_sgm
      echo "</DOC>" >>$test_sgm
      echo "</srcset>" >>$test_sgm
      foreach i (1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16)
         set r=$refdir/ref${test:t:r}_${i}.txt
         if ( -e $r ) then
	    set ref_files="${ref_files} ${r}"
	    set reflines=`wc -l <${r}`
   	    @ numrefs = $numrefs + 1
	    if ( "x${refs_list}" != "x" ) set refs_list="${refs_list},"
	    set refs_list="${refs_list}${r}"
	    perl -e 'my $numrefs='$numrefs' ;' \
		-e 'my $i = 1 ;' \
		-e 'print "<DOC docid=\"testdoc\" sysid=\"ref" . $numrefs . "\">\n" ;' \
		-e 'while (<>) {' \
		-e '  $_ =~ s/\n// ; ' \
		-e '  print "<seg id=" . $i . "> " . $_ . " </seg>\n" ;' \
		-e '  $i += 1 ; }' <${r} \
		>>$refs
	    echo "</DOC>" >>$refs
         endif
      end
      echo "</refset>" >>$refs
   endif
endif # datafmt == text/sgml

if ( $?TUNE_MER  && "x$ref_files" != "x") then
   set mer_refs=$TUNE_PANLITE_DIR/refs_all$$.txt
   paste -d '' $ref_files | \
	sed -e 's//\n/g' >$mer_refs
endif

########################################################################
## update cached files
##
cp -p $test $prevtest
chmod u+w $prevtest
cp $cfgfile $prevcfg
if ( $?TUNE_PANLITE_KEEPTMP ) cp -p $cfgfile "$TUNE_PANLITE_DIR/hyp$$.cfg"
if ( $?TUNE_MER_FINAL && ! $?final_run ) unsetenv TUNE_MER
if ( ! $?lm_only ) then
   if ( ! $?TUNE_MER_ALWAYS && ! $?final_run ) unsetenv TUNE_MER
endif

########################################################################
## perform external optimization if requested

if ( $?run_optimizer ) then
   set newwt=$TUNE_PANLITE_DIR/weights$$
   set newcfg=$TUNE_PANLITE_DIR/newcfg$$
   set cunei_eval=$TUNE_PANLITE_DIR/eval$$.sh
   set chart=$TUNE_PANLITE_DIR/opt$$.chart
   if ("$cunei" != "") then
      #### run Cunei's optimizer ####
      set opt=$TUNE_PANLITE_DIR/optcfg$$
      set log=$TUNE_PANLITE_DIR/anneal$$.log
      # extract the current weights into a file for the optimizer
      sed -e '1,/^\[LMWeights\]/d' $cfgfile | \
	sed -e '/^\[/,$d' -e 's/^\([-A-Za-z0-9_]*\) *[:=] */Feature.\1: /' >$opt
      # make a copy to simplify the eval-command script
      cp -p ${opt} ${opt}.opt
      # remove cached chart if a non-LM parameter has changed
      if ( ! $?lm_only ) then
         rm -f ${chart} >&/dev/null
      endif
      # generate the eval-command script
      echo '#\!/bin/csh -f' >$cunei_eval
      echo "sed -e 's/^[ 	][ 	]*[\\!-]CUNEI/	CUNEI/' -e '/^\[LMWeights\]/,/^\[/{' -e '/^\[LMWeights\]/d' -e '/^\[/\\!d' -e '}' $cfgfile >$newcfg" >>$cunei_eval
      echo "echo '[LMWeights]' >>$newcfg" >>$cunei_eval
      echo "grep '^Feature\.' ${opt}.opt | sed -e 's/^Feature\.//' >>$newcfg" >>$cunei_eval
      echo "if ( ! -e ${chart} ) then" >>$cunei_eval
      echo "  $mtprog -s${newcfg} -c${chart} -E-LM -q+ <$test >&/dev/null" >>$cunei_eval
      echo "endif" >>$cunei_eval
      echo "$lmprog -s${newcfg} -b${cunei_nbest} -r+ -Q+ -K- -O- . $chart" >>$cunei_eval
      # make the eval-command script executable
      chmod u+x $cunei_eval
      $cunei Optimize $opt $cunei_refs -eval-command $cunei_eval \
		-gamma 0.032 -max-gamma 4 -accel 5 \
		-output $log \
		-debug info >>& $TUNE_PANLITE_DIR/cunei-anneal.err
      grep '^Feature\.' ${opt}.opt | sed -e 's/^Feature\.//' >$newwt
      # we need to dump something to stdout to keep the caller happy,
      # but have to finish all cfgfile editing first
      set msg="`grep '@ BLEU' $log | tail -n 1`"
   else
      #### run Panlite's internal optimizer ####
      # avoid accidentally re-using an old chart
      rm -f ${chart} >&/dev/null
      set sysout=$TUNE_PANLITE_DIR/opt$$
      $mtprog -Op5,1000,0.000,1,0.001 -s$cfgfile <$ref_file >&$sysout
#      $mtprog -Op5,1000,0.000,1,0.001 -s$cfgfile <$ref_file |& tee $sysout
      # extract the updated weights
      sed -e '1,/^\[LMWeights\]/d' $sysout | sed -e '/^\[/,$d' >$newwt
      # we need to dump something to stdout to keep the caller happy,
      # but have to finish all cfgfile editing first
      set msg="`grep 'Best objective' $sysout | sort -k 6nr | head -n 1`"
      rm $ref_file
      if ( ! $?TUNE_PANLITE_KEEPTMP ) rm $sysout
   endif
   # insert the new weights into the config file
   if (`wc -l <$newwt` != 0 ) then
      sed -e '/^\[LMWeights\]/,/^\[/{' -e '/^\[LMWeights\]/d' -e '/^\[/\!d' -e '}' $cfgfile >$newcfg
      echo "[LMWeights]" | cat $newcfg - $newwt >$cfgfile
   endif
   rm -f $newcfg >&/dev/null
   if ( ! $?TUNE_PANLITE_KEEPTMP ) rm $newwt
   if ("x$msg" != "x") echo $msg
   exit 0
endif

########################################################################
## perform MER training if requested
##
if ( $?TUNE_MER ) then
   if ("x$refs_list" == "x") then
      echo "No list of reference files!"
   endif
   # generate a chart file if necessary
   #   (final run might be using a different input file)
   if ( ! $?lm_only || $?final_run ) then
      $mtprog -q+ -: -s$cfgfile $mkchart -E-LM <$test >&/dev/null
      if ( -e ${chart}$$ ) mv ${chart}$$ ${chart}
   endif
   # remove any document boundaries from the source since they mess up the MER
   set mersrc=$TUNE_PANLITE_DIR/mer_src.txt
   grep -v '^ *:' $test >$mersrc
   # set how many times to perform the MER optimization (since it starts from
   #   random points)
   set iter=1
   set mer_runs=1
   set merlimit=20
   set merpoints=10
   if ( $?final_run ) then
      if ( $?TUNE_PANLITE_NEWMERT ) then
         set iter=3
	 if ( $TUNE_MER == "0" ) then
	    set mer_runs=0
	 else
            set mer_runs=15
	 endif
	 set merpoints=10
         set merlimit=4   # only look at system output of N most recent runs
      else if ( $?TUNE_PANLITE_CMERT ) then
         set iter=3
	 if ( $TUNE_MER == "0" ) then
	    set mer_runs=0
	 else
            set mer_runs=15
	 endif
         set merlimit=4   # only look at system output of N most recent runs
      else
         set iter=5
         set mer_runs=1
      endif
   endif
   #set tracelvl=" -1"
   set tracelvl="0"
   set prev_nbest_size="-1"
   set newval=""
   set prev_ffile=""
   set prev_scfile=""
   foreach run (`seq -w 1 $mer_runs`)
      set merval=$TUNE_PANLITE_DIR/mer$$_${run}.result
      set merout=$TUNE_PANLITE_DIR/mer$$_${run}.out
      set merhyp=$TUNE_PANLITE_DIR/mer$$_${run}.hyp
      set mernames=$TUNE_PANLITE_DIR/mer$$.names
      set mererr=$TUNE_PANLITE_DIR/mer$$.err
      # decode the current chart, dumping out an n-best list with scores
      $lmprog -s$cfgfile -b$TUNE_MER -Q+ -K- -O- -r+ -T0 . ${chart} >& $merout
      # extract just the bits of the output that we need
      grep "^;.*Verbosity" $merout | head -1 | sed -e 's/^; *//' >$mernames
      if ( $?TUNE_PANLITE_NEWMERT) then
         grep -e ' |||' $merout | gzip > ${merhyp}.gz
      else if ( ! $?TUNE_PANLITE_CMERT ) then
         $lmout2hyp < $merout > ${merhyp}
      else if { grep -s -q -e '^0 |||' $merout } then
         grep -e ' |||' $merout | gzip > ${merhyp}.gz
      else
         grep -e '^|||' -e '^{}' $merout | \
	     awk 'BEGIN{id=0} {if($0=="{}") id++; else print id,$0;}' | \
	     gzip > ${merhyp}.gz
      endif
      set names=(`cat $mernames`)
      set dim=`wc -w <$mernames`
      $message "[MESSAGE] features=$names"
#      if ( ! $?TUNE_PANLITE_KEEPTMP ) then
	 rm -f $merout
#          rm $mernames
#      endif
      # pull out the initial values of the scaling factors from the config
      #   file that we used for decoding
      set scaling=""
      set min=""
      set max=""
      set first
      if ( $?TUNE_PANLITE_CMERT || $?TUNE_PANLITE_NEWMERT ) then
         set scoresep=" "
      else
         set scoresep="_"
      endif
      foreach name ($names)
	 if ($?first) then
	    unset first
	 else
	    set min="${min}${scoresep}"
	    set max="${max}${scoresep}"
	    set scaling="${scaling}${scoresep}"
         endif
	 set value="0.1"		# default if not in config file
	 if ( $?TUNE_PANLITE_CMERT ) then
	    set mn="-100"		# smallest allowable value for parm
	 else
	    set mn="-0.0001"		# smallest allowable value for parm
	 endif
	 set mx="+100.0"		# largest allowable value for parm
	 if ( $name =~ WeightOf-User* ) then
	    set value="0"
	    set mx="+1000"
	    set mn="-1000"
	 endif
	 set val=`grep -i "^${name}[ 	]*[:=]" $cfgfile | tail -1 | \
		sed -e 's/^[^:=]*[:=][ 	]*\([-+0-9.][-+0-9.eE]*\).*$/\1/'`
         echo "  val($name)=$val" >>$mererr
	 if ( "x$val" != "x" ) then
	    set value=$val
	 else if ($value == 0) then
	    set mn="0"
	    set mx="0"
	 endif
	 set min="${min}${mn}"
	 set max="${max}${mx}"
	 set scaling="${scaling}${value}"
      end
      echo "scaling=$scaling" >>$mererr
      echo "min=$min" >>$mererr
      echo "max=$max" >>$mererr
      $message "[MESSAGE] scaling=$scaling"
      if ( $?TUNE_PANLITE_NEWMERT ) then
	 pushd $TUNE_PANLITE_DIR >&/dev/null
	 $message "[MESSAGE] creating init.opt..."
	 echo "$scaling" >> init.opt
	 $message "[MESSAGE] extracting feature values and scores"
	 set ffile="feat$$_${run}.data"
	 set scfile="score$$_${run}.data"
	 $merextract -r "$refs_list" -n "${merhyp}.gz" -S "${scfile}" -F "${ffile}"
	 set prev_ffile=`ls feat$$_*.data| tail -$merlimit | sed -e 's/$/,/'`
	 set prev_ffile=`echo $prev_ffile| sed -e 's/ //g' -e 's/,$//'`
	 set prev_scfile=`ls score$$_*.data| tail -$merlimit | sed -e 's/$/,/'`
	 set prev_scfile=`echo $prev_scfile| sed -e 's/ //g' -e 's/,$//'`
	 set mertlog=mert$$_${run}.log
	 $message "[MESSAGE] executing mert: -d $dim -n $merpoints -S $prev_scfile -F $prev_ffile >$mertlog"
	 $merprog -d $dim -n $merpoints -S "$prev_scfile" -F "$prev_ffile" >& $mertlog

         ## update the configuration file with the new values
	 set oldval=($newval)
	 set val=(`grep '^Best point:' $mertlog | sed -e 's/^Best point: //' -e 's/=>.*$//'`)
	 set newval="$val"
	 if ( "x$val" == "x" ) then
	    echo "tuned parameter detection error"
	    exit
	 endif
	 set bestparam=`grep '^Best point:' $mertlog`
	 $msgbest "[MESSAGE] Current $bestparam"
	 mv weights.txt weights$$_${run}.txt
	 popd >&/dev/null

	 if ( "x$oldval" != "x" ) then
	    set minimum_change="0.00001"
	    set shouldstop="1"
	    foreach v ($newval)
		set mytest=`perl -e 'if(abs(('${oldval[1]}')-('$v'))>'$minimum_change'){ print "1"; } else { print "0"; }'`
		$message "MYTEST OLD:${oldval[1]} NEW:$v MYTEST:$mytest"
		if ( "x$mytest" == "x1" ) then
		   set shouldstop="0"
		endif
		shift oldval
	    end
	    if ( $shouldstop == "1" ) then
		$message "[MESSAGE] no significant change in weights.. Done."
		break
	    endif
	endif

      else if ( $?TUNE_PANLITE_CMERT ) then
	 pushd $TUNE_PANLITE_DIR >&/dev/null
	 set hypfiles=(`ls -rt *.hyp.gz | tail -$merlimit`)
         (zcat $hypfiles | sort -n -t "|" -k 1,1 | \
		$merscore $ref_files ${cd}/ ) >&/dev/null
 	 set curr_nbest_size=`wc -l <feats.opt`
	 $message "[MESSAGE] Current N-best Size: $curr_nbest_size"
	 if ( $prev_nbest_size == $curr_nbest_size ) then
	    $message "[MESSAGE] no change in nbest_size.. Done."
	    break
	 endif
	 set prev_nbest_size=$curr_nbest_size
	 $message "[MESSAGE] creating init.opt..."
	 echo "$min" > init.opt
	 echo "$max" >> init.opt
	 echo "$scaling" >> init.opt
	 $message "[MESSAGE] executing mert..."
	 if ( "x$dim" == "x" || "x$dim" == "x0" ) then
	    echo "score dimension detection error"
	    exit
	 endif
	 set mertlog=cmert$$_${run}.log
	 $message "[MESSAGE] $merprog -d $dim -n $merpoints >& $mertlog"
	 $merprog -d $dim -n $merpoints >& $mertlog

         ## update the configuration file with the new values
	 set oldval=($newval)
	 set val=(`grep '^Best point:' $mertlog | sed -e 's/^Best point: //' -e 's/=>.*$//'`)
	 set newval="$val"
	 if ( "x$val" == "x" ) then
	    echo "tuned parameter detection error"
	    exit
	 endif
	 set bestparam=`grep '^Best point:' $mertlog`
	 $msgbest "[MESSAGE] Current $bestparam"
	 mv init.opt init$$_${run}.opt
	 mv cands.opt cands$$_${run}.opt
	 mv feats.opt feats$$_${run}.opt
	 mv weights.txt weights$$_${run}.txt
	 gzip cmert$$_${run}.log init$$_${run}.opt
         gzip cands$$_${run}.opt feats$$_${run}.opt
	 popd >&/dev/null

	 if ( "x$oldval" != "x" ) then
	    set minimum_change="0.00001"
	    set shouldstop="1"
	    foreach v ($newval)
		set mytest=`perl -e 'if(abs(('${oldval[1]}')-('$v'))>'$minimum_change'){ print "1"; } else { print "0"; }'`
		$message "MYTEST OLD:${oldval[1]} NEW:$v MYTEST:$mytest"
		if ( "x$mytest" == "x1" ) then
		   set shouldstop="0"
		endif
		shift oldval
	    end
	    if ( $shouldstop == "1" ) then
		$message "[MESSAGE] no significant change in weights.. Done."
		break
	    endif
	endif

      else # !TUNE_PANLITE_CMERT
         ($merprog --SourceSentencesFile $mersrc --NBestListsFile $merhyp \
	    --ReferencesFile $mer_refs --NumReferences $numrefs \
	    --NormalizingScript $normscript \
	    --IterationLimit $iter --ScoringMetric $metric \
	    --TraceLevel $tracelvl \
	    --ScalingFactors $scaling --Opti_TwoStage 0 --Opti_Epsilon 0.0001 \
	    --Opti_LeftRange $min --Opti_RightRange $max --Opti_DoNorm 1 \
	    --Opti_NumStarts 3 --Opti_NumPermutes 3 --Opti_NumModify 2 \
	    --DoNormalize 1 |& tail -30 >$merval ) >>&$mererr

         ## update the configuration file with the new values
         set val=(`grep '^[123]:' $merval| sort -k 4nr | head -1 | \
   	       sed -e 's/^.* \([^ ][^ ]*\) *$/\1/' -e 's/_/ /g'`)
      endif
      $message "VALUES=${val}"
      if ( $#names > 0 && $#val == $#names ) then
         foreach i ($names)
	    set v=${val[1]}
            (sed -e "/^\[LanguageModeler\]/,999999s/^\(${i}\)[ 	]*[:=].*/\1=${v}/i" \
	  	   $cfgfile >tmp$$ ) >&/dev/null
            if ( ! -z tmp$$ ) mv tmp$$ $cfgfile
            shift val
         end
	 if ( $?TUNE_PANLITE_KEEPTMP ) \
		cp -p $cfgfile $TUNE_PANLITE_DIR/mer$$_${run}.cfg
      else
         echo "Mismatch between parameters and settings: " >>$mererr
         echo "  names = $names" >>$mererr
         echo "  value = $val" >>$mererr
         cp -p $cfgfile $TUNE_PANLITE_DIR/mer$$_${run}.cfg
      endif
   end # foreach run
   ## and now force final decoding run with scoring
   set lm_only
   set mkchart=""
endif # $?TUNE_MER

########################################################################
## perform the translation
##
if ( $?TUNE_POSTCMD ) then
   set postcmd=$TUNE_POSTCMD
else
   echo 's/[<]epsilon[>]/ /g' >>$TUNE_PANLITE_DIR/tmpeval$$.sed
   echo 's/^ *$/the/' >>$TUNE_PANLITE_DIR/tmpeval$$.sed
   set postcmd="sed -u -f $TUNE_PANLITE_DIR/tmpeval$$.sed"
endif

set sysout=$TUNE_PANLITE_DIR/hyp$$.txt
if ( $?lm_only ) then
   ($lmprog -s$cfgfile -Q+ -K- -O- -T0 . ${chart} | $lmout2hyp | \
    $postcmd >$sysout) >&/dev/null
else
   ($mtprog -q+ -: -s$cfgfile $mkchart <$test | $postcmd >$sysout) >&/dev/null
   if ( -e ${chart}$$ ) mv ${chart}$$ ${chart}
endif
rm -f $TUNE_PANLITE_DIR/tmpeval$$.sed

########################################################################
## preprocess and score the system output
##
if ( $datafmt == text || $datafmt == text1 ) then
   # normalize the system output
   set hyp=$TUNE_PANLITE_DIR/hyp$$.text
   $normscript <$sysout | $recase >$hyp
   # score the system output and extract just the score of interest
   if ( $datafmt == text ) then
      $evalprog -r $refs_int -t $hyp -n $numrefs -m $evalmetric \
		>& ${hyp:r}.score
   else
      $evalprog $hyp $refs_list ${ngramlen} >& ${hyp:r}.score
   endif
   grep "HypSent=" ${hyp:r}.score | \
	sed -e 's/^[-A-Z]*[:=] *\([0-9][0-9.]*\) .*$/\1/'
   grep "^${ngramlen}-gram" ${hyp:r}.score | \
	sed -e 's/^.*score: \([0-9][0-9.]*\) *$/\1/'
   grep "^FinalScoreMod," ${hyp:r}.score | sed -e 's/^[^,]*,//'
   if { grep -s -q "HypSent=" ${hyp:r}.score } then
      # do nothing
   else if { grep -s -q "^${ngramlen}-gram" ${hyp:r}.score } then
      # do nothing
   else if { grep -s -q "^FinalScoreMod," ${hyp:r}.score } then
      # do nothing
   else
      set hyplines=`wc -l <$hyp`
      @ diff = $hyplines - $reflines
      if ( $diff =~ -* ) then
         echo Short sysoutput - $hyplines lines
      else if ( $diff != 0 ) then
         echo Long sysoutput - $hyplines lines
      else
         echo Scoring error
      endif
   endif
else if ( $datafmt == tercom ) then
   awk "$convert" $sysout >tmpeval$$
   $evalprog -r $ref_file -h tmpeval$$ -o sum -n ${test:t:r} >&tmpeval$$.trace
   tail -3 ${test:t:r}.sum | grep TOTAL | \
	sed -e 's/^.*[ 	]\([0-9.]*\) *$/\1/'

else # $datafmt == sgml
   # convert system output into SGML format
   set hyp=$TUNE_PANLITE_DIR/hyp$$.sgm
   echo '<tstset setid="sentences" srclang="source" trglang="target">' >$hyp
   perl	-e 'my $i = 1 ;' \
	-e 'print "<DOC docid=\"testdoc\" sysid=\"MT\">\n" ;' \
	-e 'while (<>) {' \
	-e '  $_ =~ s/\n// ; ' \
	-e '  print "<seg id=" . $i . "> " . $_ . " </seg>\n" ;' \
	-e '  $i += 1 ; }' <$sysout >>$hyp
   echo "</DOC>" >>$hyp
   echo "</tstset>" >>$hyp
   # score the system output and extract just the score of interest
   $evalprog -r $refs -s $test_sgm -t $hyp  >& ${hyp:r}.score
   if { grep -q -s "BLEU score =" ${hyp:r}.score } then
      grep "BLEU score =" ${hyp:r}.score | \
         sed -e 's/^.*BLEU score = \([0-9.]*\) for system.*/\1/'
   else
      set hyplines=`wc -l <$sysout`
      @ diff = $hyplines - $reflines
      if ( $diff =~ -* ) then
         echo Short sysoutput
      else if ( $diff != 0 ) then
         echo Long sysoutput - $hyplines lines
      else
         echo Scoring error - $hyplines lines
      endif
   endif
endif
# for standalone use, let user know size of output
wc -w -c <$sysout

########################################################################
## clean up
##
if ( $?mer_refs ) then
   if ( "x$mer_refs" != "x" ) then
      rm -f $mer_refs
   endif
endif
if ( ! $?TUNE_PANLITE_KEEPTMP ) then
   rm -f $refs $test_sgm $sysout $hyp ${hyp:r}.score >&/dev/null
   rm -f tmpeval$$ tmpeval$$.trace ${test:t:r}.sum tmpref$$
   if ($?refs_int) then
      rm -f $refs_int >&/dev/null
   endif
endif

# sleep half a second before exiting so that caller can get our result
usleep 500000
exit
