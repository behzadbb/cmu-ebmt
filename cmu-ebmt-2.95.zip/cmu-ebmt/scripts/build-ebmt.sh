#!/bin/csh -f
# LastEdit: 08apr10
##	by Ralf Brown <ralf@cs.cmu.edu>					##
##									##
##  (c) Copyright 2005,2006,2007,2008,2009,2010 Ralf Brown		##
##	This program is free software; you can redistribute it and/or	##
##	modify it under the terms of the GNU General Public License as	##
##	published by the Free Software Foundation, version 3.		##
##									##
##	This program is distributed in the hope that it will be		##
##	useful, but WITHOUT ANY WARRANTY; without even the implied	##
##	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		##
##	PURPOSE.  See the GNU General Public License for more details.	##
##									##
##	You should have received a copy of the GNU General Public	##
##	License (file COPYING) along with this program.  If not, see	##
##	http://www.gnu.org/licenses/					##

set rev=""
set revrev="-r"
set revcfg=""
set prealigned=""
set canoninput=""
set alignargs=""
set enc="Latin-1"
set stopwords=""
set autostop=""
set clustopt=""
set tunefile=""
set tuneopt=""
unset keeptmp
unset runalign
unset runclust
unset nobuilddict
unset runquietly
unset skip_indexing
unset truecase_tgt
set nophrases
set numclus="20"
set minfreq="@1000"
set tmpdir=tmp_$$

## ASPA setup
set gizaebmt=/usr/jdkim/work/ebmt_dict
set jaedydir=/afs/cs/user/jdkim/bin/
set aspadir=/usr/jdkim/tools/spa_anchor/
set RATIO=0.5

while ( $#argv > 0 && x$1 =~ x-* )
   switch ($1)
      case "-a":
         set prealigned="-a"
	 set canoninput="-@"  # EBMT input breaks on whitespace only
	 breaksw
      case "-A":
         set runalign
	 set tunealign
         set alignlang="$2"
	 shift
	 breaksw
      case "-An":
         set runalign
         set alignlang="$2"
	 shift
	 breaksw
      case '-Ao':
         set alignargs="$2"
	 shift
	 breaksw
      case "-b":
         shift
	 set revcfg="$1"
	 breaksw
      case "-c":
         set runclust
         shift
	 set numclus="$1"
	 shift
	 if ("x$1" != "x-") set minfreq=$1
         breaksw
      case "-co":
         shift
	 set clustopt="$1"
         breaksw
      case "-cs":
         shift
         set autostop="-f-@$1"
	 breaksw
      case "-d":
         set nobuilddict
	 breaksw
      case "-D":
         set truecase_tgt
	 breaksw
      case "-i":
         set skip_indexing
	 breaksw
      case "-k":
	 set keeptmp
	 breaksw
      case "-p":
         unset nophrases
	 breaksw
      case "-q":
	 set runquietly
	 breaksw
      case "-r":
         set rev=-r
	 set revrev=""
	 breaksw
      case "-s":
         shift
         set stopwords="-S$1"
	 breaksw
      case "-t":
	 shift
	 set tmpdir="$1"
	 breaksw
      case "-T":
         shift
	 set tunefile="$1"
	 breaksw
      case "-To":
      case "-TO":
         shift
	 set tuneopt="$1"
	 breaksw
      case "-U":
	 shift
	 set enc=$1
	 breaksw
      default:
         echo "Unknown flag $1"
         breaksw
   endsw
   shift
end

if ( $#argv < 4 ) then
   echo "Usage: $0:t [flags] cfgfile iterations filelist thresh1 [thresh2]"
   echo "Flags:"
   echo "	-a	corpus is already annotated with alignments"
   echo "	-A l    run ASPA aligner for language 'l' to English"
   echo "	-An l   run ASPA aligner for language 'l' to English, don't tune"
   echo "	-Ao 'x'	pass additional option(s) 'x' to ASPA aligner"
   echo "	-c C F	run clustering to find C clusters of words with freq >= F"
   echo "		(use @F to cluster F most frequent terms)"
   echo "	-co 'x'	pass option(s) 'x' to clustering program"
   echo "    	-cs N	exclude N most frequent non-stopwords from clustering"
   echo "	-D	downcase (truecase) starts of sentence in target lang"
   echo "	-d	skip dictionary build, use existing dictionary files"
   echo "	-i	run all processing except final indexing of corpus files"
   echo "	-k	keep temporary files"
   echo "	-p	use ASPA-generated phrasal alignments"
   echo "	-q	run quietly (omit detailed progress)"
   echo "	-r	reverse languages"
   echo "  	-s F	set clustering stopwords from file F"
   echo "    	-t D	use directory D for temporary files"
   echo "   	-T F	run parameter tuning on test input file F"
   echo "   	-To 'x'	pass option(s) 'x' to parameter tuning script"
   echo "	-U enc	char encoding for truecaser/clustering (default Latin-1)"
   echo "Note:"
   echo "  'filelist' must contain absolute paths when using -D"
   exit 1
endif

# grab the commandline parameters
set cfg=$1
set iter=$2
set list=$3
set thr1=$4
set thr2=$5

if ( $?skip_indexing ) then
   # don't tune if we don't actually index the corpus
   set tunefile=""
endif

#################################################################
## figure out where this script is located, so that we can run
## the helper scripts and programs

set root=$0:h
if ( $root == $0 ) set root=.

set editcfg="`where editcfg.sh|head -1`"
if ( "$editcfg" == "" ) set editcfg=$root/editcfg.sh
if ( ! -e $editcfg || ! -x $editcfg ) then
   echo "Unable to find 'editcfg.sh' program.  Aborting."
   exit 1
endif

set ebmt="`where ebmt|head -1`"
if ( "$ebmt" == "" ) set ebmt="$root/ebmt"
if ( ! -e $ebmt || ! -x $ebmt ) then
   echo "Unable to find EBMT program.  Aborting."
   exit 1
endif

set builddict="`where build-dict.sh|head -1`"
if ( "$builddict" == "") set builddict=$root/build-dict.sh
if ( ! $?nobuilddict && ( ! -e $builddict || ! -x $builddict )) then
   echo "Unable to find 'build-dict.sh' program.  Aborting."
   exit 1
endif

set wordclus="`where wordclus|head -1`"
if ( "$wordclus" == "") set wordclus="$root/wordclus"
if ( $?runclust && (! -e $wordclus || ! -x $wordclus )) then
   unset runclust
   echo "Unable to find 'wordclus' program, will skip clustering"
endif

set downcase="`where downcase|head -1`"
if ( "$downcase" == "") set downcase="$root/downcase"
if ( $?truecase_tgt && (! -e $downcase || ! -x $downcase )) then
   unset truecase_tgt
   echo "Unable to find 'downcase' program, will skip truecasing of sentence starts"
endif
if ( $?truecase_tgt && $?rev ) then
   set truecase_tgt="$rev"
endif

set tuneprog="`where tune-panlite.sh|head -1`"
if ( "$tuneprog" == "" ) set tuneprog="$root/tune-panlite.sh"
if ( "x$tunefile" != "x" && ( ! -e $tuneprog || ! -x $tuneprog )) then
   echo "Unable to find tune-panlite.sh program.  Aborting."
   exit 1
endif

set embed="`where embed-sp|head -1`"
if ( "$embed" == "") set embed="$root/embed-sp"
if ( $?runalign && (! -e $embed || ! -x $embed )) then
   unset runalign
   echo "Unable to find 'embed-sp' program, will skip external aligner"
endif

set aligner="`where aspa|head -1`"
if ( "$aligner" == "") set aligner=$aspadir/aspa
if ( $?runalign && ( ! -e $aligner || ! -x $aligner )) then
   unset runalign
   echo "Unable to find 'aspa' aligner program, will skip external aligner"
endif

set spatune="`where spa_tune_arg-ebmt.sh|head -1`"
if ( "$spatune" == "") set spatune=$aspadir/spa_tune_arg-ebmt.sh
if ( $?tunealign && ( ! -e $spatune || ! -x $spatune )) then
   unset tunealign
   echo "Unable to find SPA tuner program, won't tune external aligner"
endif

set filterdict="`where filter_dict.pl|head -1`"
if ( "$filterdict" == "" ) set filterdict=$jaedydir/filter_dict.pl
if ( $?tunealign && ( ! -e $filterdict || ! -x $filterdict )) then
   unset tunealign
   echo "Unable to find 'filter_dict.pl' program, won't tune external aligner"
endif

set mkdic="`where mkdic|grep -v /usr/bin/mkdic|head -1`"
if ( "$mkdic" == "" ) set mkdic=$gizaebmt/mkdic
if ( $?runalign && ( ! -e $mkdic || ! -x $mkdic )) then
   unset runalign
   echo "Unable to find 'mkdic' program, will skip external aligner"
endif

set fltdict="`where fltdict|head -1`"
if ( "$fltdict" == "" ) set fltdict=$aspadir/fltdict
if ( 0 && $?runalign && ( ! -e $fltdict || ! -x $fltdict )) then
   unset runalign
   echo "Unable to find 'fltdict' program, will skip external aligner"
endif

set idfsent="`where idf_sent.pl|head -1`"
if ( "$idfsent" == "" ) set idfsent=$jaedydir/idf_sent.pl
if ( $?runalign && ( ! -e $idfsent || ! -x $idfsent )) then
   unset runalign
   echo "Unable to find 'idf_sent.pl' program, will skip external aligner"
endif

# ensure that relative paths for the configuration files
# explicitly start at the current directory
if ( $cfg !~ [./]* ) set cfg=./$cfg
if ( "$revcfg" != "" && $revcfg !~ [./]* ) set revcfg=./$revcfg

#################################################################
##  create the directory tree, assuming standard locations

set basedir=$cfg:h
if ( x$basedir == x$cfg ) set basedir=.
if ( $basedir == cfg ) set basedir=.
if ( $basedir:t == cfg ) set basedir=$basedir:h

set langpair=$cfg:t:r
mkdir $basedir/ebmt/{,align,$langpair} >&/dev/null
mkdir $basedir/gloss/,$langpair} >&/dev/null

# set up our scratch space
mkdir ${tmpdir} >&/dev/null


#################################################################
## if we are running the external aligner, build a reverse dictionary

@ lastiter = $iter - 1

if ( $?runalign ) then
   set ARGUMENT=(--basic_lambda=0.5 --src_word_idf_threshold=100.0 \
		--tgt_word_idf_threshold=100.0)
   set ANSWER="/dev/null"
   set ANSDIR=/usr/jdkim/data/human_aligned
   set T_ARGUMENT=""
   set lang="x"
   switch ($alignlang)
      case "a":
      case "-a":
      case "arabic":
	 set ANSWER=$ANSDIR/ar_en/Arabic-aligned.utf8.rm-diacritics.txt_${RATIO}
	 set lang=a
         breaksw
      case "c":
      case "-c":
      case "chinese":
	 set ARGUMENT=($ARGUMENT --lower_case=yes)
 	 set ANSWER=$ANSDIR/cn_en/align.all_${RATIO}
	 set T_ARGUMENT=(--second_score_ratio=0.0 \
		--second_score_threshold=-50.0 \
		--first_score_ratio=0.0 \
		--first_score_threshold=-50.0 \
		--sent_posi_gap=8.0 )
	 set lang=c
	 breaksw
      case "cu":
      case "-cu":
      case "chinese-utf8":
	 set ARGUMENT=($ARGUMENT --lower_case=yes)
 	 set ANSWER=$ANSDIR/cn_en/align.utf8.all_${RATIO}
	 set T_ARGUMENT=(--second_score_ratio=0.0 \
		--second_score_threshold=-50.0 \
		--first_score_ratio=0.0 \
		--first_score_threshold=-50.0 \
		--sent_posi_gap=8.0 )
	 set lang=c
	 set tunelang=cu
	 breaksw
      case "f":
      case "-f":
      case "french":
	 set ARGUMENT=($ARGUMENT --anchor_lambda=0.8 --sent_len_gap=4)
	 set ANSWER=$ANSDIR/fr_en/aligned_14jul04.txt_${RATIO}
	 set T_ARGUMENT=(--second_score_ratio=0.0 \
		--second_score_threshold=-30.0 \
		--first_score_ratio=1.1 \
		--first_score_threshold=-4.0 \
		--sent_posi_gap=3.3 )
	 set lang=f
	 breaksw
      case "k":
      case "-k":
      case "korean":
	 set ARGUMENT=($ARGUMENT --lower_case=yes)
	 set ANSWER=$ANSDIR/kr_en/kor_eng.jaedy.align_${RATIO}
	 set lang=k
	 breaksw
   endsw
   if ( ! $?tunelang ) set tunelang=$lang
endif

if ( $cfg !~ /* ) then
   set cfg="${cwd}/$cfg"
endif

if ("$revcfg" == "") then
   set rvcfg=${tmpdir}/${cfg:t}
   sed -e 's/^Source-Regex[:=]/S-Regex:/' \
       -e 's/^Target-Regex[:=]/Source-Regex:/' \
       -e 's/^S-Regex:/Target-Regex:/' $cfg >$rvcfg
   pushd ${tmpdir} >&/dev/null
   ln -s ${cfg:h:h}/stems ${cfg:h:h}/ebmt .
   mkdir cfg ; cd cfg ; ln -s ${cfg:h}/ebweight*.cfg . >&/dev/null
   popd >&/dev/null
else
   set rvcfg=$revcfg
endif

set revbase="${langpair}-reverse.dic"

if ( $?runalign && ! $?nobuilddict ) then
   echo "  ================= Building Inverse Dictionary ==================="
   $builddict -f -np $revrev $prealigned $rvcfg $iter $list $thr1 $thr2
   mv ${langpair}-${lastiter}.dict ${langpair}-reverse.dict
   $mkdic ${langpair}-reverse.dict >$revbase
   mv ${langpair}-${lastiter}.dct ${langpair}-reverse.dct
endif

unset verbose


#################################################################
## if user has requested truecasing of the corpus files, do that now

if ( $?truecase_tgt ) then
   echo "  =================== Truecasing Corpus Files ====================="
   pushd $tmpdir
   downcase -c -e -f$list $truecase_tgt -U$enc
   ## update list of files
   sed -e 's#^#/#' -e 's#^.*/\([^/]*\)$#'${tmpdir}/'\1#' $list >list$$
   popd
   set list="${tmpdir}/list$$"
endif


#################################################################
## build the dictionary from the corpus

if ( $?nobuilddict ) then
   echo "  ==== Skipping dictionary build and using existing dictionary ===="
else
   echo "  ===================== Building Dictionary ======================="
   set phrase=""
   if ( $?runalign ) set phrase="-np"
   $builddict -f $phrase $rev $prealigned $cfg $iter $list $thr1 $thr2
endif
if ( $?runalign && ! $?nobuilddict ) then
   $mkdic ${langpair}-${lastiter}.dict >${langpair}-forward.dic
endif


#################################################################
## optionally run the external aligner

if ( $?runalign ) then
   if (0) then
      echo Computing source IDFs
      ($root/extract-source-sent.sh `cat $list` | $idfsent | \
	sort -k 2 -n > ${tmpdir}/src.idf ) >& /dev/null
      echo Computing target IDFs
      ($root/extract-target-sent.sh `cat $list` | $idfsent | \
	sort -k 2 -n > ${tmpdir}/tgt.idf ) >& /dev/null
   else
      # IDF currently not used by aligner, so all we need is empty files
      touch ${tmpdir}/src.idf ${tmpdir}/tgt.idf
   endif
   set fwdbase="${langpair}-forward.dic"
   set fwddict="${tmpdir}/${langpair}-forward.dic"
   set revdict="${tmpdir}/${langpair}-reverse.dic"
   if ( $?tunealign ) then
      echo "  ======================= Tuning Aligner ========================="
      rm -f ${fwddict}.tmp ${revdict}.tmp
      rm -f ${fwddict}.filtered ${revdict}.filtered
      $filterdict $ANSWER $fwdbase $revbase $fwddict $revdict 
      set TUNEDPARAM=${tmpdir}/spa_tune.$$.log
      echo "$spatune ${tunelang} $aspadir $fwddict $revdict $ANSWER > $TUNEDPARAM"
      set nodetails=""
      if ( $?runquietly ) set nodetails="-e '^[0-9]:'"
      ($spatune ${tunelang} $aspadir $fwddict $revdict $ANSWER \
		> $TUNEDPARAM ) |& \
		grep --line-buffered -v -F -e "Real Time" -e "log_perp" \
		    -e Loading -e Aligning $nodetails
      set T_ARGUMENT=(`tail -6 $TUNEDPARAM | head -5 | sed 's/ : /=/'`)
   endif
   cp -p $fwdbase $fwddict
   cp -p $revbase $revdict
   rm -f ${fwddict}.tmp ${revdict}.tmp
   rm -f ${fwddict}.filtered ${revdict}.filtered
   echo "  ==================== Aligning Corpus Files ======================"
   foreach i (`cat $list`)
      if ( "x$i" !~ x\#* ) then
         echo "*** Aligning $i ***"
         set in=${i}
#	 set in=stdin
#	 grep -v -e '^;;;' -e '^ *$' ${i} | \
	    < $in \
	    $aligner $ARGUMENT $T_ARGUMENT --debug=0 \
		--input_type=1 --output_type=1 \
		--src_word_idf=${tmpdir}/src.idf --src_tgt_dict=$fwddict \
		--tgt_word_idf=${tmpdir}/tgt.idf --tgt_src_dict=$revdict \
		--dict_cut=0 --answer=${in} --input=/dev/null \
		--log=${tmpdir}/${i:t}.annotated $alignargs
	 touch ${tmpdir}/${i:t}.annotated >&/dev/null  # ensure existence
         echo "   %%% merging alignment information into corpus file %%%"
         if ( $?nophrases ) then
	    grep -v '^;;;(PHRASE' ${tmpdir}/${i:t}.annotated >${tmpdir}/${i:t}.tmp
	    mv ${tmpdir}/${i:t}.tmp ${tmpdir}/${i:t}.annotated
	 endif
	 ## check which format of output the aligner generated
	 if { grep -s -q -i '^newsent' ${tmpdir}/${i:t}.annotated } then
            $embed $i ${tmpdir}/${i:t}.annotated >${tmpdir}/${i:t}
  	    rm -f ${tmpdir}/${i:t}.annotated
         else
            mv ${tmpdir}/${i:t}.annotated ${tmpdir}/${i:t}
	 endif
	 if ( -z ${tmpdir}/${i:t} ) then
            ## oops, we ended up with a zero-length file, so use the original
	    echo "   %%% got empty file, will use original training file %%%%"
	    echo $i >>${tmpdir}/tmplist_$$
         else
            echo ${tmpdir}/${i:t} >>${tmpdir}/tmplist_$$
	 endif
      endif
   end
   if ( ! $?nobuilddict ) then
      echo "  =========== Building Dictionary from Aligned Corpus ============"
      set list2=${tmpdir}/tmplist_$$
      set lastiter=1
      $builddict -f $revrev -a $rvcfg 2 $list2 $thr1 $thr2
      mv ${langpair}-${lastiter}.dict ${langpair}-reverse.dict
      mv ${langpair}-${lastiter}.dct ${langpair}-reverse.dct
      $mkdic ${langpair}-reverse.dict >$revbase
      $builddict -f $rev -a $cfg 2 $list2 $thr1 $thr2
      $mkdic ${langpair}-${lastiter}.dict >${langpair}-forward.dic
      echo "  ================== Re-Aligning Corpus Files ===================="
      foreach i (`cat $list`)
         if ( "x$i" !~ x\#* ) then
            echo "*** Aligning $i ***"
            set in=${i}
	    $aligner $ARGUMENT $T_ARGUMENT --debug=0 \
		--input_type=1 --output_type=1 \
		--src_word_idf=${tmpdir}/src.idf --src_tgt_dict=$fwddict \
		--tgt_word_idf=${tmpdir}/tgt.idf --tgt_src_dict=$revdict \
		--dict_cut=0 --answer=${in} --input=/dev/null \
		--log=${tmpdir}/${i:t}.annotated $alignargs < $in
	    touch ${tmpdir}/${i:t}.annotated >&/dev/null  # ensure existence
            echo "  %%% merging alignment information into corpus file %%%"
            if ( $?nophrases ) then
	       grep -v '^;;;(PHRASE' ${tmpdir}/${i:t}.annotated >${tmpdir}/${i:t}.tmp
	       mv ${tmpdir}/${i:t}.tmp ${tmpdir}/${i:t}.annotated
	    endif
	    ## check which format of output the aligner generated
	    if { grep -s -q -i '^newsent' ${tmpdir}/${i:t}.annotated } then
               $embed $i ${tmpdir}/${i:t}.annotated >${tmpdir}/${i:t}
  	       rm -f ${tmpdir}/${i:t}.annotated
            else
               mv ${tmpdir}/${i:t}.annotated ${tmpdir}/${i:t}
	    endif
	    if ( -z ${tmpdir}/${i:t} ) then
               ## oops, we ended up with a zero-length file, so use the original
               echo "   %%% got empty file, will use original training file %%%%"
	       echo $i >>${tmpdir}/tmplist2_$$
            else
               echo ${tmpdir}/${i:t} >>${tmpdir}/tmplist2_$$
	    endif
         endif
      end
      mv ${tmpdir}/tmplist{2,}_$$
   endif
   set list=${tmpdir}/tmplist_$$
endif

#################################################################
## optionally run clustering

if ($?runclust) then
   echo "  ===================== Generating Clusters ======================="
   #   the multiple -f is to ensure that we won't include extremely rare words
   #   when asked to cut off clustering by number of terms, and to ensure that
   #   at least the ten most frequent terms are considered stopwords
   echo $wordclus -ctSpectral -cmCosine -cpiter=10 "-#${numclus}" -dl \
	-f5 -f-@10 -f${minfreq} -p3,0.08 -N -xn -xp $rev -U$enc \
	-O${langpair}.ebmt ${autostop} ${stopwords} ${clustopt} \
	${langpair}.tok ${langpair}-${lastiter}.dct $list
   $wordclus -ctSpectral -cpiter=10 "-#${numclus}" -dl \
	-f5 -f-@10 -f${minfreq} -p3,0.08 -N -xn -xp $rev -U$enc \
	-O${langpair}.ebmt ${autostop} ${stopwords} ${clustopt} \
	${langpair}.tok ${langpair}-${lastiter}.dct $list
else
   # zero out any previous clusters file, but make sure an empty file exists
   rm -f ${langpair}.ebmt >&/dev/null
   touch ${langpair}.ebmt
endif

#################################################################
## index the corpus, using the dictionary we just created

set quietflag=""
if ( $?runquietly ) set quietflag="-Q+"

if ( ! $?skip_indexing ) then
   echo "  ======================= Indexing Corpus ========================="
   set corpdir=`grep "^Corpus-Directory:" $cfg | \
	sed -e 's/^[^"]*"\([^"]*\)".*$/\1\//' -e "s#^[+]#${basedir}/#"`
   echo "Removing old corpus files $corpdir/corpus.???"
   rm -f $corpdir/corpus.???
   if ( ! $?nobuilddict ) then
      $editcfg $cfg Indexing-Dictionary \"$cwd/${langpair}-${lastiter}.dct\" \
   		    Dictionary \"$cwd/${langpair}-${lastiter}.dct\" \
   		    Align-Constraints \"$cwd/${langpair}-${lastiter}.ac\"
   endif
   echo ${langpair}.ebmt | cat - $list | \
	$ebmt -c -i -p $canoninput $rev $quietflag $cfg
endif

if ( "x$revcfg" != "x" && ! $?skip_indexing ) then
   echo "  ============= Indexing Corpus (Reverse Direction) ================"
   set corpdir=`grep "^Corpus-Directory:" $revcfg | \
	sed -e 's/^[^"]*"\([^"]*\)".*$/\1\//' -e "s#^[+]#${basedir}/#"`
   echo "Removing old corpus files $corpdir/corpus.???"
   rm -f $corpdir/corpus.???
   $editcfg $revcfg Indexing-Dictionary \"$cwd/${langpair}-reverse.dct\"
   $editcfg $revcfg Dictionary \"$cwd/${langpair}-reverse.dct\"
   echo ${langpair}.ebmt | cat - $list | \
	 $ebmt -c -i -p $canoninput $revrev $quietflag $revcfg
endif

if ( "x$tunefile" != "x" ) then
   set tunefiledir=${tunefile:h}
   if ( x$tunefiledir == x$tunefile ) set tunefiledir=.
   if ( -e $tunefile && -e ${tunefiledir}/refs ) then
      echo "  ====================== Tuning Parameters ========================"
      setenv TUNE_REFERENCES ${tunefiledir}/refs
      $tuneprog -c ${cfg:t:r}-tuned.cfg -r -r -t 800 $tuneopt . $cfg $tunefile
      echo "Configuration with tuned parameters written to ${cfg:t:r}-tuned.cfg"
      echo "  ======================= Tuning Complete ========================="
   else
      echo "  ====== Skipping tuning (missing input or reference file) ======"
   endif
endif

echo "  ==================== Creating Length Model ======================"
$ebmt -L${langpair}.len $rev $quietflag $cfg <$list
if ( -e ${langpair}.len && ! -z ${langpair}.len ) then
   $editcfg $cfg Length-Model \"$cwd/${langpair}.len\"
endif

echo "  ====================== Training Complete ========================"

if ( ! $?keeptmp ) then
   rm -f ${tmpdir}/cfg/* >&/dev/null
   rmdir ${tmpdir}/cfg >&/dev/null
   rm -f ${tmpdir}/* >&/dev/null
   rmdir ${tmpdir} >&/dev/null
else
   echo Keeping temporary files in ${tmpdir}
endif

exit 0
