#!/bin/csh -f
# LastEdit: 08apr10
##	by Ralf Brown <ralf@cs.cmu.edu>					##
##									##
##  (c) Copyright 2005,2006,2007,2008,2009,2010 Ralf Brown		##
##	This program is free software; you can redistribute it and/or	##
##	modify it under the terms of the GNU General Public License as	##
##	published by the Free Software Foundation, version 3.		##
##									##
##	This program is distributed in the hope that it will be		##
##	useful, but WITHOUT ANY WARRANTY; without even the implied	##
##	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		##
##	PURPOSE.  See the GNU General Public License for more details.	##
##									##
##	You should have received a copy of the GNU General Public	##
##	License (file COPYING) along with this program.  If not, see	##
##	http://www.gnu.org/licenses/					##

set rev=""
set canon=""
set always_force=N
set use_strip=Y
set pre_aligned=N

while ( "x$1" =~ x-* )
   if ( "x$1" == "x-a" ) then
      set pre_aligned=Y
      set canon="-@"
   else if ( "x$1" == "x-r" ) then
      set rev=-r
   else if ( "x$1" == "x-f" ) then
      set always_force=Y
   else if ( "x$1" == "x-s" ) then
      set use_strip=N
   endif
   shift
end

if ( $#argv < 4 ) then
   echo "Usage: $0:t [-afrs] cfgfile iterations filelist threshold1 [threshold2]"
   echo "\t-a\tcorpus is annotated with alignments, so skip seed building"
   echo "\t-f\tforce definitions to be added even on the last iteration"
   echo "\t-r\treverse languages"
   echo "\t-s\tdon't strip seed dictionary based on identity translations"
   exit 1
endif

# grab the commandline parameters
set cfg=$1
set iter=$2
set list=$3
set thr1=$4
set thr2=$4
if ( $#argv >= 5 ) set thr2=$5

if ( $cfg !~ [./]* ) set cfg=./$cfg
set base=${cfg:t:r}
set cfgdir=${cfg:h}
if ( "$cfgdir" == "$cfg" ) set cfgdir=.
if ( "$cfgdir" == "cfg" ) set cfgdir=./cfg
if ( "$cfgdir:t" == "cfg" ) set cfgdir=$cfgdir:h

# check for argument validity
@ comp1 = $iter - 1
@ comp2 = $iter / 10
if ( "$comp1" =~ "-*" ) then
   echo "You must allow for at least one iteration.  The count has been adjusted."
   set iter=1
endif
if ( $comp2 > "0" ) then
   echo "It does not make any sense to ask for more than nin iterations."
   echo "The count has been adjusted to nine."
   set iter=9
endif
if ( ! -e $cfg ) then 
   echo "The specified configuration file '$cfg' does not exist!  Terminating...."
   exit 2
endif
if ( ! -e $list ) then 
   echo "The specified file-list file '$list' does not exist!  Terminating...."
   exit 2
endif
if ( ! -e $thr1 ) then
   echo "The specified thresholds file '$thr1' does not exist!  Terminating...."
   exit 2
endif
if ( ! -e $thr2 ) set thr2=$thr1

#################################################################
## figure out where this script is located, so that we can run
## the helper scripts and programs

set root=$0:h
if ( $root == $0 ) set root=.

set editcfg=$root/editcfg.sh

set strip="`where stripdct|head -1`"
if ( "$strip" == "" ) set strip="$root/stripdct"
if ( -e $strip && $use_strip != N ) then
   set strip="$strip -f9999999 -l1 -d200"
else
   set strip="cat"
endif

set ebmt="`where ebmt|head -1`"
if ( "$ebmt" == "" ) set ebmt="$root/ebmt"

onintr done

#################################################################
## OK, finally we're ready to do the actual dictionary building

set count=0
sed -e 's/\([^-+\!]\)READONLYDICT/\1-READONLYDICT/' $cfg >dict$$.cfg
set cfg=dict$$.cfg

# make sure we have at least an empty corpus if we're running multiple iters
$editcfg $cfg Base-Directory \"${cfgdir}/\"
if ( $iter > 1 ) then
   echo "Creating empty EBMT corpus"
   $ebmt -c $cfg </dev/null >&/dev/null
endif

while ( $iter > 0 )
  echo "  ***** Pass $count *****"
  if ( $count == 0) then
     if ( $pre_aligned == N ) then
        # generate a seed dictionary
        rm -f ${base}-00.dct
        if ( -e ${base}-seed.dct ) cp ${base}-seed.dct ${base}-00.dct
        touch ${base}-0.ac
        $editcfg $cfg Dictionary \"${base}-00.dct\" \
			Align-Constraints \"${base}-0.ac\"
        $ebmt -Q+ -da3 -dt=$thr1 -x${base}-00.dict -dc400000 -dw1 $canon $rev $cfg <$list
        # remove some clear errors by stripping out lower-frequency items
        #  when the source-language term is also present in the list of
        #  translations
        echo "wfwc(" >${base}-0.dict
        $strip ${base}-00.dict >>${base}-0.dict
        echo ")" >>${base}-0.dict
        rm -f ${base}-0.dct
        $editcfg $cfg Dictionary \"${base}-0.dct\"
        $ebmt -Q+ $canon $cfg <${base}-0.dict
     else
        echo " --- skipping seed generation for pre-aligned corpus ---"
     endif
  else
     # refine the dictionary from the prior pass
     @ prev = $count - 1
     rm -f ${base}-${count}.dct
     if ( -e ${base}-seed.dct ) cp ${base}-seed.dct ${base}-${count}.dct
     set force=3
     if ($iter == 1 && $always_force == N) set force=0
     touch ${base}-{prev}.ac
     $editcfg $cfg Dictionary \"${base}-${prev}.dct\" \
		   Align-Constraints \"${base}-${prev}.ac\"
     $ebmt -Q+ -dt=$thr2 -x${base}-${count}.dict -dr${base}-${count}.dct \
	    -da$force -dC30,0.02,${base}-${count}.ac -dP -dc1500000 -dw1 $rev \
	    $canon $cfg <$list
  endif  
  @ iter = $iter - 1
  @ count = $count + 1
end

done:
   rm -f $cfg
   unset cfg base
   exit 0
