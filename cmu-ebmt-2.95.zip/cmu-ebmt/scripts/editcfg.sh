#!/bin/csh -f

if ( $#argv < 3 ) then
   echo "Usage: $0:t cfgfile param newvalue [param newvalue ...]"
   exit 1
endif

onintr done

# start by making a temporary copy of the config file
set orig=$1
set cfg=tmp$$.cfg
cp -p $orig $cfg
shift

while ( $#argv >= 2 )
   sed -e "s#^${1}:.*#${1}: ${2}#i" $cfg >tmp$$
   mv tmp$$ $cfg
   shift
   shift
end

# we're done with the edits, so replace the original config file with
# the edited version
mv $cfg $orig

# cleanup
done:
rm -f $cfg
unset orig cfg

exit 0
