/************************************************************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File plmorph.cpp		interface to morphology module		*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,2000,2001,2006,2009 Ralf Brown	*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifdef LINK_ALL
//#define LINK_MORPH
#endif /* LINK_ALL */

#ifdef LINK_MORPH
#include "icelos.h"
#endif /* LINK_MORPH */

#include "plchart.h"
#include "plengine.h"
#include "plproc.h"
#include "plutil.h"
#include "plglobal.h"

/************************************************************************/
/*	Forward Declarations						*/
/************************************************************************/

static bool exec_morph(MEMTEngine *engine, const PLConfig *config,
			 const PlEngineConfig *engcfg,
			 ostream &err, bool /*run_verbosely*/) ;
static bool get_morphology(MEMTEngine *engine, bool prepare,
			     const FrTextSpans *input, FrTextSpans *lattice,
			     ostream &err) ;
static bool start_morph_shutdown(MEMTEngine *engine) ;

/************************************************************************/
/*    Global variables for this module					*/
/************************************************************************/

MEMTEngine morph_engine("Morphological Analysis",":MORPH",ET_Annotate,
			exec_morph,get_morphology,start_morph_shutdown,0,0) ;

/************************************************************************/
/*    Helper Functions 							*/
/************************************************************************/

static void convert_morphological_info(const FrList *wordinfo, FrList *&info)
{
   if (wordinfo)
      {
      FrObject *morph = wordinfo->second() ;
      if (morph && morph->symbolp())
	 {
	 const char *mstring = ((FrSymbol*)morph)->symbolName() ;
	 FrSymbol *pos = 0 ;
	 if (strncmp(mstring,"N+",2) == 0)
	    pos = makeSymbol("NOUN") ;
	 else if (strncmp(mstring,"V+",2) == 0)
	    pos = makeSymbol("VERB") ;
	 else if (strncmp(mstring,"ADJ+",4) == 0)
	    pos = makeSymbol("ADJECTIVE") ;
	 else if (strncmp(mstring,"ADV+",4) == 0)
	    pos = makeSymbol("ADVERB") ;
	 else if (strncmp(mstring,"CONJ",4) == 0)
	    pos = makeSymbol("CONJUNCTION") ;
	 else if (strncmp(mstring,"PREP",4) == 0)
	    pos = makeSymbol("PREPOSITION") ;
	 else if (strncmp(mstring,"PRO",3) == 0)
	    pos = makeSymbol("PRONOUN") ;
	 else if (strncmp(mstring,"DET",3) == 0)
	    pos = makeSymbol("ARTICLE") ;
	 // add part of speech to start of list, full morph info to end
	 if (pos)
	    pushlistnew(pos,info) ;
	 if (!info->member(morph))
	    info = info->nconc(new FrList(morph)) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------
// perform a case-insensitive equality comparison between two FrStrings
// or between a FrString and a FrSymbol (for other type combinations, fall
// back to default FramepaC comparison)

static bool PL_equal(const FrObject *s1, const FrObject *s2)
{
   return equal_casefold(s1,s2,FrUppercaseTable(char_encoding)) ;
}

//----------------------------------------------------------------------

static FrObject *morph_to_word_struct(const FrObject *word,
				      const FrObject *morph)
{
   if (!morph || !morph->consp())
      return 0 ;
   FrList *m = (FrList*)morph ;
   // the iCelos result for a word of the input is a list of the possible
   // parses, each of which is itself a list.  For now, we use only the
   // root word of each parse
   FrList *roots = 0 ;
   FrList *morphinfo = 0 ;
   for ( ; m ; m = m->rest())
      {
      FrList *wordinfo = (FrList*)m->first() ;
      FrString *root = (FrString*)wordinfo->first() ;
      if (root && !roots->member(root,PL_equal))
	 pushlist(root,roots) ;
      convert_morphological_info(wordinfo,morphinfo) ;
      }
   FrStruct *wstruct = new FrStruct(symWORD) ;
   wstruct->put(symSTRING,word) ;
   if (roots)
      {
      // can't yet deal with multiple unique roots, so arbitrarily choose
      // the first one on the list
      wstruct->put(symROOT,roots->first()) ;
      }
   if (morphinfo)
      wstruct->put(symMORPH,morphinfo,false) ;
   return wstruct ;
}

/************************************************************************/
/*    Functions for interfacing with iCelos (Morphe)			*/
/************************************************************************/

static bool get_morphology(MEMTEngine *engine, bool prepare,
			     const FrTextSpans *input, FrTextSpans *lattice,
			     ostream & /*err*/)
{
   if (prepare)
      {
      FrList *words = 0 ;
      for (size_t i = 0 ; i < input->spanCount() ; i++)
	 {
	 const FrTextSpan *span = input->getSpan(i) ;
	 if (!span)
	    continue ;
	 const char *wordstr = span->text() ;
	 FrString *word = 0 ;
	 if (wordstr)
	    {
	    word = new FrString(wordstr) ;
	    if (word)		  // iCelos expects thing in lowercase
	       word->lowercaseString(char_encoding) ;
	    }
	 pushlist(word,words) ;
	 }
      words = listreverse(words) ;
      engine->stdIn() << "PARSE " << *words << endl << flush ;
      free_object(words) ;
      return true ;
      }
   else
      {
      FrList *morphology = 0 ;
      FrObject *result = engine->readObject() ;
      if (result && result->consp())
	 {
	 FrList *resultlist = (FrList*)result ;
	 for (size_t i = 0 ; resultlist && i < input->spanCount() ; i++)
	    {
	    const FrTextSpan *span = input->getSpan(i) ;
	    if (!span)
	       continue ;
	    const char *text = span->text() ;
	    FrString *word = new FrString(text ? text : "") ;
	    FrList *morph = (FrList*)poplist(resultlist) ;
	    pushlist(morph_to_word_struct(word,morph),morphology) ;
	    free_object(word) ;
	    free_object(morph) ;
	    }
	 }
      free_object(result) ;
      bool success = (morphology != 0) ;
      if (lattice)
	 {
	 //FIXME!!!
	 }
      free_object(morphology) ;
      return success ;
      }
}

//----------------------------------------------------------------------

FrList *inflect_words(const FrList *words)
{
   FrList *result = 0 ;
   for ( ; words ; words = words->rest())
      {

      }
   return result ;
}

//----------------------------------------------------------------------

static bool exec_morph(MEMTEngine *engine, const PLConfig *config,
			 const PlEngineConfig *engcfg,
			 ostream &err, bool run_verbosely)
{
   return engine->startEngine(config,engcfg,MORPH_NETWORK_FLAG,0,err,
			      run_verbosely) ;
}

//----------------------------------------------------------------------

static bool start_morph_shutdown(MEMTEngine *engine)
{
   engine->sendLine("*EOF*") ;
   return true ;
}

// end of file plmorph.cpp //
