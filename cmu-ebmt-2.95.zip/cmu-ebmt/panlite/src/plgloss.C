/************************************************************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File plgloss.cpp		interface to glossary engine		*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2003,2004,2006,	*/
/*		2009 Ralf Brown						*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "plengine.h"
#include "plproc.h"
#include "plglobal.h"

/************************************************************************/
/*	Forward declarations						*/
/************************************************************************/

static bool update_glossaries(MEMTEngine *engine, const FrString *src,
				const FrString *trg, const FrString *meta) ;

/************************************************************************/
/*    Global variables for this module					*/
/************************************************************************/

MEMTEngine gloss_engine("Glossary",":GLOSS",ET_Xlat,GLOSS_NETWORK_FLAG,"-G+",
			"GLOSS",update_glossaries,0,0,MEMTEng_DEFCMDFUNC) ;

/************************************************************************/
/*    Functions for interfacing with Glossary				*/
/************************************************************************/

static bool update_glossaries(MEMTEngine *engine, const FrString *src,
				const FrString *trg, const FrString */*meta*/)
{
   engine->stdIn() << "ADDGLOSS ((" << src << ' ' << trg << "))" << endl ;
   FrObject *result = engine->readObject() ;
   bool success = ((FrSymbol*)result == symOK) ;
   free_object(result) ;
   return success ;
}

// end of file plgloss.cpp //
