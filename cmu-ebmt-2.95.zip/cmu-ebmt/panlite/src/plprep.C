/************************************************************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File plprep.cpp		interface to preprocessor module	*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,2000,2001,2006,2007,2009		*/
/*		 Ralf Brown						*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifdef LINK_ALL
//#define LINK_PREPROC
#endif /* LINK_ALL */

#ifdef LINK_PREPROC
//#include "preproc.h"
#endif /* LINK_PREPROC */

#include "plengine.h"
#include "plproc.h"

/************************************************************************/
/*	Forward Declarations						*/
/************************************************************************/

static bool exec_preproc(MEMTEngine *engine, const PLConfig *config,
			   const PlEngineConfig *engcfg,
			   ostream &err, bool /*run_verbosely*/) ;
static bool start_preproc_shutdown(MEMTEngine *engine) ;
static FrObject *preprocess_sentence(MEMTEngine *engine,
				     const FrList *wordlist) ;

/************************************************************************/
/*    Global variables for this module					*/
/************************************************************************/

MEMTEngine preproc_engine("Preprocessor",":PREP",ET_Preproc,exec_preproc,0,
			  start_preproc_shutdown,0,0,preprocess_sentence) ;

/************************************************************************/
/*    Functions for interfacing with preprocessor			*/
/************************************************************************/

static bool exec_preproc(MEMTEngine *engine, const PLConfig *config,
			   const PlEngineConfig *engcfg,
			   ostream &err, bool run_verbosely)
{
   return engine->startEngine(config,engcfg,PREPROC_NETWORK_FLAG,0,err,
			      run_verbosely) ;
}

//----------------------------------------------------------------------

FrObject *preprocess_sentence(MEMTEngine *engine, const FrList *wordlist)
{
   if (!engine->usingDataFile())
      engine->stdIn() << "PREPROC " << wordlist << endl << flush ;
   return engine->readObject() ;  // allowed to return list or string
}

//----------------------------------------------------------------------

static bool start_preproc_shutdown(MEMTEngine *engine)
{
   engine->sendLine("*EOF*") ;
   return true ;
}

// end of file plprep.cpp //
