/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File plinput.h		text input processing			*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 2009 Ralf Brown					*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef PLINPUT_H_INCLUDED
#define PLINPUT_H_INCLUDED

#include "FramepaC.h"

class PlSentence
   {
   private:
      FrList      *m_textlines ;	// the lines of text that were input
      FrList	  *m_references ;	// optional reference translations
      char        *m_prefix ;		// optional prefix on translation
      char	  *m_suffix ;		// optional suffix on translation
      FrTextSpans *m_input ;		// input lattice
      FrTextSpans *m_output ;		// translated output lattice
      bool	   m_passthrough ;	// should m_textlines be passed thru?
      bool	   m_iscommand ;
   private:
      void init() ;
   public:
      PlSentence() ;
      PlSentence(const FrString *text) ;
      PlSentence(const FrList *textlines) ;
      ~PlSentence() ;

      // manipulators
      void setPrefix(const char *pref)
	 { FrFree(m_prefix) ; m_prefix = FrDupString(pref) ; }
      void setSuffix(const char *suff)
	 { FrFree(m_suffix) ; m_suffix = FrDupString(suff) ; }
      void setReferences(const FrList *refs) ;
      void markAsPassThrough() { m_passthrough = true ; }
      void markAsCommand() { m_iscommand = true ; }

      // accessors
      FrString *sourceText(size_t which = 0) const
	 { return (FrString*)m_textlines->nth(which) ; }
      const char *prefix() const { return m_prefix ? m_prefix : "" ; }
      const char *suffix() const { return m_suffix ? m_suffix : "" ; }
      FrTextSpans *input() const { return m_input ; }
      FrTextSpans *output() const { return m_output ; }
      bool passThrough() const { return m_passthrough ; }
      bool isCommand() const { return m_iscommand ; }
   } ;

//----------------------------------------------------------------------

class PlInputProcessor
   {
   private:
      istream	*m_source ;
      bool	 m_mustclose ;
   public:
      PlInputProcessor(istream &source) 
	 { m_source = &source ; m_mustclose = false ; }
      PlInputProcessor(const char *filename) ;
      virtual ~PlInputProcessor() 
	 { if (m_mustclose) { delete m_source ; }
	   m_source = 0 ; }

      virtual PlSentence **getDocument(size_t max_len = ~0) ;
      virtual PlSentence *nextSentence() ;

      bool eof() { return m_source ? m_source->eof() : true ; }

      static size_t countSentences(const PlSentence **sent) ;
   } ;

//----------------------------------------------------------------------

class PlInputProcessorText : public PlInputProcessor
   {
   public:
      PlInputProcessorText(istream &source) : PlInputProcessor(source) {}
      PlInputProcessorText(const char *file) : PlInputProcessor(file) {}
      //virtual ~PlInputProcessor() ; //inherited

      virtual PlSentence **getDocument(size_t max_len = ~0) ;
      virtual PlSentence *nextSentence() ;
   } ;

//----------------------------------------------------------------------

class PlInputProcessorXML : public PlInputProcessor
   {
   public:
      PlInputProcessorXML(istream &source) : PlInputProcessor(source) {}
      PlInputProcessorXML(const char *file) : PlInputProcessor(file) {}
      //virtual ~PlInputProcessor() ; //inherited

      virtual PlSentence **getDocument(size_t max_len = ~0) ;
      virtual PlSentence *nextSentence() ;
   } ;


#endif /* !PLINPUT_H_INCLUDED */

// end of file plinput.h //
