/************************************************************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File plserver.cpp		class MEMTServer			*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2003,2006,2007,	*/
/*		2008,2009 Ralf Brown					*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "panlite.h"
#include "plbanner.h"
#include "plglobal.h"

/************************************************************************/
/*	Methods for class MEMTServer					*/
/************************************************************************/

MEMTServer::MEMTServer(int portnum) : FrNetworkServer(portnum)
{
   global_vars = FrNewC(MEMTGlobalVariables*,maximumConnections()) ;
   partial_sentence = 0 ;
   return ;
}

//----------------------------------------------------------------------

MEMTServer::~MEMTServer()
{
   size_t maxconn = maximumConnections() ;
   for (size_t i = 0 ; i < maxconn ; i++)
      {
      delete global_vars[i] ;
      global_vars[i] = 0 ;
      }
   delete global_vars ;
   FrFree(partial_sentence) ;
   partial_sentence = 0 ;
   return ;
}

//----------------------------------------------------------------------

void MEMTServer::onConnect(size_t conn)
{
   FrNetworkServer::onConnect(conn) ;
   global_vars[conn] = new MEMTGlobalVariables(memt_vars) ;
   if (!global_vars[conn])
      {
      FrNoMemory("while opening new network connection") ;
      disconnect(conn) ;
      return ;
      }
   global_vars[conn]->_xml_input = false ;
   global_vars[conn]->_no_input_yet = true ;
   FrOSockStream *out = outputStream(conn) ;
   if (out)
      {
      display_banner(*out) ;
      welcome_message(*out) ;
      if (generate_IBM_XML)
	 PlOutputXMLHeader(*out) ;
      }
   return ;
}

//----------------------------------------------------------------------

void MEMTServer::onDisconnect(size_t conn)
{
   FrOSockStream *out = outputStream(conn) ;
   if (partial_sentence)
      {
      if (*partial_sentence)
	 {
	 FrISockStream *in = inputStream(conn) ;
	 (void)PlProcessLine(partial_sentence,*in,*out,*out) ;
	 }
      FrFree(partial_sentence) ;
      partial_sentence = 0 ;
      }
   if (generate_IBM_XML)
      PlOutputXMLFooter(*out) ;
   FrNetworkServer::onDisconnect(conn) ;
   delete global_vars[conn] ;
   global_vars[conn] = 0 ;
   return ;
}

//----------------------------------------------------------------------

bool MEMTServer::onLineReceived(size_t conn, const char *line)
{
   FrISockStream *in = inputStream(conn) ;
   FrOSockStream *out = outputStream(conn) ;
   if (!line)
      return true ;
   if (in && out)
      {
      // use the private settings for the active connection
      MEMTGlobalVariables *vars = global_vars[conn]->select() ;
      // allocate some memory for using the preprocessor, if needed
      size_t prep_len = line ? 2*strlen(line) : 0 ;
      FrLocalAlloc(char,preproc,1024,prep_len+2) ;
      current_outstream = out ;
      bool status ;
      if (preproc)
	 {
	 if (verbose)
	    cout << "; before preprocessor: " << (line ? line : "") << endl ;
	 strcpy(preproc,line ? line : "") ;
	 PlApplyPreprocessor(preproc,prep_len,false) ;
	 if (verbose)
	    cout << "; after preprocessor: " << (preproc?preproc:"") << endl ;
	 FrList *sentences = PlSplitIntoSentences(partial_sentence,preproc) ;
	 status = true ;
	 FrLocalFree(preproc) ;
	 while (sentences && status != false)
	    {
	    FrString *sent = (FrString*)poplist(sentences) ;
	    char *sentence = (char*)sent->stringValue() ;
	    status = (bool)PlProcessLine(sentence,*in,*out,*out) ;
	    free_object(sent) ;
	    }
	 }
      else
	 status = (bool)PlProcessLine(line,*in,*out,*out) ;
      current_outstream = 0 ;
      if (verbose)
	 cout << "; process_line returned " << (status?"true":"false")
	      << endl ;
      if (!status && !Panlite_network_mode)
	 requestShutdown() ;
      vars->select() ;			// restore global settings
      return status ;
      }
   else
      return false ;
}

// end of file plserver.cpp //
