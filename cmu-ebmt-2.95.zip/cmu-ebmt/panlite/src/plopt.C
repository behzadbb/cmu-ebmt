/************************************************************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File plopt.cpp		parameter optimization			*/
/*  LastEdit: 20apr10							*/
/*									*/
/*  (c) Copyright 2010 Ralf Brown					*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "panlite.h"
#include "plbleu.h"
#include "plrouge.h"
#include "plglobal.h"
#include "lmodel.h"
#include <cmath>

/************************************************************************/
/*	Manifest Constants and Conditionals				*/
/************************************************************************/

#define NORMALIZE_EACH_PASS

#define PRIOR_NBEST	50

#define MIRA_TOP_N 10

#define DEFAULT_FEATURE_WEIGHT (FLT_EPSILON/100.0)
#define DEFAULT_USED_FEATURE_WEIGHT (FLT_EPSILON/100.0)

/************************************************************************/
/*	Forward and External Declarations				*/
/************************************************************************/

void Panlite_get_line(istream &in, char *line, size_t maxline) ;
FrList *PlGetDecoderFeatures(const FrTextSpans *input_lat) ;
LmFeatureVector *PlGetDecoderWeightVector(const FrTextSpans *input_lat) ;
void PlSetDecoderWeightVector(const LmFeatureVector *weights) ;

/************************************************************************/
/*	Types for this module						*/
/************************************************************************/

class NBestEntry
   {
   private:
      static FrAllocator allocator ;
      LmFeatureVector *m_features ;
      double           m_score ;
      unsigned	       m_generation ;
   public:
      void *operator new(size_t) { return allocator.allocate() ; }
      void operator delete(void *blk) { allocator.release(blk) ; }
      NBestEntry()
	 { m_features = 0 ; m_score = -DBL_MAX ; m_generation = 0 ; }
      NBestEntry(const NBestEntry &orig) { init(orig) ; }
      ~NBestEntry() { delete m_features ; }
      void init(const FrList *trans, FrFeatureVectorMap *map,
		size_t generation = 0) ;
      void init(const NBestEntry &orig) ;

      // manipulators
      void setScore(double sc) { m_score = sc ; }
      void setGeneration(size_t gen) { m_generation = (unsigned)gen ; }
      void cacheScore(const LmFeatureVector *wt)
	 { if (m_features) (void)m_features->score(wt) ; }

      // accessors
      LmFeatureVector *features() const { return m_features ; }
      double score() const { return m_score ; }
      size_t generation() const { return m_generation ; }
      size_t age(size_t curr_gen) const { return curr_gen - generation() ; }

      // support for sorting
      static int compare(const NBestEntry *nb1, const NBestEntry *nb2) ;
      static int compareGeneration(const NBestEntry *nb1,
				   const NBestEntry *nb2) ;
      static int compareConservative(const NBestEntry *nb1,
				     const NBestEntry *nb2) ;
      static int compareBalanced(const NBestEntry *nb1,
				 const NBestEntry *nb2) ;
      static int compareInverted(const NBestEntry *nb1,
				 const NBestEntry *nb2);
      static int compareObjective(const NBestEntry *nb1,
				  const NBestEntry *nb2) ;
      static void swap(NBestEntry &nb1, NBestEntry &nb2) ;
   } ;

//----------------------------------------------------------------------

class TestInput
   {
   private:
      static FrAllocator allocator ;
      TestInput   *m_next ; 
      FrList      *m_pre_cmds ;	  // list of opt. colon commands before line
      FrList      *m_input ;	  // line(s) of input text
      FrList      *m_references ; // reference translation(s)
      FrTextSpans *m_source ;	  // input lattice
      FrTextSpans *m_lattice ;	  // translation lattice (pre-decoding)
      NBestEntry  *m_nbest ;	  // array of translations
      NBestEntry  *m_prevbest ;
      size_t	   m_sentencenum ;
      size_t	   m_nbestcount ;
      size_t	   m_prevcount ;
      size_t	   m_oracle ;
      size_t	   m_surrogate ;
      bool	   m_docstart ;
      bool	   m_docend ;
   public:
      void *operator new(size_t) { return allocator.allocate() ; }
      void operator delete(void *blk) { allocator.release(blk) ; }
      TestInput(FrList *pre, FrList *in, FrList *refs, TestInput *nxt = 0)
	 { m_pre_cmds = pre ; m_input = in ; m_references = refs ;
	    m_next = nxt ; m_docstart = m_docend = false ; m_prevbest = 0 ;
	    m_prevcount = 0 ; m_nbest = 0 ; m_nbestcount = 0 ;
	    m_source = m_lattice = 0 ;
	 }
      TestInput(const TestInput *orig) ;
      ~TestInput()
	 { free_object(m_pre_cmds) ; free_object(m_input) ; 
	   free_object(m_references) ; delete m_source ; delete m_lattice ;
	   clearNBest() ; clearPrevBest() ; }

      // accessors
      TestInput *next() const { return m_next ; }
      const FrList *preCommands() const { return m_pre_cmds ; }
      const FrList *input() const { return m_input ; }
      const FrList *references() const { return m_references ; }
      FrTextSpans *sourceLattice() const { return m_source ; }
      FrTextSpans *translationLattice() const { return m_lattice ; }
      bool documentStart() const { return m_docstart ; }
      bool documentEnd() const { return m_docend ; }
      size_t listlength() const { return FrLinkListLength(this) ; }
      size_t sentenceNumber() const { return m_sentencenum ; }
      size_t nbestCount() const { return m_nbestcount ; }
      size_t prevBestCount() const { return m_prevcount ; }
      size_t oracle() const { return m_oracle ; }
      size_t surrogate() const { return m_surrogate ; }
      size_t findBest(double lambda, const LmFeatureVector *weights,
		      double &best_score) const ;
      NBestEntry *nthBest(size_t N) const
	 { return (N < m_nbestcount) ? &m_nbest[N] : 0 ; }
      NBestEntry *prevBest() const { return m_prevbest ; }
      NBestEntry *prevBest(size_t N) const
	 { return (N < m_prevcount) ? &m_prevbest[N] : 0 ; }
      double nthBestScore(size_t N) const
	 { return (N < m_nbestcount) ? m_nbest[N].score() : -DBL_MAX ; }
      LmFeatureVector *nthBestFeatures(size_t N) const
	 { return (N < m_nbestcount) ? m_nbest[N].features() : 0 ; }

      // manipulators
      void setNext(TestInput *nxt) { m_next = nxt ; }
      void markDocumentStart() { m_docstart = true ; }
      void markDocumentEnd() { m_docend = true ; }
      void storeSource(FrTextSpans *lat)
	 { delete m_source ; m_source = lat ; }
      void storeLattice(FrTextSpans *lat)
	 { delete m_lattice ; m_lattice = lat ; }
      void setSentenceNumber(size_t s) { m_sentencenum = s ; }
      void initNBest(size_t N)
	 { clearNBest() ;
	   m_nbest = new NBestEntry[N] ; m_nbestcount = N ; }
      void clearNBest()
	 { delete [] m_nbest ; m_nbest = 0 ; m_nbestcount = 0 ; }
      void sortNBest(const LmFeatureVector *weights,
		     int compare(const NBestEntry*,const NBestEntry*)) ;
      void initNthBest(size_t N, const FrList *translation,
		       FrFeatureVectorMap *map, size_t gen)
	 { if (N < m_nbestcount) m_nbest[N].init(translation,map,gen) ; }
      void initPrevBest(size_t N)
	 { clearPrevBest() ;
	   m_prevbest = new NBestEntry[N] ; m_prevcount = N ; }
      void clearPrevBest()
	 { delete [] m_prevbest ; m_prevbest = 0 ; m_prevcount = 0 ; }
      void setOracle(size_t o) { m_oracle = o ; }
      void setSurrogate(size_t s) { m_surrogate = s ; }
      void setNthBestScore(size_t N, double score)
	 { if (N < m_nbestcount) m_nbest[N].setScore(score) ; }
      void setPrevBest(const NBestEntry *nb)
	 { initPrevBest(1) ; m_prevbest[0].init(*nb) ; }
      void setPrevBest(size_t N)
	 { if (N < m_nbestcount) setPrevBest(&m_nbest[N]) ; }
      void addPrevBest()
	 { if (m_prevbest && m_nbestcount > m_prevcount)
	       for (size_t i = 0 ; i < m_prevcount ; i++)
		  { m_nbest[m_nbestcount-i-1].init(m_prevbest[m_prevcount-i-1]) ; } }

      TestInput *reverse() { return FrLinkListReverse(this) ; }
      void deleteList() { FrLinkListDelete(this) ; }
   } ;

/************************************************************************/
/*	Global variables for this module				*/
/************************************************************************/

FrAllocator NBestEntry::allocator("NBestEntry",sizeof(NBestEntry)) ;
FrAllocator TestInput::allocator("TestInput",sizeof(TestInput)) ;

static LmFeatureVector *default_weights = 0 ;

/************************************************************************/
/*	Helper Functions						*/
/************************************************************************/

LmFeatureVector *build_vector(const FrList *features, FrFeatureVectorMap *map)
{
   LmFeatureVector *vector = new LmFeatureVector(map) ;
   for ( ; features ; features = features->rest())
      {
      FrList *feature = (FrList*)features->first() ;
      const char *fname = FrPrintableName(feature->first()) ;
      FrObject *fval = feature->second() ;
      if (fval && fval->numberp())
	 vector->setValue(fname,fval->floatValue()) ;
      }
   return vector ;
}

//----------------------------------------------------------------------

static double divergence(double hi, double lo)
{
   if (lo >= hi || hi <= 0.0)
      return 1.0 ;
   double div = (hi - lo) / hi ;
   return (div <= 1.0) ? div : 1.0 ;
}

/************************************************************************/
/*	Methods for class NBestEntry					*/
/************************************************************************/

void NBestEntry::init(const NBestEntry &orig)
{
   m_features = orig.features() ? orig.features()->clone() : 0 ;
   m_score = orig.score() ;
   setGeneration(orig.generation()) ;
   return ;
}

//----------------------------------------------------------------------

void NBestEntry::init(const FrList *translation, FrFeatureVectorMap *map,
		      size_t gen)
{

   const FrList *features = (FrList*)translation->nth(3) ;
   m_features = build_vector(features,map) ;
   m_score = -DBL_MAX ;
   setGeneration(gen) ;
   return ;
}

//----------------------------------------------------------------------

int NBestEntry::compare(const NBestEntry *nb1, const NBestEntry *nb2)
{
   if (nb1->features() && nb2->features())
      {
      double sc1 = nb1->features()->cachedScore() ;
      double sc2 = nb2->features()->cachedScore() ;
      double cmp = sc1 - sc2 ;
      if (cmp > 0.0)
	 return -1 ;
      else if (0.0 > cmp)
	 return +1 ;
      else
	 {
	 cmp = nb1->score() - nb2->score() ;
	 return cmp > 0.0 ? -1 : (cmp < 0.0 ? +1 : 0) ;
	 }
      }
   return 0 ;
}

//----------------------------------------------------------------------

int NBestEntry::compareObjective(const NBestEntry *nb1, const NBestEntry *nb2)
{
   double sc1 = nb1->score() ;
   double sc2 = nb2->score() ;
   if (sc1 > sc2)
      return -1 ;
   else if (sc1 < sc2)
      return +1 ;
   else if (nb1->features() && nb2->features())
      {
      sc1 = nb1->features()->cachedScore() ;
      sc2 = nb2->features()->cachedScore() ;
      if (sc1 > sc2)
	 return -1 ;
      else if (sc1 < sc2)
	 return +1 ;
      }
   return 0 ;
}

//----------------------------------------------------------------------

int NBestEntry::compareGeneration(const NBestEntry *nb1, const NBestEntry *nb2)
{
   // more recent generations sort above older generations
   size_t gen1 = nb1->generation() ;
   size_t gen2 = nb2->generation() ;
   if (gen1 > gen2)
      return -1 ;
   else if (gen1 < gen2)
      return +1 ;
   else
      return compare(nb1,nb2) ;
}

//----------------------------------------------------------------------

int NBestEntry::compareConservative(const NBestEntry *nb1,
				    const NBestEntry *nb2)
{
   if (nb1->features() && nb2->features())
      {
      double sc1 = nb1->features()->cachedScore() + 0.1 * nb1->score() ;
      double sc2 = nb2->features()->cachedScore() + 0.1 * nb2->score() ;
      double cmp = sc1 - sc2 ;
      return cmp > 0.0 ? -1 : (cmp < 0.0 ? +1 : 0) ;
      }
   return 0 ;
}

//----------------------------------------------------------------------

int NBestEntry::compareBalanced(const NBestEntry *nb1, const NBestEntry *nb2)
{
   if (nb1->features() && nb2->features())
      {
      double sc1 = nb1->features()->cachedScore() + nb1->score() ;
      double sc2 = nb2->features()->cachedScore() + nb2->score() ;
      double cmp = sc1 - sc2 ;
      return cmp > 0.0 ? -1 : (cmp < 0.0 ? +1 : 0) ;
      }
   return 0 ;
}

//----------------------------------------------------------------------

int NBestEntry::compareInverted(const NBestEntry *nb1, const NBestEntry *nb2)
{
   if (nb1->features() && nb2->features())
      {
      double sc1 = nb1->features()->cachedScore() - nb1->score() ;
      double sc2 = nb2->features()->cachedScore() - nb2->score() ;
      double cmp = sc1 - sc2 ;
      return cmp > 0.0 ? -1 : (cmp < 0.0 ? +1 : 0) ;
      }
   return 0 ;
}

//----------------------------------------------------------------------

void NBestEntry::swap(NBestEntry &nb1, NBestEntry &nb2)
{
   LmFeatureVector *fv = nb1.features() ;
   nb1.m_features = nb2.features() ;
   nb2.m_features = fv ;
   double sc = nb1.score() ;
   nb1.m_score = nb2.score() ;
   nb2.m_score = sc ;
   return ;
}

/************************************************************************/
/*	Methods for class TestInput					*/
/************************************************************************/

TestInput::TestInput(const TestInput *orig)
{
   m_next = 0 ;
   m_pre_cmds = 0 ;
   m_input = 0 ;
   m_references = 0 ;
   m_source = 0 ;
   m_lattice = 0 ;
   m_nbest = 0 ;
   m_nbestcount = 0 ;
   m_docstart = m_docend = false ;
   m_prevbest = 0 ;
   if (orig)
      {
      setSentenceNumber(orig->sentenceNumber()) ;
      initNBest(orig->nbestCount()) ;
      if (m_nbest)
	 {
	 for (size_t i = 0 ; i < nbestCount() ; i++)
	    m_nbest[i].init(orig->m_nbest[i]) ;
	 }
      m_prevcount = orig->m_prevcount ;
      if (orig->m_prevbest)
	 {
	 m_prevbest = new NBestEntry[m_prevcount] ;
	 for (size_t i = 0 ; i < m_prevcount ; i++)
	    m_prevbest[i].init(*orig->m_prevbest) ;
	 }
      m_oracle = orig->m_oracle ;
      m_surrogate = orig->m_surrogate ;
      }
   return ;
}

//----------------------------------------------------------------------

void TestInput::sortNBest(const LmFeatureVector *weights,
			  int compare(const NBestEntry *,
				      const NBestEntry *)
			  = NBestEntry::compareGeneration)
{
   size_t count = nbestCount() ;
   if (count == 0)
      return ;
   if (weights)
      {
      if (weights->maxMagnitude() == 0.0)
	 weights = default_weights ;
      for (size_t i = 0 ; i < count ; i++)
	 {
	 nthBest(i)->cacheScore(weights) ;
	 }
      }
   FrQuickSort(m_nbest,count,compare) ;
   return ;
}

//----------------------------------------------------------------------

size_t TestInput::findBest(double lambda, const LmFeatureVector *weights,
			   double &best_score) const
{
   best_score = -DBL_MAX ;
   size_t best_index = (size_t)~0 ;
   if (lambda == 0.0)
      {
      for (size_t i = 0 ; i < nbestCount() ; i++)
	 {
	 NBestEntry *nbest = nthBest(i) ;
	 if (!nbest)
	    continue ;
	 double score = nbest->score() ;
	 if (score > best_score)
	    {
	    best_score = score ;
	    best_index = i ;
	    }
	 }
      }
   else
      {
      double maxscore = (double)-UINT_MAX ;
      for (size_t i = 0 ; i < nbestCount() ; i++)
	 {
	 NBestEntry *nbest = nthBest(i) ;
	 if (!nbest || !nbest->features())
	    continue ;
	 if (weights)
	    nbest->cacheScore(weights) ;
	 double sc = nbest->features()->cachedScore() ;
	 if (sc > maxscore)
	    maxscore = sc ;
	 }
      double scale = (maxscore < -1.0 ? -maxscore : 1.0) ;
      for (size_t i = 0 ; i < nbestCount() ; i++)
	 {
	 NBestEntry *nbest = nthBest(i) ;
	 if (!nbest)
	    continue ;
	 double score = (1.0 - lambda) * nbest->score() ;
	 if (nbest->features())
	    score += lambda * ((nbest->features()->cachedScore() - maxscore) 
			       / scale) ;
	 if (score > best_score)
	    {
	    best_score = score ;
	    best_index = i ;
	    }
	 }
      best_score = nthBestScore(best_index) ;
      }
   return best_index ;
}

/************************************************************************/
/*	Helper functions						*/
/************************************************************************/

#if 0
static double clip(double low, double high, double value)
{
   if (value < low)
      return low ;
   else if (value > high)
      return high ;
   else
      return value ;
}
#endif

//----------------------------------------------------------------------

static double soft_limit(double x, double thresh1, double thresh2)
{
   assert(thresh2 <= 2.0 * thresh1) ;
   if (x >= thresh2)
      return x ;
   else
      {
      // the derivative of (x**2)/2k is 0 at 0 and 1 at k. with value
      //   k/2 at k, so scale the x to give us an overall function
      //   that has a continuous derivative
      double range = (thresh2 - thresh1) ;
      double low_limit = 2.0 * thresh1 - thresh2 ; // = thresh2 - 2.0 * range ;
      if (x <= low_limit)
	 return thresh1 ;
      x -= low_limit ;
      x /= 2.0 * range ;
      return thresh1 + (x * x * range) ;
      }
}

//----------------------------------------------------------------------

static void update_normalizer(const TestInput *input,
			      LmFeatureVector *normalizer)
{
   if (opt_norm_update_features && opt_norm_features_absolute)
      {
      for (size_t i = 0 ; i < input->nbestCount() ; i++)
	 {
	 NBestEntry *nbest = input->nthBest(i) ;
	 if (!nbest)
	    continue ;
	 LmFeatureVector *features = nbest->features() ;
	 if (features)
	    normalizer->maxMagnitude(features) ;
	 }
      }
   return ;
}

/************************************************************************/
/************************************************************************/

static double compute_norm(const LmFeatureVector &weights)
{
   double norm = weights.maxMagnitude() ;
   if (norm == 0.0)
      return 1.0 ;
   size_t num_features = 0 ;
   for (size_t i = 0 ; i < weights.numFeatures() ; i++)
      {
      if (default_weights->value(i) == 0.0)
	 continue ;
      num_features++ ;
      double val ;
      if (opt_use_L2_norm)
	 val = weights.value(i) * weights.value(i) ;
      else
	 val = fabs(weights.value(i)) ;
      norm += val ;
      }
   if (opt_use_L2_norm)
      norm = ::sqrt(weights.norm()) ;
   else if (num_features)
      norm /= num_features ;
   return soft_limit(norm,0.01,0.0199) ;
}

//----------------------------------------------------------------------

static void normalize_vector(LmFeatureVector *vec)
{
   // we need to preserve the weight of the Future feature, which isn't
   //   strictly part of the feature vector but is used internally in
   //   decoding
   size_t future = vec->featureMap()->featureIndex("Future") ;
   double future_wt = vec->value(future) ;
   // since it isn't part of the true feature vector, zero it before
   //   normalizing
   vec->setValue(future,0.0) ;
   double norm = compute_norm(*vec) ;
   if (norm > 0.0)
      vec->scaleValues(1.0 / norm) ;
   // round very low weights down to zero
   for (size_t i = 0 ; i < vec->numFeatures() ; i++)
      {
      if (fabs(vec->value(i)) < FLT_EPSILON)
	 vec->setValue(i,0.0) ;
      }
   // restore the value of the Future feature
   vec->setValue(future,future_wt) ;
   return ;
}

//----------------------------------------------------------------------

static void set_decoder_weights(const LmFeatureVector *weights)
{
   LmFeatureVector *norm_weights = weights->clone() ;
   normalize_vector(norm_weights) ;
   PlSetDecoderWeightVector(norm_weights) ;
   delete norm_weights ;
   return ;
}

//----------------------------------------------------------------------

static TestInput *read_input(istream &in, ostream &out)
{
   TestInput *input = 0 ;
   bool done = false ;
   while (!in.eof() && !in.fail() && !done)
      {
      FrList *cmds ;
      FrList **cmds_end = &cmds ;
      FrList *refs ;
      FrList **refs_end = &refs ;
      FrList *lines ;
      FrList **lines_end = &lines ;
      bool in_alts = false ;
      bool in_refs = false ;
      bool docstart = false ;
      bool docend = false ;
      while (!in.eof() && !in.fail())
	 {
	 char line[FrMAX_LINE+1] ;
	 FrChar16* line16 = (FrChar16*)line ;
	 line16[0] = 0 ;
	 Panlite_get_line(in,line,FrMAX_LINE) ;
	 if (line16[0] == 0)
	    continue ;			// skip blank lines
	 bool is_cmd = PlIsCommand(line) ;
	 if (is_cmd)
	    {
	    char *cmd = PlExtractCommandWord(out,line) ;
	    if (Fr_stricmp(cmd,"end") == 0 && (in_refs || in_alts))
	       {
	       in_refs = false ;
	       if (in_alts)
		  lines->pushlistend(new FrString(line),lines_end) ;
	       in_alts = false ;
	       }
	    else if (Fr_stricmp(cmd,"refs") == 0 ||
		     Fr_stricmp(cmd,"ref") == 0)
	       {
	       in_refs = true ;
	       }
	    else if (Fr_stricmp(cmd,"alt") == 0 ||
		     Fr_stricmp(cmd,"alternates") == 0)
	       {
	       in_alts = true ;
	       lines->pushlistend(new FrString(line),lines_end) ;
	       }
	    else if (Fr_stricmp(cmd,"doc") == 0)
	       docstart = true ;
	    else if (Fr_stricmp(cmd,"enddoc") == 0)
	       docend = true ;
	    else if (Fr_stricmp(cmd,"exit") == 0)
	       {
	       done = true ;
	       break ;
	       }
	    else
	       cmds->pushlistend(new FrString(line),cmds_end) ;
	    FrFree(cmd) ;
	    }
	 else if (in_refs)
	    {
	    refs->pushlistend(new FrString(line),refs_end) ;
	    }
	 else if (in_alts)
	    {
	    lines->pushlistend(new FrString(line),lines_end) ;
	    }
	 else
	    {
	    lines->pushlistend(new FrString(line),lines_end) ;
	    break ;
	    }
	 }
      *cmds_end = 0 ;
      *lines_end = 0 ; // terminate list
      *refs_end = 0 ;
      if (lines)
	 {
	 size_t sent = input ? input->sentenceNumber() + 1 : 0 ;
	 input = new TestInput(cmds,lines,refs,input) ;
	 input->setSentenceNumber(sent) ;
	 if (docstart)
	    input->markDocumentStart() ;
	 if (docend)
	    input->markDocumentEnd() ;
	 }
      }
   return input->reverse() ;
}

//----------------------------------------------------------------------

static FrTextSpans *get_translation_lattice(const TestInput *input,
					    FrTextSpans *&inlattice)
{
   if (input->documentStart())
      {
      PlPrepareForDocument(true,cin,cout,cerr) ;
      for (const TestInput *in = input->next() ; in ; in = in->next())
	 {
	 if (in->documentEnd())
	    break ;
	 FrTextSpans *inlat ;
	 FrTextSpans *lat = PlTranslateSentence(in->input(),0,inlat,cerr);
	 delete inlat ;
	 delete lat ;
	 }
      PlPrepareForDocument(false,cin,cout,cerr,false) ;
      }
   for (const FrList *pre = input->preCommands() ; pre ; pre = pre->rest())
      {
      const char *cmd = FrPrintableName(pre->first()) ;
      if (cmd && *cmd)
	 PlProcessCommand(cmd,cin,cout,cerr) ;
      }
   FrTextSpans *trlattice = PlTranslateSentence(input->input(),
						input->references(),
						inlattice,cerr) ;
   return trlattice ;
}

//----------------------------------------------------------------------

static LmFeatureVector *cache_lattices(TestInput *inputs,
				       bool zerod, bool cache)
{
   size_t count = 0 ;
   for (TestInput *input = inputs ; input ; input = input->next())
      {
      FrTextSpans *inlattice ;
      FrTextSpans *trlattice = get_translation_lattice(input,inlattice) ;
      input->storeSource(inlattice) ;
      input->storeLattice(trlattice) ;
      if (!cache)
	 break ;
      if (++count % 10 == 0)
	 cout << "." << flush ;
      }
   cout << endl ;
   // initialize weight vector
   FrTextSpans *trlattice = inputs->translationLattice() ;
   LmFeatureVector *weights =
	   (LmFeatureVector*)PlGetDecoderWeightVector(trlattice) ;
   if (weights)
      {
      FrList *onebest = PlDecodeNBestList(inputs->sourceLattice(),
					  trlattice,1) ;
      const FrList *features = 0 ;
      if (onebest)
	 {
	 features = (FrList*)((FrList*)onebest->first())->nth(3) ;
	 }
      // initialize decoder's feature weights
      delete default_weights ;
      default_weights = new LmFeatureVector(weights->featureMap()) ;
      if (features)
	 {
	 for (const FrList *f = features ; f ; f = f->rest())
	    {
	    const char *fname = FrPrintableName(f->first()->car()) ;
	    double wt = DEFAULT_USED_FEATURE_WEIGHT ;
#if 0
	    if (Fr_stricmp(fname,"Score") == 0 ||
		Fr_strnicmp(fname,"LMScore",7) == 0 ||
	        Fr_strnicmp(fname,"Brevity-",8) == 0 ||
		Fr_strnicmp(fname,"Verbosity-",10) == 0)
	       wt *= 100 ;
#endif
	    default_weights->setValue(fname,wt) ;
	    }
	 }
      else
	 default_weights->setValues(DEFAULT_FEATURE_WEIGHT) ;
      free_object(onebest) ;
      // preserve the weight of the Future feature, since it is used during
      //   decoding but its value at the end of decoding is always 0 and we
      //   don't want to force it to zero
      size_t future = weights->featureMap()->featureIndex("Future") ;
      default_weights->setValue(future,weights->value(future)) ;
      }
   if (weights && zerod)
      {
      weights->copyValues(default_weights) ;
      PlSetDecoderWeightVector(default_weights) ;
      }
   if (!cache)
      {
      inputs->storeSource(0) ;
      inputs->storeLattice(0) ;
      }
   return weights ;
}

//----------------------------------------------------------------------

static FrList *strip_null_entries(FrList *entries)
{
   FrList *result ;
   FrList **result_end = &result ;
   while (entries)
      {
      FrObject *entry = poplist(entries) ;
      if (entry)
	 result->pushlistend(entry,result_end) ;
      }
   *result_end = 0 ;
   return result ;
}

//----------------------------------------------------------------------

static void get_objective_scores_BLEU(const TestInput *input,
				      const FrList *nbest, double *scores,
				      size_t maxN, bool arith_mean = false)
{
   // calculate ngram counts in references
   PlLangModel refcounts(input->references(),maxN) ;
   // compute the sentence-level smoothed BLEU for each element of the nbest
   //   list
   for (size_t N = 0 ; nbest ; nbest = nbest->rest(), N++)
      {
      FrList *translation = (FrList*)nbest->first() ;
      if (!translation)
	 {
	 scores[N] = -DBL_MAX ;
	 continue ;
	 }
      FrString *trans_str = (FrString*)translation->second() ;
      FrList *trans = new FrList(trans_str) ;
      PlLangModel counts(trans,maxN) ;
      trans->eraseList(false) ;
      double obj_score = counts.computeBLEU(&refcounts,arith_mean) ;
      if (*trans_str == "(decoding failed)")
	 {
	 cout << "\n;\tDecoding failed for " << input->input() << endl ;
         cout << ";" << flush ;
	 obj_score = -FLT_MAX ;
	 }
      scores[N] = obj_score ;
      }
   return ;
}

//----------------------------------------------------------------------

static void get_objective_scores_ROUGE_S(const TestInput *input,
					 const FrList *nbest,
					 double *scores, size_t max_skip)
{
   PlRougeS refs(input->references(),max_skip) ;
   for (size_t N = 0 ; nbest ; nbest = nbest->rest(), N++)
      {
      FrList *translation = (FrList*)nbest->first() ;
      if (!translation)
	 {
	 scores[N] = -DBL_MAX ;
	 continue ;
	 }
      FrString *trans_str = (FrString*)translation->second() ;
      double obj_score = refs.score(trans_str) ;
      if (*trans_str == "(decoding failed)")
	 {
	 cout << "\n;\tDecoding failed for " << input->input() << endl ;
         cout << ";" << flush ;
	 obj_score = -FLT_MAX ;
	 }
      scores[N] = obj_score ;
      }
   return ;
}

//----------------------------------------------------------------------

static void get_objective_scores_external(const TestInput *input,
					  const FrList *nbest, double *scores)
{
   (void)nbest; (void)scores;
   const FrList *refs = input->references() ;

   refs = 0 ;
   return ;
}

//----------------------------------------------------------------------

static void get_objective_scores(const TestInput *input,
				 const FrList *nbest, double *scores)
{
   switch (Panlite_opt_objective)
      {
      case 0:	//EXTERNAL
	 get_objective_scores_external(input,nbest,scores) ;
	 break ;
      case 1:	//sBLEU3
	 get_objective_scores_BLEU(input,nbest,scores,3) ;
	 break ;
      case 2:	//sBLEU (sBLEU4)
	 get_objective_scores_BLEU(input,nbest,scores,4) ;
	 break ;
      case 3:	//sBLEU5
	 get_objective_scores_BLEU(input,nbest,scores,5) ;
	 break ;
      case 4:	//lBLEU3
	 get_objective_scores_BLEU(input,nbest,scores,3,true) ;
	 break ;
      case 5:	//lBLEU (lBLEU4)
	 get_objective_scores_BLEU(input,nbest,scores,4,true) ;
	 break ;
      case 6:	//lBLEU5
	 get_objective_scores_BLEU(input,nbest,scores,5,true) ;
	 break ;
      case 7:	//Rouge-S2
	 get_objective_scores_ROUGE_S(input,nbest,scores,2) ;
	 break ;
      case 8:	//Rouge-S4
	 get_objective_scores_ROUGE_S(input,nbest,scores,4) ;
	 break ;
      case 9:	//Rouge-S6
	 get_objective_scores_ROUGE_S(input,nbest,scores,6) ;
	 break ;
      case 10:  //wBLEU3
      case 11:  //wBLEU (wBLEU4)
      case 12:  //wBLEU5
	 //not implemented yet
      default:
	 FrMissedCase("get_objective_score") ;
	 break ;
      }
   return ;
}

//----------------------------------------------------------------------

#if 0
// method from David Chiang's paper
static void find_MIRA_examples(TestInput *input,
			       NBestEntry *candidates[])
{
   // first, grab the top N translations by model score
   for (size_t i = 0 ; i < MIRA_TOP_N ; i++)
      {
      candidates[i] = input->nthBest(i) ;
      }
   // then, grab the top N translations by (model + objective), making
   //   sure that the oracle translation is included
   input->sortNBest(0,NBestEntry::compareBalanced) ;
   bool have_oracle = false ;
   for (size_t i = 0 ; i < MIRA_TOP_N ; i++)
      {
      candidates[MIRA_TOP_N + i] = input->nthBest(i) ;
      if (i == input->oracle())
	 have_oracle = true ;
      }
   if (!have_oracle)
      candidates[2 * MIRA_TOP_N - 1] = input->nthBest(input->oracle());
   // finally, grab the top N translations by (model - objective) to get
   //   negative examples
   input->sortNBest(0,NBestEntry::compareInverted) ;
   for (size_t i = 0 ; i < MIRA_TOP_N ; i++)
      {
      candidates[2*MIRA_TOP_N + i] = input->nthBest(i) ;
      }
   return ;
}
#endif

//----------------------------------------------------------------------

static void adjust_weights_MIRA(LmFeatureVector *weights,
				const NBestEntry *candidate,
				const NBestEntry *oracle,
				double aggress,
				double learning_rate)
{
   LmFeatureVector feat_diff(candidate->features()) ;
   feat_diff.subtract(oracle->features()) ;
   double norm_sq = feat_diff.normSquared() ;
   double norm = ::sqrt(norm_sq) ;
   if (norm > 0.0)
      {
      norm *= ::sqrt(weights->normSquared()); 
      if (norm <= 0.0)
	 norm = 1.0 ;
      }
   else
      {
      norm = 1.0 ;
      norm_sq = 1.0 ;
      }
   double loss = oracle->score() - candidate->score() ;
   double eta = (feat_diff.score(weights)/norm + loss) / norm_sq ;
   double lim = 1.0 / (aggress * 2.0) ;
   if (eta > lim)
      eta = lim ;
   if (verbose)
      {
      FrList *fv = feat_diff.printable(false) ;
      cout << ";  MIRA update: eta=" << eta << ", diff=" << fv << endl ;
      free_object(fv) ;
      }
   weights->add(&feat_diff,-eta * learning_rate) ;
   return ;
}

//----------------------------------------------------------------------

static void update_weights_MIRA(TestInput *input,LmFeatureVector *weights)
{
//   double C = 0.05 ;
   double C = 0.25 ;
   // run sequential minimal optimization algorithm
   size_t oracle = input->oracle() ;
   const NBestEntry *oracle_entry = input->nthBest(oracle) ;
   if (oracle_entry)
      {
      // use max-loss 1-best MIRA update function as shown in Martins
      //   et al 2010
      const LmFeatureVector *oracle_feat = oracle_entry->features() ;
      double oracle_norm = ::sqrt(oracle_feat->normSquared()) ;
      size_t best = (size_t)~0 ;
#if 0
      double max_val = -DBL_MAX ;
#endif
      for (size_t i = 0 ; i < input->nbestCount() ; i++)
	 {
	 NBestEntry *entry = input->nthBest(i) ;
	 if (!entry)
	    continue ;
	 LmFeatureVector feat_diff(entry->features()) ;
	 feat_diff.subtract(oracle_feat) ;
	 double loss = oracle_entry->score() - entry->score() ;
	 double weight_norm = ::sqrt(weights->normSquared()) ;
	 double weight_diff = 0.0 ;
	 if (oracle_norm > 0.0 && weight_norm > 0.0)
	    weight_diff = feat_diff.score(weights) / oracle_norm / weight_norm;
//	 double rel_loss = loss / oracle_entry->score() ;
//	 double rel_eval = weight_diff/oracle_feat->score(weights) + rel_loss ;
	 double eval = weight_diff + loss ;
#if 0
	 if (rel_eval > max_val)
	    {
	    best = i ;
	    max_val = rel_eval ;
	    }
#else
	 if (eval > 0.0)
	    {
	    adjust_weights_MIRA(weights,entry,oracle_entry,C,1.0 / (i*i+1)) ;
	    }
#endif
	 }
      if (best < input->nbestCount())
	 {
	 NBestEntry *entry = input->nthBest(best) ;
	 adjust_weights_MIRA(weights,entry,oracle_entry,C,1.0) ;
	 }
      }
   double best_score ;
   input->setOracle(input->findBest(0,0,best_score)) ;
   input->setPrevBest(input->oracle()) ;
   return ;
}

//----------------------------------------------------------------------

static void update_weights_SP(LmFeatureVector *weights,
			      const LmFeatureVector *normalizer,
			      const LmFeatureVector *objective,
			      const LmFeatureVector *model,
			      double loss,
			      double learning_rate,
			      size_t generation)
{
   if (objective && model)
      {
      LmFeatureVector diff(objective) ;
      diff.subtract(model) ;
      if (opt_passive_aggressive)
	 {
	 double norm = diff.normSquared() ;
	 if (opt_weightbyloss)
	    {
	    // allow faster adaptation early on
	    (void)generation ;
//    	    if (generation < 10)
//	       loss *= (10.0 / generation) ;
	    loss = learning_rate = loss / (norm + 1 / (2.0 * opt_aggressiveness)) ;
	    }
	 else
	    learning_rate /= (norm + 1 / (2.0 * opt_aggressiveness)) ;
	 }
      if (opt_norm_update_features)
	 {
	 for (size_t i = 0 ; i < weights->numFeatures() ; i++)
	    {
	    double norm ;
	    if (opt_norm_features_absolute)
	       norm = normalizer ? normalizer->value(i) : 1.0 ;
	    else
	       {
	       double obj_val = objective->value(i) ;
	       double mod_val = model->value(i) ;
	       norm = fabs(obj_val) + fabs(mod_val) / 2.0 ;
	       }
	    if (norm > 0.0)
	       {
	       norm = soft_limit(norm,0.2,0.3999) ;
	       double adj = diff.value(i) / norm / norm ;
	       weights->incrValue(i,learning_rate * adj) ;
	       }
	    }
	 }
      else if (opt_weightbyloss)
	 {
	 weights->add(&diff,loss) ;
	 }
      else
	 {
	 weights->add(&diff,learning_rate) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

static void update_weights_SP(const NBestEntry *obj_best, double best_score,
			      const LmFeatureVector *model_best_features,
			      double model_score, double max_loss,
			      LmFeatureVector *weights,
			      const LmFeatureVector *normalizer,
			      double learning_rate, size_t generation)
{
   const LmFeatureVector *obj_best_features = obj_best->features() ;
   double div ;
   if (!opt_apply_divergence)
      div = 1.0 ;
   else if (weights->maxMagnitude() == 0.0)
      {
      div = divergence(model_best_features->score(default_weights),
		       obj_best_features->score(default_weights)) ;
      }
   else
      div = divergence(model_best_features->score(weights),
		       obj_best_features->score(weights) );
   // if the best translation is from a previous cycle, don't adjust the
   //   weights as much
   double aging =
      opt_apply_aging ? 1.0 / (1.0 + obj_best->age(generation)) : 1.0 ;
   double loss ;
   if (max_loss <= 0.0)
      {
      loss = 0.0 ;
      }
   else
      {
      double rel_loss = (best_score - model_score) / max_loss ;
      loss = max_loss * ::pow(rel_loss,opt_gamma) ;
      }
   update_weights_SP(weights,normalizer,
		     obj_best_features,model_best_features,
		     loss * div * aging,
		     best_score * learning_rate * div * aging,
		     generation) ;
   return ;
}

//----------------------------------------------------------------------

static double best_score_with_weights(const TestInput *input,
				      const LmFeatureVector *weights)
{
   double best_score = 0.0 ;
   double best_objective = 0.0 ;
   for (size_t i = 0 ; i < input->nbestCount() ; i++)
      {
      const LmFeatureVector *fv = input->nthBestFeatures(i) ;
      if (!fv)
	 continue ;
      double score = fv->score(weights) ;
      if (score > best_score)
	 {
	 best_score = score ;
	 best_objective = input->nthBestScore(i) ;
	 }
      }
   return best_objective ;
}

//----------------------------------------------------------------------

static double ranked_score(TestInput *inputs, size_t numinputs,
			   const char *sample,
			   const LmFeatureVector *weights)
{
   double cum_score = 0.0 ;
   size_t sampled = 0 ;
   for (size_t i = 0 ; i < numinputs && inputs ; inputs = inputs->next(), i++)
      {
      if (sample[i] && inputs->nbestCount() > 0)
	 {
	 sampled++ ;
	 cum_score += best_score_with_weights(inputs,weights) ;
	 }
      }
   return (sampled > 0) ? cum_score / sampled : 0.0 ;
}

//----------------------------------------------------------------------

static void show_curr_scores(const TestInput *input, size_t best_index,
			     double best_score, double model_score)
{
   if (verbose)
      {
      cout << ";\tbest=" << (int)best_index << " (oracle "<< input->oracle()
	   << "), best_score=" << best_score << ", model_best="
	   << model_score << endl ;
      }
   return ;
}

//----------------------------------------------------------------------

static bool do_update_step_SP(TestInput *inputs, size_t numinputs,
			      TestInput *input, size_t generation,
			      LmFeatureVector *weights,
			      const LmFeatureVector *normalizer,
			      double learning_rate)
{
   double model_score = input->nthBestScore(0) ;
   if (model_score <= -FLT_MAX)
      {
      // decoding failure, we don't actually have an n-best list, so we can't
      //   update anything
      return false ;
      }
   input->setPrevBest(input->oracle()) ;
   if (input->oracle() == 0 || input->surrogate() == 0)
      {
      // nothing to improve on
      show_curr_scores(input,0,input->nthBestScore(0),model_score) ;
      return false ;
      }
   const LmFeatureVector *model_best_features = input->nthBestFeatures(0) ;
   size_t best_index = input->surrogate() ;
   double best_score = input->nthBestScore(best_index) ;
   const NBestEntry *obj_best = input->nthBest(best_index) ;
   if (best_score < 0.0)
      best_score = 0.0 ;
   show_curr_scores(input,best_index,best_score,model_score) ;
   double max_loss = best_score - model_score ;
   TestInput *trial = 0 ;
   if (opt_minrisk && generation > 1 && input->sentenceNumber() > 0)
      {
      if (verbose)
	 {
	 cout << ";  verifying that update will not worsen performance"
	      << endl ;
	 }
      size_t sample_size = 20 ;
      FrLocalAllocC(char,sample,10000,numinputs) ;
      size_t first = (input->sentenceNumber() >= sample_size
		      ? input->sentenceNumber() - sample_size : 0) ;
      for (size_t i = first ; i < input->sentenceNumber() ; i++)
	 sample[i] = (char)1 ;
      double avgscore = ranked_score(inputs,numinputs,sample,weights) ;
      LmFeatureVector new_weights(weights) ;
      // check for best-scoring entry that doesn't cause a reduction in
      //   scores on a sampling of other n-best lists
      trial = new TestInput(input) ;
      trial->sortNBest(weights,NBestEntry::compareObjective) ;
      best_index = (size_t)~0 ;
      best_score = 0.0 ;
      obj_best = input->nthBest(0) ;
      size_t max_trials = 50 ;
      for (size_t i = 0 ; i < trial->nbestCount() && i < max_trials ; i++)
	 {
	 if (trial->nthBestScore(i) <= model_score
//	     || trial->nthBestScore(i) != trial->nthBestScore(0)
	    )
	    break ;
	 // speculatively update the weights with the current feature vector
	 new_weights.copyValues(weights) ;
	 const NBestEntry *entry = trial->nthBest(i) ;
	 update_weights_SP(entry,entry->score(),model_best_features,
			   model_score,max_loss,&new_weights,normalizer,
			   learning_rate,generation) ;
	 double new_score = ranked_score(inputs,numinputs,sample,&new_weights);
	 if (new_score >= avgscore)
	    {
	    best_index = i ;
	    best_score = trial->nthBestScore(i) ;
	    obj_best = trial->nthBest(i) ;
	    break ;
	    }
	 }
      FrLocalFree(sample) ;
      }
   bool made_changes = false ;
   if (!opt_minrisk && opt_topN > 1 &&
       best_index != 0 && best_index != (size_t)~0)
      {
      size_t topN = opt_topN ;
      TestInput trialinp(input) ;
      trialinp.sortNBest(weights,NBestEntry::compareObjective) ;
      for (size_t i = 0 ; i < trialinp.nbestCount() && topN ; i++)
	 {
//FIXME: don't update towards other high-scoring nbest entries; instead,
//  update *them* towards the oracle
	 double score = trialinp.nthBestScore(i) ;
	 if (score <= model_score)
	    continue ;
	 // update weights
	 update_weights_SP(trialinp.nthBest(i),score,model_best_features,
			   model_score,max_loss,weights,normalizer,
			   learning_rate,generation) ;
	 made_changes = true ;
	 --topN ;
	 }
      }
   else if ((opt_minrisk || best_index != 0) && best_index != (size_t)~0)
      {
      update_weights_SP(obj_best,best_score,model_best_features,
			model_score,max_loss,weights,normalizer,
			learning_rate,generation) ;
      made_changes = true ;
      }
   delete trial ;
   return made_changes ;
}

//----------------------------------------------------------------------

static bool do_update(PlOptimizerType algo, bool update_decoder_weights,
		      TestInput *inputs, size_t numinputs, TestInput *input,
		      size_t generation, LmFeatureVector *weights,
		      const LmFeatureVector *normalizer,
		      double lrate)
{
   bool made_changes = false ;
   switch (algo)
      {
      case Opt_MIRA:
	 update_weights_MIRA(input,weights) ;
	 made_changes = true ;
	 break ;
      default:
      case Opt_Perceptron:
	 if (do_update_step_SP(inputs,numinputs,input,generation,
			       weights,normalizer,lrate))
	    made_changes = true ;
	 break ;
      }
   if (made_changes && update_decoder_weights)
      set_decoder_weights(weights) ;
   if (made_changes && opt_log_updates)
      {
      FrList *fv = weights->printable(false) ;
      cout << "; updated weights: " << fv << endl ;
      free_object(fv) ;
      }
   return made_changes ;
}

//----------------------------------------------------------------------

static void rerank_nbest_list(TestInput *input,
			      const LmFeatureVector *weights,
			      double lambda = 0.0)
{
   // use the cached nbest feature vectors, re-sorting according to the
   //   given weight vector
   input->sortNBest(weights) ;
//cout<<"reranked:";for(size_t i = 0 ; i < input->nbestCount() ; i++){ NBestEntry *nbest = input->nthBest(i);cout<<' '<<nbest->features()->cachedScore(); }cout<<endl;
   double best_score  ;
   input->setSurrogate(input->findBest(lambda,0,best_score)) ;
   input->setOracle(input->findBest(0,0,best_score)) ;
   return ;
}

//----------------------------------------------------------------------

static void get_nbest_list(TestInput *input, size_t nbest_count,
			   FrFeatureVectorMap *map,
			   double lambda, const LmFeatureVector *weights,
			   size_t generation)
{
   FrTextSpans *inlattice = input->sourceLattice() ;
   FrTextSpans *trlattice = input->translationLattice() ;
   if (!trlattice || !inlattice)
      {
      trlattice = get_translation_lattice(input,inlattice) ;
      }
   FrList *nbest = PlDecodeNBestList(inlattice,trlattice,nbest_count) ;
   if (!input->sourceLattice() || !input->translationLattice())
      {
      delete trlattice ;
      delete inlattice ;
      }
   nbest = strip_null_entries(nbest) ;
   nbest_count = nbest->simplelistlength() ;
   bool had_prev_best = (input->prevBestCount() != 0) ;
   if (had_prev_best)
      nbest_count += input->prevBestCount() ;
   FrLocalAlloc(double,obj_scores,2048,nbest_count) ;
   get_objective_scores(input,nbest,obj_scores) ;
   input->initNBest(nbest_count) ;
   for (size_t N = 0 ; nbest ; N++)
      {
      FrList *nth = (FrList*)poplist(nbest) ;
      input->initNthBest(N,nth,map,generation) ;
      free_object(nth) ;
      input->setNthBestScore(N,obj_scores[N]) ;
      }
   FrLocalFree(obj_scores) ;
   if (had_prev_best)
      input->addPrevBest() ;
   double best_score ;
   input->setSurrogate(input->findBest(lambda,weights,best_score)) ;
   input->setOracle(input->findBest(0,0,best_score)) ;
   return ;
}

//----------------------------------------------------------------------

static void init_nbest_lists(TestInput *inputs, size_t numinputs, ostream &out,
			     PlOptimizerType algo, size_t nbest_count,
			     size_t generation, LmFeatureVector *weights,
			     LmFeatureVector *normalizer,
			     bool update = true, bool conservative = false,
			     double lambda = 0.0)
{
   (void)numinputs ;
   size_t num_training = 0 ;
   LmFeatureVector avg_weights(weights) ;
   normalizer->clear() ;
   bool collect_norm = opt_norm_features_absolute ;
   if (collect_norm && opt_norm_features_global && algo == Opt_Perceptron)
      {
      for (TestInput *input = inputs ; input ; input = input->next())
	 {
	 if (input->nbestCount() > 0)
	    {
	    update_normalizer(input,normalizer) ;
	    collect_norm = false ;
	    }
	 }
      }
   for (TestInput *input = inputs ; input ; input = input->next())
      {
      bool had_nbest = input->nbestCount() > 0 ;
      get_nbest_list(input,nbest_count,weights->featureMap(),lambda,weights,
		     generation) ;
      if (opt_norm_update_features && opt_norm_features_absolute &&
	  (collect_norm || (!had_nbest && algo == Opt_Perceptron)))
	 update_normalizer(input,normalizer) ;
      if (update)
	 {
	 (void) do_update(algo,true,inputs,numinputs,input,generation,weights,
			  normalizer,1.0) ;
	 avg_weights.add(weights) ;
	 }
      if (++num_training % 10 == 0 && !verbose)
	 out << "." << flush ;
      }
   if (update && conservative)
      {
      avg_weights.scaleValues(1.0 / (num_training+1)) ;
      weights->copyValues(&avg_weights) ;
      }
#ifdef NORMALIZE_EACH_PASS
   if (update)
      normalize_vector(weights) ;
#endif /* NORMALIZE_EACH_PASS */
   out << endl ;
   return ;
}

//----------------------------------------------------------------------

static double compute_current_score(TestInput *inputs, ostream &out,
				    const LmFeatureVector *weights,
				    double lambda, double &cum_oracle)
{
   size_t num_training = 0 ;
   double cum_score = 0.0 ;
   double cum_surrogate = 0.0 ;
   cum_oracle = 0.0 ;
   size_t cum_rank = 0 ;
   if (verbose)
      {
      FrList *wt = weights->printable(false) ;
      cout << "computing score with weights=" << wt << endl ;
      free_object(wt) ;
      }
   for (TestInput *input = inputs ; input ; input = input->next())
      {
      num_training++ ;
      rerank_nbest_list(input,weights,lambda) ;
      cum_oracle += input->nthBestScore(input->oracle()) ;
      cum_rank += input->oracle() ;
      if (input->surrogate() < input->nbestCount())
	 cum_surrogate += input->nthBestScore(input->surrogate()) ;
      double model_score = input->nthBestScore(0) ;
      if (model_score > -FLT_MAX)
	 cum_score += model_score ;
      }
   cum_surrogate /= num_training ;
   cum_oracle /= num_training ;
   cum_score /= num_training ;
   out << ";  Average objective score = " << setprecision(7) << cum_score
       << " (oracle " << cum_oracle << ", surrogate "
       << cum_surrogate << ")" << endl ;
   double avg_rank = cum_rank / (double)num_training ;
   out << ";  average rank of oracle translation: " << avg_rank << endl ;
   return cum_score ;
}

//----------------------------------------------------------------------

static bool do_optimize_pass(TestInput *inputs, LmFeatureVector *weights,
			     PlOptimizerType algo, size_t generation,
			     const LmFeatureVector *normalizer, double lrate,
			     bool keep_nbest, bool conservative)
{
   bool made_changes = false ;
   LmFeatureVector avg_weights(weights) ;
   size_t num_training = 0 ;
   size_t numinputs = inputs->listlength() ;
   for (TestInput *input = inputs ; input ; input = input->next())
      {
      num_training++ ;
      made_changes = do_update(algo,false,inputs,numinputs,input,generation,
			       weights,normalizer,lrate) ;
      if (conservative)
	 avg_weights.add(weights) ;
      if (!keep_nbest)
	 input->clearNBest() ;
      }
   if (verbose)
      {
      FrList *wt = weights->printable(false) ; 
      cout<<";\tweights after training epoch=" << wt << endl ;
      free_object(wt) ;
      }
   if (conservative)
      {
      avg_weights.scaleValues(1.0 / (num_training+1)) ;
      weights->copyValues(&avg_weights) ;
      if (verbose)
	 {
	 FrList *wt = weights->printable(false) ; 
	 cout<<";\taveraged weights=" << wt << endl ;
	 free_object(wt) ;
	 }
      }
#ifdef NORMALIZE_EACH_PASS
   normalize_vector(weights) ;
#endif /* NORMALIZE_EACH_PASS */
   return made_changes ;
}

//----------------------------------------------------------------------

static void print_feature_weights(ostream &out,
				  const LmFeatureVector *weights,
				  const char *prefix,
				  bool all = true)
{
   for (size_t i = 0 ; i < weights->numFeatures() ; i++)
      {
      if (!all && default_weights->value(i) == 0.0)
	 continue ;
      out << prefix << weights->featureName(i) << ": "
	  << setprecision(8) << (float)weights->value(i) << endl ;
      }
   return ;
}

//----------------------------------------------------------------------

static size_t find_best_pass(double *scores, size_t num_passes,
			     double &best_score)
{
   best_score = -DBL_MAX ;
   size_t best_pass = 0 ;
   for (size_t pass = 1 ; pass <= num_passes ; pass++)
      {
      if (scores[pass] > best_score)
	 {
	 best_score = scores[pass] ;
	 best_pass = pass ;
	 }
      }
   return best_pass ;
}

//----------------------------------------------------------------------

void PlOptimizeParameters(istream &in, ostream &out, PlOptimizerType algo,
			  size_t nbest_count, int max_iter, size_t num_passes,
			  double lambda, double convergence)
{
   bool zerod = false ;
   if (max_iter < 0)
      {
      zerod = true ;
      max_iter = -max_iter ;
      }
   if (num_passes < 1)
      num_passes = 1 ;
   FrTimer timer ;
   out << ";Parameter Optimization " ;
   switch (algo)
      {
      case Opt_Perceptron:	out << "(Perceptron)" ; break ;
      case Opt_MIRA:		out << "(MIRA)" ; break ;
      case Opt_Anneal:		out << "(Annealing)" ; break ;
      case Opt_SVM:		out << "(SVM)" ; break ;
      case Opt_CRF:		out << "(CRF)" ; break ;
      default: break ;
      }
   out << endl ;
   out << ";  MaxIter=" << max_iter << ", Passes=" << num_passes
       << ", NBest=" << nbest_count << ", Lambda=" << lambda
       << ", Converge=" << convergence
       << endl ;
   out << ";  Aggr=" << opt_aggressiveness << ", topN=" << opt_topN
       << ", gamma=" << opt_gamma << ", Rouge.beta=" << opt_rouge_beta ;
   if (zerod)
      out << ", zero wts"<< endl ;
   else
      out << ", keep wts"<< endl ;
   // Step 1: load the entire input, since we'll be iterating over it
   //   numerous times
   out << ";Step 1: Read Input" << endl ;
   TestInput *inputs = read_input(in,out) ;
   size_t numinputs = inputs->listlength() ;
   if (numinputs == 0)
      {
      out << ";NO INPUT.  Unable to optimize parameters." << endl ;
      return ;
      }
   // Step 2: cache translation lattices
   out << ";Step 2: generate translation lattices" << endl ;
   LmFeatureVector *weights = cache_lattices(inputs,zerod,Panlite_opt_cache) ;
   if (!weights)
      {
      out << "Unable to determine features!" << endl ;
      return ;
      }
   out << "; loading and translating took " << timer.readsec()
       << " seconds" << endl ;
   // Step 3: repeatedly run over the input, decoding a sentence at a time,
   //   and updating weights as we go
   out << ";Step 3: decode lattices and adjust weights" << endl ;
   out << "; Initial feature weights:" << endl ;
   print_feature_weights(out,weights,";\t",false) ;
   LmFeatureVector cum_weights(weights) ;
   // iterate over the tuning data
   bool made_changes = true ;
   double prev_oracle = -DBL_MAX ;
   double prev_best = -DBL_MAX ;
   double global_best_score = -DBL_MAX ;
   bool want_update = zerod ;
   for (int iter = 1 ; iter <= max_iter && made_changes ; iter++)
      {
      FrTimer iter_timer ;
//      made_changes = false ;
      out << "; Begin Iteration " << iter << endl ;
      out << ";  " << flush ;
      // zeroth pass: update weights incrementally to ensure that we
      //   actually make progress on each iteration, but then ignore
      //   the results and do the actual optimization by reranking
      //   the existing nbest lists
      LmFeatureVector *normalizer = new LmFeatureVector(weights->featureMap());
      bool cons = iter > 1 ;
      init_nbest_lists(inputs,numinputs,out,algo,nbest_count,iter,
		       weights,normalizer,want_update,cons,
		       (iter == 1 && zerod) ? 0.0 : lambda) ;
      want_update = false ;
      double cum_oracle = 0.0 ;
      LmFeatureVector *best_weights[num_passes+2] ;
      double scores[num_passes+1] ;
      for (size_t pass = 1 ; pass <= num_passes ; pass++)
	 {
//         double lrate = 1.0 / ::sqrt(pass) ;
//         double lrate = 1.0 / (1.0 + ::log(pass)) ;
	 double lrate = 1.0 ;
	 best_weights[pass] = weights->clone() ;
	 scores[pass] = compute_current_score(inputs,out,weights,lambda,
					      cum_oracle) ;
	 bool cons = !zerod ;
	 bool keep_nbest = pass < num_passes || opt_minrisk ;
	 if (do_optimize_pass(inputs,weights,algo,iter,normalizer,lrate,
			      keep_nbest,cons))
	    made_changes = true ;
	 }
      delete normalizer ;
      double best_score = -DBL_MAX ;
      size_t best_pass = find_best_pass(scores,num_passes,best_score) ;
      out << ";  Best objective score was " << best_score 
	  << " (oracle " << cum_oracle << ")" << endl ;
      if (best_score > global_best_score)
	 {
	 cum_weights.copyValues(best_weights[best_pass]) ;
	 global_best_score = best_score ;
	 }
      if (!quiet_mode)
	 {
	 out << ";  New feature weights:" << endl ;
	 LmFeatureVector norm_weights(best_weights[best_pass]) ;
	 normalize_vector(&norm_weights) ;
	 print_feature_weights(out,&norm_weights,";\t",false) ;
	 }
      if (best_pass == 1)
	 {
	 // if the original weights were the best, we need to use the
	 //   second best, or we'll just get stuck with the same nbest lists
	 if (num_passes == 1 || 1 ) //FIXME
	    {
	    best_pass = 0 ;
	    want_update = true ;
	    }
	 else
	    {
	    scores[best_pass] = -DBL_MAX ;
	    best_pass = find_best_pass(scores,num_passes,best_score) ;
	    }
	 }
      if (best_pass != 0)
	 weights->copyValues(best_weights[best_pass]) ;
      set_decoder_weights(weights) ;
      for (size_t pass = 1 ; pass < num_passes ; pass++)
	 {
	 delete best_weights[pass] ;
	 }
      out << "; End Iteration " << iter << " (" << iter_timer.readsec()
	  << " seconds)" << endl ;
      if (cum_oracle < prev_oracle ||
	  (convergence > 0.0 && prev_oracle > 0.0 && 
	   cum_oracle < prev_oracle * (1.0 + convergence)))
	 {
	 out << "; Oracle scores have converged." << endl ;
	 break ;
	 }
      else if (convergence < 0.0 && prev_best > 0.0 &&
	       best_score < prev_best * (1.0 + convergence))
	 {
	 out << "; Objective score is no longer increasing." << endl ;
	 break ;
	 }
      prev_best = best_score ;
      prev_oracle = cum_oracle ;
      }
   // Step 4: normalize the final weights and output the result
   out << ";Step 4: compute final weights" << endl ;
   normalize_vector(&cum_weights) ;
   // display the final weights
   out << "****Final feature weights, score="
       << global_best_score << "****" << endl ;
   out << "[LMWeights]" << endl ;
   print_feature_weights(out,&cum_weights,"") ;
   out << "\n[]" << endl ;
   // Step 5: cleanup
   delete weights ;
   inputs->deleteList() ;
   out << ";Parameter tuning complete (" << timer.readsec() << " seconds)"
       << endl ;
   return ;
}

// end of file plopt.cpp //
