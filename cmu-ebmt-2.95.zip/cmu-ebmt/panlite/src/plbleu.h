/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.95							*/
/*	 by Ralf Brown							*/
/*									*/
/*  File plbleu.h		BLEU/NIST scoring metrics		*/
/*  LastEdit: 28mar10							*/
/*									*/
/*  (c) Copyright 2002,2003,2010 Ralf Brown				*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __PLBLEU_H_INCLUDED
#define __PLBLEU_H_INCLUDED

#include "FramepaC.h"

/************************************************************************/
/*	Manifest Constants						*/
/************************************************************************/

#define DEFAULT_MAX_N 4

/************************************************************************/
/************************************************************************/

class PlLangModel
   {
   private:
      class PlNgramCount *ngrams ;
      size_t min_sent_len, max_sent_len ;
      size_t max_ngram_len ;
   private:
      void init() ;
      void insertNGrams(const FrList *sentence, size_t maxN) ;
      void limitCounts(const PlLangModel *ref_lm) ;
   public:
      PlLangModel() { init() ; }
      PlLangModel(const FrList *sentences, size_t maxN = DEFAULT_MAX_N) ;
      ~PlLangModel() ;

      // modifiers
      void insertSentences(const FrList *sentences,
			   size_t maxN = DEFAULT_MAX_N) ;

      // simple accessors
      size_t minSentenceLength() const { return min_sent_len ; }
      size_t maxSentenceLength() const { return max_sent_len ; }
      size_t avgSentenceLength() const
         { return (min_sent_len + max_sent_len) / 2 ; }
      size_t maxNGramLen() const { return max_ngram_len ; }
      double brevityPenalty(size_t sent_len) const ;

      // complex accessors
      double computeBLEU(const PlLangModel *refs,
			 bool arithmetic_mean = false) ;

      // I/O
      void dump() const ;
   } ;


#endif /* !__PLBLEU_H_INCLUDED */

// end of file plbleu.h //
