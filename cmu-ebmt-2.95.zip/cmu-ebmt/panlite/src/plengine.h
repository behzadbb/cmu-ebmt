/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File plengine.h		basic translation-engine interface 	*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 2001,2004,2005,2006,2007,2009 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "FramepaC.h"

/************************************************************************/
/************************************************************************/

class MEMTEngine ;
class PLConfig ;
class PlEngineConfig ;

typedef bool MEMT_StartEngineFunc(MEMTEngine *,const PLConfig *,
				    const PlEngineConfig *,ostream &,
				    bool verbosely) ;
typedef bool MEMT_TranslateFunc(MEMTEngine *, bool prepare_to_translate,
				  const FrTextSpans *input,
				  FrTextSpans *lattice, ostream &err) ;
typedef bool MEMT_AddTranslationFunc(MEMTEngine *, const FrString *src,
				       const FrString *trg,
				       const FrString *meta) ;
typedef bool MEMT_SelectKBFunc(MEMTEngine *, const char *) ;
typedef bool MEMT_PrepDocFunc(MEMTEngine *, bool starting) ;
typedef FrObject *MEMT_TransformFunc(MEMTEngine *, const FrList *wordlist) ;
typedef char *MEMT_CommandFunc(MEMTEngine *, const char *command) ;
typedef bool MEMT_ShutdownFunc(MEMTEngine *) ;
 
/************************************************************************/
/************************************************************************/

enum MEMTEngineType
   {
      ET_None,
      ET_Preproc,
      ET_Annotate,
      ET_Xlat,
      ET_Decode,
      ET_Postproc,
      ET_Other
   } ;

typedef FrSelfRegistering<class MEMTEngine> EngineList ;

class MEMTEngine
   {
   private:
      EngineList 	m_engines ;
      static bool 	setup_complete ;
      MEMTEngine       *shared_connection ;
      char 	       *m_filename ;
      ifstream 	       *m_stream ;
   protected:
      const char       *network_flag ;
      const char       *extra_arg ;
      const char       *translate_cmd ;
      istream 	       *engine_stdout ;
      ostream 	       *engine_stdin ;
      int 		engine_pipe_in ;
      int 		engine_pipe_out ;
      volatile bool 	m_running ;
      bool 		m_remote ;
      bool 		m_disabled ;
      bool 		start_even_if_disabled ;
      bool 		allow_updates ;
      bool 		prepping_doc ;
      
      MEMT_StartEngineFunc *start_fn ;
      MEMT_TranslateFunc *translate_fn ;
      MEMT_AddTranslationFunc *addxlat_fn ;
      MEMT_SelectKBFunc *selectKB_fn ;
      MEMT_SelectKBFunc *selectGenre_fn ;
      MEMT_PrepDocFunc *prepDoc_fn ;
      MEMT_TransformFunc *transform_fn ;
      MEMT_CommandFunc *command_fn ;
      MEMT_ShutdownFunc *shutdown_fn ;
   protected: // methods
      void init() ;
   public:
      MEMTEngine() ;
      MEMTEngine(const char *eng_name, const char *eng_tag,
		 MEMTEngineType type,
		 MEMT_StartEngineFunc *, MEMT_TranslateFunc *,
		 MEMT_ShutdownFunc *, MEMT_AddTranslationFunc * = 0,
		 MEMT_SelectKBFunc * = 0,
		 MEMT_TransformFunc * = 0, MEMT_CommandFunc * = 0,
		 MEMT_SelectKBFunc *genre_fn = 0, MEMT_PrepDocFunc * = 0) ;
      MEMTEngine(const char *eng_name, const char *eng_tag,
		 MEMTEngineType type,
		 const char *network_flag, const char *startup_extra_arg,
		 const char *xlat_cmd, MEMT_AddTranslationFunc * = 0,
		 MEMT_SelectKBFunc * = 0,
		 MEMT_TransformFunc * = 0, MEMT_CommandFunc * = 0,
		 MEMT_SelectKBFunc *genre_fn = 0, MEMT_PrepDocFunc * = 0) ;
      ~MEMTEngine() ;
      static void setupComplete() { setup_complete = true ; }

      // engine description functions
      const char *engineName() const { return m_engines.name() ; }
      FrSymbol *engineTag() const { return m_engines.tag() ; }
      bool isRunning() const { return m_running ; }
      bool isRemote() const { return m_remote ; }
      bool usingDataFile() const { return m_stream != 0 ; }
      bool engineEnabled() const { return !m_disabled ; }
      bool updatesAllowed() const
	  { return allow_updates && (addxlat_fn != 0) ; }
      bool sharedConnection() const { return shared_connection != 0 ; }
      ostream &stdIn() const { return *engine_stdin ; }
      istream &stdOut() const
	 { return m_stream ? *((istream*)m_stream) : *engine_stdout ; }
      FrSocket pipeIn() const { return (FrSocket)engine_pipe_in ; }
      FrSocket pipeOut() const { return (FrSocket)engine_pipe_out ; }

      bool inputAvailable() const ;
      bool nameInList(const FrList *namelist) const ;

      // generic engine support
      const char *networkFlag() const { return network_flag ; }
      const char *extraArg() const { return extra_arg ; }
      const char *translateCmd() const { return translate_cmd ; }
      bool startEngine(const PLConfig *config,
			 const PlEngineConfig *engcfg,
			 const char *network_flag, const char *extra_arg,
			 ostream &err, bool run_verbosely) ;
      bool translate(bool prepare, const FrTextSpans *input,
		       FrTextSpans *lattice, const char *xlat_cmd) ;

      bool prepareToTranslate(const FrTextSpans *input, FrTextSpans *lattice,
				ostream &err, bool run_verbosely) ;
      bool finishTranslation(const FrTextSpans *input, FrTextSpans *lattice,
			       ostream &err, bool gc, bool run_verbosely) ;

      // manipulators
      bool startEngine(const PLConfig *config, ostream &err,
			 bool run_verbosely = false) ;
      bool execProgram(ostream &err, const char *remote_exec_string,
			 const char *hostname, int socket,
			 const char *network_flag,
			 const char *program_name, ...) ;
      bool copyConnection(MEMTEngine &other_engine) ;
      bool awaitReadiness(ostream &err, bool run_verbosely = false) ;
      bool translateSentence(const FrTextSpans *input, FrTextSpans *lattice,
			       ostream &err, bool gc,
			       bool run_verbosely = false) ;
      bool addTranslation(const FrString *src, const FrString *trg,
			    const FrString *meta, ostream &out) ;
      bool selectKB(const char *KBname) ;
      bool selectGenre(const char *genre_name) ;
      bool prepareDoc(bool starting, ostream &err,
			bool run_verbosely = false) ;
      FrString *transform(const FrString *sentence, ostream &err,
			  bool run_verbosely = false) ;
      bool sendLine(const char *keytext,const char *value = 0) ;
      char *sendCommand(const char *command, ostream &err,
			bool run_verbosely) ;
      char *sendRemoteCommand(const char *command) ;
      bool initiateShutdown(ostream &err, bool run_verbosely = false) ;
      bool finishShutdown() ;

      bool insertArc(FrTextSpans *lattice, const FrList *info) ;
      bool insertArc(FrTextSpans *lattice, int pos, int len, FrList *info) ;
      bool insertArcs(FrTextSpans *lattice, FrList *arcs) ;

      void enableEngine(bool ena = true) ;
      void disableEngine() { m_disabled = true ; }
      void startWhileDisabled(bool start = true)
   	 { start_even_if_disabled = start ; }

      void allowUpdates(bool allow = true) { allow_updates = allow ; }
      void disallowUpdates() { allow_updates = false ; }

      FrObject *readObject() ;
      bool readLine(char *buf, size_t bufsize) ;

      void monitorPipeIO(bool enable) ;

      // static methods for class
      static void enumerate(ostream &) ;
      static MEMTEngine *findEngine(const char *name) ;
      static MEMTEngine *findEngine(FrSymbol *tag) ;
      static bool iterate(int type,enum FrComparisonType comp,
			    bool (*fn)(MEMTEngine*,va_list),...)
	 {
	 FrVarArgs(fn) ;
	 bool success = EngineList::iterateVA(type,comp,fn,args) ;
	 FrVarArgEnd() ;
	 return success ;
	 }
      static void disableAllEngines() ;
      static void disallowUpdatesAllEngines() ;
      static bool startAllEngines(const PLConfig *, ostream &err,
				    bool verbosely = false) ;
      static bool awaitReadinessAllEngines(ostream &err,
					     bool run_verbosely = false) ;
      static bool selectGenreAll(const char *genre) ;
      static bool translate(const FrTextSpans *input, FrTextSpans *lattice,
			      ostream &err, bool gc = false,
			      bool run_verbosely = false) ;
      static void shutdownAllEngines(ostream &err, bool verbosely = false) ;

      // error-reporting
      bool stillAlive(ostream &) const ;
      void engineDied(ostream &) const ;
   } ;

#define MEMTEng_DEFCMDFUNC ((MEMT_CommandFunc*)~0)

#ifdef __WATCOMC__
// turn off the mangled-name-truncated warnings by setting the level so
//  high (10) that the warning isn't issued even with the -wx (all
//  warnings) flag
#pragma warning 433 10 ;
#endif /* __WATCOMC__ */

//----------------------------------------------------------------------

extern MEMTEngine dict_engine ;
extern MEMTEngine ebmt_engine ;
extern MEMTEngine gloss_engine ;

extern MEMTEngine preproc_engine ;
extern MEMTEngine morph_engine ;
extern MEMTEngine lm_engine ;

//----------------------------------------------------------------------

void Panlite_trap_sigpipe() ;
void Panlite_restore_sigpipe() ;

// end of file plengine.h //
