/************************************************************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File plengine.cpp		basic translation-engine interface 	*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 2001,2002,2003,2004,2005,2006,2007,2008,2009		*/
/*		 Ralf Brown						*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include <fstream>
#include <signal.h>
#include "plchart.h"
#include "plconfig.h"
#include "plengine.h"
#include "panlite.h"
#include "plproc.h"
#include "plglobal.h"

/************************************************************************/
/*	Global Variables						*/
/************************************************************************/

bool MEMTEngine::setup_complete = false ;

static volatile bool *current_program ;
static volatile ostream *current_stream = 0 ;
static volatile const char *current_process_name = 0 ;

#ifdef SIGPIPE
static FrSignalHandler *sigpipe = 0 ;
#endif /* SIGPIPE */

// define some generic engine handlers
MEMTEngine kbmt_engine("Knowledge-Based MT",":KBMT",ET_Xlat,
		       KBMT_NETWORK_FLAG,0,"KBMT") ;
MEMTEngine transfer_engine("Transfer MT",":XFER",ET_Xlat,
			   XFER_NETWORK_FLAG,0,"XFER") ;

// force engines which are not explicitly accessed to be linked
extern MEMTEngine smt_engine ;
extern MEMTEngine systran_engine ;
MEMTEngine *engine_list[] =
   {
      &gloss_engine,
      &smt_engine,
      &systran_engine,
   } ;

/************************************************************************/
/*	Helper Functions						*/
/************************************************************************/

#if defined(SIGPIPE)
static void sigpipe_handler(int)
{
   if (current_program)
      *current_program = false ;
   if (current_stream)
      ((ostream*)current_stream)->setstate(ios::failbit) ;
   if (current_process_name)
      FrWarningVA("Lost connection to %s.",current_process_name) ;
   else
      FrWarning("Lost connection to another process.") ;
   return ;
}
#endif /* SIGPIPE */

//----------------------------------------------------------------------

void Panlite_trap_sigpipe()
{
#ifdef SIGPIPE
   if (!sigpipe)
      sigpipe = new FrSignalHandler(SIGPIPE,sigpipe_handler) ;
#endif /* SIGPIPE */
   return ;
}

//----------------------------------------------------------------------

void Panlite_restore_sigpipe()
{
#ifdef SIGPIPE
   delete sigpipe ;
#endif /* SIGPIPE */
   return ;
}

//----------------------------------------------------------------------

static bool generic_start(MEMTEngine *engine, const PLConfig *config,
			    const PlEngineConfig *engcfg,
			    ostream &err, bool run_verbosely)
{
   return engine->startEngine(config,engcfg,engine->networkFlag(),
			      engine->extraArg(),err,
			      run_verbosely) ;
}

//----------------------------------------------------------------------

static bool generic_translate(MEMTEngine *engine, bool prepare,
				const FrTextSpans *input,
				FrTextSpans *lattice,ostream &/*err*/)
{
   return engine->translate(prepare,input,lattice,engine->translateCmd()) ;
}

//----------------------------------------------------------------------

static bool generic_shutdown(MEMTEngine *engine)
{
   return engine->sendLine("*EOF*") ;
}

/************************************************************************/
/*	Methods for class MEMTEngine					*/
/************************************************************************/

MEMTEngine::MEMTEngine() : m_engines(this,ET_None,0,0,(FrSymbol*)0)
{
   init() ;
   return ;
}

//----------------------------------------------------------------------

MEMTEngine::MEMTEngine(const char *eng_name, const char *eng_tag,
		       MEMTEngineType type,
		       MEMT_StartEngineFunc *start, MEMT_TranslateFunc *xlat,
		       MEMT_ShutdownFunc *shutdown,
		       MEMT_AddTranslationFunc *addxlat,
		       MEMT_SelectKBFunc *select,
		       MEMT_TransformFunc *transform, MEMT_CommandFunc *cmd,
		       MEMT_SelectKBFunc *genre, MEMT_PrepDocFunc *prepdoc)
   : m_engines(this,type,0,eng_name,eng_tag)
{
   init() ;
   start_fn = start ;
   network_flag = 0 ;
   extra_arg = 0 ;
   translate_cmd = 0 ;
   translate_fn = xlat ;
   shutdown_fn = shutdown ;
   addxlat_fn = addxlat ;
   selectKB_fn = select ;
   transform_fn = transform ;
   command_fn = cmd ;
   selectGenre_fn = genre ;
   prepDoc_fn = prepdoc ;
   return ;
}

//----------------------------------------------------------------------

MEMTEngine::MEMTEngine(const char *eng_name, const char *eng_tag,
		       MEMTEngineType type,
		       const char *net_flag, const char *startup_extra_arg,
		       const char *xlat_cmd,
		       MEMT_AddTranslationFunc *addxlat,
		       MEMT_SelectKBFunc *select,
		       MEMT_TransformFunc *transform, MEMT_CommandFunc *cmd,
		       MEMT_SelectKBFunc *genre, MEMT_PrepDocFunc *prepdoc)
   : m_engines(this,type,0,eng_name,eng_tag)
{
   init() ;
   network_flag = net_flag ;
   extra_arg = startup_extra_arg ;
   translate_cmd = xlat_cmd ;
   start_fn = generic_start ;
   translate_fn = generic_translate ;
   shutdown_fn = generic_shutdown ;
   addxlat_fn = addxlat ;
   selectKB_fn = select ;
   transform_fn = transform ;
   command_fn = cmd ;
   selectGenre_fn = genre ;
   prepDoc_fn = prepdoc ;
   return ;
}

//----------------------------------------------------------------------

void MEMTEngine::init()
{
   m_running = false ;
   m_remote = false ;
   m_disabled = false ;
   start_even_if_disabled = false ;
   allow_updates = true ;
   prepping_doc = false ;
   engine_stdout = 0 ;
   engine_stdin = 0 ;
   engine_pipe_in = -1 ;
   engine_pipe_out = -1 ;
   start_fn = 0 ;
   translate_fn = 0 ;
   addxlat_fn = 0 ;
   selectKB_fn = 0 ;
   selectGenre_fn = 0 ;
   prepDoc_fn = 0 ;
   command_fn = 0 ;
   shutdown_fn = 0 ;
   return ;
}

//----------------------------------------------------------------------

MEMTEngine::~MEMTEngine()
{
   initiateShutdown(cerr) ;
   m_engines.unlink() ;
   finishShutdown() ;
   return ;
}

//----------------------------------------------------------------------

void MEMTEngine::engineDied(ostream &output) const
{
   output_message(output,"ERROR",engineName()," died!",0) ;
   return ;
}

//----------------------------------------------------------------------

bool MEMTEngine::stillAlive(ostream &output) const
{
   if (isRunning())
      return true ;
   else
      {
      engineDied(output) ;
      return false ;
      }
}

//----------------------------------------------------------------------

bool MEMTEngine::nameInList(const FrList *names) const
{
   for ( ; names ; names = names->rest())
      {
      FrSymbol *n = FrCvt2Symbol(names->first(),char_encoding) ;
      if (n)
	 {
	 if (strcmp(n->symbolName(),engineName()) == 0)
	    return true ;
	 if (*engineName() == ':' &&
	     strcmp(n->symbolName(),engineName()+1) == 0)
	    return true ;
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

static bool list_engine_tag(MEMTEngine *eng, va_list args)
{
   FrVarArg(ostream*,out) ;
   (*out) << eng->engineTag() << ' ' ;
   return true ;
}

//----------------------------------------------------------------------

void MEMTEngine::enumerate(ostream &out)
{
   EngineList::iterate(ET_Xlat,FrComp_DontCare,list_engine_tag,&out) ;
   return ;
}

//----------------------------------------------------------------------

MEMTEngine *MEMTEngine::findEngine(const char *name)
{
   EngineList *eng = EngineList::find(name) ;
   if (!eng && *name != ':')
      {
      // look for the engine with tag ":name"
      char namebuf[FrMAX_SYMBOLNAME_LEN+3] ;
      namebuf[0] = ':' ;
      strncpy(namebuf+1,name,sizeof(namebuf)-1) ;
      namebuf[sizeof(namebuf)-1] = '\0' ;
      eng = EngineList::find(namebuf) ;
      }
   return eng ? eng->instance() : 0 ;
}

//----------------------------------------------------------------------

MEMTEngine *MEMTEngine::findEngine(FrSymbol *tag)
{
   EngineList *eng = EngineList::find(tag) ;
   if (!eng && tag && tag->symbolName()[0] != ':')
      {
      // hmm, no exact match, so try a fuzzy match if there's not leading
      //   colon on the given tag
      return findEngine(tag->symbolName()) ;
      }
   return eng ? eng->instance() : 0 ;
}

//----------------------------------------------------------------------

bool MEMTEngine::inputAvailable() const
{
   if (usingDataFile())
      return !m_stream->eof() ;
   else if (engine_stdout)
      {
      if (engine_stdout->rdbuf()->in_avail())
	 return true ;
#if FIXME
      if (isRemote() && pipeIn() != (FrSocket)INVALID_SOCKET)
	 return ((FrISockStream*)engine_stdout)->inputAvailable() ;
      else
	 return (!engine_stdout->eof() && !engine_stdout->fail()) ;
#else
      if (FrInputAvailable(pipeIn()))
	 return true ;
#endif
      }
   return false ;
}

//----------------------------------------------------------------------

bool MEMTEngine::readLine(char *buf, size_t bufsize)
{
   if (isRunning() && engine_stdout && buf && bufsize > 0)
      {
      buf[0] = '\0' ;
      stdOut().getline(buf,bufsize) ;
      return true ;
      }
   else
      return false ;
}

//----------------------------------------------------------------------

FrObject *MEMTEngine::readObject()
{
   if (isRunning())
      {
      FrObject *obj ;
      stdOut() >> obj ;
      return obj ;
      }
   else
      return 0 ;
}

//----------------------------------------------------------------------

void MEMTEngine::monitorPipeIO(bool enable)
{
   if (enable)
      {
      current_program = &m_running ;
      current_stream = engine_stdin ;
      current_process_name = engineName() ;
      }
   else
      {
      current_program = 0 ;
      current_stream = 0 ;
      current_process_name = 0 ;
      }
   return ;
}

//----------------------------------------------------------------------

bool MEMTEngine::execProgram(ostream &err, const char *remote_exec_string,
			       const char *hostname, int socket,
			       const char *network_flag,
			       const char *program_name, ...)
{
   FrVarArgs(program_name) ; 
   m_running = FrExecProgram(remote_exec_string,hostname,socket,
			     network_flag,engine_pipe_in,engine_pipe_out,
			     engine_stdout,engine_stdin,err,program_name,
			     args) ;
   FrVarArgEnd() ;
   if (isRunning())
      m_remote = true ;
   return isRunning() ;
}

//----------------------------------------------------------------------

bool MEMTEngine::startEngine(const PLConfig *config, ostream &err,
			     bool run_verbosely)
{
   const PlEngineConfig *engcfg = PlFindEngineConfig(config,engineTag()) ;
   if (engcfg)
      {
      enableEngine(engcfg->isEnabled()) ;
      allowUpdates(engcfg->isUpdateable()) ;
      startWhileDisabled(engcfg->forceStart()) ;
      }
   else
      {
      disableEngine() ;
      startWhileDisabled(false) ;
      }
   if (!engineEnabled() && !start_even_if_disabled)
      {
      if (run_verbosely)
	 err << "; [skipping " << engineName() << " because it is disabled]"
	     << endl ;
      return true ;
      }
   if (start_fn && engcfg)
      {
      if (run_verbosely)
	 err << "; [starting " << engineName() << ']' << endl ;
      bool success = start_fn(this,config,engcfg,err,run_verbosely) ;
      if (success)
	 m_running = true ;
      else
	 {
	 err << "; error while starting " << engineName()
	     << "; engine will be unavailable" << endl ;
	 disableEngine() ;
	 }
      return success ;
      }
   else
      {
      if (run_verbosely)
	 {
	 err << "; unable to start " << engineName()
	     << " because no " ;
	 if (!start_fn)
	    err << "startup function was defined" << endl ;
	 else
	    err << "engine configuration was given" << endl ;
	 }
      return false ;			// could not start!
      }
}

//----------------------------------------------------------------------

bool MEMTEngine::copyConnection(MEMTEngine &other_engine)
{
   if (&other_engine == this || other_engine.usingDataFile())
      return false ;
   if (!other_engine.sharedConnection() && other_engine.isRunning())
      {
      if (other_engine.isRemote())
	 {
	 engine_stdin = other_engine.engine_stdin ;
	 engine_stdout = other_engine.engine_stdout ;
	 engine_pipe_in = other_engine.engine_pipe_in ;
	 engine_pipe_out = other_engine.engine_pipe_out ;
	 m_remote = true ;
	 }
      m_running = true ;
      shared_connection = &other_engine ;
      other_engine.shared_connection = this ;
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

bool MEMTEngine::awaitReadiness(ostream &err, bool run_verbosely)
{
   if (isRunning())
      {
      if (isRemote() && !usingDataFile())
	 {
	 if (run_verbosely)
	    err << ";[waiting for " << engineName() << " to finish loading]"
		<< endl ;
	 FrObject *result = 0 ;
	 stdOut() >> result ;
	 if (result && result->symbolp() && result == makeSymbol("STTY:"))
	    {
	    stdOut().ignore(200,'\n') ; // skip stty: error message
	    stdOut() >> result ;  // get engine's reply
	    }
	 if (result && result->symbolp() && result == makeSymbol("READY!"))
	    {
	    stdOut().ignore(128,'\n') ;
            //!!! some future engine might require more work here, but
	    //   currently we can get away with just this
	    if (run_verbosely)
	       err << "; " << engineName() << " ready" << endl ;
	    }
	 else
	    {
	    err << "; " << engineName() << " reported error on loading: "
		<< result << endl ;
	    disableEngine() ;
	    initiateShutdown(err,run_verbosely) ;
	    }
	 free_object(result) ;
	 }
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

bool MEMTEngine::prepareToTranslate(const FrTextSpans *input,
				    FrTextSpans *lattice,
				    ostream &err, bool run_verbosely)
{
   bool did_work = false ;
   if (isRunning() && engineEnabled() && !usingDataFile() && translate_fn)
      {
      if (run_verbosely)
	 err << "; priming " << engineName() << flush ;
      FrTimer *timer = 0 ;
      if (run_verbosely && !isRemote())
	 timer = new FrTimer ;
      monitorPipeIO(true) ;
      did_work = translate_fn(this,true,input,lattice,err) ;
      monitorPipeIO(false) ;
      (void)stillAlive(err) ;
      if (timer && did_work)
	 {
	 err << " (" << timer->readsec()*1000.0 << " ms)\n" ;
	 }
      delete timer ;
      }
   return did_work ;
}

//----------------------------------------------------------------------

bool MEMTEngine::finishTranslation(const FrTextSpans *input,
				     FrTextSpans *lattice,
				     ostream &err, bool gc,
				     bool run_verbosely)
{
   bool have_translations = false ;
   if (isRunning() && engineEnabled() && translate_fn)
      {
      if (run_verbosely)
	 err << "; finishing " << engineName() << flush ;
      FrTimer *timer = 0 ;
      if (run_verbosely && !isRemote())
	 timer = new FrTimer ;
      monitorPipeIO(true) ;
      have_translations = translate_fn(this,false,input,lattice,err) ;
      monitorPipeIO(false) ;
      (void)stillAlive(err) ;
      if (timer)
	 {
	 err << " (" << timer->readsec()*1000.0 << " ms)\n" ;
	 delete timer ;
	 }
      if (gc && !isRemote())
	 FramepaC_gc() ;
      }
   return have_translations ;
}

//----------------------------------------------------------------------

bool MEMTEngine::translateSentence(const FrTextSpans *input,
				   FrTextSpans *lattice,
				   ostream &err, bool gc,
				   bool run_verbosely)
{
   bool have_translations = false ;
   if (isRunning() && engineEnabled() && translate_fn)
      {
      if (run_verbosely)
	 err << "; running " << engineName() << flush ;
      FrTimer *timer = 0 ;
      if (run_verbosely && !isRemote())
	 timer = new FrTimer ;
      monitorPipeIO(true) ;
      // run start-translation command
      (void)translate_fn(this,true,input,lattice,err) ;
      // run finish-translation command
      have_translations = translate_fn(this,false,input,lattice,err) ;
      monitorPipeIO(false) ;
      (void)stillAlive(err) ;
      if (timer)
	 {
	 err << " (" << timer->readsec()*1000.0 << " ms)\n" ;
	 delete timer ;
	 }
      if (gc && !isRemote())
	 FramepaC_gc() ;
      }
   return have_translations ;
}

//----------------------------------------------------------------------

bool MEMTEngine::startEngine(const PLConfig *config,
			       const PlEngineConfig *engcfg,
			       const char *network_flag, const char *extra_arg,
			       ostream &err, bool /*run_verbosely*/)
{
   if (!config || !engcfg)
      return false ;
   const char *cfg = engcfg->cfg() ;
   if (!cfg)
      cfg = "." ;
   if (engcfg->isDataFile())
      {
      m_filename = FrDupString(engcfg->cfg()) ;
      if (m_filename && *m_filename)
	 {
	 m_stream = new ifstream(m_filename) ;
	 m_remote = (m_stream && m_stream->good()) ;
	 return m_remote ;
	 }
      return false ;
      }
   else
      {
      bool run_remotely = (config->remote_exec != 0 && engcfg->host() != 0 &&
			     engcfg->isRemote()) ;
      return execProgram(err,run_remotely ? config->remote_exec : 0,
			 engcfg->host(), engcfg->socket(),
			 network_flag, engcfg->prog(), cfg, extra_arg,
			 (void*)0) ;
      }
}

//----------------------------------------------------------------------

bool MEMTEngine::translate(bool prepare, const FrTextSpans *input,
			   FrTextSpans *lattice, const char *xlat_cmd)
{
   if (prepping_doc)
      return true ;			// trivially successful, nothing to do
   if (prepare)
      {
      if (usingDataFile())
	 return m_stream && !m_stream->eof() ;
      FrList *wordlist = input->printable() ;
      char *wl_string = wordlist->print() ;
      free_object(wordlist) ;
      sendLine(xlat_cmd,wl_string) ;
      FrFree(wl_string) ;
      return isRunning() ;
      }
   FrObject *result = readObject() ;
   if (result && result->consp() && lattice)
      return insertArcs(lattice,(FrList*)result);
   else
      free_object(result) ;
   return false ;
}

//----------------------------------------------------------------------

FrString *MEMTEngine::transform(const FrString *sentence, ostream &err,
				bool run_verbosely)
{
   if (isRunning() && engineEnabled() && sentence && transform_fn)
      {
      FrList *wordlist = 0 ;
      if (sentence && sentence->stringLength() > 0)
	 {
	 if (sentence->charWidth() == 1)
	    wordlist = FrCvtSentence2Wordlist((char*)sentence->stringValue());
	 else
	    wordlist =FrCvtUString2Wordlist((FrChar16*)sentence->stringValue(),
					     sentence->stringLength()) ;
	 }
      if (wordlist)
	 {
	 FrTimer *timer = 0 ;
	 if (run_verbosely)
	    {
	    err << "; applying transformation by " << engineName() << flush ;
	    timer = new FrTimer ;
	    }
	 monitorPipeIO(true) ;
	 FrObject *result = transform_fn(this,wordlist) ;
	 monitorPipeIO(false) ;
	 if (run_verbosely)
	    {
	    if (timer)
	       {
	       err << " (" << timer->readsec()*1000.0 << " ms)" ;
	       delete timer ; 
	       }
	    err << endl ;
	    }
	 if (stillAlive(err) && result)
	    {
	    FrString *transform = 0 ;
	    if (result->consp())
	       transform = new FrString((FrList*)result,char_encoding) ;
	    else if (result->stringp())
	       transform = (FrString*)result->deepcopy() ;
	    free_object(result) ;
	    free_object(wordlist) ; wordlist = 0 ;
	    if (transform)
	       return transform ;
	    }
	 else
	    free_object(result) ;
	 free_object(wordlist) ;
	 }
      }
   return sentence ? (FrString*)sentence->deepcopy() : 0 ;
}

//----------------------------------------------------------------------

bool MEMTEngine::addTranslation(const FrString *src, const FrString *trg,
				  const FrString *meta, ostream &out)
{
   if (isRunning() && updatesAllowed() && !usingDataFile() && addxlat_fn)
      {
      monitorPipeIO(true) ;
      bool updated = addxlat_fn(this,src,trg,meta) ;
      monitorPipeIO(false) ;
      if (!isRunning())
	 engineDied(out) ;
      else if (updated)
	 out << engineName() << " updated.  " << flush ;
      else
	 out << "Error updating " << engineName() << "!  " << flush ;
      return true ;
      }
   else
      {
      // output an appropriate error message
      out << "; can not update " << engineName() << " because " ;
      if (usingDataFile())
	 out << "results are read from a file" << endl ;
      else if (!isRunning())
	 out << "it is not running" << endl ;
      else if (!updatesAllowed())
	 out << "updates are not allowed" << endl ;
      else
	 out << "no update function was defined" << endl ;
      }
   return false ;
}

//----------------------------------------------------------------------

bool MEMTEngine::sendLine(const char *keyword, const char *value)
{
   if (isRemote() && !usingDataFile())
      {
      stdIn() << keyword ;
      if (value)
	 stdIn() << " " << value ;
      stdIn() << endl << flush ;
      }
   return true ;
}

//----------------------------------------------------------------------

char *MEMTEngine::sendCommand(const char *command, ostream &err,
			      bool run_verbosely)
{
   if (!command || !*command)
      {
      return Fr_aprintf("Error: Did not specify a command to be sent to "
			"engine %s%c",
			engineName(),'\0') ;
      }
   if (!command_fn)
      {
      return Fr_aprintf("Engine %s does not support private commands%c",
			engineName(),'\0') ;
      }
   else if (command_fn == MEMTEng_DEFCMDFUNC)
      return sendRemoteCommand(command) ;
   if (run_verbosely)
      err << "; sending command to engine " << engineName() << endl ;
   char *result = command_fn(this,command) ;
   if (run_verbosely)
      err << "; command sent " << (result?"":"un") << "successfully" << endl ;
   return result ;
}

//----------------------------------------------------------------------

char *MEMTEngine::sendRemoteCommand(const char *command)
{
   if (!isRemote() || usingDataFile())
      return 0 ;
   sendLine(command) ;
   char *result = 0 ;
   size_t length = 0 ;
   char buf[FrMAX_LINE] ;
   do {
      if (!readLine(buf,sizeof(buf)))
	 break ;
      size_t len = strlen(buf) ;
      char *new_res = FrNewR(char,result,length+len+1) ;
      if (new_res)
	 {
	 result = new_res ;
	 memcpy(result + length, buf, len + 1) ;
	 length += len ;
	 }
      } while (buf[0] && buf[0] != '\n') ;
   return result ;
}

//----------------------------------------------------------------------

bool MEMTEngine::selectKB(const char *KBname)
{
   if (isRunning())
      {
      if (selectKB_fn)
	 return selectKB_fn(this,KBname) ;
      else
	 return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

bool MEMTEngine::selectGenre(const char *genre_name)
{
   if (isRunning())
      return selectGenre_fn ? selectGenre_fn(this,genre_name) : true ;
   return false ;
}

//----------------------------------------------------------------------

bool MEMTEngine::prepareDoc(bool starting, ostream &err,
			      bool run_verbosely)
{
   if (isRunning())
      {
      if (prepping_doc == starting)
	 return false ;
      if (run_verbosely)
	 {
	 if (starting)
	    err << "; start" ;
	 else
	    err << "; done" ;
	 err << " prep " << engineName() << flush ;
	 }
      prepping_doc = starting ;
      if (prepDoc_fn && !usingDataFile())
	 return prepDoc_fn(this,starting) ;
      }
   return true ;			// trivially successful
}

//----------------------------------------------------------------------

bool MEMTEngine::initiateShutdown(ostream &err, bool run_verbosely)
{
   bool success = true ;
   if (isRunning())
      {
      if (run_verbosely)
	 err << "; shutting down " << engineName() << endl ;
      monitorPipeIO(true) ;
      if (shutdown_fn)
	 success = shutdown_fn(this) ;
      monitorPipeIO(false) ;
      if (!success && run_verbosely)
	 err << "; *** error reported on shutdown ***" << endl ;
      if (sharedConnection())
	 {
	 shared_connection->m_running = false ;
	 shared_connection->shared_connection = 0 ;
	 shared_connection->engine_stdin = 0 ;
	 shared_connection->engine_stdout = 0 ;
	 }
      }
   return success ;
}

//----------------------------------------------------------------------

bool MEMTEngine::finishShutdown()
{
   if (usingDataFile())
      {
      delete m_stream ;
      m_stream = 0 ;
      m_remote = false ;
      }
   else if (isRemote())
      {
      monitorPipeIO(true) ;
      // get any remaining output from the engine still pending on the pipe
#if FIXME
      while (isRunning() && inputAvailable() && !stdOut().eof() &&
	     !stdOut().fail())
	 {
	 stdOut().get() ;
	 }
#endif
      m_running = false ;
      m_remote = false ;
      FrShutdownPipe(engine_stdout,engine_stdin,
		     engine_pipe_in,engine_pipe_out) ;
      monitorPipeIO(false) ;
      }
   else
      {
      m_running = false ;
      }
   return true ;
}

//----------------------------------------------------------------------

bool MEMTEngine::insertArc(FrTextSpans *lattice, const FrList *arc)
{
   if (lattice)
      {
      FrTextSpan *new_span = lattice->newSpan(arc) ;
      if (new_span)
	 {
	 new_span->setMetaData(FrSymbolTable::add("ENGINE"),engineTag()) ;
	 return true ;
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

bool MEMTEngine::insertArcs(FrTextSpans *lattice, FrList *arcs)
{
   bool added = false ;
   while (arcs)
      {
      FrList *arc = (FrList*)poplist(arcs) ;
      if (arc && arc->structp())
	 lattice->addMetaData((FrStruct*)arc) ;
      else if (arc && arc->stringp())
	 {
	 // ignore this item, we don't need to know the input text
	 }
      else if (insertArc(lattice,arc))
	 added = true ;
      free_object(arc) ;
      }
   return added ;
}

//----------------------------------------------------------------------

void MEMTEngine::enableEngine(bool ena)
{
   if (setup_complete)
      {
      if (ena)
	 {
	 if (!isRunning())
	    {
//!!! startEngine(...) ;
	    }
//         if (isRunning())
	    m_disabled = false ;
	 }
      else 
	 m_disabled = true ;
      }
   else
      m_disabled = !ena ;
   return ;
}

//----------------------------------------------------------------------

static bool disable_engine(MEMTEngine *eng, va_list)
{
   eng->disableEngine() ;
   return true ;
}

//----------------------------------------------------------------------

void MEMTEngine::disableAllEngines()
{
   EngineList::iterate(ET_Xlat,FrComp_DontCare,disable_engine,0) ;
   return ;
}

//----------------------------------------------------------------------

static bool disallow_updates(MEMTEngine *eng, va_list)
{
   eng->disallowUpdates() ;
   return true ;
}

//----------------------------------------------------------------------

void MEMTEngine::disallowUpdatesAllEngines()
{
   EngineList::iterate(ET_Xlat,FrComp_Equal,disallow_updates,0) ;
   return ;
}

//----------------------------------------------------------------------

static bool start_engine(MEMTEngine *eng, va_list args)
{
   FrVarArg(const PLConfig*,config) ;
   FrVarArg(ostream*,err) ;
   FrVarArg2(bool,int,verbosely) ;
   FrVarArg(bool*,success) ;
   if (eng->startEngine(config,*err,verbosely))
      *success = true ;
   return true ;
}

//----------------------------------------------------------------------

bool MEMTEngine::startAllEngines(const PLConfig *config, ostream &err,
				   bool verbosely)
{
   bool success = false ;
   EngineList::iterate(ET_Xlat,FrComp_DontCare,start_engine,config,&err,
		       verbosely,&success) ;
   return success ;	// is at least one engine available?
}

//----------------------------------------------------------------------

static bool await_readiness(MEMTEngine *eng, va_list args)
{
   FrVarArg(ostream*,err) ;
   FrVarArg2(bool,int,verbosely) ;
   FrVarArg(bool*,success) ;
   if (eng->isRunning() && !eng->awaitReadiness(*err,verbosely))
      *success = false ;
   return true ;
}

//----------------------------------------------------------------------

bool MEMTEngine::awaitReadinessAllEngines(ostream &err, bool verbosely)
{
   bool success = true ;
   EngineList::iterate(ET_Xlat,FrComp_DontCare,await_readiness,&err,
		       verbosely,&success) ;
   return success ;	// did all running engines start OK?
}

//----------------------------------------------------------------------

static bool select_genre(MEMTEngine *eng, va_list args)
{
   FrVarArg(const char*,genre) ;
   FrVarArg(bool*,success) ;
   if (!eng->selectGenre(genre) && eng->isRunning())
      *success = false ;
   return true ;
}

//----------------------------------------------------------------------

bool MEMTEngine::selectGenreAll(const char *genre)
{
   bool success = true ;
   EngineList::iterate(ET_Xlat,FrComp_DontCare,select_genre,genre,&success) ;
   return success ;
}

//----------------------------------------------------------------------

static bool prepare_to_translate(MEMTEngine *eng, va_list args)
{
   FrVarArg(const FrTextSpans*,input) ;
   FrVarArg(FrTextSpans*,lattice) ;
   FrVarArg(ostream*,err) ;
   FrVarArg2(bool,int,run_verbosely) ;
   (void)eng->prepareToTranslate(input,lattice,*err,run_verbosely) ;
   return true ;
}

//----------------------------------------------------------------------

static bool finish_translation(MEMTEngine *eng, va_list args)
{
   FrVarArg(const FrTextSpans*,input) ;
   FrVarArg(FrTextSpans*,lattice) ;
   FrVarArg(ostream*,err) ;
   FrVarArg2(bool,int,gc) ;
   FrVarArg2(bool,int,run_verbosely) ;
   FrVarArg(bool*,have_translation) ;
   if (eng->finishTranslation(input,lattice,*err,gc,run_verbosely))
      *have_translation = true ;
   return true ;
}

//----------------------------------------------------------------------

bool MEMTEngine::translate(const FrTextSpans *input, FrTextSpans *lattice,
			   ostream &err, bool gc, bool run_verbosely)
{
   EngineList::iterate(ET_Xlat,FrComp_Equal,prepare_to_translate,
		       input,lattice,&err,run_verbosely) ;
   bool have_translation = false ;
   EngineList::iterate(ET_Xlat,FrComp_Equal,finish_translation,
		       input,lattice,&err,gc,run_verbosely,
		       &have_translation) ;
   return have_translation ;
}

//----------------------------------------------------------------------

static bool init_shutdown(MEMTEngine *eng, va_list args)
{
   FrVarArg(ostream*,err) ;
   FrVarArg2(bool,int,verbosely) ;
   eng->initiateShutdown(*err,verbosely) ;
   return true ;
}

//----------------------------------------------------------------------

static bool finish_shutdown(MEMTEngine *eng, va_list)
{
   eng->finishShutdown() ;
   return true ;
}

//----------------------------------------------------------------------

void MEMTEngine::shutdownAllEngines(ostream &err, bool verbosely)
{
   EngineList::iterate(ET_Xlat,FrComp_DontCare,init_shutdown,&err,verbosely);
   EngineList::iterate(ET_Xlat,FrComp_DontCare,finish_shutdown,0) ;
   return ;
}

//----------------------------------------------------------------------

// end of file plengine.cpp //
