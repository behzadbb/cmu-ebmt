/************************************************************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.95							*/
/*	 by Ralf Brown							*/
/*									*/
/*  File plbleu.cpp		BLEU/NIST scoring metrics		*/
/*  LastEdit: 29mar10							*/
/*									*/
/*  (c) Copyright 2002,2003,2010 Ralf Brown				*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "plbleu.h"
#include "plglobal.h"

#ifdef FrSTRICT_CPLUSPLUS
# include <cmath>
# include <iomanip>
#else
# include <math.h>
# include <iomanip.h>
#endif /* FrSTRICT_CPLUSPLUS */

#define BLEU_SMOOTH 0.5

/************************************************************************/
/*	Types for this Module						*/
/************************************************************************/

class PlNgramCount
   {
   private:
      static FrAllocator allocator ;
      PlNgramCount *m_next ;
      PlNgramCount *m_alt ;
      FrSymbol *m_word ;
      size_t m_count ;
      size_t m_prevcount ;
   public:
      void *operator new(size_t) { return allocator.allocate() ; }
      void operator delete(void *blk) { allocator.release(blk) ; }
      PlNgramCount(FrSymbol *w, size_t cnt = 1, PlNgramCount *nxt = 0)
         { m_next = nxt ; m_alt = 0 ; m_word = w ; m_count = cnt ;
	   m_prevcount = 0 ; }
      ~PlNgramCount()
         { if (m_next) delete m_next ; m_next = 0 ; 
	   if (m_alt) delete m_alt ; m_alt = 0 ; }

      // accessors
      PlNgramCount *next() { return m_next ; }
      const PlNgramCount *next() const { return m_next ; }
      PlNgramCount *nextAlternative() { return m_alt ; }
      const PlNgramCount *nextAlternative() const { return m_alt ; }
      FrSymbol *word() const { return m_word ; }
      size_t count() const { return m_count ; }
      size_t prevCount() const { return m_prevcount ; }
      void computeCoverages(size_t *covers) const ;

      // modifiers
      void setCount(size_t cnt) { m_count = cnt ; }
      void incrCount(size_t cnt = 1) { m_count += cnt ; }
      void insertNGram(const FrList *ngram) ;
      void insertNGram(const FrList *ngram, const PlNgramCount *ref) ;

      void copyCounts() ;
      void mergeCounts() ;
      void limitCounts(const PlNgramCount *ref_counts) ;
      void setNext(PlNgramCount *nxt) { m_next = nxt ; }

      // I/O
      void dump(size_t level) const ;
   } ;

/************************************************************************/
/*	Global Variables						*/
/************************************************************************/

FrAllocator PlNgramCount::allocator("PlNgramCount",sizeof(PlNgramCount)) ;

/************************************************************************/
/*	Methods for class PlNgramCount					*/
/************************************************************************/

void PlNgramCount::insertNGram(const FrList *ngram)
{
   if (!ngram)
      return ;
   const FrObject *w = ngram->first() ;
   const FrList *tail = ngram->rest() ;
   for (PlNgramCount *ngc = this ; ngc ; ngc = ngc->nextAlternative())
      {
      if (ngc->word() == w)
	 {
	 ngc->incrCount() ;
	 if (tail)
	    {
	    if (!ngc->next())
	       ngc->setNext(new PlNgramCount(FrCvt2Symbol(tail->first()),0)) ;
	    ngc->next()->insertNGram(tail) ;
	    }
	 break ;
	 }
      else if (!ngc->nextAlternative())
	 {
	 ngc->m_alt = new PlNgramCount(FrCvt2Symbol(w),1) ;
	 ngc = ngc->nextAlternative() ;
	 if (tail)
	    {
	    ngc->setNext(new PlNgramCount(FrCvt2Symbol(tail->first()),0)) ;
	    ngc->next()->insertNGram(tail) ;
	    }
	 break ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void PlNgramCount::copyCounts()
{
   // remember the current maximum n-gram count values and reset the counts
   m_prevcount = m_count ;
   m_count = 0 ;
   if (next())
      next()->copyCounts() ;
   if (nextAlternative())
      nextAlternative()->copyCounts() ;
   return ;
}

//----------------------------------------------------------------------

void PlNgramCount::mergeCounts()
{
   // the system output is allowed to use each n-gram at most the maximum
   //   number of times it appears in any one reference translation for the
   //   sentence, so use the maximum of the current translation's counts and
   //   the maximum of all previous translations' counts
   if (m_prevcount > m_count)
      m_count = m_prevcount ;
   if (next())
      next()->mergeCounts() ;
   if (nextAlternative())
      nextAlternative()->mergeCounts() ;
   return ;
}

//----------------------------------------------------------------------

void PlNgramCount::limitCounts(const PlNgramCount *ref_counts)
{
   if (!ref_counts)
      return ;
   for (PlNgramCount *ngc1 = this ; ngc1 ; ngc1 = ngc1->nextAlternative())
      {
      const PlNgramCount *ngc2 = ref_counts ;
      size_t ref_count = 0 ;
      for ( ; ngc2 ; ngc2 = ngc2->nextAlternative())
	 {
	 if (ngc2->word() == ngc1->word())
	    {
	    ref_count = ngc2->count() ;
	    break ;
	    }
	 }
      PlNgramCount *nxt = ngc1->next() ;
      if (ref_count < ngc1->count())
	 ngc1->setCount(ref_count) ;
      if (nxt)
	 {
	 if (ngc2 && ngc2->next())
	    nxt->limitCounts(ngc2->next()) ;
	 else
	    {
	    // there aren't any longer ngrams starting with the current
	    //   prefix in the reference counts, so zap all continuations
	    delete nxt ;
	    ngc1->setNext(0) ;
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void PlNgramCount::computeCoverages(size_t *covers) const
{
   *covers += count() ;
   for (const PlNgramCount *a = m_alt ; a ; a = a->nextAlternative())
      {
      *covers += a->count() ;
      if (a->next())
	 a->next()->computeCoverages(covers+1) ;
      }
   return ;
}

//----------------------------------------------------------------------

void PlNgramCount::dump(size_t level) const
{
   for (const PlNgramCount *ngc = this ; ngc ; ngc = ngc->nextAlternative())
      {
      if (ngc->word() == 0)
	 continue ;
      if (level > 0)
	 cout << setw(3 * level) << " " ;
      cout << "+-- " << ngc->word() << " = " << ngc->m_count << "/"
	   << ngc->m_prevcount << endl ;
      if (ngc->next())
	 ngc->next()->dump(level+1) ;
      }
   return ;
}

/************************************************************************/
/*	Methods for class PlLangModel					*/
/************************************************************************/

PlLangModel::PlLangModel(const FrList *sentences, size_t maxN)
{ 
   init() ;
   insertSentences(sentences,maxN) ;
   return ;
}

//----------------------------------------------------------------------

void PlLangModel::init()
{ 
   ngrams = new PlNgramCount(0,0) ; 
   min_sent_len = max_sent_len = 0 ;
   max_ngram_len = 1 ;
   return ;
}

//----------------------------------------------------------------------

PlLangModel::~PlLangModel()
{
   delete ngrams ; ngrams = 0 ; 
   min_sent_len = max_sent_len = 0 ;
   return ; 
}

//----------------------------------------------------------------------

void PlLangModel::limitCounts(const PlLangModel *ref_lm)
{
   ngrams->limitCounts(ref_lm->ngrams) ;
   return ;
}

//----------------------------------------------------------------------

void PlLangModel::insertNGrams(const FrList *sentence, size_t maxN)
{
   if (maxN == 0)
      return ;
   if (maxN > max_ngram_len)
      max_ngram_len = maxN ;
   size_t len = sentence->listlength() ;
   if (maxN > len)
      maxN = len ;
   ngrams->copyCounts() ; 
   for (size_t i = 0 ; i < len ; i++)
      {
      FrList *ngram = (FrList*)sentence->subseq(i,i+maxN-1) ;
      ngrams->insertNGram(ngram) ; 
      free_object(ngram) ;
      }
   ngrams->mergeCounts() ; 
   return ;
}

//----------------------------------------------------------------------

void PlLangModel::insertSentences(const FrList *sentences, size_t maxN)
{
   if (maxN == 0 || !sentences)
      return ;
   if (max_sent_len == 0)
      min_sent_len = ~0 ;
   for ( ; sentences ; sentences = sentences->rest())
      {
      FrString *sentence = (FrString*)sentences->first() ;
      if (sentence && sentence->stringp())
	 {
	 const char *sent = (char*)sentence->stringValue() ;
	 FrList *words = FrCvtString2Symbollist(sent,char_encoding) ;
	 size_t sent_len = words->simplelistlength() ;
	 if (sent_len < min_sent_len)
	    min_sent_len = sent_len ;
	 if (sent_len > max_sent_len)
	    max_sent_len = sent_len ;
	 size_t max_N = maxN ;
	 if (sent_len < max_N)
	    max_N = sent_len ;
	 if (max_N > max_ngram_len)
	    max_ngram_len = max_N ;
	 insertNGrams(words,max_N) ;
	 free_object(words) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

double PlLangModel::computeBLEU(const PlLangModel *refs, bool arith_mean)
{
   FrLocalAllocC(size_t,coverages,100,refs->maxNGramLen()) ;
   double score = 0.0 ;
   if (coverages)
      {
      if (!arith_mean)
	 score = 1.0 ;
      limitCounts(refs) ;
      ngrams->computeCoverages(coverages) ;
      for (size_t len = 1 ; len <= refs->maxNGramLen() ; len++)
	 {
	 size_t hyplen = avgSentenceLength() ;
	 if (hyplen < len)
	    hyplen = 1 ;
	 else
	    hyplen -= (len - 1) ;
	 if (arith_mean)
	    {
	    double cover = coverages[len-1] / (double)hyplen ;
	    score += cover ;
	    }
	 else
	    {
	    // since single sentences will frequently not have any
	    //   long matches, apply smoothing by incrementing both
	    //   numerator and denominator for phrases
	    double cover ;
	    if (len > 1)
	       cover = ((coverages[len-1] + BLEU_SMOOTH)
			/ (hyplen + BLEU_SMOOTH)) ;
	    else
	       cover = coverages[len-1] / (double)hyplen ;
	    score *= cover ;
	    }
	 }
      if (arith_mean)
	 score /= refs->maxNGramLen() ;
      else
	 score = ::pow(score, 1.0 / refs->maxNGramLen()) ;
      FrLocalFree(coverages) ;
      }
   return score * refs->brevityPenalty(avgSentenceLength()) ;
}

//----------------------------------------------------------------------

double PlLangModel::brevityPenalty(size_t hyp_len) const
{
   size_t len = avgSentenceLength() ;
   if (hyp_len > len)
      {
      // give a bit of a bonus for long outputs to counteract the tendency
      //   of sentence-level BLEU to push for short translations
      double lambda = len >= 5 ? 0.25 / len : 0.05 ;
      return lambda * (hyp_len / (double)len) + (1.0 - lambda) ;
//      return 1.0 ;
      }
   else
      {
      // because sentence-level BLEU has a substantial bias toward
      //   shorter outputs, slightly sharpen the brevity penalty
      //   compared to the standard BLEU formula
      return ::exp(1.1 * (1.0 - len / (double)hyp_len)) ;
      }
}

//----------------------------------------------------------------------

void PlLangModel::dump() const
{
   if (ngrams)
      ngrams->dump(0) ;
   return ;
}

// end of file plbleu.cpp //
