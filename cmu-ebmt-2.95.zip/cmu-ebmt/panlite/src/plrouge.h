/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.95							*/
/*	 by Ralf Brown							*/
/*									*/
/*  File plrouge.h		ROUGE scoring metrics			*/
/*  LastEdit: 28mar10							*/
/*									*/
/*  (c) Copyright 2010 Ralf Brown					*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __PLROUGE_H_INCLUDED
#define __PLROUGE_H_INCLUDED

#include "FramepaC.h"

/************************************************************************/
/************************************************************************/

class PlRougeS
   {
   private:
      FrHashTable **m_bigrams ;
      size_t	   *m_reflen ;
      size_t	    m_numrefs ;
      size_t 	    m_maxskip ;
   protected:
      static FrHashTable *makeSkipBigrams(const FrObject *sentence,
					  size_t maxskip,
					  size_t &sentlen) ;
      static double score(FrHashTable *hyp_ht, size_t hyp_len,
			  const FrHashTable *ref_ht, size_t ref_len,
			  size_t max_skip) ;
   public:
      PlRougeS(const FrList *sentences, size_t max_skip = 4) ;
      ~PlRougeS() ;

      size_t numReferences() const { return m_numrefs ; }
      size_t referenceLength(size_t N) const ;
      size_t maxSkip() const { return m_maxskip ; }
      double score(const FrObject *sentence) const ;
   } ;

#endif /* !__PLROUGE_H_INCLUDED */

// end of file plrouge.h //
