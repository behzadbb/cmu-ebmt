/************************************************************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File pllm.cpp		language-model interface functions	*/
/*  LastEdit: 01apr10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifdef LINK_ALL
#define LINK_LM
#endif /* LINK_ALL */

#ifdef LINK_LM
#include "lmodel.h"
#endif /* LINK_LM */

#include "plchart.h"
#include "plengine.h"
#include "plproc.h"
#include "plutil.h"
#include "panlite.h"
#include "plglobal.h"

/************************************************************************/
/*	Forward and External Declarations				*/
/************************************************************************/

static bool exec_LM(MEMTEngine *engine, const PLConfig *config,
		      const PlEngineConfig *engcfg,
		      ostream &err, bool run_verbosely) ;
static bool find_best_walk(MEMTEngine *engine, bool prepare,
			     const FrTextSpans * /*input*/,
			     FrTextSpans *lattice, ostream &err) ;
static FrObject *transform_LM_sentence(MEMTEngine *engine,
				       const FrList *wordlist) ;
static char *send_LM_command(MEMTEngine *engine, const char *command) ;
static bool prepare_LM_document(MEMTEngine *engine, bool starting) ;
static bool start_LM_shutdown(MEMTEngine *engine) ;
static bool select_LM_genre(MEMTEngine *engine, const char *genre_name) ;

/************************************************************************/
/*    Global variables for this module				       	*/
/************************************************************************/

MEMTEngine lm_engine("Language Modeler",":LM",ET_Decode,exec_LM,find_best_walk,
		     start_LM_shutdown,0,0,transform_LM_sentence,
		     send_LM_command,select_LM_genre,prepare_LM_document) ;

extern MEMTEngine postproc_engine ;

/************************************************************************/
/*    Functions for interfacing with LM					*/
/************************************************************************/

static FrString *extract_chart_walk(const FrTextSpans *lattice)
{
   FrSymbol *symLM = FrSymbolTable::add(":LM") ;
   FrSymbol *symENGINE = FrSymbolTable::add("ENGINE") ;
   FrTextSpans *walkspans = new FrTextSpans(lattice) ;
   for (size_t i = 0 ; i < lattice->spanCount() ; i++)
      {
      const FrTextSpan *span = lattice->getSpan(i) ;
      if (span && span->getMetaData(symENGINE) == symLM)
	 walkspans->addSpan(span) ;
      }
   walkspans->sort() ;
   FrList *walk = 0 ;
   for (size_t i = 0 ; i < walkspans->spanCount() ; i++)
      {
      const FrTextSpan *span = walkspans->getSpan(i) ;
      char *text = span->getText() ;
      if (text)
	 {
	 pushlist(new FrString(text),walk) ;
	 FrFree(text) ;
	 }
      }
   delete walkspans ;
   walk = listreverse(walk) ;
   FrString *chartwalk = walk ? new FrString(walk,char_encoding) : 0 ;
   free_object(walk) ;
   return chartwalk ;
}

//----------------------------------------------------------------------

static size_t count_words(const char *str)
{
   size_t count = 0 ;
   if (str)
      {
      count = 1 ;
      while (str && *str)
	 {
	 if (Fr_isspace(*str))
	    count++ ;
	 str++ ;
	 }
      }
   return count ;
}

//----------------------------------------------------------------------

static void extract_alignments(const FrList *align, size_t /*start*/,
			       size_t /*len*/,
			       size_t targetpos, size_t trgwords,
			       FrList *&alignments)
{
   FrList *alignment = 0 ;
   FrSymbol *symComma = makeSymbol(",") ;
   size_t alignlen = align->simplelistlength() ;
   if (alignlen > trgwords)
      {
      // this arc overlapped the previous one, so the initial alignment
      //   values in the list aren't actually used
      align = align->nthcdr(alignlen - trgwords) ;
      }
   FrLocalAlloc(bool,used,1024,alignlen+1) ;
   if (!used)
      return ;
   for (size_t i = 0 ; align ; align = align->rest(), i++)
      {
      if (used[i])
	 continue ;
      const FrObject *al = align->first() ;
      if (!al)
	 continue ;
      FrList *target = new FrList(new FrInteger(targetpos+i)) ;
      size_t j = i+1 ;
      for (const FrList *algn = align->rest() ; algn ; algn=algn->rest(), j++)
	 {
	 const FrObject *al2 = algn->first() ;
	 if (!al2)
	    continue ;
	 if (::equal(al,al2))
	    {
	    used[j] = true ;
	    pushlist(new FrInteger(targetpos+j),target) ;
	    }
	 }
      target = listreverse(target) ;
      pushlist(symComma,target) ;
      FrList *source = 0 ;
      if (al->numberp())
	 {
	 source = new FrList(new FrInteger(al->intValue()+1)) ;
	 }
      else if (al->consp())
	 {
	 for (FrList *algn = (FrList*)al ; algn ; algn = algn->rest())
	    {
	    FrObject *val = algn->first() ;
	    if (val && val->numberp() /* &&
		val->intValue() >= (long)start && val->intValue() <= (long)end */)
	       {
	       // adjust for the 1-origin of the aligment format
	       pushlist(new FrInteger(val->intValue()+1),source) ;
	       }
	    }
	 }
      FrList *a = listreverse(source)->nconc(target) ; 
      pushlist(a,alignment) ;
      }
   // TODO: merge together any source words which have the same target align
//!!!
   // TODO: merge together any target words which have the same source align
//!!!
   FrLocalFree(used) ;
   targetpos += alignlen ;
   if (alignment)
      alignments = alignment->nconc(alignments) ;
   return ;
}

//----------------------------------------------------------------------

static FrList *extract_chart_alignment(const FrTextSpans *lattice)
{
   FrList *alignments = 0 ;
   size_t trgpos = 1 ;
   FrSymbol *symLM = FrSymbolTable::add("LM") ;
   FrSymbol *symENGINE = FrSymbolTable::add("ENGINE") ;
   FrSymbol *symALIGN = FrSymbolTable::add("ALIGN") ;
   for (size_t i = 0 ; i < lattice->spanCount() ; i++)
      {
      const FrTextSpan *span = lattice->getSpan(i) ;
      if (span && span->getMetaData(symENGINE) == symLM)
	 {
	 size_t wc = count_words(span->text()) ;
	 const FrList *align = (FrList*)span->getMetaData(symALIGN) ;
	 if (align)
	    {
	    extract_alignments(align,span->start(),span->length(),trgpos,wc,
			       alignments) ;
	    }
	 trgpos += wc ;
	 }
      }
   return listreverse(alignments) ;
}

//----------------------------------------------------------------------

static void fixup_alignment(char *align)
{
   char *dest = align + 1 ;
   for (align = dest ; *align ; align++)
      {
      if (*align == ',')
	 {
	 if (align[-1] == '|')
	    {
	    dest-- ;
	    if (align[-2] == ' ')
	       dest-- ;
	    }
	 *dest++ = *align ;
	 if (align[1] == '|')
	    {
	    align++ ;
	    if (align[1] == ' ')
	       align++ ;
	    }
	 }
      else
	 *dest++ = *align ;
      }
   *dest = '\0' ;			// ensure proper string termination
   return ;
}

//----------------------------------------------------------------------

static void output_arc(const FrTextSpan *span, ostream &out)
{
   size_t start = span->start() ;
   size_t end = span->end() ;
   double score = span->score() ;
   char *trans = span->getText() ;
   FrSymbol *symENGINE = FrSymbolTable::add("ENGINE") ;
   FrSymbol *symINIT = FrSymbolTable::add("INIT_TEXT") ;
   FrSymbol *type = (FrSymbol*)span->getMetaData(symENGINE);
   FrString *ignore = new FrString(IGNORE_TOKEN) ;
   FrList *metadata = 0 ;
   FrList *fields = span->metaDataKeys() ;
   while (fields)
      {
      FrSymbol *key = (FrSymbol*)poplist(fields) ;
      if (!key)
	 continue ;
      if (key != symENGINE && key != symINIT &&
	  (output_chart_alignment || strcmp(key->symbolName(),"ALIGN") != 0))
	 {
	 const FrObject *value = span->getMetaData(key) ;
	 FrList *meta = value ? (FrList*)value->deepcopy() : 0 ;
	 pushlist(key,meta) ;
	 pushlist(meta,metadata) ;
	 }
      }
   char *input = span->originalText() ;
   FrString *translation = new FrString(trans) ;
   const unsigned char *charmap = FrUppercaseTable(char_encoding) ;
   FrString *xlat = (FrString*)translation->deepcopy() ;
   size_t width = FrDisplayWidth(~0) ; // disable wrapping on output
   if (lattice_in_transducer_format)
      {
      if (equal_casefold(translation,ignore,charmap))
	 out << type << " # " << input << " # # " << score << endl ;
      else
	 {
	 const char *output = xlat ? xlat->stringValue() : "<?>" ;
	 out << type << " # " << input << " # " << output << " # " 
	     << score << endl ;
	 }
      }
   else if (lattice_in_smtstub_format)
      {
      out << '(' << start << ' ' << end << ' ' ;
      if (xlat && !equal_casefold(translation,ignore,charmap))
	 out << xlat ;
      else
	 out << "\"\"" ;
      FrString *instring = new FrString(input) ;
      out << ' ' << score << ' ' << instring << ' ' << type ;
      free_object(instring) ;
      for (FrList *md = metadata ; md ; md = md->rest())
	 {
	 out << ' ' << md->first() ;
	 }
      out << ')' << endl ;
      }
   else
      {
      out << start << ' ' << end << ' ' << type << ' ' << score << ' ' ;
      if (xlat && !equal_casefold(translation,ignore,charmap))
	 out << xlat ;
      else
	 out << "\"\"" ;
      for (FrList *md = metadata ; md ; md = md->rest())
	 {
	 out << ' ' << md->first() ;
	 }
      out << endl ;
      }
   (void)FrDisplayWidth(width) ;	// re-enable output wrapping
   free_object(xlat) ;
   FrFree(input) ;
   free_object(translation) ;
   free_object(metadata) ;
   ignore->freeObject() ;
   FrFree(trans) ;
   return ;
}

//----------------------------------------------------------------------

static void output_lattice_end(const FrString *input, ostream &out)
{
   if (lattice_in_transducer_format)
      {
      out << " # # # " << endl ;
      return ;
      }
   else if (lattice_in_smtstub_format)
      {
      out << ')' << endl ;
      return ;
      }
   FrList *words = input
      ? FrCvtString2Wordlist((char*)input->stringValue(),word_delimiters,
			     abbrevs_list,char_encoding)
      : 0 ;
   FrString *sentence = words ? new FrString(words,char_encoding) : 0 ;
   free_object(words) ;
   out << "-1 -1 :INPUT -1 " << sentence << endl << flush ;
   free_object(sentence) ;
   return ;
}

//----------------------------------------------------------------------

static void output_lattice(FrTextSpans *lattice, ostream &out)
{
   if (lattice_in_smtstub_format)
      out << '(' << endl ;
   lattice->sort() ;
   for (size_t i = 0 ; i < lattice->spanCount() ; i++)
      {
      const FrTextSpan *span = lattice->getSpan(i) ;
      if (!span)
	 continue ;
      output_arc(span,out) ;
      }
   // output the original order of words in the selected arcs, if that info
   //   is available in the chart
   const FrList *ordering = (FrList*)lattice->metaData(makeSymbol("ORDER")) ;
   if (ordering && !lattice_in_transducer_format && !lattice_in_smtstub_format)
      {
      out << "-1 -1 :ORDER 0 \"" ;
      for (const FrList *ord = ordering ; ord ; ord = ord->rest())
	 {
	 FrObject *p = ord->first() ;
	 int pos = (p ? (int)p->intValue() : -1) ;
	 out << pos ;
	 if (ord->rest())
	    out << ' ' ;
	 }
      out << "\"" << endl ;
      }
   if (output_chart_alignment && !lattice_in_transducer_format)
      {
      FrList *align = extract_chart_alignment(lattice) ;
      if (align)
	 {
	 char *alignstr = align->print() ;
	 free_object(align) ;
	 fixup_alignment(alignstr) ;
	 out << "-1 -1 :ALIGN 0 \"" << alignstr << "\"" << endl ;
	 FrFree(alignstr) ;
	 }
      }
   if (lattice_lists_source)
      {
      const char *instring = lattice->originalString() ;
      FrString *input = new FrString(instring) ;
      output_lattice_end(input,out) ;
      free_object(input) ;
      }
   else
      {
      FrString *walk = extract_chart_walk(lattice) ;
      output_lattice_end(walk,out) ;
      free_object(walk) ;
      }
   return ;
}

//----------------------------------------------------------------------

void PlOutputXMLHeader(ostream &out)
{
   out << "<!DOCTYPE translations SYSTEM \"translations.dtd\">" << endl ;
   out << "<translations>" << endl ;
   return ;
}

//----------------------------------------------------------------------

static bool is_LM_span(const FrTextSpan *span)
{
   if (!span)
      return false ;
   const FrObject *eng = span->getMetaData("ENGINE") ;
   const char *engname = FrPrintableName(eng) ;
   if (engname && 
       (Fr_stricmp(engname,"LM") == 0 || Fr_stricmp(engname,":LM") == 0))
      return true ;
   return false ;
}

//----------------------------------------------------------------------

static bool find_word_boundaries(const FrTextSpans *lattice,
				   size_t *&word_indices,
				   size_t *&word_boundaries,
				   size_t &num_words)
{
   size_t textlen = lattice->textLength() ;
   bool *boundaries = FrNewC(bool,textlen+1) ;
   if (!boundaries)
      {
      word_indices = 0 ;
      word_boundaries = 0 ;
      return false ;
      }
   boundaries[0] = true ;
   boundaries[textlen] = true ;
   for (size_t i = 0 ; i < lattice->spanCount() ; i++)
      {
      const FrTextSpan *span = lattice->getSpan(i) ;
      if (!span || is_LM_span(span))
	 continue ;
      size_t start = span->start() ;
      if (start < textlen) 
	 boundaries[start] = true ;
      }
   num_words = 0 ;
   for (size_t i = 0 ; i < textlen ; i++)
      {
      if (boundaries[i])
	 num_words++ ;
      }
   word_indices = FrNewC(size_t,textlen+1) ;
   word_boundaries = FrNewC(size_t,num_words+1) ;
   if (word_indices && word_boundaries)
      {
      size_t count = 0 ;
      for (size_t i = 0 ; i <= textlen ; i++)
	 {
	 if (boundaries[i])
	    word_boundaries[count++] = i ;
	 word_indices[i] = count - 1 ;
	 }
      }
   else
      {
      FrFree(word_indices) ;
      FrFree(word_boundaries) ;
      num_words = 0 ;
      }
   FrFree(boundaries) ;
   return (num_words > 0) ;
}

//----------------------------------------------------------------------

static void get_source_span(const FrTextSpan *span,
			    size_t &s_start, size_t &s_end)
{
   // the LM may have reordered arcs, so the indicated start and stop
   //   positions for the span may not represent the actual source location
   // thus, if we have alignment information available, use that in
   //   preference to the span's start/stop position
   const FrList *align = (FrList*)span->getMetaData("ALIGN") ;
   if (align)
      {
      s_start = UINT_MAX ;
      s_end = 0 ;
      for ( ; align ; align = align->rest())
	 {
	 const FrList *al = (FrList*)align->first() ;
	 if (al && al->consp())
	    {
	    for ( ; al ; al = al->rest())
	       {
	       FrObject *a = al->first() ;
	       if (a && a->numberp())
		  {
		  size_t pos = a->intValue() ;
		  if (pos < s_start)
		     s_start = pos ;
		  if (pos > s_end)
		     s_end = pos ;
		  }
	       }
	    }
	 else if (al && al->numberp())
	    {
	    size_t pos = al->intValue() ;
	    if (pos < s_start)
	       s_start = pos ;
	    if (pos > s_end)
	       s_end = pos ;
	    }
	 }
      }
   else
      {
      s_start = span->start() ;
      s_end = span->end() ;
      }
   return ;
}

//----------------------------------------------------------------------

static void output_XML(const FrTextSpans *input, 
		       const FrTextSpans *lattice, ostream &out)
{
   out << "<tr engine=\"Panlite\">" << endl ;
   size_t *word_indices ;
   size_t *word_boundaries ;
   size_t num_words ;
   out << "<s id=\"" << sentences_translated << "\"> " << flush ;
   if (find_word_boundaries(input,word_indices,word_boundaries,num_words))
      {
      // output the source text, with individual words marked
      for (size_t i = 0 ; i < num_words ; i++)
	 {
	 char *text = input->getText(word_boundaries[i],
				     word_boundaries[i+1]-1) ;
	 if (text)
	    {
	    out << "<w> " << text << " </w> " ;
	    FrFree(text) ;
	    }
	 }
      }
   out << " </s>" << endl ;
   FrFree(word_boundaries) ;
   // output the translation hypothesis, with the target text having its
   //  individual phrases marked for the corresponding source words which
   //  generated those phrases
   const FrObject *conf = lattice->metaData(lattice->makeSymbol("SCORE")) ;
   if (conf && conf->consp())
      conf = ((FrList*)conf)->first() ;
   double confidence = (conf&&conf->numberp()) ? conf->floatValue() : -999.9 ;
   out << "<hyp r=\"0\" c=\"" << confidence << "\">" << endl ;
   out << "<t>" << endl ;
   size_t textlen = input->textLength() ;
   for (size_t i = 0 ; i < lattice->spanCount() ; i++)
      {
      const FrTextSpan *span = lattice->getSpan(i) ;
      if (!is_LM_span(span))
	 continue ;
      char *text = span->getText() ;
      if (!text)
	 continue ;
      size_t s_start, s_end ;
      get_source_span(span,s_start,s_end) ;
      if (s_start < textlen)
	 s_start = word_indices[s_start] ;
      if (s_end < textlen)
	 s_end = word_indices[s_end] ;
      out << "<p al=\"" << s_start << "-" << s_end << "\"> "
	  << text << " </p> " ;
      FrFree(text) ;
      }
   FrFree(word_indices) ;
   out << "</t>" << endl ;
   out << "</hyp>" << endl ;
   out << "</tr>" << endl ;
   return ;
}

//----------------------------------------------------------------------

void PlOutputXMLFooter(ostream &out)
{
   out << "</translations>" << endl ;
   return ;
}

//----------------------------------------------------------------------

void PlApplyLM(const FrTextSpans *input, FrTextSpans *lattice,
	       ostream &out, ostream &err, bool gc)
{
   lm_engine.translateSentence(input,lattice,err,gc,verbose) ;
   if (preparing_for_doc)
      {
      // we don't want any output yet, we're just letting the LM perform
      //   its own preparation for the document; however, we do need to store
      //   the text in the chart file if we are generating one
      if (chartfile)
	 {
	 FrList *words = input->wordList() ;
	 (*chartfile) << words << endl ;
	 free_object(words) ;
	 }
      return ;
      }
   if (verbose)
      err << endl ;
   if (generate_IBM_XML)
      {
      lattice->sort() ;
      output_XML(input,lattice,out) ;
      }
   else if (generate_lattice)
      output_lattice(lattice,out) ;
   else if (lm_engine.isRunning())
      {
      FrString *walk = extract_chart_walk(lattice) ;
      if (walk)
	 {
	 FrString *postproc ;
	 if (postproc_engine.isRunning())
	    postproc = postproc_engine.transform(walk,err,verbose) ;
	 else
	    postproc = lm_engine.transform(walk,err,verbose) ;
	 const char *s ;
	 if (postproc)
	    s = (char*)postproc->stringValue() ;
	 else
	    s = (char*)walk->stringValue() ;
	 PlLineWrap(out,s) ;
	 out << flush ;
	 free_object(postproc) ;
	 free_object(walk) ;
	 }
      }
   else if (verbose)
      {
      FrList *chart = lattice->printable() ;
      out << chart << endl ;
      free_object(chart) ;
      }
   else
      out << "(no language modeler)" << endl ;
   sentences_translated++ ;
   if (chartfile)
      {
      FrList *chart = lattice->printable() ;
      (*chartfile) << chart << endl ;
      free_object(chart) ;
      }
   return ;
}

//----------------------------------------------------------------------

void PlResyncLM(ostream &out)
{
   if (lm_engine.isRemote())
      {
      char line[FrMAX_LINE+1] ;
      while (lm_engine.inputAvailable())
	 {
	 lm_engine.stdOut().getline(line,FrMAX_LINE) ;
	 PlLineWrap(out,line) ;
	 }
      }
   else
      PlLineWrap(out,"") ;
   return ;
}

/************************************************************************/
/************************************************************************/

static bool exec_LM(MEMTEngine *engine, const PLConfig *config,
		      const PlEngineConfig *engcfg,
		      ostream &err, bool run_verbosely)
{
#ifdef LINK_LM
   if (engcfg->isInternal())
      {
      const char *cfg = engcfg->cfg() ;
      if (cfg && cfg[0] == '-' && cfg[1] == 's')
	 cfg += 2 ;
      active_lm = new LanguageModeler("panlite-LM",cfg,true) ;
      bool success = active_lm && active_lm->good() ;
      if (success)
	 {
	 if (run_verbosely)
	    active_lm->identify(cout,true) ;
	 }
      else
	 {
	 delete active_lm ;
	 active_lm = 0 ;
	 }
      return success ;
      }
#endif /* LINK_LM */
   if (engcfg->isDataFile())
      {
//FIXME
      return false ;
      }
   else
      {
      bool run_remotely = (config->remote_exec != 0 && engcfg->host() != 0 &&
			     engcfg->isRemote()) ;
      return engine->execProgram(err,run_remotely ? config->remote_exec : 0,
				 engcfg->host(), engcfg->socket(),
				 LM_NETWORK_FLAG, engcfg->prog(),
				 LM_CHART_TO_STDOUT_FLAG,LM_QUIET_MODE_FLAG,
				 engcfg->cfg(),".",0) ;
      }
}

//----------------------------------------------------------------------

FrList *PlGetDecoderFeatures(const FrTextSpans *input_lat)
{
#ifdef LINK_LM
   return active_lm ? active_lm->getFeatureNames(input_lat) : 0 ;
#else
   (void)input_lat ;
   return 0 ;
#endif
}

//----------------------------------------------------------------------

LmFeatureVector *PlGetDecoderWeightVector(const FrTextSpans *input_lat)
{
#ifdef LINK_LM
   return active_lm ? active_lm->getFeatureWeights(input_lat) : 0 ;
#else
   (void)input_lat ;
   return 0 ;
#endif
}

//----------------------------------------------------------------------

void PlSetDecoderWeightVector(const LmFeatureVector *weights)
{
#ifdef LINK_LM
   if (active_lm)
      active_lm->setFeatureWeights(weights) ;
#else
   (void)input_lat ;
#endif
   return ;
}

//----------------------------------------------------------------------

static void remove_word_list(FrList *nbest)
{
   for ( ; nbest ; nbest = nbest->rest())
      {
      FrList *best = (FrList*)nbest->first() ;
      if (best && best->consp())
	 {
	 best = best->nthcdr(2) ;
	 free_object(best->first()) ;
	 best->replaca(0) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

FrList *PlDecodeNBestList(const FrTextSpans *input, FrTextSpans *lattice,
			  size_t nbest_count)
{
   FrList *nbest = 0 ;
#ifdef LINK_LM
   if (!lm_engine.isRemote())
      {
      if (preparing_for_doc)
	 active_lm->prepareDoc(input) ;
      else
	 {
	 bool old_show = active_lm->showRawScores(true) ;
	 ParseChart *pc ;
	 // we need to preserve the chart until we free the returned
	 //   word lists
	 nbest = active_lm->process(lattice,false,&pc,false,nbest_count) ;
	 remove_word_list(nbest) ;
	 active_lm->deleteParseChart(pc) ;
	 active_lm->showRawScores(old_show) ;
	 sentences_translated++ ;
	 }
      }
   else
#endif   
      {
      (void)lattice ;
      FrError("Decoder was not linked, unable to perform parameter tuning") ;
      exit(1) ;
      }
   return nbest ;
}
//----------------------------------------------------------------------

void PlFreeNBestList(FrList *nbest)
{
   free_object(nbest) ;
}

//----------------------------------------------------------------------

static bool find_best_walk(MEMTEngine *engine, bool prepare,
			   const FrTextSpans *input,
			   FrTextSpans *lattice, ostream &/*err*/)
{
   FrList *result = 0 ;
#ifdef LINK_LM
   if (!engine->isRemote())
      {
      if (prepare || !active_lm)
	 return false ;			// no preparations made
      if (preparing_for_doc)
	 active_lm->prepareDoc(input) ;
      else
	 result = active_lm->process(lattice,true) ;
      }
   else
#endif /* LINK_LM */
      {
      if (prepare)
	 {
	 if (!engine->usingDataFile())
	    {
	    if (preparing_for_doc)
	       {
	       // tell the LM what text we were given to translate
	       FrList *words = input->wordList() ;
	       if (words)
		  lm_engine.stdIn() << words << endl << flush ;
	       free_object(words) ;
	       }
	    else
	       {
	       // request translation of the chart
	       FrList *chart = lattice->printable() ;
	       lm_engine.stdIn() << chart << endl << flush ;
	       free_object(chart) ;
	       }
	    }
	 return true ;
	 }
      if (!preparing_for_doc)
	 result = (FrList*)lm_engine.readObject() ;
      }
   if (result && result->consp() && lattice)
      (void)engine->insertArcs(lattice,(FrList*)result) ;
   else
      free_object(result) ;
   return true ;
}

//----------------------------------------------------------------------

static FrObject *transform_LM_sentence(MEMTEngine *engine,
				       const FrList *wordlist)
{
#ifdef LINK_LM
   if (!engine->isRemote())
      {
      FrString *string = new FrString(wordlist) ;
      char *str = active_lm->postprocess((char*)string->stringValue()) ;
      free_object(string) ;
      string = new FrString(str) ;
      FrFree(str) ;
      return string ;
      }
#endif /* LINK_LM */
   (void)engine ;
//!!!
   return wordlist ? wordlist->deepcopy() : 0 ;
}

//----------------------------------------------------------------------

static bool send_LM_command(MEMTEngine *engine, const char *command,
				const char *arg, const char *success_string)
{
   engine->sendLine(command,arg) ;
   FrObject *result = engine->readObject() ;
   bool success = (result && result->stringp() &&
		     ((FrString*)result)->operator==(success_string)) ;
   free_object(result) ;
   return success ;
}

//----------------------------------------------------------------------

static bool prepare_LM_document(MEMTEngine *engine, bool starting)
{
#ifdef LINK_LM
   if (!engine->isRemote())
      {
      if (chartfile)
	 {
	 if (starting)
	    (*chartfile) << "PREPDOC" << endl ;
	 else
	    (*chartfile) << "ENDPREP" << endl ;
	 }
      return active_lm->prepareForDocument(starting) ;
      }
#endif /* LINK_EBMT */
   engine->sendLine(starting ? "PREPDOC" : "ENDPREP") ;
   FrObject *result = engine->readObject() ;
   bool success = ((FrSymbol*)result == symOK) ;
   free_object(result) ;
   return success ;
}

//----------------------------------------------------------------------

static bool select_LM_genre(MEMTEngine *engine, const char *genre_name)
{
#ifdef LINK_LM
   if (!engine->isRemote())
      return active_lm->selectGenre(genre_name) ;
#endif /* LINK_LM */
   return send_LM_command(engine,"GENRE",genre_name,"Genre selected") ;
}

//----------------------------------------------------------------------

static char *send_LM_command(MEMTEngine *engine, const char *command)
{
#ifdef LINK_LM
   if (!engine->isRemote())
      return active_lm->privateCommand(command) ;
#endif /* LINK_LM */
   return engine->sendRemoteCommand(command) ;
}

//----------------------------------------------------------------------

static bool start_LM_shutdown(MEMTEngine *engine)
{
#ifdef LINK_LM
   if (!engine->isRemote() && engine->isRunning())
      {
      if (!quiet_mode)
	 LMShowCoverage() ;
      delete active_lm ;
      active_lm = 0 ;
      shutdown_LM() ;
      engine->finishShutdown() ;
      if (curr_column > 0)
	 PlResetLineWrap(cout) ;
      return true ;
      }
#endif /* LINK_LM */
   engine->sendLine("*EOF*") ;
   return true ;
}

// end of file pllm.cpp //
