/************************************************************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File plsystrn.cpp		interface to Systran module		*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,2000,2001,2006,2007,2009		*/
/*		 Ralf Brown						*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifdef LINK_ALL
//#define LINK_SYSTRAN
#endif /* LINK_ALL */

#ifdef LINK_SYSTRAN
//#include "systran.h"
#endif /* LINK_SYSTRAN */

#include "plchart.h"
#include "plengine.h"
#include "plproc.h"
#include "plglobal.h"

/************************************************************************/
/*	Forward declarations						*/
/************************************************************************/

static bool exec_Systran(MEMTEngine *engine, const PLConfig *config,
			   const PlEngineConfig *engcfg,
			   ostream &err, bool run_verbosely) ;
static bool translate_sentence_Systran(MEMTEngine *engine, bool prepare,
					 const FrTextSpans *input,
					 FrTextSpans *lattice,ostream &err) ;
static bool start_Systran_shutdown(MEMTEngine *engine) ;

/************************************************************************/
/*    Global variables for this module					*/
/************************************************************************/

MEMTEngine systran_engine("Systran(Babelfish)",":SYSTRAN",ET_Xlat,exec_Systran,
			translate_sentence_Systran,start_Systran_shutdown,
			0,0) ;

/************************************************************************/
/*    Functions for interfacing with Systran				*/
/************************************************************************/

static bool exec_Systran(MEMTEngine *engine, const PLConfig *config,
			   const PlEngineConfig *engcfg,
			   ostream &err, bool run_verbosely)
{
#ifdef LINK_SYSTRAN
   if (engcfg->isInternal())
      {
//!!!
      }
#endif /* LINK_SYSTRAN */
   return engine->startEngine(config,engcfg,SYSTRAN_NETWORK_FLAG,0,err,
			      run_verbosely) ;
}

//----------------------------------------------------------------------

static void insert_result(MEMTEngine *engine, FrTextSpans *lattice,
			  const FrString *sentence, char *result,
			  int start, size_t inputlen)
{
   double score = SYSTRAN_SCORE_OK ;
   if (strncmp(result,"**time-out**",12) == 0)
      {
      score = SYSTRAN_SCORE_TIMEOUT ;
      strcpy(result,result+12) ;
      }
   if (sentence)
      sentence = (FrString*)sentence->deepcopy() ;
   else
      sentence = new FrString("{unavailable}") ;
   FrList *entry = makelist(new FrInteger(start),
			    new FrInteger(start+inputlen-1),
			    new FrList(new FrString(result)),
			    new FrFloat(score),sentence,
			    0) ;
   engine->insertArc(lattice,entry) ;
   free_object(entry) ;
   return ;
}

//----------------------------------------------------------------------

static bool translate(MEMTEngine *engine, FrTextSpans *lattice,
			const char *text,
			int startpos, size_t inputlen, ostream &err)
{
   FrString *sentence = new FrString(text,char_encoding) ;
   const char *string = (char*)sentence->stringValue() ;
   engine->sendLine(string) ;
   if (!engine->stillAlive(err))
      return false ;
   char result[FrMAX_LINE] ;
   *result = '\0' ;
   // the following line works for both data files (one line of text per
   //   line of input to be translated) and network connections
   engine->stdOut().getline(result,sizeof(result)) ;
   bool success ;
   if (*result)
      {
      insert_result(engine,lattice,sentence,result,startpos,inputlen) ;
      success = true ;
      }
   else
      {
      if (verbose)
	 cout << "; Systran translation failed!" << endl ;
      success = false ;
      }
   free_object(sentence) ;
   return success ;
}

//----------------------------------------------------------------------

static bool translate_sentence_Systran(MEMTEngine *engine, bool prepare,
					 const FrTextSpans *input,
					 FrTextSpans *lattice,ostream &err)
{
   if (prepare)
      return false ;			// didn't prepare anything
   size_t inputlen = input->textLength() ;
   bool translated = translate(engine,lattice,input->originalString(),0,
				 inputlen,err) ;
   for (size_t i = 0 ; translated && i < input->spanCount() ; i++)
      {
      const FrTextSpan *span = input->getSpan(i) ;
      if (span)
	 {
	 char *text = span->getText() ;
	 if (!translate(engine,lattice,text,span->start(),span->length(),err))
	    translated = false ;
	 FrFree(text) ;
	 }
      }
   return translated ;
}

//----------------------------------------------------------------------

static bool start_Systran_shutdown(MEMTEngine *engine)
{
#ifdef LINK_SYSTRAN
   if (!engine->isRemote())
      {
      //!!!
      return true ;
      }
#endif /* LINK_SYSTRAN */
   engine->sendLine(".") ;
   return true ;
}

// end of file plsystrn.cpp //
