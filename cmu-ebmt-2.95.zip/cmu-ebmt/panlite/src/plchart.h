/************************************************************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File plchart.h		chart-handling functions		*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2006,2009	*/
/*		 Ralf Brown						*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __PLCHART_H_INCLUDED
#define __PLCHART_H_INCLUDED

#include "FramepaC.h"

/************************************************************************/
/************************************************************************/

#define PL_MERGE_NONE	0
#define PL_MERGE_REF	((size_t)(~0-3))
#define PL_MERGE_SEG	((size_t)(~0-2))
#define PL_MERGE_WORD	((size_t)(~0-1))
#define PL_MERGE	((size_t)(~0-3))

/************************************************************************/
/************************************************************************/

#endif /* __PLCHART_H_INCLUDED */

// end of file plchart.h //
