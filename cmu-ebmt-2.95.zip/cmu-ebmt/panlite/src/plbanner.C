/************************************************************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.91							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File plbanner.cpp							*/
/*  LastEdit: 01feb10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2009,2010		*/
/*		 Ralf Brown						*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "panlite.h"
#include "plbanner.h"
#include "plglobal.h"

/************************************************************************/
/************************************************************************/

bool complete_banner_when_redirected = false ;

/************************************************************************/
/************************************************************************/

void display_banner(ostream &out)
{
   out << PROGRAM_NAME " " ;
   if (Panlite_languages_specified > 1)
      out << '(' << Panlite_source_language << " to "
	    << Panlite_target_language << ") " ;
   out << "v" PANLITE_VERSION_STR "." ;
   if (generate_lattice)
      out << " [Lattice]" ;
   out << endl ;
   out << "This is free software; see the source for copying conditions.  There is NO\n"
          "warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE."
       << endl ;
   if (&out == &cout && !complete_banner_when_redirected)
      out << "	(loading)\r" << flush ;
   return ;
}

//----------------------------------------------------------------------

void welcome_message(ostream &out)
{
   if (interactive_Panlite || complete_banner_when_redirected)
      {
      out << "Enter :HELP for available commands, or type sentences to be translated." 
	  << endl << endl ;
      }
   return ;
}

//----------------------------------------------------------------------

void goodbye_message(ostream &out)
{
   if (interactive_Panlite)
      {
      out << "\nGood-bye." << endl ;
      }
   return ;
}

// end of file plbanner.cpp //
