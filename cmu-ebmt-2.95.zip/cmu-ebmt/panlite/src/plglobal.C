/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File plglobal.cpp		global variables for PanLite		*/
/*  LastEdit: 29mar10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2006,2007,2009,2010 Ralf Brown				*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "FramepaC.h"
#include "plengine.h"
#include "plproc.h"
#include "plutil.h"
#include "plglobal.h"

#if defined(LINK_ALL) || defined(LINK_LM)
#include "lmodel.h"
#endif /* LINK_ALL || LINK_LM */

/************************************************************************/
/*	Manifest constants for this module				*/
/************************************************************************/

/************************************************************************/
/*	Global variables shared with other modules			*/
/************************************************************************/

MEMTGlobalVariables memt_vars ;

/************************************************************************/
/*	Global variables for this module				*/
/************************************************************************/

static MEMTGlobalVariables *active_vars = 0 ;
static MEMTGlobalVariables *default_vars = 0 ;

static char def_source_language[] = "source language" ;
static char def_target_language[] = "target language" ;

/************************************************************************/
/*	Helper Functions						*/
/************************************************************************/

static void clear_regex_list(FrRegExp *re_list)
{
   while (re_list)
      {
      FrRegExp *tmp = re_list ;
      re_list = re_list->next() ;
      delete tmp ;
      }
   return ;
}

/************************************************************************/
/*	Methods for class MEMTGlobalVariables				*/
/************************************************************************/

MEMTGlobalVariables::MEMTGlobalVariables()
{
   _stats__sentences_translated = 0 ;
   _Panlite_source_language = def_source_language ;
   _Panlite_target_language = def_target_language ;
   _Panlite_update_filename = 0 ;
   _Panlite_chartfilename = 0 ;
   _showmem = false ;
   _current_outstream = 0 ;
   FrSetNonbreakingAbbreviations(0) ;
   _conserve_memory = false ;
   _xml_input = false ;
   _no_input_yet = true ;
   _abbrevs_list = 0 ;
   _alternative_genres = 0 ;
   _curr_alternative_genre = 0 ;
   _verbose_feature_names = false ;
   _preparing_for_doc = false ;
   _prepared_doc = 0 ;
   _pending_metadata = 0 ;
   _opt_scorer = 0 ;
   _opt_cache_lattices = true ;
   _symMORPH = makeSymbol("MORPH") ;
   _symOK = makeSymbol("OK") ;
   _symROOT = makeSymbol("ROOT") ;
   _symSTRING = makeSymbol("STRING") ;
   _symWORD = makeSymbol("WORD") ;
   applyConfiguration(0) ;
   return ;
}

//----------------------------------------------------------------------

MEMTGlobalVariables::MEMTGlobalVariables(const MEMTGlobalVariables &vars)
{
   memcpy(this,&vars,sizeof(MEMTGlobalVariables)) ;
   // fix up the items which are allocated on the heap
   _Panlite_chartfilename = FrDupString(_Panlite_chartfilename) ;
   _Panlite_update_filename = FrDupString(_Panlite_update_filename) ;
   _Panlite_source_language = FrDupString(_Panlite_source_language) ;
   _Panlite_target_language = FrDupString(_Panlite_target_language) ;
   _alternative_genres = 0 ;		// should never be nonzero at this time
   _curr_alternative_genre = 0 ;	//   anyway, as these are temporaries
   if (_prepared_doc)
      _prepared_doc = (FrList*)_prepared_doc->deepcopy() ;
   if (_word_delimiters)
      {
      char *delimiters = FrNewN(char,256) ;
      if (delimiters)
	 memcpy(delimiters,_word_delimiters,256) ;
      _word_delimiters = delimiters ;
      }
   return ;
}

//----------------------------------------------------------------------

MEMTGlobalVariables::~MEMTGlobalVariables()
{
   if (this == active_vars)
      default_vars->select() ;
   if (this == &memt_vars)
      {
#if defined(LINK_ALL) || defined(LINK_LM)
      delete _lm ;
#endif /* LINK_ALL || LINK_LM */
      _lm = 0 ;
      return ;
      }
   freeVariables() ;
   return ;
}

//----------------------------------------------------------------------

void MEMTGlobalVariables::freeVariables()
{
   free_object(_prepared_doc) ;		_prepared_doc = 0 ;
   if (_Panlite_source_language != def_source_language)
      FrFree(_Panlite_source_language) ;
   _Panlite_source_language = 0 ;
   if (_Panlite_target_language != def_target_language)
      FrFree(_Panlite_target_language) ;
   _Panlite_target_language = 0 ;
   FrFree(_Panlite_chartfilename) ;	_Panlite_chartfilename = 0 ;
   FrFree(_Panlite_update_filename) ;	_Panlite_update_filename = 0 ;
   FrFree(_word_delimiters) ;		_word_delimiters = 0 ;
   FrFreeAbbreviationList(_abbrevs_list) ; _abbrevs_list = 0 ;
   if (this == &memt_vars)
      {
      clear_regex_list(_preproc_regex_list) ; _preproc_regex_list = 0 ;
      FrSetNonbreakingAbbreviations(0) ;
      }
   return ;
}

//----------------------------------------------------------------------

static FrRegExp *load_regex_list(const char *filename)
{
   FrRegExp *re_list = 0 ;
   FrRegExp *re_list_tail = 0 ;
   FILE *fp = fopen(filename,"r") ;
   if (fp)
      {
      size_t linenum = 0 ;
      FrSymbol *symbolEOF = makeSymbol("*EOF*") ;
      while (!feof(fp))
	 {
	 char line[FrMAX_LINE] ;
	 line[0] = '\0' ;
	 if (fgets(line,sizeof(line),fp) && !feof(fp))
	    {
	    linenum++ ;
	    const char *lineptr = line ;
	    FrObject *src = string_to_FrObject(lineptr) ;
	    // check whether line contained anything besides whitespace and
	    // comments
	    if (src && src != symbolEOF)
	       {
	       if (!src->stringp())
		  {
		  FrWarningVA("%s (line %lu): expecting two quoted strings\n"
			      "\t(regex to test and replacement)",filename,
			      (unsigned long)linenum) ;
		  continue ;
		  }
	       FrObject *replacement = string_to_FrObject(lineptr) ;
	       if (replacement == symbolEOF)
		  {
		  FrWarningVA("%s (line %lu):\n"
			      "\tno replacement string given -- entry skipped",
			      filename,(unsigned long)linenum) ;
		  continue ;
		  }
	       if (!replacement ||
		   (!replacement->stringp() && !replacement->symbolp()))
		  {
		  FrWarningVA("%s (line %lu):\n"
			      "\tsecond item on line must be a quoted string!",
			      filename,(unsigned long)linenum) ;
		  continue ;
		  }
	       const char *repl = 0 ;
	       if (replacement->stringp())
		  repl = (char*)((FrString*)replacement)->stringValue();
	       else // if (replacement->symbolp())
		  repl = ((FrSymbol*)replacement)->symbolName() ;
	       if (repl)
		  {
		  char *regex = (char*)((FrString*)src)->stringValue() ;
		  FrRegExp *re = new FrRegExp(regex,repl,0) ;
		  // store REs on list in the order in which they appear in
		  // the file
		  if (re_list)
		     re_list_tail->relink(re) ;
		  else
		     re_list = re ;
		  re_list_tail = re ;
		  }
	       free_object(replacement) ;
	       }
	    free_object(src) ;
	    }
	 }
      fclose(fp) ;
      }
   return re_list ;
}

//----------------------------------------------------------------------

void PlEnableEngines(const FrList *engines)
{
   if (engines)
      {
      MEMTEngine::disableAllEngines() ;
      for ( ; engines ; engines = engines->rest())
	 {
	 FrSymbol *name = FrCvt2Symbol(engines->first()) ;
	 MEMTEngine *engine = MEMTEngine::findEngine(name) ;
	 if (engine)
	    engine->enableEngine() ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void PlUpdateableEngines(const FrList *engines)
{
   MEMTEngine::disallowUpdatesAllEngines() ;
   for ( ; engines ; engines = engines->rest())
      {
      FrSymbol *name = FrCvt2Symbol(engines->first()) ;
      MEMTEngine *engine = MEMTEngine::findEngine(name) ;
      if (engine)
	 engine->allowUpdates() ;
      }
   return ;
}

//----------------------------------------------------------------------

void MEMTGlobalVariables::applyConfiguration(const PLConfig *config)
{
   FrSetNonbreakingAbbreviations(0) ;
   // FrHashTable*
   _lm = 0 ;
   _preproc_regex_list = 0 ;
   _curr_column = 0 ;
   if (config)
      {
      if (config->sourcelang && *config->sourcelang)
	 {
	 _Panlite_source_language = FrDupString(config->sourcelang) ;
	 _Panlite_languages_specified++ ;
	 }
      if (config->targetlang && *config->targetlang)
	 {
	 _Panlite_target_language = FrDupString(config->targetlang) ;
	 _Panlite_languages_specified++ ;
	 }
      if (config->updates && *config->updates)
	 _Panlite_update_filename = FrDupString(config->updates) ;
      if (config->word_delim)
	 set_word_delimiters(_word_delimiters,config->word_delim) ;
      if (config->preproc_regex && *config->preproc_regex)
	 _preproc_regex_list = load_regex_list(config->preproc_regex) ;
      }
   else
      {
      // use the default configuration
      // bool
      _Panlite_batch_mode = false ;
      _Panlite_network_mode = false ;
      _Unicode_bswap = false ;
      _generate_lattice = false ;
      _generate_IBM_XML = false ;
      _interactive_Panlite = true ;
      _lattice_lists_source = true ;
      _lattice_in_transducer_format = false ;
      _show_Panlite_memusage = false ;
      _freeform_input = false ;
      _gloss_overrides_dict = false ;
      _allow_colon_commands = false ;
      _keep_empty_lines = true ;
      _conserve_memory = false ;
      _quiet_mode = false ;

      // int
      _Panlite_lines_per_batch = 0 ;
      _Panlite_prev_batchsize = 0 ;
      _Panlite_linewrap_width = 78 ;
      _Panlite_languages_specified = 0 ;

      // double

      // char*
      _Panlite_update_filename = 0 ;

      // ostream*
      _chartfile = 0 ;

      // FrSymbol*

      // other types
      _named_entity_spec = 0 ;
      _char_encoding = FrChEnc_Latin1 ;
      }
   return ;
}

//----------------------------------------------------------------------

MEMTGlobalVariables *MEMTGlobalVariables::select()
{
   MEMTGlobalVariables *prev = active_vars ;
   if (!active_vars && !default_vars)
      default_vars = active_vars = new MEMTGlobalVariables(memt_vars) ;
   if (this == 0)
      {
      if (default_vars)
	 return default_vars->select() ;
      else
	 return prev ;
      }
   if (this != active_vars)
      {
      if (prev)
	 memcpy(prev,&memt_vars,sizeof(MEMTGlobalVariables)) ;
      if (this != &memt_vars)
	 memcpy(&memt_vars,this,sizeof(MEMTGlobalVariables)) ;
      active_vars = this ;
      return prev ? prev : active_vars ;
      }
   return prev ;
}

// end of file plglobal.cpp //
