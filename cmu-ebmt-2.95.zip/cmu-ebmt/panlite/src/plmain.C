/************************************************************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File plmain.cpp		main functions				*/
/*  LastEdit: 20apr10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "plchart.h"
#include "plengine.h"
#include "plproc.h"
#include "panlite.h"
#include "plglobal.h"
#include "frsstrm.h"		// for class strstream

#ifdef FrSTRICT_CPLUSPLUS
# include <fstream>
#else
# include <fstream.h>
#endif /* FrSTRICT_CPLUSPLUS */

/************************************************************************/
/*	Global Variables						*/
/************************************************************************/

static FrList *reference_translations = 0 ;
static char *active_genre = 0 ;

/************************************************************************/
/*    	General utility functions					*/
/************************************************************************/

inline size_t minimum(size_t a,size_t b) { return a<b ? a : b ; }

//----------------------------------------------------------------------

static FrString *apply_regex(FrString *line, FrRegExp *regex_list)
{
   if (regex_list && line)
      {
      FrList *wordlist ;
      if (line->charWidth() == 1)
	 wordlist = FrCvtString2Wordlist((char*)line->stringValue(),
					 word_delimiters,abbrevs_list,
					 char_encoding) ;
      else if (line->stringLength() > 0)
	 wordlist = FrCvtUString2Wordlist((FrChar16*)line->stringValue(),
					  line->stringLength()) ;
      else
	 wordlist = 0 ;
      if (wordlist)
	 {
	 bool replacement = false ;
	 for (FrList *wl = wordlist ; wl ; wl = wl->rest())
	    {
	    FrString *word = (FrString*)wl->first() ;
	    if (!word)
	       continue ;
	    for (FrRegExp *re = regex_list ; re ; re = re->next())
	       {
	       // (note: this currently will not work for Unicode....)
	       FrObject *translation = re->match((char*)word->stringValue()) ;
	       if (translation)
		  {
		  replacement = true ;
		  // remove the current word from the line
		  wl->replaca(0) ;
		  word->freeObject() ;
		  // now plug in the new one (may include embedded blanks,
		  // which will cause it to be treated as multiple words after
		  // we reassemble the line to return the updates)
		  wl->replaca(translation) ;
		  word = (FrString*)translation ;
		  }
	       }
	    }
	 if (replacement)
	    {
	    line->freeObject() ;
	    line = new FrString(wordlist,char_encoding) ;
	    }
	 wordlist->freeObject() ;
	 }
      }
   return line ;
}

//----------------------------------------------------------------------

void PlApplyPreprocessor(char *line, size_t maxline, bool canonicalize)
{
   if (!line || !*line)
      return ;
   // first line of input is a special case, as we need to check for a
   //   number of things that affect further processing: UTF-8 marker,
   //   XML DTD header, ??
   if (no_input_yet)
      {
      char *lineptr = line ;
      if (PlHasUTF8Marker(line))
	 {
	 char_encoding = FrChEnc_UTF8 ;
	 lineptr += 3 ;			// skip the marker
	 }
      if (PlIsXMLHeader(lineptr,false))
	 {
	 xml_input = true ;
	 freeform_input = true ;
	 }
      no_input_yet = false ;
      }
   FrString *sent = new FrString(line) ;
   sent = apply_regex(sent,preproc_regex_list) ;
   FrString *preproc = preproc_engine.transform(sent,cerr,verbose) ;
   free_object(sent) ;
   if (preproc)
      {
      memcpy(line,(char*)preproc->stringValue(),
	     minimum(maxline,preproc->stringSize() + preproc->charWidth())) ;
      free_object(preproc) ;
      }
   line[maxline-1] = '\0' ;
   if (canonicalize)
      {
      char *tmp = FrCanonicalizeSentence(line,char_encoding,false,
					 word_delimiters,abbrevs_list) ;
      if (tmp)
	 {
	 strncpy(line,tmp,maxline) ;
	 line[maxline-1] = '\0' ;
	 FrFree(tmp) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

bool PlHasUTF8Marker(const char *line)
{
   // UTF-8 encoded byte-order marker: 0xEF 0xBB 0xBF
   (void)FrSkipWhitespace(line) ;
   if (line[0] == '\xEF' && line[1] == '\xBB' && line[2] == '\xBF')
      return true ;
   return false ;
}

//----------------------------------------------------------------------

bool PlIsXMLHeader(const char *line, bool unicode)
{
   const char marker[] = "<?xml " ;
   if (unicode)
      {
      FrChar16 c ;
      while ((c = *((FrChar16*)line)) != 0 &&
	     Fr_is8bit(c) && Fr_isspace(c))
	 {
	 line += sizeof(FrChar16) ;
	 }
      }
   else
      (void)FrSkipWhitespace(line) ;
   return FrStringCmp(line,marker,sizeof(marker)-1,
		      unicode ? sizeof(FrChar16) : sizeof(char),
		      sizeof(char)) == 0 ;
}

//----------------------------------------------------------------------

void Panlite_get_line(istream &in, char *line, size_t maxline)
{
   if (!line || maxline == 0)
      return ;
   in.getline(line,maxline) ;
   // remove any trailing newline
   char *end = strchr(line,'\0') ;
   while (end > line && (end[-1] == '\n' || Fr_isspace(end[-1])))
      end[-1] = '\0' ;
   PlApplyPreprocessor(line,maxline,false) ;
   return ;
}

/************************************************************************/
/*    Translation Engine utility functions				*/
/************************************************************************/

void PlResetLineWrap(ostream &out, bool force)
{
   if (generate_IBM_XML)
      out << flush ;
   else if (force || curr_column > 0 || Panlite_linewrap_width <= 0)
      out << endl ;
   else
      out << flush ;
   curr_column = 0 ;
   return ;
}

//----------------------------------------------------------------------

void PlLineWrap(ostream &out, const char *line)
{
   if (Panlite_linewrap_width <= 0)
      {
      if (!line || !*line)
	 line = " " ;
      out << line ;
      size_t len = strlen(line) - 1 ;
      if (line[len] == '\r' || line[len] == '\n')
	 curr_column = 0 ;
      else
	 curr_column++ ;	 // we have output, so will need newline later
      return ;
      }
   int len = strlen(line) ;
   int remaining = Panlite_linewrap_width - curr_column ;
   if (len <= remaining)
      {
      out << line ;
      curr_column += len ;
      }
   else
      {
      const char *end = line + remaining ;
      while (end > line && *end != ' ')
	 end-- ;
      if (end <= line)
	 for (end = line + remaining ; *end && *end != ' ' ; end++)
	    ;
      out.write(line,end-line) ;
      out << endl ;
      curr_column = 0 ;
      PlLineWrap(out,end+1) ;
      }
   if (curr_column < Panlite_linewrap_width)
      {
      out << ' ' ;
      curr_column++ ;
      }
   return ;
}

//----------------------------------------------------------------------

void PlSetAlternativeGenres(const FrList *genres)
{
   FrList **end = &alternative_genres ;
   free_object(alternative_genres) ;
   for ( ; genres ; genres = genres->rest())
      {
      FrSymbol *genre = FrCvt2Symbol(genres->first()) ;
      alternative_genres->pushlistend(genre,end) ;
      }
   *end = 0 ; 				// properly terminate the list
   curr_alternative_genre = alternative_genres ;
   return ;
}

//----------------------------------------------------------------------

FrSymbol *PlNextAlternativeGenre()
{
   FrSymbol *genre = 0 ;
   if (curr_alternative_genre)
      {
      genre = (FrSymbol*)curr_alternative_genre->first() ;
      FrList *next = curr_alternative_genre->rest() ;
      if (next)
	 curr_alternative_genre = next ;
      }
   return genre ;
}

/************************************************************************/
/************************************************************************/

bool PlExecPrograms(const PLConfig *config,ostream &err)
{
   if (config)
      MEMTEngine::startAllEngines(config,err,verbose) ;
   MEMTEngine::awaitReadinessAllEngines(err,verbose) ;
   return true ;
}

//----------------------------------------------------------------------

void PlShutdownPrograms(ostream & /*out*/,ostream &err)
{
   if (chartfile)
      {
      ((ofstream*)chartfile)->close() ;
      delete chartfile ;
      chartfile = 0 ;
      }
   MEMTEngine::shutdownAllEngines(err,verbose) ;
   return ;
}

//----------------------------------------------------------------------

static bool filter_span(const FrTextSpan *span, va_list)
{
   return span && span->score() < Panlite_lattice_minscore ;
}

//----------------------------------------------------------------------

void PlAddSourcePassthru(const FrTextSpans *inlattice,
			 FrTextSpans *outlattice)
{
   if (Panlite_passthru_source > 0.0)
      {
      // since inlattice and outlattice may be the same, start by accumulating
      //   a list of all the pass-through spans we want to add
      FrList *spans = 0 ;
      FrSymbol *sym_ENGINE = makeSymbol("ENGINE") ;
      FrSymbol *sym_PASS = makeSymbol(":PASS") ;
      for (size_t i = 0 ; i < inlattice->spanCount() ; i++)
	 {
	 FrTextSpan span(inlattice->getSpan(i)) ;
	 span.updateText(span.getText(),false) ;
	 span.setScore(span.score() * Panlite_passthru_source) ;
	 span.setMetaData(sym_ENGINE,sym_PASS) ;
	 pushlist(span.printable(),spans) ;
	 }
      // now that we're done processing the input lattice, add the new spans
      //   to the output lattice
      outlattice->newSpans(spans) ;
      free_object(spans) ;
      }
   return ;
}

//----------------------------------------------------------------------

FrTextSpans *PlMakeLattice(const FrList *wordlist)
{
   FrTextSpans *spans = new FrTextSpans(wordlist,char_encoding,
					word_delimiters) ;
   if (!spans)
      {
      FrNoMemory("while creating translation lattice") ;
      return 0 ;
      }
   if (Panlite_lattice_minscore > 0.0)
      spans->removeMatchingSpans(filter_span) ;
   (void)FrParseNamedEntityData(spans,named_entity_spec,true) ;
   (void)FrParseMorphologyData(spans,morph_classes,morph_replace_text,
			       morph_global_info) ;
   if (pending_metadata)
      {
      spans->addMetaData(pending_metadata) ;
      delete pending_metadata ;
      pending_metadata = 0 ;
      }
   spans->sort() ;
   return spans ;
}

//----------------------------------------------------------------------

FrTextSpans *PlMakeLattice(const FrString *text)
{
   if (!text || !text->stringp() || !text->stringValue())
      return 0 ;
   FrList *wordlist = FrCvtString2Wordlist(text->stringValue(),
					   word_delimiters,abbrevs_list,
					   char_encoding) ;
   FrTextSpans *spans = PlMakeLattice(wordlist) ;
   free_object(wordlist) ;
   return spans ;
}

//----------------------------------------------------------------------

FrTextSpans *PlMakeLattice(const FrObject *obj)
{
   if (!obj)
      return 0 ;
   else if (obj->consp())
      return PlMakeLattice((FrList*)obj) ;
   else if (obj->stringp())
      return PlMakeLattice((FrString*)obj) ;
   else
      return 0 ;
}

//----------------------------------------------------------------------

static bool annotate_input(MEMTEngine *eng, va_list args)
{
   FrVarArg(FrTextSpans*,sent) ;
   FrVarArg(ostream*,err) ;
   FrVarArg(bool*,have_annotations) ;
   if (eng->engineEnabled())
      {
      eng->translateSentence(sent,sent,*err,conserve_memory,verbose) ;
      *have_annotations = true ;
      }
   return true ;
}

//----------------------------------------------------------------------

FrTextSpans *PlTranslateSentence(const FrList *alternatives,
				 const FrList *ref, FrTextSpans *&input,
				 ostream &err)
{
   if (!alternatives)
      return 0 ;
   input = PlMakeLattice(alternatives->first()) ;
   if (!input)
      return 0 ;			// ran out of memory
   if (ref)
      input->setMetaData(makeSymbol("REFXLAT"),ref) ;
   bool translations = false ;
   FrTextSpans *lattice = new FrTextSpans(input) ;
   for ( ; alternatives ; alternatives = alternatives->rest())
      {
      FrString *currline = (FrString*)alternatives->first() ;
      if (!currline)
	 continue ;
      const char *line = (char*)currline->stringValue() ;
      FrList *sentence = FrCvtString2Wordlist(line,word_delimiters,
					      abbrevs_list,char_encoding) ;
      if (sentence)
	 {
	 FrTextSpans *sent = PlMakeLattice(sentence) ;
	 sent->copyMetaData(lattice) ;
	 // apply morphological analyzer and any other annotation engines
	 //   which may be running
	 bool have_annotations = false ;
	 MEMTEngine::iterate(ET_Annotate,FrComp_Equal,annotate_input,
			     sent,&err,&have_annotations) ;
	 // finally, perform the actual translation by calling all running
	 //    translation engines
	 if (sent->compatibleWith(input) &&
	     MEMTEngine::translate(sent,lattice,err,conserve_memory,verbose))
	    translations = true ;
	 sentence->freeObject() ;
	 delete sent ;
	 }
      }
   PlAddSourcePassthru(input,lattice) ;
   return lattice ;
}

//----------------------------------------------------------------------

static char *translate_sentence(const FrList *lines, const FrList *ref)
{
   FrTextSpans *input ;
   FrTextSpans *lattice = PlTranslateSentence(lines,ref,input,cerr) ;
   ostrstream out ;
   int lw_width = Panlite_linewrap_width ;
   Panlite_linewrap_width = 0 ;		// disable line wrapping
   PlApplyLM(input,lattice,out,cerr) ;
   Panlite_linewrap_width = lw_width ;
   delete input ;
   delete lattice ;
   out << '\0' ;		// ensure string termination
   char *xlat = out.str() ;
   char *translated = FrDupString(xlat) ;
   delete [] xlat ;
   return translated ;
}

//----------------------------------------------------------------------

static bool apply_engine(MEMTEngine *engine, va_list args)
{
   FrVarArg(size_t,num_lattices) ;
   FrVarArg(FrTextSpans**,lattices) ;
   FrVarArg(FrTextSpans**,outputs) ;
   FrVarArg(istream*,in) ;
   FrVarArg(ostream*,out) ;
   FrVarArg(ostream*,err) ;
   FrVarArg(bool*,success) ;
   if (!engine->isRunning())
      {
      *success = true ;
      return true ;
      }
   for (size_t i = 0 ; i < num_lattices ; i++)
      {
      if (!lattices[i] || !outputs[i])
	 continue ;
      const char *text = lattices[i]->originalString() ;
      if (text && text[0] == ':')
	 {
	 // it's a colon-command, so interpret it
	 if (!PlProcessCommand(text,*in,*out,*err))
	    {
	    (*out) << ">Shutdown requested." << endl ;
	    return false ;
	    }
	 if (out != &cout)
	    cout << ">done" << endl ;
	 }
      else if (!engine->translateSentence(lattices[i],outputs[i],*err,false,
					  verbose))
	 return false ;
      else
	 PlAddSourcePassthru(lattices[i],outputs[i]) ;
      }
   *success = true ;
   return true ;
}

//----------------------------------------------------------------------

static bool Panlite_translate_sentences(const FrList *lines,
					  istream &in, ostream &out,
					  ostream &err,size_t merge,
					  FrTextSpans **&inputs,
					  FrTextSpans **&outputs)
{
   size_t num_lines = lines->simplelistlength() ;
   inputs = FrNewC(FrTextSpans*,num_lines) ;
   outputs = FrNewC(FrTextSpans*,num_lines) ;
   if (!inputs || !outputs)
      {
      FrNoMemory("while translating a batch of sentences") ;
      FrFree(outputs) ; 	outputs = 0 ;
      FrFree(inputs) ;		inputs = 0 ;
      return false ;
      }
   size_t count = 0 ;
   for (const FrList *s = lines ; s && count < num_lines ; s = s->rest())
      {
      const FrString *line = (FrString*)s->first() ;
      if (merge != PL_MERGE_NONE && line->stringValue() &&
	  Fr_strnicmp(line->stringValue(),":END",4) == 0)
	 continue ;
      else if (PlIsCommand((char*)line->stringValue()))
	 {
	 if (PlIsSafeCommand((char*)line->stringValue()))
	    inputs[count++] = PlMakeLattice(line) ;
	 continue ;
	 }
      FrList *sentence = FrCvtString2Wordlist((char*)line->stringValue(),
					      word_delimiters,abbrevs_list,
					      char_encoding) ;
      if (sentence)
	 {
	 FrTextSpans *input = PlMakeLattice(sentence) ;
	 if (morph_engine.engineEnabled())
	    morph_engine.translateSentence(input,input,err,false,verbose) ;
	 if (merge == PL_MERGE_SEG)
	    {
	    FrSymbol *genre = PlNextAlternativeGenre() ;
	    if (genre)
	       input->addAllMetaData(FrSymbolTable::add("GENRE"),genre) ;
	    if (inputs[0])
	       {
	       if (!inputs[0]->merge(input,false,FrTSOp_Average,FrTSOp_Add) &&
		   !quiet_mode)
		  cout << "; incompatible inputs -- "
		          "lines differ by more than just whitespace" << endl ;
	       delete input ;
	       }
	    else
	       inputs[0] = input ;
	    if (count == 0)
	       count = 1 ;
	    }
	 else
	    inputs[count++] = input ;
	 free_object(sentence) ;
	 }
      }
   for (size_t i = 0 ; i < count ; i++)
      {
      if (inputs[i])
	 outputs[i] = new FrTextSpans(inputs[i]) ;
      }
   // run each translation engine in turn
   if (verbose && merge == PL_MERGE_SEG)
      {
      inputs[0]->sort() ;
      FrList *lat = inputs[0]->printable() ;
      cout << "#| Translating " << lat << " |#" << endl ;
      free_object(lat) ;
      }
   bool success = false ;
   MEMTEngine::iterate(ET_Xlat,FrComp_Equal,apply_engine,count,inputs,
		       outputs,&in,&out,&err,&success) ;
   return success ;
}

//----------------------------------------------------------------------

static void translate_sentences(const FrList *lines, istream &in,
				ostream &out, ostream &err,
				int merge)
{
   FrTextSpans **inputs ;
   FrTextSpans **outputs ;
   size_t num_lines = lines->simplelistlength() ;
   bool success = Panlite_translate_sentences(lines,in,out,err,merge,
						inputs,outputs) ;
   if (merge != PL_MERGE_NONE)
      {
      PlSetAlternativeGenres(0) ;	// clean up after :ALT command
//FIXME: need to deal with PL_MERGE_WORD and PL_MERGE_REF
      }
   if (success)
      {
      for (size_t i = 0 ; i < num_lines ; i++)
	 {
	 if (inputs[i] && outputs[i])
	    {
	    PlApplyLM(inputs[i],outputs[i],out,err) ;
	    if (Panlite_linewrap_width == 0 && !preparing_for_doc)
	       PlResetLineWrap(out) ;
	    }
	 else if ((size_t)merge != PL_MERGE_SEG && !preparing_for_doc)
	    PlResetLineWrap(out) ;
	 delete inputs[i] ;
	 delete outputs[i] ;
	 }
      }
   else
      {
      err << "error encountered while translating a batch of sentences" << endl ;
      for (size_t i = 0 ; i < num_lines ; i++)
	 {
	 if (inputs) delete inputs[i] ;
	 if (outputs) delete outputs[i] ;
	 }
      }
   FrFree(inputs) ;
   FrFree(outputs) ;
   return ;
}

//----------------------------------------------------------------------

int PlProcessLine(const char *line, istream &in, ostream &out,
		  ostream &err)
{
   if ((line && line[0] != '\0') ||
       preparing_for_doc || prepared_doc ||
       generate_lattice || generate_IBM_XML)
      {
      if (&out != &cout)
	 cout << "< " << line << endl ;
      if (PlIsCommand(line) && PlIsSafeCommand(line))
	 {
	 if (!PlProcessCommand(line,in,out,err))
	    {
	    out << ">Shutdown requested." << endl ;
	    return 0 ;			// no more input to process
	    }
	 if (&out != &cout)
	    cout << ">done" << endl ;
	 }
      else
	 {
	 FrList *lines = new FrList(new FrString(line)) ;
	 if (&out == &cout)
	    {
	    FrTextSpans *input ;
	    FrTextSpans *lattice
	       = PlTranslateSentence(lines,reference_translations,input,err) ;
	    PlApplyLM(input,lattice,out,err) ;
	    out << flush ;
	    delete input ;
	    delete lattice ;
	    }
	 else
	    {
	    char *translated = translate_sentence(lines,
						  reference_translations) ;
	    out << translated << flush ;
	    cout << "> " << translated << endl ;
	    FrFree(translated) ;
	    }
	 free_object(lines) ;
	 free_object(reference_translations) ;
	 reference_translations = 0 ;
	 if ((interactive_Panlite || Panlite_linewrap_width <= 0) &&
	     !preparing_for_doc)
	    PlResetLineWrap(out) ;
	 }
      }
   else
      {
      // empty input, so don't do anything except output the empty translation
      PlResyncLM(out) ;
      if (Panlite_network_mode)
	 {
	 cout << "> " << endl ;
	 PlResetLineWrap(out,true) ;	// keep in sync, always send something
	 }
      else
	 PlResetLineWrap(out,keep_empty_lines) ;
      if (chartfile)
	 {
	 FrTextSpans *lattice = new FrTextSpans("") ;
	 FrList *chart = lattice->printable() ;
	 (*chartfile) << chart << endl ;
	 free_object(chart) ;
	 delete lattice ;
	 }
      }
   return 1 ;				// done with line, but more to process
}

//----------------------------------------------------------------------

inline bool blank_line(const char *line)
{
   return line[0] == '\0' ;
}

//----------------------------------------------------------------------

static FrList *split_off_sentence(char *&linebuf, const char *sentbreak,
				  size_t &buflen, FrList *sentences,
				  size_t &numlines)
{
   // split the combined line into two pieces; put the first
   // piece on the list of sentences and move the second piece
   // up to the beginning of the accumulation buffer
   const char *sent = linebuf ;
   while (Fr_isspace(*sent))
      sent++ ;
   size_t sentlen = sentbreak - sent ;
   pushlist(new FrString(sent,sentlen),sentences) ;
   sentlen = sentbreak - linebuf ;
   numlines++ ;
   memcpy(linebuf,sentbreak,buflen-sentlen+1) ;
   buflen -= sentlen ;
   linebuf = FrNewR(char,linebuf,buflen+1) ;
   return sentences ;
}

//----------------------------------------------------------------------

static FrList *split_off_sentences(char *&linebuf, FrList *lines,
				   size_t &buflen, size_t &numlines,
				   ostream *out = 0)
{
   const char *sentbreak = FrSentenceBreak(linebuf,char_encoding,
					   freeform_maxlen) ;
   if (sentbreak)
      {
      while (sentbreak)
	 {
	 lines = split_off_sentence(linebuf,sentbreak,buflen,lines,numlines) ;
	 sentbreak = FrSentenceBreak(linebuf,char_encoding,
				     freeform_maxlen) ;
	 }
      }
   else if (out && interactive_Panlite)
      (*out) << "> " << flush ;
   return lines ;
}

//----------------------------------------------------------------------

FrList *PlSplitIntoSentences(char *&partial, char *line)
{
   if (!freeform_input)
      {
      FrFree(partial) ;
      partial = 0 ;
      return new FrList(new FrString(line ? line : "")) ;
      }
   FrList *sentences = 0 ;
   // if the new input line is empty or a command, the prior partial
   //   sentence is now complete
   if (!line || !*line)
      {
      pushlist(new FrString(partial ? partial : ""),sentences) ;
      partial = 0 ;
      }
   else if (PlIsCommand(line))
      {
      if (partial)
	 pushlist(new FrString(partial),sentences) ;
      pushlist(new FrString(line),sentences) ;
      partial = 0 ;
      }
   else
      {
      // append the new input to the prior partial sentence and check
      //   whether the result contains a sentence break
      size_t len1 = partial ? strlen(partial) : 0 ;
      size_t len2 = strlen(line) ;
      char *newline = FrNewR(char,partial,len1+len2+2) ;
      if (newline)
	 {
	 if (len1 > 0)
	    newline[len1++] = ' ' ; // ensure word break on line boundary
	 memcpy(newline+len1,line,len2+1) ;
	 size_t buflen = len1+len2 ;
	 size_t numlines = 0 ;
	 sentences = split_off_sentences(newline,sentences,buflen,numlines) ;
	 partial = newline ;
	 }
      else
	 FrNoMemory("while accumulating free-form sentence") ;
      }
   return listreverse(sentences) ;
}

//----------------------------------------------------------------------

static FrList *accumulate_lines(size_t batch_size, istream &in, ostream &out,
				char *&linebuf, size_t &buflen)
{
   FrList *lines = 0 ;
   size_t numlines = 0 ;
   bool is_cmd ;
   bool no_freeform = false ;
   bool will_merge = false ;
   bool reference_xlat = false ;
   if (batch_size >= PL_MERGE)
      {
      no_freeform = true ;
      will_merge = true ;
      }
   do {
      char line[FrMAX_LINE+1] ;
      FrChar16* line16 = (FrChar16*)line ;
      line16[0] = 0 ;
      Panlite_get_line(in,line,FrMAX_LINE) ;
      is_cmd = PlIsCommand(line) ;
      if (is_cmd && will_merge)
	 {
	 char *cmd = PlExtractCommandWord(out,line) ;
	 if (Fr_stricmp(cmd,"end") == 0)
	    {
	    if ((size_t)Panlite_lines_per_batch == PL_MERGE_REF)
	       reference_xlat = true ;
	    Panlite_lines_per_batch = Panlite_prev_batchsize ;
	    }
	 else if (Fr_stricmp(cmd,"enddoc") != 0)
	    is_cmd = false ;		// include commands other than :END
	 				//   and :ENDDOC
	 FrFree(cmd) ;
	 }
      if (line[0] == '.')		// treat any "dot"-commands for other
	 is_cmd = true ;		//   programs as a paragraph break
      // flush all buffered data on paragraph break or embedded command
      if (buflen > 0 && (is_cmd || blank_line(line)))
	 {
	 FrString *new_line = new FrString(linebuf) ;
	 pushlist(new_line,lines) ;
	 if (preparing_for_doc)
	    pushlist(new_line ? new_line->deepcopy() : 0,prepared_doc) ;
	 numlines++ ;
	 FrFree(linebuf) ;
	 linebuf = 0 ;
	 buflen = 0 ;
	 }
      if (in.eof() || in.fail())
	 break ;
      if (reference_xlat)
	 {
	 reference_translations = lines ;
	 lines = 0 ;
	 numlines = 0 ;			// read one more line of input
	 batch_size = 1 ;
	 }
      if (freeform_input && !no_freeform && !is_cmd && *line)
	 {
	 // combine the new input line with any previously-buffered data
	 size_t linelen = strlen(line) ;
	 size_t newlen = buflen + linelen + 1 ;
	 char *newbuf = FrNewR(char,linebuf,newlen+1) ;
	 if (!newbuf)
	    {
	    FrNoMemory("while accumulating multi-line sentence") ;
	    break ;
	    }
	 linebuf = newbuf ;
	 if (buflen > 0)
	    linebuf[buflen++] = ' ' ;	// ensure word break on line boundary
	 strcpy(linebuf+buflen,line) ;
	 buflen += linelen ;
	 lines = split_off_sentences(linebuf,lines,buflen,numlines,&out) ;
	 }
      else
	 {
	 FrString *new_line = new FrString(line) ;
	 pushlist(new_line,lines) ;
	 if (preparing_for_doc)
	    pushlist(new_line ? new_line->deepcopy() : 0,prepared_doc) ;
	 numlines++ ;
	 }
      } while (numlines < batch_size && !is_cmd) ;
   return listreverse(lines) ;
}

//----------------------------------------------------------------------

void PlProcessInput(istream &in,ostream &out, ostream &err)
{
   char *linebuf = 0 ;
   size_t buflen = 0 ;
   bool stop = false ;
   PLConfig::startupComplete() ;	// switch from STARTUP to RUNTIME vars
   while (!in.eof() && !in.fail() && !stop)
      {
      size_t batch_size = Panlite_batch_mode ? Panlite_lines_per_batch : 1 ;
      int merge = PL_MERGE_NONE ;
      if ((size_t)Panlite_lines_per_batch >= PL_MERGE)
	 {
	 merge = Panlite_lines_per_batch ;
	 batch_size = Panlite_lines_per_batch ;
	 }
      FrList *lines = accumulate_lines(batch_size,in,out,linebuf,buflen) ;
      if (lines && lines->rest())
	 translate_sentences(lines,in,out,err,merge) ;
      else if (lines)
	 {
	 FrString *line = (FrString*)lines->first() ;
	 if (!PlProcessLine((char*)line->stringValue(),in,out,err))
	    stop = true ;
	 }
      free_object(lines) ;
      if (show_Panlite_memusage && verbose)
	 FrMemoryStats(cerr) ;
      }
   FrFree(linebuf) ;
   if (Panlite_batch_mode)
      PlResetLineWrap(out) ;
   out.flush() ;
   return ;
}

//----------------------------------------------------------------------

static bool prepare_doc(MEMTEngine *eng, va_list args)
{
   FrVarArg2(bool,int,starting) ;
   FrVarArg(ostream*,err) ;
   FrVarArg(bool*,success) ;
   if (!eng->prepareDoc((bool)starting,*err,verbose))
      *success = false ;
   return true ;
}

//----------------------------------------------------------------------

bool PlPrepareForDocument(bool starting, istream &in, ostream &out,
			  ostream &err, bool replay)
{
   if (starting == preparing_for_doc)
      return false ;
   // inform all the translation engines of the change in status
   bool success = true ;
   MEMTEngine::iterate(ET_Xlat,FrComp_Equal,prepare_doc,starting,&err,
			 &success) ;
   // inform the decoder of the change in status
   MEMTEngine::iterate(ET_Decode,FrComp_Equal,prepare_doc,starting,&err,
			 &success) ;
   if (!lm_engine.isRunning() && chartfile)
      {
      if (starting)
	 (*chartfile) << "PREPDOC" << endl ;
      else
	 (*chartfile) << "ENDPREP" << endl ;
      }
   if (verbose)
      err << endl ;
   if (starting)
      preparing_for_doc = true ;
   else
      {
      preparing_for_doc = false ;
      // replay the lines we've accumulated while preparing for the document
      if (prepared_doc)
	 free_object(poplist(prepared_doc)) ; // eliminate :ENDDOC
      prepared_doc = listreverse(prepared_doc) ;
      while (prepared_doc)
	 {
	 FrString *line = (FrString*)poplist(prepared_doc) ;
	 if (replay && !PlProcessLine((char*)line->stringValue(),in,out,err))
	    success = false ;
	 free_object(line) ;
	 if (replay && verbose && show_Panlite_memusage)
	    FrMemoryStats(cout) ;
	 }
      FramepaC_gc() ;
      if (show_Panlite_memusage)
	 FrMemoryStats(cout) ;
      }
   return success ;
}

//----------------------------------------------------------------------

const char *PlGetGenre()
{
   return active_genre ? active_genre : "*" ;
}

//----------------------------------------------------------------------

bool PlSetGenre(const char *genre)
{
   bool success = MEMTEngine::selectGenreAll(genre) ;
   if (success)
      {
      FrFree(active_genre) ;
      active_genre = FrDupString(genre) ;
      }
   return success ;
}

// end of file plmain.cpp //
