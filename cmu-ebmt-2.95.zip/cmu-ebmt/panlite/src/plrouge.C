/************************************************************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.95							*/
/*	 by Ralf Brown							*/
/*									*/
/*  File plrouge.cpp		ROUGE scoring metrics			*/
/*  LastEdit: 07apr10							*/
/*									*/
/*  (c) Copyright 2010 Ralf Brown					*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "plrouge.h"
#include "plglobal.h"

/************************************************************************/
/*	Methods for class PlRougeS					*/
/************************************************************************/

PlRougeS::PlRougeS(const FrList *sentences, size_t max_skip)
{
   m_maxskip = max_skip ;
   m_numrefs = sentences->simplelistlength() ;
   m_bigrams = FrNewC(FrHashTable*,m_numrefs) ;
   m_reflen = FrNewC(size_t,m_numrefs) ;
   if (!m_bigrams || !m_reflen)
      {
      FrFree(m_bigrams) ;	m_bigrams = 0 ;
      FrFree(m_reflen) ;	m_reflen = 0 ;
      m_numrefs = 0 ;
      sentences = 0 ;
      }
   for (size_t i = 0 ; sentences ; sentences = sentences->rest(), i++)
      {
      m_bigrams[i] = makeSkipBigrams(sentences->first(),maxSkip(),
				     m_reflen[i]) ;
      }
   return ;
}

//----------------------------------------------------------------------

PlRougeS::~PlRougeS()
{
   for (size_t i = 0 ; i < numReferences() ; i++)
      {
      delete m_bigrams[i] ;
      }
   FrFree(m_bigrams) ;
   FrFree(m_reflen) ;
   m_bigrams = 0 ;
   m_maxskip = 0 ;
   return ;
}

//----------------------------------------------------------------------

static FrString *make_bigram(const char *word1, const char *word2)
{
   char *s = Fr_aprintf("%s\t%s",word1,word2) ;
   return new FrString(s,strlen(s),1,false) ;
}

//----------------------------------------------------------------------

FrHashTable *PlRougeS::makeSkipBigrams(const FrObject *sentence,
				       size_t maxskip, size_t &sentlen)
{
   FrHashTable *ht = new FrHashTable ;
   if (!ht)
      {
      FrNoMemory("while making skip-bigrams table") ;
      return 0 ;
      }
   sentlen = 0 ;
   if (maxskip > 9)
      maxskip = 9 ;
   if (sentence && sentence->stringp())
      {
      const char *sent = FrPrintableName(sentence) ;
      FrList *words = FrCvtString2Symbollist(sent,char_encoding) ;
      sentlen = words->listlength() ;
      ht->expandTo(sentlen * sentlen / 2) ;
      for (FrList *wl = words ; wl ; wl = wl->rest())
	 {
	 const char *firstword = FrPrintableName(wl->first()) ;
	 FrList *tail = wl->rest() ;
	 for (size_t skip = 0 ;
	      skip <= maxskip && tail ;
	      tail = tail->rest(), skip++)
	    {
	    const char *secondword = FrPrintableName(tail->first()) ;
	    FrString *bigram = make_bigram(firstword,secondword) ;
	    FrHashEntryObject key(bigram,(void*)1,false) ;
	    FrHashEntryObject *entry = (FrHashEntryObject*)ht->lookup(&key) ;
	    if (entry)
	       {
	       entry->setUserData((void*)((size_t)entry->getUserData()+1)) ;
	       }
	    else
	       ht->add(&key) ;
	    }
	 }
      free_object(words) ;
      }
   else
      FrProgError("arg to makeSkipBigrams must be a FrString") ;
   return ht ;
}

//----------------------------------------------------------------------

static size_t combinations2(size_t total)
{
   return total * (total - 1) / 2 ;
}

//----------------------------------------------------------------------

static size_t num_combinations(size_t sent_len, size_t max_skip)
{
   size_t combos = combinations2(min(sent_len,max_skip + 2)) ;
   if (sent_len > max_skip + 2)
      combos += (sent_len - max_skip - 2) * (max_skip + 1) ;
   return combos ;
}

//----------------------------------------------------------------------

static bool count_matches(FrHashEntry *e, va_list args)
{
   FrVarArg(const FrHashTable *,ref_ht) ;
   FrVarArg(size_t*,matches) ;
   FrHashEntryObject *ref = (FrHashEntryObject*)ref_ht->lookup(e) ;
   if (ref)
      {
      FrHashEntryObject *hyp = reinterpret_cast<FrHashEntryObject*>(e) ;
      size_t ref_count = (size_t)ref->getUserData() ;
      size_t hyp_count = (size_t)hyp->getUserData() ;
      *matches += min(ref_count,hyp_count) ;
      }
   return true ;
}

//----------------------------------------------------------------------

static size_t count_matches(FrHashTable *hyp_ht,
			    const FrHashTable *ref_ht)
{
   size_t matches = 0 ;
   if (hyp_ht && ref_ht)
      {
      hyp_ht->doHashEntries(count_matches,ref_ht,&matches) ;
      }
   return matches ;
}

//----------------------------------------------------------------------

double PlRougeS::score(FrHashTable *hyp_ht, size_t hyp_len,
		       const FrHashTable *ref_ht, size_t ref_len,
		       size_t max_skip)
{
   if (hyp_ht && ref_ht)
      {
      size_t matches = count_matches(hyp_ht,ref_ht) ;
      double prec = matches / (double)num_combinations(hyp_len,max_skip) ;
      double recall = matches / (double)num_combinations(ref_len,max_skip) ;
      return FrMath::F_measure(opt_rouge_beta,prec,recall) ;
      }
   else
      return 0.0 ;
}

//----------------------------------------------------------------------

size_t PlRougeS::referenceLength(size_t N) const
{
   return (N < numReferences()) ? m_reflen[N] : 0 ;
}

//----------------------------------------------------------------------

double PlRougeS::score(const FrObject *sentence) const
{
   double best_score = 0.0 ;
   if (sentence && numReferences())
      {
      size_t hyp_len ;
      FrHashTable *hyp = makeSkipBigrams(sentence,maxSkip(),hyp_len) ;
      if (hyp && hyp->currentSize() > 0)
	 {
	 for (size_t i = 0 ; i < numReferences() ; i++)
	    {
	    double sc = score(hyp,hyp_len,m_bigrams[i],m_reflen[i],
			      maxSkip()) ;
	    if (sc > best_score)
	       best_score = sc ;
	    }
	 }
      delete hyp ;
      }
   return best_score ;
}

// end of file plrouge.cpp //
