/************************************************************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File panlite.cpp		main program				*/
/*  LastEdit: 06apr10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2006,2007,2009,2010 Ralf Brown				*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "FramepaC.h"
#include "frlowio.h"
#include "plbanner.h"
#include "plconfig.h"
#include "plengine.h"
#include "panlite.h"
#include "plglobal.h"

#ifdef FrSTRICT_CPLUSPLUS
# include <cstdlib>
# include <fstream>
# include <iomanip>
#else
# include <fstream.h>
# include <iomanip.h>
# include <stdlib.h>
#endif /* FrSTRICT_CPLUSPLUS */

/************************************************************************/
/*    Manifest constants for this module				*/
/************************************************************************/

#define WINDOWS_TITLEBAR "MEMT"

// default number of lines to process in a single batch in batch mode
#define LINES_PER_BATCH 10

/************************************************************************/
/*    Forward declarations						*/
/************************************************************************/

/************************************************************************/
/*    Types for this module						*/
/************************************************************************/

/************************************************************************/
/*    Global variables							*/
/************************************************************************/

extern bool complete_banner_when_redirected ;

static FrTimer runtime ;

static int port_number = 0 ;
static char *host_name = 0 ;
static bool initiate_connection = false ;
static int run_optimizer = 0 ;
static PlOptimizerType optimize_type = Opt_Perceptron ;
static size_t optimize_nbest = 1000 ;
static size_t optimize_passes = OPTIMIZER_PASSES ;
static double optimize_lambda = OPTIMIZER_LAMBDA ;
static double optimize_converge = ORACLE_CONVERGENCE ;

extern PLConfig *pl_config ;

static MEMTServer *Panlite_server ;

//----------------------------------------------------------------------

#if defined(__WINDOWS__) || defined(__NT__)
extern "C" char __WinTitleBar[] = WINDOWS_TITLEBAR ;
#endif /* __WINDOWS__ || __NT__ */

/************************************************************************/
/*	Space-Savers							*/
/************************************************************************/

// since we will never create an EBMT index, the following function can
// never be called, so make a dummy version to avoid pulling in all of the
// token-file conversion code (12K or so)
bool convert_token_file(const char *, class EBMTIndex *)
{
   return false ;
}

/************************************************************************/
/*    Helper functions							*/
/************************************************************************/

static void usage(const char *argv0,ostream &err)
{
   display_banner(err) ;
   err << "Usage: " << argv0 << " [options]" << endl ;
   err << "Options:\n"
	 "\t-b[N]\tbatch N (default 10) lines at a time for less thrashing\n"
	 "\t-cFILE\tstore generated charts in 'FILE' for later use\n"
         "\t-f\tfree-form input, rather than sentence-per-line\n"
	 "\t-g\tbeing run by TONGUES user interface\n"
	 "\t-l\tgenerate lattice (chart) to output instead of translation\n"
	 "\t-lw\tgenerate lattice with chart-walk in INPUT field\n"
	 "\t-ll\toutput results as lattice in SMTstub format\n"
	 "\t-lt\toutput results as lattice in SMT .td format\n"
	 "\t-lx\toutput results in IBM/Rosetta XML format\n"
	 "\t-m-\tdon't use morphology file\n"
	 "\t-n[N]\trun in network mode, on port N (default "
	 << DEFAULT_PANLITE_PORTNUM << ")\n"
	 "\t-Nhst:N\tinitiate network connection to port N on 'hst'\n"
         "\t-On\trun parameter optimizer for a maximum of 'n' iterations\n"
	 "\t-q\trun quietly (no banner or shutdown messages)\n"
	 "\t-sFILE\tuse configuration file 'FILE' instead of default\n"
	 "\t-u\tshow memory usage\n"
	 "\t-Uxxx\tperform I/O using character encoding 'xxx'\n"
	 "\t-Ub\tperform I/O using byte-swapped Unicode characters\n"
	 "\t-v\tverbose operation\n"
	 "\t-wN\twrap lines at column N (default = 0 -- no wrapping)\n"
	 "\t-Ex\ttoggle use of engine 'x'\n"
	 "\t-E+x\tenable use of engine 'x'\n"
	 "\t-E-x\tdisable use of engine 'x'\n"
	 "\t-Lx\ttoggle the :LEARN command for engine 'x'\n"
	 "\t-L+x\tenable the :LEARN command for engine 'x'\n"
	 "\t-L-x\tdisable the :LEARN command for engine 'x'\n"
	 "\t-:\tpermit colon commands when reading text from a file\n"
	  << endl ;
   exit(1) ;
}

//----------------------------------------------------------------------

static void check_interactivity()
{
   if (!isatty(fileno(stdin)))
      interactive_Panlite = false ;
   if (Panlite_batch_mode && interactive_Panlite)
      cerr << "Warning: in batch mode (-b), no commands are available, and\n"
	    "input is not processed immediately." << endl ;
   return ;
}

/************************************************************************/
/*    program setup functions						*/
/************************************************************************/

static bool load_engine_config(const char *filename, PLConfig *config)
{
   for (FrList *eng = config->engine_names ; eng ; eng = eng->rest())
      {
      const char *eng_name = FrPrintableName(eng->first()) ;
      if (eng_name)
	 {
	 const char *name = eng_name ;
	 if (name[0] == ':')
	    name++ ;
	 char *section = Fr_aprintf("MEMTEngine-%s",name) ;
	 char *eng_name_ptr = (char*)eng_name ;
	 FrSymbol *eng_tag = (FrSymbol*)string_to_FrObject(eng_name_ptr) ;
	 PlEngineConfig *engcfg = new PlEngineConfig(eng_name,eng_tag) ;
	 if (engcfg)
	    {
	    engcfg->load(filename,section) ;
	    engcfg->setNext(config->engines) ;
	    config->engines = engcfg ;
	    }
	 FrFree(section) ;
	 }
      }
   return true ;
}

//----------------------------------------------------------------------

static bool load_setup_file(const char *filename)
{
   if (FrFileReadable(filename))
      {
      char *base_directory = FrFileDirectory(filename) ;
      pl_config = new PLConfig(base_directory) ;
      FrFree(base_directory) ;
      if (pl_config)
	 {
	 pl_config->load(filename,"MEMT") ;
//	   pl_config->dump(cout) ;
	 load_engine_config(filename,pl_config) ;
	 return true ;
	 }
      }
   else
      pl_config = 0 ;
   return false ;
}

//----------------------------------------------------------------------

static bool try_loading_setup(const char *dir, const char *basename)
{
   char *filename = FrAddDefaultPath(basename,dir) ;
   if (!filename)
      {
      FrNoMemory("while trying to load configuration file") ;
      return false ;
      }
   bool success = load_setup_file(filename) ;
   FrFree(filename) ;
   return success ;
}

//----------------------------------------------------------------------

static void get_setup_file(const char *filespec, const char *argv0)
{
   if (strcmp(filespec,".") != 0)
      {
      if (load_setup_file(filespec))
	 return ;
      else
	 cerr << "unable to open specified setup file, "
		 "will use default file" << endl ;
      }
   // if we get here, either no setup file was specified, or unable to open it
   // so, try to load panlite.cfg from the current directory, then .panlite.cfg
   // from user's home directory, and finally panlite.cfg from the directory
   // containing the executable
   const char *cfg = DEFAULT_PANLITE_CFGFILE ;
   if (try_loading_setup(".",cfg))
      return ;
   char *homedir = getenv("HOME") ;
   if (homedir && *homedir)
      {
#if defined(unix)
      if (try_loading_setup(homedir,"."DEFAULT_PANLITE_CFGFILE))
	 return ;
#else
      if (try_loading_setup(homedir,DEFAULT_PANLITE_CFGFILE))
	 return ;
#endif /* unix */
      }
   char *dir = FrFileDirectory(argv0) ;
   if (!dir)
      return ;
   try_loading_setup(dir,cfg) ;
   FrFree(dir) ;
   return ;
}

//----------------------------------------------------------------------

static void set_flag_var(bool &flag, char option)
{
   if (option == '+')
      flag = true ;
   else if (option == '-')
      flag = false ;
   else
      flag = !flag ;
   return ;
}

//----------------------------------------------------------------------

static void toggle_engine(const PLConfig *config, const char *name,
			  char option)
{
   if (!name)
      return ;
   PlEngineConfig *engine = PlFindEngineConfig(config,makeSymbol(name)) ;
   if (!engine)
      return ;
   if (option == '+')
      engine->enable(true) ;
   else if (option == '-')
      engine->enable(false) ;
   else
      engine->enable(!engine->isEnabled()) ;
   if (engine->isEnabled())		// if at any point we enable the
      engine->forceStart(true) ;	//   eng, load even if later disabled
   return ;
}

//----------------------------------------------------------------------

static void toggle_engine_updates(const PLConfig *config, const char *name,
				  char option)
{
   if (!name)
      return ;
   PlEngineConfig *engine = PlFindEngineConfig(config,makeSymbol(name)) ;
   if (!engine)
      return ;
   if (option == '+')
      engine->updateable(true) ;
   else if (option == '-')
      engine->updateable(false) ;
   else
      engine->updateable(!engine->isUpdateable()) ;
   return ;
}

//----------------------------------------------------------------------

static void extract_hostname_and_port(const char *parm, char *&host_name,
				      int &port_number)
{
#ifdef FrUSING_SOCKETS
   FrFree(host_name) ;
   host_name = FrDupString(parm) ;
   if (!host_name)
      return ;
   char *colon = strchr(host_name,':') ;
   if (colon)
      {
      *colon = '\0' ;			// strip off port number
      port_number = atoi(colon+1) ;	// get port number into variable
      initiate_connection = true ;	// yes, we want to initiate the conn.
      Panlite_network_mode = true ;
      }
   else
      {
      port_number = -1 ;
      FrFree(host_name) ;
      host_name = 0 ;
      cerr << "; You must specify both hostname and port for -N" << endl ;
      }
#else
   (void)parm ;
   host_name = 0 ;
   port_number = -1 ;
#endif /* FrUSING_SOCKETS */
   return ;
}

//----------------------------------------------------------------------

static void parse_opt_params(const char *args)
{
   if (isalpha(*args))
      {
      if (*args == 'p')
	 optimize_type = Opt_Perceptron ;
      else if (*args == 'm')
	 optimize_type = Opt_MIRA ;
      else if (*args == 'a')
	 optimize_type = Opt_Anneal ;
      else if (*args == 's')
	 optimize_type = Opt_SVM ;
      else if (*args == 'c')
	 optimize_type = Opt_CRF ;
      args++ ;
      }
   char *arg_end ;
   run_optimizer = strtol(args,&arg_end,0) ;
   if (*arg_end == ',')
      {
      args = arg_end + 1 ;
      optimize_nbest = strtol(args,&arg_end,0) ;
      if (*arg_end == ',')
	 {
	 args = arg_end + 1 ;
	 optimize_converge = strtod(args,&arg_end) ;
	 if (arg_end == args)
	    optimize_converge = ORACLE_CONVERGENCE ;
	 else if (*arg_end == ',')
	    {
	    args = arg_end + 1 ;
	    optimize_passes = strtol(args,&arg_end,0) ;
	    if (*arg_end == ',')
	       {
	       args = arg_end + 1 ;
	       optimize_lambda = strtod(args,&arg_end) ;
	       if (arg_end == args)
		  optimize_lambda = OPTIMIZER_LAMBDA ;
	       }
	    }
	 }
      }
   if (optimize_nbest == 0)
      optimize_nbest = 1000 ;
   if (optimize_passes < 1)
      optimize_passes = 1 ;
   return ;
}

//----------------------------------------------------------------------

static void process_cmdline(int argc, char **argv,ostream &err)
{
   const char *argv0 = argv[0] ;
   for (int i = 1 ; i < argc ; i++)
       if (argv[i][0] == '-' && argv[i][1] == 's' && argv[i][2])
	  {
	  get_setup_file(argv[i]+2,argv0) ;
	  break ;
	  }
   if (!pl_config)
      {
      get_setup_file(".",argv[0]) ;
      if (!pl_config)
	 {
	 usage(argv0,err) ;
	 exit(1) ;
	 }
      }
   if (pl_config->socketnum == 0)
      pl_config->socketnum = DEFAULT_PANLITE_PORTNUM ;
   memt_vars.applyConfiguration(pl_config) ;
   if (abbrevs_filename)
      abbrevs_list = FrLoadAbbreviationList(abbrevs_filename) ;
   MEMTEngine::setupComplete() ;
   while (argc > 1)
      {
      if (argv[1][0] == '-')
	 {
	 char option = argv[1][2] ;
	 switch (argv[1][1])
	    {
	    case 'b':
	        Panlite_batch_mode = true ;
		if (option)
		   Panlite_lines_per_batch = atoi(argv[1]+2) ;
		if (Panlite_lines_per_batch <= 0)
		   Panlite_lines_per_batch = LINES_PER_BATCH ;
		break ;
	    case 'c':
	        Panlite_chartfilename = FrDupString(argv[1]+2) ;
		break ;
	    case 'f':
	       set_flag_var(freeform_input,option) ;
	       break ;
	    case 'g':
	       complete_banner_when_redirected = true ;
	       break ;
	    case 'l':
		if (Fr_toupper(option) == 'S')
		   {
		   lattice_lists_source = true ;
		   set_flag_var(generate_lattice,argv[1][3]) ;
		   }
		else if (option == 't')
		   {
		   lattice_in_transducer_format = true ;
		   set_flag_var(generate_lattice,argv[1][3]) ;
		   }
		else if (option == 'l')
		   {
		   lattice_in_smtstub_format = true ;
		   set_flag_var(generate_lattice,argv[1][3]) ;
		   }
		else if (option == 'x')
		   {
		   set_flag_var(generate_IBM_XML,argv[1][3]) ;
		   if (generate_IBM_XML)
		      generate_lattice = false ;
		   }
		else if (Fr_toupper(option) == 'W')
		   {
		   lattice_lists_source = false ;
		   set_flag_var(generate_lattice,argv[1][3]) ;
		   }
		else
		   set_flag_var(generate_lattice,option) ;
		break ;
	    case 'n':
		if (option)
		   port_number = atoi(argv[1]+2) ;
		if (port_number == 0)
		   port_number = DEFAULT_PANLITE_PORTNUM ;
		pl_config->socketnum = port_number ;
#ifdef FrUSING_SOCKETS
		Panlite_network_mode = true ;
#else
		err << "Network mode is not available" << endl ;
#endif /* FrUSING_SOCKETS */
		break ;
	    case 'N':
	        extract_hostname_and_port(argv[1]+2,host_name,port_number) ;
		pl_config->socketnum = port_number ;
	        break ;
	    case 'O':
	        parse_opt_params(argv[1]+2) ;
		break ;
	    case 'q':
	    case 'Q':
	        set_flag_var(quiet_mode,option) ;
		break ;
	    case 's':
		// do nothing, we already processed it
		break ;
	    case 'u':
		set_flag_var(show_Panlite_memusage,option) ;
		break ;
	    case 'U':
	        if (option == 'b')
		   {
		   Unicode_bswap = true ;
		   char_encoding = FrParseCharEncoding(argv[1]+3) ;
		   }
		else
		   {
		   char_encoding = FrParseCharEncoding(argv[1]+2) ;
		   }
		if (char_encoding == FrChEnc_Unicode)
		   {
		   cout << "Sorry, 16-bit Unicode not supported at this time"
			<< endl ;
		   exit(1) ;
		   }
		break ;
	    case 'v':
		set_flag_var(verbose,option) ;
		break ;
	    case 'w':
		Panlite_linewrap_width = atoi(argv[1]+2) ;
		break ;
	    case 'E':
	        if (option == '+' || option == '-')
	           toggle_engine(pl_config,argv[1]+3,option) ;
		else
		   toggle_engine(pl_config,argv[1]+2,'\0') ;
		break ;
	    case 'L':
	        if (option == '+' || option == '-')
	           toggle_engine_updates(pl_config,argv[1]+3,option) ;
		else
		   toggle_engine_updates(pl_config,argv[1]+2,'\0') ;
		break ;
	    case ':':
	        set_flag_var(allow_colon_commands,option) ;
		break ;
	    default:
		usage(argv0,err) ;
		break ;
	    }
	 }
      else
	 usage(argv0,err) ;
      argv++ ;
      argc-- ;
      }
   if (Panlite_chartfilename)
      chartfile = new ofstream(Panlite_chartfilename,ios::app) ;
   else
      chartfile = 0 ;
   return ;
}

/************************************************************************/
/************************************************************************/

static void terminate_program(int exitcode)
{
   if (!quiet_mode)
      cout << "\n" PROGRAM_NAME " v" PANLITE_VERSION_STR
	      " shutting down (please wait)" << endl ;
   if (Panlite_server)
      {
      delete Panlite_server ;
      Panlite_server = 0 ;
      }
   PlShutdownPrograms(cout,cerr) ;
   memt_vars.freeVariables() ;
   if (show_Panlite_memusage && !quiet_mode)
      {
      FrMemoryStats(cerr) ;
      if (verbose)
	 {
	 FramepaC_gc() ;
	 cerr << "After reclaiming memory:" << endl ;
	 FrMemoryStats(cerr) ;
	 cerr << "\nUnfreed strings:" << endl ;
	 FrString::dumpUnfreed(cerr) ;
	 }
      }
   if (!quiet_mode)
      goodbye_message(cerr) ;
   if (!Panlite_network_mode)
      {
      FrDestroyWindow() ;
      }
   if (!quiet_mode)
      cout << "Total run time: " << setprecision(6) << runtime.readsec()
	   << " seconds for " << sentences_translated << " translations"
	   << endl ;
   Panlite_clear_word_delimiters() ;
   FrFreeNamedEntitySpec(named_entity_spec) ;
   PlRestoreErrors() ;
   PlRestoreSignals() ;
   FrShutdown() ;
   FrExitProcess(exitcode) ;
   return ;
}

//----------------------------------------------------------------------

static void run_network_mode(int port_number)
{
#ifdef FrUSING_SOCKETS
   istream *in = &cin ;
   ostream *out = &cout ;
   ostream *err = &cerr ;
   if (FrInitiateConnection(host_name,port_number,in,out,err))
      {
      display_banner(*out) ;
      welcome_message(*out) ;
      if (generate_IBM_XML)
	 PlOutputXMLHeader(*out) ;
      PlProcessInput(*in,*out,*err) ;
      if (generate_IBM_XML)
	 PlOutputXMLFooter(*out) ;
      }
   else
      {
      (*err) << "Unable to initiate network connection!" << endl ;
      terminate_program(EXIT_FAILURE) ;
      }
#endif /* FrUSING_SOCKETS */
   return ;
}

//----------------------------------------------------------------------

static void run_network_server()
{
   Panlite_server = new MEMTServer(pl_config->socketnum) ;
   Panlite_server->setUnicode(char_encoding == FrChEnc_Unicode,Unicode_bswap) ;
   Panlite_server->setEUC(char_encoding == FrChEnc_EUC) ;
   if (Panlite_server && Panlite_server->good())
      {
      Panlite_server->wantCanonical(false) ;	// don't canonicalize lines
      FrMinimizeWindow() ;			//  as it will be done later
      Panlite_network_mode = true ;
      do {
	 // keep looping every time that the wait for a new connection times
	 // out
	 } while (!Panlite_server->run()) ;
      Panlite_network_mode = false ;
      }
   delete Panlite_server ;
   Panlite_server = 0 ;
   return ;
}

/************************************************************************/
/************************************************************************/

int
#ifndef __WATCOMC__
   __FrCDECL
#endif
   main(int argc, char **argv)
{
   initialize_FramepaC() ;
   process_cmdline(argc,argv,cerr) ;
   if (!quiet_mode)
      display_banner(cout) ;
   if (!PlExecPrograms(pl_config,cerr))
      {
      cout << "Program load failed -- bailing out...." << endl ;
      return 1 ;
      }
   check_interactivity() ;
   PlTrapSignals() ;
   PlTrapErrors() ;
   if (!word_delimiters)
      {
      char *delim = FrNewN(char,256) ;
      if (delim)
	 memcpy(delim,FrStdWordDelimiters(char_encoding),256) ;
      word_delimiters = delim ;
      }
   xml_input = false ;
   no_input_yet = true ;
   if (run_optimizer != 0)
      {
      welcome_message(cerr) ;
      PlOptimizeParameters(cin,cout,optimize_type,optimize_nbest,run_optimizer,
			   optimize_passes,optimize_lambda,optimize_converge) ;
      }
   else if (pl_config && pl_config->socketnum > 0)
      {
      if (initiate_connection)
	 run_network_mode(port_number) ;
      else
	 run_network_server() ;
      }
   else
      {
      welcome_message(cerr) ;
      if (generate_IBM_XML)
	 PlOutputXMLHeader(cout) ;
#if defined(_MSC_VER) && _MSC_VER >= 800
#define BUFFER_SIZE 4096
      char buffer[BUFFER_SIZE] ;
      istream *in ;
      if (!isatty(stdin))
	 {
	 in = new ifstream(fileno(stdin),buffer,BUFFER_SIZE) ;
	 if (!in || !in->good())
	    {
	    delete in ;
	    in = &cin ;
	    }
	 }
      else
	 in = &cin ;
      PlProcessInput(*in,cout,cerr) ;
      if (in != &cin)
	 delete in ;
#else
      PlProcessInput(cin,cout,cerr) ;
#endif /* _MSC_VER */
      if (generate_IBM_XML)
	 PlOutputXMLFooter(cout) ;
      }
   delete pl_config ;
   terminate_program(0) ;
   return 0 ;
}

// end of file panlite.cpp //
