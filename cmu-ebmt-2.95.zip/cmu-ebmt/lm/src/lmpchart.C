/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmpchart.cpp		class ParseChart and associated funcs	*/
/*  LastEdit: 13apr10							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,1999,2000,2001,2002,2003	*/
/*		2004,2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "lmpchart.h"
#include "lmengine.h"
#include "lmglobal.h"
#include "ebutil.h"	// for EbFixDottedList

size_t LmCountWords(const char *text) ;

/************************************************************************/
/*	Manifest Constants for this module				*/
/************************************************************************/

#define INTERNAL_NBEST 	   5	// number of refills for Options:CHECK_NBEST
#define NEW_ENGINE_WEIGHT  0.001
#define DUMMY_ARC_QUALITY  0.001
#define DUMMY_ARC_WEIGHT   0.001

/************************************************************************/
/*    Global data limited to this module				*/
/************************************************************************/

static const char *lm_arc_tag = ":LM" ;

static size_t num_parsecharts = 0 ;

/************************************************************************/
/*    Helper functions							*/
/************************************************************************/

#ifdef NDEBUG1
# define print_successor(cur,suc,gap,src,trg,fill)
#else
#include "ebmt.h"
static void print_source(const ChartArc *arc)
{
   const WordInfo *info = arc->sourceWordInfo() ;
   for (size_t i = 0 ; i < arc->sourceWordSpan() ; i++)
      {
      if (info[i].surface())
	 cout << ' ' << info[i].surface() ; 
      else
	 cout << " {}" ;
      }
}

static void print_sources(const ChartArc *arc)
{
   cout << " <<composite: " ;
   const char *sep = "" ;
   for (size_t i = 0 ; i < arc->numSubsumedArcs() ; i++)
      {
      const ChartArc *sub = arc->subsumedArc(i) ;
      if (sub)
	 {
	 cout << sep ; 
	 print_source(sub) ;
	 sep = "|" ;
	 }
      }
   cout << ">> " ;
   return ;
}

static void print_target(const ChartArc *arc)
{
   if (arc->arcLength() == 0)
      cout << " {epsilon}" ;
   for (size_t i = 0 ; i < arc->arcLength() ; i++)
      {
      const TargetWord *tw = arc->targetWordInfo(i) ;
      if (tw)
	 {
	 cout << ' ' << FrPrintableName(tw->name()) ;
	 const FrSymbol *cl = tw->matchClass() ;
	 if (cl && !tw->isGapMarker())
	    cout << '[' << cl << ']' ;
	 }
      }
   return ;
}

static void print_successor(const ChartArc *curr_arc,
			    const ChartArcSuccessor *successor)
{
   size_t srcoverlap = successor->sourceOverlap() ;
   size_t trgoverlap = successor->targetOverlap() ;
   if (trace > 5 && (verbose || successor->reordering() == 0 || trace > 10) &&
       (srcoverlap + trgoverlap > 0 || trace > 12))
      {
      cout << "Possible successor for "
	   << curr_arc->startPosition() << "/" << curr_arc->endPosition()
	   << " @ " << successor->arc()->startPosition() << "/"
	   << successor->arc()->endPosition()
	   << ": " << endl ;
      cout << "\tsrc (" << srcoverlap << "):" ;
      if (curr_arc->numSubsumedArcs() > 0)
	 print_sources(curr_arc) ;
      else
	 print_source(curr_arc) ;
      cout << " ==>" ;
      if (successor->arc()->numSubsumedArcs() > 0)
	 print_sources(successor->arc()) ;
      else
	 print_source(successor->arc()) ;
      cout << endl ;
      cout << "\ttrg (" << trgoverlap << "):" ;
      print_target(curr_arc) ;
      cout << " ==>" ;
      print_target(successor->arc()) ;
      cout << endl ;
      }
   return ;
}
#endif

//----------------------------------------------------------------------

static bool equivalent_arc(const ChartArc *arc1, const ChartArc *arc2)
{
   if (arc1->startPosition() == arc2->startPosition() &&
       arc1->coverage() == arc2->coverage() &&
       arc1->arcLength() == arc2->arcLength())
      {
      // the arcs cover the same source span and have the same number of
      //   words on the target side, so check whether the target words
      //   are equivalent
      for (size_t i = 0 ; i < arc1->arcLength() ; i++)
	 {
	 const TargetWord *tw1 = arc1->targetWordInfo(i) ;
	 const TargetWord *tw2 = arc2->targetWordInfo(i) ;
	 if (!tw1 || !tw2 || tw1->name() != tw2->name())
	    return false ;
	 }
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

static ChartArc *arc_matches(const ChartArc *arc,ChartArc *arclist)
{
   for ( ; arclist ; arclist = arclist->nextArc())
      {
      if (equivalent_arc(arc,arclist))
	 return arclist ;
      }
   return 0 ;
}

//----------------------------------------------------------------------

static bool arc_can_be_last(const ChartArc *a)
{
   if (reorder_window_is_uncovered)
      return true ;
   const ParseChart *chart = a->chart() ;
   size_t startword = chart->wordIndex(a->startPosition()) ;
   if (chart->numWordBoundaries() - startword < max_reorder_window)
      return true ;
   return false ;
}

/************************************************************************/
/*    Methods for class ParseChart					*/
/************************************************************************/

static bool single_word_source(const FrTextSpan *span)
{
   char *source = span->initialText() ;
   if (source)
      {
      bool single = true ;
      for (char *src = source ; *src ; src++)
	 {
	 if (Fr_isspace(*src))
	    {
	    single = false ;
	    break ;
	    }
	 }
      FrFree(source) ;
      return single ;
      }
   return false ;
}

//----------------------------------------------------------------------

static FrList *add_alternate_sequence(FrList *altseq, const char *name,
				      const FrTextSpan *span)
{
   FrList *alt = (FrList*)span->getMetaData(name) ;
   if (alt)
      {
      alt = EbFixDottedList(alt) ;
      pushlist(makeSymbol(name),alt) ;
      pushlist(alt,altseq) ;
      }
   return altseq ;
}

//----------------------------------------------------------------------

#undef symMORPH
#undef symALIGN
static bool add_span(const FrTextSpan *span, va_list args)
{
   FrVarArg(ParseChart*,chart) ;
   if (span && chart)
      {
      FrVarArg(FrSymbol*,symENGINE) ;
      FrSymbol *arctype = (FrSymbol*)span->getMetaDataSingle(symENGINE) ;
      if (arctype && arctype->symbolp() &&
	  strcmp(arctype->symbolName(),lm_arc_tag) == 0)
	 return true ;			// ignore arcs inserted by decoder
      size_t start = span->start() ;
      FrVarArg(FrSymbol*,symMORPH) ;
      FrVarArg(FrSymbol*,symALIGN) ;
      MTEngine *engine = MTEngine::findEngine(arctype) ;
      if (!engine && arctype)
	 {
	 FrWarningVA("Unknown arc type %s in chart -- update your config file",
		     arctype->symbolName()) ;
	 ChartEntryType type = ChartArc::allocateArcType(arctype) ;
	 engine = new MTEngine(arctype,arctype->symbolName(),type,
			       NEW_ENGINE_WEIGHT) ;
	 }
      if (engine)
	 {
	 const FrList *alignment = (FrList*)span->getMetaData(symALIGN) ;
	 const FrList *morph = (FrList*)span->getMetaData(symMORPH) ;
	 FrList *altseq = (FrList*)span->getMetaData("ALT") ;
	 if (altseq)
	    altseq = (FrList*)altseq->deepcopy() ;
	 altseq = add_alternate_sequence(altseq,"SPANS",span) ;
	 altseq = add_alternate_sequence(altseq,"RESTRICT",span) ;
	 altseq = add_alternate_sequence(altseq,"POS",span) ;
	 ChartArc *new_arc = engine->readArc(span,chart,chart->getArc(start),
					     morph,alignment,altseq) ;
	 if (new_arc != chart->getArc(start))
	    new_arc->singleWordSource(single_word_source(span)) ;
	 chart->setArcs(start,new_arc) ;
	 free_object(altseq) ;
	 }
      }
   return true ;
}

//----------------------------------------------------------------------

static bool record_limits(MTEngine *eng, va_list args)
{
   FrVarArg(size_t*,limits) ;
   FrVarArg(size_t*,limits1) ;
   limits[eng->engineID()] = eng->maxAlts() ;
   limits1[eng->engineID()] = eng->maxAlts1() ;
   return true ;
}

//----------------------------------------------------------------------

ParseChart::ParseChart(FrTextSpans *chart, LmNGramModel **models)
{
   init(models) ;
   num_parsecharts++ ;
   if (chart)
      {
      FrTimer timer ;
      input_length = chart->textLength() ;
      // allocate enough for the input plus terminator
      m_arcs = FrNewC(ChartArc*,chartLength()+1) ;
      m_lattice = chart ;
      // find the symbols which were used to tag the metadata on spans
      FrSymbolTable *symtab = chart->symbolTable()->select() ;
      FrSymbol *symALIGN = makeSymbol("ALIGN") ;
      FrSymbol *symENGINE = makeSymbol("ENGINE") ;
      FrSymbol *symMORPH = makeSymbol("MORPH") ;
      symtab->select() ;
      initFeatureIndex() ;
      m_feature_map->finalize(LmFeatureVector::featureSize()) ;
      chart->iterate(add_span,this,symENGINE,symMORPH,symALIGN) ;
      // since arcs in the lattice are sorted from longest to shortest and
      //   highest score to lowest score, but the build process reverses
      //   that order, re-reverse the order here
      for (size_t i = 0 ; i < chartLength() ; i++)
	 {
	 ChartArc *a = getArc(i) ;
	 if (a)
	    setArcs(i,a->reverseList()) ;
	 }
      finishBuilding(timer) ;
      }
   return ;
}

//----------------------------------------------------------------------

void ParseChart::init(LmNGramModel **models)
{
   metadata = 0 ;
   m_models = models ;
   for (m_num_models = 0 ; models[m_num_models] ; m_num_models++)
      {
      // nothing to do
      }
   max_overlap = max_source_overlap ;
   max_reorder_gap = max_reorder_window > 0 ? max_reorder_window - 1 : 0 ;
   m_numarcs = 0 ;
   m_initarc = new ChartArc ;
   m_pending_arcs = 0 ;
   m_obsolete_arcs = 0 ;
   m_covering_arcs = 0 ;
   m_future_score_matrix = 0;
   m_covering_counts = 0 ;
   m_covering_ptrs = 0 ;
   m_feature_weights = 0 ;
   m_feature_index = 0 ;
   m_feature_map = new FrFeatureVectorMap(&LMfeature_map) ;
   word_indices = 0 ;
   word_boundaries = 0 ;
   num_boundaries = 0 ;
   wordtable = new FrSymbolTable(20000) ;
   FrSymbol *bsword = 0 ;
   if (m_models && m_models[0])
      bsword = m_models[0]->word_begsent() ;
   FrSymbol *esword = 0 ;
   if (m_models && m_models[0])
      esword = m_models[0]->word_endsent() ;
   endsent_word = new TargetWord(m_models,esword,0) ;
   endsent_word->addReference() ;
   quesmark_word = new TargetWord(m_models,makeSymbol("?"),0) ;
   quesmark_word->addReference() ;
   origtable = wordtable->select() ;
   symEPSILON = makeSymbol(LM_EPSILON_MARKER) ;
   origtable->select() ;
   for (size_t i = 0 ; m_models && m_models[i] ; i++)
      m_models[i]->setSentMarkers() ;
   return ;
}

//----------------------------------------------------------------------

void ParseChart::initFeatureIndex()
{
   LmAccumulateFeatures(m_feature_map,m_lattice) ;
   m_feature_index =
      new LmFeatureIndex((FrList*)m_lattice->metaData("FEATURES"),
			 m_feature_map) ;
   return ;
}

//----------------------------------------------------------------------

void ParseChart::finishBuilding(FrTimer &timer)
{
   setWordBoundaries() ;
   initFutureScoreMatrix() ;
   initWeightVector() ;
   filterArcs() ;
   addDummyArcs() ;
   setWordBoundaries() ;
   weightMergedArcs() ;
   optimizeArcs() ;
   addAlignments() ;
   size_t num_combined = 1 ;
   while (setSuccessorArcs(num_combined))
      {
      removeObsoletedArcs() ;
      insertCompositeArcs() ;
      pruneArcs() ;
      if (++num_combined > predecode_max_arcs)
	 break ;
      TRACE(2,cout<<"Clearing successor arcs for next pass of chart decoding"<<endl);
      clearSuccessorArcs() ;
      }
   initCoveringArcs() ;
   initFutureScoreMatrix() ;
   if (verbose)
      cout << "Time to build chart: " << setprecision(5)
	   << (1000.0*timer.readsec()) << " ms." << endl ;
   return ;
}

//----------------------------------------------------------------------

static ChartArc **collect_arcs(ChartArc **arcs, size_t chartlen,
			       size_t total_arc_count, LmNGramModel **models)
{
   ChartArc **all_arcs = FrNewN(ChartArc*,total_arc_count) ;
   if (!all_arcs)
      FrNoMemory("while determining successor arcs") ;
   else
      {
      size_t count = 0 ;
      for (size_t i = 0 ; i <= chartlen && count < total_arc_count ; i++)
	 {
	 for (ChartArc *a = arcs[i] ; a && count<total_arc_count ; a = a->nextArc())
	    {
	    // while we're scanning all arcs anyway, compute future
	    //   utility values
	    if( a->targetText()[0] == '\0' ) a->setFutureUtility(MIN_FUTURE_SCORE) ;
	    else a->setFutureUtility(models,a->chart()->weightVector()) ;
	    a->markNotSuccessor() ;
	    all_arcs[count++] = a ;
	    }
	 }
      for ( ; count < total_arc_count ; count++)
	 all_arcs[count] = 0 ;
      }
   return all_arcs ;
}

//----------------------------------------------------------------------

void ParseChart::clearSuccessorArcs()
{
   for (size_t i = 0 ; i < chartLength() ; i++)
      {
      for (ChartArc *a = arcs(i) ; a ; a = a->nextArc())
	 {
	 a->setSuccessors(0,0) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

bool ParseChart::setSuccessorArcs(size_t iteration)
{
   bool make_composite_arcs = (iteration < predecode_max_arcs) ;
   TRACE(2,cout<<"Chart Decoding, pass "<<iteration<<endl) ;
   // for each arc, check the rest of the lattice for arcs that we could
   //   append to that arc during the search, and remember those potential
   //   successors in the arc
   ChartArc **all_arcs = collect_arcs(m_arcs,chartLength(),numArcs(),models()) ;
   ChartArcSuccessor *successors = new ChartArcSuccessor[numArcs()] ;
   bool added_composite_arcs = false ;
   if (all_arcs && successors)
      {
      for (size_t i = 0 ; i <= numArcs() ; i++)
	 {
	 bool added_composite = false ;
	 ChartArc *curr_arc = (i >= numArcs()) ? initialArc() : all_arcs[i] ;
	 if (!curr_arc)
	    continue ;
	 VTRACE(4,(cout<<"Checking successors for "<<curr_arc<<" @"<< \
		   curr_arc->startPosition()<<"/"<< \
		   curr_arc->endPosition()<<endl)) ;
	 size_t curr_start = wordIndex(curr_arc->startPosition()) ;
	 size_t curr_end = wordIndex(curr_arc->startPosition() + 
				     curr_arc->coverage()) ;
	 size_t num_succ = 0 ;
	 for (size_t j = 0 ; j < numArcs() ; j++)
	    {
	    ChartArc *succ = all_arcs[j] ;
	    if (!succ || succ == curr_arc ||
		curr_arc->subsumes(succ) || succ->subsumes(curr_arc)
	       )
	       continue ;
	    size_t succ_start = wordIndex(succ->startPosition()) ;
	    size_t succ_end = wordIndex(succ->startPosition() +
					succ->coverage()) ;
	    size_t srcoverlap = ((succ_start < curr_end)
				 ? curr_end - succ_start : 0) ;
	    if (succ_end <= curr_start)
	       {
	       // make sure that we aren't too far away from the current
	       //   arc; if REORDER_UNCOV is enabled, any arc preceding
	       //   the current arc is a potential successor, since it
	       //   might have been skipped early on and the reorder window
	       //   never filled with N skipped source positions
	       if (!reorder_window_is_uncovered &&
		   curr_start - succ_start > maxReorderGap())
		  continue ;
	       srcoverlap = 0 ;		// disjoint arcs
	       }
	    NVTRACE(7,(cout<<"  Potential: "<<succ<<" @ "<< \
		       succ->startPosition()<<"/"<< \
		       succ->endPosition()<<endl)) ;
	    // not a possible successor if it's entirely embedded within the
	    //   current arc and the current arc has no gaps to fill
	    if ((srcoverlap >= succ->sourceWordSpan() &&
		 !curr_arc->hasGapMarkers()))
	       {
	       curr_arc->addConflict(succ,numArcs()) ;
	       continue ;
	       }
	    // not a successor if it covers the identical input span
	    if (srcoverlap == succ->sourceWordSpan() && 
		srcoverlap == curr_arc->sourceWordSpan())
	       {
	       curr_arc->addConflict(succ,numArcs()) ;
	       continue ;
	       }
	    size_t srcgap = ((succ_start > curr_end)
			     ? succ_start - curr_end : 0) ;
	    size_t trgoverlap = 0 ;
	    bool allowable = false ;
	    bool fills_gap = false ;
	    // check whether the overlap regions of the two arcs are
	    //   compatible
	    if (LmOverlapAllowed(curr_arc,succ,srcoverlap,trgoverlap,
				 maxOverlap(),fills_gap))
	       {
	       allowable = true ;
	       }
	    else if (curr_arc->canFillGap(succ,srcoverlap,trgoverlap))
	       {
	       allowable = true ;
	       fills_gap = true ;
	       }
	    else if (srcoverlap == 0 && srcgap == 0)
	       {
	       allowable = true ;	// simple abutting extension always OK
	       }
	    else if (srcgap > 0 && srcgap <= maxReorderGap())
	       {
	       //FIXME: additional verification here
	       allowable = true ;
	       }
	    // don't bother trying a strict prefix as successor, since we
	    //   will be adding the current arc to the prefix anyway
	    else if (srcoverlap == succ->sourceWordSpan() &&
		   trgoverlap == curr_arc->sourceWordSpan())
	       allowable = false ;
	    else if (srcgap > 0)
	       break ;			// we've passed the last possible succ.
	    if (allowable)
	       {
	       succ->markAsSuccessor() ;
	       // at this point, we have the choice of simply recording that
	       //   the arc is a potential successor, or actually creating
	       //   a composite arc containing both the current arc and the
	       //   potential successor
	       if (make_composite_arcs && curr_arc != initialArc() &&
		   createMergedArc(curr_arc,succ,srcoverlap,trgoverlap,
				   fills_gap))
		  added_composite = true ;
	       else
		  {
		  // count both forward and backward jumps as reordering
		  //   provided that the successor arc is not overlapped or
		  //   interleaved with the current arc
		  size_t reorder = srcgap ;
		  if (curr_end > succ_start && srcoverlap == 0 && !fills_gap)
		     reorder = (curr_end - succ_start) ;
		  successors[num_succ++].init(succ,srcoverlap,trgoverlap,
					      reorder,fills_gap) ;
		  }
	       }
	    else if (srcoverlap > 0)
	       curr_arc->addConflict(succ,numArcs()) ;
	    }
	 if (added_composite)
	    added_composite_arcs = true ;
#if 0
//	 if (num_succ == 0 && curr_end < numWordBoundaries())
	 if (num_succ == 0 && !added_composite && !arc_can_be_last(curr_arc)
	     && curr_arc->numSubsumedArcs() == 0)
	    {
	    TRACE(3,(cout << "removing arc '" << curr_arc->sourceText()
		          << "' --> '" << curr_arc->targetText()
		     	  << "' because it can't lead to a complete walk"
		          << endl << flush)) ;
	    curr_arc->markOverridden() ; // we can't possibly use it
	    }
	 else // if (num_succ > 0)
#endif
	    {
	    if (trace > 2)
	       {
	       for (size_t s = 0 ; s < num_succ ; s++)
		  print_successor(curr_arc,&successors[s]) ;
	       }
	    curr_arc->setSuccessors(successors,num_succ) ;
	    }
	 }
      }
   delete [] successors ;
   FrFree(all_arcs) ;
   return added_composite_arcs ;
}

//----------------------------------------------------------------------

bool ParseChart::createMergedArc(const ChartArc *arc, const ChartArc *succ_arc,
				 size_t srcoverlap, size_t trgoverlap,
				 bool fills_gap)
{
   size_t new_len = arc->sourceWordCount() ;
   if (srcoverlap < succ_arc->sourceWordCount())
      new_len += (succ_arc->sourceWordCount() - srcoverlap) ;
   if (!m_pending_arcs)
      {
      const ParseChart *chart = arc->chart() ;
      m_pending_arcs = FrNewC(ChartArc *,chart->chartLength()+1) ;
      }
   if (new_len <= predecode_max_len || fills_gap)
      {
      ChartArc *new_arc = ChartArc::combineArcs(arc,succ_arc,trgoverlap) ;
      // queue up the new arc for addition to the lattice (don't add it just
      //   yet, as that can confuse the code creating the merged arcs
      size_t pos = new_arc->startPosition() ;
      new_arc->setNextArc(m_pending_arcs[pos]) ;
      m_pending_arcs[pos] = new_arc ;
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

void ParseChart::removeObsoletedArcs()
{
   for (size_t i = 0 ; i < chartLength() ; i++)
      {
      ChartArc *prev = 0 ;
      ChartArc *next_arc ;
      for (ChartArc *a = arcs(i) ; a ; a = next_arc)
	 {
	 next_arc = a->nextArc() ;
	 if (!a->isSuccessor() ||
	     (a->numSuccessors() == 0 && !arc_can_be_last(a)))
	    {
	    // we can't reach this arc or we can't extend from it (and it
	    //   can't be the last arc in the output), so dump it
	    TRACE(3,(cout << "removing obsoleted arc '" << a->sourceText()
		          << "' --> '" << a->targetText() 
		          << "'"<< endl)) ;
	    if (prev)
	       prev->setNextArc(next_arc) ;
	    else
	       m_arcs[i] = next_arc ;
	    a->setNextArc(m_obsolete_arcs) ;
	    m_obsolete_arcs = a ;
	    }
	 else
	    prev = a ;
	 }
      }
   cout << flush ;
   return ;
}

//----------------------------------------------------------------------

void ParseChart::insertCompositeArcs()
{
   for (size_t i = 0 ; i < chartLength() ; i++)
      {
      ChartArc *next_arc ;
      for (ChartArc *pend = m_pending_arcs[i] ; pend ; pend = next_arc)
	 {
	 next_arc = pend->nextArc() ;
	 ChartArc *match = arc_matches(pend,m_arcs[i]) ;
	 if (match)
	    {
	    // merge the composite arc with the existing simple arc
	    TRACE(3,cout << "Merging composite with existing arc: " << pend << endl) ;
	    match->mergeArc(CE_Merged,pend->features(),
			    pend->features()->value(featureID_arcweight)) ;
	    }
	 else
	    {
	    // insert the composite arc on the list of arcs starting at the
	    //   current position
	    TRACE(3,cout << "Inserting composite arc: " << pend << endl) ;
	    pend->setID(numArcs()) ;
	    pend->setNextArc(m_arcs[i]) ;
	    m_arcs[i] = pend ;
	    m_numarcs++ ;
	    }
	 }
      m_pending_arcs[i] = 0 ;
      }
   return ;
}

//----------------------------------------------------------------------

static double combined_utility(const ChartArc *arc)
{
   double lambda = 0.5 ;
   return (lambda * arc->logScore()) + ((1.0 - lambda) * arc->futureUtility()) ;
}

//----------------------------------------------------------------------

static int compare_arcs(const ChartArc &arc1, const ChartArc &arc2)
{
   size_t len1 = arc1.coverage() ;
   size_t len2 = arc2.coverage() ;
   if (len1 > len2)
      return -1 ;
   else if (len1 < len2)
      return +1 ;
   double score1 = combined_utility(&arc1) ;
   double score2 = combined_utility(&arc2) ;
   if (score1 > score2)
      return -1 ;
   else if (score1 < score2)
      return +1 ;
   return 0 ;
}

//----------------------------------------------------------------------

static bool limit_exceeded(const ChartArc *arc, size_t *counts, 
			   size_t max_engines)
{
   size_t *counts1 = counts + max_engines ;
   size_t *limits = counts + 2*max_engines ;
   size_t *limits1 = limits + max_engines ;
   bool below_limit = false ;
   ChartEntryTypes arctype = arc->arcType() ;
   unsigned num_types = ChartArc::numArcTypes() ;
   for (unsigned i = 0 ; i < num_types ; i++)
      {
      if ((arctype & (1<<i)) != 0)
	 {
	 if (arc->singleWordSource())
	    {
	    if (++counts1[i] <= limits1[i])
	       below_limit = true ;
	    }
	 else
	    {
	    if (++counts[i] <= limits[i])
	       below_limit = true ;
	    }
	 }
      }
   return !below_limit ;
}

//----------------------------------------------------------------------

void ParseChart::filterArcs()
{
   size_t max_engines = MTEngine::maxEngines() ;
   FrLocalAllocC(size_t,counts,512,4*max_engines) ;
   if (!counts)
      FrNoMemory("while allocating scratch space to filter arcs") ;
   else
      {
      size_t *limits = counts + 2*max_engines ;
      size_t *limits1 = limits + max_engines ;
      MTEngineList::iterateAll(record_limits,limits,limits1) ;
      for (size_t i = 0 ; i < chartLength() ; i++)
	 {
	 ChartArc *arcs = getArc(i)->sort(weightVector()) ;
	 ChartArc *filtered = 0 ;
	 ChartArc *next ;
	 size_t prev_cover = ~0 ;
	 for ( ; arcs ; arcs = next)
	    {
	    next = arcs->next() ;
	    size_t cover = arcs->coverage() ;
	    if (cover != prev_cover)
	       {
	       // reset counts each time the covered span changes
	       for (size_t i = 0 ; i < 2*max_engines ; i++)
		  counts[i] = 0 ;
	       prev_cover = cover ;
	       }
	    if (limit_exceeded(arcs,counts,max_engines))
	       {
	       arcs->setNext(0) ;
	       delete arcs ; 
	       }
	    else
	       {
	       arcs->setNext(filtered) ;
	       filtered = arcs ;
	       }
	    }
	 setArcs(i,filtered->reverseList()) ;
	 }
      FrLocalFree(counts) ;
      }
   return ;
}

//----------------------------------------------------------------------

void ParseChart::pruneArcs()
{
   // limit the number of arcs covering any given span of input
   for (size_t i = 0 ; i < chartLength() ; i++)
      {
      if (!m_arcs[i])
	 continue ;
      // sort the arcs starting at the current position by decreasing length
      //   and decreasing score
      m_arcs[i] = FrMergeSort(m_arcs[i],compare_arcs) ;
      // count up the number of arcs of each length, and eliminate any extras
      //   as well as those with too low a utility score
      size_t max_arcs = beam_width ; //FIXME
      double cutoff = predecode_cutoff ;
      size_t prevlen = 0 ;
      size_t count = 0 ;
      double best_score = DBL_MAX ;
      ChartArc *prev = 0 ;
      ChartArc *next = 0 ;
      for (ChartArc *arcs = m_arcs[i] ; arcs ; arcs = next)
	 {
	 next = arcs->next() ;
	 if (arcs->coverage() != prevlen)
	    {
	    // reset the count for the new length
	    count = 0 ;
	    best_score = combined_utility(arcs) ;
	    prevlen = arcs->coverage() ;
	    prev = arcs ;
	    }
	 else if ((++count > max_arcs && arcs->isComposite()) ||
		  combined_utility(arcs) < cutoff * best_score)
	    {
	    // delete the extraneous arc
	    prev->setNext(next) ;
	    arcs->setNext(m_obsolete_arcs) ;
	    m_obsolete_arcs = arcs ;
	    }
	 else
	    prev = arcs ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

bool ParseChart::inboundArcs(size_t pos) const
{
   if (pos == 0 || pos >= chartLength())
      return false ;			// by definition
   else
      {
      // while this isn't the most efficient method (using a second array
      //   sorted by arc end would be better), building the chart is a very
      //   small fraction of the total decoding time
      for (size_t i = 1 ; i <= pos ; i++)
	 {
	 size_t loc = pos - i ;
	 for (ChartArc *a = arcs(loc) ; a ; a = a->nextArc())
	    {
	    // is the current arc a non-dummy arc with no source hole that
	    //   has the desired ending location?
	    if (loc + a->coverage() == pos && a->arcType() != (1<<CE_none) &&
	       a->sourceWordCount() == a->sourceWordSpan())
	       return true ;
	    }
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

bool ParseChart::addDummyArc(size_t where, int len, const char *translation)
{
   char *source = m_lattice->getText(where,where+len-1) ;
   char *trans ;
   if (translation && translation[0] == '=' && translation[1] == '\0')
      trans = FrDupString(source) ;
   else
      trans = FrDupString(translation) ;
   size_t trans_len = LmCountWords(trans) ;
   FrList *alignment = 0 ;
   for (size_t i = 0 ; i < trans_len ; i++)
      {
      pushlist(new FrList(new FrInteger(where),makeSymbol("-"),
			  new FrInteger(where+len-1)),
	       alignment) ;
      }
   const FrList *morph = 0 ;
   LmFeatureVector *features = new LmFeatureVector(&LMfeature_map) ;
   features->setValue(featureID_score,
		      LmNGramModel::smoothedLog(0.0001)) ;
   features->setValue(featureID_quality,
		      LmNGramModel::smoothedLog(DUMMY_ARC_QUALITY)) ;
   features->setValue(featureID_arcweight,
		      LmNGramModel::smoothedLog(DUMMY_ARC_WEIGHT));
   ChartArc *newarc =
      new ChartArc((MTEngine*)0,source,trans,alignment,where,len,
		   features,m_models,morph,0,this,arcs(where)) ;
   delete features ;
   newarc->setID(numArcs()) ;
   setArcs(where,newarc) ;
   free_object(alignment) ;
   addedArc() ;
   return true ;
}

//----------------------------------------------------------------------

bool ParseChart::addDummyArcs(size_t where, int len)
{
   bool added_dummy = false ;
   if (dummy_arc_contents)
      {
      FrSymbolTable *symtab = wordtable->select() ;
      char *dummy_start = dummy_arc_contents ;
      for ( ; ; )
	 {
	 char *dummy_end = strchr(dummy_start,'|') ;
	 if (!dummy_end)
	    break ;
	 *dummy_end = '\0' ;	// turn delimiter into end-of-string
	 if (addDummyArc(where,len,dummy_start))
	    added_dummy = true ;
	 *dummy_end = '|' ;	// restore the delimiter
	 dummy_start = dummy_end + 1 ;
	 }
      if (addDummyArc(where,len,dummy_start))
	 added_dummy = true ;
      symtab->select() ;
      }
   if (!added_dummy)			// if no dummy added yet, add one
      addDummyArc(where,len,"") ;	//   that simply omits the word(s)
   return added_dummy ;
}

//----------------------------------------------------------------------

int ParseChart::longestArc(size_t pos) const
{
   size_t len = 0 ;
   if (pos < chartLength())
      {
      for (const ChartArc *a = arcs(pos) ; a ; a = a->nextArc())
	 {
	 if (a->coverage() > len &&
	     // ignore arcs with holes in their source sides
	     a->sourceWordCount() == a->sourceWordSpan())
	    len = a->coverage() ;
	 }
      }
   return len ;
}

//----------------------------------------------------------------------

static bool ungapped_arc(const ChartArc *arc)
{
   for ( ; arc ; arc = arc->nextArc())
      {
      if (arc->sourceWordCount() == arc->sourceWordSpan())
	 return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

void ParseChart::addDummyArcs()
{
   for (size_t pos = 0 ; pos < chartLength() ; pos++)
      {
      if (!ungapped_arc(arcs(pos)))
	 {
	 // if there are incoming but no outgoing arcs from the current
	 //   position, add dummies from here to the most proximate
	 //   subsequent position that has either incoming or outgoing
	 //   non-dummy arcs
	 if (pos == 0 || inboundArcs(pos))
	    {
	    for (int len = 1 ; pos + len <= chartLength() ; len++)
	       {
	       if ((ungapped_arc(arcs(pos+len))
		    || pos + len == chartLength() 
		    || inboundArcs(pos+len)) &&
		   addDummyArcs(pos,len))
		  break ;
	       }
	    }
	 }
      else
	 {
	 // if there ARE outgoing arcs, then check positions prior to the
	 //   target of the longest outgoing arc, and add dummies to any that
	 //   have outbound but no incoming arcs
	 int max_len = longestArc(pos) ;
	 for (int len = 1 ; len < max_len ; len++)
	    {
	    if (arcs(pos+len) && !inboundArcs(pos+len))
	       addDummyArcs(pos,len) ;
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

static bool arcs_intersect(const ChartArc *arc1, const ChartArc *arc2)
{
   for (size_t i = 0 ; i < arc1->arcLength() ; i++)
      {
      for (size_t j = 0 ; j < arc2->arcLength() ; j++)
	 {
	 const TargetWord *twinfo1 = arc1->targetWordInfo(i) ;
	 const TargetWord *twinfo2 = arc2->targetWordInfo(j) ;
	 if (twinfo1 && twinfo2 && twinfo1->name() == twinfo2->name())
	    return true ;
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

static size_t reinforcing_arcs(const ChartArc *arc, const ParseChart *chart)
{
   size_t arc_start = arc->startPosition() ;
   size_t arc_end = arc_start + arc->coverage() - 1 ;
   ChartEntryTypes engines = 0 ;
   for (size_t start = 0 ; start <= arc_end ; start++)
      {
      for (const ChartArc *a = chart->getArc(start) ; a ; a = a->nextArc())
	 {
	 size_t end = start + a->coverage() - 1 ;
	 if (end >= arc_start)
	    {
	    // this arc overlaps the one we're interested in, so add its
	    //   engines to the set of all engines if it contains any of
	    //   the word in the arc
	    if (arcs_intersect(arc,a))
	       engines |= a->arcType() ;
	    }
	 }
      } 
   engines &= ~arc->arcType() ;
   engines &= ~(CE_LM | CE_Merged) ;
   size_t count = 0 ;
   while (engines != 0)
      {
      if ((engines & 1) != 0)
	 count++ ;
      engines >>= 1 ;
      }
   return count ;
}

//----------------------------------------------------------------------

void ParseChart::weightMergedArcs()
{
   for (size_t i = 0 ; i < chartLength() ; i++)
      {
      for (ChartArc *a = getArc(i) ; a ; a = a->nextArc())
	 {
	 // while we're at it, also store the arc's starting position
	 a->setStart(i) ;
	 // and set the source locations corresponding to any gap markers
	 a->setFillerLocations() ;
	 // and update the number of input words the arc spans
	 a->setSourceSpan(boundaryCount(a->startPosition(),
					a->endPosition())+1) ;
	 a->setAgreementBonus(a->occurrences()-1) ;
	 // scan all other arcs that cover the locations covered by
	 //   this arc for the words in this arc's output side
	 size_t num_reinforce = reinforcing_arcs(a,this) ;
	 a->setFeature(featureID_reinforcement,num_reinforce) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

static bool flag_overridden(MTEngine *eng,va_list args)
{
   FrVarArg(ParseChart*,chart) ;
   FrVarArg(size_t,i) ;
   FrVarArg(char*,lengths) ;
   memset(lengths,'\0',chart->chartLength()) ;
   ChartEntryTypes mask = 1L << (int)eng->engineID() ;
   ChartArc *arc ;
   bool have_arc_type = false ;
   for (arc = chart->getArc(i) ; arc ; arc = arc->nextArc())
      {
      if ((arc->arcType() & mask) != 0 && arc->startPosition() == i)
	 {
	 size_t len = arc->coverage() ;
	 if (i+len >= (size_t)chart->chartLength() ||
	     chart->getArc(i+len) != 0)
	    lengths[len] = 1 ;
	 have_arc_type = true ;
	 }
      }
   if (have_arc_type)
      {
      ChartEntryTypes ovr = eng->overriddenEngines() ;
      ChartEntryTypes tovr = eng->totallyOverriddenEngines() ;
      for (arc = chart->getArc(i) ; arc ; arc = arc->nextArc())
	 {
	 if ((arc->arcType()&mask) == 0 && arc->startPosition() == i)
	    {
	    arc->overrideTypes(tovr) ;
	    if (lengths[arc->coverage()] != 0)
	       arc->overrideTypes(ovr) ;
	    }
	 }
      }
   return true ;
}

//----------------------------------------------------------------------

void ParseChart::removeOverriddenEngines()
{
   // if we have any engines which override others, remove any arcs which are
   // overridden, so that they will be not be considered during the search
   // for the best chart walk
   if (MTEngine::haveOverrides())
      {
      FrLocalAlloc(char,lengths,1024,chartLength()+1) ;
      for (size_t i = 0 ; i < chartLength() ; i++)
	 {
	 MTEngineList::iterateAll(flag_overridden,this,i,lengths) ;
	 // remove any arcs which have been completely overridden
	 ChartArc *prev = 0 ;
	 ChartArc *next ;
	 for (ChartArc *arc = getArc(i) ; arc ; arc = next)
	    {
	    next = arc->nextArc() ;
	    if ((arc->arcType() & ~(1L << CE_Merged)) == 0)
	       {
	       if (prev)
		  prev->setNextArc(next) ;
	       else
		  setArcs(i,next) ;
	       arc->setNextArc(m_obsolete_arcs) ;
	       m_obsolete_arcs = arc ;
	       removedArc() ;
	       }
	    else
	       prev = arc ;
	    }
	 }
      FrLocalFree(lengths) ;
      }
   return ;
}

//----------------------------------------------------------------------

static bool engine_produces_partials(MTEngine *eng, va_list args)
{
   FrVarArg(int,engines) ;
   ChartEntryType type = eng->engineID() ;
   if (((engines & (1L << (int)type)) != 0) && eng->partialResults())
      {
      return false ;			// don't iterate any more, we have an
      } 				// engine that produces partial xlat
   return true ;
}

//----------------------------------------------------------------------

static bool engine_produces_partials(const ChartArc *arc)
{
   int engines = arc->arcType() ;
   return !MTEngineList::iterateAll(engine_produces_partials,engines) ;
}

//----------------------------------------------------------------------

void ParseChart::optimizeArcs()
{
   // if we have any arcs that cover the entire input, trim the chart so that
   // only those arcs are ever considered
   if (complete_arc_overrides_partial)
      {
      bool have_complete_arc = false ;
      for (ChartArc *a = getArc(0) ; a ; a = a->nextArc())
	 {
	 if (a->coverage() == chartLength() &&
	     a->sourceWordCount() == a->sourceWordSpan() && // any src gaps?
	     engine_produces_partials(a))
	    {
	    ChartArc *prev = 0 ;
	    ChartArc *next ;
	    have_complete_arc = true ;
	    for (a = getArc(0) ; a ; a = next)
	       {
	       next = a->nextArc() ;
	       if (a->coverage() != chartLength())
		  {
		  if (prev)
		     prev->setNextArc(next) ;
		  else
		     setArcs(0,next) ;
		  a->setNextArc(m_obsolete_arcs) ;
		  m_obsolete_arcs = a ;
		  removedArc() ;
		  }
	       else
		  prev = a ;
	       }
	    break ;
	    }
	 }
      if (have_complete_arc)
	 {
	 for (size_t i = 1 ; i < chartLength() ; i++)
	    {
	    // remove all arcs starting at position i for i>0
	    ChartArc *next ;
	    for (ChartArc *a = getArc(i) ; a ; a = next)
	       {
	       next = a->nextArc() ;
	       a->setNextArc(m_obsolete_arcs) ;
	       m_obsolete_arcs = a ;
	       removedArc() ;
	       }
	    setArcs(i,0) ;
	    }
	 }
      }
   removeOverriddenEngines() ;
   return ;
}

//----------------------------------------------------------------------

void ParseChart::setWordBoundaries()
{
   FrFree(word_boundaries) ;
   FrFree(word_indices) ;
   word_indices = FrNewC(size_t,chartLength()+1) ;
   size_t num_words = 0 ;
   for (size_t i = 0 ; i < chartLength() ; i++)
      {
      if (0 == i || getArc(i))
	 num_words++ ;
      }
   word_boundaries = FrNewN(size_t,num_words+1) ;
   if (word_boundaries)
      {
      num_words = 0 ;
      for (size_t i = 0 ; i < chartLength() ; i++)
	 {
	 if (0 == i || getArc(i))
	    word_boundaries[num_words++] = i ;
	 if (word_indices)
	    word_indices[i] = num_words-1 ;
	 }
      num_boundaries = num_words ;
      if (word_indices)
	 word_indices[chartLength()] = num_words ;
      word_boundaries[num_words] = chartLength() ;
      }
   else
      num_boundaries = 0 ;
   return ; 
}

//----------------------------------------------------------------------

void ParseChart::addAlignments()
{
   // scan through the arcs in the chart to see whether we can infer
   //   any alignments that weren't explicitly provided
   for (size_t i = 0 ; i < chartLength() ; i++)
      {
      for (ChartArc *arc = getArc(i) ; arc ; arc = arc->nextArc())
	 {
	 if (arc->hasGapMarkers())
	    {
	    for (size_t w = 0 ; w < arc->arcLength() ; w++)
	       {
	       TargetWord *tw = (TargetWord*)arc->targetWordInfo(w) ;
	       if (!tw)
		  continue ;
	       if (tw->isGapMarker() && !tw->sourceWords())
		  {
		  size_t fillpos = tw[w].gapFillerLocation() ;
		  size_t first = wordBoundary(fillpos) ;
		  size_t last = wordBoundary(fillpos+1)-1 ;
		  tw->setSourceWords(first,last) ;
		  }
	       }
	    }
	 else if (!arc->hasAlignments())
	    {
	    if (arc->arcLength() == 1 || arc->sourceWordSpan() == 1)
	       {
	       // a single word must have aligned with entire source text;
	       //   multiple words as translation for a single word must also
	       //   all align with the source
	       for (size_t word = 0 ; word < arc->arcLength() ; word++)
		  arc->setSourceAlignment(word,arc->startPosition(),
					  arc->endPosition()) ;
	       }
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

ParseChart::~ParseChart()
{
   ChartArc *nextarc ;
   if (m_arcs)
      {
      for (size_t i = 0 ; i < chartLength() ; i++)
	 {
	 for (ChartArc *a = getArc(i) ; a ; a = nextarc)
	    {
	    nextarc = a->nextArc() ;
	    delete a ;
	    removedArc() ;
	    }
	 setArcs(i,0) ;
	 }
      FrFree(m_arcs) ;
      }
   while (m_obsolete_arcs)
      {
      ChartArc *tmp = m_obsolete_arcs ;
      m_obsolete_arcs = m_obsolete_arcs->nextArc() ;
      delete tmp ;
      }
   origtable->select() ;
   destroy_symbol_table(wordtable) ;	wordtable = 0 ;
   if (endsent_word)
      {
      endsent_word->removeReference() ;
      endsent_word->free() ;		endsent_word = 0 ;
      }
   if (quesmark_word)
      {
      quesmark_word->removeReference() ;
      quesmark_word->free() ;		quesmark_word = 0 ;
      }
   freeCoveringArcs() ;
   freeFutureScoreMatrix() ;
   freeWeightVector() ;
   FrFree(word_boundaries) ;		word_boundaries = 0 ;
   FrFree(word_indices) ;		word_indices = 0 ;
   free_object(metadata) ;		metadata = 0 ;
   delete m_initarc ;			m_initarc = 0 ;
   delete m_pending_arcs ;		m_pending_arcs = 0 ;
   delete m_feature_index ;		m_feature_index = 0 ;
   m_lattice = 0 ;
   if (num_parsecharts > 0)
      {
      num_parsecharts-- ;
      if (num_parsecharts == 0)
	 TargetWord::zapAll() ;
      }
   return ;
}

//----------------------------------------------------------------------

int compare_future_utility(const void *a1, const void *a2)
{
   const ChartArc *arc1 = *((ChartArc**)a1) ;
   const ChartArc *arc2 = *((ChartArc**)a2) ;
   double dif = arc1->futureUtility() - arc2->futureUtility() ;
   if (dif > 0.0)
      return -1 ;
   else if (dif < 0.0)
      return +1 ;
   // as tie-breaker, use the number of conflicts for each arc (lower means
   //   we'll be less likely to have to scan to the next arc)
   size_t conf1 = arc1->numConflicts() ;
   size_t conf2 = arc2->numConflicts() ;
   if (conf1 < conf2)
      return -1 ;
   else if (conf1 > conf2)
      return +1 ;
   return 0 ;
}

//----------------------------------------------------------------------

bool ParseChart::initCoveringArcs()
{
   freeCoveringArcs() ;
   if (numWordBoundaries() > 0 && 
       weightVector()->value(featureID_future) != 0.0)
      {
      m_covering_counts = FrNewC(unsigned int,numWordBoundaries()+1) ;
      m_covering_arcs = FrNewC(const ChartArc**,numWordBoundaries()+1) ;
      if (!m_covering_counts || !m_covering_arcs)
	 {
	 FrFree(m_covering_counts) ; m_covering_counts = 0 ;
	 FrFree(m_covering_arcs) ; m_covering_arcs = 0 ;
	 return false ;
	 }
      size_t covers = 0 ;
      for (size_t i = 0 ; i < numArcs() ; i++)
	 {
	 const ChartArc *arc = getArc(i) ;
	 if (arc)
	    {
	    size_t startword = wordIndex(arc->startPosition()) ;
	    size_t endword = wordIndex(arc->endPosition() + 1) ;
	    const LmBitFlags *cov = arc->sourceCover() ;
	    for (size_t j = startword ; j < endword ; j++)
	       {
	       if (!cov || LmGetBit(cov,j-startword))
		  m_covering_counts[j]++ ;
	       }
	    covers += (endword - startword) ;
	    }
	 }
      // set up a pool of arc pointers
      m_covering_ptrs = FrNewN(const ChartArc*,covers+1) ;
      if (!m_covering_ptrs)
	 {
	 FrFree(m_covering_counts) ; m_covering_counts = 0 ;
	 FrFree(m_covering_arcs) ; m_covering_arcs = 0 ;
	 return false ;
	 }
      // point at appropriate offsets within the pointer pool so that each
      //   source word is associated with the arcs which cover it
      const ChartArc **bufptr = m_covering_ptrs ;
      m_covering_arcs[0] = bufptr ;
      for (size_t i = 0 ; i < numWordBoundaries() ; i++)
	 {
	 bufptr += m_covering_counts[i] ;
	 m_covering_counts[i] = 0 ;
	 m_covering_arcs[i+1] = bufptr ;
	 }
      m_covering_counts[numWordBoundaries()] = 0 ;
      for (size_t i = 0 ; i < numArcs() ; i++)
	 {
	 const ChartArc *arc = getArc(i) ;
	 if (arc)
	    {
	    size_t startword = wordIndex(arc->startPosition()) ;
	    size_t endword = wordIndex(arc->endPosition() + 1) ;
	    const LmBitFlags *cov = arc->sourceCover() ;
	    for (size_t j = startword ; j < endword ; j++)
	       {
	       if (!cov || LmGetBit(cov,j-startword))
		  m_covering_arcs[j][m_covering_counts[j]++] = arc ;
	       }
	    }
	 }
      // finally, sort the arcs for each source word by decreasing utility
      for (size_t i = 0 ; i < numWordBoundaries() ; i++)
	 {
	 if (m_covering_counts[i])
	    qsort(m_covering_arcs[i],m_covering_counts[i],
		  sizeof(m_covering_arcs[i][0]),compare_future_utility) ;
	 }
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

void ParseChart::freeCoveringArcs()
{
   if (m_covering_arcs)
      {
      FrFree(m_covering_arcs) ;      m_covering_arcs = 0 ;
      FrFree(m_covering_ptrs) ;	     m_covering_ptrs = 0 ;
      }
   if (m_covering_counts)
      {
      FrFree(m_covering_counts) ;    m_covering_counts = 0 ;
      }
   return ;
}

//----------------------------------------------------------------------

// By Jaedy
#define FUTURE_SCORE_ZERO -1000000
bool ParseChart::initFutureScoreMatrix()
{
   freeFutureScoreMatrix() ;
   if (!moses_style_scoring)
      return true ;
   m_future_score_matrix = FrNewC(double *, numWordBoundaries());
   for( size_t i=0; i<numWordBoundaries(); i++ )
      m_future_score_matrix[i] = FrNewC(double, numWordBoundaries());
   for( size_t i=0; i<numWordBoundaries(); i++ )
      {
      for( size_t j=0; j<numWordBoundaries(); j++ )
	 m_future_score_matrix[i][j] = FUTURE_SCORE_ZERO;
      }
   for (size_t i = 0 ; i < chartLength() ; i++)
      {
      const ChartArc *arc = getArc(i) ;
      if (arc)
	 {
	 for( const ChartArc *a = arc; a; a=a->nextArc() )
	    {
	    size_t startword = wordIndex(a->startPosition()) ;
	    size_t endword = wordIndex(a->endPosition() + 1) ;
	    double future_score = a->futureUtility();
	    size_t len = endword - startword - 1 ;
	    // startword index is 0-based
	    // 2nd dim. index is arclength-1
	    if (future_score > m_future_score_matrix[startword][len])
	       m_future_score_matrix[startword][len] = future_score;
	    }
	 }
      }
   for( size_t len=1; len<numWordBoundaries(); len++ )
      { // from length 2
      for( size_t start=0; start<numWordBoundaries()-len; start++ )
	 {
	 size_t end = start+len;
	 double best = FUTURE_SCORE_ZERO;
	 for( size_t k=start; k<end; k++ )
	    {
	    double sc = (m_future_score_matrix[start][k-start] +
			 m_future_score_matrix[k+1][end-k-1]) ;
	    if (sc > best)
	       best = sc ;
	    }
	 if (best > m_future_score_matrix[start][len])
	    m_future_score_matrix[start][len] = best;
	 }
      }
   return true ;
}

//----------------------------------------------------------------------
// By Jaedy
void ParseChart::freeFutureScoreMatrix()
{
   if (m_future_score_matrix)
      {
      for (size_t i = 0 ; i < numWordBoundaries() ; i++)
	 {
	 FrFree(m_future_score_matrix[i]);
	 }
      FrFree(m_future_score_matrix) ;
      m_future_score_matrix = 0;
      }
   return ;
}

//----------------------------------------------------------------------

bool ParseChart::initWeightVector()
{
   if (m_feature_map)
      m_feature_weights = LmMakeWeightVector(m_feature_map,
					     genre_feature_weights) ;
   return (m_feature_weights != 0) ;
}

//----------------------------------------------------------------------

void ParseChart::freeWeightVector()
{
   delete m_feature_weights ;	m_feature_weights = 0 ;
   delete m_feature_map ;	m_feature_map = 0 ;
   return ;
}

//----------------------------------------------------------------------

double ParseChart::bestUtility(size_t srcword, const LmConflicts *conflicts)
const
{
   if (srcword < numWordBoundaries() && m_covering_arcs && m_covering_counts)
      {
      for (size_t i = 0 ; i < m_covering_counts[srcword] ; i++)
	 {
	 const ChartArc *arc = m_covering_arcs[srcword][i] ;
	 if (arc && (!conflicts || !conflicts->conflicts(arc->conflicts())))
	    {
	    // this arc is OK for future use, so return its utility score
	    return arc->futureUtility() ;
	    }
	 }
      }
   return 0.0 ;
}

//----------------------------------------------------------------------

double ParseChart::bestUtility(size_t start, size_t length )
const
{
   // start is 0-based, length should be 0-based too (but the input
   //   will be real)
   double score = m_future_score_matrix[start][length-1];
   return score;
}

//----------------------------------------------------------------------

static size_t LmTotalStackRefills(size_t total_nbest)
{
   if (total_nbest == 1 && internal_nbest)
      return INTERNAL_NBEST ;
   size_t topN = stack_refill_topN ;
   if (total_nbest < topN)
      topN = total_nbest ;
   return topN ;
}

//----------------------------------------------------------------------

FrList *ParseChart::bestSentences(size_t n, bool logspace)
{
   FrTimer timer ;
   if (!m_models || !m_models[0])      // if we have no models, we can't decode
      return 0 ;
   for (size_t m = 0 ; m_models && m_models[m] ; m++)
      m_models[m]->useLogSpace(logspace) ;
   size_t numbest = best_count ;
   if (n == 1 && internal_nbest && best_count < 2)
      best_count = 2 ;
   else if (n > 1 && stack_refill_topN == 1)
      {
      best_count = 1 ; 			// no need to retain pruned nodes
      }
   BFSNode::newCoverAllocator(numWordBoundaries()) ;
   BFSNode::newWordAllocators() ;
   BFSNode *startnode = new BFSNode(this) ;
   BestFirstSearch *bfs = new BestFirstSearch(startnode,n,
					      LmTotalStackRefills(n)) ;
   time_t start_time = time(0) ;
   bool first = true ;
   bool search_succeeded = false ;
   size_t orig_beam = beam_width ;
   // do the search, placing the results on the final stack
   for (int i = LmTotalStackRefills(n) ; i > 0 ; i--)
      {
      if (!first)
	 bfs->refillQueues(false,i) ;
      bool succ = bfs->search() ;
      if (succ)
	 search_succeeded = true ;
      else if (first && n == 1)
	 {
	 // if we didn't fall back on pruned nodes, re-start the search
	 //  and ensure that pruned nodes are checked this time
	 TRACE(1,cout << "Search failure; retrying with pruned nodes." << endl) ;
	 best_count = 2 ;
	 delete bfs ;
	 if (beam_width < 30)
	    beam_width = 30 ;
	 startnode = new BFSNode(this) ;
	 bfs = new BestFirstSearch(startnode,best_count) ;
	 i++ ;
	 }
      first = false ;
      // avoid getting stuck on pathological cases
      if (time(0) > (time_t)(start_time + nbest_timeout))
	 break ;
      }
   beam_width = orig_beam ;
   best_count = numbest ;
   // gather the results
   FrList *results = 0 ;
   if (search_succeeded)
      {
      for (size_t i = 0 ; i < n ; i++)
	 {
	 FrList *nextbest = bfs->popBestResult() ;
	 if (!nextbest)
	    break ;
	 pushlist(nextbest,results) ;
	 }
      }
   if (!results)
      {
      startnode = new BFSNode(this) ;
      pushlist(new FrList(new FrFloat(-9999.9),
			  new FrString("(decoding failed)"),0,
			  startnode->scoreInfo()),results) ;
      delete startnode ;
      }
   // if we got fewer valid translations than requested, add dummies
   size_t num_xlat = results->simplelistlength() ;
   while (num_xlat < n)
      {
      pushlist(0,results) ;
      num_xlat++ ;
      }
   if (verbose)
      {
      cout << endl ;
      cout << "Total nodes processed/expanded: " <<setw(6) << bfs->totalNodes()
	    << " / " << bfs->expandedNodes() << endl ;
      cout << "Maximum/final queue length:     " << setw(6) << bfs->maxNodes() 
      	    << " / " << bfs->currNodes() << endl ;
      cout << "Time to process chart:          " << setw(8) << setprecision(8)
	    << (1000.0*timer.readsec()) << " ms." << endl ;
      cout << endl ;
      }
   delete bfs ;
   BFSNode::deleteCoverAllocator() ;
   BFSNode::deleteWordAllocators() ;
   return listreverse(results) ;
}

//----------------------------------------------------------------------

ostream &ParseChart::dump(ostream &output) const
{
   output << endl ;
   for (size_t i = 0 ; i < chartLength() ; i++)
      {
      output << i << ":" ;
      if (arcs(i))
	 {
	 for (const ChartArc *a = arcs(i) ; a ; a = a->nextArc())
	    a->dump(output) ;
	 }
      else
	 output << "(none)" << endl ;
      }
   return output ;
}

//----------------------------------------------------------------------

ostream &ParseChart::dump() const
{
   return dump(cout) ; 
}

//----------------------------------------------------------------------

const FrObject *ParseChart::getMetaData(FrSymbol *datatype) const
{
   if (metadata)
      return metadata->get(datatype) ;
   // if we get here, there was no matching data
   return 0 ;
}

//----------------------------------------------------------------------

const FrObject *ParseChart::getMetaData(const char *datatype) const
{
   return getMetaData(makeSymbol(datatype)) ;
}

//----------------------------------------------------------------------

size_t ParseChart::boundaryCount(size_t start, size_t end) const
{
   return wordIndex(end) - wordIndex(start) ;
}

//----------------------------------------------------------------------

char *ParseChart::sourceText(size_t first, size_t last) const
{
   if (m_lattice)
      {
      return m_lattice->getText(first,last) ;
      }
   else
      return FrDupString("") ;
}

//----------------------------------------------------------------------

char *ParseChart::sourceText(const ChartArc *arc) const
{
   if (arc)
      return sourceText(arc->startPosition(),arc->endPosition()) ;
   else
      return FrDupString("") ;
}

//----------------------------------------------------------------------

double ParseChart::chunkingBonus(size_t start, size_t end) const
{
   const FrObject *boundsinfo = getMetaData("BOUNDS") ;
   if (boundsinfo && boundsinfo->consp())
      {
      const FrList *bounds = (const FrList*)boundsinfo ;
      size_t leftmost = ~0 ;
      size_t rightmost = 0 ;
      if (start == 0)
	 leftmost = 0 ;			// implicit boundary at start of sent
      if (end + 1 >= chartLength())
	 rightmost = chartLength() ;	// implicit boundary at end of sentence
      for ( ; bounds ; bounds++)
	 {
	 if (!bounds->first() || !bounds->first()->numberp())
	    continue ;
	 size_t bound = bounds->first()->intValue() ;
	 if (bound >= start && bound <= end)
	    {
	    if (bound < leftmost)
	       leftmost = bound ;
	    if (bound > rightmost)
	       rightmost = bound ;
	    }
	 }
      if (leftmost < rightmost)
	 return rightmost - leftmost ;
      }
   return 0.0 ;
}

/************************************************************************/
/************************************************************************/

static bool show_engine_type(MTEngine *eng, va_list args)
{
   FrVarArg(ostream*,out) ;
   FrSymbol *tag = eng->engineTag() ;
   const char *tagstr = tag->symbolName() ;
   if (*tagstr == ':') tagstr++ ;
   const char *name = eng->engineName() ;
   if (!name) name = "" ;
   (*out) << '\t' ;
   out->width(15) ;
   out->setf(ios::left,ios::adjustfield) ;
   (*out) << tagstr ;
   out->setf(ios::internal,ios::adjustfield) ;
   (*out) << '\t' << name << endl ;
   return true ;
}

//----------------------------------------------------------------------

void set_arcignore(const char *ignoretype)
{
   if (MTEngine::findEngine(makeSymbol(ignoretype)))
      MTEngine::setIgnoreEngine(ignoretype) ;
   else
      {
      if (strcmp(ignoretype,"-") != 0 && strcmp(ignoretype,"?") != 0)
	 cerr << "Unknown arc type" << endl ;
      cerr << "Valid arc types are:\n" ;
      MTEngineList::iterateAll(show_engine_type,&cerr) ;
      cerr << endl ;
      }
   return ;
}

// end of file lmpchart.cpp //
