/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmoutput.cpp		display functions			*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,1999,2000,2001,2002,2003	*/
/*		2004,2005,2006,2007,2008,2009 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "lmpchart.h"
#include "lmglobal.h"

/************************************************************************/
/*    Global data limited to this module				*/
/************************************************************************/

static const char *typelist_loc_name = "TYPE-LIST" ;
static const char *lm_arc_tag = ":LM" ;

/************************************************************************/
/************************************************************************/

static char *get_source_coverage(const ParseChart *chart,
				 const TargetWordList *wordlist)
{
   char *source_cover = FrNewC(char,chart->chartLength()) ;
   size_t len = wordlist->twlLength() ;
   for (size_t i = 0 ; i < len ; i++)
      {
      ChartArc *arc = (*wordlist)[i]->sourceArc();
      if (arc)
	 {
	 int start = arc->startPosition() ;
	 int cover = arc->coverage() ;
	 memset(source_cover+start,1,cover) ; // mark input words arc covers
	 }
      }
#ifndef NDEBUG
   if (LM_trace > 6)
      {
      cout << "; source_cover = " ;
      size_t length = chart->chartLength() ;
      for (size_t i = 0 ; i < length ; i++)
	 cout << (size_t)source_cover[i] ;
      cout << endl ;
      }
#endif /* !NDEBUG */
   return source_cover ;
}

//----------------------------------------------------------------------

static bool combine_arcs(const TargetWordList *wordlist,
			   char *source_cover, size_t start,
			   int &arclen, int &coverage, int &sourcepos,
			   const char *&sourcetext,
			   const char *&translation)
{
   NTRACE(4,(cout << "; combine_arcs(" << start << ")" << endl)) ;
   // figure out how many arcs could actually be involved by looking at the
   //   range from the first to last target words originating from the arc
   //   at 'start'
   // step 1: make the arc at 'start' the sole member of the set of active arcs
   FrLocalAlloc(ChartArc*,active,1024,wordlist->twlLength()) ;
   if (!active)
      {
      FrNoMemory("combining arcs") ;
      return false ;
      }
   active[0] = (*wordlist)[start]->sourceArc() ;
   size_t num_active = 1 ;
   size_t last = start + active[0]->arcLength() - 1 ;
   bool must_merge = false ;
   if (last >= wordlist->twlLength())
      {
      last = wordlist->twlLength() - 1 ;
      must_merge = true ;
      }
   size_t i ;
   bool expanded ;
   // check for the case where we've deleted one or more words from a multi-
   //   word arc
   for (i = start + 1 ; i <= last ; i++)
      {
      if ((*wordlist)[i]->sourceArc() != active[0])
	 {
	 must_merge = true ;
	 break ;
	 }
      }
   size_t srcfirst = (size_t)active[0]->startPosition() ;
   size_t srclast = srcfirst + active[0]->coverage() - 1 ;
   do {
      expanded = false ;
      // step 2: find the first and last target words origin. from active arcs
      for (i = wordlist->twlLength()-1 ; i > last ; i--)
	 {
	 ChartArc *srcarc = (*wordlist)[i]->sourceArc() ;
	 for (size_t a = 0 ; a < num_active ; a++)
	    {
	    if (srcarc == active[a])
	       {
	       last = i ;
	       expanded = true ;
	       must_merge = true ;
	       break ;
	       }
	    }
	 }
      coverage = srclast - srcfirst + 1 ;
      // step 3: collect all distinct arcs within the currently active range
      if (expanded)
	 {
	 for (i = start ; i <= last ; i++)
	    {
	    bool found = false ;
	    ChartArc *srcarc = (*wordlist)[i]->sourceArc() ;
	    for (size_t a = 0 ; a < num_active ; a++)
	       {
	       if (srcarc == active[a])
		  {
		  found = true ;
		  break ;
		  }
	       }
	    if (!found)
	       {
	       active[num_active++] = srcarc ;
	       int first = srcarc->startPosition() ;
	       int cover = srcarc->coverage() ;
	       if ((size_t)first < srcfirst)
		  srcfirst = (size_t)first ;
	       size_t last = (size_t)(first + cover - 1) ;
	       if (last > srclast)
		  srclast = last ;
	       }
	    }
	 // check whether there are any arcs whose source side is within the
	 //   active range but whose target side is completely outside the
	 //   range; those will be any we haven't put on the active list yet
	 for (i = 0 ; i < wordlist->twlLength() ; i++)
	    {
	    if (i >= (size_t)start && i <= last)
	       continue ;
	    ChartArc *arc = (*wordlist)[i]->sourceArc() ;
	    if (arc && (size_t)arc->startPosition() >= srcfirst &&
		(size_t)arc->startPosition() <= srclast)
	       {
	       bool found = false ;
	       for (size_t a = 0 ; a < num_active ; a++)
		  {
		  if (arc == active[a])
		     {
		     found = true ;
		     break ;
		     }
		  }
	       if (!found)
		  active[num_active++] = arc ;
	       }
	    }
	 }
      // repeat steps 2 and 3 until no more expansion of the range occurs
      } while (expanded) ;
   arclen = last - start + 1 ;
   // combine the arcs that are involved in the re-ordering
   // step 1: add in any null translations in the range we are combining
   //   or immediately preceding
   while (srcfirst > 0 && !source_cover[srcfirst-1])
      {
      srcfirst-- ;
      coverage++ ;
      source_cover[srcfirst] = '\1' ;	// mark source word as covered
      must_merge = true ;
      if (LM_trace > 5)
	 cout << "; adding null arc for word " << srcfirst << endl ;
      }
   if (!must_merge)
      {
      FrLocalFree(active) ;
      return false ; 
      }
   if (LM_trace > 4)
      cout << "; merging arcs covering words " << srcfirst << " to "
	   << srclast << " of the input." << endl ;
   // step 2: a quick in-place insertion sort to ensure that the arcs are in
   //   the original source text order
   for (i = 0 ; i < num_active-1 ; i++)
      {
      size_t first = active[i]->startPosition() ;
      size_t which = i ;
      for (size_t j = i+1 ; j < num_active ; j++)
	 if (active[j]->startPosition() < first)
	    {
	    which = j ;
	    first = active[j]->startPosition() ;
	    }
      if (which != i)
	 {
	 ChartArc *tmp = active[which] ;
	 memmove(active+i+1, active+i, (which-i)*sizeof(ChartArc*)) ;
	 active[i] = tmp ;
	 }
      }
   sourcepos = active[0]->startPosition() ;
   // step 3: build the source text string from source arcs and individual
   //   source words, including any null translations mixed in with the arcs
   //   we are combining
   // collect the source text
   size_t len = 0 ;
   for (i = 0 ; i < num_active ; i++)
      {
      const char *text = active[i]->sourceText() ;
      if (text)
	 len += strlen(text) + 1 ;
      }
   char *text = FrNewN(char,len+1) ;
   if (!text)
      {
      FrNoMemory("combining reordered arcs") ;
      FrLocalFree(active) ;
      return false ;
      }
   sourcetext = text ;
   for (i = 0 ; i < num_active ; i++)
      {
      const char *arctext = active[i]->sourceText() ;
      if (arctext)
	 {
	 strcpy(text,arctext) ;
	 text += strlen(arctext) ;
	 *text++ = ' ' ;		// ensure separation between words
	 }
      }
   FrLocalFree(active) ;
   if (text != sourcetext)
      text-- ;				// overwrite last space
   *text = '\0' ;
   // step 4: build the target text string from the individual target words
   len = arclen ;			// count spaces between words+final NUL
   for (i = start ; i <= last ; i++)
      len += strlen((*wordlist)[i]->name()->symbolName()) ;
   translation = FrNewN(char,len) ;
   text = (char*)translation ;
   for (i = start ; i <= last ; i++)
      {
      const FrSymbol *w = (*wordlist)[i]->name() ;
      len = strlen(w->symbolName()) ;
      memcpy(text,w->symbolName(),len) ; // add word to string
      text += len ;
      if (i < last)
	 *text++ = ' ' ;		// separate each word from next
      }
   *text = '\0' ;			// ensure proper termination
   return true ;
}

//----------------------------------------------------------------------

FrList *LmPrintableMetadata(const FrStruct *meta, bool show_all)
{
   FrList *metadata = 0 ;
   if (meta)
      {
      FrList *fields = listreverse(meta->fieldNames()) ;
      FrSymbol *symALIGN = makeSymbol("ALIGN") ;
      FrSymbol *symENGINE = makeSymbol("ENGINE") ;
      while (fields)
	 {
	 FrSymbol *key = (FrSymbol*)poplist(fields) ;
	 // don't include ENGINE or ALIGN metadata, that's handled separately
	 if (key == symENGINE || (key == symALIGN && !show_all))
	    continue ;
	 FrObject *data = meta->get(key) ;
	 if (data)
	    {
	    data = data->deepcopy() ;
	    if (!data->consp())
	       data = new FrList(data) ;
	    FrList *datalist = (FrList*)data ;
	    pushlist(key,datalist) ;
	    pushlist(datalist,metadata) ;
	    }
	 }
      }
   return metadata ;
}

//----------------------------------------------------------------------

FrList *LmCollectChartWalk(const TargetWordList *wordlist,
			   const ParseChart *pchart,
			   LmNGramModel **models, bool /*minimal*/)
{
   FrList *arcs = 0 ;
   FrSymbol *symLM = makeSymbol(lm_arc_tag) ;
   FrSymbol *symALIGN = makeSymbol("ALIGN") ;
   FrSymbol *symENGINE = makeSymbol("ENGINE") ;
   char *source_cover = get_source_coverage(pchart,wordlist) ;
   size_t num_words = wordlist->twlLength() ;
   if (num_words > 0 && wordlist->wordN(num_words-1) == pchart->endSentence())
      num_words-- ;
   size_t i = 0 ;
   int startpos = 0 ;
   while (i < num_words)
      {
      const TargetWord *tword = (*wordlist)[i] ;
      ChartArc *arc = tword->sourceArc() ;
      if (arc)
	 {
	 int arclen = arc->arcLength() ;
	 int coverage = arc->coverage() ;
	 int sourcepos = arc->startPosition() ;
	 const char *sourcetext = arc->sourceText() ;
	 const char *translation = arc->targetText() ;
	 if (tword->name() == symEPSILON)
	    {
	    translation = epsilon_arc_contents ;
	    if (translation && translation[0] == '=' && translation[1] == '\0')
	       {
	       if (arc->sourceWordSpan() == 1)
		  translation = arc->sourceWordInfo()->surface() ;
	       }
	    }
	 bool combined = combine_arcs(wordlist,source_cover,i,
				      arclen,coverage,sourcepos,
				      sourcetext,translation) ;
	 double score = 0.0 ; 
	 double total_weight = 0.0 ;
	 for (size_t m = 0 ; models && models[m] ; m++)
	    {
	    LmNGramModel *model = models[m] ;
	    double weight = model->weight() ;
	    total_weight += weight ;
	    LmWordID_t w[3] ;
	    size_t history = 0 ;
	    for (size_t j = (i>=2) ? i-2 : 0 ; j < i ; j++)
	       {
	       const TargetWord *tw = (*wordlist)[j] ;
	       if (tw && tw->IDcount(m) > 0)
		  w[history++] = tw->ID(m) ;
	       }
	    for (size_t j = i ; j < i+arclen ; j++)
	       {
	       if (history >= 3)
		  {
		  w[0] = w[1] ;
		  w[1] = w[2] ;
		  history = 2 ;
		  }
	       const TargetWord *tw = (*wordlist)[j] ;
	       if (tw && tw->IDcount(m) > 0)
		  w[history++] = tw->ID(m) ;
	       score += weight * model->probability(w,history) ;
	       }
	    }
	 if (total_weight > 0.0)
	    score /= total_weight ;
	 if (arclen > 1)
	    score /= arclen ;
	 FrString *xlat = new FrString(translation) ;
	 if (!combined)
	    {
	    const char *pref = arc->targetPrefix() ;
	    if (pref)
	       {
	       FrString *prefix = new FrString(pref) ;
	       prefix->append(xlat) ;
	       free_object(xlat) ;
	       xlat = prefix ;
	       }
	    const char *suff = arc->targetSuffix() ;
	    if (suff)
	       xlat->append(suff) ;
	    }
	 FrList *align = arc->sourceAlignments() ;
	 if (align)
	    pushlist(symALIGN,align) ;
	 FrList *metadata = LmPrintableMetadata(arc->metaData()) ;
	 FrList *result_arc = makelist(new FrInteger(startpos),
				       new FrInteger(startpos+coverage-1),
				       xlat,
				       new FrFloat(score),
				       new FrString(sourcetext),
				       new FrList(symENGINE,symLM),
				       align,(void*)0) ;
	 if (metadata)
	    result_arc = result_arc->nconc(metadata) ;
	 startpos += coverage ;
	 if (combined)
	    {
	    FrFree((char*)sourcetext) ;
	    FrFree((char*)translation) ;
	    }
	 pushlist(result_arc,arcs) ;
	 i += arclen ;
	 }
      else
	 {
	 i++ ;
	 }
      }
   FrFree(source_cover) ;
   return arcs ;
}

//----------------------------------------------------------------------

void output_augmented_chart(ostream &out, const ParseChart *pchart,
			    FrTextSpans *lattice, LmNGramModel **models,
			    const FrList *best, bool minimal)
{
   // add the best path to the original chart, and then dump it to the
   // specified file
   const FrList *translation = best ? (FrList*)(best->first()) : 0 ;
   const TargetWordList *wordlist = translation
                               	? (TargetWordList*)translation->third()
				: 0 ;
   FrList *list = 0 ;
   if (wordlist)
      {
      FrList *arcs = LmCollectChartWalk(wordlist,pchart,models,minimal) ;
      if (minimal)
	 {
	 FrTextSpans *walk = new FrTextSpans(lattice) ;
	 walk->newSpans(arcs) ;
	 list = walk->printable() ;
	 delete walk ;
	 }
      else
	 {
	 // add the arcs from the walk we just collected
	 lattice->newSpans(arcs) ;
	 // add the language modeler to the list of engines contributing to
	 // the chart
	 lattice->addMetaData(makeSymbol(typelist_loc_name),
			      makeSymbol(lm_arc_tag)) ;
	 list = lattice->printable() ;
	 }
      free_object(arcs) ;
      }
   else
      list = lattice->printable() ;
   out << list << endl << flush ;
   free_object(list) ;
   return ;
}

//----------------------------------------------------------------------

// end of file lmoutput.cpp //
