/************************************************************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmspan.cpp		functions to extract attribs of spans	*/
/*  LastEdit: 05apr10							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,1999,2000,2001,2002,2003	*/
/*		2004,2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "lmengine.h"
#include "lmodel.h"
#include "lmglobal.h"

/************************************************************************/
/************************************************************************/

double LmSpanQuality(const FrTextSpan *span)
{
   double quality = DEFAULT_QUALITY ;
   const FrObject *q = span ? span->getMetaDataSingle("Q") : 0 ;
   if (q && q->numberp())
      quality = q->floatValue() ;
   return quality ;
}

//----------------------------------------------------------------------

size_t LmSpanFrequency(const FrTextSpan *span)
{
   size_t freq = 0 ;
   const FrObject *f = span ? span->getMetaData("FREQUENCY") : 0 ;
   if (f)
      {
      if (f->consp() && ((FrList*)f)->first()->numberp())
	 freq = ((FrList*)f)->first()->intValue() ;
      if (f->consp() && ((FrList*)f)->second() &&
	  ((FrList*)f)->second()->numberp())
	 freq = ((FrList*)f)->second()->intValue() ;
      else if (f->numberp())
	 freq = f->intValue() ;
      }
   return freq ;
}

//----------------------------------------------------------------------

double LmSpanAlignmentScore(const FrTextSpan *span)
{
   double score = 0.0 ;
   const FrObject *a = span ? span->getMetaData("ALIGNMENT") : 0 ;
   if (a)
      {
      if (a->consp() && ((FrList*)a)->first()->numberp())
	 score = ((FrList*)a)->first()->floatValue() ;
      if (a->consp() && ((FrList*)a)->second() &&
	  ((FrList*)a)->second()->numberp())
	 score = ((FrList*)a)->second()->floatValue() ;
      else if (a->numberp())
	 score = a->floatValue() ;
      }
   return score ;
}

// end of file lmspan.C //
