/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Language Modeler -- configuration file parser			*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmfeat.h		feature and weight vectors		*/
/*  LastEdit: 21apr10							*/
/*									*/
/*  (c) Copyright 2010 Ralf Brown					*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __LMFEAT_H_INCLUDED
#define __LMFEAT_H_INCLUDED

#include "lmodel.h"

/************************************************************************/
/************************************************************************/

class LmFeatureIndex
   {
   private:
      size_t *m_index ;
      size_t m_numfeatures ;
   public:
      LmFeatureIndex(const FrList *feature_names,
		     const FrFeatureVectorMap *map) ;
      ~LmFeatureIndex() ;

      // accessors
      size_t numFeatures() const { return m_numfeatures ; }
      size_t index(size_t N) const 
	 { return (N < numFeatures()) ? m_index[N] : FrFeatureVectorMap::unknown ; }
   } ;

/************************************************************************/
/************************************************************************/

LmFeatureVector *LmMakeWeightVector(FrFeatureVectorMap *map,
				    const FrList *weights) ;

void LmAccumulateFeatures(FrFeatureVectorMap *map,
			  const FrTextSpans *lattice) ;
void LmAccumulateFeatures(const FrTextSpan *span,
			  FrFeatureVectorMap *map,
			  const FrList *prot_features = 0) ;
void LmAccumulateFeatures(const FrTextSpan *span, FrList *&features) ;

LmFeatureVector *LmMakeFeatureVector(const FrTextSpan *span,
				     FrFeatureVectorMap *map,
				     const LmFeatureIndex *) ;

#endif /* !__LMFEAT_H_INCLUDED */

/* end of file lmfeat.h */
