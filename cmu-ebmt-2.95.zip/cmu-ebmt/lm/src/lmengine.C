/************************************************************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmengine.cpp		translation engine base class		*/
/*  LastEdit: 29mar10							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,1999,2000,2001,2002,2003	*/
/*		2004,2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "lmengine.h"
#include "lmodel.h"
#include "lmmain.h"
#include "lmpchart.h"
#include "lmglobal.h"

/************************************************************************/
/*    Manifest constants for this module				*/
/************************************************************************/

/************************************************************************/
/*    Types for this module						*/
/************************************************************************/

/************************************************************************/
/*    Global variables for class MTEngine				*/
/************************************************************************/

bool MTEngine::have_overrides = false ;

size_t MTEngine::global_word_count_SL = 0 ;
size_t MTEngine::global_selected_arcs = 0 ;
size_t MTEngine::global_selected_TL = 0 ;

/************************************************************************/
/*	A dummy engine so that we can process charts which already	*/
/*    contain our own output						*/
/************************************************************************/

static MTEngine lm(makeSymbol(":LM"),"Language Modeler",CE_LM,1.0) ;

/************************************************************************/
/*    Helper functions		 					*/
/************************************************************************/

//----------------------------------------------------------------------

inline int LM_stricmp(const char *s1, const char *s2)
{
   int diff = 0 ;
   const unsigned char *map = uppercase_table ;
   while ((diff = map[(unsigned char)*s1] - map[(unsigned char)*s2]) == 0 &&
	  *s1)
      {
      s1++ ;
      s2++ ;
      }
   return diff ;
}

//----------------------------------------------------------------------
// GCC's SPARC libs use signed chars, and thus mess up when high bit chars used

inline int compare(const char *s1, const char *s2)
{
   int diff = 0 ;
   while ((diff = ((unsigned char)*s1 - (unsigned char)*s2)) == 0 && *s1)
      {
      s1++ ;
      s2++ ;
      }
   return diff ;
}

//----------------------------------------------------------------------

static size_t word_count(const char *str)
{
   size_t wc = 0 ;
   if (str)
      {
      while (*str)
	 {
	 FrSkipWhitespace(str) ;
	 if (*str)
	    wc++ ;
	 FrSkipToWhitespace(str) ;
	 }
      }
   return wc ;
}

/************************************************************************/
/*    Methods for class MTEngine					*/
/************************************************************************/

MTEngine::MTEngine(FrSymbol *typetag, const char *type_name,
		   ChartEntryType typ, bool partial_res)
   : m_engines(this,0,MTEngineList::numInstances(),type_name,typetag)
{
   arctype = typ ;
   const char *tag_str = FrPrintableName(typetag) ;
   if (tag_str && *tag_str == ':')
      tag_str++ ;
   char *featname = Fr_aprintf("Engine-%s",tag_str) ;
   m_featureID = LMfeature_map.addFeature(featname) ;
   FrFree(featname) ;
   engine_number = MTEngineList::numInstances() ;
   ignore_engine = false ;
   partial_results = partial_res ;	// can engine produce partial coverage?
   setMaxAlts(~0,~0) ;			// no limit to allowed ambiguity
   overridden = 0 ;
   totally_overridden = 0 ;
   m_overrides = m_total_overrides = 0 ;
   arc_count = selected_arc_count = 0 ;
   threshold_score = -1000000 ;
   total_coverage = 0 ;
   word_count_SL = word_count_TL = 0 ;
   byte_count_SL = byte_count_TL = 0 ;
   selected_word_count_SL = selected_word_count_TL = 0 ;
   selected_byte_count_SL = selected_byte_count_TL = 0 ;
   return ;
}

//----------------------------------------------------------------------

MTEngine::~MTEngine()
{
   free_object(m_overrides) ;		m_overrides = 0 ;
   free_object(m_total_overrides) ;	m_total_overrides = 0 ;
   return ;
}

//----------------------------------------------------------------------

bool MTEngine::configure(MTEngineConfig *config)
{
   while (config && config->tag != engineTag())
      config = config->next ;
   bool have_config ;
   if (config)
      {
      have_config = true ;
      untransl_penalty = config->untrans_penalty ;
      threshold_score = config->threshold ;
      if (config->max_alts || config->max_alts1)
	 setMaxAlts(config->max_alts? config->max_alts: ~0,config->max_alts1) ;
      if (config->options & ENGINE_IGNORE_ARCS)
	 ignore_engine = true ;
      const FrList *ovr = config->overrides ;
      const FrList *t_ovr = config->total_overrides ;
      m_overrides = ovr ? (FrList*)ovr->deepcopy() : 0 ;
      m_total_overrides = t_ovr ? (FrList*)t_ovr->deepcopy() : 0 ;
      if (untransl_penalty < 0.0)
	 untransl_penalty = DEFAULT_UNTRANS_PENALTY ;
      }
   else
      {
      have_config = false ;
      untransl_penalty = DEFAULT_UNTRANS_PENALTY ;
      }
   return have_config ;
}

//----------------------------------------------------------------------

MTEngine *MTEngine::findEngine(FrSymbol *typetag)
{
   if (!typetag)
      return 0 ;
   MTEngineList *eng = MTEngineList::find(typetag) ;
   return eng ? eng->instance() : 0 ;
}

//----------------------------------------------------------------------

ChartArc *MTEngine::readArc(const FrTextSpan *span, ParseChart *chart,
			    ChartArc *arc, const FrList *morph,
			    const FrList *align, const FrList *altseq)
{
   if (ignore_engine)
      return arc ;
   double score = span->score() ;
   if (score < threshold_score)
      return arc ;
   size_t startpos = span->start() ;
   int cover = span->spanLength() ;
   LmNGramModel **models = chart->models() ;
   FrSymbolTable *symtab = chart->symtab() ;
   const FrStruct *metadata = span->metaData() ;
   FrSymbolTable *origsym = symtab->select() ;
   char *source = span->initialText() ;
   char *translation = span->getText() ;
   if (show_coverage)
      newArc(cover,word_count(translation)) ;
   ChartArc *prev_arc = 0 ;
   LmFeatureVector *features = LmMakeFeatureVector(span,chart->featureMap(),
						   chart->featureIndex()) ;
   if (!arc || !arc->merge(this,source,translation,altseq,cover,features,
			   &prev_arc))
      {
      arc = new ChartArc(this,source,translation,align,startpos,cover,
			 features,models,morph,altseq,chart,arc) ;
      if (prev_arc)
	 {
	 // 'prev_arc' has already had the new scores and weight added in to
	 //   all previous values, so just copy them into the new arc
	 arc->replaceFeatures(prev_arc->features()) ;
	 arc->setWeight(prev_arc->weight()) ;
	 }
      arc->setMetaData(metadata) ;
      chart->addedArc() ;
      }
   else
      {
      FrFree(source) ;
      FrFree(translation) ;
      }
   delete features ;
   // update chunking bonus to be maximum of all arcs merged into this one
   arc->setChunkingBonus(span) ;
   origsym->select() ;
   return arc ;
}

//----------------------------------------------------------------------

void MTEngine::newArc(size_t sourcelength, size_t targetlength)
{
   arc_count++ ;
   word_count_SL += sourcelength ;
   word_count_TL += targetlength ;
   return ;
}

//----------------------------------------------------------------------

void MTEngine::selectArc(size_t sourcelength, size_t targetlength)
{
   selected_arc_count++ ;
   selected_word_count_SL += sourcelength ;
   selected_word_count_TL += targetlength ;
   return ;
}

//----------------------------------------------------------------------

void MTEngine::updateGlobalCounts(size_t sourcelength, size_t targetlength)
{
   global_selected_arcs++ ;
   global_word_count_SL += sourcelength ; 
   global_selected_TL += targetlength ;
   return ;
}

//----------------------------------------------------------------------

void MTEngine::updateCoverage(size_t cover)
{
   total_coverage += cover ;
   return ;
}

//----------------------------------------------------------------------

void MTEngine::showStatsHeader(FILE *fp)
{
   if (!fp)
      return ;
   fprintf(fp,"Engine\t Total\tSource\tTarget\tSelect\tSelect\tSelect\n") ;
   fprintf(fp," Name \t Arcs \tBytes \tBytes \t Arcs \tSrcByt\tTrgByt\n") ;
   fprintf(fp,"======\t =====\t======\t======\t======\t======\t======\n") ;
   return ;
}

//----------------------------------------------------------------------

void MTEngine::showStats(FILE *fp)
{
   if (!fp)
      return ;
   if (arc_count == 0 && !verbose)
      return ;
   const char *name = engineTag() ? engineTag()->symbolName() : "(?)" ;
   if (*name == ':')
      name++ ;
   fprintf(fp,"%8.8s%7lu\t%6lu\t%6lu\t%6lu\t%6lu\t%6lu\n",
	   name,(unsigned long)arc_count,(unsigned long)word_count_SL,
	   (unsigned long)word_count_TL,(unsigned long)selected_arc_count,
	   (unsigned long)selected_word_count_SL,
	   (unsigned long)selected_word_count_TL) ;
   return ;
}

//----------------------------------------------------------------------

void MTEngine::showStatsFooter(FILE *fp)
{
   if (!fp)
      return ;
   fprintf(fp,"  Total: \t \t \t%6lu\t%6lu\t%6lu\n",
	   (unsigned long)global_selected_arcs,
	   (unsigned long)global_word_count_SL,
	   (unsigned long)global_selected_TL) ;
   return ;
}

//----------------------------------------------------------------------

static bool set_untrans_penalty(MTEngine *eng, va_list args)
{
   FrVarArg(const char*,tag) ;
   FrVarArg(double,penalty) ;
   if (tag[0] == '*' && tag[1] == '\0')
      {
      eng->untransPenalty(penalty) ;
      }
   else if (strcmp(tag,eng->engineTag()->symbolName()) == 0)
      {
      eng->untransPenalty(penalty) ;
      return false ;
      }
   return true ;
}

//----------------------------------------------------------------------

void MTEngine::setUntranslatedPenalty(const char *tag, double penalty)
{
   MTEngineList::iterateAll(set_untrans_penalty,tag,penalty) ;
   return ;
}

//----------------------------------------------------------------------

void MTEngine::setIgnoreEngine(const char *type, bool ignore)
{
   if (strcmp(type,"*") != 0)  // don't want to ignore all types!
      {
      MTEngineList *eng = MTEngineList::find(type) ;
      if (eng)
	 eng->instance()->ignoreEngine(ignore) ;
      }
   return ;
}

//----------------------------------------------------------------------

static bool collect_override_map(MTEngine *eng, va_list args)
{
   FrVarArg(FrList **,map) ;
   FrVarArg(int*,all_engines) ;
   FrSymbol *tag = eng->engineTag() ;
   int bit = 1L << (int)eng->engineID() ;
   (*all_engines) |= bit ;
   FrInteger *mask = new FrInteger(bit) ;
   pushlist(new FrList(tag,mask),*map) ;
   return true ;
}

//----------------------------------------------------------------------

static bool build_bitmask(MTEngine *eng, va_list args)
{
   FrVarArg(const FrList*,map) ;
   FrVarArg(bool*,have_overrides) ;
   int mask = 0 ;
   for (const FrList *ovr = eng->overrides() ; ovr ; ovr = ovr->rest())
      {
      FrList *assoc = (FrList*)map->assoc(ovr->first()) ;
      if (assoc)
	 {
	 FrInteger *bitmask = (FrInteger*)assoc->second() ;
	 mask |= (int)*bitmask ;
	 }
      }
   eng->setOverridden(mask) ;
   mask = 0 ;
   for (const FrList *ovr = eng->totalOverrides() ; ovr ; ovr = ovr->rest())
      {
      FrList *assoc = (FrList*)map->assoc(ovr->first()) ;
      if (assoc)
	 {
	 FrInteger *bitmask = (FrInteger*)assoc->second() ;
	 mask |= (int)*bitmask ;
	 }
      }
   eng->totallyOverridden(mask) ;
   if (eng->overriddenEngines() || eng->totallyOverriddenEngines())
      (*have_overrides) = true ;
   return true ;
}

//----------------------------------------------------------------------

static bool check_circularity_2(MTEngine *eng, va_list args)
{
   FrVarArg(MTEngine*,engine1) ;
   if (eng != engine1)
      {
      FrVarArg(int*,all_engines) ;
      FrVarArg(int*,msk) ;
      int mask = *msk ;
      int ovr = (engine1->overriddenEngines() |
		 engine1->totallyOverriddenEngines()) ;
      if (((1L << (int)eng->engineID()) & ovr) != 0 &&
	  ((eng->overriddenEngines() & mask) != 0 ||
	   (eng->totallyOverriddenEngines() & mask) != 0))
	 {
	 FrWarningVA("circular Overrides: or Total-Override: in configuration\n"
		     "\toverride disabled for %s",
		     eng->engineTag()->symbolName()) ;
	 eng->setOverridden(eng->overriddenEngines() & ~mask) ;
	 eng->totallyOverridden(eng->totallyOverriddenEngines() & ~mask) ;
	 }
      (*msk) &= ~eng->overriddenEngines() ;
      (*msk) &= ~eng->totallyOverriddenEngines() ;
      if (mask == 0)
	 {
	 (*all_engines) &= ~(1L << (int)engine1->engineID()) ;
	 return false ;			// no need to iterate further
	 }
      }
   return true ;
}

//----------------------------------------------------------------------

static bool check_circularity(MTEngine *eng, va_list args)
{
   FrVarArg(int*,all_engines) ;
   int mask = 1L << (int)eng->engineID() ;
   MTEngineList::iterateAll(check_circularity_2,eng,all_engines,&mask) ;
   return true ;
}

//----------------------------------------------------------------------

static bool clear_overrides(MTEngine *eng, va_list)
{
   eng->setOverridden(0) ;
   eng->totallyOverridden(0) ;
   return true ;
}

//----------------------------------------------------------------------

void MTEngine::setupOverrides()
{
   // step 1: scan the list of engines to get a mapping from tag to bitmask
   FrList *map = 0 ;
   int all_engines = 0 ;
   MTEngineList::iterateAll(collect_override_map,&map,&all_engines) ;
   // step 2: build the bitmask for each engine
   MTEngineList::iterateAll(build_bitmask,map,&have_overrides) ;
   // step 3: see whether there are circular overrides; if yes, clear all
   //     bitmasks, effectively turning off the override feature
   MTEngineList::iterateAll(check_circularity,&all_engines) ;
   if (MTEngine::numEngines() > 0 && all_engines == 0)
      {
      FrWarning("circularity in an engine's Overrides: or Total-Override:\n"
		"\tdisabling all overrides....") ;
      MTEngineList::iterateAll(clear_overrides) ;
      have_overrides = false ;
      }
   free_object(map) ;
   return ;
}

//----------------------------------------------------------------------

bool MTEngine::engineOverrides(FrSymbol *tag) const
{
   return m_overrides->member(tag) != 0 ;
}

//----------------------------------------------------------------------

bool MTEngine::engineTotallyOverrides(FrSymbol *tag) const
{
   return m_total_overrides->member(tag) != 0 ;
}

//----------------------------------------------------------------------

bool MTEngine::validInfo(FrObject *arcobj,size_t minlen,size_t maxlen) const
{
   if (!arcobj)
      FrWarningVA("missing :INFO field for %s",engineName()) ;
   else
      {
      if (arcobj->consp())
	 {
	 size_t len = ((FrList*)arcobj)->listlength() ;
	 if (len >= minlen && len <= maxlen)
	    return !ignore_engine ;
	 }
      FrWarningVA("invalid :INFO field for %s arc",engineName()) ;
      }
   return false ;
}

/************************************************************************/
/************************************************************************/

static bool configure_translation_engine(MTEngine *eng, va_list args)
{
   FrVarArg(MTEngineConfig*,config) ;
   if (!eng->configure(config) && verbose)
      {
      if (eng != &lm)
	 cout << "No configuration for engine " << eng->engineTag()
	      << ", using defaults" << endl ;
      }
   return true ;
}

//----------------------------------------------------------------------

void configure_translation_engines(MTEngineConfig *config)
{
   MTEngineList::iterateAll(configure_translation_engine,config) ;
   // create new MTEngine instances for all named engines which don't yet have
   //   one
   for ( ; config ; config = config->next)
      {
      if (!MTEngine::findEngine(config->tag))
	 {
	 bool partial = (config->options & ENGINE_FULLSENT_ONLY) == 0 ;
	 ChartEntryType arctype = ChartArc::allocateArcType(config->tag) ;
	 MTEngine *eng = new MTEngine(config->tag,config->name,arctype,
				      partial) ;
	 if (eng)
	    {
	    eng->configure(config) ;
	    }
	 }
      }
   MTEngine::setIgnoreEngine(":LM",true) ;
   MTEngine::setupOverrides() ;
   return ;
}

//----------------------------------------------------------------------

bool free_translation_engine(MTEngine *eng, va_list /*args*/)
{
   if (eng && eng->engineID() > CE_LM)
      delete eng ;
   return true ;
}

//----------------------------------------------------------------------

void free_translation_engines()
{
   MTEngineList::iterateAll(free_translation_engine,0) ;
   return ;
}

// end of file lmengine.cpp //
