/************************************************************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmengine.h		translation engine base class		*/
/*  LastEdit: 29mar10							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __LMENGINE_H_INCLUDED
#define __LMENGINE_H_INCLUDED

#ifndef __LMARCS_H_INCLUDED
#include "lmarcs.h"
#endif

#ifndef __LMBASE_H_INCLUDED
#include "lmbase.h"
#endif

#ifndef __LMCONFIG_H_INCLUDED
#include "lmconfig.h"
#endif

#ifdef FrSTRICT_CPLUSPLUS
# include <cmath>
#else
# include <math.h>
#endif /* FrSTRICT_CPLUSPLUS */

/************************************************************************/
/*	Manifest constants						*/
/************************************************************************/

#define TOKEN_IGNORE 		"<ignore>"

#define DEFAULT_UNTRANS_PENALTY 0.7	// reduce 30% if untranslated arc
#define DEFAULT_QUALITY		1.0

// how confident are we in our engines?
#define DEFAULT_DICT_WEIGHT     0.10
#define DEFAULT_EBMT_WEIGHT     2.00
#define DEFAULT_PASS_WEIGHT     0.01
#define DEFAULT_SYSTRAN_WEIGHT  1.00

#define MAX_BONUS_LENGTH        16	// size above which length bonus const.

/************************************************************************/
/*	declaration of class MTEngine					*/
/************************************************************************/

typedef FrSelfRegistering<MTEngine> MTEngineList ;

class MTEngine : public LMBaseObject
   {
   private:
      MTEngineList m_engines ;
      static bool have_overrides ;
   protected:
      double threshold_score ;
      double untransl_penalty ;
      size_t engine_number ;
      FrList *m_overrides ;
      FrList *m_total_overrides ;
      size_t m_featureID ;
      size_t max_alts ;
      size_t max_alts1 ;
      size_t arc_count ;
      size_t total_coverage ;
      size_t word_count_SL ;
      size_t word_count_TL ;
      size_t byte_count_SL ;
      size_t byte_count_TL ;
      size_t selected_arc_count ;
      size_t selected_word_count_SL ;
      size_t selected_word_count_TL ;
      size_t selected_byte_count_SL ;
      size_t selected_byte_count_TL ;
      static size_t global_word_count_SL ;
      static size_t global_selected_arcs ;
      static size_t global_selected_TL ;
      ChartEntryTypes overridden ;
      ChartEntryTypes totally_overridden ;
      ChartEntryType arctype ;
      bool ignore_engine ;
      bool partial_results ;
   public:
      MTEngine(FrSymbol *typetag, const char *type_name,
	       ChartEntryType typ, bool partial_res = true) ;
      ~MTEngine() ;
      bool configure(MTEngineConfig *config) ;

      // I/O functions
      ChartArc *readArc(const FrTextSpan *span, ParseChart *chart,
			ChartArc *arc, const FrList *morph,
			const FrList *align, const FrList *altseq) ;

      // test functions
      bool validInfo(FrObject *arcobj,size_t minlen,size_t maxlen) const ;
      bool engineOverrides(FrSymbol *tag) const ;
      ChartEntryTypes overriddenEngines() const { return overridden ; }
      bool engineTotallyOverrides(FrSymbol *tag) const ;
      ChartEntryTypes totallyOverriddenEngines() const
	    { return totally_overridden ; }

      // engine description functions
      const char *engineName() const { return m_engines.name() ; }
      FrSymbol *engineTag() const { return m_engines.tag() ; }
      size_t engineNumber() const { return engine_number ; }
      ChartEntryType engineID() const { return arctype ; }
      size_t featureID() const { return m_featureID ; }
      size_t maxAlts() const { return max_alts ; }
      size_t maxAlts1() const { return max_alts1 ; }

      // state access functions
      bool beingIgnored() const { return ignore_engine ; }
      bool partialResults() const { return partial_results ; }
      const FrList *overrides() const { return m_overrides ; }
      const FrList *totalOverrides() const { return m_total_overrides ; }

      double untranslatedPenalty() const { return untransl_penalty ; }

      // manipulators
      void untransPenalty(double pen) { untransl_penalty = pen ; }
      void ignoreEngine(bool ign) { ignore_engine = ign ; }
      void setOverridden(bool ovr) { overridden = ovr ; }
      void totallyOverridden(bool ovr) { totally_overridden = ovr ; }

      // statistics functions
      void newArc(size_t sourcelength, size_t targetlength) ;
      void selectArc(size_t sourcelength, size_t targetlength) ;
      void updateCoverage(size_t cover) ;
      void showStats(FILE *outfp) ;
      static void updateGlobalCounts(size_t sourcelength,
				     size_t targetlength) ;
      static void showStatsHeader(FILE *outfp) ;
      static void showStatsFooter(FILE *outfp) ;

      // static methods for class
      static MTEngine *findEngine(FrSymbol *typetag) ;
      static size_t maxEngines() { return ChartArc::maxEngines() ; }
      static size_t numEngines()
	 { return MTEngineList::numInstances() ; }
      static bool haveOverrides() { return have_overrides ; }

      // setup functions
      static void setUntranslatedPenalty(const char *tag, double penalty) ;
      static void setIgnoreEngine(const char *tag, bool ignore = true) ;
      static void setupOverrides() ;
      void setMaxAlts(size_t max, size_t max1)
	 { max_alts = max ; max_alts1 = max1 ? max1 : max ; }
   } ;

//----------------------------------------------------------------------

void configure_translation_engines(MTEngineConfig *) ;
void free_translation_engines() ;

#endif /* !__LMENGINE_H_INCLUDED */

// end of file lmengine.h //
