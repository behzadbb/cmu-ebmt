/************************************************************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmovrlap.cpp	support for overlapping arcs			*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 2002,2003,2006,2007,2008,2009 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "lmarcs.h"
#include "lmodel.h"
#include "lmglobal.h"

/************************************************************************/
/************************************************************************/

#define min(x,y) ((x < y) ? x : y)
#define max(x,y) ((x > y) ? x : y)

/************************************************************************/
/************************************************************************/

static size_t count_gaps(const ChartArc *arc, size_t first, size_t last)
{
   size_t gap_count = 0 ;
   for (size_t i = first ; i <= last ; i++)
      {
      if (arc->targetWordInfo(i)->isGapMarker())
	 gap_count++ ;
      }
   return gap_count ;
}

//----------------------------------------------------------------------

static size_t count_matching_words(const ChartArc *arc1, const ChartArc *arc2,
				   size_t overlap,
				   bool allow_any_overlap = false)
{
   size_t num_words1 = arc1->arcLength() ;
   size_t num_words2 = arc2->arcLength() ;
   size_t max_match = overlap ;
   if (overlap > num_words2)
      {
      if (allow_any_overlap)
	 max_match = num_words2 ;
      else
	 max_match = overlap = num_words2 ;
      }
   size_t offset = num_words1 - overlap ;
   size_t count = 0 ;
   for (size_t i = 0 ; i < max_match ; i++)
      {
      const TargetWord *words1 = arc1->targetWordInfo(i+offset) ;
      const TargetWord *words2 = arc2->targetWordInfo(i) ;
      if (words1->name() == words2->name())
	 count++ ;
      else
	 {
	 bool gap1 = words1->isGapMarker() ;
	 bool gap2 = words2->isGapMarker() ;
	 if (gap1 != gap2)
	    count++ ;
	 else
	    break ;
	 }
      }
   return count ; 
}

//----------------------------------------------------------------------

bool LmCompatibleTargetWords(const TargetWord *w1,
			       const TargetWord *w2)
{
   bool gap1 = w1->isGapMarker() ;
   bool gap2 = w2->isGapMarker() ;
   const FrSymbol *class1 = w1->matchClass() ;
   const FrSymbol *class2 = w2->matchClass() ;
   if (gap1 && gap2 && (class1 || class2) &&
       !equal_casefold(class1,class2,lowercase_table))
      return false ;
   else if (gap1 != gap2)
      {
      if (gap1)
	 {
	 if (class1 && (strict_gap_filler || class2) &&
	     !equal_casefold(class1,class2,lowercase_table))
	    return false ;
	 }
      else // (gap2)
	 {
	 if (class2 && (strict_gap_filler || class1) &&
	     !equal_casefold(class2,class1,lowercase_table))
	    return false ;
	 }
      }
   else if (!gap1)
      {
      // neither word is a gap marker, so they need to be the same (modulo
      //    upper/lowercase)
      return equal_casefold(w1->name(),w2->name(),lowercase_table) ;
      }
   return true ;
}

//----------------------------------------------------------------------

static bool compatible_source_align(const uint16_t *source1,
				      const uint16_t *source2,
				      size_t min_srcword, size_t max_srcword)
{
   if (!source1 && !source2)
      return true ;			// no alignment info, so anything goes
   else
   if (!source1 || !source2)
      return false ;

   size_t i(0) ;
   size_t j(0) ;
   while (source1[i] != SOURCE_ALIGN_EOD && source2[j] != SOURCE_ALIGN_EOD)
      {
      if (source1[i] < source2[j])
	 {
	 if (source1[i] < min_srcword || source1[i] > max_srcword)
	    i++ ;
	 else
	    return false ;
	 }
      else if (source1[i] > source2[j])
	 {
	 if (source2[j] < min_srcword || source2[j] > max_srcword)
	    j++ ;
	 else
	    return false ;
	 }
      else
	 {
	 // equal, so continue with the next pair
	 i++ ;
	 j++ ;
	 }
      }
   while (source1[i] != SOURCE_ALIGN_EOD && source1[i] > max_srcword)
      i++ ;
   while (source2[j] != SOURCE_ALIGN_EOD && source2[j] > max_srcword)
      j++ ;
   return (source1[i] == SOURCE_ALIGN_EOD && source2[j] == SOURCE_ALIGN_EOD) ;
}

//----------------------------------------------------------------------

static bool compatible_source_words(size_t offset,
				      const ChartArc *arc1,
				      const ChartArc *arc2, size_t &gapfill,
				      size_t &gapfill2)
{
   gapfill = 0 ;
   gapfill2 = 0 ;
   size_t last = offset + arc2->arcLength() ;
   bool extendsrc = (arc2->endPosition() > arc1->endPosition()) ;
   bool extendtrg = false ;
   if (last >= arc1->arcLength())
      {
      extendtrg = true ;
      last = arc1->arcLength() ;
      }
   size_t minsrc = arc1->startPosition() ;
   size_t maxsrc = arc1->endPosition() ;
   if (maxsrc < arc2->endPosition())
      maxsrc = arc2->endPosition() ;
   for (size_t i = offset ; i < last ; i++)
      {
      const TargetWord *w1 = arc1->targetWordInfo(i) ;
      const TargetWord *w2 = arc2->targetWordInfo(i-offset) ;
      if (!LmCompatibleTargetWords(w1,w2))
	  return false ;
      else if (!compatible_source_align(w1->sourceWords(),w2->sourceWords(),
					minsrc,maxsrc))
	 {
	 // don't allow a gap filler to match a different gap filler, or two
	 //   incompatible words to match
	 return false ;
	 }
      if (w1->isGapMarker())
	 gapfill++ ;
      if (w2->isGapMarker())
	 gapfill2++ ;
      }
   // compatible only if the arc fills a gap, extends both source and target,
   //   or extends neither
   return ((extendsrc && extendtrg) || gapfill > 0 ||
	   (arc1->endPosition() == arc2->endPosition() &&
	    last == arc1->arcLength())) ;
}

//----------------------------------------------------------------------

static bool compatible_source_words(const ChartArc *arc1,
				      const ChartArc *arc2,
				      size_t src_overlap,
				      size_t &trg_overlap, bool &fills_gap,
				      bool *fills_gap_2)
{
   if (src_overlap == 0 && !arc1->hasGapMarkers() && !arc2->hasGapMarkers())
      return false ;
   if (arc2->startPosition() < arc1->startPosition() &&
       arc2->endPosition() > arc1->startPosition())
      return false ;	      // candidate successor can't precede arc
   if (!allow_jigsaw_combination && max_source_overlap == 0)
      return false ;			// no sense checking if not allowed
   else if (max_source_overlap == 0 && !arc1->hasGapMarkers() &&
	    !arc2->hasGapMarkers())
      return false ;			// no need to try jigsaw if no gaps
   size_t len1 = arc1->arcLength() ;

//cout<<"compatsrc("<<arc1<<","<<arc2<<")"<<endl;
   // try each possible overlap between the two arcs
   for (size_t start1 = 0 ; start1 < len1 ; start1++)
      {
      size_t gapfill ;
      size_t gapfill2 ;
      if (compatible_source_words(start1,arc1,arc2,gapfill,gapfill2))
	 {
	 if (gapfill)
	    fills_gap = true ;
	 if (fills_gap_2 && gapfill2)
	    *fills_gap_2 = true ;
	 trg_overlap = len1 - start1 ;
	 return (src_overlap + gapfill > 0) ;
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

size_t LmTargetOverlap(const ChartArc *arc1, const ChartArc *arc2,
		       size_t src_overlap)
{
   size_t max_overlap = arc1->arcLength() ;
   if (arc2->arcLength() < max_overlap)
      max_overlap = arc2->arcLength() ;
   if (src_overlap == 0)
      {
      // find the longest prefix of the next arc that matches a suffix
      //   of the current arc
      for (size_t i = max_overlap ; i > 0 ; i--)
	 {
	 if (count_matching_words(arc1,arc2,i) == i)
	    return i ;
	 }
      }
   else
      {
      // find the amount of overlapping target text nearest in length to
      //   the number of words overlapping in the source
      size_t mindiff = ~0 ;
      size_t closest = 0 ;
      for (size_t i = max_overlap ; i > 0 ; i--)
	 {
	 if (count_matching_words(arc1,arc2,i) == i)
	    {
	    size_t diff = (i>src_overlap) ? i - src_overlap : src_overlap - i ;
	    if (diff < mindiff)
	       {
	       mindiff = diff ;
	       closest = i ;
	       }
	    }
	 }
      return closest ;
      }
   return 0 ;
}

//----------------------------------------------------------------------

bool LmOverlapAllowed(const ChartArc *arc1, const ChartArc *arc2,
		      size_t src_overlap,size_t &trg_overlap,
		      size_t max_overlap, bool &fills_gap,
		      bool *fills_gap_2)
{
   // as a special case, if max_overlap is set to zero, we disallow all
   //   overlapping of arcs
   if (max_overlap == 0)
      return false ;
   // if we have alignment information, we can allow (almost) arbitrary overlaps
   //   provided that the alignments are compatible
   if (arc1->hasAlignments() && arc2->hasAlignments() &&
       compatible_source_words(arc1,arc2,src_overlap,trg_overlap,
			       fills_gap,fills_gap_2))
      {
      // if the successor completely overlaps the predecessor arc but does not
      //   extend the translation, or at least have some non-gaps in common,
      //   we can't overlap it
      if (src_overlap >= arc1->sourceWordCount() &&
	  (trg_overlap > arc2->arcLength() ||
	   (trg_overlap == arc2->arcLength() && !fills_gap)))
	 return false ;
      return true ;
      }
   // without alignment information, we can still permit the overlap, within
   //   pre-set limits
   if (src_overlap == 0)		// must have both source and target
      return false ;			//   overlap
   if (src_overlap > max_overlap)
      return false ;
   trg_overlap = LmTargetOverlap(arc1,arc2,src_overlap) ;
   size_t trg_len = arc2->arcLength() ;
   if (trg_overlap == 0 || trg_overlap >= trg_len)
      return false ;
   size_t src_len = arc2->sourceWordSpan() ;
   if (src_overlap >= src_len && trg_overlap < trg_len)
      return false ;			// no extending trg w/o ext. src!
   bool allowed ;
   if (max_overlap_diff >= 1.0)
      {
      int diff = src_overlap - trg_overlap ;
      if (diff < 0) diff = -diff ;
      allowed = (diff <= max_overlap_diff) ;
      }
   else
      {
      double ratio = (min(src_overlap,trg_overlap) / 
		      (double)max(src_overlap,trg_overlap)) ;
      allowed = (1.0 - ratio) <= max_overlap_diff ;
      }
   if (allowed && arc1->hasGapMarkers())
      fills_gap = true ;
   if (fills_gap_2 && allowed && arc2->hasGapMarkers())
      {
      size_t overlap_len = min(trg_overlap,arc2->arcLength()) ;
      *fills_gap_2 = (count_gaps(arc2,0,overlap_len) != 0) ;
      }
   return allowed ;
}

//----------------------------------------------------------------------

// end of file lmovrlap.cpp //
