/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.91							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmbuild.cpp	  	functions for building an n-gram model	*/
/*  LastEdit: 17feb09							*/
/*									*/
/*  (c) Copyright 1996,1997,1998,1999,2000,2001,2002,2003,2004,2006,	*/
/*		2007,2008,2009 Ralf Brown				*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "lmodel.h"
#include "lmngram.h"
#include "lmbuild.h"
#include "lmglobal.h"

# include <fcntl.h>
#if defined(__MSDOS__) || defined(__WATCOMC__) || defined(_MSC_VER)
#  include <io.h>
#  include <dos.h>
#endif
#ifdef unix
#  include <unistd.h>
#endif

/************************************************************************/
/*	Manifest Constants						*/
/************************************************************************/

#define MAXWORDLEN (FrMAX_SYMBOLNAME_LEN-1)

#define STDIN_HANDLE 0

/************************************************************************/
/*	Types for this module						*/
/************************************************************************/

class VocabPointers
   {
   private:
      FrVocabulary *m_basevocab ;
      FrVocabulary *m_surfvocab ;
      FrVocabulary *m_stopvocab ;
   public:
      VocabPointers(FrVocabulary *base, FrVocabulary *surf, FrVocabulary *stop)
	 { m_basevocab = base ; m_surfvocab = surf ; m_stopvocab = stop ; }

      FrVocabulary *baseVocabulary() const { return m_basevocab ; }
      FrVocabulary *surfaceVocabulary() const { return m_surfvocab ; }
      FrVocabulary *stopwordVocabulary() const { return m_stopvocab ; }

   } ;

/************************************************************************/
/*	Global Variables						*/
/************************************************************************/

bool read_filenames_from_stdin = false ;
static char **abbreviations = 0 ;

static size_t total_stop_words = 0 ;

//----------------------------------------------------------------------

bool bilingual_data = false ;
bool auto_insert_EOS = false ;
bool bilingual_use_source = false ;

/************************************************************************/
/*    helper functions							*/
/************************************************************************/

/************************************************************************/
/*    Trigram-generation functions					*/
/************************************************************************/

static int tgfile = -1 ;
static FrChar16 _tgbuffer[8*BUFSIZ] ;
static char * const tgbuffer = (char*)_tgbuffer ;
static int tgbuffer_end = 0 ;
static int tgbuffer_pos = 0 ;
static int tgline_pos ;
static int tgline_end = -1 ;
static char *tgline = 0 ;
static bool inserted_eos = false ;

//----------------------------------------------------------------------

static void close_text_file()
{
   if (tgfile != -1)
      {
      if (tgfile != STDIN_HANDLE)
	 close(tgfile) ;
      tgfile = -1 ;
      }
   return ;
}

//----------------------------------------------------------------------

static bool fill_tgbuffer(size_t partial = 0, bool force_lowercase = false,
			    bool strip_accents = false)
{
   if (partial > (size_t)tgbuffer_end)
      {
      cout << "Error: buffer pointer out of range! (is " << partial
	   << ", should be <= " << tgbuffer_end << ")" << endl ;
      tgbuffer_pos = 0 ;
      tgbuffer_end = 0 ;
      return false ;
      }
   if (partial > 0)
      memcpy(tgbuffer,tgbuffer+(tgbuffer_end-partial),partial) ;
   bool nulls = false ;
   int read_count ;
   int count = 0 ;
   size_t start = partial ;
   do {
      read_count = read(tgfile,tgbuffer+start,sizeof(_tgbuffer)-start) ;
      if (read_count > 0)
	 {
	 size_t dest = start ;
	 size_t end = start + read_count ;
	 for (size_t i = start ; i < end ; i++)
	    {
	    if (tgbuffer[i])
	       tgbuffer[dest++] = tgbuffer[i] ;
	    }
	 nulls = (dest < end) ;
	 count += (dest - start) ;
	 start = dest ;
	 }
      } while (read_count > 0 && nulls) ;
   if (count >= 0)
      {
      tgbuffer_pos = partial ;
      tgbuffer_end = count + partial ;
      if ((size_t)tgbuffer_end < sizeof(_tgbuffer))
	 tgbuffer[tgbuffer_end] = '\0' ;
      if (force_lowercase)
	 {
	 const unsigned char *map = lowercase_table ;
	 for (int i = partial ; i < tgbuffer_end ; i++)
	    tgbuffer[i] = (char)map[(unsigned char)tgbuffer[i]] ;
	 }
      if (strip_accents)
	 {
	 if (char_encoding == FrChEnc_Latin2)
	    for (int i = partial ; i < tgbuffer_end ; i++)
	       tgbuffer[i] = Fr_unaccent_Latin2(tgbuffer[i]) ;
	 else
	    for (int i = partial ; i < tgbuffer_end ; i++)
	       tgbuffer[i] = Fr_unaccent_Latin1(tgbuffer[i]) ;
	 }
      return tgbuffer_end > 0 ;
      }
   else
      {
      tgbuffer_pos = 0 ;
      tgbuffer_end = 0 ;
      return false ;
      }
}

//----------------------------------------------------------------------

static bool fill_tgline(bool strip_accents = false)
{
   FrFree(tgline) ;
   tgline = 0 ;
   tgline_pos = 0 ;
   int start = tgbuffer_pos ;
   bool success = true ;
   while (tgbuffer[tgbuffer_pos] != '\n')
      {
      if (++tgbuffer_pos >= tgbuffer_end)
	 {
	 if (start == 0 || tgbuffer_end == 0)
	    break ;			// already using entire buffer....
	 success = false ;
	 if (!fill_tgbuffer(tgbuffer_end-start,ignore_case,
			    strip_accents)) // end of file or read error?
	    break ;	
	 start = 0 ;
	 success = true ;
	 }
      }
   if (tgbuffer_pos >= 0)
      {
      tgbuffer[tgbuffer_pos++] = '\0' ;
      FrCharEncoding enc = (canonicalized_input_data
			    ? FrChEnc_RawOctets
			    : char_encoding) ;
      const char *delim = FrStdWordDelimiters(enc) ;
      char *tmpline = FrCanonicalizeSentence((char*)(tgbuffer+start),
					     char_encoding,
					     false,delim,abbreviations) ;
      if (named_entity_spec)
	 {
	 tgline = FrStripNamedEntityData(tmpline,named_entity_spec) ;
	 FrFree(tmpline) ;
	 }
      else
	 tgline = tmpline ;
      if (ignore_case)
	 Fr_strmap(tgline,(char*)lowercase_table) ;
      }
   if (tgline)
      tgline_end = strlen(tgline) ;
   else
      tgline_end = 0 ;
   return success ;
}

//----------------------------------------------------------------------

static bool is_metadata_line(const char *line)
{
   // check whether the first three non-whitespace characters are semicolons
   while (*line && Fr_isspace(*line))
      line++ ;
   if (*line != ';')
      return false ;
   line++ ;
   while (*line && Fr_isspace(*line))
      line++ ;
   if (*line != ';')
      return false ;
   line++ ;
   while (*line && Fr_isspace(*line))
      line++ ;
   if (*line != ';')
      return false ;
   return true ;
}

//----------------------------------------------------------------------

static bool skip_over_line()
{
   do {
      // advance to next line
      if (!fill_tgline(remove_accents))
	 break ;
      // and repeat until we get a non-blank, non-metadata line
      } while (tgline_end == 0 || is_metadata_line(tgline)) ;
   tgline_pos = tgline_end+1 ;
   return (tgline_end > 0) ;
}

//----------------------------------------------------------------------

static bool open_text_file(const char *filename)
{
   close_text_file() ;
   if (strcmp(filename,"-") == 0)
      tgfile = STDIN_HANDLE ;
   else
      tgfile = open(filename,O_RDONLY) ;
   if (tgfile != -1)
      {
      tgbuffer_pos = 0 ;
      tgbuffer_end = 0 ;
      fill_tgbuffer(0,ignore_case,remove_accents) ;
      if (bilingual_data && !bilingual_use_source)
	 {
	 // skip the first line of the file
	 skip_over_line() ;
	 }
      if (!fill_tgline(remove_accents))
	 return false ;
      while (bilingual_data && is_metadata_line(tgline))
	 {
	 if (!fill_tgline(remove_accents))
	    return false ;
	 }
      return (tgbuffer_end > 0) ;
      }
   else
      return false ;
}

//----------------------------------------------------------------------

static const char *next_word(const char *&raw_word, bool char_based,
			     bool include_spaces)
{
   raw_word = 0 ;
   if (tgbuffer_end <= 0)		// already at EOF?
      return 0 ;
   if (inserted_eos)
      {
      inserted_eos = false ;
      return BEGIN_SENTENCE ;
      }
   if (tgline_pos >= tgline_end)	// if at end of line, get the next one
      {
      if (bilingual_data && !skip_over_line())
	 {
	 // at end of file
	 return auto_insert_EOS ? END_SENTENCE : 0 ;
	 }
      do {
         if (!fill_tgline(remove_accents))
	    {
	    tgbuffer_end = -1 ;
	    break ;
	    }
         } while (tgline_end == 0) ;	// until non-blank line
      if (auto_insert_EOS)
	 {
	 inserted_eos = true ;
	 return END_SENTENCE ;
	 }
      else if (tgbuffer_end == -1)
	 return 0 ;			// end of file or read error
      }
   unsigned int startpos = tgline_pos ;	// remember the start of the word
   char *word = &tgline[tgline_pos] ;
   if (char_based)
      {
      // IMPORTANT: this code needs to stay synchronized with LmWord2Chars()
      //   in lmodel.C
      static char chbuf[8] ;
      // skip whitespace characters
      if (!include_spaces)
	 {
	 while (tgline[tgline_pos] && 
		(tgline[tgline_pos] == ' ' || tgline[tgline_pos] == '\t'))
	    tgline_pos++ ;
	 }
      // special-case end-of-sentence marker so that we don't rip it apart
      if (Fr_strnicmp(tgline+tgline_pos,END_SENTENCE,
		      sizeof(END_SENTENCE)-1) == 0 &&
	  (tgline[tgline_pos+sizeof(END_SENTENCE)-1] == ' ' ||
	   tgline[tgline_pos+sizeof(END_SENTENCE)-1] == '\0'))
	 {
	 tgline_pos += sizeof(END_SENTENCE)-1 ;
	 return END_SENTENCE ;
	 }
      switch (char_encoding)
	 {
	 case FrChEnc_Unicode:
	    chbuf[0] = tgline[tgline_pos++] ;
	    chbuf[1] = tgline[tgline_pos++] ;
	    chbuf[2] = '\0' ;
	    chbuf[3] = '\0' ;
	    break ;
	 case FrChEnc_UTF8:
	    if ((tgline[tgline_pos] & 0x80) != 0)
	       {
	       chbuf[0] = tgline[tgline_pos++] ;
	       size_t i = 1 ;
	       while ((tgline[tgline_pos] & 0xC0) == 0x80 &&
		      i+1 < sizeof(chbuf))
		  chbuf[i++] = tgline[tgline_pos++] ;
	       chbuf[i] = '\0' ;
	       }
	    else
	       {
	       // plain ASCII character, so just copy a single byte
	       chbuf[0] = tgline[tgline_pos++] ;
	       chbuf[1] = '\0' ;
	       }
	    break ;
	 case FrChEnc_EUC:
	    if (tgline[tgline_pos] & 0x80)
	       {
	       chbuf[0] = tgline[tgline_pos++] ;
	       if (tgline[tgline_pos] & 0x80)
		  {
		  chbuf[1] = tgline[tgline_pos++] ;
		  chbuf[2] = '\0' ;
		  }
	       else
		  chbuf[1] = '\0' ;
	       }
	    else
	       {
	       // plain ASCII character, so just copy a single byte
	       chbuf[0] = tgline[tgline_pos++] ;
	       chbuf[1] = '\0' ;
	       }
	    break ;
	 case FrChEnc_Latin1:
	 case FrChEnc_Latin2:
	 case FrChEnc_RawOctets:
	 default:
	    chbuf[0] = tgline[tgline_pos++] ;
	    chbuf[1] = '\0' ;
	    break ;
	 }
      return chbuf ;
      }
   else
      {
      // advance to next whitespace character
      while (tgline[tgline_pos] && tgline[tgline_pos] != ' ' &&
	     tgline[tgline_pos] != '\t' &&
	     tgline_pos - startpos < MAXWORDLEN)
	 {
	 tgline_pos++ ;
	 }
      tgline[tgline_pos] = '\0' ;		// terminate the word
      tgline_pos++ ;			// skip over the byte we nulled

      // convert the raw word into the one which will actually be used to
      //   build the model
      bool poss = false ;
      bool using_affix = false ;
      const char *remapped = LmNGramModel::remapWord(word,wordstem_ht,poss,
						     true,build_affix_sizes,
						     &using_affix) ;
      raw_word = (!using_affix && (poss || strcmp(word,remapped) != 0)) ? word : 0 ;
      return poss ? TOKEN_POSSESSIVE : remapped ;
      }
}

/************************************************************************/
/*	new-style BWT n-gram model					*/
/************************************************************************/

static bool convert_to_wordIDs(const char *filename, size_t &numIDs,
				 FrWordIDList *&idlist, uint32_t eor,
				 FrSymHashTable *surface_words,
				 FrSymHashTable *stop_words,
				 bool char_based, bool include_spaces)
{
   if (!filename || !*filename || !open_text_file(filename))
      return false ;
   uint32_t id = eor ;
   bool success = true ;
   const char *word ;
   const char *raw_word ;
   bool have_eos = false ;
   size_t num_words = 0 ;
   if (auto_insert_EOS)
      inserted_eos = true ; // ensure that we get a <s> as first token
   while ((word = next_word(raw_word,char_based,include_spaces)) != 0)
      {
      if (stop_words)
	 {
	 FrSymbol *sym = findSymbol(word) ;
	 if (sym && stop_words->lookup(sym))
	    {
	    total_stop_words++ ;
	    continue ;
	    }
	 }
      num_words++ ;
      if (strcmp(word,END_SENTENCE) == 0)
	 {
	 raw_word = 0 ;
	 id = eor ;
	 have_eos = true ;
	 }
      else
	 id = FrCvtWord2WordID(word,numIDs) ;
      if (id != FrVOCAB_WORD_NOT_FOUND)
	 {
	 FrSymbol *sym ;
	 if (raw_word)
	    {
	    sym = findSymbol(raw_word) ;
	    if (!sym)
	       {
	       sym = FrSymbolTable::add(raw_word) ;
	       sym->setFrame((FrFrame*)((uintptr_t)id)) ;
	       }
	    }
	 else
	    sym = findSymbol(word) ;
	 // increment the count of the un-generalized word so that we may
	 //   properly adjust its predicted probability later
	 if (surface_words)
	    {
	    FrSymHashEntry *entry = surface_words->lookup(sym) ;
	    if (entry)
	       entry->setCount(entry->getCount()+1) ;
	    else
	       surface_words->add(sym,(size_t)1) ;
	    }
	 }
      if (!FrAdd2WordIDList(idlist,id))
	 {
	 success = false ;
	 break ;
	 }
      }
   if (!have_eos && num_words > 100000)
      {
      cerr << "; WARNING: no end-of-sentence markers in data, sorting will be very slow"
	   << endl ;
      }
   // ensure that there is an end-of-record marker as the last item if we
   //   wrote anything at all
   if (success && id != eor &&!FrAdd2WordIDList(idlist,eor))
      success = false ;
   close_text_file() ;
   return success ;
}

//----------------------------------------------------------------------

static bool collect_rare_word(FrSymHashEntry *entry, va_list args)
{
   size_t count = entry->getCount() ;
   FrVarArg(int,threshold) ;
   if (count <= (size_t)threshold)
      {
      FrSymbol *word = findSymbol(entry->getName()->symbolName()) ;
      if (word)
	 {
	 const char *name = word->symbolName() ;
	 if (name[0] != '<' && !strchr(name,AFFIX_CHAR) &&
	     !LmIsNumber(name))
	    {
	    FrVarArg(FrBitVector*,rare_words) ;
	    rare_words->setBit((size_t)(word->symbolFrame())) ;
	    FrVarArg(LmWordID_t,rare_id) ;
	    word->setFrame((FrFrame*)rare_id) ;
	    }
	 }
      }
   return true ;			// continue iterating
}

//----------------------------------------------------------------------

static void map_rare_words(FrWordIDList *wordIDlist,LmWordID_t rare_id,
			   FrSymHashTable *surface_words, size_t numIDs,
			   int rare_word_threshold)
{
   FrBitVector *rare_words = new FrBitVector(numIDs) ;
   if (!rare_words)
      {
      FrNoMemory("-- remapping of rare words skipped") ;
      return ;
      }
   // collect the rare words
   surface_words->doHashEntries(collect_rare_word,rare_word_threshold,
				rare_words,rare_id) ;
   // now remap any IDs in 'rare_words' to 'rare_id'
   for ( ; wordIDlist ; wordIDlist = wordIDlist->next())
      {
      for (size_t i = 0 ; i < wordIDlist->eltsUsed() ; i++)
	 {
	 uint32_t id = wordIDlist->getNth(i) ;
	 if (id < numIDs && rare_words->getBit(id))
	    wordIDlist->setNth(i,rare_id) ;
	 }
      }
   delete rare_words ;
   return ;
}

//----------------------------------------------------------------------

static bool save_vocab(FILE *fp,void *v)
{
   if (!fp)
      {
      cout << "; unable to save vocaulary -- invalid file pointer" << endl ;
      return false ;
      }
   VocabPointers *vp = (VocabPointers*)v ;
   FrVocabulary *vocab = vp->baseVocabulary() ;
   bool success = true ;
   if (vocab)
      {
      off_t offset = ftell(fp) ;
      success = vocab->save(fp,offset) ;
      }
   else
      {
      cout << "; unable to save vocabulary -- insufficient data" << endl ;
      return false ;
      }
   vocab = vp->surfaceVocabulary() ;
   if (vocab && success)
      {
      // write the surface vocabulary to the file
      off_t offset = ftell(fp) ;
      success = vocab->save(fp,offset) ;
      }
   vocab = vp->stopwordVocabulary() ;
   if (vocab && success)
      {
      // write the stop-word vocabulary to the file
      off_t offset = ftell(fp) ;
      success = vocab->save(fp,offset) ;
      }
   return success ;
}

//----------------------------------------------------------------------

static bool compress_ngram_model(FrBWTIndex &model)
{
   FrTimer timer ;
   if (!model.compress())
      {
      cout << "; unable to reduce size by compression" << endl ;
      return false ;
      }
   size_t uncomp_size ;
   size_t comp_size ;
   if (model.compressionStats(uncomp_size,comp_size))
      cout << "; compression reduced size from " << uncomp_size << " to "
	   << comp_size << " (" << 100.0 - (100.0 * comp_size / uncomp_size)
	   << "%) in " << timer.readsec() << " seconds" << endl ;
   return true ;
}

//----------------------------------------------------------------------

bool compress_ngram_model(const char *filename, const char *compfilename)
{
   FrBWTIndex index(filename,true) ;
   if (index.good())
      {
      FrFileMapping *map = index.mappedFile() ;
      FrVocabulary *vocab ;
      if (map)
	 vocab = new FrVocabulary(map,filename,index.userDataOffset());
      else
	 vocab = new FrVocabulary(filename,index.userDataOffset(),true,
				  allow_memmapped_model) ;
      bool success = false ;
      if (compress_ngram_model(index))
	 {
	 VocabPointers vp(vocab,0,0) ;
	 success = index.save(compfilename,save_vocab,&vp) ;
	 }
      delete vocab ;
      return success ;
      }
   return false ;
}

//----------------------------------------------------------------------

static bool add_surface(FrSymHashEntry *entry, va_list args)
{
   const FrObject *root = entry->getValue() ;
   if (root)
      {
      FrVarArg(size_t*,numIDs) ;
      const FrSymbol *surface = entry->getName() ;
      (void)FrCvtWord2WordID(surface->symbolName(),*numIDs) ;
      }
   return true ;			// continue iterating
}

//----------------------------------------------------------------------

static void add_surface_to_vocab(FrSymHashTable *stem_ht,
				 size_t &numIDs)
{
   if (stem_ht)
      (void)stem_ht->doHashEntries(add_surface,&numIDs) ;
   return ;
}

//----------------------------------------------------------------------

static bool mark_new(FrSymHashEntry *entry, va_list /*args*/)
{
   FrSymbol *surface = (FrSymbol*)entry->getName() ;
   FrSymbol *root = (FrSymbol*)entry->getValue() ;
   FrText2WordIDsMarkNew(surface) ;
   FrText2WordIDsMarkNew(root) ;
   return true ;			// continue iterating
}

//----------------------------------------------------------------------

static void mark_words_new(FrSymHashTable *stem_ht)
{
   if (stem_ht)
      (void)stem_ht->doHashEntries(mark_new) ;
   return ;
}

//----------------------------------------------------------------------

FrSymHashTable *LmLoadStopWords(const char *filename)
{
   if (!filename || !*filename)
      return 0 ;
   bool piped ;
   FILE *fp = FrOpenMaybeCompressedInfile(filename,piped) ;
   if (!fp)
      return 0 ;
   FrSymHashTable *stop_words = new FrSymHashTable ;
   if (stop_words)
      stop_words->expand(10000) ;
   FrSymbol *symEOF = FrSymbolTable::add("*EOF*") ;
   while (!feof(fp))
      {
      char line[FrMAX_LINE] ;
      if (!fgets(line,sizeof(line),fp))
	 break ;
      char *lineptr = line ;
      FrObject *obj = string_to_FrObject(lineptr) ;
      if (obj == symEOF)
	 break ;
      const char *word = FrPrintableName(obj) ;
      if (word && *word)
	 {
	 FrSymbol *wordsym = FrSymbolTable::add(word) ;
	 stop_words->add(wordsym) ;
	 }
      }
   FrCloseMaybeCompressedInfile(fp,piped) ;
   return stop_words ;
}

//----------------------------------------------------------------------

static bool add_to_vocab(FrSymHashEntry *entry, va_list args)
{
   const FrSymbol *word = entry->getName() ;
   if (word)
      {
      FrVarArg(FrVocabulary*,vocab) ;
      FrVarArg2(bool,int,preserve_count) ;
      if (preserve_count)
	 {
	 vocab->addWord(word->symbolName(),entry->getCount()) ;
	 }
      else
	 vocab->addWord(word->symbolName()) ;
      }
   return true ;			// continue iterating
}

//----------------------------------------------------------------------

FrVocabulary *LmConvertHash2Vocab(FrSymHashTable *ht, bool force = false,
				  bool preserve_counts = false)
{
   FrVocabulary *vocab = 0 ;
   if (force || (ht && ht->currentSize() > 0))
      {
      vocab = new FrVocabulary ;
      if (vocab)
	 {
	 vocab->useNameAsID(!preserve_counts) ;
	 vocab->setScaleFactor(0) ;
	 if (ht && vocab->startBatchUpdate())
	    {
	    (void)ht->doHashEntries(add_to_vocab,vocab,preserve_counts) ;
	    vocab->finishBatchUpdate() ;
	    }
	 }
      }
   return vocab ;
}

//----------------------------------------------------------------------

bool generate_ngram_model(const char *outfile, const char *vocabfile,
			    FrList *inputfiles, bool compress,
			    double discountmass, bool reverse_words,
			    const char *abbrevs_file,
			    const char *wordstems_file,
			    const char *stopwords_file)
{
   if (!outfile || !*outfile)
      return false ;
   char *tmpfile = FrForceFilenameExt(outfile,"$$$") ;
   if (!tmpfile)
      {
      FrNoMemory("generating temporary filename") ;
      return false ;
      }
   FrTimer timer ;
   FrSymbolTable *old_symtab ;
   if (!FrBeginText2WordIDs(old_symtab))
      return false ;
   if (abbrevs_file)
      abbreviations = FrLoadAbbreviationList(abbrevs_file) ;
   if (wordstems_file)
      {
      cout << ";loading stems/equivalences from " << wordstems_file << endl ;
      LmLoadWordStems(wordstems_file) ;
      mark_words_new(wordstem_ht) ;
      }
   FrSymHashTable *stop_words = 0 ;
   total_stop_words = 0 ;
   if (stopwords_file)
      {
      cout << ";loading stopwords from " << stopwords_file << endl ;
      stop_words = LmLoadStopWords(stopwords_file) ;
      if (stop_words)
	 cout << ";  (" << stop_words->currentSize() << " words loaded)"
	      << endl ;
      }
   // since digit strings always get converted to <number>, keep track of
   //   surface word counts even if we're not using any explicit wordstem_ht
   FrSymHashTable *surface_words = new FrSymHashTable ;
   if (surface_words)
      surface_words->expand(10000) ;
   size_t numIDs = 0 ;
   LmWordID_t rare_id = FrVOCAB_WORD_NOT_FOUND ;
   if (rare_words_threshold > 0)
      rare_id = FrCvtWord2WordID(TOKEN_RARE,numIDs) ;
   uint32_t eor = ~0 ;
   FrWordIDList *wordIDlist = 0 ;
   cout << ";creating "
	<< (ignore_case ? "case-folded" : "case-sensitive")
	<< " "
	<< (char_based_model ? "character" : "word") 
	<< " n-gram model using "
	<< FrCharEncodingName(char_encoding) << " character set" << endl ;
   if (build_affix_sizes)
      {
      unsigned int prefix ;
      unsigned int suffix ;
      UNPACK_AFFIX_LENGTHS(build_affix_sizes,prefix,suffix) ;
      cout << ";limiting tokens to first " << prefix << " and last "
	   << suffix << " bytes" << endl ;
      }
   for ( ; inputfiles ; inputfiles = inputfiles->rest())
      {
      FrObject *inputfile = inputfiles->first() ;
      const char *filename = FrPrintableName(inputfile) ;
      if (filename)
	 {
	 if (access(filename,R_OK) != 0)
	    {
	    cout << "; Warning: unable to access "<< filename << endl ;
	    continue ;
	    }
	 cout << "; processing " ;
	 if (bilingual_data)
	    cout << (bilingual_use_source?"source":"target") << " half of " ;
	 cout << filename << endl ;
	 if (!convert_to_wordIDs(filename,numIDs,wordIDlist,eor,
				 surface_words,stop_words,char_based_model,
				 model_includes_spaces))
	    FrWarningVA("unable to preprocess %s\n",filename) ;
	 }
      }
   // if we've been asked to automatically map rare words to the <rare> class,
   //   do so now
   if (rare_words_threshold > 0)
      {
      cout << "; mapping words with frequency <= " << rare_words_threshold
	   << " to class <rare>" << endl ;
      map_rare_words(wordIDlist,rare_id,surface_words,numIDs,
		     rare_words_threshold) ;
      }
   add_surface_to_vocab(wordstem_ht,numIDs) ;
   // convert the surface-word hash table into a vocabulary; we must do this
   //   conversion before FrFinishText2WordIDs, because that destroys the
   //   symbol table containing the hash keys
   FrVocabulary *surface_vocab = LmConvertHash2Vocab(surface_words,false,true);
   delete surface_words ;
   FrVocabulary *vocab = FrFinishText2WordIDs(old_symtab) ;
   if (!vocab)
      {
      wordIDlist->freeIDList() ;
      FrFreeAbbreviationList(abbreviations) ;
      LmUnloadWordStems() ;
      return false ;
      }
   wordIDlist = wordIDlist->reverse() ;
   cout << "; processed " << FrCountWordIDs(wordIDlist)
	<< " words and context cues in " << timer.readsec() << " seconds"
	<< endl ;
   if (total_stop_words > 0)
      cout << ";  (skipped " << total_stop_words << " stop words)" << endl ;
   timer.start() ;
   size_t num_words = 0 ;
   uint32_t *wordIDs = FrMakeWordIDArray(wordIDlist,num_words,eor,
					 reverse_words) ;
   wordIDlist->freeIDList() ;
   wordIDlist = 0 ;
   cout << "; collected word IDs in " << timer.readsec() << " seconds"
	<< endl ;
   // memory has been fragmented somewhat by the growth of the vocab while
   //   processing the input data, so compact memory by writing out the
   //   vocabulary to a file, performing a garbage collection, and then
   //   re-reading the vocabulary from disk
   FILE *fp = fopen(tmpfile,FrFOPEN_WRITE_MODE) ;
   if (fp && vocab->save(fp,0))
      {
      fclose(fp) ;
      delete vocab ;
      FramepaC_gc() ;
      vocab = new FrVocabulary(tmpfile) ;
      if (!vocab)
	 {
	 FrError("garbage collection failed!") ;
	 FrFree(wordIDs) ;
	 FrFreeAbbreviationList(abbreviations) ;
	 LmUnloadWordStems() ;
	 return false ;
	 }
      }
   else if (fp)
      fclose(fp) ;
   else
      {
      FrErrorVA("unable to create temporary file %s",tmpfile) ;
      FrFree(wordIDs) ;
      FrFreeAbbreviationList(abbreviations) ;
      LmUnloadWordStems() ;
      return false ;
      }
   if (num_words == 0)
      {
      cout << "No text processed!  Output file not created." << endl ;
      Fr_unlink(tmpfile) ;
      FrFreeAbbreviationList(abbreviations) ;
      LmUnloadWordStems() ;
      return false ;
      }
   cout << "; building sorted index" << endl ;
   timer.start() ;
   FrBWTIndex index(wordIDs,num_words,FrBWT_MergeEOR,eor,&cout) ;
   index.wordsAreReversed(reverse_words) ;
   index.wordsAreCaseSensitive(!ignore_case) ;
   index.indexIsCharBased(char_based_model) ;
   index.setAffixSizes(build_affix_sizes) ;
   FrFree(wordIDs) ;
   cout << ";   (building index took " << timer.readsec() << " seconds, "
	<< index.numIDs() << " unique words)" << endl ;
   if (compress && index.good())
      (void)compress_ngram_model(index) ;
   if (verbose && index.good())
      {
      #define HIST_SIZE 80
      size_t diffs[HIST_SIZE+2] ;
      if (index.deltaHistogram(HIST_SIZE+1,diffs))
	 {
	 for (size_t i = 1 ; i <= HIST_SIZE ; i++)
	    cout << setw(3) << i << '\t' << diffs[i] << endl ;
	 cout << ">" << HIST_SIZE << "\t" << diffs[HIST_SIZE+1] << endl ;
	 cout << "EOR\t" << diffs[0] << endl ;
	 }
      }
   timer.start() ;
   index.setDiscounts(discountmass) ;
   //   add the surface-word vocabulary to the output file if appropriate
   FrVocabulary *stop_vocab = 0 ;
   if (stop_words && stop_words->currentSize() > 0)
      {
      // convert the stop-word hash table into a vocabulary and add it
      //   to the output file
      stop_vocab = LmConvertHash2Vocab(stop_words,true) ;
      // if we have a stop_vocab, we must also have a surface_vocab or the
      //   stop_vocab will be interpreted as the surface_vocab...
      if (!surface_vocab)
	 surface_vocab = LmConvertHash2Vocab(0,true) ;
      }
   delete stop_words ;
   VocabPointers vp(vocab,surface_vocab,stop_vocab) ;
   bool good = index.save(outfile,save_vocab,&vp) ;
   if (vocabfile && *vocabfile)
      {
      // write out the words in the vocabulary to the specified file
      bool piped ;
      FILE *vocfp = FrOpenMaybeCompressedOutfile(vocabfile,piped) ;
      if (vocfp)
	 {
	 size_t count = 0 ;
	 for (size_t i = 0 ; i < vocab->numWords() ; i++)
	    {
	    const char *entry = vocab->indexEntry(i) ;
	    if (entry)
	       {
	       const char *name = vocab->getNameFromIndexEntry(entry) ;
	       if (name)
		  {
		  LmWordID_t wordID = vocab->getID(entry) ;
		  size_t wordfreq = index.unigramFrequency(wordID) ;
		  fprintf(vocfp,"%s\tID=%lu\tN=%lu\n",
			  name,(unsigned long)wordID,wordfreq) ;
		  count++ ;
		  }
	       }
	    }
	 cout << "; wrote " << count << " words to " << vocabfile << endl ;
	 FrCloseMaybeCompressedOutfile(vocfp,piped) ;
	 }
      else
	 cout << "; unable to write vocabulary to " << vocabfile << endl ;
      }
   delete vocab ;
   delete surface_vocab ;
   delete stop_vocab ;
   Fr_unlink(tmpfile) ;
   if (good)
      cout << "; saved language model in " << timer.readsec()
	   << " seconds" << endl ;
   else
      cout << "; ERROR while saving language model to disk" << endl ;
   FrFreeAbbreviationList(abbreviations) ;
   LmUnloadWordStems() ;
   return good ;
}

// end of file lmbuild.cpp //
