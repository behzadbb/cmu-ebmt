/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Language Modeler -- genre support					*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmgenre.h							*/
/*  LastEdit: 08apr10							*/
/*									*/
/*  (c) Copyright 2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __LMGENRE_H_INCLUDED
#define __LMGENRE_H_INCLUDED

class LmGenreSettings
   {
   protected:
      char *m_genre ;
   private:
      class LMGlobalVariables *m_vars ;
      LmGenreSettings *m_next ;
      LmGenreSettings *m_prev ;
   public: // data
      FrList *_feature_weights ;
      char *_untrans_prefix ;
      char *_untrans_suffix ;
      double _max_overlap_diff ;
      double _LM_scale_factor ;
      double _LM_scale_adjust ;
      double _source_cover_power ;
      double _length_bias_byte ;
      double _length_bias_word ;
      size_t _max_ngram_length ;
      size_t _beam_width ;
      double _beam_ratio ;
      size_t _max_source_overlap ;
      size_t _max_reorder_window ;

   protected:
      void link(class LMGlobalVariables *vars) ;
   public: // methods
      LmGenreSettings(class LMGlobalVariables * = 0, const char *genre = 0) ;
      LmGenreSettings(const LmGenreSettings &,
		      class LMGlobalVariables *, const char *newgenre = 0) ;
      ~LmGenreSettings() ;
      LmGenreSettings &operator = (const LmGenreSettings&) ;

      // accessors
      LmGenreSettings *next() const { return m_next ; }
      const char *name() const { return m_genre ; }
      static LmGenreSettings *find(const char *genre) ;
      const LMGlobalVariables *belongsTo() const { return m_vars ; }
   } ;

#endif /* !__LMGENRE_H_INCLUDED */

// end of file lmgenre.h //
