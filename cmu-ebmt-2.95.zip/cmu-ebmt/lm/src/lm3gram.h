/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 1.41							*/
/*	 by Ralf Brown							*/
/*									*/
/*  File lm3gram.h							*/
/*  LastEdit: 21mar05							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,1999,2002,2003,2004,2005	*/
/*		 Ralf Brown						*/
/*	This software may be used for educational and non-commercial	*/
/*	research purposes.  Any other use requires prior permission	*/
/*	from Ralf Brown or the Carnegie Mellon University Language	*/
/*	Technologies Institute.						*/
/*									*/
/************************************************************************/

#ifndef __LM3GRAM_H_INCLUDED
#define __LM3GRAM_H_INCLUDED

#include "FramepaC.h"

#ifndef __LMBASE_H_INCLUDED
#include "lmbase.h"
#endif

/************************************************************************/
/*    Manifest Constants for this module				*/
/************************************************************************/

#define BEGIN_SENTENCE "<s>"
#define END_SENTENCE "</s>"

// the following should match the limit in RR's 3gram code:
#define LmMAX_WORD_LENGTH 200

#define TOKEN_CARDINAL	"<cardinal>"
#define TOKEN_EXCL	"<excl>"
#define TOKEN_MONEY 	"<money>"
#define TOKEN_NUMBER	"<number>"
#define TOKEN_ORDINAL	"<ordinal>"
#define TOKEN_PHONE	"<phone>"
#define TOKEN_POSSESSIVE "<possessive>"
#define TOKEN_TIME	"<time>"

#define LmVOCAB_GAP_MARKER	((WordIdent)(((size_t)~0)-1))

/************************************************************************/
/*	Data Types							*/
/************************************************************************/

typedef int WordIdent ;

struct trigram_model ;
struct bic_record ;
class LmNGramModel ;

class TrigramModel
   {
   private:
      trigram_model *_model ;
      FrSymbol *begsent_symbol, *endsent_symbol ;
      WordIdent beg_sent, end_sent, number_id ;
      size_t ngram_limit ;
      FrBool verbose ;
      FrBool LOGspace ;
      FrBool initialized ;
   public:
      void *operator new(size_t size) { return FrMalloc(size) ; }
      void operator delete(void *blk) { FrFree(blk) ; }
      TrigramModel() ;
      TrigramModel(const char *filename, size_t max_ngram,
		   FrBool run_verbosely, FrBool logprob) ;
      ~TrigramModel() ;
      void setSentMarkers() ;
      void setSpace(FrBool logprob) { LOGspace = logprob ; }
      static const char *remapWord(const char *word,
				   FrBool &is_possessive) ;
      WordIdent findWordID(const char *word) const ;
      double probability(WordIdent ID1) const ;
      double probability(WordIdent ID1, WordIdent ID2) const ;
      double probability(WordIdent ID1, WordIdent ID2, WordIdent ID3,
			 double lowbound = 0.0) const ;
      double jointProbability(WordIdent ID1, WordIdent ID2) const ;
      double jointProbability(WordIdent ID1, WordIdent ID2,
			      WordIdent ID3) const ;

      static double log(double x) ;

      // access to internal state
      FrBool OK() const { return initialized ; }
      FrBool LOGprob() const { return LOGspace ; }
      trigram_model *model() const { return _model ; }
      WordIdent wordID_begsent() const { return beg_sent ; }
      WordIdent wordID_endsent() const { return end_sent ; }
      WordIdent wordID_number() const { return number_id ; }
      FrSymbol *word_begsent() const { return begsent_symbol ; }
      FrSymbol *word_endsent() const { return endsent_symbol ; }
      size_t maxNGramLength() const { return ngram_limit ; }
   } ;

/************************************************************************/
/*	Functions							*/
/************************************************************************/

double uniprob_of(int,trigram_model*) ;

double biprob_of(int,int,trigram_model*) ;
double bo_biprob_of(int,int,trigram_model*) ;
double biprob_joint(int id1, int id2, trigram_model *tg) ;
double bo_biprob_joint(int id1, int id2, trigram_model *tg) ;

double triprob_of(int,int,int,trigram_model*,int) ;
double triprob_joint(int id1, int id2, int id3, trigram_model *tg) ;
double bo_triprob_of(int,int,int,trigram_model*,int,double *logprog) ;
double bo_triprob_joint(int id1, int id2, int id3, trigram_model *tg) ;

double multigram_score(WordIdent *wordIDs, size_t numwords, trigram_model *tg,
		       size_t max_ngram) ;

int bigrams_starting_with(int id1, trigram_model *tg, bic_record *&bics) ;
double most_freq_bigram(int id1, trigram_model *tg, int endsent_id,
			int number_id, int &id2) ;
double most_freq_bigram(int id1, const LmNGramModel *model, int &id2) ;
double most_freq_bigram_joint(int id1, trigram_model *tg,
			      int endsent_id, int number_id, int &id2) ;
double most_freq_bigram_joint(int id1, const LmNGramModel *model, int &id2) ;
double most_freq_trigram(int id0, int id1, int id3, trigram_model *tg,
			 int endsent_id, int number_id, int &id2) ;
double most_freq_trigram(int id0, int id1, int id3, const LmNGramModel *model,
			 int &id2) ;
double most_freq_trigram_joint(int id0, int id1, int id3, trigram_model *tg,
			       int endsent_id, int number_id, int &id2) ;
double most_freq_trigram_joint(int id0, int id1, int id3, 
			       const LmNGramModel *model, int &id2) ;

FrSymbol *word_for_ID(const trigram_model *tg, int id) ;

/************************************************************************/
/************************************************************************/

#endif /* !__LM3GRAM_H_INCLUDED */

// end of lm3gram.h //
      
