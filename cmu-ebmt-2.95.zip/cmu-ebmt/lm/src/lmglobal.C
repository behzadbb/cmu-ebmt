/************************************************************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmglobal.C	    Language Modeler's global variables		*/
/*  LastEdit: 21apr10    						*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,1999,2000,2001,2002,2003	*/
/*		2004,2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "lmconfig.h"
#include "lmglobal.h"
#include "ebmt.h"		// for EbSetCharEncoding

#ifdef FrSTRICT_CPLUSPLUS
# include <cmath>
#else
# include <math.h>
#endif /* FrSTRICT_CPLUSPLUS */

/************************************************************************/
/*    Manifest Constants for this module				*/
/************************************************************************/

/************************************************************************/
/*	Global variables						*/
/************************************************************************/

LMGlobalVariables lm_vars ;
// a map of the default features we control; other features will be added to
//   a copy of this map on a per-chart basis
FrFeatureVectorMap LMfeature_map ;	

static LMGlobalVariables *active_vars = 0 ;
static LMGlobalVariables *default_vars = 0 ;

//----------------------------------------------------------------------

int LM_trace = 0 ;

extern bool LmUnloadWordStems() ;

/************************************************************************/
/************************************************************************/

LMGlobalVariables::LMGlobalVariables()
{
   genre_list = 0 ;
   genre = new LmGenreSettings(this) ;
   _thread_pool = 0 ;
   _language_model_count = 0 ;
   _wordstem_ht = 0 ;
   _named_entity_spec = 0 ;

   _trace = LM_trace ;
   _LM_port_number = -1 ;		// by default, don't use socket
   _allow_memmapped_model = true ;
   _touch_all_memory = false ;
   _show_coverage = false ;
   _show_overlap_stats = false ;
   _show_search_stats = false ;
   _show_raw_scores = false ;
   _raw_scores_in_CMERT_format = false ;
   _raw_scores_in_ZMERT_format = false ;
   _raw_scores_in_Cunei_format = false ;
   _skip_raw_scores = 0 ;		// don't omit any of the raw scores if
					//   we are asked to output them
   _lowercase_table = FrLowercaseTable(FrChEnc_Latin1) ;
   _uppercase_table = FrUppercaseTable(FrChEnc_Latin1) ;

   _preparing_for_document = false ;

   _symMORPH = makeSymbol("MORPH") ;
   _symNIL = makeSymbol("NIL") ;
   _symSTRING = makeSymbol("STRING") ;
   _symEPSILON = 0 ;
   _symLEXICAL = makeSymbol("LEXICAL") ;
   _sym_empty = makeSymbol("") ;

   applyConfiguration(0) ;
   return ;
}

//----------------------------------------------------------------------

LMGlobalVariables::LMGlobalVariables(const LMGlobalVariables &vars)
{
   *this = vars ;
   // fix up the items which are allocated on the heap
   if (vars._wordstem_ht)
      _wordstem_ht = (FrSymHashTable*)vars._wordstem_ht->deepcopy() ;
   _thread_pool = 0 ;
   // duplicate the genre-specific information records
   LmGenreSettings *g = genre_list ;
   LmGenreSettings *curr_g = genre ;
   genre_list = 0 ;
   genre = 0 ;
   for ( ; g ; g = g->next())
      {
      LmGenreSettings *new_g = new LmGenreSettings(*g,this,0) ;
      if (g == curr_g)
	 genre = new_g ;
      }
   return ;
}

//----------------------------------------------------------------------

LMGlobalVariables::~LMGlobalVariables()
{
   if (this == active_vars)
      default_vars->select() ;
   if (this == &lm_vars && active_vars != 0)
      return ;
   freeVariables() ;
   LmUnloadWordStems() ;
   delete genre ; 		genre = 0 ;
   FrDestroyGlobalThreadPool(_thread_pool) ;  _thread_pool = 0 ;
   return ;
}

//----------------------------------------------------------------------

void LMGlobalVariables::freeVariables()
{
   // free any variables allocated on the heap
   FrFree(_dummy_arc_contents) ;	_dummy_arc_contents = 0 ;
   FrFree(_epsilon_arc_contents) ;	_epsilon_arc_contents = 0 ;
   _language_model_count = 0 ;
   while (genre_list)
      {
      LmGenreSettings *g = genre_list ;
      genre_list = genre_list->next() ;
      delete g ;
      }
   genre = 0 ;
   if (this != &lm_vars)
      {
      while (genre_list)
	 {
	 LmGenreSettings *g = genre_list->next() ;
	 delete genre_list ;
	 genre_list = g ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

bool LMGlobalVariables::applyConfiguration(const LMConfig *config)
{
   _ngrams = 0 ;

   _verbose = false ;
   _char_based_model = false ;
   _model_includes_spaces = false ;

   // the decoder's statistics
   _attempted_expansions = 0 ;
   _expansion_collisions = 0 ;
   _unable_to_cover = 0 ;
   _unfillable_gaps = 0 ;
   _successful_expansions = 0 ;
   _overlap_expansions = 0 ;
   _interleaved_expansions = 0 ;
   _reordered_expansions = 0 ;
   _dups_removed = 0 ;
   _beam_exceeded = 0 ;
   _never_inserted = 0 ;
   _reorderings_used = 0 ;
   _total_nodes_expanded = 0 ;
   _total_ngram_probs = 0 ;
   _total_avg_ngram = 0 ;
   _total_sentences = 0 ;

   // set up default and decoder features, and store their IDs
   _featureID_langmodel = LMfeature_map.addFeature("LMScore") ;
   _featureID_score = LMfeature_map.addFeature("Score") ;
   _featureID_quality = LMfeature_map.addFeature("Quality") ;
   _featureID_arcweight = LMfeature_map.addFeature("ArcWeight") ;
   _featureID_length2bonus = LMfeature_map.addFeature("Length2Bonus") ;
   _featureID_length3bonus = LMfeature_map.addFeature("Length3Bonus") ;
   _featureID_length4bonus = LMfeature_map.addFeature("Length4Bonus") ;
   _featureID_length5bonus = LMfeature_map.addFeature("Length5Bonus") ;
   _featureID_length6bonus = LMfeature_map.addFeature("Length6Bonus") ;
   _featureID_lengthplusbonus = LMfeature_map.addFeature("LengthPlusBonus") ;
   _featureID_chunking = LMfeature_map.addFeature("Chunking") ;
   _featureID_reordering = LMfeature_map.addFeature("Reordering") ;
   _featureID_reordering2 = LMfeature_map.addFeature("Reordering2") ;
   _featureID_reorderpunct = LMfeature_map.addFeature("Reorder-Punct") ;
   _featureID_reorderpunctEOS = LMfeature_map.addFeature("Reorder-Punct-EOS") ;
   _featureID_gaps = LMfeature_map.addFeature("Gaps-Discarded") ;
   _featureID_interleave = LMfeature_map.addFeature("Interleave") ;
   _featureID_ngramlength = LMfeature_map.addFeature("NGramLength") ;
   _featureID_OOV = LMfeature_map.addFeature("OOV") ;
   _featureID_ngram1 = LMfeature_map.addFeature("NGrams1") ;
   _featureID_ngram2 = LMfeature_map.addFeature("NGrams2") ;
   _featureID_ngram3 = LMfeature_map.addFeature("NGrams3") ;
   _featureID_ngram4 = LMfeature_map.addFeature("NGrams4") ;
   _featureID_ngram5 = LMfeature_map.addFeature("NGrams5") ;
   _featureID_ngram6 = LMfeature_map.addFeature("NGrams6") ;
   _featureID_ngramlong = LMfeature_map.addFeature("NGramsLong") ;
   _featureID_brevity_b = LMfeature_map.addFeature("Brevity-Byte") ;
   _featureID_brevity_w = LMfeature_map.addFeature("Brevity-Word") ;
   _featureID_verbosity_b = LMfeature_map.addFeature("Verbosity-Byte") ;
   _featureID_verbosity_w = LMfeature_map.addFeature("Verbosity-Word") ;
   _featureID_length_b = LMfeature_map.addFeature("Length-Byte") ;
   _featureID_length_w = LMfeature_map.addFeature("Length-Word") ;
   _featureID_wordcount = LMfeature_map.addFeature("WordCount") ;
   _featureID_numarcs = LMfeature_map.addFeature("ArcCount") ;
   _featureID_overlap = LMfeature_map.addFeature("Overlap") ;
   _featureID_agreement = LMfeature_map.addFeature("MultiEngine") ;
   _featureID_reinforcement = LMfeature_map.addFeature("Reinforcement") ;
   _featureID_multipath = LMfeature_map.addFeature("MultiPath") ;
   _featureID_untrans = LMfeature_map.addFeature("Untranslated") ;
   _featureID_nulltrans = LMfeature_map.addFeature("Null-Translation") ;
   _featureID_future = LMfeature_map.addFeature("Future") ;

   if (config)
      {
      }
   else
      {
      // set default values
      _char_encoding = FrChEnc_Latin1 ;
      _Unicode_bswap = false ;
      _generate_chart = false ;		// output best path in a chart file?
      _ignore_case = true ;
      _ignore_source_morphology = false ;
      _question_particle_hack = true ;
      _canonicalized_input_data = false ;

      _LM_reach = 1 ;
      }
   return true ;
}

//----------------------------------------------------------------------

LMGlobalVariables *LMGlobalVariables::select()
{
   LMGlobalVariables *prev = active_vars ;
   if (!active_vars && !default_vars)
      default_vars = active_vars = new LMGlobalVariables(lm_vars) ;
   if (this == 0)
      {
      if (default_vars)
	 return default_vars->select() ;
      else
	 {
	 active_vars = 0 ;
	 return prev ;
	 }
      }
   if (this != active_vars)
      {
      if (prev)
	 *prev = lm_vars ;
      lm_vars = *this ;
      active_vars = this ;
      return prev ? prev : active_vars ;
      }
   return prev ;
}

/************************************************************************/
/************************************************************************/

void LmSetCharEncoding(const char *char_enc)
{
   char_encoding = FrParseCharEncoding(char_enc) ;
   if (char_encoding == FrChEnc_Unicode)
      cout << "Sorry, 16-bit Unicode not supported at this time" << endl ;
   uppercase_table = FrUppercaseTable(char_encoding) ;
   lowercase_table = FrLowercaseTable(char_encoding) ;
   EbSetCharEncoding(char_enc) ;
   return ;
}

//----------------------------------------------------------------------

double LmSetScaleFactor(double new_scale)
{
   double old_scale = LM_scale_factor ;
   if (new_scale >= 0.0 && new_scale <= 100.0)
      LM_scale_factor = new_scale ;
   return old_scale ;
}

//----------------------------------------------------------------------

double LmSetScaleFactor(const FrList *weights)
{
   for ( ; weights ; weights = weights->rest())
      {
      FrList *wtspec = (FrList*)weights->first() ;
      if (!wtspec || !wtspec->consp())
	 continue ;
      FrString *featname = (FrString*)wtspec->first() ;
      if (!featname || !featname->stringp())
	 continue ;
      const char *name = featname->stringValue() ;
      if (Fr_stricmp(name,"LMScore") == 0)
	 {
	 FrNumber *weight = (FrNumber*)wtspec->second() ;
	 if (weight && weight->numberp())
	    return LmSetScaleFactor(weight->floatValue()) ;
	 }
      }
   return LM_scale_factor ;
}

//----------------------------------------------------------------------

double LmSetScaleAdjust(double new_adjust)
{
   double old_adjust = LM_scale_adjust ;
   if (new_adjust >= 0.0 && new_adjust <= 100.0)
      LM_scale_adjust = new_adjust ;
   return old_adjust ;
}

// end of file lmglobal.cpp //
