/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Language Modeler -- configuration file parser			*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmfeat.C		feature and weight vectors		*/
/*  LastEdit: 21apr10							*/
/*									*/
/*  (c) Copyright 2010 Ralf Brown					*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "lmfeat.h"
#include "lmglobal.h"

/************************************************************************/
/*	Methods for class LmFeatureIndex				*/
/************************************************************************/

LmFeatureIndex::LmFeatureIndex(const FrList *feature_names,
			       const FrFeatureVectorMap *map)
{
   if (!feature_names || !map)
      {
      m_index = 0 ;
      m_numfeatures = 0 ;
      }
   else
      {
      m_numfeatures = feature_names->simplelistlength() ;
      m_index = FrNewC(size_t,m_numfeatures) ;
      if (!m_index)
	 {
	 m_numfeatures = 0 ;
	 FrNoMemory("while creating feature index") ;
	 }
      else
	 {
	 size_t i = 0 ;
	 for ( ; feature_names ; feature_names = feature_names->rest(), i++)
	    {
	    FrObject *feat = feature_names->first() ;
	    const char *featname = FrPrintableName(feat) ;
	    if (featname)
	       m_index[i] = map->featureIndex(featname,true) ;
	    else
	       m_index[i] = FrFeatureVectorMap::unknown ;
            }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

LmFeatureIndex::~LmFeatureIndex()
{
   FrFree(m_index) ;
   m_index = 0 ;
   m_numfeatures = 0 ;
   return ;
}

/************************************************************************/
/************************************************************************/

LmFeatureVector *LmMakeWeightVector(FrFeatureVectorMap *map,
				    const FrList *weights)
{
   LmFeatureVector *vector = new LmFeatureVector(map) ;
   if (!vector)
      {
      FrNoMemory("creating feature weight vector") ;
      return 0 ;
      }
   if (!weights)
      {
      if (total_sentences == 0)
	 FrWarning("no weights specified, all features will default to weight 1.0") ;
      for (size_t i = 0 ; i < vector->numFeatures() ; i++)
	 vector->setValue(i,1.0) ;
      vector->setValue(featureID_langmodel,LM_scale_factor) ;
      return vector ;
      }
   vector->setValue(featureID_langmodel,LM_scale_factor) ;
   for ( ; weights ; weights = weights->rest())
      {
      FrList *wtspec = (FrList*)weights->first() ;
      if (!wtspec || !wtspec->consp())
	 continue ;
      FrString *featname = (FrString*)wtspec->first() ;
      if (!featname || !featname->stringp())
	 continue ;
      const char *name = featname->stringValue() ;
      size_t index = map->featureIndex(name) ;
      if (index == FrFeatureVectorMap::unknown)
	 {
	 if (Fr_strnicmp(name,"WeightOf-",9) == 0)
	    {
	    name += 9 ;
	    index = map->featureIndex(name) ;
	    }
	 else
	    {
	    char *name2 = Fr_aprintf("WeightOf-%s",name) ;
	    index = map->featureIndex(name2) ;
	    FrFree(name2) ;
	    }
	 }
      if (index != FrFeatureVectorMap::unknown)
	 {
	 FrNumber *weight = (FrNumber*)wtspec->second() ;
	 if (!weight || !weight->numberp())
	    {
	    if (total_sentences == 0)
	       FrWarningVA("The weight for feature %s is not a number.",name) ;
	    continue ;
	    }
	 vector->setValue(index,weight->floatValue()) ;
	 }
      else if (verbose && total_sentences == 0)
	 FrWarningVA("Feature %s is not used",name) ;
      }
   return vector ;
}

//----------------------------------------------------------------------

static double makeLogValue(double value)
{
   static bool chart_in_log_space = false ; //FIXME
   if (chart_in_log_space)
      return value ;
   else
      return LmNGramModel::smoothedLog(value) ;
}

//----------------------------------------------------------------------

void LmAccumulateFeatures(const FrTextSpan *span,
			  FrFeatureVectorMap *map,
			  const FrList *prot_features)
{
   if (span && map)
      {
      const FrList *featlist = (const FrList*)span->getMetaData("F") ;
      if (featlist && featlist->consp())
	 {
	 for (const FrList *f = featlist ; f ; f = f->rest())
	    {
	    FrObject *feature = f->first() ;
	    if (!feature)
	       continue ;
	    else if (feature->consp())
	       {
	       FrObject *fname = ((FrList*)feature)->first() ;
	       const char *featname = FrPrintableName(fname) ;
	       if (featname)
		  {
		  bool protect = prot_features->member(fname,::equal) != 0 ;
		  (void)map->addFeature(featname,protect) ;
		  }
	       }
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void LmAccumulateFeatures(const FrTextSpan *span,
			  FrList *&features)
{
   if (span)
      {
      const FrList *featlist = (const FrList*)span->getMetaData("F") ;
      if (featlist && featlist->consp())
	 {
	 for (const FrList *f = featlist ; f ; f = f->rest())
	    {
	    FrObject *feature = f->first() ;
	    if (!feature)
	       continue ;
	    else if (feature->consp())
	       {
	       FrObject *fname = ((FrList*)feature)->first() ;
	       const char *featname = FrPrintableName(fname) ;
	       if (featname)
		  pushlist(new FrString(featname),features) ;
	       }
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

bool logspace_feature_vector = false ; //FIXME

LmFeatureVector *LmMakeFeatureVector(const FrTextSpan *span,
				     FrFeatureVectorMap *map,
				     const LmFeatureIndex *feature_index)
{
   if (!map)
      map = &LMfeature_map ;
   LmFeatureVector *vector = new LmFeatureVector(map) ;
   if (span)
      {
      const FrList *featlist = (const FrList*)span->getMetaData("F") ;
      if (featlist && featlist->consp())
	 {
	 size_t idx = 0 ;
	 for (const FrList *f = featlist ; f ; f = f->rest(), idx++)
	    {
	    FrObject *feature = f->first() ;
	    if (!feature)
	       continue ;
	    if (feature->numberp())
	       {
	       size_t index = feature_index->index(idx) ;
	       double value = feature->floatValue() ;
	       if (!logspace_feature_vector && !map->isProtected(index))
		  value = LmNGramModel::smoothedLog(value) ;
	       else if (!logspace_feature_vector && map->isProtected(index))
		  value -= feature_offset ; // offset base value from zero
	       vector->setValue(index,value) ;
	       }
	    else if (feature->consp())
	       {
	       FrObject *fname = ((FrList*)feature)->first() ;
	       FrObject *fvalue = ((FrList*)feature)->second() ;
	       if (FrPrintableName(fname) && fvalue && fvalue->numberp())
		  {
		  size_t index = map->featureIndex(FrPrintableName(fname)) ;
		  double value = fvalue->floatValue() ;
		  if (!logspace_feature_vector && !map->isProtected(index))
		     value = LmNGramModel::smoothedLog(value) ;
		  else if (!logspace_feature_vector && map->isProtected(index))
		     value -= feature_offset ; // offset base value from zero
		  vector->setValue(index,value) ;
		  }
	       }
	    }
	 }
      // override the generic feature vector metadata with specific values
      //   that were stored separately
      vector->setValue(featureID_score,makeLogValue(span->score())) ;
      vector->setValue(featureID_arcweight,makeLogValue(span->weight())) ;
      }
   return vector ;
}

//----------------------------------------------------------------------

static bool accumulate_features(const FrTextSpan *span, va_list args)
{
   FrVarArg(FrFeatureVectorMap*,map) ;
   FrVarArg(const FrList *,prot_features) ;
   if (span && map)
      LmAccumulateFeatures(span,map,prot_features) ;
   return true ;
}

//----------------------------------------------------------------------

void LmAccumulateFeatures(FrFeatureVectorMap *map, const FrTextSpans *lattice)
{
   if (!map || !lattice)
      return ;
   const FrList *prot_features = (FrList*)lattice->metaData("LIN_FEATURES");
   const FrList *feature_names = (FrList*)lattice->metaData("FEATURES") ;
   if (feature_names && !feature_names->consp())
      feature_names = 0 ;
   for (const FrList *fn = feature_names ; fn ; fn = fn->rest())
      {
      const char *name = FrPrintableName(fn->first()) ;
      if (name)
	 {
	 bool protect = prot_features->member(fn->first(),::equal) != 0 ;
	 map->addFeature(name,protect) ;
	 }
      }
   lattice->iterate(accumulate_features,map,prot_features) ;
   return ;
}

// end o file lmfeat.cpp //
