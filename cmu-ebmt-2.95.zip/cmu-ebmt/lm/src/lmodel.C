/************************************************************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmodel.cpp							*/
/*  LastEdit: 31mar10							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,2000,2002,2003,2004,2005,	*/
/*		2006,2007,2008,2009,2010 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "ebmt.h"			// for EbIsGapMarker etc.
#include "lmodel.h"
#include "lmarcs.h"
#include "lmglobal.h"

/************************************************************************/
/*	Manifest Constants						*/
/************************************************************************/

#define RANGE_MARKER "-"

/************************************************************************/
/*    Global variables for class TargetWord				*/
/************************************************************************/

FrAllocator TargetWord::allocator("TargetWord",sizeof(TargetWord)) ;
FrAllocator *TargetWord::s_IDallocator = 0 ;
size_t TargetWord::s_num_models = 1 ;

FrAllocator *TargetWordRef::s_prob_allocator = 0 ;
size_t TargetWordRef::s_num_models = 0 ;

/************************************************************************/
/*	Helper Functions						*/
/************************************************************************/

double weighted_average(double val1, double wt1, double val2, double wt2)
{
   if (wt1 + wt2)
      {
      double sum = (val1 * wt1) + (val2 * wt2) ;
      return sum / (wt1 + wt2) ;
      }
   else
      return 0.0 ;
}

//----------------------------------------------------------------------
// IMPORTANT: this function needs to stay synchronized with next_word()
//   in lmbuild.C

FrList *LmWord2Chars(const char *word, bool include_spaces)
{
   FrList *chars ;
   FrList **ch_end = &chars;

   // special-case the end-of-sentence marker since we don't want to rip it
   //   apart into separate characters
   if (Fr_stricmp(word,END_SENTENCE) == 0)
      return new FrList(new FrString(END_SENTENCE)) ;
   while (word && *word)
      {
      if (!include_spaces)
	 (void)FrSkipWhitespace(word) ;
      char chbuf[8] ;
      switch (char_encoding)
	 {
	 case FrChEnc_Unicode:
	    chbuf[0] = *word++ ;
	    chbuf[1] = *word++ ;
	    chbuf[2] = '\0' ;
	    chbuf[3] = '\0' ;
	    break ;
	 case FrChEnc_UTF8:
	    if (*word & 0x80)
	       {
	       chbuf[0] = *word++ ;
	       size_t i = 1 ;
	       while (*word && (*word++ & 0xC0) == 0x80 && i < sizeof(chbuf))
		  chbuf[i++] = *word++ ;
	       chbuf[i] = '\0' ;
	       }
	    else
	       {
	       // plain ASCII character, so just copy a single byte
	       chbuf[0] = *word++ ;
	       chbuf[1] = '\0' ;
	       }
	    break ;
	 case FrChEnc_EUC:
	    if (*word & 0x80)
	       {
	       chbuf[0] = *word++ ;
	       if (*word & 0x80)
		  {
		  chbuf[1] = *word++ ;
		  chbuf[2] = '\0' ;
		  }
	       else
		  chbuf[1] = '\0' ;
	       }
	    else
	       {
	       // plain ASCII character, so just copy a single byte
	       chbuf[0] = *word++ ;
	       chbuf[1] = '\0' ;
	       }
	    break ;
	 case FrChEnc_Latin1:
	 case FrChEnc_Latin2:
	 case FrChEnc_RawOctets:
	 default:
	    chbuf[0] = *word++ ;
	    chbuf[1] = '\0' ;
	    break ;
	 }
      chars->pushlistend(new FrString(chbuf),ch_end) ;
      }
   *ch_end = 0 ;			// properly terminate the list
   return chars ;
}

/************************************************************************/
/*    Methods for class TargetWord					*/
/************************************************************************/

void TargetWord::init(LmWordID_t **ids,const FrSymbol *nm,ChartArc *arc,
		      const FrSymbol *cl)
{
   m_IDs = (LmWordID_t**)s_IDallocator->allocate() ;
   for (size_t i = 0 ; i < s_num_models ; i++)
      {
      size_t count = ids[i][0] ;
      m_IDs[i] = FrNewN(LmWordID_t,count+1) ;
      if (m_IDs[i])
	 memcpy(m_IDs[i],ids[i],(count+1)*sizeof(m_IDs[i][0])); 
      }
   m_name = nm ;
   source_arc = arc ;
   source_words = 0 ;
   setMatchClass((FrSymbol*)cl,true) ;
   m_gapmarker = EbIsGapMarker(nm) ;
   m_gapfiller = (unsigned)~0 ;
   initFeatures(arc) ;
   m_refcount = 0 ;
   return ;
}

//----------------------------------------------------------------------

void TargetWord::init(LmNGramModel **models, FrSymbol *nm, ChartArc *arc,
		      FrSymbol *cl)
{ 
   m_name = nm ; 
   source_arc = arc ; 
   source_words = 0 ; 
   m_IDs = 0 ;
   setWordID(models,nm) ; 
   setMatchClass((FrSymbol*)cl,true) ;
   m_gapmarker = EbIsGapMarker(nm) ;
   m_gapfiller = (unsigned)~0 ;
   initFeatures(arc) ;
   m_refcount = 0 ;
   return ;
}

//----------------------------------------------------------------------

void TargetWord::init(LmNGramModel **models, FrSymbol *nm, const FrList *nms,
		      ChartArc *arc, FrSymbol *cl)
{ 
   m_name = nm ;
   source_arc = arc ; 
   source_words = 0 ; 
   m_IDs = 0 ;
   setWordID(models,nms) ; 
   setMatchClass((FrSymbol*)cl,true) ;
   m_gapmarker = EbIsGapMarker(nm) ;
   m_gapfiller = (unsigned)~0 ;
   initFeatures(arc) ;
   m_refcount = 0 ;
   return ;
}

//----------------------------------------------------------------------

void TargetWord::initFeatures(ChartArc *arc)
{
   if (arc)
      m_features.init(arc->features()) ;
   else
      m_features.init(&LMfeature_map) ; //FIXME
   return ;
}

//----------------------------------------------------------------------

void TargetWord::initIDAllocator(size_t num_models)
{
   freeIDAllocator() ;
   s_IDallocator = new FrAllocator("TargetWord_IDs",
				   num_models*sizeof(LmWordID_t*)) ;
   if (!s_IDallocator)
      num_models = 0 ;
   s_num_models = num_models ;
   return ;
}

//----------------------------------------------------------------------

void TargetWord::freeIDAllocator()
{
   if (s_IDallocator)
      {
      s_IDallocator->zapAll() ;
      delete s_IDallocator ;
      s_IDallocator = 0 ;
      }
   return ;
}

//----------------------------------------------------------------------

void TargetWord::zapAll()
{ 
//   allocator.zapAll() ; 
//   if (s_IDallocator)
//      s_IDallocator->zapAll() ;
   return ;
}

//----------------------------------------------------------------------

void TargetWord::setWordID(LmNGramModel **models, FrSymbol *nm)
{
   FrList *nms = 0 ;
   for (size_t i = 0 ; models[i] ; i++)
      pushlist(nm,nms) ;
   setWordID(models,nms) ;
   nms->eraseList(false) ;
   return ;
}

//----------------------------------------------------------------------

void TargetWord::setWordID(LmNGramModel **models, const FrList *nms)
{
   if (!m_IDs)
      {
      m_IDs = (LmWordID_t**)s_IDallocator->allocate() ;
      if (!m_IDs)
	 {
	 FrNoMemory("while allocating storage for TargetWord's word IDs") ;
	 return ;
	 }
      }
   for (size_t i = 0 ; i < s_num_models ; i++)
      m_IDs[i] = 0 ;
   if (!models || !models[0])
      {
      // fallback for the case where we have no language models at all:
      //   set every word to be unknown
      m_IDs[0] = FrNewN(LmWordID_t,2) ;
      if (m_IDs[0])
	 {
	 m_IDs[0][0] = 1 ;
	 m_IDs[0][1] = LmVOCAB_WORD_NOT_FOUND ;
	 }
      return ;
      }
   for (size_t i = 0 ; i < s_num_models ; i++, nms = nms ? nms->rest() : 0)
      {
      FrSymbol *nm = nms ? (FrSymbol*)nms->first() : 0 ;
      const char *word = nm ? nm->symbolName() : 0 ;
      if (word && !*word)
	 word = " " ;
      setWordID(models[i],word) ;
      }
   return ;
}

//----------------------------------------------------------------------

void TargetWord::setWordID(LmNGramModel *model, const char *word)
{
   size_t which = model->modelNumber() ;
   if (which < s_num_models)
      {
      if (model->isCharBased())
	 {
	 if (model->isStopWord(word))
	    {
	    m_IDs[which] = FrNewC(LmWordID_t,1) ;
	    }
	 else
	    {
	    FrList *chars = LmWord2Chars(word) ;
	    size_t numchars = chars->simplelistlength() ;
	    m_IDs[which] = FrNewN(LmWordID_t,numchars+1) ;
	    if (m_IDs[which])
	       {
	       m_IDs[which][0] = numchars ;
	       for (size_t c = 1 ; c <= numchars ; c++)
		  {
		  FrString *ch_str = (FrString*)poplist(chars) ;
		  const char *ch = ch_str->stringValue() ;
		  m_IDs[which][1] = model->findWordID(ch) ;
		  free_object(ch_str) ;
		  }
	       }
	    }
	 }
      else
	 {
	 m_IDs[which] = FrNewN(LmWordID_t,2) ;
	 if (m_IDs[which])
	    {
	    if (model->isStopWord(word))
	       m_IDs[which][0] = 0 ;
	    else
	       {
	       m_IDs[which][0] = 1 ;
	       m_IDs[which][1] = model->findWordID(word) ;
	       }
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void TargetWord::freeWordID()
{
   if (m_IDs)
      {
      for (size_t i = 0 ; i < s_num_models ; i++)
	 {
	 FrFree(m_IDs[i]) ;
	 }
      s_IDallocator->release(m_IDs) ;
      m_IDs = 0 ;
      }
   return ;
}

//----------------------------------------------------------------------

void TargetWord::setSourceWords(size_t first, size_t last)
{
   FrFree(source_words) ;
   if (last < first)
      last = first ;
   size_t numsource = last - first + 2 ;
   source_words = FrNewN(uint16_t,numsource) ;
   if (source_words)
      {
      for (size_t i = first ; i <= last ; i++)
	 source_words[i-first] = (uint16_t)i ;
      source_words[numsource-1] = SOURCE_ALIGN_EOD ;
      }
   else
      FrNoMemory("while storing source-alignment information for target word");
   return ;
}

//----------------------------------------------------------------------

bool TargetWord::isEmbeddedGapMarker() const
{
   return EbIsEmbeddedGapMarker(name()->symbolName()) ;
}

//----------------------------------------------------------------------

static size_t highest_location(const FrList *locations)
{
   size_t highest = 0 ;
   for ( ; locations ; locations = locations->rest())
      {
      FrObject *first = locations->first() ;
      if (!first)
	 continue ;
      size_t high ;
      if (first->consp())
	 high = highest_location((FrList*)first) ;
      else if (first->numberp())
	 high = first->intValue() ;
      else
	 high = 0 ;
      if (high > highest)
	 highest = high ;
      }
   return highest ;
}

//----------------------------------------------------------------------

static void collect_locations(const FrList *locations, FrBitVector &locs)
{
   size_t prevloc = 0 ;
   for ( ; locations ; locations = locations->rest())
      {
      FrObject *first = locations->first() ;
      if (!first)
	 continue ;
      else if (first->consp())
	 collect_locations((FrList*)first,locs) ;
      else if (first->symbolp() && 
	       strcmp(((FrSymbol*)first)->symbolName(),"-") == 0)
	 {
	 locations = locations->rest() ;
	 size_t lastloc = locations->first()->intValue() ;
	 locs.setRange(prevloc,lastloc) ;
	 prevloc = lastloc ;
	 }
      else if (first->numberp())
	 {
	 size_t loc = first->intValue() ;
	 locs.setBit(loc) ;
	 prevloc = loc ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void TargetWord::setSourceWords(const FrList *locations)
{
   if (locations && !locations->consp())
      {
      source_words = FrNewN(uint16_t,2) ;
      if (source_words)
	 {
	 source_words[0] = (uint16_t)locations->intValue() ;
	 source_words[1] = SOURCE_ALIGN_EOD ;
	 }
      }
   else
      {
      size_t highest = highest_location(locations) ;
      FrBitVector locs(highest+1) ;
      collect_locations(locations,locs) ;
      size_t numsource = locs.countBits() ;
      source_words = FrNewN(uint16_t,numsource+1) ;
      if (source_words)
	 {
	 size_t i ;
	 size_t loc ;
	 for (i = 0, loc = 0 ; loc <= highest && i < numsource ; loc++)
	    {
	    if (locs.getBit(loc))
	       source_words[i++] = (uint16_t)loc ;
	    }
	 source_words[i] = SOURCE_ALIGN_EOD ;
	 }
      else
	 FrNoMemory("while storing source-alignment information for target word");
      }
   return ;
}

//----------------------------------------------------------------------

FrList *TargetWord::sourceAlignment() const
{
   FrList *align = 0 ;
   FrList **end = &align ;
   if (source_words)
      {
      FrSymbol *range_marker = FrSymbolTable::add(RANGE_MARKER) ;
      for (size_t i = 0 ; source_words[i] != SOURCE_ALIGN_EOD ; i++)
	 {
	 size_t pos1 = source_words[i] ;
	 size_t pos2 = source_words[i+1] ;
	 align->pushlistend(new FrInteger(pos1),end) ;
	 if (pos1 + 1 == pos2 && pos2 != SOURCE_ALIGN_EOD &&
	     pos2 + 1 == source_words[i+2])
	    {
	    // this is a range that can be compressed
	    i += 2 ;
	    pos2 = source_words[i] ;
	    while (source_words[i+1] != SOURCE_ALIGN_EOD &&
		   pos2 + 1 == source_words[i+1])
	       {
	       pos2++ ;
	       i++ ;
	       }
	    align->pushlistend(range_marker,end) ;
	    align->pushlistend(new FrInteger(pos2),end) ;
	    }
	 }
      }
   *end = 0 ;				// ensure proper termination of list
   return align ;
}

//----------------------------------------------------------------------

void TargetWord::freeSourceWords()
{
   FrFree(source_words) ;
   source_words = 0 ;
   return ;
}

//----------------------------------------------------------------------

void TargetWord::setFillerLocation(size_t arc_start)
{
   if (isGapMarker())
      m_gapfiller = EbGapFillerLocation(name(),arc_start,
					source_arc->sourceWordSpan()) ;
   return ;
}

/************************************************************************/
/*    Methods for class TargetWordRef					*/
/************************************************************************/

void TargetWordRef::init(TargetWord *tword, const ChartArc *, size_t cover)
{
   m_targetword = tword ;
   if (tword) tword->addReference() ;
   setCoverage(cover) ;
   allocProbabilities() ;
   invalidateProbability() ;
   setAvgNgram(0.0) ;
   return ;
}

//----------------------------------------------------------------------

void TargetWordRef::init(TargetWord *tword, size_t cover)
{
   m_targetword = tword ;
   if (tword) tword->addReference() ;
   setCoverage(cover) ;
   allocProbabilities() ;
   invalidateProbability() ;
   setAvgNgram(0.0) ;
   return ;
}

//----------------------------------------------------------------------

void TargetWordRef::init(const TargetWordRef &orig)
{
   m_targetword = orig.targetWord() ;
   if (m_targetword) m_targetword->addReference() ;
   setCoverage(orig.coverage()) ;
   allocProbabilities() ;
   setProbabilities(orig) ;
   m_avgngram = orig.avgNgram() ;
   return ;
}

//----------------------------------------------------------------------

void TargetWordRef::reinit(const TargetWordRef &orig)
{
   if (m_targetword != orig.targetWord())
      {
      if (m_targetword)
	 m_targetword->removeReference() ;
      m_targetword = orig.targetWord() ;
      if (m_targetword)
	 m_targetword->addReference() ;
      }
   setCoverage(orig.coverage()) ;
   if (m_probabilities == 0)
      allocProbabilities() ;
   setProbabilities(orig) ;
   m_avgngram = orig.avgNgram() ;
   return ;
}

//----------------------------------------------------------------------

void TargetWordRef::setProbabilities(const TargetWordRef &orig)
{
   for (size_t i = 0 ; i <= s_num_models ; i++)
      m_probabilities[i] = orig.m_probabilities[i] ;
   return ;
}

//----------------------------------------------------------------------

void TargetWordRef::initProbAllocator(size_t num_models)
{
   freeProbAllocator() ;
   s_prob_allocator = new FrAllocator("TargetWord Probs",
				      (num_models+1)*sizeof(float)) ;
   if (!s_prob_allocator)
      num_models = 0 ;
   s_num_models = num_models ;
   return ;
}

//----------------------------------------------------------------------

void TargetWordRef::freeProbAllocator()
{
   if (s_prob_allocator)
      {
      s_prob_allocator->zapAll() ;
      delete s_prob_allocator ;
      s_prob_allocator = 0 ;
      s_num_models = 0 ;
      }
   return ;
}

//----------------------------------------------------------------------

void TargetWordRef::allocProbabilities()
{
   m_probabilities = (float*)s_prob_allocator->allocate() ;
   if (m_probabilities)
      {
      for (size_t i = 0 ; i <= s_num_models ; i++)
	 m_probabilities[i] = LmINVALID_PROB ;
      }
   return ;
}

//----------------------------------------------------------------------

void TargetWordRef::freeProbabilities()
{
   if (m_probabilities)
      {
      s_prob_allocator->release(m_probabilities) ;
      m_probabilities = 0 ;
      }
   return ;
}

/************************************************************************/
/*    Methods for class TargetWordList					*/
/************************************************************************/

TargetWordList::TargetWordList(const TargetWord * const *words,int num,
			       LmNGramModel **models)
{
   numwords = num ; 
   m_models = models ;
   m_numarcs = 0 ;
   m_arcs = 0 ;
   wordlist = FrNewN(TargetWord*,num) ;
   if (wordlist)
      {
      for (int i = 0 ; i < num ; i++)
	 {
	 TargetWord *w = (TargetWord*)(words[i]) ;
	 wordlist[i] = w ;
	 if (w)
	    w->addReference() ;
	 }
      }
   else
      FrNoMemory("setting up target word list") ;
   return ;
}

//----------------------------------------------------------------------

TargetWordList::TargetWordList(const TargetWordRef *words,int num,
			       LmNGramModel **models)
{
   numwords = num ; 
   m_models = models ;
   m_numarcs = 0 ;
   m_arcs = 0 ;
   wordlist = FrNewN(TargetWord*,num) ;
   if (wordlist)
      {
      for (int i = 0 ; i < num ; i++)
	 {
	 TargetWord *tw = words[i].targetWord() ;
	 wordlist[i] = tw ;
	 if (tw)
	    tw->addReference() ;
	 }
      }
   else
      FrNoMemory("setting up target word list") ;
   return ;
}

//----------------------------------------------------------------------

TargetWordList::~TargetWordList()
{
   for (int i = 0 ; i < numwords ; i++)
      {
      if (wordlist[i])
	 {
	 wordlist[i]->removeReference() ;
	 // delete if this was the last reference to the target word
//FIXME:causing freelist-loop
//	 wordlist[i]->free() ;
	 }
      }
   numwords = 0 ;
   FrFree(wordlist) ;		wordlist = 0 ;
   FrFree(m_arcs) ;		m_numarcs = 0 ;
   return ;
}

//----------------------------------------------------------------------

void TargetWordList::freeObject()
{
   delete this ;
   return ;
}

//----------------------------------------------------------------------

size_t TargetWordList::length() const
{
   return numwords ;
}

//----------------------------------------------------------------------

ostream &TargetWordList::printValue(ostream &output) const
{
   output << "TargetWordList<" << numArcs() << '/' ;
   for (size_t i = 0 ; i < twlLength() ; i++)
      {
      if (i > 0)
	 output << ' ' ;
      output << wordN(i)->name() ;
      }
   output << ">" ;
   return output ;
}

//----------------------------------------------------------------------

size_t TargetWordList::displayLength() const
{
   size_t len = 16 ;
   for (size_t i = 0 ; i < twlLength() ; i++)
      {
      if (i > 0)
	 len++ ;
      len += wordN(i)->name()->displayLength() ;
      }
   return len ;
}

//----------------------------------------------------------------------

char *TargetWordList::displayValue(char *buffer) const
{
   strcpy(buffer,"TargetWordList<") ;
   buffer = strchr(buffer,'\0') ;
   sprintf(buffer,"%d/",(int)numArcs()) ;
   buffer = strchr(buffer,'\0') ;
   for (size_t i = 0 ; i < twlLength() ; i++)
      {
      if (i > 0)
	 *buffer++ = ' ' ;
      strcpy(buffer,wordN(i)->name()->symbolName()) ;
      buffer = strchr(buffer,'\0') ;
      }
   *buffer++ = '>' ;
   *buffer = '\0' ;
   return buffer ;
}

//----------------------------------------------------------------------

void TargetWordList::addArcs(const ComponentArcInfo *arcs, size_t numarcs)
{
   if (m_arcs)
      {
      FrFree(m_arcs) ;
      m_arcs = 0 ;
      }
   m_numarcs = 0 ;
   if (arcs)
      {
      m_arcs = FrNewN(const ChartArc*,numarcs) ;
      if (m_arcs)
	 {
	 m_numarcs = numarcs ;
	 for (size_t i = 0 ; i < numarcs ; i++)
	    {
	    m_arcs[i] = arcs[i].arc() ;
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

bool TargetWordList::removeWord(size_t N)
{
   if (N < (size_t)numwords)
      {
      if (wordlist[N])
	 wordlist[N]->removeReference() ;
      for (int i = N+1 ; i < numwords ; i++)
	 {
	 wordlist[i-1] = wordlist[i] ;
	 }
      numwords-- ;
      return true ;
      }
   else
      return false ;
}

/************************************************************************/
/*    Methods for class WordInfo					*/
/************************************************************************/

void WordInfo::init()
{
   m_surface = 0 ;
   return ;
}

//----------------------------------------------------------------------

void WordInfo::init(const char *word, size_t wordlen)
{
   m_surface = FrNewN(char,wordlen+1) ;
   if (m_surface)
      {
      memcpy(m_surface,word,wordlen) ;
      m_surface[wordlen] = '\0' ;
      m_symbol = FrSymbolTable::add(m_surface) ;
      }
   else
      m_symbol = 0 ;
   return ;
}

//----------------------------------------------------------------------

WordInfo &WordInfo::operator = (const WordInfo &orig)
{
   FrFree(m_surface) ;
   m_surface = FrDupString(orig.surface()) ;
   m_symbol = orig.symbol() ;
   return *this ;
}

//----------------------------------------------------------------------

void WordInfo::initVariables()
{
   return ;
}

// end of file lmodel.cpp //
