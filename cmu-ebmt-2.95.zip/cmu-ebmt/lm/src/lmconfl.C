/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.90beta							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmconfl.cpp		conflict sets				*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 2008 Ralf Brown					*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "lmarcs.h"

/************************************************************************/
/************************************************************************/

void LmConflicts::init(size_t min, size_t max)
{
   if (max < min)
      {
      size_t tmp = min ; min = max ; max = tmp ;
      }
   min /= LM_BITS_PER_ENTRY ;
   max = (max / LM_BITS_PER_ENTRY) + 1 ;
   if (m_conflictset) FrFree(m_conflictset) ;
   m_conflictset = FrNewC(LmBitFlags,max-min) ;
   m_count = 0 ;
   if (m_conflictset)
      {
      m_min = min * LM_BITS_PER_ENTRY ;
      m_max = max * LM_BITS_PER_ENTRY ;
      }
   else
      {
      m_min = m_max = 0 ;
      }
   return ;
}

//----------------------------------------------------------------------

void LmConflicts::addConflict(size_t N)
{
   if (N >= m_min && N < m_max)
      {
      N -= m_min ;
      size_t loc = N / LM_BITS_PER_ENTRY ;
      size_t mask = 1U << (N % LM_BITS_PER_ENTRY) ;
      if ((m_conflictset[loc] & mask) == 0)
	 {
	 m_conflictset[loc] |= mask ;
	 m_count++ ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

bool LmConflicts::conflicts(const LmConflicts &other) const
{
   if (maxStored() < other.minStored() ||
       minStored() > other.maxStored())
      return false ;
   const LmBitFlags *set1 = conflictSet() ;
   const LmBitFlags *set2 = other.conflictSet() ;
   FrUINT32 min1 = minStored() / LM_BITS_PER_ENTRY ;
   FrUINT32 min2 = other.minStored() / LM_BITS_PER_ENTRY ;
   FrUINT32 max1 = maxStored() / LM_BITS_PER_ENTRY ;
   FrUINT32 max2 = other.maxStored() / LM_BITS_PER_ENTRY ;
   // adjust start offsets to remove non-common elements
   if (min1 > min2)
      {
      set2 += (min1 - min2) ;
      max2 -= (min1 - min2) ;
      }
   else if (min2 > min1)
      {
      set1 += (min2 - min1) ;
      max1 -= (min2 - min1) ;
      }
   if (max2 < max1) max1 = max2 ;
   for (size_t i = 0 ; i < max1 ; i++)
      {
      if ((set1[i] & set2[i]) != 0)
	 return true ;			// the sets have a member in common
      }
   return false ;
}

// end of file lmconfl.cpp //
