/************************************************************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmprique.h	priority queue					*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,2002,2004,2006,2008,2009	*/
/*		 Ralf Brown						*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __LMPRIQUE_H_INCLUDED
#define __LMPRIQUE_H_INCLUDED

#include "FramepaC.h"

class BFSNode ;

/************************************************************************/
/************************************************************************/

class PriorityQueue
   {
   private:
      BFSNode *m_nodes ;		// treap of the nodes in the queue
      BFSNode *m_pruned ;		// list of pruned nodes
      BFSNode *m_sorted ;		// list of nodes by decr. score
      size_t m_length ;			// current queue length
      size_t maxlength ;		// maximum queue length permitted
      size_t maxlength_used ;		// maximum queue length actually used
      size_t num_pruned ;
      size_t max_pruned ;		// limit 'pruned' to this many nodes
      double m_highscore ;		// highest score of all nodes in queue
      double m_cutoff ;
      double m_cutoff_ratio ;
      bool nodes_sorted ;
      bool remember_pruned ;
#ifdef FrMULTITHREAD
      FrMutex m_mutex ;
#endif /* FrMULTITHREAD */
   private:
      bool insertPruned(BFSNode *node, size_t &prune_count) ;
   public:
      void *operator new(size_t size) { return FrMalloc(size) ; }
      void operator delete(void *blk) { FrFree(blk) ; }
      PriorityQueue(size_t limit, double ratio = 1000000.0,
		    bool keep_pruned = false, size_t nbest_list_size = 0) ;
      ~PriorityQueue() ;

      // access to internal state
      size_t currentLength() const { return m_length ; }
      size_t maximumLength() const { return maxlength ; }
      size_t maximumLengthAttained() const { return maxlength_used ; }
      size_t numPruned() const { return num_pruned ; }
      size_t maxPruned() const { return max_pruned ; }
      double highestScore() const { return m_highscore ; }
      double cutoff() const { return m_cutoff ; }
      const BFSNode *prunedNodes() const { return m_pruned ; }

      // operations on the queue
      void sort() ;
      BFSNode *peek() ;
      BFSNode *pop() ;
      BFSNode *popAll() ; // returns list
      bool insert(BFSNode *newelt, size_t &num_pruned) ;
      bool insertMultiple(BFSNode *nodes, size_t &prune_count) ;
      bool refill(size_t num_remaining = 0) ;
      void setCutoff(double) ;
      void setPruningLimit(size_t factor) ;
      void clearPruning() ;

      // synchronization
#ifdef FrMULTITHREAD
      FrMutex &mutex() { return m_mutex ; }
#endif /* FrMULTITHREAD */
      void lock() { FrCRITSECT_ENTER(m_mutex) ; }
      bool trylock() { return FrCRITSECT_TRYENTER(m_mutex) ; }
      void unlock() { FrCRITSECT_LEAVE(m_mutex) ; }

      // debugging support
      static void checkTree(const BFSNode *tree) ;
   } ;

/************************************************************************/
/************************************************************************/

BFSNode *LmTreapInsert(BFSNode *&root, BFSNode *node) ;
BFSNode *LmTreapFromList(BFSNode *nodelist) ;
BFSNode *LmTreapJoin(BFSNode *left, BFSNode *right) ;
bool LmTreapRemove(BFSNode *&root, BFSNode *node) ;
BFSNode *LmTreapPopMin(BFSNode *&root) ;
BFSNode *LmTreapToList(BFSNode *root) ;
void LmTreapDelete(BFSNode *root) ;

#endif /* !__LMPRIQUE_H_INCLUDED */

// end of file lmprique.h //
