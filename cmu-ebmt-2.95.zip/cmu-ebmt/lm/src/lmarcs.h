/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmarcs.h	classes ChartArc, ChartArcElt, ChartContext 	*/
/*  LastEdit: 06apr10							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __LMARCS_H_INCLUDED
#define __LMARCS_H_INCLUDED

#include "FramepaC.h"

#ifndef __LMBITSET_H_INCLUDED
#include "lmbitset.h"
#endif

#ifndef __LMNGRAM_H_INCLUDED
#include "lmngram.h"
#endif

#ifndef __LMBFS_H_INCLUDED
#include "lmbfs.h"
#endif

#include "lmglobal.h"

/************************************************************************/
/*	Manifest Constants						*/
/************************************************************************/

#define SOURCE_ALIGN_EOD ((uint16_t)~0)

#define LmINVALID_PROB	(999.9)

/************************************************************************/
/*	Types								*/
/************************************************************************/

class TargetWord ;
class TargetWordRef ;
class ChartArc ;
class ChartContext ;
class ParseChart ;
class MTEngine ;

enum ChartEntryType
   {
   CE_none,
   CE_Merged,
   CE_LM,
   } ;

typedef uint32_t ChartEntryTypes ; // bitmap of entry types

/************************************************************************/
/************************************************************************/

class LmNGramLengthMask
   {
   private:
      uint16_t m_mask ;
   public:
      LmNGramLengthMask() { clear() ; }
      ~LmNGramLengthMask() {}

      // accessors
      size_t maxLength() const ;
      bool lengthExisted(size_t N) const
	 { return (N > 0) ? (m_mask & (1 << (N-1))) != 0 : false ; }

      // modifiers
      void clear() { m_mask = 0 ; }
      void addLength(size_t N) { if (N > 0) m_mask |= (1 << (N-1)) ; }
   } ;

/************************************************************************/
/************************************************************************/

class WordInfo
   {
   private:
      char  *m_surface ;
      FrSymbol *m_symbol ;
   public:
      void *operator new(size_t /*size*/, void *where) { return where ; }
      void *operator new(size_t size) { return FrMalloc(size) ; }
      void operator delete(void *blk) { FrFree(blk) ; }
      WordInfo() { m_surface = 0 ; m_symbol = 0 ; }
      WordInfo(const char *word, size_t wordlen)
	 { init(word,wordlen) ; }
      ~WordInfo() { FrFree(m_surface) ; }
      void init() ;
      void init(const char *word, size_t wordlen) ;

      WordInfo &operator = (const WordInfo &) ;

      // accessors
      const char *surface() const { return m_surface ; }
      FrSymbol *symbol() const { return m_symbol ; }

      static void initVariables() ;
   } ;

/************************************************************************/
/************************************************************************/

class ChartArcSuccessor
   {
   private:
      ChartArc *m_successor ;
      LmUSHORT  m_srcoverlap ;
      LmUSHORT	m_trgoverlap ;
      LmUSHORT	m_reordering ;
      bool      m_fillsgap ;
   public:
      void init(ChartArc *arc, size_t s_ovr = 0, size_t t_ovr = 0,
		size_t reord = 0, bool fills = false)
	 { m_successor = arc ; m_srcoverlap = (LmUSHORT)s_ovr ;
	   m_trgoverlap = (LmUSHORT)t_ovr ;
	   m_fillsgap = fills ; m_reordering = (LmUSHORT)reord ; }

      ChartArcSuccessor() { m_successor = 0 ; m_srcoverlap=m_trgoverlap=0 ; }
      ChartArcSuccessor(ChartArc *arc, size_t s_ovr = 0, size_t t_ovr = 0,
			size_t reord = 0, bool fills = false)
	 { init(arc,s_ovr,t_ovr,reord,fills) ; }
      ~ChartArcSuccessor() {}

      // accessors
      ChartArc *arc() const { return m_successor ; }
      size_t sourceOverlap() const { return m_srcoverlap ; }
      size_t targetOverlap() const { return m_trgoverlap ; }
      size_t reordering() const { return m_reordering ; }
      bool fillsGap() const { return m_fillsgap ; }
   } ;

/************************************************************************/
/************************************************************************/

class ComponentArcInfo
   {
   private:
      const ChartArc *m_arc ;
      int32_t         m_overlap ;
      int32_t	      m_trgposition ;
      bool	      m_subsumed ;
   public:
      void *operator new(size_t, void *where) { return where ; }
      void init(const ChartArc *arc, size_t overlap, size_t trgpos,
		bool sub = false)
	 { m_arc = arc ; m_overlap = (int32_t)overlap ;
	   m_trgposition = (int32_t)trgpos ; m_subsumed = sub ; }
      ComponentArcInfo() { init(0,0,0) ; }
      ComponentArcInfo(const ChartArc *arc, size_t overlap = 0,
		       size_t trgpos = 0, bool sub = false)
	 { init(arc,overlap,trgpos,sub) ; }
      ~ComponentArcInfo() {}

      // accessors
      const ChartArc *arc() const { return m_arc ; }
      size_t overlap() const { return m_overlap ; }
      size_t targetPosition() const { return m_trgposition ; }
      bool subsumed() const { return m_subsumed ; }

      // manipulators
      void setTargetPosition(size_t pos) { m_trgposition = (int32_t)pos ; }
      void incrTargetPosition(size_t ofs) { m_trgposition += (int32_t)ofs ; }
      void markSubsumed() { m_subsumed = true ; }
   } ;

/************************************************************************/
/************************************************************************/

class LmConflicts
   {
   private:
      LmBitFlags *m_conflictset ;
      FrUINT32 m_count ;
      FrUINT32 m_min ;
      FrUINT32 m_max ;
   public:
      LmConflicts() { m_count = m_min = m_max = 0 ; m_conflictset = 0 ; }
      ~LmConflicts()
	 { FrFree(m_conflictset) ; m_conflictset = 0 ; m_count = m_max = 0 ;}

      // manipulators
      void init(size_t min, size_t max) ;
      void addConflict(size_t N) ;

      // accessors
      LmBitFlags *conflictSet() const { return m_conflictset ; }
      FrUINT32 numConflicts() const { return m_count ; }
      FrUINT32 minStored() const { return m_min ; }
      FrUINT32 maxStored() const { return m_max ; }
      bool conflicts(size_t N) const
	 { if (N >= m_min && N < m_max)
	    return LmGetBit(m_conflictset,N - m_min) ;
	  else return false ; }
      bool conflicts(const LmConflicts &other) const ;

   } ;

/************************************************************************/
/************************************************************************/

class ChartArc
   {
   private:
      static FrAllocator allocator ;
   protected:
      ChartArc *m_next ;
   private:
      ChartArcSuccessor *m_successors ;	// array of arcs that could add to path
      WordInfo *source_word_info ;
      TargetWordRef *target_word_stats ;
      ComponentArcInfo *m_subsumes ;	// arcs subsumed by this one
      ParseChart *m_chart ;		// the chart containing this arc
      char *source_text ;
      char *target_text ;
      FrList *m_altsequences ;		// alternate target sequences for arc
      LmBitFlags *m_source_cover ;	// which words are actually covered?
      char *target_prefix ;
      char *target_suffix ;
      LmNGramModel **m_models ;
      const FrStruct *m_metadata ;	// meta-data in input FrTextSpans
      LmConflicts m_conflicts ;
      LmFeatureVector m_features ;	// all feature values
      size_t m_arcID ;
      size_t m_numsuccessors ;
      size_t m_numsubsumed ;
      int    m_occurrences ;
      LmUSHORT m_startpos ;
      LmUSHORT m_coverage ;
      LmUSHORT m_match_wc ;
      LmUSHORT m_source_span ;
      LmUSHORT m_source_wc ;
      LmUSHORT m_arclen ;
      bool     question ;
      bool     has_gap_markers ;
      bool     has_alignments ;
      bool     m_is_successor ;
      bool     m_singleword_source ;
      ChartEntryTypes arctype ;
   private: //methods
      void init(bool have_feature_vector) ;
      void makeTargetText() ;
      void allocSourceCover(size_t count) ;
      void freeSourceCover() ;
      ComponentArcInfo *mergeSubsumedArcs(const ChartArc *other,
					  size_t &num_subsumed,
					  size_t trg_offset) const ;
   public:
      void *operator new(size_t) { return allocator.allocate() ; }
      void operator delete(void *blk) { allocator.release(blk) ; }
      ChartArc() ;
      ChartArc(const ChartArc *base_arc, const ChartArc *add_arc,
	       TargetWordRef target_words[], size_t num_words,
	       size_t trg_offset) ;
      ChartArc(MTEngine *engine, char *source, char *translation,
	       const FrList *alignment, size_t startpos, int cover,
	       const LmFeatureVector*, LmNGramModel **models,
	       const FrList *morph, const FrList *altseq,
	       ParseChart *chart, ChartArc *nextarc) ;
      ~ChartArc() ;
      static ChartArc *combineArcs(const ChartArc *arc1, const ChartArc *arc2,
				   size_t trg_overlap);

      // modifiers
      void setNext(ChartArc *nxt) { m_next = nxt ; }
      void setNextArc(ChartArc *nxt) { m_next = nxt ; }
      void setChart(ParseChart *chart) { m_chart = chart ; }
      void setID(size_t id) { m_arcID = id ; }
      void markAsSuccessor() { m_is_successor = true ; }
      void markNotSuccessor() { m_is_successor = false ; }
      void updateInputCover(LmBitFlags *overall_coverage, LmUSHORT &bytecover,
			    const size_t *word_boundaries) const ;
      void mergeArc(MTEngine *engine, const LmFeatureVector*, double weight) ;
      void mergeArc(ChartEntryType type, const LmFeatureVector*, double weight) ;
      bool merge(MTEngine *engine, const char *source,
		 const char *translation, const FrList *altseq,
		 size_t cover, const LmFeatureVector*, ChartArc **prev_arc = 0) ;

      ChartArc *sort(const LmFeatureVector *weights) ;
      ChartArc *reverseList() ;
      void replaceFeatures(const LmFeatureVector *f)
	 { m_features.copyValues(f) ; }

      // tests
      bool allowableArc(const LmBitFlags *previous_coverage,
			size_t src_overlap) const ;
      bool canFillGap(const ChartArc *, size_t srcoverlap,
		      size_t &trgoverlap) const ;

      // I/O
      ostream &dump(ostream &output) const ;
      friend ostream &operator << (ostream &output, const ChartArc *) ;

      // manipulation functions
      void initSourceWC() ;
      void singleWordSource(bool s) { m_singleword_source = s ; }
      void setStart(size_t start) { m_startpos = start ; }
      void setFeature(unsigned ID, double val) { m_features.setValue(ID,val); }
      void setWeight(double weight)
	 { m_features.setValue(featureID_arcweight,weight) ; }
      void setAgreementBonus(size_t count)
	 { m_features.setValue(featureID_agreement,count) ; }
      void setFutureUtility(double util)
	 { m_features.setValue(featureID_future,util) ; }
      void setFutureUtility(class LmNGramModel **models,
			    const LmFeatureVector *weights) ;
      void setDecoration(const char *prefix, const char *suffix) ;
      void setMetaData(const FrStruct *md)
	 { m_metadata = md ; } // note: 'md' must remain valid!
      void incrLengthBonus(size_t len) ;
      void setChunkingBonus(double chbonus) ;
      void setChunkingBonus(const FrTextSpan *span) ;
      void setUntransPenalty(double pen)
	 { m_features.setValue(featureID_untrans,pen) ; }
      void incrUntransPenalty(double incr)
	 { m_features.incrValue(featureID_untrans,incr) ; }
      void setSuccessors(ChartArcSuccessor *successors, size_t count) ;
      void setSourceSpan(size_t span) { m_source_span = span ; }
      void setSourceAlignment(size_t wordnum, size_t srcstart, size_t srcend);
      void overrideTypes(ChartEntryTypes types)
	    { arctype &= ~types ; }
      void setFillerLocations() ;
      void addConflict(const ChartArc *, size_t total_arcs) ;

      // access to state
      ChartArc *next() const { return m_next ; }
      ChartArc *nextArc() const { return m_next ; }
      const LmFeatureVector *features() const { return &m_features ; }
      LmFeatureVector *features() { return &m_features ; }
      size_t arcID() const { return m_arcID ; }
      ParseChart *chart() const { return m_chart ; }
      const FrSymbol *nthWord(size_t n) const ;
      LmWordID_t nthWordID(size_t n, size_t modelnum) const ;
      int occurrences() const { return m_occurrences ; }
      LmNGramModel **models() const { return m_models ; }
      double getFeature(unsigned ID) const { return m_features.value(ID) ; }
      double logScore() const { return m_features.value(featureID_score) ; }
      double weight() const { return m_features.value(featureID_arcweight) ; }
      double chunkingBonus() const { return m_features.value(featureID_chunking) ; }
      double untransPenalty() const { return m_features.value(featureID_untrans) ; }
      double futureUtility() const { return m_features.value(featureID_future) ; }
      size_t startPosition() const { return m_startpos ; }
      size_t coverage() const { return m_coverage ; }
      size_t endPosition() const { return m_startpos + m_coverage - 1 ; }
      size_t pastEndPosition() const { return m_startpos + m_coverage ; }
      size_t arcLength() const { return m_arclen ; }
      size_t sourceWordSpan() const { return m_source_span ; }
      size_t sourceWordCount() const { return m_source_wc ; }
      size_t matchWordCount() const { return m_match_wc ; }
      ChartEntryTypes arcType() const { return arctype ; }
      const char *arc_type_name() const ;
      const WordInfo *sourceWordInfo() const { return source_word_info ; }
      const TargetWordRef *targetWordStats(size_t N) const ;
      const TargetWordRef *targetWordStats() const
	 { return target_word_stats ; }
      const TargetWord *targetWordInfo(size_t N) const ;
      const ComponentArcInfo *subsumedArcs() const
	 { return m_subsumes ; }
      const ChartArc *subsumedArc(size_t N) const
	 { return (subsumedArcs() && N < numSubsumedArcs())
	      ? m_subsumes[N].arc() : 0 ; }
      const ComponentArcInfo *subsumedArcInfo(size_t N) const
	 { return (subsumedArcs() && N < numSubsumedArcs())
	      ? &m_subsumes[N] : 0 ; }
      const char *sourceText() const { return source_text ; }
      const char *targetText() const { return target_text ; }
      const LmBitFlags *sourceCover() const
         { const LmBitFlags &f = reinterpret_cast<LmBitFlags>(m_source_cover) ;
	   return LmGetBit(&f,0) ? &f : m_source_cover ; }
      LmBitFlags *sourceCover()
         { const LmBitFlags &f = reinterpret_cast<LmBitFlags>(m_source_cover) ;
	   return LmGetBit(&f,0) ? (LmBitFlags*)&f : m_source_cover ; }
      bool sourceCovered(size_t N) const ;
      const char *targetPrefix() const { return target_prefix ; }
      const char *targetSuffix() const { return target_suffix ; }
      FrSymbol *sourceWord(size_t N) const ;
      FrSymbol *targetWord(size_t N) const ;
      const FrStruct *metaData() const { return m_metadata ; }
      const LmConflicts &conflicts() const { return m_conflicts ; }
      size_t numConflicts() const { return m_conflicts.numConflicts() ; }
      bool isQuestion() const { return question ; }
      bool hasGapMarkers() const { return has_gap_markers ; }
      bool hasAlignments() const { return has_alignments ; }
      bool isSuccessor() const { return m_is_successor ; }
      bool isComposite() const { return m_numsubsumed > 0 ; }
      bool singleWordSource() const { return m_singleword_source ; }
      bool subsumes(const ChartArc *other) const ;
      FrList *sourceAlignments() const ;
      size_t numSuccessors() const { return m_numsuccessors ; }
      size_t numSubsumedArcs() const { return m_numsubsumed ; }
      ChartArcSuccessor *successor(size_t N) const
	 { return (N < numSuccessors()) ? &m_successors[N] : 0 ; }
      ChartArc *successorArc(size_t N) const
	 { return (N < numSuccessors()) ? m_successors[N].arc() : 0 ; }

      static ChartEntryType allocateArcType(FrSymbol *tag) ;
      static void freeArcTypes() ;
      static unsigned numArcTypes() ;
      static size_t maxEngines() ;
   } ;

/************************************************************************/
/************************************************************************/

class TargetWord
   {
   private:
      static FrAllocator allocator ;
      static FrAllocator *s_IDallocator ;
      static size_t s_num_models ;
   private:
      const FrSymbol *m_name ;
      ChartArc *source_arc ;
      uint16_t *source_words ;
      LmWordID_t **m_IDs ;
      const FrSymbol *m_match_class ;	// restriction on gap-filling
      LmFeatureVector m_features ;
      unsigned m_refcount ;		// how many pointers to this instance?
      unsigned m_gapfiller ;		// source location of filler if gap
      bool     m_gapmarker ;		// is this word a gap marker?
   public: // methods
      void *operator new(size_t) { return allocator.allocate() ; }
      void operator delete(void *blk) { allocator.release(blk) ; }
      static void initIDAllocator(size_t num_models) ;
      static void freeIDAllocator() ;
      void init(LmWordID_t **ids,const FrSymbol *nm,ChartArc *arc,
		const FrSymbol *cl = 0) ;
      void init(LmNGramModel **models, FrSymbol *nm, ChartArc *arc,
		FrSymbol *cl = 0) ;
      void init(LmNGramModel **models, FrSymbol *nm, const FrList *nms, ChartArc *arc,
		FrSymbol *cl = 0) ;
      void init(const TargetWord &oldtw)
	 { init(oldtw.m_IDs,oldtw.name(),oldtw.sourceArc(),
		oldtw.matchClass()) ; }
      TargetWord(LmNGramModel **models, FrSymbol *nm, ChartArc *arc,
		 FrSymbol *cl = 0)
	 { init(models,nm,arc,cl) ; }
      TargetWord(LmNGramModel **models, FrSymbol *nm, const FrList *nms, ChartArc *arc,
		 FrSymbol *cl = 0)
	 { init(models,nm,nms,arc,cl) ; }
      TargetWord(const TargetWord &oldtw) { init(oldtw) ; }
   protected:
      ~TargetWord() { freeSourceWords() ; freeWordID() ; }
      void initFeatures(ChartArc *arc) ;
   public:
      void free() { if (m_refcount < 1 ) delete this ; }
      TargetWord &operator = (const TargetWord &oldtw)
	 { init(oldtw.m_IDs,oldtw.name(),oldtw.sourceArc()) ; return *this ; }
      void freeWordID() ;
      static void zapAll() ;

      // modifiers
      void setWordID(LmNGramModel **models, FrSymbol *nm) ;
      void setWordID(LmNGramModel **models, const FrList *nms) ;
      void setWordID(LmNGramModel *model, const char *word) ;
      void setSourceWords(size_t first, size_t last) ;
      void setSourceWords(const FrList *locations) ;
      void setMatchClass(FrSymbol *cl, bool override = false)
	 { if (override || !m_match_class) m_match_class = cl ; }
      void freeSourceWords() ;
      static void setModelCount(size_t num_models)
	 { initIDAllocator(num_models) ; }
      void setFillerLocation(size_t arc_start) ;
      void addReference() { m_refcount++ ; }
      void removeReference() { if (m_refcount > 0) m_refcount-- ; }

      // accessors
      static size_t numModels() { return s_num_models ; }
      bool haveIDs() const { return m_IDs != 0 ; }
      bool isGapMarker() const { return m_gapmarker ; }
      bool isEmbeddedGapMarker() const ;
      LmWordID_t ID(size_t N, size_t C) const { return m_IDs[N][C] ; }
      LmWordID_t ID(size_t N) const { return m_IDs[N][1] ; }
      size_t IDcount(size_t N) const { return m_IDs[N][0] ; }
      const LmWordID_t * const *IDs() const { return m_IDs ; }
      LmWordID_t *IDs(size_t N) const { return m_IDs[N] ; }
      const FrSymbol *name() const { return m_name ; }
      const FrSymbol *matchClass() const { return m_match_class ; }
      ChartArc *sourceArc() const { return source_arc ; }
      const WordInfo *sourceWord() const
	 { return source_arc->sourceWordInfo() ; }
      const FrSymbol *nthWord(int n) const { return source_arc->nthWord(n) ; }
      bool isOOV(size_t N = 0) const { return ID(N) <= 0 ; }
      const uint16_t *sourceWords() const { return source_words ; }
      FrList *sourceAlignment() const ;
      const LmFeatureVector *features() const { return &m_features ; }
      LmFeatureVector *features() { return &m_features ; }
      size_t gapFillerLocation() const { return m_gapfiller ; }

      // feature accessors
      double weight() const
	 { return m_features.value(featureID_arcweight) ; }
      double score() const
	 { return m_features.value(featureID_score) ; }
      double quality() const
	 { return m_features.value(featureID_quality) ; }
      double chunkingBonus() const
	 { return m_features.value(featureID_chunking) ; }
      double untransPenalty() const
         { return m_features.value(featureID_untrans) ; }

      // feature modifiers
      void setWeight(double wt)
         { m_features.setValue(featureID_arcweight,wt) ; }
      void incrWeight(double wt)
         { m_features.incrValue(featureID_arcweight,wt) ; }
      void setChunkingBonus(double cb)
         { m_features.setValue(featureID_chunking,cb) ; }
      void incrChunkingBonus(double cb)
         { m_features.incrValue(featureID_chunking,cb) ; }
      void setUntransPenalty(double ut)
         { m_features.setValue(featureID_untrans,ut) ; }
      void incrUntransPenalty(double ut)
         { m_features.incrValue(featureID_untrans,ut) ; }
   } ;

/************************************************************************/
/************************************************************************/

class TargetWordRef
   {
   private:
      static FrAllocator *s_prob_allocator ;
      static size_t      s_num_models ;
      TargetWord        *m_targetword ;
      float	        *m_probabilities ;
      LmNGramLengthMask  m_ngramlengths ;
      float 	         m_avgngram ;
      unsigned 	         m_coverage ;
   protected:
      void allocProbabilities() ;
      void freeProbabilities() ;
   public:
      void init(TargetWord *tword, const ChartArc *arc, size_t cover = 1) ;
      void init(TargetWord *tword, size_t cover) ;
      void init(const ChartArc *arc) ;
      void init(const TargetWordRef &orig) ;
      void reinit(const TargetWordRef &orig) ;
      TargetWordRef(TargetWord *tword, size_t cover = 1)
	 { init(tword,cover) ; }
      TargetWordRef(TargetWord *tword, const ChartArc *arc, size_t cover = 1)
	 { init(tword,arc,cover) ; }
      ~TargetWordRef() { destroy() ; }
      void destroy()
	 { if (m_targetword) m_targetword->removeReference() ;
	   freeProbabilities() ; }

      // accessors
      TargetWord *targetWord() const { return m_targetword ; }
      bool probabilityKnown() const
	 { return m_probabilities[s_num_models] < LmINVALID_PROB ; }
      float probability(size_t N) const { return m_probabilities[N] ; }
      float probability() const { return m_probabilities[s_num_models] ; }
      float avgNgram() const { return m_avgngram ; }
      size_t coverage() const { return m_coverage ; }
      size_t maxNgram() const { return m_ngramlengths.maxLength() ; }
      const LmNGramLengthMask &ngramMask() const { return m_ngramlengths ; }
      bool ngramMatched(size_t N) const
	 { return m_ngramlengths.lengthExisted(N) ; }
      const LmWordID_t * const *IDs() const
	 { return targetWord() ? targetWord()->IDs() : 0; }
      LmWordID_t *IDs(size_t N) const
	 { return targetWord() ? targetWord()->IDs(N) : 0; }
      LmWordID_t ID(size_t N) const
	 { return targetWord()? targetWord()->ID(N) : LmVOCAB_WORD_NOT_FOUND; }
      LmWordID_t ID(size_t N, size_t C) const
	 { return targetWord() ? targetWord()->ID(N,C) : LmVOCAB_WORD_NOT_FOUND ; }
      size_t IDcount(size_t N) const
	 { return targetWord()? targetWord()->IDcount(N) : 0 ; }
      const FrSymbol *name() const
	 { return targetWord() ? targetWord()->name() : 0 ; }
      const ChartArc *sourceArc() const
	 { return targetWord() ? targetWord()->sourceArc() : 0 ; }
      bool isGapMarker() const
	 { return targetWord() ? targetWord()->isGapMarker() : false ; }

      // modifiers
      void setWord(TargetWord *tword)
	 { if (m_targetword) m_targetword->removeReference() ;
	   m_targetword = tword ; if (tword) tword->addReference() ; }
      void setCoverage(size_t cover) { m_coverage = (unsigned)cover ; }
      void setProbabilities(const TargetWordRef &orig) ;
      void setProbability(size_t N, double prob)
	 { m_probabilities[N] = (float)prob ; }
      void setProbability(size_t N, float prob) { m_probabilities[N] = prob ; }
      void setProbability(double prob)
	 { m_probabilities[s_num_models] = (float)prob ; }
      void setProbability(float prob)
	 { m_probabilities[s_num_models] = prob ; }
      void setAvgNgram(double avg) { m_avgngram = (float)avg ; }
      void setAvgNgram(float avg) { m_avgngram = avg ; }
      void clearNgramLengths() { m_ngramlengths.clear() ; }
      void addNgramLength(size_t N) { m_ngramlengths.addLength(N) ; }
      void invalidateProbability()
	 { m_probabilities[s_num_models] = LmINVALID_PROB ; }
      void addCover(const TargetWordRef *other) ;

      // memory management
      static void setModelCount(size_t num_models)
	 { initProbAllocator(num_models) ; }
      static void initProbAllocator(size_t num_models) ;
      static void freeProbAllocator() ;
   } ;

inline void TargetWordRef::addCover(const TargetWordRef *other)
{
   if (other)
      m_coverage += other->coverage() ; 
   return ;
}

/************************************************************************/
/************************************************************************/

class TargetWordList : public FrObject
   {
   private:
      int          numwords ;
      size_t	   m_numarcs ;
      TargetWord   **wordlist ;
      const ChartArc **m_arcs ;
      LmNGramModel **m_models ;
   public:
      TargetWordList(const TargetWord * const *words,int num,
		     LmNGramModel **models) ;
      TargetWordList(const TargetWordRef *words,int num,
		     LmNGramModel **models) ;
      virtual ~TargetWordList() ;
      virtual void freeObject() ;
      virtual size_t length() const ;
      virtual ostream &printValue(ostream &output) const ;
      virtual char *displayValue(char *buffer) const ;
      virtual size_t displayLength() const ;

      // accessors
      size_t twlLength() const { return numwords ; }
      TargetWord *wordN(int N) const { return wordlist[N] ; }
      TargetWord **words() const { return wordlist ; }
      size_t numArcs() const { return m_numarcs ; }
      const ChartArc *arc(size_t N) const
	 { return (N < m_numarcs) ? m_arcs[N] : 0 ; }
      LmNGramModel * const *models() const { return m_models ; }
      const TargetWord *operator [] (int N) const
	{ return (N >= 0 && N < numwords) ? wordlist[N] : 0 ; }

      // modifiers
      void addArcs(const ComponentArcInfo *arcs, size_t numarcs) ;
      bool removeWord(size_t N) ;
      void updateLength(int newlen) { numwords = newlen ; }
   } ;

/************************************************************************/
/************************************************************************/

ostream &dump_arc_list(ostream &out, TargetWordList *) ;
void dump_arc_info(ostream &out, const ChartArc *arc) ;

void LmMergeTargetWords(TargetWordRef merged[], size_t wordcount,
			const TargetWordRef oldtw[], size_t prev,
			const TargetWordRef newtw[],
			size_t new_start, size_t new_end,
			BFSNode *node, LmUSHORT &OOV_count) ;
#endif /* !__LMARCS_H_INCLUDED */

// end of file lmarcs.h //
