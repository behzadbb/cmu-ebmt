/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmbfs.h	best-first search				*/
/*  LastEdit: 06apr10							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __LMBFS_H_INCLUDED
#define __LMBFS_H_INCLUDED

#include "FramepaC.h"
#include "lmbitset.h"
#include "lmfeat.h"
#include "lmngram.h"
#include "lmsetup.h"
#include "lmodel.h"
#include "lmglobal.h"

/************************************************************************/
/*	Manifest Constants						*/
/************************************************************************/

#define WORD_ALLOC_BINS 	16
#define WORD_ALLOC_STEP		4

#define MAX_USER_SCORES	 	9

/************************************************************************/
/************************************************************************/

class ChartArc ;
class ComponentArcInfo ;
class ParseChart ;
class PriorityQueue ;
class TargetWord ;
class TargetWordRef ;
class LmNGramModel ;

/************************************************************************/
/************************************************************************/

class BestFirstSearch
   {
   private:
      static FrAllocator allocator ;
      PriorityQueue **m_queue ;
      long int m_totalnodes, nodes_expanded ;
      size_t m_substacks ;
      size_t m_jigsawstacks ;
      size_t m_numpruned ;
      size_t m_inputlength ;
      size_t m_activestack ;
   private: // methods
      FrList *finalize(BFSNode *node) ;
   public: // methods
      void *operator new(size_t) { return allocator.allocate() ; }
      void operator delete(void *blk) { allocator.release(blk) ; }
      BestFirstSearch(BFSNode *node, size_t nbest_list_size = 1,
		      size_t max_refills = 1) ;
      ~BestFirstSearch() ;
      bool addNode(BFSNode *node) ;
      void insertNodes(BFSNode *nodes) ;
      BFSNode *peek() ;
      BFSNode *pop() ;
      bool refillQueues(bool unlimit_beam = false,
			size_t num_remaining = 0) ;
      bool search() ;
      FrList *popBestResult() ;

      // accessors
      size_t inputLength() const { return m_inputlength ; }
      size_t activeStack() const { return m_activestack ; }
      size_t nextActiveStack() const ;
      size_t totalStacks() const ;
      size_t finalStack() const ;
      size_t queueInputCover(size_t stacknum) const ;
      size_t activeQueueLength() ;
      size_t finalStackLength() const ;
      BFSNode *extractActiveStack(size_t &queuelen) ;
      int maxNodes() const ;
      int currNodes() const ;
      size_t nodesPruned() const { return m_numpruned ; }
      long int totalNodes() const { return m_totalnodes ; }
      long int expandedNodes() const { return nodes_expanded ; }
      size_t queueNumber(const BFSNode *node) const ;
      PriorityQueue *queue(const BFSNode *node) const
	 { return m_queue[queueNumber(node)] ; }
      PriorityQueue *queue(size_t qnum) const
	 { return m_queue[qnum] ; }

      // threading statistics
      size_t totalUncontested() const ;
      size_t totalCollisions() const ;
      ostream &collisionStatistics(ostream &out) const ;
      ostream &cs() const ; // collisionStatistics(cerr)
   } ;

/************************************************************************/
/************************************************************************/

extern class BestFirstSearch *lm_active_search ;

class BFSNode
   {
   private:
      static FrAllocator allocator ;
      static FrAllocator *cover_allocator ;
      static FrAllocator **word_allocators ;
      BFSNode *right_node ;
      BFSNode *left_node ;
      ParseChart *chart ;
      TargetWordRef *m_words ;
      ComponentArcInfo *arcs ;		// which arcs have been combined?
      LmBitFlags *m_covered ;		// which words of input are covered?
      LmNGramStates m_modelstates ;
      LmFeatureVector m_features ;
      double m_score ;			// actual score for determining best
      LmUSHORT m_twordalloc ;		// alloc size for 'words'
      LmUSHORT m_numwords ;		// number of words in target so far
      LmUSHORT m_coverage ;		// number of input words covered so far
      LmUSHORT numarcs ;		// number of arcs combined
      LmUSHORT m_activearc ;		// which arc is to be extended next?
      LmUSHORT m_bytecover ;		// number of input bytes covered so far
      LmUSHORT m_bytelength ;		// number of output bytes so far
      LmUSHORT num_gap_markers ;	// number of gap words to be replaced
      LmUSHORT num_gaps_filled ;	// number of gap words already replaced
      LmUSHORT num_gaps_discarded ;	// number of unfilled gaps we skipped
      LmUSHORT arc_reorderings ;
   private: // methods
      static void copyNodeInfo(BFSNode *dest, const BFSNode *oldnode) ;
      void initHistories(LmNGramModel **,size_t maxhist) ;
      bool allocCovered(const LmBitFlags *init = 0) ;// get space for 'covered'
      void freeCovered() ;
      void allocTargetWords() ;		// allocate storage for 'm_words'
      void freeTargetWords() ;
      bool removeGapMarkers(bool force = false) ; // false if embedded gaps
      void setDiscountedScore(const LmFeatureVector *weights) ;
      double futureUtility() ;
      double futureUtilityMoses() ;
      void updateNodeInfo(size_t prevwords, const ChartArc *arc,
			  size_t chartlength, const LmFeatureVector *weights,
			  size_t reordering, size_t src_overlap,
			  size_t trg_overlap) ;
      BFSNode *makeExpandedNode(const ChartArc *arc, const ParseChart *chart,
				size_t reordering, size_t src_cover,
				size_t src_overlap, size_t trg_overlap,
				BFSNode *nodelist = 0) const ;
   public: // methods
      void *operator new(size_t) { return allocator.allocate() ; }
      void operator delete(void *blk) { allocator.release(blk) ; }
      BFSNode(ParseChart *parsechart) ;
      BFSNode(const BFSNode *oldnode) ;
      BFSNode(const BFSNode *oldnode,size_t cover,size_t wordcount,
	      const ChartArc *new_arc, const ParseChart *chart,
	      size_t overlap = 0) ;
      ~BFSNode() ;
      BFSNode *nconc(BFSNode *more) ;
      BFSNode *expand(bool must_fill_gap = false) ;
      void usedArcs(const BFSNode *prev_node, const ChartArc *new_arc,
		    size_t overlap, size_t trgposition) ;

      int compareNode(const BFSNode *node) const ;
      bool sameTranslation(const BFSNode *node) const ;
      bool sameCoverage(const BFSNode *node) const ;
      bool canCoverRemainder() const ;
      bool complete() const ;
      bool good() const { return coveredInput() != 0 && m_words != 0 ; }
      void *value() const ;
      void *optionalInfo() const ;
      FrList *scoreInfo() const ;

      size_t targetOverlap(const ChartArc *arc, size_t src_overlap = 0) const ;
      bool arcAlreadyUsed(const ChartArc *arc) const ;

      // manipulation functions
      void setLeft(BFSNode *leftnode) { left_node = leftnode ; }
      void setRight(BFSNode *rightnode) { right_node = rightnode ; }
      void setNext(BFSNode *nextnode) { right_node = nextnode ; }
      BFSNode *makeSortedList() ; // destroys the Treap rooted at 'this'!
      BFSNode *sortListByScore() ;
      void setActiveArc(size_t N) { m_activearc = (LmUSHORT)N ; }
      void updateActiveArc(size_t last_target) ;
      bool nextActiveArc() ; // -> true if a longer arc at same pos exists
      void adjustTargetPositions(size_t *map) ;

      void setOOVs(size_t OOV) { m_features.setValue(featureID_OOV,OOV) ; }
      void pathCount(double count)
	 { m_features.setValue(featureID_multipath,count) ; }
      void incrPathCount(double incr = 1.0)
	 { m_features.incrValue(featureID_multipath,incr) ; }
      void incrGapMarkers(size_t count = 1)
	 { num_gap_markers += (LmUSHORT)count ; }
      void decrGapMarkers(size_t count = 1)
	 { num_gap_markers -= (LmUSHORT)count ; }
      void gapFilled(size_t count = 1) { num_gaps_filled += (LmUSHORT)count ; }
      void gapDiscarded(size_t count = 1)
	 { num_gaps_discarded += (LmUSHORT)count ; }
      void adjustByteLength(size_t adj) { m_bytelength += adj ; }
      void clearNgramLengths() ;
      void addNgramLength(size_t N, size_t count = 1) ;
      void addNgramLengths(const class LmNGramLengthMask &mask) ;

      // access to internal state
      BFSNode *left() const { return left_node ; }
      BFSNode **leftPtr() { return &left_node ; }
      BFSNode *right() const { return right_node ; }
      BFSNode **rightPtr() { return &right_node ; }
      BFSNode *next() const { return right_node ; }
      const LmNGramStates *modelStates() const { return &m_modelstates ; }
      LmNGramStates *modelStates() { return &m_modelstates ; }
      double score() const { return m_score ; }
      double overlapBonus() const
	 { return m_features.value(featureID_overlap) ; }
      size_t inputLength() const ;
      size_t outputLength() const { return m_numwords ; }
      size_t inputCoverage() const { return m_coverage ; }
      size_t numArcs() const { return numarcs ; }
      size_t activeArc() const { return m_activearc ; }
      size_t byteCover() const { return m_bytecover ; }
      size_t byteLength() const { return m_bytelength ; }
      double pathCount() const
	 { return m_features.value(featureID_multipath) ; }
      size_t gapsFilled() const { return num_gaps_filled ; }
      size_t gapsDiscarded() const { return num_gaps_discarded ; }
      size_t gapMarkers() const { return num_gap_markers ; }
      size_t gapInCoverage() const ; // do we need to fill anything we skipped?
      size_t futureReordering() const ;
      size_t numOOVs() const
	 { return (size_t)m_features.value(featureID_OOV) ; }
      const ComponentArcInfo *usedArcs() const { return arcs ; }
      const ChartArc *lastArcUsed() const ;
      size_t lastArcPosition() const ;
      size_t lastArcEnd() const ;
      bool lastArcSubsumed() const ;
      bool isQuestion() const ;
      ParseChart *getParseChart() const { return chart ; }
      const TargetWordRef *wordList() const { return m_words ; }
      FrSymbol *outputWord(size_t N) const ;
      bool inputCovered(size_t N) const
	 { if (N < inputLength())
	    { const LmBitFlags *cov = coveredInput() ;
	      return (cov ? LmGetBit(cov,N) : true) ; }
	   else return false ; }
      const LmBitFlags *coveredInput() const
	 { if (inputLength() > CHAR_BIT * sizeof(LmBitFlags*))
	   return m_covered ; 
	   else { return reinterpret_cast<const LmBitFlags*>(&m_covered) ; } }
      LmBitFlags *coveredInputMod()
	 { if (inputLength() > CHAR_BIT * sizeof(LmBitFlags*))
	   return m_covered ; 
	   else { return reinterpret_cast<LmBitFlags*>(&m_covered) ; } }
      size_t coverageEntries() const
	 { return (inputLength()+LM_BITS_PER_ENTRY-1) / LM_BITS_PER_ENTRY ; }
      size_t arcReorderings() const { return arc_reorderings ; }
      static int compare(const BFSNode &n1, const BFSNode &n2)
	 {
	 size_t q1 = lm_active_search->queueNumber(&n1) ;
	 size_t q2 = lm_active_search->queueNumber(&n2) ;
	 if (q1 < q2) return -1 ;
	 else if (q1 > q2) return +1 ;
	 double dif = n1.score() - n2.score() ;
	 return (dif>0.0 ? -1 : (dif<0.0 ? +1 : 0)) ; 
	 }

      // debugging support
      bool inTree(const BFSNode *node) const ;
      void dumpArcs(ostream &) const ;
      void dumpArcs() const ; // use cout
      void dumpActiveArc(ostream &) const ;
      void dumpActiveArc() const ; // use cout
      void showCoverage(ostream &) const ;
      void showCoverage() const ; // use cout
      void showUsedArcs(ostream &) const ;
      void showUsedArcs() const ; // use cout
      static size_t numNodesAlloc()
	 { return (allocator.objects_allocated()
		   - allocator.freelist_length()) ; }
      static size_t numNodeAllocs()
	 { return allocator.requests_made() ; }

      // memory management
      static bool newCoverAllocator(size_t input_length) ;
      static void deleteCoverAllocator() ;
      static bool newWordAllocators() ;
      static void deleteWordAllocators() ;
   } ;

/************************************************************************/
/************************************************************************/

#endif /* !__LMBFS_H_INCLUDED */

// end of lmbfs.h //
