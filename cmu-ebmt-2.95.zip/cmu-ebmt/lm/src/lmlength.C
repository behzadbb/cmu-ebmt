/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmlength.cpp		sentence-length model			*/
/*  LastEdit: 13apr10							*/
/*									*/
/*  (c) Copyright 2010 Ralf Brown					*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "FramepaC.h"
#include "lmlength.h"

/************************************************************************/
/*	Global Variables						*/
/************************************************************************/

static LmLengthModel *length_model = 0 ;

/************************************************************************/
/*	Methods for class LmLengthDistribution				*/
/************************************************************************/

double LmLengthDistribution::brevity(size_t input, double output) const
{
   double expected = input * m_ratio ;
   if (output >= expected)
      return 0.0 ;
   if (output == 0)
      return expected / m_shortdev ;
   double brev = (expected / output) - 1.0 ;
   return brev / m_shortdev ;
}

//----------------------------------------------------------------------

double LmLengthDistribution::verbosity(size_t input, double output) const
{
   double expected = input * m_ratio ;
   if (output <= expected)
      return 0.0 ;
   double verb = (output / expected) - 1.0 ;
   return verb / m_longdev ;
}

//----------------------------------------------------------------------

double LmLengthDistribution::gaussian(size_t input, double output) const
{
   double expected = input * m_ratio ;
   double stddev = (output < expected) ? m_shortdev : m_longdev ;
   return FrMath::gaussianProbability(output,expected,stddev) ;
}

/************************************************************************/
/*	Methods for class LmLengthModel					*/
/************************************************************************/

LmLengthModel::LmLengthModel()
{
   m_bytemodel[1].init(1.0,1.0,1.0) ;
   m_wordmodel[1].init(1.0,1.0,1.0) ;
   m_longestmodel = 1 ;
   m_bytebias = 1.0 ;
   m_wordbias = 1.0 ;
   m_OK = true ;
   return ;
}

//----------------------------------------------------------------------

LmLengthModel::LmLengthModel(const char *filename)
{
   FILE *fp = fopen(filename,"r") ;
   if (load(fp))
      {
      interpolateDistributions(m_bytemodel) ;
      interpolateDistributions(m_wordmodel) ;
      m_OK = true ;
      }
   else
      {
      m_bytemodel[1].init(1.0,1.0,1.0) ;
      m_wordmodel[1].init(1.0,1.0,1.0) ;
      m_longestmodel = 1 ;
      m_OK = false ;
      }
   if (fp)
      fclose(fp) ;
   m_bytebias = 1.0 ;
   m_wordbias = 1.0 ;
   return ;
}

//----------------------------------------------------------------------

bool LmLengthModel::load(FILE *fp)
{
   m_longestmodel = 0 ;
   while (fp && !feof(fp))
      {
      char line[FrMAX_LINE] ;
      if (!fgets(line,sizeof(line),fp))
	 break ;
      char *cur_ptr = line ;
      if (FrSkipWhitespace(cur_ptr) == '#')
	 continue ;  // comment line
      // parse the input line into seven values:
      //   inputlen byteratio b-short b-long wordratio w-short w-long
      char *end_ptr ;
      size_t inlen = strtol(cur_ptr,&end_ptr,0) ;
      if (end_ptr == cur_ptr)
	 {
	 cerr << "invalid line in length model: " << cur_ptr << endl ;
	 continue ;
	 }
      cur_ptr = end_ptr + 1 ;
      if (inlen < 1 || inlen >= lengthof(m_bytemodel))
	 {
	 cerr << "invalid input length " << inlen << " in length model"
	      << endl ;
	 continue ;
	 }
      double values[6] ;
      bool good_line = true ;
      for (size_t i = 0 ; i < lengthof(values) ; i++)
	 {
	 values[i] = strtod(cur_ptr,&end_ptr) ;
	 if (end_ptr > cur_ptr)
	    cur_ptr = end_ptr + 1 ;
	 else
	    {
	    cerr << "too few values on length model line (expected " 
		 << lengthof(values) << ")" << endl ;
	    good_line = false ;
	    break ;
	    }
	 }
      if (good_line)
	 {
	 if (inlen + 1 < lengthof(m_bytemodel))
	    {
	    m_bytemodel[inlen].init(values[0],values[1],values[2]) ;
	    m_wordmodel[inlen].init(values[3],values[4],values[5]) ;
	    }
	 else
	    {
	    inlen = lengthof(m_bytemodel) - 1 ;
	    if (m_longestmodel < inlen)
	       {
	       m_bytemodel[inlen].init(values[0],values[1],values[2]) ;
	       m_wordmodel[inlen].init(values[3],values[4],values[5]) ;
	       }
	    else
	       {
//FIXME
	       }
	    }
	 if (inlen > m_longestmodel)
	    m_longestmodel = inlen ;
	 }
      }
   return m_longestmodel > 0 ;
}

//----------------------------------------------------------------------

static double interpolate(double low, double high, size_t first, size_t cur,
			  size_t last)
{
   size_t range = (last - first) ;
   double weight_lo = (last - cur - 1) / (double)range ;
   double weight_hi = (cur - first) / (double)range ;
   return weight_lo * low + weight_hi * high ;
}

//----------------------------------------------------------------------

void LmLengthModel::interpolateDistributions(LmLengthDistribution *models)
{
   for (size_t i = 1 ; i < m_longestmodel ; i++)
      {
      if (models[i].expectedRatio() > 0.0)
	 continue ;
      for (size_t j = i + 1 ; j <= m_longestmodel ; j++)
	 {
	 if (models[j].expectedRatio() > 0.0)
	    {
	    // we now have lower and upper bounds of the range of lengths
	    //   without information, so do a linear interpolation of the
	    //   two endpoints
	    size_t lo = i - 1 ;
	    double low_ratio = lo ? models[lo].expectedRatio() : 1.0 ;
	    double low_short = lo ? models[lo].shortDeviation() : 1.0 ;
	    double low_long = lo ? models[lo].longDeviation() : 1.0 ;
	    double high_ratio = models[j].expectedRatio() ;
	    double high_short = models[j].shortDeviation() ;
	    double high_long = models[j].longDeviation() ;
	    for (size_t k = i ; k < j ; k++)
	       {
	       double ratio = interpolate(low_ratio,high_ratio,lo,k,j) ;
	       double s = interpolate(low_short,high_short,lo,k,j) ;
	       double l = interpolate(low_long,high_long,lo,k,j) ;
	       models[k].init(ratio,s,l) ;
	       }
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

double LmLengthModel::expectedLengthWords(size_t srcwords) const
{
   if (srcwords > m_longestmodel)
      srcwords = m_longestmodel ;
   double target = srcwords * m_wordmodel[srcwords].expectedRatio() ;
   return target * lengthBiasWord() ;
}

//----------------------------------------------------------------------

double LmLengthModel::expectedLengthBytes(size_t srcwords, size_t srcbytes)
const
{
   if (srcwords > m_longestmodel)
      srcwords = m_longestmodel ;
   double target = srcbytes * m_bytemodel[srcwords].expectedRatio() ;
   return target * lengthBiasByte() ;
}

//----------------------------------------------------------------------

double LmLengthModel::brevityByte(size_t input, double ratio) const
{
   size_t len = input ;
   if (len > m_longestmodel)
      len = m_longestmodel ;
   return m_bytemodel[len].brevity(input,ratio * input / m_bytebias) ;
}

//----------------------------------------------------------------------

double LmLengthModel::brevityWord(size_t input, double output) const
{
   size_t len = input ;
   if (len > m_longestmodel)
      len = m_longestmodel ;
   return m_wordmodel[len].brevity(input,output / m_wordbias) ;
}

//----------------------------------------------------------------------

double LmLengthModel::verbosityByte(size_t input, double ratio) const
{
   size_t len = input ;
   if (len > m_longestmodel)
      len = m_longestmodel ;
   return m_bytemodel[len].verbosity(input,ratio * input / m_bytebias) ;
}

//----------------------------------------------------------------------

double LmLengthModel::verbosityWord(size_t input, double output) const
{
   size_t len = input ;
   if (len > m_longestmodel)
      len = m_longestmodel ;
   return m_wordmodel[len].verbosity(input,output / m_wordbias) ;
}

//----------------------------------------------------------------------

double LmLengthModel::gaussianByte(size_t input, double ratio) const
{
   size_t len = input ;
   if (len > m_longestmodel)
      len = m_longestmodel ;
   return m_bytemodel[len].gaussian(input,ratio * input / m_bytebias) ;
}

//----------------------------------------------------------------------

double LmLengthModel::gaussianWord(size_t input, double output) const
{
   size_t len = input ;
   if (len > m_longestmodel)
      len = m_longestmodel ;
   return m_wordmodel[len].gaussian(input,output / m_wordbias) ;
}

/************************************************************************/
/************************************************************************/

bool LmInitLengthModel(const char *filename)
{
   delete length_model;
   if (filename && *filename)
      length_model = new LmLengthModel(filename) ;
   else
      length_model = new LmLengthModel ;
   return length_model && length_model->OK() ;
}

//----------------------------------------------------------------------

void LmFreeLengthModel()
{
   delete length_model ;
   length_model = 0 ;
   return ;
}

//----------------------------------------------------------------------

void LmSetLengthBias(double byte_bias, double word_bias)
{
   if (length_model)
      {
      length_model->setLengthBiasByte(byte_bias) ;
      length_model->setLengthBiasWord(word_bias) ;
      }
   return ;
}

//----------------------------------------------------------------------

const LmLengthModel *LmActiveLengthModel()
{
   return length_model ;
}

// end of file lmlength.C //
