/************************************************************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmstems.C	    word-stem support				*/
/*  LastEdit: 04nov09    						*/
/*									*/
/*  (c) Copyright 2006,2007,2008,2009 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "lmodel.h"
#include "lmglobal.h"

/************************************************************************/
/************************************************************************/

bool LmLoadWordStems(const char *stemsfile)
{
   LmUnloadWordStems() ;
   if (stemsfile && *stemsfile)
      {
      bool piped ;
      FILE *fp = FrOpenMaybeCompressedInfile(stemsfile,piped) ;
      if (fp)
	 {
	 wordstem_ht = new FrSymHashTable(1000) ;
	 if (!wordstem_ht)
	    {
	    fclose(fp) ;
	    FrNoMemory("while loading word stems") ;
	    return false ;
	    }
	 FrSymbol *symEOF = FrSymbolTable::add("*EOF*") ;
	 size_t warned = 0 ;
	 while (!feof(fp) && !ferror(fp))
	    {
	    char buf[FrMAX_LINE] ;
	    if (!fgets(buf,sizeof(buf),fp))
	       break ;
	    char *line = buf ;
	    FrObject *obj1 = string_to_FrObject(line) ;
	    FrObject *obj2 = string_to_FrObject(line) ;
	    if (obj1 != symEOF && obj2 != symEOF)
	       {
	       const char *word1 = FrPrintableName(obj1) ;
	       const char *word2 = FrPrintableName(obj2) ;
	       if (word1 && word2)
		  wordstem_ht->add(FrSymbolTable::add(word1),
				   FrSymbolTable::add(word2)) ;
	       else if (warned < 10)
		  {
		  line = FrTrimWhitespace(buf) ;
		  cout << "; bad entry in stems file: " << line << endl ;
		  warned++ ;
		  }
	       }
	    free_object(obj1) ;
	    free_object(obj2) ;
	    }
	 FrCloseMaybeCompressedInfile(fp,piped) ;
	 if (wordstem_ht->currentSize() > 0)
	    return true ;
	 }
      else
	 {
	 FrWarningVA("unable to open file '%s' to load word stems",stemsfile);
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

bool LmUnloadWordStems()
{
   if (wordstem_ht)
      {
      delete wordstem_ht ;
      wordstem_ht = 0 ;
      }
   return true ;
}

// end of file lmstems.cpp //
