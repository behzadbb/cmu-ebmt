/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmglobal.h	    Language Modeler's global variables		*/
/*  LastEdit: 20apr10    						*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,1999,2000,2001,2002,2003	*/
/*		2004,2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __LMGLOBAL_H_INCLUDED
#define __LMGLOBAL_H_INCLUDED

#ifndef __LMGENRE_H_INCLUDED
#include "lmgenre.h"
#endif

#ifndef __LMNGRAM_H_INCLUDED
#include "lmngram.h"
#endif

/************************************************************************/
/************************************************************************/

#define TRACE(level,cmd) if (lm_vars._trace >= level) cmd ;
#define VTRACE(level,cmd) if (verbose && lm_vars._trace >= level) cmd ;

#ifdef NDEBUG
#  define NTRACE(level,cmd)
#  define NVTRACE(level,cmd)
#else
#  define NTRACE(level,cmd) if (lm_vars._trace >= level) { cmd ; }
#  define NVTRACE(level,cmd) if (verbose && lm_vars._trace >= level) { cmd ; }
#endif

#ifdef NO_LM_STATS
#define INCR_STATS(which)
#define INCR_STATS_N(which,count)
#else
#define INCR_STATS(which) 		(stats__##which++)
#define INCR_STATS_N(which,count) 	(stats__##which += (count))
#endif

#define LM_EPSILON_MARKER "<epsilon>"

#define MIN_FUTURE_SCORE -100.0f

/************************************************************************/
/* 	Shared Global Variables						*/
/************************************************************************/

class LMConfig ;
class TriggerWords ;
class LmNGramModel ;
class LMConfig ;

class LMGlobalVariables
   {
   public:
      LmGenreSettings *genre_list ;
      LmGenreSettings *genre ;
      LmGenreSettings *previous_genre ;
      FrList *_genre_names ;
      FrList *_engine_names ;
      FrList *_model_IDs ;
      FrThreadPool *_thread_pool ;

      double _feature_offset ;
      double _discount_mass ;
      char *_dummy_arc_contents ;
      char *_epsilon_arc_contents ;
      char *_wordstems_filename ;
      char *_length_model_filename ;
      FrSymbol *_symMORPH ;
      FrSymbol *_symNIL ;
      FrSymbol *_symSTRING ;
      FrSymbol *_symEPSILON ;
      FrSymbol *_symLEXICAL ;
      FrSymbol *_sym_empty ;
      FrList *_skip_raw_scores ;
      LmNGramModel **_ngrams ;
      LMConfig *_lm_config ;		// default configuration read from file
      FrSymHashTable *_wordstem_ht ;
      size_t _language_model_count ;
      size_t _best_count ;
      size_t _nbest_timeout ;
      int _LM_port_number ;
      int _rare_words_threshold ;
      size_t _trace ;
      size_t _LM_reach ;

      unsigned _featureID_brevity_b ;
      unsigned _featureID_brevity_w ;
      unsigned _featureID_verbosity_b ;
      unsigned _featureID_verbosity_w ;
      unsigned _featureID_length_b ;
      unsigned _featureID_length_w ;
      unsigned _featureID_wordcount ;
      unsigned _featureID_chunking ;
      unsigned _featureID_length2bonus ;
      unsigned _featureID_length3bonus ;
      unsigned _featureID_length4bonus ;
      unsigned _featureID_length5bonus ;
      unsigned _featureID_length6bonus ;
      unsigned _featureID_lengthplusbonus ;
      unsigned _featureID_untrans ;
      unsigned _featureID_arcweight ;
      unsigned _featureID_agreement ;
      unsigned _featureID_quality ;
      unsigned _featureID_score ;
      unsigned _featureID_reordering ;
      unsigned _featureID_reordering2 ; // square of reordering count
      unsigned _featureID_reorderpunct ;
      unsigned _featureID_reorderpunctEOS ;
      unsigned _featureID_interleave ;
      unsigned _featureID_gaps ;
      unsigned _featureID_ngramlength ;
      unsigned _featureID_ngram1 ;
      unsigned _featureID_ngram2 ;
      unsigned _featureID_ngram3 ;
      unsigned _featureID_ngram4 ;
      unsigned _featureID_ngram5 ;
      unsigned _featureID_ngram6 ;
      unsigned _featureID_ngramlong ;
      unsigned _featureID_OOV ;
      unsigned _featureID_nulltrans ;
      unsigned _featureID_numarcs ;
      unsigned _featureID_overlap ;
      unsigned _featureID_reinforcement ;
      unsigned _featureID_multipath ;
      unsigned _featureID_future ;
      unsigned _featureID_langmodel ;

      bool _Unicode_bswap ;
      bool _canonicalized_input_data ;
      bool _use_context_cues ;
      bool _use_joint_probabilities ;
      bool _internal_nbest ;
      bool _guarantee_nbest ;
      bool _moses_style_scoring ;
      bool _ignore_prepdoc_command ;
      bool _allow_memmapped_model ;
      bool _verbose ;
      bool _run_quietly ;
      bool _remove_accents ;
      bool _fuzzy_match ;
      bool _auto_rare ;
      bool _ignore_case ;
      bool _char_based_model ;
      bool _model_includes_spaces ;
      bool _adjust_class_probs ;
      bool _use_word_stems ;
      bool _complete_arc_overrides_partial ;
      bool _reorder_window_is_uncovered ;
      bool _use_multiple_stacks ;
      bool _ignore_source_morphology ;
      bool _preparing_for_document ;
      bool _allow_jigsaw_combination ;
      bool _question_particle_hack ;
      bool _generate_chart ;
      bool _prettyprint_output ;
      bool _show_origins ;
      bool _show_metadata ;
      bool _touch_all_memory ;
      bool _show_coverage ;
      bool _show_overlap_stats ;
      bool _show_search_stats ;
      bool _strict_gap_filler ;
      bool _show_raw_scores ;
      bool _raw_scores_in_CMERT_format ;
      bool _raw_scores_in_ZMERT_format ;
      bool _raw_scores_in_Cunei_format ;

      uint8_t _build_affix_sizes ;

      FrCharEncoding _char_encoding ;
      const unsigned char *_uppercase_table ;
      const unsigned char *_lowercase_table ;
      FrNamedEntitySpec *_named_entity_spec ;

      // stack-refilling control
      size_t _stack_refill_topN ;

      // chart-parsing control
      size_t _predecode_max_arcs ;
      size_t _predecode_max_len ;
      double _predecode_cutoff ;

      // statistics
      size_t _attempted_expansions ;
      size_t _expansion_collisions ;
      size_t _unable_to_cover ;
      size_t _unfillable_gaps ;
      size_t _successful_expansions ;
      size_t _reordered_expansions ;
      size_t _overlap_expansions ;
      size_t _interleaved_expansions ;
      size_t _dups_removed ;
      size_t _beam_exceeded ;
      size_t _never_inserted ;
      size_t _reorderings_used ;
      size_t _interleaves_used ;
      size_t _total_nodes_expanded ;
      size_t _total_ngram_probs ;
      size_t _total_avg_ngram ;
      size_t _total_sentences ;
   public:
      LMGlobalVariables() ;
      LMGlobalVariables(const LMGlobalVariables &) ;
      ~LMGlobalVariables() ;

      void freeVariables() ;

      bool applyConfiguration(const LMConfig *config) ;
      LMGlobalVariables *select() ;
   } ;

extern LMGlobalVariables lm_vars ;
extern FrFeatureVectorMap LMfeature_map ;

#define thread_pool		lm_vars._thread_pool
#define ignore_case		lm_vars._ignore_case
#define build_affix_sizes	lm_vars._build_affix_sizes
#define char_based_model	lm_vars._char_based_model
#define model_includes_spaces	lm_vars._model_includes_spaces
#define adjust_class_probs	lm_vars._adjust_class_probs
#define rare_words_threshold	lm_vars._rare_words_threshold
#define use_word_stems		lm_vars._use_word_stems
#define complete_arc_overrides_partial	lm_vars._complete_arc_overrides_partial
#define reorder_window_is_uncovered	lm_vars._reorder_window_is_uncovered
#define use_multiple_stacks	lm_vars._use_multiple_stacks
#define trace			lm_vars._trace
#define verbose			lm_vars._verbose
#define Unicode_bswap		lm_vars._Unicode_bswap
#define char_encoding		lm_vars._char_encoding
#define uppercase_table		lm_vars._uppercase_table
#define lowercase_table		lm_vars._lowercase_table
#define canonicalized_input_data	lm_vars._canonicalized_input_data

#define LM_genre_names		lm_vars._genre_names
#define LM_engine_names		lm_vars._engine_names
#define LM_model_IDs		lm_vars._model_IDs
#define named_entity_spec	lm_vars._named_entity_spec

#define use_context_cues	lm_vars._use_context_cues
#define use_joint_probabilities	lm_vars._use_joint_probabilities
#define internal_nbest		lm_vars._internal_nbest
#define guarantee_nbest		lm_vars._guarantee_nbest
#define moses_style_scoring	lm_vars._moses_style_scoring
#define ignore_prepdoc_command	lm_vars._ignore_prepdoc_command
#define run_LM_quietly		lm_vars._run_quietly

#define	symMORPH		lm_vars._symMORPH
#define symNIL			lm_vars._symNIL
#define symSTRING		lm_vars._symSTRING
#define symEPSILON		lm_vars._symEPSILON
#define symLEXICAL		lm_vars._symLEXICAL
#define sym_empty		lm_vars._sym_empty

#define remove_accents		lm_vars._remove_accents
#define fuzzy_match		lm_vars._fuzzy_match
#define auto_rare		lm_vars._auto_rare
#define beam_width		lm_vars.genre->_beam_width
#define beam_ratio		lm_vars.genre->_beam_ratio

#define ignore_source_morphology lm_vars._ignore_source_morphology
#define strict_gap_filler	lm_vars._strict_gap_filler

#define show_raw_scores		lm_vars._show_raw_scores
#define raw_scores_in_CMERT_format lm_vars._raw_scores_in_CMERT_format
#define raw_scores_in_ZMERT_format lm_vars._raw_scores_in_ZMERT_format
#define raw_scores_in_Cunei_format lm_vars._raw_scores_in_Cunei_format
#define skip_raw_scores		lm_vars._skip_raw_scores
#define allow_jigsaw_combination lm_vars._allow_jigsaw_combination
#define question_particle_hack	lm_vars._question_particle_hack
#define LM_reach		lm_vars._LM_reach

#define feature_offset		lm_vars._feature_offset
#define discount_mass		lm_vars._discount_mass

#define genre_feature_weights	lm_vars.genre->_feature_weights

#define featureID_chunking	lm_vars._featureID_chunking
#define featureID_length2bonus	lm_vars._featureID_length2bonus
#define featureID_length3bonus	lm_vars._featureID_length3bonus
#define featureID_length4bonus	lm_vars._featureID_length4bonus
#define featureID_length5bonus	lm_vars._featureID_length5bonus
#define featureID_length6bonus	lm_vars._featureID_length6bonus
#define featureID_lengthplusbonus	lm_vars._featureID_lengthplusbonus
#define featureID_untrans	lm_vars._featureID_untrans
#define featureID_arcweight	lm_vars._featureID_arcweight
#define featureID_agreement	lm_vars._featureID_agreement
#define featureID_quality	lm_vars._featureID_quality
#define featureID_score		lm_vars._featureID_score
#define featureID_reordering	lm_vars._featureID_reordering
#define featureID_reordering2	lm_vars._featureID_reordering2
#define featureID_reorderpunct	lm_vars._featureID_reorderpunct
#define featureID_reorderpunctEOS lm_vars._featureID_reorderpunctEOS
#define featureID_interleave	lm_vars._featureID_interleave
#define featureID_gaps		lm_vars._featureID_gaps
#define featureID_future	lm_vars._featureID_future
#define featureID_ngramlength	lm_vars._featureID_ngramlength
#define featureID_ngram1	lm_vars._featureID_ngram1
#define featureID_ngram2	lm_vars._featureID_ngram2
#define featureID_ngram3	lm_vars._featureID_ngram3
#define featureID_ngram4	lm_vars._featureID_ngram4
#define featureID_ngram5	lm_vars._featureID_ngram5
#define featureID_ngram6	lm_vars._featureID_ngram6
#define featureID_ngramlong	lm_vars._featureID_ngramlong
#define featureID_brevity_b	lm_vars._featureID_brevity_b
#define featureID_brevity_w	lm_vars._featureID_brevity_w
#define featureID_verbosity_b	lm_vars._featureID_verbosity_b
#define featureID_verbosity_w	lm_vars._featureID_verbosity_w
#define featureID_length_b	lm_vars._featureID_length_b
#define featureID_length_w	lm_vars._featureID_length_w
#define featureID_wordcount	lm_vars._featureID_wordcount 
#define featureID_OOV		lm_vars._featureID_OOV
#define featureID_nulltrans	lm_vars._featureID_nulltrans
#define featureID_numarcs	lm_vars._featureID_numarcs
#define featureID_overlap	lm_vars._featureID_overlap
#define featureID_reinforcement	lm_vars._featureID_reinforcement
#define featureID_multipath	lm_vars._featureID_multipath
#define featureID_langmodel	lm_vars._featureID_langmodel

#define wordstems_filename	lm_vars._wordstems_filename
#define length_model_filename	lm_vars._length_model_filename

#define best_count		lm_vars._best_count
#define nbest_timeout		lm_vars._nbest_timeout
#define generate_chart		lm_vars._generate_chart
#define prettyprint_output	lm_vars._prettyprint_output
#define show_origins		lm_vars._show_origins
#define show_metadata		lm_vars._show_metadata
#define LM_port_number		lm_vars._LM_port_number
#define language_model_count	lm_vars._language_model_count

#define max_ngram_length	lm_vars.genre->_max_ngram_length

#define max_reorder_window	lm_vars.genre->_max_reorder_window

#define length_bias_byte	lm_vars.genre->_length_bias_byte
#define length_bias_word	lm_vars.genre->_length_bias_word

#define max_source_overlap	lm_vars.genre->_max_source_overlap
#define max_overlap_diff	lm_vars.genre->_max_overlap_diff

#define untrans_prefix		lm_vars.genre->_untrans_prefix
#define untrans_suffix		lm_vars.genre->_untrans_suffix
#define dummy_arc_contents	lm_vars._dummy_arc_contents
#define epsilon_arc_contents	lm_vars._epsilon_arc_contents

#define allow_memmapped_model	lm_vars._allow_memmapped_model
#define touch_all_memory	lm_vars._touch_all_memory
#define show_coverage		lm_vars._show_coverage
#define show_overlap_stats	lm_vars._show_overlap_stats
#define show_search_stats	lm_vars._show_search_stats

#define lm_config		lm_vars._lm_config
#define LM_ngrams		lm_vars._ngrams
#define wordstem_ht		lm_vars._wordstem_ht

#define LM_scale_factor		lm_vars.genre->_LM_scale_factor
#define LM_scale_adjust		lm_vars.genre->_LM_scale_adjust
#define source_cover_power	lm_vars.genre->_source_cover_power

#define preparing_for_document	lm_vars._preparing_for_document

#define stack_refill_topN	lm_vars._stack_refill_topN

#define predecode_cutoff	lm_vars._predecode_cutoff
#define predecode_max_arcs	lm_vars._predecode_max_arcs
#define predecode_max_len	lm_vars._predecode_max_len

#define stats__attempted_node_expansions lm_vars._attempted_expansions
#define stats__expansion_collisions      lm_vars._expansion_collisions
#define stats__unable_to_cover		 lm_vars._unable_to_cover
#define stats__unfillable_gaps		 lm_vars._unfillable_gaps
#define stats__successful_expansions     lm_vars._successful_expansions
#define stats__reordered_expansions      lm_vars._reordered_expansions
#define stats__overlap_expansions	 lm_vars._overlap_expansions
#define stats__interleaved_expansions	 lm_vars._interleaved_expansions
#define stats__dups_removed		 lm_vars._dups_removed
#define stats__beam_exceeded		 lm_vars._beam_exceeded
#define stats__never_inserted		 lm_vars._never_inserted
#define stats__reorderings_used		 lm_vars._reorderings_used
#define stats__interleaves_used		 lm_vars._interleaves_used
#define stats__total_nodes_expanded	 lm_vars._total_nodes_expanded
#define stats__total_ngram_probs	 lm_vars._total_ngram_probs
#define stats__total_avg_ngram		 lm_vars._total_avg_ngram
#define total_sentences			 lm_vars._total_sentences

//----------------------------------------------------------------------

extern int LM_trace ;

void LmSetCharEncoding(const char *char_enc) ;

#endif /* !__LMGLOBAL_H_INCLUDED */

// end of file lmglobal.h //
