/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Language Modeler -- configuration file parser			*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmconfig.C							*/
/*  LastEdit: 20apr10							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,1999,2000,2001,2002,2003	*/
/*		2004,2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "lmconfig.h"
#include "lmlength.h"
#include "lmngram.h"
#include "lmglobal.h"

#ifdef FrSTRICT_CPLUSPLUS
# include <cmath>
# include <string>
# include <fstream>
#else
# include <fstream.h>
# include <math.h>		// some systems need this for log()
# include <string.h>
#endif /* FrSTRICT_CPLUSPLUS */

bool LmLoadWordStems(const char *stemsfile) ;
double LmSetScaleFactor(const FrList*) ;

//-----------------------------------------------------------------------
//  the parsing information for the language modeler configuration

#undef addr
static MTEngineConfig *dummy_MTConfig = 0 ;
#define addr(x) (void*)((char*)(&dummy_MTConfig->x) - (char*)dummy_MTConfig)

#undef fn
#define fn(x) ((FrConfigVariableType)(x))

static FrCommandBit engine_options[] =
   {
    { "DISABLE",	ENGINE_IGNORE_ARCS,	false, "Ignore any arcs from this engine." } ,
    { "FULLSENT",	ENGINE_FULLSENT_ONLY,	false, "Engine only generates translations of the full input sentence." },
    { 0,		0,			false, "" }
   } ;

FrConfigurationTable MTEngineConfig::engine_def[] =
   {
      // keyword	parse func    storage location		settability
      //	next    extra-arg	default  	min	max
      //	description
    { "Max-Alts",      integer,      addr(max_alts),		FrSET_ANYTIME,
		0,	0,		"0",	"0",	"100",
		"Number of top-scoring alternatives from an engine to use for each span of input.  Default of 0 means no limit." },
    { "Max-Alts1",      integer,      addr(max_alts1),		FrSET_ANYTIME,
		0,	0,		"0",	"0",	"100",
		"Number of top-scoring alternatives from an engine to use for each span of input if engine indicates a single-word source (no whitespace in arc's source text).  Default of 0 means to use the value set by Max-Alts:" },
    { "Name",		cstring,	addr(name),		FrSET_STARTUP,
		0,	0,		0,	0,	0,
		"The user-friendly name of the engine." },
    { "Options",	bitflags,  addr(options),       	FrSET_ANYTIME,
		0, engine_options,	0,	0,	0,
		"" },
    { "Overrides",	  list,      addr(overrides),     	FrSET_STARTUP,
		0,	0,		0,	0,	0,
		"" },
    { "Threshold-Score",  real,      addr(threshold),		FrSET_STARTUP,
		0,	0,		"0.0",	0,	0,
		"" },
    { "Total-Override",	  list,      addr(total_overrides),	FrSET_STARTUP,
		0,	0,		0,	0,	0,
		"" },
    { "Untrans-Penalty",  real,      addr(untrans_penalty),	FrSET_STARTUP,
		0,	0,		"0.9",	"0.0",	0,
		"" },
    { "",		  invalid,   	0,		       	FrSET_READONLY,
		0,	0,		0,	0,	0,
		"" },
      // what to do if we reach EOF
    { 0,		  invalid,	0,			FrSET_READONLY,
		0,	0,		0,	0,	0,
		"" }
   } ;

//----------------------------------------------------------------------

#undef addr
static LModelConfig *dummy_LModelConfig = 0 ;
#define addr(x) (void*)((char*)(&dummy_LModelConfig->x) - (char*)dummy_LModelConfig)

FrConfigurationTable LModelConfig::model_def[] =
   {
      // keyword	parse func    storage location		settability
      //	next    extra-arg	default  	min	max
      //	description
    { "Context-Weight",	  real,      	addr(context_weight),  	FrSET_ANYTIME,
		0,	0,		"1.0",	0,	0,
		"Relative context-based weight of this language model." },
    { "Discount-Mass",	  real,         addr(discount),	       	FrSET_ANYTIME,
		0,	0,		"0.001",	"0.0",	"1.0",
		"" },
    { "Fallback",	list,		addr(fallbacks),	FrSET_STARTUP,
		0,	0,		0,	0,	0,
	  	"List of the order in which to fall back from one sequence to another for any missing words in a given token sequence, e.g. (SPANS POS LEXICAL) (RESTRICT LEXICAL)" },
    { "Longest-NGram",	cardinal,	addr(max_ngram),	FrSET_ANYTIME,
		0,	0,		"4",	"0",	"99",
		"" },
    { "Model-File",	filename,	addr(modelfile),	FrSET_STARTUP,
		0,	0,		0,	0,	0,
		"Name of the file containing the language model" },
    { "Sequences",	list,		addr(sequences),	FrSET_STARTUP,
		0,	0,		"LEXICAL",	0,	0,
		"Names of word sequences to be used for this model, in priority order (e.g. RESTRICT LEXICAL)" },
    { "Smoothing-Type",	  symbol,       addr(smoothing_name),	FrSET_ANYTIME,
		0,	0,		"SIMPLE_KN",	0,	0,
      		"How to smooth/interpolate probabilities in the language model (MEAN, MAX, or SIMPLE_KN [default])" },
    { "Source-Model",	filename,	addr(sourcemodel),	FrSET_STARTUP,
		0,	0,		0,	0,	0,
		"Name of the file containing a language model for corresponding source text (used in dynamically weighting multiple models)." },
    { "Weight",		real,		addr(weight),		FrSET_ANYTIME,
		0,	0,		"1.0",	0,	0,
		"Relative weight of this language model." },
    { "",		  invalid,   	0,		       	FrSET_READONLY,
		0,	0,		0,	0,	0,
		"" },
      // what to do if we reach EOF
    { 0,		  invalid,	0,			FrSET_READONLY,
		0,	0,		0,	0,	0,
		"" }
   } ;

//----------------------------------------------------------------------

static FrCommandBit lm_options[] =
   {
    { "FUZZYMATCH",	LM_FUZZY_MATCH,		false,	"" },
    { "AUTO_RARE",	LM_AUTO_RARE,		false,  "automatically convert any unknown words to <rare> if the language model contains that class" },
    { "JIGSAW",		LM_JIGSAW,		false,	"" },
    { "MORPH",		LM_MORPHOLOGY,		true,	"" },
    { "IGNORECASE",	LM_IGNORE_CASE,		true,	"" },
    { "STEMS",		LM_STEM_WORDS,		false,	"Apply Stem-Words file to all words prior to looking up probabilities" },
    { "QUIET",		LM_RUN_QUIETLY,		false,	"" },
    { "QUESPARTICLE",	LM_QUESTION_PARTICLE,	false,	"language has a question particle which implies that the translation should end with a question mark" },
    { "MMAP",		LM_MMAP,		true,	"" },
    { "TOUCHMEM",	LM_TOUCHMEM,		false,	"" },
    { "KEEP_PARTIAL",	LM_KEEP_PARTIAL,	false,	"" },
    { "REORDER_UNCOV",	LM_REORDER_UNCOVERED,	false,	"allow any preceding arc to fill an open gap in the path, not just those within the reordering window (but still limits total gaps to the size of the reordering window)" },
    { "STRICT_GAPFILL",	LM_STRICT_GAPFILL,	false,	"" },
    { "MULTISTACK",	LM_MULTISTACK,		true,   "" },
    // for compatibility with other MEMT engines
    { "VERBOSE",	0,			false,	"" },
    // obsolete options
    { 0,        	0,			false,	"" }
   } ;

static FrCommandBit lm_outopts[] =
   {
    { "SHOWCOVERAGE",	LM_SHOWCOVERAGE,	false,	"" },
    { "SHOWOVERLAP",	LM_SHOWOVERLAP,		false,	"" },
    { "SHOWSEARCH",	LM_SHOWSEARCH,		false,	"" },
    { "SHOWMETADATA",	LM_SHOWMETADATA,	false,	"" },
    { "ORIGINS",	LM_SHOW_ORIGINS,	false,	"" } ,
    { "ACCENTS",	LM_KEEP_ACCENTS,	true,	"" } ,
    { "GENCHART",	LM_GENERATE_CHART,	false,	"" },
    { "PRETTYPRINT",	LM_PRETTYPRINT,		true,	"Apply some prettifying postprocessing to string output." },
    { "MOSES_MERT",	LM_MOSES_MERT,		false,	"dump raw scores in MOSES CMERT format instead of OptimizeNBest format" },
    { "ZMERT",		LM_ZMERT,		false,	"dump raw scores in Joshua ZMERT format instead of OptimizeNBest format" },
    { "CUNEI",		LM_CUNEI,		false,	"dump raw scores in Cunei optimizer format instead of OptimizeNBest format" },
    { 0,        	0,	 		false,	"" }
   } ;

static FrCommandBit lm_sc_opts[] =
   {
    { "ADJ_CLASSPROB",	LM_ADJPROBS,		true,	"adjust conditional probabilities of class members by their relative unigram frequency" },
    { "JOINT_PROB",	LM_JOINTPROB,		true,	"use joint probabilities instead of conditional probabilities" },
    { "FRAGMENTS",	LM_FRAGMENTS,		false,	"skip begin/end-sentence context cues (useful for translating ASR output)" },
    { "CHECK_NBEST",	LM_CHECK_NBEST,		false,  "internally generate 5-best list and pick best-scoring item to output as the translation when Num-Translations=1" },
    { "GUARANTEE_NBEST", LM_GUARANTEE_NBEST,	true,  "When generating an n-best list (Num-Translations>1 or +CHECK_NBEST), retain enough pruned nodes to guarantee that the top N are actually found; when disabled, use less memory at the risk of missing some of the translations that should have been on the n-best list." },
    { "MOSES",		LM_MOSES,		false, "use MOSES-style scoring during decoding" },
    { "IGNORE_PREPDOC",	LM_IGNORE_PREPDOC,	false, "don't change LM context weights on PREPDOC command" },
    { 0,        	0,	 		false, "" }
   } ;

//----------------------------------------------------------------------

#undef addr
static LMConfig *dummy_LMConfig = 0 ;
#define addr(x) (void*)((char*)(&dummy_LMConfig->x) - (char*)dummy_LMConfig)

FrConfigurationTable LMConfig::LM_def[] =
   {
      // keyword	parse func    location		    next    extra-arg
    { "Base-Directory",   basedir,    0,                      	FrSET_STARTUP,
		0,	0,		0,	0,	0,
		"" },
    { "Beam-Width",       cardinal,   addr(genre._beam_width),	FrSET_ANYTIME,
		0,       0,		"80",	"2",	"10000000",
		"" },
    { "Beam-Ratio",       real,	      addr(genre._beam_ratio),	FrSET_ANYTIME,
		0,       0,		"10",	"1.1",	"999999999",
		"" },
    { "Char-Encoding",	  cstring,    addr(char_enc),	       	FrSET_STARTUP,
		0,	0,		"Latin-1",	0,	0,
		"Name of the character encoding used by all input and output" },
    { "Discount-Mass",	  real,       &discount_mass,	       	FrSET_STARTUP,
		0,	0,		"0.001",	"0.0",	"1.0",
		"" },
    { "Dummy-Arc",	  cstring,    &dummy_arc_contents,     	FrSET_ANYTIME,
		0,	0,		"<epsilon>",	0,	0,
		"" },
    { "Epsilon-Arc",	  cstring,    &epsilon_arc_contents,   	FrSET_ANYTIME,
		0,	0,		"=",	0,	0,
		"" },
    { "Engines",	   list,      &LM_engine_names,		FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"List of engines with individual setups" },
    { "Feature-Offset",	real,	      &feature_offset,		FrSET_ANYTIME,
      		0,	0,	"0",		"-1",		"1",
      		"" },
    { "Genres",		   list,      &LM_genre_names,		FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"List of genres with individual setups for the GENRE command" },
    { "Length-Model",	filename,     &length_model_filename,	FrSET_STARTUP,
      		0,	0,	"",		0,		0,
      		"Name of the file containing the sentence-length model" },
    { "Length-Bias-Byte",  real, addr(genre._length_bias_byte), FrSET_ANYTIME,
		0,	0,		"1.0",	"0.00001", "10.0",
		"Expected ratio between source and target sentence lengths.  By using extremely small values, Verbosity-Penalty can emulate a simple length penalty." },
    { "Length-Bias-Word", real, addr(genre._length_bias_word), FrSET_ANYTIME,
		0,	0,		"1.0",	"0.00001", "10.0",
		"Expected ratio between source and target sentence lengths.  By using extremely small values, Verbosity-Penalty can emulate a simple length penalty." },
    { "LM-Scale-Pivot",   real,  addr(genre._LM_scale_adjust),  FrSET_ANYTIME,
		0,	0,		"0.01",	"0.0",	"1.0",
		"" },
    { "Longest-NGram",	  cardinal,addr(genre._max_ngram_length),FrSET_ANYTIME,
		0,	0,		"3",	"0",	"99",
		"" },
    { "Max-Overlap-Diff", real,  addr(genre._max_overlap_diff), FrSET_ANYTIME,
		0,	0,		"0.0",	"0.0",	"100.0",
		"" },
    { "Max-Src-Overlap",  cardinal, addr(genre._max_source_overlap), FrSET_ANYTIME,
		0,	0,		"2",	"0",	"100",
		"" },
    { "Max-Threads",	  cardinal,   addr(maxthreads),    	FrSET_STARTUP,
		0, 	0,		"0",	"0",	"16",
		"Maximum number of parallel worker threads to use (0=disable multi-threading entirely)" },
    { "Models", 	   list,      &LM_model_IDs,		FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"List of language models with individual setups in sections [LM-%%s]" },
    { "NBest-Timeout",	cardinal,	&nbest_timeout,		FrSET_ANYTIME,
		0,	0,		"600",	"1",	"7200",
		"" },
    { "NE-Spec",	cstring,	addr(ne_spec),		FrSET_ANYTIME,
     		0,	0,	0,		0,		0,
	   	"Format specification for tagged named entities, e.g. @%%c{%%s#%%t#%%p}" },
    { "Num-Translations", integer,    &best_count,	 	FrSET_ANYTIME,
		0,	0,		"1",	"1",	"10000",
		"" },
    { "Options",	  bitflags,   addr(options),	       	FrSET_ANYTIME,
		0, lm_options,		0,	0,	0,
		"" },
    { "Output-Options",	  bitflags,   addr(output_options),   	FrSET_ANYTIME,
		0, lm_outopts,		0,	0,	0,
		"" },
    { "PreDecode-Cutoff", real,  	&predecode_cutoff,	FrSET_ANYTIME,
		0,	0,		"0.01",	"0.00",	"0.999",
		"Threshold for relative score (relative to maximal-scoring arc) of composite arcs generated during the chart decoding phase to be kept." },
    { "PreDecode-Len",  cardinal,  	&predecode_max_len,	FrSET_ANYTIME,
		0,	0,		"1",	"1",	"99",
		"Maximum length of arcs to create during the chart decoding phase" },
    { "PreDecode-MaxArcs", cardinal,  &predecode_max_arcs,	FrSET_ANYTIME,
		0,	0,		"1",	"1",	"9",
		"Maximum number of arcs to combine into one during the chart decoding phase" },
    { "Refill-TopN",  cardinal,  	&stack_refill_topN,	FrSET_ANYTIME,
		0,	0,		"5",	"1",	"100",
                "Refill stacks for each of the first Refill-TopN translations when generating an n-best list." },
    { "Reorder-Window",	  cardinal, addr(genre._max_reorder_window), FrSET_ANYTIME,
		0,	0,		"3",	"1",	"10",
		"" },
    { "Score-Options",	  bitflags,   addr(score_options),    	FrSET_ANYTIME,
		0, lm_sc_opts,		0,	0,	0,
		"" },
    { "Skip-Raw-Scores",  list,		&skip_raw_scores,	FrSET_STARTUP,
		0,	0,		0,	0,	0,
		"Names of parameters whose corresponding scores should not be output when -r is specified on the command line." },
    { "Socket-Number",	  integer,    &LM_port_number,	       	FrSET_STARTUP,
		0,	0,		"0",	"0",	"65535",
		"" },
    { "Source-Cover-Power", real,addr(genre._source_cover_power),FrSET_ANYTIME,
		0,	0,		"2.0",	"0.0",	"15.0",
		"When computing overall source-language coverage, raise the length of each match to this power." },
    { "Stats-Attempted-Expansions", cardinal, &stats__attempted_node_expansions, FrSET_READONLY,
		0,	0,		"0",	0,	0,
		"" },
    { "Stats-Exp-Collisions", cardinal, &stats__expansion_collisions, FrSET_READONLY,
		0,	0,		"0",	0,	0,
		"" },
    { "Stats-Unable-To-Cover", cardinal, &stats__unable_to_cover, FrSET_READONLY,
		0,	0,		"0",	0,	0,
		"" },
    { "Stats-Unfillable-Gaps", cardinal, &stats__unfillable_gaps, FrSET_READONLY,
		0,	0,		"0",	0,	0,
		"" },
    { "Stats-Good-Expansions", cardinal, &stats__successful_expansions, FrSET_READONLY,
		0,	0,		"0",	0,	0,
		"" },
    { "Stats-Interleaved-Expansions", cardinal, &stats__interleaved_expansions, FrSET_READONLY,
		0,	0,		"0",	0,	0,
		"" },
    { "Stats-Interleaves-Used", cardinal, &stats__interleaves_used,FrSET_READONLY,
		0,	0,		0,	0,	0,
		"" },
    { "Stats-Reordered-Expansions", cardinal, &stats__reordered_expansions, FrSET_READONLY,
		0,	0,		"0",	0,	0,
		"" },
    { "Stats-Overlap-Expansions", cardinal, &stats__overlap_expansions, FrSET_READONLY,
		0,	0,		"0",	0,	0,
		"" },
    { "Stats-Dups-Removed", cardinal, &stats__dups_removed, 	FrSET_READONLY,
		0,	0,		"0",	0,	0,
		"" },
    { "Stats-Beam-Exceeded", cardinal, &stats__beam_exceeded, 	FrSET_READONLY,
		0,	0,		"0",	0,	0,
		"" },
    { "Stats-Never-Inserted", cardinal, &stats__never_inserted, FrSET_READONLY,
		0,	0,		"0",	0,	0,
		"" },
    { "Stats-Reorders-Used", cardinal, &stats__reorderings_used,FrSET_READONLY,
		0,	0,		"0",	0,	0,
		"" },
    { "Stats-Total-Expanded", cardinal, &stats__total_nodes_expanded, FrSET_READONLY,
		0,	0,		"0",	0,	0,
		"" },
    { "Stats-Total-NGram-Probs", cardinal, &stats__total_ngram_probs, FrSET_READONLY,
		0,	0,		"0",	0,	0,
		"" },
    { "Stats-Avg-NGram-Match", cardinal, &stats__total_avg_ngram, FrSET_READONLY,
		0,	0,		"0",	0,	0,
		"" },
    { "Trace-Level",    cardinal,   	&trace, 	  	FrSET_ANYTIME,
		0,      0,		0,	0,	0,
		"How verbose should debugging output be?  (Levels above 4 vary depending on whether the program was compiled with NDEBUG or not)" },
    { "Untrans-Prefix",	  cstring, addr(genre._untrans_prefix),	FrSET_ANYTIME,
		0,	0,		0,	0,	0,
		"String to insert just before an untranslated word." },
    { "Untrans-Suffix",	  cstring, addr(genre._untrans_suffix),	FrSET_ANYTIME,
		0,	0,		0,	0,	0,
		"String to insert just after an untranslated word." },
    { "WordStems-File", filename,   &wordstems_filename,  	FrSET_ANYTIME,
		0,	0,		0,	0,	0,
		"Name of a file containing a list of words and the corresponding stems which are to be used for language modeling (one pair per line).  Also enable Options: STEMS to actually use this file." },
    { "",		  invalid,    0,		       	FrSET_READONLY,
		0,	0,		0,	0,	0,
		"" },
      // what to do if we reach EOF
    { 0,                  invalid,       0,		       	FrSET_READONLY,
		0,	0,		0,	0,	0,
		"" }
   } ;


/************************************************************************/
/************************************************************************/

void LMConfig::init()
{
   FrConfiguration::init() ;
   engines = 0 ;
   models = 0 ;
   return ;
}

//-----------------------------------------------------------------------

void LMConfig::resetState()
{
   curr_state = LM_def ;
   return ;
}

//-----------------------------------------------------------------------

size_t LMConfig::lastLocalVar() const
{
   return (size_t)((char*)(&this->last_local_var) - (char*)this) ;
}

//----------------------------------------------------------------------

size_t LMConfig::maxUserType() const
{
   return user+1 ;
}

//-----------------------------------------------------------------------

bool LMConfig::onRead(FrConfigVariableType, void *where)
{
   if (where == 0)
      {}
#define UPDATE_GENRE(x) else if (where == &genre._##x) { genre._##x = x ; }
#define UPDATE_GENRE_STR(x) else if (where == &genre._##x) { FrFree(x) ; x = FrDupString(genre._##x) ; }
   UPDATE_GENRE(max_ngram_length)
   UPDATE_GENRE_STR(untrans_prefix)
   UPDATE_GENRE_STR(untrans_suffix)
   UPDATE_GENRE(max_overlap_diff)
   UPDATE_GENRE(LM_scale_adjust)
   UPDATE_GENRE(length_bias_byte)
   UPDATE_GENRE(length_bias_word)
   UPDATE_GENRE(beam_width)
   UPDATE_GENRE(beam_ratio)
   UPDATE_GENRE(max_source_overlap)
   UPDATE_GENRE(max_reorder_window)
   UPDATE_GENRE(source_cover_power)
#undef UPDATE_GENRE
   return true ;
}

//-----------------------------------------------------------------------

bool LMConfig::onChange(FrConfigVariableType /*vartype*/, void *where)
{
   if (where == &options)
      {
      allow_jigsaw_combination = (options & LM_JIGSAW) != 0 ;
      ignore_case = (options & LM_IGNORE_CASE) != 0 ;
      use_word_stems = (options & LM_STEM_WORDS) != 0 ;
      ignore_source_morphology = (options & LM_MORPHOLOGY) == 0 ;
      complete_arc_overrides_partial = (options & LM_KEEP_PARTIAL) == 0 ;
      reorder_window_is_uncovered = (options & LM_REORDER_UNCOVERED) != 0 ;
      use_multiple_stacks = (options & LM_MULTISTACK) != 0 ;
      strict_gap_filler = (options & LM_STRICT_GAPFILL) != 0 ;
      run_LM_quietly = (options & LM_RUN_QUIETLY) != 0 ;
      question_particle_hack = (options & LM_QUESTION_PARTICLE) != 0 ;
      fuzzy_match = (options & LM_FUZZY_MATCH) != 0 ;
      auto_rare = (options & LM_AUTO_RARE) != 0 ;
      allow_memmapped_model = (options & LM_MMAP) != 0 ;
      touch_all_memory = (options & LM_TOUCHMEM) != 0 ;
      }
   else if (where == &score_options)
      {
      use_joint_probabilities = (score_options & LM_JOINTPROB) != 0 ; 
      use_context_cues = (score_options & LM_FRAGMENTS) == 0 ;
      internal_nbest = (score_options & LM_CHECK_NBEST) != 0 ;
      guarantee_nbest = (score_options & LM_GUARANTEE_NBEST) != 0 ;
      moses_style_scoring = (score_options & LM_MOSES) != 0 ;
      ignore_prepdoc_command = (score_options & LM_IGNORE_PREPDOC) != 0 ;
      adjust_class_probs = (score_options & LM_ADJPROBS) != 0 ;
      }
   else if (where == &output_options)
      {
      show_coverage = (output_options & LM_SHOWCOVERAGE) != 0 ;
      show_overlap_stats = (output_options & LM_SHOWOVERLAP) != 0 ;
      show_search_stats = (output_options & LM_SHOWSEARCH) != 0 ;
      show_origins = (output_options & LM_SHOW_ORIGINS) != 0 ;
      show_metadata = (output_options & LM_SHOWMETADATA) != 0 ;
      remove_accents = (output_options & LM_KEEP_ACCENTS) == 0 ;
      generate_chart = (output_options & LM_GENERATE_CHART) != 0 ;
      prettyprint_output = (output_options & LM_PRETTYPRINT) != 0 ;
      raw_scores_in_CMERT_format = (output_options & LM_MOSES_MERT) != 0 ;
      raw_scores_in_ZMERT_format = (output_options & LM_ZMERT) != 0 ;
      raw_scores_in_Cunei_format = (output_options & LM_CUNEI) != 0 ;
      }
   else if (where == &char_enc)
      {
      LmSetCharEncoding(char_enc) ;
      }
   else if (where == &wordstems_filename)
      {
      LmLoadWordStems(wordstems_filename) ;
      }
   else if (where == &ne_spec)
      {
      FrFreeNamedEntitySpec(named_entity_spec) ;
      named_entity_spec = FrParseNamedEntitySpec(ne_spec,false) ;
      }
   else if (where == &length_model_filename)
      {
      LmInitLengthModel(length_model_filename) ;
      LmSetLengthBias(length_bias_byte,length_bias_word) ;
      }
#define UPDATE_GENRE(x) else if (where == &genre._##x) { x = genre._##x ; }
#define UPDATE_GENRE_STR(x) else if (where == &genre._##x) { FrFree(x) ; x = FrDupString(genre._##x) ; }
   UPDATE_GENRE(max_ngram_length)
   UPDATE_GENRE_STR(untrans_prefix)
   UPDATE_GENRE_STR(untrans_suffix)
   UPDATE_GENRE(max_overlap_diff)
   UPDATE_GENRE(LM_scale_adjust)
   UPDATE_GENRE(length_bias_byte)
   UPDATE_GENRE(length_bias_word)
   UPDATE_GENRE(beam_width)
   UPDATE_GENRE(beam_ratio)
   UPDATE_GENRE(max_source_overlap)
   UPDATE_GENRE(max_reorder_window)
   UPDATE_GENRE(source_cover_power)
#undef UPDATE_GENRE
   LmSetScaleFactor(lm_vars.genre->_feature_weights) ;
   LmSetLengthBias(length_bias_byte,length_bias_word) ;
   if (LM_scale_factor == 0.0)
      LM_reach = ~0 ;			// we need to have exact match to prune
   else
      LM_reach = max_ngram_length - 1 ;	// can ignore any diffs not seen by LM
   if (max_source_overlap > LM_reach)
      LM_reach = max_source_overlap ;
   return true ;
}

//-----------------------------------------------------------------------

LMConfig::~LMConfig()
{
   beginningShutdown() ;
   freeValues() ;
   while (engines)
      {
      MTEngineConfig *eng = engines ;
      engines = engines->next ;
      delete eng ;
      }
   while (models)
      {
      LModelConfig *tmp = models ;
      models = models->next ;
      delete tmp ;
      }
   return ;
}

//-----------------------------------------------------------------------

ostream &LMConfig::dump(ostream &output) const
{
   dumpValues("LMConfig",output) ;
   for (MTEngineConfig *engin = engines ; engin ; engin = engin->next)
      {
      output << "  Engine:           " << engin->tag << endl ;
      output << "    Threshold-Score:  " << engin->threshold << endl ;
      output << "    Untrans-Penalty:  " << engin->untrans_penalty << endl ;
      output << "  " ; // extra indent for options list
      dumpFlags("    Options:          ",engin->options,engine_options, output) ;
      }
   output << endl ;
   return output ;
}

/************************************************************************/
/************************************************************************/

MTEngineConfig::MTEngineConfig(const MTEngineConfig &eng)
  : FrConfiguration(eng)
{
   next = 0 ;
   tag = eng.tag ;
   name = FrDupString(eng.name) ;
   overrides = eng.overrides ? (FrList*)eng.overrides->deepcopy() : 0 ;
   total_overrides = eng.total_overrides
                      ? (FrList*)eng.total_overrides->deepcopy() : 0 ;
   max_alts = eng.max_alts ;
   max_alts1 = eng.max_alts1 ;
   options = eng.options ;
   untrans_penalty = eng.untrans_penalty ;
   threshold = eng.threshold ;
   return ;
}

//----------------------------------------------------------------------

MTEngineConfig::~MTEngineConfig()
{
   free_object(overrides) ;		overrides = 0 ;
   free_object(total_overrides) ;	total_overrides = 0 ;
   FrFree(name) ;			name = 0 ;
   tag = 0 ;
   init() ;				// clear everything back to defaults
   return ;
}

//----------------------------------------------------------------------

void MTEngineConfig::init()
{
   FrConfiguration::init() ;
   next = 0 ;
   tag = 0 ;
   options = 0 ;
   overrides = total_overrides = 0 ;
   max_alts = 0 ;
   max_alts1 = 0 ;
   untrans_penalty = -1.0 ;
   threshold = -1000000 ;
   return ;
}

//-----------------------------------------------------------------------

void MTEngineConfig::resetState()
{
   curr_state = engine_def ;
   return ;
}

//----------------------------------------------------------------------

size_t MTEngineConfig::maxUserType() const
{
   return user+1 ;
}

//-----------------------------------------------------------------------

size_t MTEngineConfig::lastLocalVar() const
{
   return (size_t)((char*)(&this->last_local_var) - (char*)this) ;
}

//-----------------------------------------------------------------------

bool MTEngineConfig::onChange(FrConfigVariableType /*vartype*/,
				void * /*where*/)
{
   // nothing to do yet; eventually will update engine parameters on the fly
   //   from the data fields in the MTEngineConfig
   return true ;
}

//-----------------------------------------------------------------------

ostream &MTEngineConfig::dump(ostream &output) const
{
   dumpValues("MTEngineConfig",output) ;
   return output ;
}

/************************************************************************/
/************************************************************************/

LModelConfig::LModelConfig(const char *base_directory, const char *model)
	 : FrConfiguration(base_directory)
{
   init() ;
   name = FrDupString(model) ;
   return ;
}

//----------------------------------------------------------------------

LModelConfig::~LModelConfig()
{
   freeValues() ;
   FrFree(name) ;
   return ;
}

//----------------------------------------------------------------------

void LModelConfig::init()
{
   FrConfiguration::init() ;
   next = 0 ;
   modelfile = 0 ;
   sourcemodel = 0 ;
   smoothing_name = FrSymbolTable::add("SIMPLE_KN") ;
   return ;
}

//-----------------------------------------------------------------------

void LModelConfig::resetState()
{
   curr_state = model_def ;
   return ;
}

//----------------------------------------------------------------------

size_t LModelConfig::maxUserType() const
{
   return user+1 ;
}

//-----------------------------------------------------------------------

size_t LModelConfig::lastLocalVar() const
{
   return (size_t)((char*)(&this->last_local_var) - (char*)this) ;
}

//-----------------------------------------------------------------------

bool LModelConfig::onChange(FrConfigVariableType /*vartype*/,
			    void * /*where*/)
{
   // nothing to do yet; eventually will update LM parameters on the fly
   //   from the data fields in the LModelConfig
   return true ;
}

//-----------------------------------------------------------------------

ostream &LModelConfig::dump(ostream &output) const
{
   dumpValues("LModelConfig",output) ;
   return output ;
}

/************************************************************************/
/************************************************************************/

//----------------------------------------------------------------------

static bool make_LmGenreConfig(istream &input, LMConfig *config,
				 const char *base_section, const char *genre)
{
   if (config && genre)
      {
      char *section = Fr_aprintf("%s-%s",base_section,genre) ;
      if (section)
	 {
	 lm_vars.genre = new LmGenreSettings(*lm_vars.genre, &lm_vars, genre) ;
	 bool success = config->load(input,section,false) ;
	 FrFree(section) ;
	 if (!success)
	    {
	    delete lm_vars.genre ;
	    lm_vars.genre = lm_vars.genre_list ;
	    }
	 return success ;
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

static bool make_LmEngineConfig(istream &input, LMConfig *config,
				  const char *engine)
{
   if (config && engine)
      {
      input.seekg(0) ;
      char *section = Fr_aprintf("LMEngine-%s",
				 (*engine==':') ? engine+1 : engine) ;
      if (section)
	 {
         MTEngineConfig *cfg = new MTEngineConfig ;
	 bool success ;
	 if (cfg)
	    {
	    cfg->tag = makeSymbol(engine) ;
	    success = cfg->load(input,section,false) ;
	    }
	 else
	    success = false ;
	 FrFree(section) ;
	 if (success)
	    {
	    cfg->next = config->engines ;
	    config->engines = cfg ;
	    }
	 else
	    delete cfg ;
	 return success ;
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

static bool make_LmModelConfig(istream &input, LMConfig *config,
			       const char *model)
{
   if (config && model)
      {
      input.seekg(0) ;
      char *section = Fr_aprintf("LM-%s",model) ;
      if (section)
	 {
         LModelConfig *cfg = new LModelConfig(config->baseDirectory(),model) ;
	 bool success = cfg ? cfg->load(input,section,false) : false ;
	 FrFree(section) ;
	 if (success)
	    {
	    cfg->next = config->models ;
	    config->models = cfg ;
	    }
	 else
	    delete cfg ;
	 return success ;
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

bool make_LmModelConfig(LMConfig *config, const char *model)
{
   const char *config_file = LmConfigurationFile() ;
   if (config_file)
      {
      ifstream *input = new ifstream(config_file) ;
      if (input)
	 {
	 bool success = make_LmModelConfig(*input,config,model) ;
	 input->close() ;
	 delete input ;
	 return success ;
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

LMConfig *make_LMConfig(istream &input,const char *base_directory)
{
   LMConfig *cfg = new LMConfig(base_directory) ;
   if (cfg)
      {
      const char *section = "LanguageModeler" ;
      cfg->load(input,section) ;
      if (!cfg->loadRaw(input,"LMWeights",lm_vars.genre->_feature_weights))
	 {
	 if (!run_LM_quietly)
	    FrWarning("config file missing section [LMWeights]") ;
	 }
      if (LM_genre_names)
	 {
	 input.seekg(0) ;
	 // preserve the list of genre names, which might be clobbered by
	 //   reading in the genre-specific info
	 FrList *genres = LM_genre_names ;
	 LM_genre_names = 0 ;
	 // iterate over the named genres, and try to load genre-specific
	 //   settings for each
	 for (const FrList *gn = genres ; gn ; gn = gn->rest())
	    {
	    FrObject *genre = gn->first() ;
	    if (FrPrintableName(genre))
	       {
	       if (!make_LmGenreConfig(input,cfg,section,
				       FrPrintableName(genre)))
		  cout << "Warning: no configuration section for LM genre '"
		       << FrPrintableName(genre) << "'" << endl ;
	       char *gweight_section = Fr_aprintf("LMWeights-%s",
						  FrPrintableName(genre)) ;
	       if (!cfg->loadRaw(input,gweight_section,
				 lm_vars.genre->_feature_weights))
		  {
		  if (!run_LM_quietly)
		     FrWarningVA("config file missing section [LMWeights-%s]",
				 FrPrintableName(genre)) ;
		  }
	       FrFree(gweight_section) ;
	       }
	    }
	 // restore the list of genre names
	 free_object(LM_genre_names) ;
	 LM_genre_names = genres ;
	 lm_vars.genre = LmGenreSettings::find(0) ;
	 }
      LmSetScaleFactor(lm_vars.genre->_feature_weights) ;
      if (LM_engine_names)
	 {
	 // preserve the list of engine names, which might be clobbered by
	 //   reading in the genre-specific info
	 FrList *engines = LM_engine_names ;
	 LM_engine_names = 0 ;
	 // iterate over the named engines, and try to load engine-specific
	 //   settings for each
	 for (const FrList *eng = engines ; eng ; eng = eng->rest())
	    {
	    FrObject *engine = eng->first() ;
	    if (FrPrintableName(engine))
	       {
	       if (!make_LmEngineConfig(input,cfg,FrPrintableName(engine)))
		  cout << "Warning: no configuration section for LM engine '"
		       << FrPrintableName(engine) << "'" << endl ;
	       }
	    }
	 // restore the list of engine names
	 free_object(LM_engine_names) ;
	 LM_engine_names = engines ;
	 }
      if (LM_model_IDs)
	 {
	 // preserve the list of lang-model IDs, which might be clobbered by
	 //   reading in the genre-specific info
	 FrList *IDs = LM_model_IDs ;
	 LM_model_IDs = 0 ;
	 // iterate over the specified LMs, and try to load settings for each
	 for (const FrList *lm = IDs ; lm ; lm = lm->rest())
	    {
	    FrObject *model = lm->first() ;
	    if (FrPrintableName(model))
	       {
	       if (!make_LmModelConfig(input,cfg,FrPrintableName(model)))
		  cout << "Warning: no configuration section for Language "
		          "Model '"
		       << FrPrintableName(model) << "'" << endl ;
	       }
	    }
	 // restore the list of language model IDs
	 free_object(LM_model_IDs) ;
	 LM_model_IDs = IDs ;
	 }
      }
   return cfg ;
}

// end of file lmconfig.C //
