/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmodel.h		Language Modeler			*/
/*  LastEdit: 06apr10							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,1999,2000,2001,2002,2003,	*/
/*		2004,2005,2006,2007,2008,2009 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __LMODEL_H_INCLUDED
#define __LMODEL_H_INCLUDED

#include "FramepaC.h"

#ifdef FrSTRICT_CPLUSPLUS
# include <cstdio>
# include <cstdlib>
# include <iomanip>
# include <string>
#else
# include <iomanip.h>
# include <stdio.h>
# include <stdlib.h>
# include <string.h>
#endif /* FrSTRICT_CPLUSPLUS */

/************************************************************************/
/*	Manifest constants						*/
/************************************************************************/

#define LM_VERSION_STRING "2.95"

#define LM_DUMMYARC_PENALTY	(-700.0)  // log value

/************************************************************************/
/************************************************************************/

class BFSNode ;
class LMConfig ;
class ParseChart ;
class LMGlobalVariables ;
class LmNGramModel ;
class ChartArc ;
class TargetWord ;

// select maximal precision or saving space by using either
//   FrFeatureVectorDouble or FrFeatureVectorFloat as our feature
//   vector Type
//typedef FrFeatureVectorFloat LmFeatureVector ;
typedef FrFeatureVectorDouble LmFeatureVector ;

/************************************************************************/
/************************************************************************/

class LanguageModeler
   {
   private:
      LMGlobalVariables *vars ;
      LmNGramModel **m_models ;
      FrFeatureVectorMap *m_feature_map ;  // needed by Panlite optimizer
   public:
      LanguageModeler(const char *argv0, const char *configfile,
		      bool load_model = true, bool unicode_bswap = false) ;
      ~LanguageModeler() ;

      // the actual modeling functions
      FrList *process(FrTextSpans *lattice, bool generate_walk = false,
		      ParseChart **pc = 0, bool run_gc = false,
		      size_t nbest_count = 1) ;
      void deleteParseChart(ParseChart *pc) ;
      bool prepareForDocument(bool starting) ;
      void prepareDoc(const FrTextSpans *inputlattice) ;
      void clearFeatureMap() ;
      FrList *getFeatureNames(const FrTextSpans *inputlattice) ;
      LmFeatureVector *getFeatureWeights(const FrTextSpans *inputlattice) ;
      void setFeatureWeights(const LmFeatureVector *weights) ;
      bool showRawScores(bool show) ;

      // utility functions
      void identify(ostream &out, bool as_comment = false) ;
      char *postprocess(const char *string) ;
      char *privateCommand(const char *command) ;
      bool selectGenre(const char *genre_name) ;

      // accessors
      bool good() const ;
      LmNGramModel **models() const { return m_models ; }
   } ;

//----------------------------------------------------------------------

void shutdown_LM() ;
bool LMReorderingRulesLoaded() ;
bool LMAllowReordering(bool allow) ;
void LMShowCoverage() ;			// display coverage stats, if enabled

bool LmLoadWordStems(const char *stemsfile) ;
bool LmUnloadWordStems() ;

double LmSetScaleFactor(const FrList *weights) ;
double LmSetScaleFactor(double new_scale) ;
double LmSetScaleAdjust(double new_adjust) ;

bool LmInputAlreadyCanonical(bool canon) ;

bool LmCompatibleTargetWords(const TargetWord *w1,
			       const TargetWord *w2) ;

bool LmOverlapAllowed(const ChartArc *arc1, const ChartArc *arc2,
			size_t src_overlap, size_t &trg_overlap,
			size_t maxoverlap, bool &fills_gap,
			bool *fills_gap_2 = 0) ;
size_t LmTargetOverlap(const ChartArc *arc1, const ChartArc *arc2,
		       size_t src_overlap) ;

FrList *LmWord2Chars(const char *word, bool include_spaces = false) ;

bool LmCaseSensitiveModel() ;
bool LmCaseSensitiveModel(LmNGramModel const * const *) ;

FrList *LmPrintableMetadata(const FrStruct *meta, bool show_all = false) ;

void LmUpdateOverlapStatistics(const BFSNode *finalnode) ;
void LmPrintOverlapStatistics(ostream &out) ;

void LmActiveNGrams(LmNGramModel **ngrams) ;
bool LmPrepareDocument(bool starting) ;
void LmAccumulateSourceCoverage(LmNGramModel **ngrams, const FrList *words) ;

#endif /* !__LMODEL_H_INCLUDED */

// end of file lmodel.h //



