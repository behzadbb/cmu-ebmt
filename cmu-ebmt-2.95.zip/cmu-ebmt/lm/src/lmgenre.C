/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Language Modeler -- genre support					*/
/*  Version 2.93							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmgenre.cpp							*/
/*  LastEdit: 20mar10							*/
/*									*/
/*  (c) Copyright 2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include <FramepaC.h>
#include "lmgenre.h"
#include "lmglobal.h"

/************************************************************************/
/*	Global Variables for class LmGenreSettings			*/
/************************************************************************/

/************************************************************************/
/************************************************************************/

LmGenreSettings::LmGenreSettings(LMGlobalVariables *vars, const char *genre)
{
   m_genre = FrDupString(genre) ;
   // initialize genre-specific global variables
   _feature_weights = 0 ;
   _max_source_overlap = 0 ;
   _max_ngram_length = 3 ;
   _LM_scale_factor = 1.0 ;
   _source_cover_power = 1.5 ;
   _untrans_prefix = 0 ;
   _untrans_suffix = 0 ;

   // insert the next object into the list of all genres
   link(vars) ;
   return ;
}

//----------------------------------------------------------------------

LmGenreSettings::LmGenreSettings(const LmGenreSettings &old,
				 LMGlobalVariables *vars,
				 const char *newgenre)
{
   if (!newgenre)
      newgenre = old.m_genre ;
   // copy the elements of the old structure into the new one
   memcpy(this,&old,sizeof(LmGenreSettings)) ;
   if (_feature_weights)
      _feature_weights = (FrList*)_feature_weights->deepcopy() ;
   // duplicate genre-specific variables allocated on the heap
   _untrans_prefix = FrDupString(old._untrans_prefix) ;
   _untrans_suffix = FrDupString(old._untrans_suffix) ;
   // set the new genre name
   m_genre = FrDupString(newgenre) ;
   link(vars) ;
   return ;
}

//----------------------------------------------------------------------

LmGenreSettings::~LmGenreSettings()
{
   // free genre-specific variables allocated on the heap
   free_object(_feature_weights) ;		_feature_weights = 0 ;
   FrFree(_untrans_prefix) ;			_untrans_prefix = 0 ;
   FrFree(_untrans_suffix) ;			_untrans_suffix = 0 ;
   FrFree(m_genre) ;				m_genre = 0 ;

   // unlink from the list of all genres
   if (m_next)
      m_next->m_prev = m_prev ;
   if (m_prev)
      m_prev->m_next = m_next ;
   else if (m_vars && m_vars != &lm_vars)
      m_vars->genre_list = m_next ;
   return ;
}

//----------------------------------------------------------------------

LmGenreSettings &LmGenreSettings::operator = (const LmGenreSettings &src)
{
   FrFree(m_genre) ;
   memcpy(this,&src,sizeof(LmGenreSettings)) ;
   m_genre = FrDupString(src.m_genre) ;
   m_next = m_prev = 0 ;
   m_vars = 0 ;
   return *this ;
}

//----------------------------------------------------------------------

void LmGenreSettings::link(LMGlobalVariables *vars)
{
   m_vars = vars ;
   m_prev = 0 ;
   if (vars)
      {
      m_next = vars->genre_list ;
      if (m_next)
	 m_next->m_prev = this ;
      vars->genre_list = this ;
      }
   else
      m_next = 0 ;
   return ;
}

//----------------------------------------------------------------------

LmGenreSettings *LmGenreSettings::find(const char *genre)
{
   for (LmGenreSettings *g = lm_vars.genre_list ; g ; g = g->m_next)
      {
      // are we looking for the default genre?
      if ((!genre || (genre[0] == '*' && genre[1] == '\0')) && !g->m_genre)
	 return g ;
      // check whether the names match
      if (genre && g->m_genre && strcmp(genre,g->m_genre) == 0)
	 return g ;
      }
   return 0 ;				// not found
}

//----------------------------------------------------------------------

// end of file lmgenre.cpp //
