/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmlength.h		sentence-length model			*/
/*  LastEdit: 13apr10							*/
/*									*/
/*  (c) Copyright 2010 Ralf Brown					*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __LMLENGTH_H_INCLUDED
#define __LMLENGTH_H_INCLUDED

/************************************************************************/
/************************************************************************/

class LmLengthDistribution
   {
   private:
      double	m_ratio ;
      double	m_shortdev ;
      double	m_longdev ;
   public:
      LmLengthDistribution()
	 { m_ratio = m_shortdev = m_longdev = 0.0 ; }
      void init(double r, double s, double l)
	 { m_ratio = r ; m_shortdev = s ; m_longdev = l ; }

      // accesssors
      double expectedRatio() const { return m_ratio ; }
      double shortDeviation() const { return m_shortdev ; }
      double longDeviation() const { return m_longdev ; }

      double brevity(size_t input, double output) const ;
      double verbosity(size_t input, double output) const ;
      double gaussian(size_t input, double output) const ;
   } ;

//----------------------------------------------------------------------

class LmLengthModel
   {
   private:
      LmLengthDistribution m_bytemodel[256] ;
      LmLengthDistribution m_wordmodel[256] ;
      double               m_bytebias ;
      double               m_wordbias ;
      size_t		   m_longestmodel ;
      bool		   m_OK ;
   protected:
      void interpolateDistributions(LmLengthDistribution*) ;
      bool load(FILE *fp) ;
   public:
      LmLengthModel() ;
      LmLengthModel(const char *filename) ;
      ~LmLengthModel() { m_OK = false ; }

      // manipulators
      void setLengthBiasByte(double bias) { if (bias > 0) m_bytebias = bias ; }
      void setLengthBiasWord(double bias) { if (bias > 0) m_wordbias = bias ; }

      // accessors
      bool OK() const { return m_OK ; }
      double lengthBiasByte() const { return m_bytebias ; }
      double lengthBiasWord() const { return m_wordbias ; }
      double expectedLengthWords(size_t srcwords) const ;
      double expectedLengthBytes(size_t srcwords, size_t srcbytes) const ;
      double brevityByte(size_t input, double ratio) const ;
      double brevityWord(size_t input, double output) const ;
      double verbosityByte(size_t input, double ratio) const ;
      double verbosityWord(size_t input, double output) const ;
      double gaussianByte(size_t input, double ratio) const ;
      double gaussianWord(size_t input, double output) const ;
   } ;

/************************************************************************/
/************************************************************************/

bool LmInitLengthModel(const char *filename) ;
void LmFreeLengthModel() ;
void LmSetLengthBias(double byte_bias, double word_bias) ;
const LmLengthModel *LmActiveLengthModel() ;

#endif /* !__LMLENGTH_H_INCLUDED */

// end of file lmlength.h //
