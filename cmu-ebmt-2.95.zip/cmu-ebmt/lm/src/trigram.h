/************************************************************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 1.30							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File trigram.h    Roni Rosenfeld's trigram back-off code		*/
/*			(adapted for LM by Ralf Brown)			*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,2000,2003 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __TRIGRAM_H_INCLUDED
#define __TRIGRAM_H_INCLUDED

#include <stdio.h>

#include "frconfig.h"

#include <sys/types.h>
#ifdef FrSTRICT_CPLUSPLUS
# include <cmath>
#else
# include <math.h>
#endif /* FrSTRICT_CPLUSPLUS */

/*=====================================================================
		=======	  COPYRIGHT NOTICE   =======
Copyright (C) 1994, Carnegie Mellon University and Ronald Rosenfeld.
All rights reserved.

This software is made available for research purposes only.  It may be
redistributed freely for this purpose, in full or in part, provided
that this entire copyright notice is included on any copies of this
software and applications and derivations thereof.

This software is provided on an "as is" basis, without warranty of any
kind, either expressed or implied, as to any matter including, but not
limited to warranty of fitness of purpose, or merchantability, or
results obtained from use of this software.
======================================================================*/

#ifdef FrLITTLEENDIAN
#define SLM_SWAP_BYTES	1     /* reverse byteorder on little-endian machines */
#endif /* FrLITTLEENDIAN */

#ifdef __alpha
#define SLM_SWAP_BYTES	1    /* reverse byteorder */
#endif

/* MIPS_SWAP.H	*/

#ifdef SLM_SWAP_BYTES	 /* reverse byteorder */

/* the following works even for badly aligned pointers */

#define SWAPHALF(x) {char tmp_byte;			   \
			       tmp_byte = *((char*)(x)+0); \
			*((char*)(x)+0) = *((char*)(x)+1); \
			*((char*)(x)+1) = tmp_byte;	   \
		    }
#define SWAPWORD(x) {char tmp_byte;			   \
			       tmp_byte = *((char*)(x)+0); \
			*((char*)(x)+0) = *((char*)(x)+3); \
			*((char*)(x)+3) = tmp_byte;	   \
			       tmp_byte = *((char*)(x)+1); \
			*((char*)(x)+1) = *((char*)(x)+2); \
			*((char*)(x)+2) = tmp_byte;	   \
		    }

#define SWAPDOUBLE(x) {char tmp_byte;			   \
			       tmp_byte = *((char*)(x)+0); \
			*((char*)(x)+0) = *((char*)(x)+7); \
			*((char*)(x)+7) = tmp_byte;	   \
			       tmp_byte = *((char*)(x)+1); \
			*((char*)(x)+1) = *((char*)(x)+6); \
			*((char*)(x)+6) = tmp_byte;	   \
			       tmp_byte = *((char*)(x)+2); \
			*((char*)(x)+2) = *((char*)(x)+5); \
			*((char*)(x)+5) = tmp_byte;	   \
			       tmp_byte = *((char*)(x)+3); \
			*((char*)(x)+3) = *((char*)(x)+4); \
			*((char*)(x)+4) = tmp_byte;	   \
		    }

#else

#define SWAPHALF(x)
#define SWAPWORD(x)
#define SWAPDOUBLE(x)

#endif


// end of MIPS_SWAP.H //


/* GENERAL.H  */

#define CMU_SLM_VERSION	 "CMU SLM Toolkit, Version 1.0 Release"

/* the following should be made machine-dependent */
typedef int   int32;
typedef short int16;

typedef char Boolean;
typedef unsigned short wordid_t;

#define MIN(X,Y)  ( ((X)<(Y)) ? (X) : (Y))
#define MAX(X,Y)  ( ((X)>(Y)) ? (X) : (Y))

#define LOG_BASE	9.9995e-5
#define MIN_LOG		-690810000
#define LOG(x)	((x == 0.0) ? MIN_LOG :	((x > 1.0) ?				\
					(int) ((log (x) / LOG_BASE) + 0.5) :	\
					(int) ((log (x) / LOG_BASE) - 0.5)))

// end of GENERAL.H //

/* SIH.H : String-to-Integer Hashing */

struct sih_slot_t {
	char *string;	   /* string (input to hash function) */
	int32 intval;	   /* Associated int32 value (output of hash function) */
} ;

struct sih_t {
	double	max_occupancy;	/* max. allowed occupancy rate */
	double	growth_ratio;	/* ratio of expansion when above is violated */
	int	warn_on_update; /* print warning if same string is hashed again */
	int	nslots;		/* # of slots in the hash table */
	int	nentries;	/* # of actual entries */
	sih_slot_t *slots;	/* array of (string,intval) pairs */
        char 	*strings ;
} ;

char sih_lookup(sih_t *ht, char *string, int32 *p_intval);

// end of SIH.H //

/* TRIGRAM.H */

/* ***** CAUTION *****: If the following 2 lines change, we must also 
			change the SWAPping in "SWAP_{BIC,TRIC}_RECORD()".
*/
typedef unsigned short counts_t;
typedef float alpha_t;

struct bic_record {
	wordid_t  id;	   /* relative to a vocab, 1-based, where OOV=0 */
	counts_t  bicount; /* actually, an index into 'count_table' */
	int	  index;   /* index into "tricounts" */
	alpha_t	  alpha;   /* backoff weight  */
     } ;

struct tric_record {
	wordid_t  id;	    /* relative to a vocab, 1-based, where OOV=0 */
	counts_t  tricount; /* actually, an index into 'count_table' */
     } ;

class FrFileMapping ;

struct trigram_model
   {
   int   version;	/* taken from compile-time constant in 'bbo_file.c' */
   int   bigram_only;	/* 1: trigram information is not available or should not be used */

   FILE  *fp ;		/* file from which to demand-load records */
   FrFileMapping *fmap ;/* memory-mapped file (if supported&enabled) */
   /* vocabulary parameters */
   int    open_vocab;	/* 0 if closed, 1 or 2 if open (see DESIGN) */
   sih_t  *vocab_ht;	/* hash-table from vocab words to their id */
   char   **vocab;	/* array[0..V] of the vocabulary words	(not in .bbo file) */
   int    V;		/* # of non-OOV words in vocabulary (<UNK> gets id==0) */
   int    first_id;	/* open_vocab: 0;    closed_vocab: 1  */
   int    VS;		/* Vocabulary Size (open_vocab: V+1;  closed_vocab: V) */
   int    begin_doc_id;	/* word-id of <art> or <begin_doc>,  or -1 if none */
   int    begin_para_id;/* word-id of <p> or <begin_para>, or -1 if none */
   int    begin_sent_id;/* word-id of <begin_sent> or <s> */
   int    end_sent_id;	/* word-id of </s> */

   /* .sidtric file parameters */
   int    n_trigrams;	/* # trigrams on which .sidtric file was based;
			   ~|training-data| */
   int    distances[2];	/* The distances on which the trigrams are based:
			   (d1,d2) counts are C(W(i-d2),W(i-d1),Wi) */

   /* unigram parameters */
   int    min_unicount;	// externally imposed minimum unicount, for smoothing
   double OOV_fraction;	// fraction of unigram discount going to OOV
   			// (open_vocab==2 only)*/
   double zeroton_fraction;// cap on prob(zeroton) as fraction on P(singleton)
   int    n_unigrams;	// # of words used to derive the unigram; aka N;
   			// sum[unicounts]
   int    *unicounts;	// array[0...V] or unicounts (context-cues excluded)
			// (used by 'idtric2bo' but not saved in the .bbo file)
   int    max_unicount;	// maximal unigram count collected in the training data
   int    n_distinct_unicounts; // # of distinct unigr. counts in training data
   int    *N1_list;	// triplets of <unicount, #-wds-w/such-unicount, example-wid>
   int    l_N1;		// size of N1 array
   int    *N1;		// array[0..l_N1] of counts of unicount-values
			//  ("freq. of freq.")
   int    K1;		// Good-Turing discounting cutoff for the unigram
   double *D1;		// array[0..K1] of GT-discounted unicounts
   int    *marg_counts;	// array[0..V] or marginal (uni-)counts, for use as denominator
   double *uniprobs;	// array[0..V] of unigram probabilities
   double *log_uniprobs;// log values of "uniprobs"
   int    *LOG_uniprobs;// LOG values of "uniprobs" (not in .bbo file)
   double *alphas;	// array[0..V] of bigram-backoff weights
   double *log_alphas;	// log values of "alphas"
   int    *LOG_alphas;	// LOG values of "alphas" (not in .bbo file)

   /* bigram parameters */
   int    n_bicounts;	// number of bicounts (distinct bigrams) in training data
   int    bigram_cutoff;// 2grams occurring in training <= this times were excluded
   int    max_bicount;	// maximal bigram count collected in the training data
   int    l_N2;		// length of N2 array
   int    *N2;		// array[0..l_N2] of counts of bicount-values
			//   ("freq. of freq.")
   int    K2;		// Good-Turing discounting cutoff for the bigram
   double *D2;		// array[0..K2] of GT-discounted bicounts
   int    *bicount_indxs; // array[0..V+1] id1-indices into "bicounts"
   int    n_bi_recs;	// number of bicount records (excluded bicounts have no record)
   int    bicount_table_size;// size of "bicount_table"
   int    *bicount_table;    // lookup table for bicount values
   bic_record  *bics;	     // array of bicount records
   bic_record **bic_ptrs ;   // arrays of bicount recs, one per ID1
   long int bic_offset ;     // offset of bic records in .bbo file

   /* trigram parameters */
   int    n_tricounts;	  // number of tricounts (distinct trigrams) in the training data
   int    trigram_cutoff; // 3grams occurring in training this or fewer times were excluded
   int    max_tricount;	  // maximal trigram count in the training data
   int    l_N3;		  // length of N3 array
   int    *N3;		  // array[0..l_N3] of counts of tricount-values ("freq. of freq.")
   int    K3;		  // Good-Turing discounting cutoff for the trigram
   double *D3;		  // array[0..K3] of GT-discounted tricounts
   int    n_tri_recs;	  // number of tricount records 
		// (excluded or w3-compressed tricounts have no record)
   int    tricount_table_size;	// size of "tricount_table"
   int    *tricount_table;	// lookup table for tricount values
   tric_record *trics;		// array of tricount records
   tric_record **tric_ptrs ;
   long int tric_offset ;	// offset of tricount recs in .bbo file
				// Conext-based Backoff Capping (aka Confidence Interval Capping)
				// For details, see my paper in proc. DARPA 92
   int    ic2;			// 1 if 2gram-capping is enabled; 0 o/w
   double ic2_confidence;	// confidence level ('Q') for 2gram-capping
   double ic2_point;		// point ('P') for 2gram-capping
   int    ic2_highest_modified_alpha;// (only useful if vocabulary is in frequency order)
   int    ic3;			// 1 if 3gram-capping is enabled; 0 o/w
   double ic3_confidence;	// confidence level ('Q') for 3gram-capping
   double ic3_point;		// point ('P') for 3gram-capping
   int    ic3_bicount_threshold;// 3gram-capping only applied if C(context)>=threshold
   } ;

double bo_triprob_of(int,int,int,trigram_model*,int,double *logprog) ;


/*

COMPRESSION OF THE TRICOUNT INFO:

If C(W1,W2)=1, then I store a fake bicount of -1, and store w3 in alpha.
The real alpha is then dynamically rederived when needed, as:

			   1 - P3(W3|W1,W2)		  1 - D3[1]
alpha(W1,W2,C(W1,W2)=1) = ------------------ = --------------------------------
			    1 - P2(W3|W2)	1 - D2[C(W2,W3)]*C(W2,W3)/C(W2)

Backoff Capping will not be used for alpha(W1,W2) when C(W1,W2)=1.
(CBC does not make any difference when the count is so low). 

This compression is currently used by 'sidtric2bo', but all the code that
uses the trigram structure does not rely on it, so it can be turned
off in 'sidtric2bo' and things should still work fine.

It is a bit awkward to store w3 (an int) in alpha (a float), but it seems 
to work.  A better alternative would be to store -(w3+1) in the bicount,
and make sure the bicount_table can handle it (ie enlarge it and possible
modify the index-creation code).

note: - When interval_capping is used, a modified alpha is marked by making it 
	negative (may have to be changed if we store log_alphas).
*/

/* BBO_FILE.H */
int verify_bbo_signature(const char *bbo_path) ;
int load_bbo_file(char *bbo_path, int verbosity, trigram_model *tg);
bic_record *load_bic_records(int id1, trigram_model *tg, int verbosity) ;
void close_bbo_file(trigram_model *tg) ;

#endif /* __TRIGRAM_H_INCLUDED */

// end of file trigram.h //
