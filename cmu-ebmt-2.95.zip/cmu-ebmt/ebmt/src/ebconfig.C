/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebconfig.C							*/
/*  LastEdit: 20apr10							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,1999,2000,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*  with contributions by Aaron B. Phillips				*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#if defined(__GNUC__)
#  pragma implementation "ebconfig.h"
#  pragma implementation "dict.h"
#endif

#include "dict.h"
#include "ebalign.h"
#include "ebconfig.h"
#include "ebcorpus.h"
#include "ebmt.h"
#include "ebglobal.h"

/************************************************************************/
/*	Manifest constants						*/
/************************************************************************/

#define DEFAULT_EBMT_CFGFILE  "ebmt.cfg"

#define EBMT_SECTION 	"EBMT"

/************************************************************************/
/************************************************************************/

extern double *EBMT_align_weights ;

//-----------------------------------------------------------------------
//  the parsing information for the EBMT configuration

static FrCommandBit ebmt_options[] =
   {
    { "VERBOSE",     	EB_VERBOSE,		false, "run verbosely" } ,
    { "QUIET",		EB_QUIET,		false, "run quietly" },
    { "IGNORECASE",	EB_IGNORE_CASE,		true,  "ignore case in source" },
    { "BRUTE_ALIGN",	EB_BRUTE_ALIGN,		false, "allow brute-force alignments" },
    { "MMAP",     	EB_MMAP,		true,  "use memory-mapped files" },
    { "MAPCORPUS",	EB_MAPCORPUS,		true,  "map entire corpus into memory, not just index" },
    { "TOUCHMEM",	EB_TOUCHMEM,		false, "touch all memory at startup" },
    { "UNIGRAMS",	EB_KEEP_UNIGRAMS,	true,  "use unigram matches as well as phrasal matches" },
    { "IGNOREACCENTS",  EB_IGNORE_ACCENTS,	false, "match accented/unaccented in retrieval" },
    { "PHRASEBOUNDS",	EB_PHRASE_BOUNDS,	false, "require matches to respect boundaries set by PHRASE tags in corpus" },
    { "RESCOREPHRASES",	EB_RESCOREPHRASES,	false, "use internal scoring functions to override stored score for PHRASE tags" },
    { "MATCHACCENTED",	EB_MATCH_ACCENTS,	false, "match accented/unaccented in indexing" },
    { "READONLYDICT",	EB_READONLYDICT,	false, "dictionary may not be updated at runtime" },
    { "READONLYCORPUS",	EB_READONLYCORPUS,	false, "corpus may not be updated at runtime" },
    { "MATCHWITHGAP",	EB_GAPPED_MATCHES,	false, "allow gaps in matches" },
    { "CONTEXTSAMPLE",	EB_CONTEXT_SAMPLE,	true,  "use context to bias sampling when more than Max-Duplicates instances are available" },
    { "GLOBAL_MAXALT",	EB_GLOBAL_MAXALTS,	true,  "Max-Alternatives applies across all corpora instead of to each corpus individually" },
    { "USE_MORPH",	EB_USE_MORPH,		false, "use morphology information" }, // ABP
    { "SPAN_PRODUCT",	EB_SPAN_MULTIPLY,	false, "combine span confidence scores by multiplying instead of averaging" },
    { "SPAN_GEOMEAN",	EB_SPAN_GEOMEAN,	false, "combine span confidence scores by using geometric mean instead of averaging" },
    { "UP_MORPH",	EB_UPPERCASE_MORPH,	true,  "force morphology info to uppercase" },
    { "GLOBAL_MORPH",	EB_GLOBAL_MORPH,	false, "always add morphology info to catch-all class, in addition to any defined special class" },
    { "KEEP_UNMORPHED",	EB_KEEP_UNMORPHED,	false, "retain original words with morphology tags attached" },
    { "USE_SPA",	EB_USE_SPA,		false, "use SPA instead of heuristic aligner" },

// obsolete, left for backward compat
    { 0,		0,			false,	0 }
   } ;

static FrCommandBit idx_options[] =
   {
    { "COMPRESS",	EB_COMPRESS_INDEX,	false, "" },
    { "DBLCOUNT_PHRASE",EB_DBLCOUNT_PHRASES,	false, "" },
    { "DICT_KEEPCASE",	EB_DICT_KEEP_CASE,	false, "" },
    { "FULLRECURSION", 	EB_FULLRECURSION,	false, "" },
    { "INDEXORIGINAL",  EB_INDEXORIG,		true,  "" },
    { "STRIP_PUNCT", 	EB_STRIP_PUNCT,		false, "" },
    { "COGNATES",	EB_COGNATE_ALIGN,	false, "allow cognates when aligning" },
    { 0,		0,			false, 0  }
   } ;

static FrCommandBit out_options[] =
   {
    { "OMITSUBSUMED",	EB_OMITSUBSUMED,	false, "don't generate chunks which are proper subsets of another chunk (note: do not enable if structural matching is used)" },
    { "SHOWCOVERAGE",	EB_SHOWCOVERAGE,	false, "" },
    { "SHOWGENSEQ",	EB_SHOWGENSEQ,		false,  "Include generalization sequence in arcs (default is off because this is CPU-intensive)" },
    { "TRACEMATCHES",	EB_TRACEMATCHES,	false, "" },
    { "UNDERSCOREHACK", EB_UNDERSCORE_HACK,	false, "" },
    { "ALIGNSCORES",	EB_SHOWALIGNSCORES,	false, "Output values of individual scoring functions as user scores in arcs" },
    { "BACKSUB",	EB_BACKSUBSTITUTE,	true,  "Apply backsubstitutions to generalized matches" },
    // obsolete, to be removed
    { "SHOWSOURCE",	0,			true,  "(obsolete)" },
    { 0,		0,			false, 0  }
   } ;

static size_t cache_inserts = 0 ;
static size_t cache_reinserts = 0 ;
static size_t cache_hits = 0 ;
static size_t cache_lookups = 0 ;

static EBMTConfig *dummy_EBMTConfig = 0 ;
#undef addr
#define addr(x) (void*)((char*)(&dummy_EBMTConfig->x) - (char*)dummy_EBMTConfig)

FrConfigurationTable EBMTConfig::EBMT_def[] =
   {
 	// keyword	parsing func   location		 settability
	//   	next-state  extra-args default	min	max
	//	description
    { "Abbreviations",    filename, 	&abbrevs_filename,	FrSET_STARTUP,
    		0,		0,		0,	0,	0,
		"Name of file containing a list of abbreviations to which a "
		"period should remain attached" },
    { "Align-Ambig-Cutoff", real,addr(genre._align_ambig_cutoff),FrSET_ANYTIME,
		0,	0,	"0.95",		"0.0",		"1.0",
      		"Ratio between highest and lowest alignment scores among "
		"ambiguous alignments for a given source phrase" },
    { "Align-Filename",    filename, 	&alignment_filename,	FrSET_STARTUP,
    		0,		0,		0,	0,	0,
		"" },
    { "Align-Constraints", filename, addr(constraints_filename),FrSET_STARTUP,
		0,		0,		0,	0,	0,
		"Name of file containing information constraining possible "
		"word-level alignments" },
    { "Align-Ratio-Max",   cardinal,	&max_word_ratio,	FrSET_ANYTIME,
		0,		0,		"3",	"1",	"9",
		"When aligning words, a translation may not be more than this "
		"many times as long as the matched phrase." },
    { "Align-Ratio-Min",   cardinal,	&min_word_ratio,	FrSET_ANYTIME,
		0,		0,		"3",	"1",	"9",
		"When aligning words, a matched phrase may not be more than "
		"this many times as long as its candidate translation." },
    { "Align-Threshold",   real,  addr(genre._align_threshold),	FrSET_ANYTIME,
		0,	0,	"0.5",		"0.0",		"1.0",
		"Minimum alignment score to consider an alignment good enough "
		"to use for a translation" },
    { "AlignSc-SrcCover",  	real,   &EBMT_align_weights[0],	FrSET_ANYTIME,
	      	0,	0,	"1.0",	"-1000.0",	"1000.0",
	      	"" },
    { "AlignSc-SrcXlat",  	real,   &EBMT_align_weights[1],	FrSET_ANYTIME,
	      	0,	0,	"40",	"-1000.0",	"1000.0",
	      	"" },
    { "AlignSc-TrgXlat",  	real,   &EBMT_align_weights[2],	FrSET_ANYTIME,
	      	0,	0,	"20",	"-1000.0",	"1000.0",
	      	"" },
    { "AlignSc-Inside",  	real,   &EBMT_align_weights[1],	FrSET_ANYTIME,
	      	0,	0,	"40",	"-1000.0",	"1000.0",
	      	"" },
    { "AlignSc-Outside",  	real,   &EBMT_align_weights[2],	FrSET_ANYTIME,
	      	0,	0,	"20",	"-1000.0",	"1000.0",
	      	"" },
    { "AlignSc-MatchGap",  	real,   &EBMT_align_weights[3],	FrSET_ANYTIME,
	      	0,	0,	"0.8",	"-1000.0",	"1000.0",
	      	"" },
    { "AlignSc-LengthRatio",  	real,   &EBMT_align_weights[4],	FrSET_ANYTIME,
	      	0,	0,	"1.5",	"-1000.0",	"1000.0",
	      	"" },
    { "AlignSc-SentBounds",  	real,   &EBMT_align_weights[5],	FrSET_ANYTIME,
	      	0,	0,	"0.15",	"-1000.0",	"1000.0",
	      	"" },
    { "AlignSc-SurfaceMatch",  	real,   &EBMT_align_weights[6],	FrSET_ANYTIME,
	      	0,	0,	"0.5",	"-1000.0",	"1000.0",
	      	"" },
    { "AlignSc-Excised",  	real,   &EBMT_align_weights[7],FrSET_ANYTIME,
	      	0,	0,	"0.06",	"-1000.0",	"1000.0",
	      	"" },
    { "AutoPhrase-Freq",   cardinal,	&autophrase_freq_thresh,FrSET_ANYTIME,
		0,	0,	"1000",		"0",		"9999999",
		"Minimum frequency of phrases to automatically extract and "
		"align while indexing the corpus" },
    { "AutoPhrase-File",   filename,    &autophrase_filename,	FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"Optional file in which to store results of AutoPhrase "
		"processing during indexing" },
    { "AutoPhrase-MaxLen", cardinal,	&autophrase_max_length,	FrSET_STARTUP,
		0,	0,	"1",		"0",		"99",
		"Maximum length of phrases to automatically extract and align "
		"while indexing the corpus" },
    { "Base-Directory",    basedir,  0,				FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"The directory to use as the base for relative pathnames" },
    { "Char-Encoding",	   cstring,  addr(char_enc),		FrSET_STARTUP,
		0,	0,	"Latin-1",	0,		0,
		"Name of the character encoding used by all input and output" },
    { "Cognate-Threshold",   real,     &cognate_threshold,	FrSET_ANYTIME,
      		0,	0,	"0.95",		"0.00",		"1.00",
		"Minimum similarity of words to accept them as cognates for "
		"alignment." },
    { "Cognates-File",	   filename,  addr(cognates_filename),	FrSET_STARTUP,
		0,	0,	0,		0,		0,
      		"Name of the file containing a specification of "
		"cross-language letter correspondence strengths" },
    { "Context-Window",      cardinal, &context_window_size,	FrSET_ANYTIME,
		0,	0,	"3",		"0",		"19",
		"Size of sliding window (in sentences) over which to compute "
		"similarity between input and corpus." },	
    { "Corpus-Directory",  filelist, addr(corpus_directory),	FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"Name of the directory containing the indexed EBMT corpus" },
    { "Dictionary",	   filename, addr(dictionary_file), 	FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"" },
    { "Dict-Max-Weight",  cardinal,    &dict_max_weight,	FrSET_ANYTIME,
		0,	0,	"4",		"1",		"100",
		"When generating a dictionary, shorter sentence pairs can be "
		"given more weight, up to a maximum of X for "
		"single-word/single-word pairs." },
    { "Dict-SStopList",	   list,     addr(dict_sstoplist),	FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"" },
    { "Dict-TStopList",	   list,     addr(dict_tstoplist),	FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"" },
    { "Dict-Score-Def",	   real,     &default_dict_score,	FrSET_ANYTIME,
		0,	0,	"0.01",		"0.00",		"1.00",
		"Probability to assume when there is no frequency "
		"information for a word." },
    { "Dict-Score-Root",   real,     &dict_score_root,		FrSET_ANYTIME,
		0,	0,	"0.25",		"0.00",		"1.00",
		"Factor by which to multiply the dictionary probability when "
		"retrieving a stem or root instead of the word itself." },
    { "Dict-Stems-File", filename,   &dict_stems_file,		FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"Name of file containing word stems/roots for backing off "
		"dictionary lookups" },
    { "Example-Wt-Begin",  real,     addr(ex_weight_start),	FrSET_ANYTIME,
		0,	0,	"1.0",		"0.0",		"9999999",
		"" },
    { "Example-Wt-End",    real,     addr(ex_weight_end),	FrSET_ANYTIME,
		0,	0,	"2.0",		"0.0",		"9999999",
		"" },
    { "Examples-Max",	   cardinal, addr(genre._example_limit_hi),FrSET_ANYTIME,
	        0,	0,	"4294967295",	"0",		"4294967295",
	        "Index of last training example to use for translations" },
    { "Examples-Min",	   cardinal, addr(genre._example_limit_lo),FrSET_ANYTIME,
	        0,	0,	"0",		"0",		"4294967295",
	        "Index of first training example to use for translations" },
    { "ExtAlign-CfgFile",  filename,  &external_aligner_cfgfile, FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"Configuration file for external word-level aligner." },
    { "ExtAlign-MinLength",cardinal,  &external_align_minlen,	FrSET_ANYTIME,
		0,	0,	"3",		"1",		"99",
		"Minimum length (in words) of a match on which to call the "
		"external aligner program to override the alignment stored "
		"in the corpus." },
    { "ExtAlign-Program",  filename,  &external_aligner,	FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"Program to invoke for overriding subsentential alignments "
		"stored in the corpus." },
    { "Func-Words",	   list,     &function_words,		FrSET_ANYTIME,
		0,	0,	0,		0,		0,
		"List of function words/morphemes.  Corpus matches which "
		"consist solely of items from this list are ignored." },
    { "Genres",		   list,      &EBMT_genre_names,	FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"List of genres with individual setups for the GENRE command" },
    { "Index-Options",	   bitflags, addr(index_options),	FrSET_ANYTIME,
		0,	idx_options,	0,		0,		0,
		"" },
    { "Indexing-Dictionary",filename,addr(indexing_dictionary), FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"Which bilingual dictionary to use while indexing a corpus.  "
		"If not set, the dictionary specified by Dictionary: is "
		"used." },
    { "MakeDict-Force-Xlat", cardinal,	&makedict_force,	FrSET_ANYTIME,
		0,	0,	"3",		"0",		"3",
		"If nonzero, when generating a dictionary, force translations "
		"for each source word whenever no collocation passes the "
		"filtering thresholds" },
    { "Max-Align-Ambig",  cardinal,addr(genre._max_align_ambig),FrSET_ANYTIME,
		0,	0,	"3",		"1",		"9",
      		"Maximum number of alignments to produce for a given source "
		"phrase" },
    { "Max-Alternatives",  cardinal,addr(genre._max_alternatives),FrSET_ANYTIME,
		0,	0,	"50",		"1",		"99999999",
		"Maximum number of candidate EBMT translations to output for "
		"a phrase" },
    { "Max-Alternatives1",cardinal,addr(genre._max_alternatives1),FrSET_ANYTIME,
		0,	0,	"50",		"1",		"99999999",
		"Maximum number of candidate EBMT translations to output for "
		"a unigram" },
    { "Max-Dict-Xlat",	   cardinal,	&max_dict_translations,	FrSET_ANYTIME,
		0,	0,	"9999999",	"1",		"99999999",
		"Maximum number of dictionary translations to output for a "
		"word" },
    { "Max-Duplicates",	   cardinal, addr(genre._max_duplicates),FrSET_ANYTIME,
		0,	0,	"300",		"1",		"99999999",
		"Maximum number of matches for a phrase in the corpus to "
      		"retrieve and process" },
    { "Max-Duplicates1",  cardinal, addr(genre._max_duplicates1),FrSET_ANYTIME,
		0,	0,	"300",		"1",		"99999999",
		"Maximum number of matches for a unigram in the corpus to "
      		"retrieve and process" },
    { "Max-Match",	   cardinal, addr(genre._max_match),	FrSET_ANYTIME,
		0,	0,	"65535",	"1",		"65535",
	        "Maximum length of a source match to consider (for testing)" },
    { "Max-Sentence",	   cardinal,	&max_sentence_length,	FrSET_ANYTIME,
		0,	0,	"255",		"10",		"255",
		"Maximum number of words in a sentence to be indexed" },
    { "Max-Threads",	  cardinal,   addr(maxthreads),    	FrSET_STARTUP,
		0, 	0,		"0",	"0",	"16",
		"Maximum number of parallel worker threads to use (0=disable "
		"multi-threading entirely)" },
    { "Min-Phrase-Length", cardinal,	&min_phrase_length,	FrSET_ANYTIME,
		0,	0,	"2",		"1",		"255",
		"Minimum length of pre-aligned phrase to use for alignment" },
    { "Min-Struct-Match", cardinal,	&min_struct_match,	FrSET_ANYTIME,
		0,	0,	"3",		"2",		"255",
		"Minimum length of structural (PoS) match to process" },
    { "Min-Struct-Lex", real,		&min_struct_lex,	FrSET_ANYTIME,
		0,	0,	"1.0",		"0.0",		"255.0",
		"Minimum amount of lexicalization to use a structural (PoS) "
		"match; proportion if < 1.0, absolute number of lexicalized "
		"words if >= 1.0" },
    { "Morph-Assign",   cstring,	&morph_assign_str,	FrSET_ANYTIME,
		0,	0,	"=",	0,		0,
		"Character sequence which takes the role of the equal sign in "
		"TYPE=VALUE morphology information" },
    { "Morph-Intro", 	   cstring,	&morph_intro_str,	FrSET_ANYTIME,
		0,	0,	0,		0,		0,
		"Character sequence which introduces embedded morphology "
		"information" },
    { "Morph-Separator",   cstring,	&morph_separator_str,	FrSET_ANYTIME,
		0,	0,	"+",	0,		0,
		"Character sequence which separates items in embedded "
		"morphology information" },
    { "Morph-Classes",   list,		&morph_classes,		FrSET_ANYTIME,
		0,	0,	0,		0,		0,
		"Mapping from morphology tags to classes, with optional "
		"renaming of the tags if a third element is specified in the "
		"sublist" },
    // ABP Begin
    // Debug-Level 0 : No debugging output
    // Debug-Level 1 : Add extra (scoring) information about each candidate
    // Debug-Level 2 : Additionally output all candidates looked up from the corpus
    { "Debug-Level",	     cardinal,  &debug_level,           FrSET_ANYTIME,
                0,      0,      "0",            "0",            "3",
                "" },
    { "Candidate-Thresh",       real,   &cand_thresh,           FrSET_ANYTIME,
                0,      0,      "0.0",          "0.0",          "1.0",
                "" },
    { "Score-Discount",         real,   &score_discount,        FrSET_ANYTIME,
                0,      0,      "1.0",          "0.000001",	"1000000.0",
                "" },
    { "Freq-Thresh",            real,   &freq_thresh,           FrSET_ANYTIME,
                0,      0,      "100.0",        "0.0",          "1000000.0",
                "" },
    { "Metainfo-File",	     filename, &metainfo_file, 	        FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"" },
    { "Generalization-Weights",	filename, &weights_file, 	FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"" },
    // If Generalization-Weights is not provided, this value is used for all generalizations
    { "Generalization-Weight",  real,   &generalization_weight, FrSET_ANYTIME,
                0,      0,      "0.0",          "0.0",          "1.0",
                "" },
    { "Generalization-Rules",	filename, &rules_file, 	        FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"" },
    // ABP End
    { "NE-Spec",	cstring,	addr(ne_spec),		FrSET_ANYTIME,
     		0,	0,	0,		0,		0,
	   	"Format specification for tagged named entities, e.g. "
		"@%%c{%%s#%%t#%%p}" },
    { "NE-Def-Score",	real,		&ne_default_score,	FrSET_ANYTIME,
     		0,	0,	"0.25",		"0.0",		"1.0",
	   	"Default score for pass-through translations produced by "
		"tagged named entities that do not include a score specifier "
		"(%%p)." },
    { "Number-CharMapping",list,     addr(number_charmap),	FrSET_STARTUP,
		0,	0,	0,	0,	0,
		"How characters in a numeric string map from source to "
		"target; typically used to swap commas and periods" },
    { "Options",	   bitflags, addr(options),		FrSET_STARTUP,
		0,	ebmt_options,		0,	0,	0,
		"" },
    { "Origin-Weights",	   list, addr(genre._example_origin_weights),FrSET_STARTUP,
		0,	0,	0,	0,	0,
		"" },
    { "Output-Options",	   bitflags, addr(output_options),	FrSET_ANYTIME,
		0,	out_options,		0,	0,	0,
		"" },
    { "Phrase-Threshold",   real,  addr(genre._phrase_threshold),FrSET_ANYTIME,
		0,	0,	"0.001",	"0.0",		"1.0",
		"Minimum score to consider an external phrasal alignment good "
		"enough to use as translation alignment" },
    { "PrepDoc-MinLength", cardinal, &prepare_doc_minlen,	FrSET_ANYTIME,
      		0,	0,	"0",		"0",	"10",
		"Minimum phrasal match length to use in computing similarity "
		"between input document for PREPDOC command and training docs."
		},
    { "Reverse-Dictionary",filename, addr(reverse_dictionary), 	FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"Which bilingual dictionary to use for the reverse "
		"(target->source) direction while indexing a corpus." },
    { "Sentence-Ratio-Max",   	real,	&max_sentence_ratio,	FrSET_ANYTIME,
		0,	0,	"5.0",		"0.5",		"10.0",
		"Target half of sentence pair to be indexed must be no more "
      		"than X times as long as the source half" },
    { "Sentence-Ratio-Min",   	real,	&min_sentence_ratio,	FrSET_ANYTIME,
		0,	0,	"0.2",		"0.05",		"2.0",
		"Target half of sentence pair to be indexed must be at least "
      		"X times as long as the source half" },
    { "Socket-Number",     integer,  addr(socketnum),		FrSET_STARTUP,
		0,	0,	"0",		"0",		"65535",
		"" },
    { "Source-CharMapping",list,     addr(source_charmap),	FrSET_STARTUP,
		0,	0,		0,	0,	0,
		"" },
    { "Source-Language",   cstring,  &corpus_source_language,	FrSET_STARTUP,
		0,	0,		0,	0,	0,
		"" },
    { "Source-Regex",	   filename, addr(source_regex),	FrSET_STARTUP,
		0,	0,		0,	0,	0,
		"" },
    { "Source-Suffixes",   list,     addr(source_suffixes),	FrSET_STARTUP,
		0,	0,		0,	0,	0,
		"" },
    { "Source-SynSets",	   filename,	&source_synsets_file,	FrSET_STARTUP,
		0,	0,		0,	0,	0,
    		"Name of file containing source synonym sets to expand "
		"matches" },
    { "SrcFeat-Position",    real,	&srcfeat_position,	FrSET_ANYTIME,
	      	0,	0,		"0.2",	"0.0",	"1000.0",
      		"Weight of 'sentence position' source feature" },
    { "Stats-Covered-Bytes", cardinal,	&covered_bytes,		FrSET_READONLY,
      		0,	0,		0,	0,	0,
	      	"Number of bytes of the input text actually translated by "
		"EBMT" },
    { "Stats-Cache-Adds",  cardinal,	&cache_inserts,		FrSET_READONLY,
      		0,	0,		0,	0,	0,
	       "Number of phrases inserted in the translation cache" },
    { "Stats-Cache-Dups", cardinal,	&cache_reinserts,	FrSET_READONLY,
      		0,	0,		0,	0,	0,
	        "Number of phrases inserted in the translation cache while "
      		"already in the cache" },
    { "Stats-Cache-Hits",  cardinal,	&cache_hits,		FrSET_READONLY,
      		0,	0,		0,	0,	0,
	        "Number of phrases found in the translation cache" },
    { "Stats-Cache-Lookups", cardinal,	&cache_lookups,		FrSET_READONLY,
      		0,	0,		0,	0,	0,
	       "Number of phrases looked up in the translation cache" },
    { "Stats-Covered-Words", cardinal,	&covered_words,		FrSET_READONLY,
      		0,	0,		0,	0,	0,
	      	"Number of words of text actually translated by EBMT" },
    { "Stats-Exact-Matches", cardinal, &ungapped_match_count,	FrSET_READONLY,
      		0,	0,		0,	0,	0,
	      	"Number of matches against EBMT corpus that did not contain a "
		"gap." },
    { "Stats-Gapped-Matches", cardinal,	&gapped_match_count,	FrSET_READONLY,
      		0,	0,		0,	0,	0,
	      	"Number of matches against EBMT corpus that contained a gap." },
    { "Stats-Input-Bytes", cardinal,	&total_input_len,	FrSET_READONLY,
      		0,	0,		0,	0,	0,
	      	"Number of bytes of non-whitespace text input to be "
		"translated" },
    { "Stats-Input-Words", cardinal,	&total_input_len,	FrSET_READONLY,
      		0,	0,		0,	0,	0,
	      	"Number of words of text input to be translated" },
    { "Stats-Match-Count", cardinal,	&total_match_count,	FrSET_READONLY,
      		0,	0,		0,	0,	0,
	      	"Number of words matched against EBMT corpus" },
    { "Target-Language",   cstring,  &corpus_target_language,	FrSET_STARTUP,
		0,	0,		0,	0,	0,
		"The name of the output language." },
    { "Target-Regex",	   filename, addr(target_regex),	FrSET_STARTUP,
		0,	0,		0,	0,	0,
		"" },
    { "Target-Roots",	   filename, addr(target_roots),	FrSET_STARTUP,
		0,	0,		0,	0,	0,
		"" },
    { "Tight-Bound-Left",  list,     addr(tight_bound_left),	FrSET_STARTUP,
		0,	0,		0,	0,	0,
		"" },
    { "Tight-Bound-Right", list,     addr(tight_bound_right),	FrSET_STARTUP,
		0,	0,		0,	0,	0,
		"" },
    { "TM-Mode",	   keyword,  &tm_mode,			FrSET_ANYTIME,
		0,	0,	"OFF",	"OFF ON FAILOVER",	0,
		"Translation-Memory Mode: force complete matches only, or use "
		"partial matches only if no complete matches are available" },
    { "Token-File",	   filename, &token_source_filename,	FrSET_STARTUP,
		0,	0,		0,	0,	0,
    		"" },
    { "Word-Delimiters",   list,     addr(word_delim),		FrSET_STARTUP,
		0,	0,		0,	0,	0,
		"" },
    { "Word-Order-Sim",	   cardinal,&EBMT_word_order_similarity,FrSET_ANYTIME,
		0,	0,	"1",		"0",		"10",
		"" },
    { "",		   invalid,  0,				FrSET_READONLY,
		0,	0,		0,	0,	0,
		"" },
      // what to do if we reach EOF
    { 0,		   invalid, 	       0, 		FrSET_READONLY,
		0,	0,		0,	0,	0,
		"" },
   } ;

FrConfigurationTable DictConfig::DICT_def[] =
   {
    { "Base-Directory",    basedir,  0,				FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"The directory to use as the base for relative pathnames" },
    { "Char-Encoding",	   cstring,  addr(char_enc),		FrSET_STARTUP,
		0,	0,	"Latin-1",	0,		0,
		"Name of the character encoding used by all input and output" },
    { "Dictionary",	   filename, addr(dictionary_file), 	FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"" },
    { "Dict-SStopList",	   list,     addr(dict_sstoplist),	FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"" },
    { "Dict-TStopList",	   list,     addr(dict_tstoplist),	FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"" },
    { "Max-Dict-Xlat",	   cardinal,	&max_dict_translations,	FrSET_ANYTIME,
		0,	0,	"9999999",	"1",		"99999999",
		"Maximum number of dictionary translations to output for a "
      		"word" },
    { "Options",	   bitflags, addr(options),		FrSET_ANYTIME,
		0,	ebmt_options,		0,	0,	0,
		"" },
    { "Socket-Number",     integer,  addr(socketnum),		FrSET_STARTUP,
		0,	0,	"0",		"0",		"65535",
		"" },
    { "Source-CharMapping",list,     addr(source_charmap),	FrSET_STARTUP,
		0,	0,		0,	0,	0,
		"" },
    { "Source-Language",   cstring,  &corpus_source_language,	FrSET_STARTUP,
		0,	0,		0,	0,	0,
		"" },
    { "Target-Language",   cstring,  &corpus_target_language,	FrSET_STARTUP,
		0,	0,		0,	0,	0,
		"The name of the output language." },
    { "",		   invalid,  0,				FrSET_READONLY,
		0,	0,		0,	0,	0,
		"" },
      // what to do if we reach EOF
    { 0,		   invalid, 	       0, 		FrSET_READONLY,
		0,	0,		0,	0,	0,
		"" },
   } ;

/************************************************************************/
/*	Helper functions						*/
/************************************************************************/

void clear_regex_list(FrRegExp *re_list) ;

//----------------------------------------------------------------------

static void set_word_delimiters(char *&delimiter_table, const FrList *delims)
{
   if (!delims)
      return ;
   if (delims->first() && delims->first()->consp())
      delims = (FrList*)delims->first() ;
   delimiter_table = FrNewC(char,256) ;
   if (delimiter_table)
      {
      for (size_t i = 0 ; delims && i < 256 ; i++, delims = delims->rest())
	 {
	 FrObject *del = delims->first() ;
	 if (del && del->numberp() && del->intValue() > 0)
	    delimiter_table[i] = (char)1 ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

static FrRegExp *load_regex_list(const char *filename)
{
   if (!filename || !*filename)
      return 0 ;
   FrRegExp *re_list = 0 ;
   FrRegExp *re_list_tail = 0 ;
   FILE *fp = fopen(filename,"r") ;
   if (fp)
      {
      size_t linenum = 0 ;
      FrSymbol *symbolEOF = makeSymbol("*EOF*") ;
      while (!feof(fp))
	 {
	 char line[FrMAX_LINE] ;
	 line[0] = '\0' ;
	 if (fgets(line,sizeof(line),fp) && !feof(fp))
	    {
	    linenum++ ;
	    const char *lineptr = line ;
	    FrObject *src = string_to_FrObject(lineptr) ;
	    // check whether line contained anything besides whitespace and
	    // comments
	    if (src && src != symbolEOF)
	       {
	       if (!src->stringp())
		  {
		  FrWarningVA("%s (line %lu): expecting two quoted strings\n"
			      "\t(regex to test and replacement)",filename,
			      (unsigned long)linenum) ;
		  continue ;
		  }
	       FrObject *replacement = string_to_FrObject(lineptr) ;
	       if (replacement == symbolEOF)
		  {
		  FrWarningVA("%s (line %lu):\n"
			      "\tno replacement string given -- entry skipped",
			      filename,(unsigned long)linenum) ;
		  continue ;
		  }
	       if (!replacement ||
		   (!replacement->stringp() && !replacement->symbolp()))
		  {
		  FrWarningVA("%s (line %lu):\n"
			      "\tsecond item on line must be a quoted string!",
			      filename,(unsigned long)linenum) ;
		  continue ;
		  }
	       const char *repl = 0 ;
	       if (replacement->stringp())
		  repl = ((FrString*)replacement)->stringValue();
	       else // if (replacement->symbolp())
		  repl = ((FrSymbol*)replacement)->symbolName() ;
	       if (repl)
		  {
		  const char *regex = ((FrString*)src)->stringValue() ;
		  FrRegExp *re = new FrRegExp(regex,repl,0) ;
		  // store REs on list in the order in which they appear in
		  // the file
		  if (re_list)
		     re_list_tail->relink(re) ;
		  else
		     re_list = re ;
		  re_list_tail = re ;
		  }
	       free_object(replacement) ;
	       }
	    free_object(src) ;
	    }
	 }
      fclose(fp) ;
      }
   else
      FrWarningVA("unable to open '%s'\n"
		  "\tto read regular expressions",filename) ;
   return re_list ;
}

/************************************************************************/
/*	Methods for class EBMTConfig					*/
/************************************************************************/

EBMTConfig::~EBMTConfig()
{
   freeValues() ;
   return ;
}

//----------------------------------------------------------------------

void EBMTConfig::init()
{
   FrConfiguration::init() ;
   socketnum = -1 ;
   return ;
}

//-----------------------------------------------------------------------

void EBMTConfig::resetState()
{
   curr_state = EBMT_def ;
   return ;
}

//-----------------------------------------------------------------------

size_t EBMTConfig::lastLocalVar() const
{
   return (size_t)((char*)(&this->last_local_var) - (char*)this) ;
}

//-----------------------------------------------------------------------

bool EBMTConfig::onRead(FrConfigVariableType, void * /*where*/)
{
   //else
      {
      // don't bother checking which, just update all of them
      genre = *ebmt_vars.genre ;
      }
   return true ;
}

//-----------------------------------------------------------------------

bool EBMTConfig::onChange(FrConfigVariableType /*vartype*/, void *where)
{
   if (where == &char_enc)
      {
      EbSetCharEncoding(char_enc) ;
      }
   else if (where == &options)
      {
      verbose = (options & EB_VERBOSE) != 0 ;
      quiet_mode = (options & EB_QUIET) != 0 ;
      ignore_source_case = (options & EB_IGNORE_CASE) != 0 ;
      allow_gapped_matches = (options & EB_GAPPED_MATCHES) != 0 ;
      context_biases_sampling = (options & EB_CONTEXT_SAMPLE) != 0 ;
      keep_unigram_matches = (options & EB_KEEP_UNIGRAMS) != 0 ;
      match_accented = (options & EB_MATCH_ACCENTS) != 0 ;
      ignore_accents = (options & EB_IGNORE_ACCENTS) != 0 ;
      rescore_external_phrases = (options & EB_RESCOREPHRASES) != 0 ;
      may_cross_phrase_boundaries = (options & EB_PHRASE_BOUNDS) == 0 ;
      brute_force_align = (options & EB_BRUTE_ALIGN) != 0 ;
      allow_memory_mapping = (options & EB_MMAP) != 0 ;
      touch_all_memory = (options & EB_TOUCHMEM) != 0 ;
      map_corpus_subfiles = (options & EB_MAPCORPUS) != 0 ;
      max_alts_are_global = (options & EB_GLOBAL_MAXALTS) != 0 ;
      span_scores_product = (options & EB_SPAN_MULTIPLY) != 0 ;
      span_scores_geometric_mean = (options & EB_SPAN_GEOMEAN) != 0 ;
      load_dict_readonly = (options & EB_READONLYDICT) != 0 ;
      load_corpus_readonly = (options & EB_READONLYCORPUS) != 0 ;
      morph_global_info = (options & EB_GLOBAL_MORPH) != 0 ;
      morph_replace_text = (options & EB_KEEP_UNMORPHED) == 0 ;
      use_SPA = (options & EB_USE_SPA) != 0 ; 
      use_morph = (options & EB_USE_MORPH) != 0 ; // ABP
      uppercase_morph = (options & EB_UPPERCASE_MORPH) != 0 ;
      FrSetMorphologyFeatures(use_morph,uppercase_morph?uppercase_table:0) ;
      }
   else if (where == &index_options)
      {
      use_compressed_index = (index_options & EB_COMPRESS_INDEX) != 0 ;
      double_count_phrases = (index_options & EB_DBLCOUNT_PHRASES) != 0 ;
      dict_keep_case = (index_options & EB_DICT_KEEP_CASE) != 0 ;
      allow_token_recursion = (index_options & EB_FULLRECURSION) != 0 ;
      allow_cognates = (index_options & EB_COGNATE_ALIGN) != 0 ;
      index_original = (index_options & EB_INDEXORIG) != 0 ;
      strip_punct = (index_options & EB_STRIP_PUNCT) != 0 ;
      }
   else if (where == &output_options)
      {
      compute_coverage = (output_options & EB_SHOWCOVERAGE) != 0 ;
      trace_matching = (output_options & EB_TRACEMATCHES) != 0 ;
      underscore_hack = (output_options & EB_UNDERSCORE_HACK) != 0 ;
      show_all_align_scores = (output_options & EB_SHOWALIGNSCORES) != 0 ;
      show_gen_sequence = (output_options & EB_SHOWGENSEQ) != 0 ;
      omit_subsumed = (output_options & EB_OMITSUBSUMED) != 0 ;
      apply_backsubs = (output_options & EB_BACKSUBSTITUTE) != 0 ;
      }
   else if (where == &ex_weight_start && ex_weight_start > 0)
      example_weight_start = ex_weight_start ;
   else if (where == &ex_weight_end && ex_weight_end > 0)
      example_weight_end = ex_weight_end ;
   else if (where == &word_delim)
      set_word_delimiters(word_delimiters,word_delim) ;
   else if (where == &source_regex)
      {
      clear_regex_list(source_regex_list) ;
      source_regex_list = load_regex_list(source_regex) ;
      }
   else if (where == &target_regex)
      {
      clear_regex_list(target_regex_list) ;
      target_regex_list = load_regex_list(target_regex) ;
      }
   else if (where == &cognates_filename)
      {
      if (cognates_filename && *cognates_filename)
	 FrLoadCognateLetters(cognates_filename) ;
      else
	 FrSetDefaultCognateLetters() ;
      }
#define UPDATE_GENRE(x) else if (where == &genre._##x) { x = genre._##x ; }
   UPDATE_GENRE(max_duplicates)
   UPDATE_GENRE(max_duplicates1)
   UPDATE_GENRE(max_match)
   UPDATE_GENRE(max_alternatives)
   UPDATE_GENRE(max_alternatives1)
   UPDATE_GENRE(max_align_ambig)
   UPDATE_GENRE(align_ambig_cutoff)
   UPDATE_GENRE(align_threshold)
   UPDATE_GENRE(phrase_threshold)
   UPDATE_GENRE(example_limit_lo)
   UPDATE_GENRE(example_limit_hi)
#undef UPDATE_GENRE
   else if (where == &genre._example_origin_weights)
      {
      example_origin_weights = genre._example_origin_weights ;
      genre._example_origin_weights = 0 ;
      }
   else if (where == &morph_intro_str || where == &morph_separator_str ||
	    where == &morph_assign_str)
      FrSetMorphologyMarkers(morph_intro_str,morph_separator_str,
			     morph_assign_str) ;
   else if (where == &ne_spec)
      {
      FrFreeNamedEntitySpec(named_entity_spec) ;
      named_entity_spec = FrParseNamedEntitySpec(ne_spec,false,
						 ne_default_score) ;
      }
   else if (where == &ne_default_score)
      {
      if (named_entity_spec)
	 FrNamedEntitySetConf(named_entity_spec,ne_default_score) ;
      }
   example_weight_range = example_weight_end - example_weight_start ;
   if (show_all_align_scores)
      EbAddAlignmentFeatures() ;
   return true ;			// successfully processed notification
}

//-----------------------------------------------------------------------

ostream &EBMTConfig::dump(ostream &output) const
{
   dumpValues("EBMTConfig",output) ;
   output << endl ;
   return output ;
}

/************************************************************************/
/*	Methods for class DictConfig					*/
/************************************************************************/

DictConfig::~DictConfig()
{
   freeValues() ;
   return ;
}

//-----------------------------------------------------------------------

void DictConfig::init()
{
   FrConfiguration::init() ;
   return ;
}

//-----------------------------------------------------------------------

void DictConfig::resetState()
{
   curr_state = DICT_def ;
   return ;
}

//-----------------------------------------------------------------------

size_t DictConfig::lastLocalVar() const
{
   return (size_t)((char*)(&this->last_local_var) - (char*)this) ;
}

//-----------------------------------------------------------------------

bool DictConfig::onChange(FrConfigVariableType vartype, void *where)
{
(void)vartype; (void)where;   
   return true ;			// successfully processed notification
}

//-----------------------------------------------------------------------

ostream &DictConfig::dump(ostream &output) const
{
   dumpValues("DictConfig",output) ;
   output << endl ;
   return output ;
}

/************************************************************************/
/************************************************************************/

static EBMTConfig *make_EBMTConfig(istream &input,const char *base_directory,
				   const char *section = 0)
{
   EBMTConfig *cfg = new EBMTConfig(base_directory) ;
   if (!section)
      section = EBMT_SECTION ;
   if (cfg)
      cfg->load(input,section,true) ;
   return cfg ;
}

//----------------------------------------------------------------------

static bool make_GenreConfig(istream &input, EBMTConfig *config,
			       const char *genre)
{
   if (config && genre)
      {
      size_t len = strlen(genre) ;
      size_t sect_len = len + sizeof(EBMT_SECTION) + 2 ;
      FrLocalAlloc(char,section,1024,sect_len) ;
      if (section)
	 {
	 ebmt_vars.genre = new EbGenreSettings(*ebmt_vars.genre,&ebmt_vars,
					       genre) ;
	 strcpy(section,EBMT_SECTION) ;
	 char *s = strchr(section,'\0') ;
	 *s++ = '-' ;
	 memcpy(s,genre,len+1) ;	// include terminating NUL in copy
	 bool success = config->load(input,section,false) ;
	 FrLocalFree(section) ;
	 if (!success)
	    {
	    delete ebmt_vars.genre ;
	    ebmt_vars.genre = ebmt_vars.genre_list ;
	    }
	 return success ;
	 }
      }
   return false ;
}

/************************************************************************/
/************************************************************************/

static EBMTConfig *ebmt_config = 0 ;

//----------------------------------------------------------------------

static EBMTConfig *load_setup_file(const char *filename,
				   const char *section = 0)
{
   ifstream in(filename) ;
   if (in.good())
      {
      config_file = filename;
      char *base_directory = FrFileDirectory(filename) ;
      EBMTConfig *config = make_EBMTConfig(in,base_directory,section) ;
      FrFree(base_directory) ;
      if (config && EBMT_genre_names)
	 {
	 in.seekg(0) ;
	 // preserve the list of genre names, which might be clobbered by
	 //   reading in the genre-specific info
	 FrList *genres = EBMT_genre_names ;
	 EBMT_genre_names = 0 ;
	 // iterate over the named genres, and try to load genre-specific
	 //   settings for each
	 for (const FrList *gn = genres ; gn ; gn = gn->rest())
	    {
	    FrObject *genre = gn->first() ;
	    if (FrPrintableName(genre))
	       {
	       if (!make_GenreConfig(in,config,FrPrintableName(genre)))
		  cout << "Warning: no configuration section for EBMT genre '"
		       << FrPrintableName(genre) << "'" << endl ;
	       }
	    }
	 // restore the list of genre names
	 free_object(EBMT_genre_names) ;
	 EBMT_genre_names = genres ;
	 ebmt_vars.genre = EbGenreSettings::find(0) ;
	 }
      if(debug_level == 2)
	{
	  max_alternatives = 100;
	  cand_thresh = 0;
	}
      if(debug_level == 3)
	{
	  max_alternatives = ~0;
	  max_dict_translations = ~0;
	  align_threshold = 0;
	  cand_thresh = 0;
	}
      if (verbose && trace_matching) config->dump(cerr) ;
      return config ;
      }
   else
      return 0 ;
}

//----------------------------------------------------------------------

static EBMTConfig *try_loading_setup(const char *dir, const char *basename,
				     const char *section = 0)
{
   char *filename = FrAddDefaultPath(basename,dir) ;
   if (!filename)
      {
      FrNoMemory("while trying to load configuration file") ;
      return 0 ;
      }
   EBMTConfig *config = load_setup_file(filename,section) ;
   FrFree(filename) ;
   return config ;
}

//----------------------------------------------------------------------

EBMTConfig *get_EBMT_setup_file(const char *filespec, const char *argv0,
				ostream &err)
{
   EBMTConfig *config ;
   if (filespec && strcmp(filespec,".") != 0)
      {
      config = load_setup_file(filespec,EBMT_SECTION) ;
      if (!config)
	 {
	 err << "unable to open specified setup file, "
		 "will use default file" << endl ;
	 }
      delete ebmt_config ;
      ebmt_config = config ;
      return config ;
      }
   // if we get here, either no setup file was specified, or unable to open it
   // so, try to load ebmt.cfg from the current directory, then .ebmt.cfg
   // from user's home directory, and finally embt.cfg from the directory
   // containing the executable
   const char *cfg = DEFAULT_EBMT_CFGFILE ;
   config = try_loading_setup(".",cfg,EBMT_SECTION) ;
   if (config)
      {
      delete ebmt_config ;
      ebmt_config = config ;
      return config ;
      }
   char *homedir = getenv("HOME") ;
   if (homedir && *homedir)
      {
      config = try_loading_setup(homedir,"."DEFAULT_EBMT_CFGFILE,
				 EBMT_SECTION) ;
      if (config)
	 {
	 delete ebmt_config ;
	 ebmt_config = config ;
	 return config ;
	 }
      }
   char *dir = FrFileDirectory(argv0) ;
   if (!dir)
      FrNoMemory("in get_EBMT_setup_file") ;
   else
      {
      config = try_loading_setup(dir,cfg,EBMT_SECTION) ;
      FrFree(dir) ;
      }
   delete ebmt_config ;
   ebmt_config = config ;
   return config ;
}

//----------------------------------------------------------------------

EBMTConfig *get_EBMT_config()
{
   return ebmt_config ;
}

//----------------------------------------------------------------------

void unload_EBMT_config()
{
   delete ebmt_config ;
   ebmt_config = 0 ;
   return ;
}

// end of file ebconfig.C //
