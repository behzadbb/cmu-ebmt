/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebchunks.h	create candidate chunks from occurrence lists	*/
/*  LastEdit: 08apr10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2001,2002,2003,2004,2005	*/
/*		2006,2007,2008,2009,2010 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __EBCHUNKS_H_INCLUDED
#define __EBCHUNKS_H_INCLUDED

#ifndef __FRAMEPAC_H_INCLUDED
#include "FramepaC.h"
#endif

#ifndef __EBBITEXT_H_INCLUDED
#include "ebbitext.h"
#endif

#ifndef __EBINDEX_H_INCLUDED
#include "ebindex.h"
#endif

#ifndef __EBSETUP_H_INCLUDED
#include "ebsetup.h"
#endif

#ifndef __EBCRPINF_H_INCLUDED
#include "ebcrpinf.h"
#endif

#if defined(__GNUC__)
#  pragma interface
#endif /* __GNUC__ */

#ifdef FrSTRICT_CPLUSPLUS
#  include <cmath>
#else
#  include <math.h>
#endif

/************************************************************************/
/*    Manifest constants for this module				*/
/************************************************************************/

#define SCORE_UNALIGNABLE	-1.0
#define SCORE_ACCEPTABLE	0.0	// we were able to do some alignment
#define SCORE_PERFECT		1.0	// exact match of the example!

#define NO_GAP			0

#define ALIGNSCORE_POWER	3	// the exponent of the power mean
					//   for alignment scores (or 0 to
					//   use log-linear combination)

#define NUM_ALIGN_SCORES	8	// max # of alignment scores

#define DUMMY_EXAMPLE_NUMBER (1999 * LINES_PER_SUBFILE)

/************************************************************************/
/************************************************************************/

// the following must match the values declared for the TM-Mode parameter
//   in ebconfig.cpp
#define EbTRANSMEM_OFF		0
#define EbTRANSMEM_ON		1
#define EbTRANSMEM_FAILOVER	2

/************************************************************************/
/*    Type declarations for this module					*/
/************************************************************************/

class BiTextMap ;
class EbSentence ;
class TokenInfo ;
class EbCorpusMatches ;
class EbGeneralizations ;
class EbMatchFrequency ;

//----------------------------------------------------------------------

// select maximal precision or saving space by using either
//   FrFeatureVectorDouble or FrFeatureVectorFloat as our feature
//   vector type
//typedef FrFeatureVectorFloat EbFeatureVector ;
typedef FrFeatureVectorDouble EbFeatureVector ;

//----------------------------------------------------------------------

class EBMTCandidate
   {
   private:
      static FrAllocator allocator ;

      EBMTCandidate *m_next ;
      EbSentence *target_sentence ;	// full target from corpus
      const FrTextSpan **m_spans ;	// input spans covered by this cand.
      const FrList **m_backsubs ;	// back-substitutions for tokens
      FrList *source_words ;		// section of sent under consideration
      FrString *target_words ;		// target phrase selected as translatn
      FrList *m_generalizationseq ;
      EbCorpusMetaInfo metainfo ;	// addt'l info from corpus
      EbFeatureVector m_features ;
      EBMTCorpus *m_corpus ;		// which corpus sourced this candidate
      size_t m_gaploc ;			// bitmask of gap positions in match
      uint32_t example_number ;		// which training example in the corpus
      uint32_t m_indexloc ;		// starting item in index
      EbIndexSpec m_whichindex ;	//  (lets us recover matched string)
      EbUSHORT m_numspans ;		// number of spans in m_spans
      EbUSHORT m_start ;		// start position in input sentence
      EbUSHORT orig_length ;		// length of match before tokenizing
      EbUSHORT m_sourceoffset ;		// first source word covered by chunk
      EbUSHORT match_length ;		// number of words in chunk
      EbUSHORT m_inputwords ;		// number of words of orig text matched
      EbUSHORT m_numtokens ;		// number of words repres. by tokens
      EbUSHORT source_length ;		// # of words in source half of pair
      EbUSHORT target_offset ;		// pos of target phrase in target sent
      EbUSHORT target_end ;		// last word of target sent in xlat
      EbUSHORT m_inputtext ;		// length of input in bytes
   public:
      EbGeneralizations *generalizations ;
   private: // methods
      EBMTCandidate() ;  // for internal use by sort()
      void initCommon() ;
      double alignQuality() const ; // un-normalized value, use internally
      double make_align_quality(double qual, size_t freq) {
#if ALIGNSCORE_POWER == 0
	 qual = freq * log(qual) ;
#elif ALIGNSCORE_POWER == 1
	 qual = freq * qual ;
#elif ALIGNSCORE_POWER == 2
	 qual = freq * qual * qual ;
#elif ALIGNSCORE_POWER == 3
	 qual = freq * qual * qual * qual ;
#else
	 qual = freq * ::pow(qual,ALIGNSCORE_POWER) ;
#endif
	 return qual ; 
         }
      double norm_align_quality() const
#if ALIGNSCORE_POWER == 0
	 { return ::exp(alignQuality() / frequency()) ; }
#elif ALIGNSCORE_POWER == 1
	 { return alignQuality() / frequency() ; }
#elif ALIGNSCORE_POWER == 2
	 { return ::sqrt(alignQuality() / frequency()) ; }
#elif ALIGNSCORE_POWER == 3
	 { return ::cbrt(alignQuality() / frequency()) ; }
#else
	 { return ::pow(alignQuality() / frequency(),1.0/ALIGNSCORE_POWER);}
#endif /* ALIGNSCORE_POWER */
   public: // methods
      void *operator new(size_t) { return allocator.allocate() ; }
      void operator delete(void *blk) { allocator.release(blk) ; }
      EBMTCandidate(const EBMTCandidate *original, bool min_copy = false) ;
      EBMTCandidate(uint32_t indexloc, EbIndexSpec whichindex,
		    uint32_t ex_number, size_t startpos, size_t endpos,
		    size_t matchstart, size_t matchlen, size_t srclen,
		    const FrTextSpan * const *spans) ;
      EBMTCandidate(size_t startpos, const FrString *srcword,
		    const FrString *translation, EBMTCandidate *next = 0) ;
      EBMTCandidate(const FrList *ssent, const FrList *tsent,
		    const FrList *match, size_t matchstart,
		    BiTextMap *bitext, FrVocabulary *vocab) ;
      ~EBMTCandidate() ;
      bool loadSentencePair(EBMTCorpus *corpus,
			    bool ignore_bitext = false,
			    bool ignore_morphology = false);

      // manipulators
      void setNext(EBMTCandidate *nxt) { m_next = nxt ; }
      void setMatchData(const EbCorpusMatches *matches) ;
      void setAlignScore(double newscore) ;
      void setAlignScores(const double *, size_t num_scores) ;
      void setDocContext(double d) ;
      void setSentContext(double s) ;
      void setPhraseContext(size_t context_size) ;
      void clearAlignQuality() ;
      void setAlignQuality(double qual) ;
      void incrAlignQuality(double qual, size_t freq) ;
      void setAlignQuality(const EBMTCandidate *other) ;
      void incrAlignQuality(const EBMTCandidate *other) ;
      void normalizeAlignQuality() ;
      void normalizeFeatureValues() ;
      void markUnalignable()
	 { setAlignScore(SCORE_UNALIGNABLE) ; clearAlignQuality() ; }
      void setScore(double newscore) ;
      void setConfidence(double conf) ;
      void setWeight(double weight) ;
      void setProbability(double p) ;
      void setOriginWeight(double w) ;
      void setMultiRef(double c) ;
      void setSourceFeatureScore(double s) ;
      void setSourceOffset(size_t offset)
	 { m_sourceoffset = (EbUSHORT)offset ; }
      void setSourcePosition(size_t startpos, size_t endpos,
			     size_t matchstart, size_t matchlen) ;
      void setBackSubstitutions(const EbCorpusMatches *) ;
      void setCoveredSpans(size_t N, const FrTextSpan * const *spans) ;
      EBMTCandidate *reverseList() ;
      EBMTCandidate *nconc(EBMTCandidate *) ;
      void deleteList() ;
      static void gc() { allocator.compact() ; }
      static void zapAll() { allocator.zapAll() ; }
//      static void zapAll() {} // we use so few now that we prune early....

      static BiTextMap *makeBiText(EBMTCorpus *corpus,
				   const FrList *swords,const FrList *twords,
				   FrCasemapTable number_charmap = 0,
				   const FrList *alignment = 0,
				   bool reverse_alignment = false) ;
      void freeCorrespondences() { metainfo.freeBitext() ; }
      void freeTargetSentence() ;
      void freeTargetWords() { free_object(target_words) ; target_words = 0 ; }
      void finishParsingMorphology() { metainfo.finishParsingMorphology() ; }
      bool alignMatch(EBMTCorpus *, bool keep_sentpair = false,
			bool relaxed = false,
			const FrSymHashTable *targetvocab = 0) ;
      FrList *backsubstitute(const FrList *translation,
			     const FrSymHashTable *targetvocab = 0,
			     size_t trg_start = (size_t)~0) ;

      void printScores(ostream &out) ;
      EBMTCandidate *sortByChunk() ;
      EBMTCandidate *sortByChunkAlign() ;
      EBMTCandidate *sortByChunkPosition() ;
      EBMTCandidate *sortByScore() ;

      // modifiers
      int listlength() const ;
      ostream &dumpCandidate(ostream &output) const ;
      void _() const ;
      void setInputLength(size_t len) { orig_length = (EbUSHORT)len ; }
      void setInputTextLength(size_t len) { m_inputtext = (EbUSHORT)len ; }
      void setInputWords(size_t w) { m_inputwords = (EbUSHORT)w ; }
      void setSourceWords(FrList *source, size_t gaps = NO_GAP) ;
      void setSourceSentence(FrList *source) ;
      void setChunkingBonus(double bonus) ;
      FrList *extractInputWords(const FrList *input_sent)
         { return (FrList*)input_sent->subseq(m_start,m_start+orig_length-1); }
      void coverage(size_t &firstword, size_t &lastword) const
         { firstword = m_start ; lastword = m_start + orig_length - 1 ; }
      void setFrequency(size_t freq) ;
      void setFrequency(size_t len, size_t freq) ;
      void setMass(double mass) ;
      void clearTargetWords() ;
      void setTargetWords(FrString *tw, size_t offset, size_t end,
			  size_t mask = ~0) ;
      void setGeneralizationSequence(FrList *gen_seq) ;
      void setBiTextMap(const BiTextMap *new_bitext) ;
      void setWordAlignments(const FrList *alignments)
	 { metainfo.wordAlignments(alignments) ; }
      void pruneBitextTarget(size_t t_start, size_t t_end)
	 { if (metainfo.bitext())
	    metainfo.bitext()->pruneTarget(sourceOffset(),
					   sourceOffset()+matchLength()-1,
					   t_start,t_end) ; }
      void equivClass(FrSymbol *cl) { metainfo.token(cl) ; }
      void gapPositions(size_t where) { m_gaploc = where ; }
      void numTokens(size_t num) { m_numtokens = (EbUSHORT)num ; }

      // accessors
      EBMTCandidate *next() const { return m_next ; }
      EBMTCandidate **nextPtr() { return &m_next ; }
      EBMTCandidate * const *nextPtr() const { return &m_next ; }
      double alignmentScore() const { return metainfo.alignmentScore() ; }
      const EbFeatureVector *features() const { return &m_features ; }
      EbFeatureVector *features() { return &m_features ; }
      double alignmentQuality() const
	 { return norm_align_quality() ; }
      double score() const { return metainfo.score() ; }
      double weight() const ;
      double confidence() const ;
      double candProbability() const ;
      double docContext() const ;
      double sentContext() const ;
      double chunkingBonus() const ;
      size_t inputTextLength() const { return m_inputtext ; }
      size_t inputLength() const { return orig_length ; }
      size_t inputStart() const { return m_start ; }
      size_t inputWords() const { return m_inputwords ; }
      size_t sourceLength() const { return source_length ; }
      const FrList *sourceWords() const { return source_words ; }
      FrString *targetWords() { return target_words ; }
      const FrString *targetWords() const { return target_words ; }
      const FrList *generalizationSequence() const
	 { return m_generalizationseq ; }
      const EbSentence *targetSentence() const { return target_sentence ; }
      EbSentence *targetSentence() { return target_sentence ; }
      EbIndexSpec sourceIndex() const { return m_whichindex ; }
      size_t gapPositions() const { return m_gaploc ; }
      bool haveGap() const { return m_gaploc != NO_GAP ; }
      bool gapAt(size_t offset) const
	 { return (m_gaploc & (1UL << offset)) != 0 ; }
      uint32_t indexLocation() const { return m_indexloc ; }
      uint32_t exampleNumber() const { return example_number ; }
      EBMTCorpus *sourceCorpus() const { return m_corpus ; }
      EBMTIndex *getIndex() const ;
      size_t numTokens() const { return m_numtokens ; }
      bool haveMetaScore() const { return metainfo.hasScore() ; }
      FrSymbol *token() const { return metainfo.token() ; }
      FrSymbol *equivClass() const { return metainfo.token() ; }
      size_t matchLength() const { return match_length ; }
      size_t frequency() const ;
      double totalMass() const ;
      size_t sourceOffset() const { return m_sourceoffset ; }
      size_t sourceEnd() const { return sourceOffset() + matchLength() - 1 ; }
      size_t targetOffset() const { return target_offset ; }
      size_t targetEnd() const { return target_end ; }
      size_t targetLength() const { return target_end - target_offset ; }
      BiTextMap *bitext() const { return metainfo.bitext() ; }
      BiTextMap *phraseBitext() const ; // use delete on result
      FrList *targetRestrictions() const ; // use free_object() on result
      FrList *targetSpans() const ; // use free_object() on result
      const FrList *wordAlignments() const { return metainfo.wordAlignments();}
      const double *metadataUserScores() const { return metainfo.userScores();}
      double phraseAlign(size_t &trg_start, size_t &trg_end,
			 size_t &trg_mask, size_t alt_num = 0) const
	 { return metainfo.phraseAlign(sourceOffset(),
				       sourceOffset()+matchLength()-1,
				       trg_start,trg_end,trg_mask,alt_num) ; }
      double phraseAlignSuperset(size_t &trg_start, size_t &trg_end,
				 size_t &trg_mask) const ;
      bool crossesPhrases() const ;
      FrList *morphology(size_t N) const
	 { return metainfo.morphology(N) ; }
      bool havePhraseAlignments() const ;
      size_t partOfSpeech(size_t N) const
	 { return metainfo.partOfSpeech(N) ; }
      size_t person(size_t N) const
	 { return metainfo.person(N) ; }
      size_t number(size_t N) const
	 { return metainfo.number(N) ; }
      size_t gender(size_t N) const
	 { return metainfo.gender(N) ; }
      size_t aspect(size_t N) const
	 { return metainfo.aspect(N) ; }
      const FrList *otherMorphology(size_t N) const
	 { return metainfo.otherMorphology(N) ; }
      bool hasPartOfSpeech(size_t N, size_t pos) const
	 { return metainfo.hasPartOfSpeech(N,pos) ; }
      bool hasPerson(size_t N, size_t pers) const
	 { return metainfo.hasPerson(N,pers) ; }
      bool hasNumber(size_t N, size_t num) const
	 { return metainfo.hasNumber(N,num) ; }
      bool hasGender(size_t N, size_t gend) const
	 { return metainfo.hasGender(N,gend) ; }
      bool hasAspect(size_t N, size_t asp) const
	 { return metainfo.hasAspect(N,asp) ; }
      bool completeMatch() const
	 { return sourceOffset() == 0 && matchLength() == sourceLength() ; }
      bool completeMapping() const
	 { return bitext() && bitext()->isCompleteMap() ; }
      bool haveBackSubstitutions() const ;
      size_t spansCovered() const { return m_numspans ; }
      const FrTextSpan * const *spans() const { return m_spans ; }
      const FrTextSpan *span(size_t N) const
	 { return (N < spansCovered()) ? m_spans[N] : 0 ; }
      const BiTextMap *correspondences() const { return metainfo.bitext() ; }
      int numTargetCorrespondences(int sword) const
	 { return bitext()->numTargetCorrespondences(sword) ; }
      int numTargetCorrespondences(int sword, int t_start, int t_end) const
	 { return bitext()->numTargetCorrespondences(sword,t_start,t_end) ; }
      bool hasTargetCorrespondences(int sword, int t_start, int t_end) const
	 { return bitext()->hasTargetCorrespondences(sword,t_start,t_end) ; }
      int nextTargetCorrespondence(int sword, int t_start) const
	 { return bitext()->nextTargetCorrespondence(sword,t_start) ; }
      int numSourceCorrespondences(int tword) const
	 { return bitext()->numSourceCorrespondences(tword) ; }
      int numSourceCorrespondences(int tword, int s_start, int s_end) const
	 { return bitext()->numSourceCorrespondences(tword,s_start,s_end) ; }
      bool hasSourceCorrespondences(int tword, int s_start, int s_end) const
	 { return bitext()->hasSourceCorrespondences(tword,s_start,s_end) ; }
      size_t firstSourceCorrespondence(int tword) const
	 { return bitext()->firstSourceCorrespondence(tword) ; }
      int wordsCorrespond(int sword, int tword) const
	 { return bitext()->wordsCorrespond(sword,tword) ; }

      static double log(double) ;
   } ;

//----------------------------------------------------------------------

#ifdef IMPLEMENT_EBCHUNKS

#ifndef __EBGLOBAL_H_INCLUDED
#include "ebglobal.h"
#endif

inline double EBMTCandidate::alignQuality() const
{ return m_features.value(featureID_quality) ; }

inline size_t EBMTCandidate::frequency() const
{ return (size_t)m_features.value(featureID_frequency) ; }

inline double EBMTCandidate::totalMass() const
{ return m_features.value(featureID_mass) ; }

//----------------------------------------------------------------------

inline void EBMTCandidate::setAlignScore(double newscore)
{ 
   metainfo.alignmentScore(newscore);
   m_features.setValue(featureID_alignment,newscore) ; 
}

inline void EBMTCandidate::setDocContext(double d)
{ m_features.setValue(featureID_doccontext,d) ; }

inline void EBMTCandidate::setSentContext(double s)
{ m_features.setValue(featureID_sntcontext,s) ; }

inline void EBMTCandidate::clearAlignQuality()
{ m_features.setValue(featureID_quality,0.0) ; }

inline void EBMTCandidate::setAlignQuality(double qual)
{ 
   qual = make_align_quality(qual,frequency()) ;
   m_features.setValue(featureID_quality,qual) ; 
}

inline void EBMTCandidate::incrAlignQuality(double qual, size_t freq)
{ 
   qual = make_align_quality(qual,freq) ;
   m_features.incrValue(featureID_quality,qual) ; 
}

inline void EBMTCandidate::setAlignQuality(const EBMTCandidate *other)
{ m_features.setValue(featureID_quality,other->alignQuality()) ; }

inline void EBMTCandidate::incrAlignQuality(const EBMTCandidate *other)
{ m_features.incrValue(featureID_quality,other->alignQuality()) ; }

inline void EBMTCandidate::normalizeAlignQuality()
{ m_features.setValue(featureID_quality,norm_align_quality()) ; }

inline void EBMTCandidate::setScore(double newscore)
{ 
   metainfo.score(newscore) ;
   m_features.setValue(featureID_score,newscore) ; 
}

inline void EBMTCandidate::setConfidence(double conf)
{ m_features.setValue(featureID_confidence,conf) ; }

inline void EBMTCandidate::setWeight(double weight)
{ m_features.setValue(featureID_weight,weight) ; }

inline void EBMTCandidate::setProbability(double p)
{ m_features.setValue(featureID_probability,p) ; }

inline void EBMTCandidate::setOriginWeight(double w)
{ m_features.setValue(featureID_originwt,w) ; }

inline void EBMTCandidate::setMultiRef(double c)
{ m_features.setValue(featureID_multiref,c) ; }

inline void EBMTCandidate::setSourceFeatureScore(double s)
{ m_features.setValue(featureID_srcfeat,s) ; }

inline void EBMTCandidate::setChunkingBonus(double bonus)
{ m_features.setValue(featureID_chunking,bonus) ; }

inline void EBMTCandidate::setFrequency(size_t freq)
{ m_features.setValue(featureID_frequency,freq) ; }

inline void EBMTCandidate::setMass(double mass)
{  m_features.setValue(featureID_mass,mass) ; }

//----------------------------------------------------------------------

inline double EBMTCandidate::weight() const
{ return m_features.value(featureID_weight) ; }

inline double EBMTCandidate::confidence() const
{ return m_features.value(featureID_confidence) ; }

inline double EBMTCandidate::candProbability() const
{ return m_features.value(featureID_probability) ; }

inline double EBMTCandidate::docContext() const
{ return m_features.value(featureID_doccontext) ; }

inline double EBMTCandidate::sentContext() const
{ return m_features.value(featureID_sntcontext) ; }

inline double EBMTCandidate::chunkingBonus() const
{ return m_features.value(featureID_chunking) ; }

#endif /* IMPLEMENT_EBCHUNKS */

/************************************************************************/
/************************************************************************/

EbCorpusMatches *find_matches(EBMTIndex *index, EbIndexSpec which,
			      const FrTextSpans *input_lattice,
			      TokenInfo **tokens,
			      EbCorpusMatches **active,
			      EbCorpusMatches *matches,
			      bool complete_only = false,
			      EbMatchFrequency * = 0) ;

EbCorpusMatches *finished_matches(EbCorpusMatches *&active,
				  EbCorpusMatches *matches,
				  EBMTIndex *index,
				  bool complete_only = false,
				  const EbMatchFrequency * = 0) ;

EBMTCandidate *build_token_info(FrTextSpans *input_lattice, EBMTCorpus *corpus,
				const Tokenizer *tokenizer, TokenInfo **tokens,
				FrCasemapTable number_charmap) ;

EBMTCandidate *find_generalized_chunks(FrTextSpans *input_lattice,
				       EBMTCorpus *corpus,
				       const Tokenizer *tokenizer,
				       TokenInfo **tokens,
				       FrCasemapTable number_charmap = 0,
				       const FrList *targetwords = 0) ;

EBMTCandidate *find_recursive_chunks(Tokenizer *tokenizer,
				     FrTextSpans *input_lattice,
				     EBMTCorpus *corpus,
				     int transmem_mode = EbTRANSMEM_OFF) ;
EbCorpusMatches *find_recursive_matches(Tokenizer *tokenizer,
					FrTextSpans *input_lattice,
					EBMTCorpus *corpus,
					int transmem_mode = EbTRANSMEM_OFF) ;

EBMTCandidate *find_structural_matches(FrTextSpans *input_lattice,
				       EBMTCorpus *corpus,
				       const EBMTCandidate *lex_matches,
				       int translation_memory_mode = 0,
				       FrCasemapTable number_charmap = 0) ;

EbCorpusMatches *EbFilterMatches(EbCorpusMatches *matches,
				 size_t min_length,
				 size_t max_freq,
				 const EbMatchFrequency * = 0) ;
size_t EbPrepDocMaxDups(const EBMTIndex *index) ;

void EbClearMatchCover() ;

bool EbIsDuplicateCandidate(const EBMTCandidate *c1,
			      const EBMTCandidate *c2) ;

bool EbIsDuplicateCandidateAnyScore(const EBMTCandidate *c1,
				      const EBMTCandidate *c2) ;

EBMTCandidate *EbCopyCandidates(const EBMTCandidate *cand) ;
void EbAdjustFrequency(EBMTCandidate*) ;

double EbSpanConfidence(size_t N, const FrTextSpan * const *spans,
			size_t &words, double &weight) ;

EBMTCandidate *EbMakeCandidates(EbCorpusMatches *matches,
				const FrTextSpans *input_lattice,
				EBMTCorpus *corpus,
				bool complete_matches = false,
				size_t cover_len = 0,
				const EbMatchFrequency *freq = 0,
				const FrSymHashTable *targetvocab = 0) ;
		// if cover_len!=0, it's the length of the input
		//   sentence, and the function is to tally corpus coverage
		// if freq!=0, it will be used to guide subsampling on a
		//   per-span basis

#endif /* !__EBCHUNKS_H_INCLUDED */

// end of file ebchunks.h //
