/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebutil.h	general utility functions			*/
/*  LastEdit: 08apr10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2006,2007,2008,2009,2010 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __EBUTIL_H_INCLUDED
#define __EBUTIL_H_INCLUDED

#include "FramepaC.h"

#ifdef FrSTRICT_CPLUSPLUS
# include <cstdio>
#else
# include <stdio.h>
#endif /* FrSTRICT_CPLUSPLUS */

//----------------------------------------------------------------------

#define MAX_EBMT_LINE 16000		// longest line of input we'll accept

typedef unsigned char BYTE ;
typedef unsigned char LONGbuffer[4] ;

//----------------------------------------------------------------------

#ifndef EXIT_SUCCESS
#define EXIT_SUCCESS 0
#endif

#ifndef EXIT_FAILURE
#define EXIT_FAILURE 127
#endif

/************************************************************************/
/************************************************************************/

inline bool is_number(const char *word)
{
   if (*word == '+' || *word == '-')
      word++ ;				// skip leading sign if present
   if (Fr_isdigit(*word))		// must have at least one digit
      {
      word++ ;
      while (*word)
         {
         if (!Fr_isdigit(*word) && *word != '.' && *word != ',')
	    return false ;
         else
	    word++ ;
         }
      return true ;
      }
   else
      return false ;
}

inline bool is_number(const FrSymbol *word)
{ return is_number(word->symbolName()) ; }

inline bool is_number(const FrString *word)
{ return is_number((const char *)word->stringValue()) ; }

//----------------------------------------------------------------------

char *unaccent(const char *word) ;
char *unaccent(const FrObject *word) ;
FrSymbol *cvt2unaccented_symbol(const FrObject *word) ;

int FrString_casefoldcmp(const FrObject *s1, const FrObject *s2) ;
bool EBMT_equal(FrSymbol *s1, const FrObject *s2) ;
inline bool EBMT_equal(const FrObject *s1, FrSymbol *s2)
   { return EBMT_equal(s2,s1) ; }
bool EBMT_equal(const FrObject *s1, const FrObject *s2) ;
bool EBMT_list_equiv(const FrList *l1, const FrList *l2) ;

FrList *remove_punctuation(FrList *words) ;

size_t EbWordCount(const char *words) ;
size_t EbWordCount(const FrString *words) ;
size_t EbWordCount(const FrObject *words) ;

void EBMT_set_word_delimiters(FrCharEncoding enc) ;
void EBMT_set_word_delimiters(const char *delim) ;

FrString *EBMT_apply_regex(FrString *line, FrRegExp *regex_list) ;
FrString *EBMT_apply_regex(const char *line, FrRegExp *regex_list,
			   size_t charwidth = 1, size_t stringlen=(size_t)-1) ;

bool EbInputAlreadyCanonical(bool canon) ;

bool read_EBMT_entry(FILE *fp, FrCasemapTable charmap,
		     char *&ssent, char *&tsent, char *&tags,
		     bool preserve_case = false,
		     FrRegExp *source_re_list = 0, FrRegExp *target_re = 0,
		     char const * const *abbrevs = 0) ;
bool read_EBMT_entry(FILE *fp, FrCharEncoding encoding, FrCasemapTable charmap,
		     char *&ssent, char *&tsent, char *&tags,
		     bool preserve_case = false,
		     FrRegExp *source_re_list = 0, FrRegExp *target_re = 0,
		     char const * const *abbrevs = 0) ;

FrList *EbFixDottedList(const FrList *original) ;

FrList *EbStripMorph(FrList *words, FrCharEncoding enc) ;

FrTextSpans *EbMakeLattice(const FrObject *input,
			   const FrList *morphology_classes,
			   bool keep_global_info = false) ;
void EbClearLattice(FrTextSpans *lattice) ;
void EbFreeLattice(FrTextSpans *lattice) ;
FrTextSpans *EbGetStructuralLattice(FrTextSpans *lattice) ;
void EbStoreStructuralLattice(FrTextSpans *lattice,
			      FrTextSpans *struct_lattice) ;

FrList *EbCvtString2Symbollist(const FrObject *str) ;
FrList *coerce_string_to_wordlist(const FrString *sent) ;

bool get_glossary_entry(FILE *fp, FrList *&source, FrList *&target,
			bool reverse_langs = false,
			bool strict = false, FrCasemapTable charmap = 0,
			char const * const *abbrevs = 0) ;

const FrSymbol *map_number(const FrSymbol *number,
			   FrCasemapTable number_charmap) ;
const FrSymbol *map_number(const char *number,
			   FrCasemapTable number_charmap) ;

const char *first_corpus_dir(const FrList *corpus_dir_list) ;

#endif /* !__EBUTIL_H_INCLUDED */

// end of file ebutil.cpp //
