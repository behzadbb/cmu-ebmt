/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.91							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebsent.h		EbSentence class			*/
/*  LastEdit: 20feb10							*/
/*									*/
/*  (c) Copyright 2001,2003,2004,2006,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __EBSENT_H_INCLUDED
#define __EBSENT_H_INCLUDED

#include "FramepaC.h"

/************************************************************************/
/************************************************************************/

typedef uint32_t EbWordID_t ;

class EbSentence
   {
   private:
      static FrAllocator allocator ;

   protected:
      const FrVocabulary *vocabulary ;
      EbWordID_t *wordIDs ;
      size_t numwords ;

   public:
      void *operator new(size_t) { return allocator.allocate() ; }
      void operator delete(void *blk) { allocator.release(blk) ; }
      EbSentence(const EbSentence &orig, size_t start = 0, size_t end = ~0) ;
      EbSentence(const FrVocabulary *vocab, const FrList *words) ;
      EbSentence(FrVocabulary *vocab, const FrList *words,
		 bool update_vocab, bool targetlang = false) ;
      EbSentence(FrSymHashTable *vocab, const FrList *words,
		 bool update_vocab) ;
      EbSentence(const FrVocabulary *vocab, const char *packed_data,
		 const char **end = 0) ;
      EbSentence(const FrVocabulary *vocab, EbWordID_t *word_IDs,
		 size_t num_words)
	    { vocabulary = vocab; wordIDs = word_IDs; numwords = num_words; }
      ~EbSentence() ;

      // manipulators
      EbSentence *subseq(size_t start, size_t end) const ;
      void setVocabulary(const FrVocabulary *vocab) { vocabulary = vocab ; }

      // access to contents
      bool good() const { return wordIDs != 0 ; }
      size_t length() const { return numwords ; }
      const char *word(size_t N) const ;
      EbWordID_t wordID(size_t N) const
	    { return (N < numwords) ? wordIDs[N] : FrVOCAB_WORD_NOT_FOUND ; }
      const FrVocabulary *activeVocabulary() const { return vocabulary ; }
      FrList *wordList() const ;
      FrList *wordList(size_t first, size_t last) const ;

      size_t locate(const FrList *phrase) const ;

      // I/O
      bool write(FILE *fp) const ;
      char *print() const ;

   } ;


//----------------------------------------------------------------------

#endif /* !__EBSENT_H_INCLUDED */

// end of file ebsent.h //
