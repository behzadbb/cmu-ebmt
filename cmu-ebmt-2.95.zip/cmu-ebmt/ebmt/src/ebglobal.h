/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebglobal.h		global variables for PanEBMT		*/
/*  LastEdit: 20apr10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*  with contributions by Aaron B. Phillips				*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __EBGLOBAL_H_INCLUDED
#define __EBGLOBAL_H_INCLUDED

#ifndef __FRCOMMON_H_INCLUDED
#include "frcommon.h"
#endif

#ifdef FrSTRICT_CPLUSPLUS
#  include <cstdlib>
#  include <fstream>
#  include <iomanip>
#else
#  include <iomanip.h>
#  include <fstream.h>
#  include <stdlib.h>
#endif /* FrSTRICT_CPLUSPLUS */

#ifndef __EBGENRE_H_INCLUDED
#include "ebgenre.h"
#endif

//----------------------------------------------------------------------

class FrRegExp ;
class EBMTConfig ;

class EBMTGlobalVariables
   {
   public: // variables
      EbGenreSettings *genre_list ;
      EbGenreSettings *genre ;
      EbGenreSettings *previous_genre ;
      FrList *_genre_names ;
      FrCharEncoding _char_encoding ;
      FrCasemapTable _uppercase_table ;
      FrCasemapTable _lowercase_table ;
      FrThreadPool  *_thread_pool ;

      size_t _max_dict_translations ;	// max. translations for a word
      size_t _max_sentence_length ;
      double _min_sentence_ratio ;
      double _max_sentence_ratio ;

      bool _Unicode_bswap ;
      bool _use_stdin ;
      bool _verbose ;
      bool _trace_matching ;
      bool _add_alignments ;
      bool _print_alignments ;
      bool _brute_force_align ;
      bool _allow_memory_mapping ;
      bool _map_corpus_subfiles ;
      bool _touch_all_memory ;
      bool _quiet_mode ;
      bool _monolingual_data ;
      bool _reverse_languages ;
      bool _underscore_hack ;
      bool _load_dict_readonly ;
      bool _load_corpus_readonly ;
      bool _use_compressed_index ;
      bool _match_accented ;
      bool _ignore_accents ;
      bool _may_cross_phrase_boundaries ;
      bool _keep_unigram_matches ;
      bool _allow_gapped_matches ;
      bool _context_biases_sampling ;
      bool _span_scores_product ;
      bool _span_scores_geometric_mean ;
      bool _compute_coverage ;
      bool _prune_by_freq ;
      bool _double_count_phrases ;
      bool _learn_dict_phrases ;
      bool _dict_keep_case ;
      bool _show_source_text ;
      bool _show_all_align_scores ;
      bool _show_gen_sequence ;
      bool _apply_backsubs ;
      bool _rescore_external_phrases ;
      bool _omit_subsumed ;
      bool _max_alts_are_global ;
      bool _preparing_for_doc ;

      size_t _featureID_score ;
      size_t _featureID_weight ;
      size_t _featureID_confidence ;
      size_t _featureID_probability ;
      size_t _featureID_frequency ;
      size_t _featureID_frequency1 ;
      size_t _featureID_frequency2 ;
      size_t _featureID_frequency3 ;
      size_t _featureID_frequency4 ;
      size_t _featureID_frequency5 ;
      size_t _featureID_frequencylong ;
      size_t _featureID_mass ;
      size_t _featureID_quality ;
      size_t _featureID_alignment ;
      size_t _featureID_chunking ;
      size_t _featureID_complete ;
      size_t _featureID_doccontext ;
      size_t _featureID_sntcontext ;
      size_t _featureID_phrcontext ;
      size_t _featureID_phrcontext1 ;
      size_t _featureID_phrcontext2 ;
      size_t _featureID_phrcontext3 ;
      size_t _featureID_phrcontext4 ;
      size_t _featureID_phrcontext5 ;
      size_t _featureID_phrcontext6 ;
      size_t _featureID_phrcontextplus ;
      size_t _featureID_originwt ;
      size_t _featureID_multiref ;
      size_t _featureID_srcfeat ;

      size_t _featureID_al_srccover ;
      size_t _featureID_al_inside ;
      size_t _featureID_al_outside ;
      size_t _featureID_al_matchgap ;
      size_t _featureID_al_length ;
      size_t _featureID_al_sentbound ;
      size_t _featureID_al_surfmatch ;
      size_t _featureID_al_excised ;

      size_t _featureID_spa_source ;
      size_t _featureID_spa_target ;
      size_t _featureID_spa_s2t ;
      size_t _featureID_spa_t2s ;

      size_t _num_align_features ;
      size_t _align_featureIDs[8] ;  // enough for either Heur. or SPA

      int    _tm_mode ;

      bool _EBMT_fill_gaps ;
      bool _allow_token_recursion ;
      bool _allow_cognates ;
      bool _index_original ;
      bool _strip_punct ;
      size_t _EBMT_word_order_similarity ;
      double _cognate_threshold ;

      size_t _max_word_ratio ;   // target may not be more than triple src len
      size_t _min_word_ratio ;   // target must be >= half as long as source

      size_t _min_phrase_length ;
      size_t _min_struct_match ;
      double _min_struct_lex ;

      size_t _context_window_size ;
      size_t _prepare_doc_minlen ;	// minimum match length to weight docs
      size_t _infer_min_frequency ;
      double _infer_max_contradictions ;

      char *_word_delimiters ;

      char *_token_source_filename ;

      char *_abbrevs_filename ;
      char **_abbrevs_list ;

      char *_alignment_filename ;
      char *_external_aligner ;
      char *_external_aligner_cfgfile ;
      size_t _external_align_minlen ;

      bool _compute_mutual_info ;
      bool _mutual_info_via_chisquared ;
      bool _mutual_info_oneway ;
      size_t _mutual_info_window ;

      char *_default_dictionary ;
      bool _export_dict_requested ;
      bool _export_corpus_requested ;
      char *_dict_export_file ;

      double _dict_HF_threshold ;
      double _dict_store_threshold ;
      size_t _dict_max_weight ;

      bool _showmem ;

      double _dict_correspondence_threshold ;
      double _dict_correspondence_threshold_low ;
      double _dict_correspondence_threshold_high ;
      size_t _dict_min_occurrences ;
      size_t _lines_per_chunk ;

      size_t _makedict_force ;
      size_t _dict_bias_low ;
      size_t _dict_bias_high ;
      double _dict_bias_range ;

      double _default_dict_score ;
      double _dict_score_root ;
      char * _dict_stems_file ;

      char * _morph_intro_str ;
      char * _morph_assign_str ;
      char * _morph_separator_str ;
      bool _uppercase_morph ;
      bool _morph_global_info ;
      bool _morph_replace_text ;
      FrList *_morph_classes ;
      FrList *_function_words ;

      // ABP Begin
      bool _use_morph ;
      size_t _debug_level ;
      double _cand_thresh ;
      double _score_discount ;
      double _freq_thresh ;
      double _generalization_weight ;
      char *_metainfo_file ;
      FrSymHashTable *_metainfo_ht ;
      char *_weights_file ;
      char *_rules_file ;
      const char *_config_file ;
      // ABP End

      size_t _autophrase_freq_thresh ;
      size_t _autophrase_max_length ;
      char * _autophrase_filename ;

      bool _dict_extracting_HF ;
      bool _dict_loading_counts ;
      bool _dict_storing_counts ;
      bool _ignore_source_case ;
      bool _canonicalized_input_data ;
      bool _reconstrain_bitext ;

      size_t _total_input_len ;
      size_t _total_match_count ;
      size_t _gapped_match_count ;
      size_t _ungapped_match_count ;
      size_t _skipped_training_instances ;
      size_t _covered_words ;
      size_t _covered_bytes ;
      size_t _total_words ;
      size_t _total_bytes ;
      size_t _total_arcs ;
      size_t _total_words_in_arcs ;

      const char *_dict_HF_filename ;
      const char *_dict_load_filename ;
      const char *_dict_store_filename ;

      // source-feature weights
      double _srcfeat_position ;

      FrSymbol *_symPERIOD ;
      FrSymbol *_symUPERIOD ;
      FrSymbol *_symMORPH ;
      FrSymbol *_symPOS ;
      FrSymbol *_symPERSON ;
      FrSymbol *_symNUMBER ;
      FrSymbol *_symGENDER ;
      FrSymbol *_symASPECT ;
      FrSymbol *_symNIL ;
      FrSymbol *_symROOT ;
      FrSymbol *_symSTRING ;
      FrSymbol *_symTOKEN ;
      FrSymbol *_symALIGN ;

      char *_source_language ;
      char *_target_language ;
      char *_source_synsets_file ;

      FrRegExp *_source_regex_list ;
      FrRegExp *_target_regex_list ;

      FrSymHashTable *_stemword_ht ;

      FrNamedEntitySpec *_named_entity_spec ;
      double _ne_default_score ;

      FrStruct *_pending_metadata ;
   protected:
      void applyDefaultConfig() ;

   public: // methods
      EBMTGlobalVariables() ;
      EBMTGlobalVariables(const EBMTGlobalVariables &) ;
      ~EBMTGlobalVariables() ;

      void applyConfiguration(const EBMTConfig *config) ;
      EBMTGlobalVariables *select() ;

      void free() ;
   } ;

//----------------------------------------------------------------------

extern EBMTGlobalVariables ebmt_vars ;
extern FrFeatureVectorMap EBfeature_map ;

/************************************************************************/
/*	Declarations of shortcuts for global variables			*/
/************************************************************************/

#define word_delimiters		ebmt_vars._word_delimiters
#define token_source_filename	ebmt_vars._token_source_filename
#define abbrevs_filename	ebmt_vars._abbrevs_filename
#define abbrevs_list		ebmt_vars._abbrevs_list
#define alignment_filename	ebmt_vars._alignment_filename
#define allow_memory_mapping 	ebmt_vars._allow_memory_mapping
#undef touch_all_memory
#define touch_all_memory	ebmt_vars._touch_all_memory
#define map_corpus_subfiles     ebmt_vars._map_corpus_subfiles
#define use_compressed_index	ebmt_vars._use_compressed_index
#define underscore_hack		ebmt_vars._underscore_hack
#define load_dict_readonly	ebmt_vars._load_dict_readonly
#define load_corpus_readonly	ebmt_vars._load_corpus_readonly
#define match_accented		ebmt_vars._match_accented
#define ignore_accents		ebmt_vars._ignore_accents
#define may_cross_phrase_boundaries	ebmt_vars._may_cross_phrase_boundaries
#define brute_force_align	ebmt_vars._brute_force_align
#define compute_coverage	ebmt_vars._compute_coverage
#undef canonicalized_input_data
#define canonicalized_input_data ebmt_vars._canonicalized_input_data
#define prune_by_freq		ebmt_vars._prune_by_freq
#define double_count_phrases	ebmt_vars._double_count_phrases
#define learn_dict_phrases	ebmt_vars._learn_dict_phrases
#define dict_keep_case		ebmt_vars._dict_keep_case
#define show_source_text	ebmt_vars._show_source_text
#define show_all_align_scores	ebmt_vars._show_all_align_scores
#define show_gen_sequence	ebmt_vars._show_gen_sequence
#define apply_backsubs		ebmt_vars._apply_backsubs
#define rescore_external_phrases ebmt_vars._rescore_external_phrases
#define omit_subsumed		ebmt_vars._omit_subsumed
#define max_alts_are_global	ebmt_vars._max_alts_are_global
#define preparing_for_doc	ebmt_vars._preparing_for_doc
#define prepare_doc_minlen	ebmt_vars._prepare_doc_minlen
#define context_window_size	ebmt_vars._context_window_size
#define keep_unigram_matches	ebmt_vars._keep_unigram_matches
#define allow_gapped_matches	ebmt_vars._allow_gapped_matches
#define context_biases_sampling	ebmt_vars._context_biases_sampling
#define span_scores_product	ebmt_vars._span_scores_product
#define span_scores_geometric_mean	ebmt_vars._span_scores_geometric_mean
#define compute_mutual_info 	ebmt_vars._compute_mutual_info
#define infer_min_frequency	ebmt_vars._infer_min_frequency
#define infer_max_contradictions ebmt_vars._infer_max_contradictions
#define tm_mode			ebmt_vars._tm_mode
#define makedict_force		ebmt_vars._makedict_force
#define dict_bias_high 		ebmt_vars._dict_bias_high
#define dict_bias_low 		ebmt_vars._dict_bias_low
#define dict_bias_range 	ebmt_vars._dict_bias_range
#define default_dict_score	ebmt_vars._default_dict_score
#define dict_score_root		ebmt_vars._dict_score_root
#define dict_stems_file		ebmt_vars._dict_stems_file
#define morph_intro_str		ebmt_vars._morph_intro_str
#define morph_assign_str	ebmt_vars._morph_assign_str
#define morph_separator_str	ebmt_vars._morph_separator_str
#define uppercase_morph		ebmt_vars._uppercase_morph
#define morph_global_info	ebmt_vars._morph_global_info
#define morph_replace_text	ebmt_vars._morph_replace_text
#define morph_classes		ebmt_vars._morph_classes
#define function_words		ebmt_vars._function_words
#define dict_correspondence_threshold ebmt_vars._dict_correspondence_threshold
#define dict_correspondence_threshold_high ebmt_vars._dict_correspondence_threshold_high
#define dict_correspondence_threshold_low ebmt_vars._dict_correspondence_threshold_low
#define dict_export_file 	ebmt_vars._dict_export_file
#define dict_extracting_HF 	ebmt_vars._dict_extracting_HF
#define dict_HF_filename 	ebmt_vars._dict_HF_filename
#define dict_HF_threshold 	ebmt_vars._dict_HF_threshold
#define dict_loading_counts 	ebmt_vars._dict_loading_counts
#define dict_load_filename 	ebmt_vars._dict_load_filename
#define dict_max_weight 	ebmt_vars._dict_max_weight
#define dict_min_occurrences 	ebmt_vars._dict_min_occurrences
#define dict_store_filename 	ebmt_vars._dict_store_filename
#define dict_store_threshold 	ebmt_vars._dict_store_threshold
#define dict_storing_counts 	ebmt_vars._dict_storing_counts
#define do_surrounding_match 	ebmt_vars._do_surrounding_match
#define EBMT_fill_gaps 		ebmt_vars._EBMT_fill_gaps
#define allow_token_recursion	ebmt_vars._allow_token_recursion
#define allow_cognates		ebmt_vars._allow_cognates
#define cognate_threshold	ebmt_vars._cognate_threshold
#define index_original		ebmt_vars._index_original
#define strip_punct		ebmt_vars._strip_punct
#define EBMT_word_order_similarity ebmt_vars._EBMT_word_order_similarity
#define default_dictionary	ebmt_vars._default_dictionary
#define export_dict_requested 	ebmt_vars._export_dict_requested
#define export_corpus_requested ebmt_vars._export_corpus_requested
#define lines_per_chunk 	ebmt_vars._lines_per_chunk
#define ignore_source_case	ebmt_vars._ignore_source_case
#define EBMT_genre_names	ebmt_vars._genre_names
#define align_threshold 	ebmt_vars.genre->_align_threshold
#define phrase_threshold 	ebmt_vars.genre->_phrase_threshold
#define max_alternatives	ebmt_vars.genre->_max_alternatives
#define max_alternatives1	ebmt_vars.genre->_max_alternatives1
#define max_duplicates 		ebmt_vars.genre->_max_duplicates
#define max_duplicates1 	ebmt_vars.genre->_max_duplicates1
#define max_match 		ebmt_vars.genre->_max_match
#define max_align_ambig		ebmt_vars.genre->_max_align_ambig
#define align_ambig_cutoff	ebmt_vars.genre->_align_ambig_cutoff
#define use_SPA			ebmt_vars.genre->_use_SPA
#define example_limit_lo	ebmt_vars.genre->_example_limit_lo
#define example_limit_hi	ebmt_vars.genre->_example_limit_hi
#define example_weight_start	ebmt_vars.genre->_example_weight_start
#define example_weight_end	ebmt_vars.genre->_example_weight_end
#define example_weight_range	ebmt_vars.genre->_example_weight_range
#define example_origin_weights	ebmt_vars.genre->_example_origin_weights
#define max_dict_translations	ebmt_vars._max_dict_translations
#define min_phrase_length	ebmt_vars._min_phrase_length
#define min_struct_match	ebmt_vars._min_struct_match
#define min_struct_lex		ebmt_vars._min_struct_lex
#define max_sentence_length 	ebmt_vars._max_sentence_length
#define max_sentence_ratio 	ebmt_vars._max_sentence_ratio
#define min_sentence_ratio 	ebmt_vars._min_sentence_ratio
#define max_word_ratio		ebmt_vars._max_word_ratio
#define min_word_ratio		ebmt_vars._min_word_ratio
#define total_input_len		ebmt_vars._total_input_len
#define total_match_count	ebmt_vars._total_match_count
#define gapped_match_count	ebmt_vars._gapped_match_count
#define ungapped_match_count	ebmt_vars._ungapped_match_count
#define skipped_training_instances ebmt_vars._skipped_training_instances
#define covered_words		ebmt_vars._covered_words
#define covered_bytes		ebmt_vars._covered_bytes
#define total_words		ebmt_vars._total_words
#define total_bytes		ebmt_vars._total_bytes
#define total_arcs		ebmt_vars._total_arcs
#define total_words_in_arcs	ebmt_vars._total_words_in_arcs
#define monolingual_data 	ebmt_vars._monolingual_data
#define mutual_info_oneway 	ebmt_vars._mutual_info_oneway
#define mutual_info_via_chisquared ebmt_vars._mutual_info_via_chisquared
#define mutual_info_window 	ebmt_vars._mutual_info_window
#define quiet_mode 		ebmt_vars._quiet_mode
#define reverse_languages 	ebmt_vars._reverse_languages
#define roots_are_stems		ebmt_vars._roots_are_stems
#define showmem			ebmt_vars._showmem
#define source_regex_list	ebmt_vars._source_regex_list
#define target_regex_list	ebmt_vars._target_regex_list
#define stemword_ht 		ebmt_vars._stemword_ht
#undef named_entity_spec
#define named_entity_spec	ebmt_vars._named_entity_spec
#define ne_default_score	ebmt_vars._ne_default_score
#define external_aligner	ebmt_vars._external_aligner
#define external_aligner_cfgfile	ebmt_vars._external_aligner_cfgfile
#define external_align_minlen	ebmt_vars._external_align_minlen

#define featureID_score		ebmt_vars._featureID_score
#define featureID_weight	ebmt_vars._featureID_weight
#define featureID_confidence	ebmt_vars._featureID_confidence
#define featureID_probability	ebmt_vars._featureID_probability
#define featureID_frequency	ebmt_vars._featureID_frequency
#define featureID_frequency1	ebmt_vars._featureID_frequency1
#define featureID_frequency2	ebmt_vars._featureID_frequency2
#define featureID_frequency3	ebmt_vars._featureID_frequency3
#define featureID_frequency4	ebmt_vars._featureID_frequency4
#define featureID_frequency5	ebmt_vars._featureID_frequency5
#define featureID_frequencylong	ebmt_vars._featureID_frequencylong
#define featureID_mass		ebmt_vars._featureID_mass
#define featureID_quality	ebmt_vars._featureID_quality
#define featureID_alignment	ebmt_vars._featureID_alignment
#define featureID_complete	ebmt_vars._featureID_complete
#define featureID_chunking	ebmt_vars._featureID_chunking
#define featureID_doccontext	ebmt_vars._featureID_doccontext
#define featureID_sntcontext	ebmt_vars._featureID_sntcontext
#define featureID_phrcontext	ebmt_vars._featureID_phrcontext
#define featureID_phrcontext1	ebmt_vars._featureID_phrcontext1
#define featureID_phrcontext2	ebmt_vars._featureID_phrcontext2
#define featureID_phrcontext3	ebmt_vars._featureID_phrcontext3
#define featureID_phrcontext4	ebmt_vars._featureID_phrcontext4
#define featureID_phrcontext5	ebmt_vars._featureID_phrcontext5
#define featureID_phrcontext6	ebmt_vars._featureID_phrcontext6
#define featureID_phrcontextplus	ebmt_vars._featureID_phrcontextplus
#define featureID_originwt	ebmt_vars._featureID_originwt
#define featureID_multiref	ebmt_vars._featureID_multiref
#define featureID_srcfeat	ebmt_vars._featureID_srcfeat

#define featureID_al_srccover	ebmt_vars._featureID_al_srccover
#define featureID_al_inside	ebmt_vars._featureID_al_inside
#define featureID_al_outside	ebmt_vars._featureID_al_outside
#define featureID_al_matchgap	ebmt_vars._featureID_al_matchgap
#define featureID_al_length	ebmt_vars._featureID_al_length
#define featureID_al_sentbound	ebmt_vars._featureID_al_sentbound
#define featureID_al_surfmatch	ebmt_vars._featureID_al_surfmatch
#define featureID_al_excised	ebmt_vars._featureID_al_excised

#define featureID_spa_source	ebmt_vars._featureID_spa_source
#define featureID_spa_target	ebmt_vars._featureID_spa_target
#define featureID_spa_s2t	ebmt_vars._featureID_spa_s2t
#define featureID_spa_t2s	ebmt_vars._featureID_spa_t2s

#define num_align_features	ebmt_vars._num_align_features
#define align_featureIDs	ebmt_vars._align_featureIDs

#undef Unicode_bswap
#define Unicode_bswap		ebmt_vars._Unicode_bswap
#define use_stdin		ebmt_vars._use_stdin
#undef verbose
#define verbose			ebmt_vars._verbose
#define trace_matching		ebmt_vars._trace_matching
#define print_EBMT_alignments	ebmt_vars._print_alignments
#define reconstrain_bitext	ebmt_vars._reconstrain_bitext

#undef char_encoding
#define char_encoding		ebmt_vars._char_encoding
#undef uppercase_table
#define uppercase_table		ebmt_vars._uppercase_table
#undef lowercase_table
#define lowercase_table		ebmt_vars._lowercase_table

#undef thread_pool
#define thread_pool		ebmt_vars._thread_pool

#define srcfeat_position	ebmt_vars._srcfeat_position

#define symPERIOD		ebmt_vars._symPERIOD
#define symUPERIOD		ebmt_vars._symUPERIOD
#undef symMORPH
#define symMORPH		ebmt_vars._symMORPH
#define symPOS			ebmt_vars._symPOS
#define symNUMBER		ebmt_vars._symNUMBER
#define symPERSON		ebmt_vars._symPERSON
#define symGENDER		ebmt_vars._symGENDER
#define symASPECT		ebmt_vars._symASPECT
#undef symNIL
#define symNIL			ebmt_vars._symNIL
#define symROOT			ebmt_vars._symROOT
#undef symSTRING
#define symSTRING		ebmt_vars._symSTRING
#define symTOKEN		ebmt_vars._symTOKEN
#define symALIGN		ebmt_vars._symALIGN

#define autophrase_freq_thresh	ebmt_vars._autophrase_freq_thresh
#define autophrase_max_length	ebmt_vars._autophrase_max_length
#define autophrase_filename	ebmt_vars._autophrase_filename

#define corpus_source_language	ebmt_vars._source_language
#define corpus_target_language	ebmt_vars._target_language

#define source_synsets_file	ebmt_vars._source_synsets_file

// ABP Begin
#define use_morph		ebmt_vars._use_morph
#define debug_level             ebmt_vars._debug_level
#define cand_thresh             ebmt_vars._cand_thresh
#define score_discount          ebmt_vars._score_discount
#define freq_thresh             ebmt_vars._freq_thresh
#define metainfo_file           ebmt_vars._metainfo_file
#define metainfo_ht             ebmt_vars._metainfo_ht
#define weights_file            ebmt_vars._weights_file
#define generalization_weight   ebmt_vars._generalization_weight
#define rules_file              ebmt_vars._rules_file
#define config_file             ebmt_vars._config_file
// ABP End

#define pending_metadata	ebmt_vars._pending_metadata

#endif /* !__EBGLOBAL_H_INCLUDED */

// end of file ebglobal.h //
