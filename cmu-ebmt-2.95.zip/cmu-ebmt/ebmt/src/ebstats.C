/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebconfig.h							*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 2009 Ralf Brown					*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "ebstats.h"
#include "ebcmatch.h"
#include "ebcorpus.h"
#include "ebutil.h"
#include "ebmt.h"
#include "ebglobal.h"

/************************************************************************/
/*	Methods for class EbMatchStatistics				*/
/************************************************************************/

EbMatchStatistics::EbMatchStatistics(size_t length, const char *text)
{
   m_length = 0 ;
   m_stats = FrNewC(unsigned,length*length) ;
   m_text = FrDupString(text) ;
   if (m_stats)
      m_length = length ;
   return ;
}

//----------------------------------------------------------------------

EbMatchStatistics::~EbMatchStatistics()
{
   FrFree(m_stats) ;	m_stats = 0 ;
   FrFree(m_text) ;	m_text = 0 ;
   m_length = 0 ;
   return ;
}

//----------------------------------------------------------------------

unsigned EbMatchStatistics::getCount(size_t start, size_t length) const
{
   if (start < m_length && length > 0 && start + length <= m_length)
      return m_stats[start * m_length + (length - 1)] ;
   else
      return 0 ;
}

//----------------------------------------------------------------------

void EbMatchStatistics::incrCount(size_t start, size_t length, size_t incr)
{
   if (start < m_length && length > 0 && start + length <= m_length)
      m_stats[start * m_length + (length - 1)] += (unsigned)incr ;
   return ;
}

//----------------------------------------------------------------------

unsigned &EbMatchStatistics::count(size_t start, size_t length)
{
   if (start < m_length && length > 0 && start + length <= m_length)
      return m_stats[start * m_length + (length - 1)] ;
   else
      return m_dummy ;
}

//----------------------------------------------------------------------

bool EbMatchStatistics::covered(size_t start, size_t length) const
{
   if (start < m_length && length > 0 && start + length <= m_length)
      return m_stats[start * m_length + (length - 1)] != 0 ;
   else
      return false ;
}

/************************************************************************/
/*	Methods for class EbMatchStatisticsEngine			*/
/************************************************************************/

EbMatchStatisticsEngine::EbMatchStatisticsEngine(const char *corpusdir)
{
   m_corpus = new EBMTCorpus(corpusdir,0,0,false) ;
   return ;
}

//----------------------------------------------------------------------

EbMatchStatisticsEngine::~EbMatchStatisticsEngine()
{
   delete m_corpus ;	m_corpus = 0 ;
   return ;
}

//----------------------------------------------------------------------

EbMatchStatistics *EbMatchStatisticsEngine::getStatistics(FrTextSpans *lattice)
{
   if (lattice->spanCount() == 0 || lattice->textLength() == 0)
      return 0 ;			// nothing to look up
   FrLocalAlloc(size_t,wordidx,1024,lattice->textLength()) ;
   if (!wordidx)
      {
      FrNoMemory("allocating array for word index") ;
      return 0 ;			// ran out of memory!
      }
   lattice->sort() ;
   size_t wordcount = 0 ;
   size_t prevstart = 0 ;
   for (size_t i = 1 ; i < lattice->spanCount() ; i++)
      {
      const FrTextSpan *span = lattice->getSpan(i) ;
      if (span->start() > prevstart)
	 {
	 // got a new word, so fill in the index array up to the new start
	 //   position with the previous word number, then update the count
	 //   and start position
	 for (size_t j = prevstart ; j < span->start() ; j++)
	    wordidx[j] = wordcount ;
	 wordcount++ ;
	 prevstart = span->start() ;
	 }
      }
   // finish up the last word in the lattice
   for (size_t j = prevstart ; j < lattice->textLength() ; j++)
      wordidx[j] = wordcount ;
   wordcount++ ;
   EbMatchStatistics *stats = new EbMatchStatistics(wordcount,
						    lattice->originalString());
   if (!stats)
      {
      FrLocalFree(wordidx) ;
      FrNoMemory("allocating match statistics") ;
      return 0 ;
      }
   Tokenizer *tokenizer = 0 ;
   if (m_corpus->getIndex())
       tokenizer = m_corpus->getIndex()->getTokenizer() ;
   EBMTCorpus *prev_corpus = EbSetActiveEBMTCorpus(m_corpus) ;
   EbCorpusMatches *matches
      = find_recursive_matches(tokenizer,lattice,m_corpus,tm_mode) ;
   EbSetActiveEBMTCorpus(prev_corpus) ;
   while (matches)
      {
      size_t startpos = wordidx[matches->startPosition()] ;
      size_t len = matches->inputMatch() ;
      size_t count = matches->totalMatches() ;
      stats->incrCount(startpos,len,count) ;
      // advance to next match record, deleting the current one
      EbCorpusMatches *tmp = matches ;
      matches = matches->next() ;
      delete tmp ;
      }
   FrLocalFree(wordidx) ;
   return stats ; 
}

//----------------------------------------------------------------------

EbMatchStatistics *EbMatchStatisticsEngine::getStatistics(const FrList *words)
{
   FrTextSpans *lattice = EbMakeLattice(words,morph_classes,morph_global_info);
   EbMatchStatistics *stats = getStatistics(lattice) ;
   EbFreeLattice(lattice) ;
   return stats ; 
}

//----------------------------------------------------------------------

EbMatchStatistics *EbMatchStatisticsEngine::getStatistics(const char *text)
{
   FrList *words = FrCvtString2Wordlist(text,0,0,char_encoding) ;
   EbMatchStatistics *stats = getStatistics(words) ;
   free_object(words) ;
   return stats ; 
}

//----------------------------------------------------------------------


// end of file ebstats.cpp //
