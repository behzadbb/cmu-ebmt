/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebxalign.cpp	external-aligner interface			*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 2005,2009 Ralf Brown					*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#if defined(__GNUC__)
#  pragma implementation "ebalign.h"
#endif

#include "ebmt.h"
#include "ebalign.h"
#include "ebutil.h"
#include "ebglobal.h"

/************************************************************************/
/*	Global Variables for this module				*/
/************************************************************************/

static istream *xalign_in ;
static ostream *xalign_out ;
static int xalign_pipe_in ;
static int xalign_pipe_out ;
static bool aligner_running = false ;

/************************************************************************/
/************************************************************************/

bool EbStartExternalAligner()
{
   if (!external_aligner || !*external_aligner)
      return true ;
   if (!aligner_running &&
       FrExecProgram(0,0,0,0,xalign_pipe_in,xalign_pipe_out,xalign_in,
		     xalign_out,cerr,external_aligner,
		     external_aligner_cfgfile,0))
      aligner_running = true ;
   else
      aligner_running = false ;
   return aligner_running ;
}

//----------------------------------------------------------------------

bool EbStopExternalAligner()
{
   if (aligner_running)
      {
      FrShutdownPipe(xalign_in,xalign_out,xalign_pipe_in,xalign_pipe_out) ;
      aligner_running = false ;
      }
   return false ;
}

//----------------------------------------------------------------------

bool EbExternalAlignerRunning()
{
   return aligner_running ;
}

//----------------------------------------------------------------------

FrList *EbApplyExternalAligner(const char *source, const char *target)
{
   FrList *alignments = 0 ;
   if (aligner_running)
      {
      (*xalign_out) << source << endl << target << endl << flush ;
      while (!xalign_in->eof())
	 {
	 char line[FrMAX_LINE] ;
	 xalign_in->getline(line,sizeof(line)) ;
	 char *lineptr = line ;
	 FrSkipWhitespace(lineptr) ;
	 if (Fr_strnicmp(lineptr,"NEWSENT",7) == 0)
	    break ;
	 if (*lineptr == ';')
	    {
	    while (*lineptr == ';' || Fr_isspace(*lineptr))
	       lineptr++ ;
	    }
	 while (FrSkipWhitespace(lineptr) != '\0')
	    {
	    FrObject *obj = string_to_FrObject(lineptr) ;
	    pushlist(obj,alignments) ;
	    }
	 }
      }
   return alignments ;
}

//----------------------------------------------------------------------

FrList *EbApplyExternalAligner(const FrList *source, const FrList *target)
{
   FrString *s = new FrString(source) ;
   FrString *t = new FrString(target) ;
   const char *sourcestr = s ? s->stringValue() : "" ;
   const char *targetstr = t ? t->stringValue() : "" ;
   FrList *alignments = EbApplyExternalAligner(sourcestr,targetstr) ;
   free_object(s) ;
   free_object(t) ;
   return alignments ;
}

// end of file ebxalign.cpp //

