/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.92							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebauto.cpp	automatic phrase-translation pre-computation	*/
/*  LastEdit: 18mar10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "ebchunks.h"
#include "ebcorpus.h"
#include "ebutil.h"
#include "ebmt.h"
#include "ebglobal.h"

/************************************************************************/
/************************************************************************/

static bool auto_align_phrase(uint32_t *IDs, size_t N, size_t freq,
			      const class FrBWTIndex *, va_list args)
{
   FrVarArg(EBMTIndex *,index) ;
   FrVarArg(size_t *,num_ngrams) ;
   FrVarArg(size_t *,num_phrases_added) ;
   FrVarArg(FILE *,auto_fp) ;
   FrVocabulary *vocab = index->vocabulary() ;
   FrList *phrase = 0 ;
   for (size_t i = 0 ; i < N ; i++)
      pushlist(new FrConstString(vocab->nameForID(IDs[i])),phrase) ;
   FrTextSpans *lattice = EbMakeLattice(phrase,morph_classes,
					morph_global_info) ;
   EBMTCandidate *candidates = find_full_chunks(IDs, N, lattice,
						index->getCorpus(),
						EbIndex_Main) ;
   if (candidates)
      (*num_ngrams)++ ;
   candidates = candidates->sortByScore() ;
   double totalfreq = 0.0 ;
   EBMTCandidate *cand ;
   for (cand = candidates ; cand ; cand = cand->next())
      totalfreq += cand->frequency() ;
   size_t num_xlat = 0 ;
   for (cand = candidates ; cand ; cand = cand->next())
      {
      if (cand->matchLength() < N || !cand->targetWords())
	 continue ;
      if (++num_xlat > max_alternatives) // restrict number of alternatives
	 continue ;
      (*num_phrases_added)++ ;
      FrString *source = new FrString(phrase) ;
      const char *trgstr = FrPrintableName(cand->targetWords()) ;
      FrString *target = new FrString(trgstr) ;
      fprintf(auto_fp,";;;(SCORE %f)(FREQ %lu)\n%s\n\t%s\n\n",
	      cand->score(),(unsigned long)freq,
	      source->stringValue(),target->stringValue()) ;
      free_object(source) ;
      free_object(target) ;
      }
   candidates->deleteList() ;
   EbFreeLattice(lattice) ;
   free_object(phrase) ;
   return true ;			// continue iterating
}

//----------------------------------------------------------------------

void generate_auto_phrases(EBMTIndex *index)
{
   if (autophrase_max_length <= 1)
      return ;				// nothing to do
   FILE *auto_fp = 0 ;
   if (autophrase_filename && *autophrase_filename)
      auto_fp = fopen(autophrase_filename,"a") ;
   if (!auto_fp)
      {
      cout << "; skipping automatic phrase extraction because there is no output file"
	   << endl ;
      return ;
      }
   // enumerate all n-grams with frequency greater than the
   // threshold and pre-compute alignments for them, adding any
   // successful alignments to the corpus
   FrVocabulary *vocab = index->vocabulary() ;
   if (vocab)
      vocab->createReverseMapping() ;
   if (!index->exampleInfoLoaded())
      index->loadExampleInfo(false) ;	// make sure sent-length info loaded
   FrTimer timer ;
   size_t num_ngrams = 0 ;
   size_t count = 0 ;
   cout << "; extracting/aligning common phrases in corpus" << endl ;
   size_t prev_ngrams = 0 ;
   size_t old_dups = max_duplicates ;
   if (max_duplicates < 200)
      max_duplicates = 200 ;
   size_t old_alts = max_alternatives ;
   if (max_alternatives < 5)
      max_alternatives = 5 ;
   bool old_quiet = EBMT_quiet_mode(true) ;
   for (size_t len = 2 ; len <= autophrase_max_length ; len++)
      {
      cout << ";   phrase length " << len << endl ;
      if (!index->enumerateNGrams(EbIndex_Main,len,autophrase_freq_thresh,
				  false, auto_align_phrase,index,
				  &num_ngrams,&count,auto_fp))
	 {
	 cout << ";   error while adding automatic phrases of length "
	       << len << " to index" << endl ;
	 break ;
	 }
      if (prev_ngrams == num_ngrams)
	 break ;			// no sense trying anything longer....
      cout << ";\tfound " << (num_ngrams-prev_ngrams)
	    << " distinct phrases" << endl ;
      prev_ngrams = num_ngrams ;
      }
   EBMT_quiet_mode(old_quiet) ;
   max_duplicates = old_dups ;
   max_alternatives = old_alts ;
   cout << "; found " << num_ngrams << " phrases ("
	 << count << " translations) of frequency "
	 << autophrase_freq_thresh << " or higher\n;  in "
	 << timer.readsec() << " seconds" << endl ;
   if (auto_fp)
      {
      fflush(auto_fp) ;
      fclose(auto_fp) ;
      }
   return ;
}

// end of file ebauto.cpp //
