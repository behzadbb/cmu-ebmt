/************************************************************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebdict2.cpp	EBMT translation dictionary - update functions	*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2006,2009 Ralf Brown					*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#if defined(__GNUC__)
#  pragma implementation "dict.h"
#  pragma implementation "ebdict.h"
#endif

#include "dict.h"
#include "ebdict.h"
#include "ebutil.h"
#include "ebglobal.h"

/************************************************************************/
/*	Helper functions						*/
/************************************************************************/

static int extract_CASE_marker(const FrList *markers)
{
   for ( ; markers ; markers = markers->rest())
      {
      FrObject *marker = markers->first() ;
      if (marker == makeSymbol("NOM"))
	 return CASE_nominative ;
      else if (marker == makeSymbol("DAT"))
	 return CASE_dative ;
      else if (marker == makeSymbol("GEN"))
	 return CASE_genitive ;
      else if (marker == makeSymbol("ACC"))
	 return CASE_accusative ;
      else if (marker == makeSymbol("LOC"))
	 return CASE_locative ;
      else if (marker == makeSymbol("INS"))
	 return CASE_instrumental ;
      else if (marker == makeSymbol("VOC"))
	 return CASE_vocative ;
      }
   return CASE_unknown ;
}

//----------------------------------------------------------------------

static int extract_POS_marker(const FrList *markers)
{
   for ( ; markers ; markers = markers->rest())
      {
      FrObject *marker = markers->first() ;
      if (marker == makeSymbol("N") || marker == makeSymbol("NOUN"))
	 return POS_Noun ;
      else if (marker == makeSymbol("V") || marker == makeSymbol("VERB"))
	 return POS_Verb ;
      else if (marker == makeSymbol("A") || marker == makeSymbol("ADJ") ||
	       marker == makeSymbol("ADJECTIVE"))
	 return POS_Adjective ;
      else if (marker == makeSymbol("ADV") || marker == makeSymbol("ADVERB"))
	 return POS_Adverb ;
      else if (marker == makeSymbol("CONJ") ||
	       marker == makeSymbol("CONJUNC") ||
	       marker == makeSymbol("CONJUNCTION"))
	 return POS_Conjunction ;
      else if (marker == makeSymbol("DET") ||
	       marker == makeSymbol("DETERMINER") ||
	       marker == makeSymbol("ARTICLE"))
	 return POS_Determiner ;
      else if (marker == makeSymbol("PREP") ||
	       marker == makeSymbol("PREPOSITION"))
	 return POS_Preposition ;
      else if (marker == makeSymbol("PM") || marker == makeSymbol("POSTMOD"))
	 return POS_Postmod ;
      }
   return POS_unknown ;
}

//----------------------------------------------------------------------

static size_t find_empty_def(FrObject **defs, size_t defs_used)
{
#if 1
   // since we currently never remove anything from the 'defs' array, we can
   // simply always return the next item past the last one in use
   (void)defs ;
#else
   if (availdefs)
      {
      for (size_t i = 0 ; i < defs_used ; i++)
	 {
	 if (defs[i] == 0)
	    {
	    availdefs-- ;
	    return i ;
	    }
	 }
      }
#endif
   return defs_used ;
}

//----------------------------------------------------------------------

static void nomem_headword()
{
   FrNoMemory("while adding new head word to dictionary") ;
   return ;
}

//----------------------------------------------------------------------

static void nomem_adding()
{
   FrNoMemory("while adding word to dictionary") ;
   return ;
}

/************************************************************************/
/************************************************************************/

bool Dictionary::unmapHeads()
{
   if (heads_mapped)
      {
      DictWordInfo *newinfo = FrNewN(DictWordInfo,numheads+DICTIONARY_SLACK) ;
      if (!newinfo)
	 {
	 nomem_headword() ;
	 return false ;
	 }
      memcpy(newinfo,headinfo,numheads * sizeof(DictWordInfo)) ;
      headinfo = newinfo ;
      heads_size = numheads + DICTIONARY_SLACK ;
      heads_mapped = false ;
      }
   return true ;
}

//----------------------------------------------------------------------

bool Dictionary::unmapDefinitions(size_t expand_by)
{
   if (definitions_mapped)
      {
      DictDefItem *newdefs = FrNewN(DictDefItem,
				    definition_items + expand_by) ;
      if (!newdefs)
	 {
	 nomem_adding() ;
	 return false ;
	 }
      memcpy(newdefs,definitions,definition_items * sizeof(DictDefItem)) ;
      definitions = newdefs ;
      definition_size = definition_items + expand_by ;
      definitions_mapped = false ;
      }
   return true ;
}

//----------------------------------------------------------------------

size_t Dictionary::add_dict_definition(const FrObject *translation)
{
   if (translation && translation->consp() && !((FrList*)translation)->rest())
      translation = ((FrList*)translation)->first() ;
   size_t idx = getIndex(translation) ;
   if (idx == (size_t)-1)
      {
      idx = find_empty_def(defs,numdefs) ;
      if (idx >= defs_size)
	 {
	 // we must expand the 'defs' array
	 if (!expandDefsBuffer())
	    return (size_t)-1 ;
	 }
      defs[idx] = translation ? translation->deepcopy() : 0 ;
      if (defhash)
	 {
	 FrHashEntryObject item(defs[idx],(void*)idx) ;
	 defhash->add(&item) ;
	 }
      if (idx >= numdefs)
	 numdefs++ ;
      }
   return idx ;
}

//----------------------------------------------------------------------

void Dictionary::adjustLoc(size_t boundary, int adjust)
{
   if (adjust && boundary < definition_items)
      {
      if (!unmapHeads())
	 {
	 FrNoMemory("while creating gap for new dictionary definition") ;
	 return ;
	 }
      for (size_t i = 0 ; i < numheads ; i++)
	 {
	 DictWordInfo *info = &headinfo[i] ;
	 size_t loc = info->index() ;
	 if (loc > boundary)
	    {
	    if (adjust < 0)
	       loc -= (size_t)(-adjust) ;
	    else
	       loc += adjust ;
	    info->setIndex(loc) ;
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

bool Dictionary::expandDefinitionBuffer(size_t extra)
{
   size_t limit1 = 50000 ;
   size_t limit2 = 200000L ;
   size_t expand_by ;
   if (definition_size == 0)
      expand_by = DICTIONARY_SLACK ;
   else if (definition_size < limit1)
      expand_by = definition_size*2 ;
   else if (definition_size < limit2)
      expand_by = definition_size ;
   else
      expand_by = definition_size/2 ;
   if (extra + DICTIONARY_SLACK >= expand_by)
      expand_by = extra + DICTIONARY_SLACK ;
   DictDefItem *newdefs ;
   if (definitions_mapped)
      {
      newdefs = FrNewN(DictDefItem,definition_size+expand_by) ;
      if (!newdefs)
	 {
	 nomem_adding() ;
	 return false ;
	 }
      memcpy(newdefs,definitions,definition_items * sizeof(DictDefItem)) ;
      definitions_mapped = false ;
      }
   else
      {
      newdefs = FrNewR(DictDefItem,definitions,definition_size+expand_by) ;
      if (!newdefs)
	 {
	 nomem_adding() ;
	 return false ;
	 }
      }
   memset(newdefs+definition_size,'\0',expand_by*sizeof(DictDefItem)) ;
   definition_size += expand_by ;
   definitions = newdefs ;
   return true ;
}


//----------------------------------------------------------------------

bool Dictionary::expandDefsBuffer()
{
   size_t prev_size = defs_size ;
   size_t limit1 = 20000 ;
   size_t limit2 = 80000L ;
   if (defs_size == 0)
      defs_size = DEFINITION_SLACK ;
   else if (defs_size < limit1)
      defs_size += defs_size*2 ;
   else if (defs_size < limit2)
      defs_size += defs_size ;
   else
      defs_size += defs_size/2 ;
   FrObject **newdefs = FrNewR(FrObject*,defs,defs_size);
   if (!newdefs)
      {
      FrNoMemory("while adding translation to dictionary") ;
      defs_size = prev_size ;
      return false ;
      }
   memset(newdefs+prev_size,'\0',(defs_size-prev_size)*sizeof(FrObject*)) ;
   defs = newdefs ;
   return true ;
}

//----------------------------------------------------------------------

size_t Dictionary::newHeadWord(const FrSymbol *word, size_t frequency,
			       bool already_sorted)
{
   const char *wordname = word ? word->symbolName() : "" ;
   size_t len = strlen(wordname) + 1 ;
   if (names_mapped)
      {
      char *newnames = FrNewN(char,names_size + HEADNAMES_INCR) ;
      if (newnames)
	 {
	 memcpy(newnames,headwordnames,names_size) ;
	 headwordnames = newnames ;
	 names_alloc = names_size + HEADNAMES_INCR ;
	 names_mapped = false ;
	 }
      else
	 {
	 nomem_headword() ;
	 return FrVOCAB_WORD_NOT_FOUND ;
	 }
      }
   else if (names_size + len >= names_alloc)
      {
      char *newnames = FrNewR(char,headwordnames,names_alloc+HEADNAMES_INCR) ;
      if (!newnames)
	 {
	 nomem_headword() ;
	 return FrVOCAB_WORD_NOT_FOUND ;
	 }
      headwordnames = newnames ;
      names_alloc += HEADNAMES_INCR ;
      }
   memcpy(headwordnames+names_size,wordname,len) ;
   if (heads_mapped)
      {
      if (!unmapHeads())
	 return FrVOCAB_WORD_NOT_FOUND ;
      }
   else if (numheads >= heads_size)
      {
      DictWordInfo *newinfo = FrNewR(DictWordInfo,headinfo,
				     heads_size + DICTIONARY_SLACK) ;
      if (!newinfo)
	 {
	 nomem_headword() ;
	 return FrVOCAB_WORD_NOT_FOUND ;
	 }
      headinfo = newinfo ;
      heads_size += DICTIONARY_SLACK ;
      }
   size_t index = numheads ;
   if (!already_sorted)
      {
      index = insertionPoint(wordname) ;
      // make gap for the new head word by shifting everything after it by one
      if (index < numheads)
	 {
	 // make room for the new name and word-info
	 size_t rest = numheads - index ;
	 memmove(headinfo+index+1,headinfo+index,rest*sizeof(headinfo[0])) ;
	 }
      }
   // insert the new headword
   new (&headinfo[index]) DictWordInfo(names_size,definition_items,frequency) ;
   // update buffer sizes ;
   names_size += len ;
   numheads++ ;
   return index ;
}

//----------------------------------------------------------------------

bool Dictionary::shiftDefItems(size_t boundary, size_t oldsize,
				 size_t newsize)
{
   int adjust = (newsize > oldsize) ? (int)(newsize-oldsize)
                                    : -((int)(oldsize-newsize)) ;
   // increase the size of our definition list buffer if necessary
   size_t extra = DEFINITION_SLACK ;
   if (adjust > 0 && definition_items + adjust >= definition_size)
      extra += adjust ;
   if (!unmapDefinitions(extra))
      return false ;
   if (adjust > 0 && definition_items + adjust >= definition_size &&
       !expandDefinitionBuffer((size_t)adjust))
      return false ;
   if (adjust != 0)
      {
      adjustLoc(boundary,adjust) ;
      memmove(&definitions[boundary+newsize],&definitions[boundary+oldsize],
	      sizeof(DictDefItem)*(definition_items-(boundary+oldsize))) ;
      definition_items += adjust ;
      }
   return true ;
}

//----------------------------------------------------------------------

bool Dictionary::defineWord(const FrSymbol *word, const FrList *translations,
			      size_t frequency,size_t count, int POS, int CASE)
{
   if (readonly)
      return false ;			// can't update read-only dict!
   size_t entry_index = findWord(word) ;
   size_t newsize = translations->listlength() ;
   size_t loc ;
   if (entry_index != FrVOCAB_WORD_NOT_FOUND)
      {
      if (!translations)		// !!! needs to be changed to REMOVE
	 return false ;			//   the head word
      loc = headinfo[entry_index].index() ;
      // need to delete old definition and insert new one
      size_t oldsize = definition_length(loc) ;
      if (!shiftDefItems(loc,oldsize,newsize))
	 return false ;
      if (!unmapHeads())
	 return false ;
      headinfo[entry_index].incrFreq(frequency) ;
      }
   else if (!translations)
      return true ;
   else
      {
      // append the new word to the dictionary
      // increase the size of our definition list buffer if necessary
      if (definition_items + newsize >= definition_size &&
	  !expandDefinitionBuffer(newsize))
	 return false ;
      newHeadWord(word) ;
      loc = definition_items ;
      definition_items += newsize ;
      }
   for ( ; translations ; translations = translations->rest())
      {
      FrObject *translation = translations->first() ;
      size_t xlatloc = add_dict_definition(translation) ;
      bool last = (translations->rest() == 0) ;
      new (&definitions[loc++]) DictDefItem(count,xlatloc,POS,CASE,last) ;
      }
   dict_changed = true ;
   return true ;
}

//----------------------------------------------------------------------
// input: 'word'  name of word to define, replacing any previous definitions
//	  'translations'  list of lists containing one translation&count each

bool Dictionary::defineWordCounted(const FrSymbol *word,
				     const FrList *translations,
				     size_t frequency)
{
   if (readonly)
      return false ;			// can't update read-only dict!
   size_t entry_index = findWord(word) ;
   size_t newsize = translations->listlength() ;
   size_t loc ;
   if (entry_index != FrVOCAB_WORD_NOT_FOUND)
      {
      if (!translations)		// !!! needs to be changed to REMOVE
	 return false ;			//   the head word
      loc = headinfo[entry_index].index() ;
      // need to delete old definition and insert new one
      size_t oldsize = definition_length(loc) ;
      if (!shiftDefItems(loc,oldsize,newsize))
	 return false ;
      if (!unmapHeads())
	 return false ;
      headinfo[entry_index].setFrequency(frequency) ;
      }
   else if (!translations)
      return true ;
   else
      {
      // append the new word to the dictionary
      // increase the size of our definition list buffer if necessary
      if (definition_items + newsize >= definition_size &&
	  !expandDefinitionBuffer(newsize))
	 return false ;
      newHeadWord(word,frequency) ;
      loc = definition_items ;
      definition_items += newsize ;
      }
   for ( ; translations ; translations = translations->rest())
      {
      FrList *translation = (FrList*)translations->first() ;
      if (!translation || !translation->consp())
	 continue ;
      FrNumber *cnt = (FrNumber*)translation->second() ;
      if (!cnt || !cnt->numberp())
	 continue ;
      size_t count = cnt->intValue() ;
      size_t xlatloc = add_dict_definition(translation->first()) ;
      int POS = extract_POS_marker(translation->rest()) ;
      int CASE = extract_CASE_marker(translation->rest()) ;
      bool last = (translations->rest() == 0) ;
      new (&definitions[loc++]) DictDefItem(count,xlatloc,POS,CASE,last) ;
      }
   dict_changed = true ;
   return true ;
}

//----------------------------------------------------------------------

bool Dictionary::addDefinition(const FrSymbol *word,
				 const FrObject *translation,
				 size_t frequency, size_t count,
				 int POS, int CASE)
{
   if (readonly)
      return false ;			// can't update read-only dict!
   size_t entry_index = findWord(word) ;
   if (translation && translation->consp() && !((FrList*)translation)->rest())
      translation = ((FrList*)translation)->first() ;
   if (entry_index != FrVOCAB_WORD_NOT_FOUND)
      {
      // update the total word frequency, if appropriate
      if (frequency > 0)
	 {
	 if (!unmapHeads())
	    return false ;
	 headinfo[entry_index].incrFreq(frequency) ;
	 dict_changed = true ;
	 }
      // check if the translation is already in the definition list
      size_t loc = headinfo[entry_index].index() ;
      for ( ; loc < definition_items ; loc++)
	 {
	 if (sameTranslation(&definitions[loc],translation))
	    return true ;		// already defined, thus successful
	 if (definitions[loc].isLast())
	    break ;
	 }
      if (loc >= definition_items && definition_items > 0)
	 loc = definition_items - 1 ;
      // definition is not in list, so add it
      // expand the definition list buffer if necessary
      if (!shiftDefItems(loc,1,2))
	 return false ;
      definitions[loc].setLast(false) ;
      loc++ ;			// point at gap we've created
      // insert the new translation into the gap we just made
      size_t xlatloc = add_dict_definition(translation) ;
      new (&definitions[loc]) DictDefItem(count,xlatloc,POS,CASE,true) ;
      dict_changed = true ;
      }
   else
      {
      FrList *xlat = new FrList(translation) ;
      bool OK = defineWord(word,xlat,frequency,count,POS,CASE) ;
      (void)poplist(xlat) ;
      return OK ;
      }	     
   return true ;
}

//----------------------------------------------------------------------
// input: 'word'  name of word for which to add an additional definition
//	 'translation'	list consisting of new definition and its count

bool Dictionary::addDefinitionCounted(const FrSymbol *word,
					const FrList *translation,
					size_t frequency)
{
   if (readonly)
      return false ;			// can't update read-only dict!
   FrObject *trans = translation->first() ;
   FrNumber *cnt = (FrNumber*)translation->second() ;
   if (!trans || !cnt || !cnt->numberp())
      return false ;
   long count = cnt->intValue() ;
   if (count < 0)
      count = 0 ;
   int POS = extract_POS_marker(translation->rest()) ;
   int CASE = extract_CASE_marker(translation->rest()) ;
   return addDefinition(word,trans,frequency,(size_t)count,POS,CASE) ;
}

//----------------------------------------------------------------------

bool Dictionary::addDefinition(const char *word, const char *translation)
{
   if (!word || readonly)
      return false ;
   const char *w = word ;
   char tmp[FrMAX_SYMBOLNAME_LEN+1] ;
   if (strlen(word) > FrMAX_SYMBOLNAME_LEN)
      {
      memcpy(tmp,word,FrMAX_SYMBOLNAME_LEN) ;
      tmp[FrMAX_SYMBOLNAME_LEN] = '\0' ;
      w = tmp ;
      }
   FrSymbol *wordsym = makeSymbol(w) ;
   FrObject *xlat = string_to_FrObject(translation) ;
   return addDefinition(wordsym,xlat) ;
}

//----------------------------------------------------------------------

bool Dictionary::addDefinitions(const FrSymbol *word,
				  const FrList *translations)
{
   if (readonly)
      return false ;			// can't update read-only dict!
   if (!translations)
      return true ;			// trivially successful
   size_t entry_index = findWord(word) ;
   if (entry_index != FrVOCAB_WORD_NOT_FOUND)
      {
      size_t loc = headinfo[entry_index].index() ;
      // first, find out which of the translations are not yet in the dict
      FrList *newdefs = 0 ;
      size_t numnew = 0 ;
      size_t numdefs = definition_length(loc) ;
      for (const FrList *trans = translations ; trans ; trans = trans->rest())
	 {
	 FrObject *def = trans->first() ;
	 bool found = false ;
	 if (def && def->consp() && !((FrList*)def)->rest())
	    def = ((FrList*)def)->first() ;
	 for (size_t i = loc ; i < loc + numdefs ; i++)
	    {
	    if (sameTranslation(&definitions[i],def))
	       {
	       found = true ;
	       break ;
	       }
	    }
	 if (!found)
	    {
	    pushlist(def,newdefs) ;
	    numnew++ ;
	    }
	 }
      if (numnew == 0)
	 return true ;			// no additions - trivially successful
      // finally, insert the new definitions
      if (!shiftDefItems(loc,numdefs,numdefs+numnew))
	 return false ;
      newdefs = listreverse(newdefs) ;
      if (numdefs > 0)
	 {
	 definitions[loc+numdefs-1].setLast(false) ;
	 loc += numdefs ;
	 }
      while (newdefs)
	 {
	 FrObject *newdef = poplist(newdefs) ;
	 size_t count = 0 ;
	 size_t defloc = add_dict_definition(newdef) ;
	 int POS = POS_unknown ;
	 int CASE = CASE_unknown ;
	 bool last = (newdefs == 0) ;
	 new (&definitions[loc++]) DictDefItem(count,defloc,POS,CASE,last) ;
	 }
      dict_changed = true ;
      }
   else
      return defineWord(word,translations) ;
   return true ;
}

//----------------------------------------------------------------------
// input: 'word'  name of word for which to add one or more definitions
//	 'translation'	list of lists, each containing new def & its count

bool Dictionary::addDefinitionsCounted(const FrSymbol *word,
					 const FrList *translations,
					 size_t frequency)
{
   if (readonly)
      return false ;			// can't update read-only dict!
   if (!translations)
      return true ;			// trivially successful
   size_t entry_index = findWord(word) ;
   if (entry_index != FrVOCAB_WORD_NOT_FOUND)
      {
      size_t loc = headinfo[entry_index].index() ;
      if (!unmapHeads())
	 return false ;
      if (frequency > 0)
	 {
	 size_t freq = headinfo[entry_index].frequency() ;
	 headinfo[entry_index].setFrequency(freq + frequency) ;
	 }
      // first, find out which of the translations are not yet in the dict
      FrList *newdefs = 0 ;
      size_t numnew = 0 ;
      size_t numdefs = definition_length(loc) ;
      for (const FrList *trans = translations ; trans ; trans = trans->rest())
	 {
	 FrList *defn = (FrList*)trans->first() ;
	 if (!defn || !defn->consp())
	    continue ;
	 FrNumber *cnt = (FrNumber*)defn->second() ;
	 FrObject *def = defn->first() ;
	 if (!cnt || !cnt->numberp())
	    continue ;
	 if (def && def->consp() && !((FrList*)def)->rest())
	    def = ((FrList*)def)->first() ;
	 bool found = false ;
	 for (size_t i = loc ; i < loc + numdefs ; i++)
	    {
	    if (sameTranslation(&definitions[i],def))
	       {
	       found = true ;
	       // update the count for the already-existing definition
	       size_t count = cnt->intValue() ;
	       if (!unmapDefinitions())
		  {
		  free_object(newdefs) ;
		  return false ;
		  }
	       definitions[i].setCount(definitions[i].getCount()+count) ;
	       dict_changed = true ;
	       break ;
	       }
	    }
	 if (!found)
	    {
	    pushlist(defn,newdefs) ;
	    numnew++ ;
	    }
	 }
      if (numnew == 0)
	 return true ;		// nothing to add, so trivially successful
      // finally, insert the new definitions
      if (!shiftDefItems(loc,numdefs,numdefs+numnew))
	 return false ;
      newdefs = listreverse(newdefs) ;
      if (numdefs > 0)
	 {
	 definitions[loc+numdefs-1].setLast(false) ;
	 loc += numdefs ;
	 }
      while (newdefs)
	 {
	 FrList *newdefn = (FrList*)poplist(newdefs) ;
	 FrObject *newdef = newdefn->first() ;
	 FrNumber *cnt = (FrNumber*)newdefn->second() ;
	 size_t count = cnt->intValue() ;
	 size_t defloc = add_dict_definition(newdef) ;
	 int POS = extract_POS_marker(newdefn->rest()) ;
	 int CASE = extract_CASE_marker(newdefn->rest()) ;
	 bool last = (newdefs == 0) ;
	 new (&definitions[loc++]) DictDefItem(count,defloc,POS,CASE,last) ;
	 }
      dict_changed = true ;
      }
   else
      return defineWordCounted(word,translations,frequency) ;
   return true ;
}

//----------------------------------------------------------------------

bool Dictionary::addInstance(const FrSymbol *word,
			       const FrObject *translation)
{
   if (!readonly)
      {
      size_t entry_index = findWord(word) ;
      if (entry_index != FrVOCAB_WORD_NOT_FOUND)
	 {
	 entry_index = headinfo[entry_index].index() ;
	 for (size_t i = entry_index ; i < definition_items ; i++)
	    {
	    if (sameTranslation(&definitions[i],translation))
	       {
	       if (!unmapDefinitions()) // ensure data not memory-mapped
		  return false ;
	       definitions[i].incrCount() ;
	       dict_changed = true ;
	       break ;
	       }
	    else if (definitions[i].isLast()) // end of definitions for word?
	       break ;
	    }
	 return true ;			// successfully incremented
	 }
      }
   return false ;			// couldn't incr because no such word
}

//----------------------------------------------------------------------

bool Dictionary::setCount(const FrSymbol *word,
			    const FrObject *translation, size_t freq)
{
   if (!readonly)
      {
      size_t entry_index = findWord(word) ;
      if (entry_index != FrVOCAB_WORD_NOT_FOUND)
	 {
	 entry_index = headinfo[entry_index].index() ;
	 for (size_t i = entry_index ; i < definition_items ; i++)
	    {
	    if (sameTranslation(&definitions[i],translation))
	       {
	       if (!unmapDefinitions()) // ensure data not memory-mapped
		  return false ;
	       definitions[i].setCount(freq) ;
	       dict_changed = true ;
	       break ;
	       }
	    else if (definitions[i].isLast()) // end of definitions for word?
	       break ;
	    }
	 return true ;			// successfully incremented
	 }
      }
   return false ;			// couldn't incr because no such word
}

//----------------------------------------------------------------------

bool Dictionary::setCount(const FrSymbol *word, size_t freq)
{
   if (!readonly)
      {
      size_t entry_index = findWord(word) ;
      if (entry_index != FrVOCAB_WORD_NOT_FOUND)
	 {
	 headinfo[entry_index].setFrequency(freq) ;
	 return true ;			// successfully incremented
	 }
      }
   return false ;			// couldn't incr because no such word
}

//----------------------------------------------------------------------

bool Dictionary::clearCounts(const FrSymbol *word)
{
   size_t entry_index = findWord(word) ;
   if (entry_index != FrVOCAB_WORD_NOT_FOUND)
      {
      size_t loc = headinfo[entry_index].index() ;
      if (!unmapDefinitions())		// ensure data not memory-mapped
	 return false ;
      for ( ; loc < definition_items ; loc++)
	 {
	 definitions[loc].setCount(0) ;
	 if (definitions[loc].isLast())
	    break ;
	 }
      dict_changed = true ;
      return true ;			// successfully cleared
      }
   return false ;			// couldn't clear because no such word
}

//----------------------------------------------------------------------

bool Dictionary::clearCounts()
{
   if (definitions)
      {
      if (!unmapDefinitions())	// ensure data not memory-mapped
	 return false ;
      for (size_t i = 0 ; i < definition_items ; i++)
	 definitions[i].setCount(0) ;
      dict_changed = true ;
      return true ;
      }
   return false ;
}

// end of file ebdict2.cpp //
