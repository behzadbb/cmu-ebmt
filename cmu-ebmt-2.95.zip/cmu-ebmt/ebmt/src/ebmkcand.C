/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.94							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebmkcand.cpp	code to build candidate chunks from matches	*/
/*  LastEdit: 21mar10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#if defined(__GNUC__)
#  pragma implementation "ebchunks.h"
#endif

#define IMPLEMENT_EBCHUNKS
#include <limits.h>
#include "ebalign.h"
#include "ebcmatch.h"
#include "ebcorpus.h"
#include "ebfreq.h"
#include "ebtoken.h"
#include "ebutil.h"
#include "ebmt.h"
#include "ebglobal.h"
#include "ebmorph.h"

// avoid spurious data-race reports on statistics gathering
#ifdef HELGRIND
#  define KEEP_STATS(x)
#else
#  define KEEP_STATS(x) (x)
#endif

/************************************************************************/
/*	Manifest Constants						*/
/************************************************************************/

// the minumum number of instances to keep during pre-sampling prior to
//   ranking matches.  Higher values give better quality at the cost of
//   longer runtimes. 
#define MIN_OVERSAMPLE 30000

// how many times Max-Dups instances to keep while oversampling prior to
//   ranking matches.  Higher values give better quality at the cost of
//   longer runtimes.  Must not be less than 5.
#define OVERSAMPLE_RATIO 15

/************************************************************************/
/*	Types local to this module					*/
/************************************************************************/

class MatchInfo
   {
   private:
      static FrAllocator allocator ;
      MatchInfo *m_next ;
      const EbCorpusMatches *m_match ;
      uint32_t m_location ;
      uint32_t m_recnum ;
      uint16_t m_offset ;
   public:
      void *operator new(size_t) { return allocator.allocate() ; }
      void operator delete(void *blk) { allocator.release(blk) ; }
      MatchInfo() {}
      MatchInfo(const EbCorpusMatches *matches, size_t loc,
		size_t recnum, size_t offset, MatchInfo *nxt = 0) ;
      ~MatchInfo() {}

      // accessors
      MatchInfo *next() const { return m_next ; }
      size_t listlength() const ;
      const EbCorpusMatches *sourceMatch() const { return m_match ; }
      uint32_t location() const { return m_location ; }
      uint32_t recordNumber() const { return m_recnum ; }
      uint16_t offset() const { return m_offset ; }

      // manipulators
      void setNext(MatchInfo *nxt) { m_next = nxt ; }

      // support for sorting
      static uint16_t rankingLevels() ;
      static uint16_t ranking(bool complete_match, size_t context,
			      EbDocRank docrank, double localscore,
			      size_t recnum) ;
      static int compare(const MatchInfo &inf1, const MatchInfo &inf2)
	 { if (inf1.recordNumber() > inf2.recordNumber())
	    return -1 ;
	  else if (inf1.recordNumber() < inf2.recordNumber())
	     return +1 ;
	  else
	     return 0 ;
	 }
   } ;

//----------------------------------------------------------------------

class MatchesPlusInfo
   {
   public:
      EbCorpusMatches        *m_matches ;
      FrThreadWorkOrder	     *m_workorder ;
      EBMTCandidate	     *m_candidates ;
      EBMTCorpus	     *m_corpus ;
      const FrTextSpans      *m_lattice ;
      const EbMatchFrequency *m_freqs ;
      const FrSymHashTable   *m_targetvocab ;
      size_t 	              m_totalcount ;
      bool		      m_complete ;
   public:
      void init(FrThreadWorkFunc *fn)
	 { m_matches = 0 ; m_totalcount = 0 ; m_candidates = 0 ;
	   createWorkOrder(fn) ; }

      // access to internal state
      FrThreadWorkOrder *workOrder() const { return m_workorder ; }
      EBMTCandidate *&candidateList() { return m_candidates ; }
      bool isDependent() const
	 { return m_workorder ? !m_workorder->prerequisitesMet() : false ; }

      // manipulators
      void createWorkOrder(FrThreadWorkFunc *fn) 
	 { m_workorder = new FrThreadWorkOrder(fn,this,this) ; }
      void addDependent(MatchesPlusInfo *dep) const
	 { if (m_workorder) m_workorder->addDependent(dep->m_workorder) ; }
      void clearWorkOrder() { m_workorder = 0 ; }
      void clearMatchList() { m_matches->deleteList() ; }
   } ;

/************************************************************************/
/*	Global Variables						*/
/************************************************************************/

static char match_cover[8000] ;

FrAllocator MatchInfo::allocator("MatchInfo",sizeof(MatchInfo)) ;

static FrMutex mutex ;
static FrMutex prereq_mutex ;

/************************************************************************/
/*	 Utility functions						*/
/************************************************************************/

static void remember_matches(size_t startpos, size_t endpos)
{
   // remember which words we've covered
   if (endpos >= sizeof(match_cover))
      endpos = sizeof(match_cover) - 1 ;
   for (size_t i = startpos ; i <= endpos ; i++)
      match_cover[i] = (char)1 ;
   return ;
}

/************************************************************************/
/*	Methods for class MatchInfo					*/
/************************************************************************/

MatchInfo::MatchInfo(const EbCorpusMatches *matches, size_t loc,
		     size_t recnum, size_t offset, MatchInfo *nxt)
{
   m_next = nxt ;
   m_match = matches ;
   m_location = (uint32_t)loc ;
   m_recnum = (uint32_t)recnum ;
   m_offset = (uint16_t)offset ;
   return ;
}

//----------------------------------------------------------------------

uint16_t MatchInfo::ranking(bool complete_match, size_t context,
			    EbDocRank docrank, double localscore,
			    size_t recnum)
{
   if (localscore > 1.0)
      localscore = 1.0 ;
   else if (localscore < 0.0)
      localscore = 0.0 ;
   (void)recnum ; // not used yet
#if NUM_LOCAL_RANKS > 1
   uint16_t localrank =
      (uint16_t)((localscore + NUM_LOCAL_RANKS/2) / (NUM_LOCAL_RANKS-1)) ;
#else
   uint16_t localrank = 0 ;
#endif /* NUM_LOCAL_RANKS > 1 */
   if (context >= NUM_CONTEXT_RANKS)
      context = NUM_CONTEXT_RANKS - 1 ;
   uint16_t rank =
      (uint16_t)(localrank
		 | (docrank << NUM_LOCAL_RANK_BITS)
		 | (context << (NUM_DOC_RANK_BITS+NUM_LOCAL_RANK_BITS))
	        ) ;
   if (complete_match)
      rank |= (1<<(NUM_DOC_RANK_BITS+NUM_CONTEXT_RANK_BITS+NUM_LOCAL_RANK_BITS)) ;
   return rank ;
}

//----------------------------------------------------------------------

uint16_t MatchInfo::rankingLevels()
{
   return 2 * NUM_CONTEXT_RANKS * NUM_DOC_RANKS * NUM_LOCAL_RANKS ;
}

//----------------------------------------------------------------------

size_t MatchInfo::listlength() const
{
   size_t len = 0 ;
   for (const MatchInfo *inf = this ; inf ; inf = inf->next())
      len++ ;
   return len ;
}

/************************************************************************/
/************************************************************************/

//----------------------------------------------------------------------
// determine whether 'c1' exactly duplicates 'c2' (except that 'c1'
// may have a worse alignment score than 'c2')

bool EbIsDuplicateCandidate(const EBMTCandidate *c1,
			      const EBMTCandidate *c2)
{
   if (c1->inputStart() == c2->inputStart() &&
       c1->inputLength() == c2->inputLength() &&
       c1->sourceWords() && c2->sourceWords() &&
       c1->targetWords() && c2->targetWords() &&
       EBMT_equal(c1->targetWords(),c2->targetWords()) &&
       (c1->alignmentScore() * c1->confidence() <=
	c2->alignmentScore() * c2->confidence()))
      return true ;		// yes, the chunks are equal
   return false ;
}

//----------------------------------------------------------------------
// determine whether 'c1' exactly duplicates 'c2', ignoring score

bool EbIsDuplicateCandidateAnyScore(const EBMTCandidate *c1,
				      const EBMTCandidate *c2)
{
   if (c1->inputStart() == c2->inputStart() &&
       c1->inputLength() == c2->inputLength() &&
       c1->targetWords() && c2->targetWords() &&
       EBMT_equal(c1->targetWords(),c2->targetWords()))
      return true ;		// yes, the chunks are equal
   return false ;
}

//----------------------------------------------------------------------

void EbClearMatchCover()
{
   memset(match_cover,'\0',sizeof(match_cover)) ;
   return ;
}

//----------------------------------------------------------------------

static EbCorpusMorphology **make_morph_info(const EbCorpusMatches *match,
					    size_t &morph_spans,
					    FrSymbol *&genre)
{
   genre = 0 ;
   if (!use_morph || !match)
      {
      morph_spans = 0 ;
      return 0 ;
      }
   morph_spans = match->matchLength() ;
   EbCorpusMorphology **info = FrNewC(EbCorpusMorphology*,morph_spans) ;
   FrSymbol *symGENRE = FrSymbolTable::add("GENRE") ;
   if (info)
      {
      FrSymbol *first_genre = 0 ;
      bool single_genre = true ;
      for (size_t i = 0 ; i < morph_spans ; i++)
	 {
	 const FrTextSpan *span = match->span(i) ;
	 if (span)
	    {
	    info[i] = new EbCorpusMorphology(span->metaData()) ;
	    // while we're at it, check whether all spans have the same
	    //   GENRE metadata, and if so, return that value to the caller
	    const FrObject *g = span->getMetaData(symGENRE) ;
	    FrSymbol *curr_genre = 0 ;
	    if (g)
	       {
	       if (g->consp())
		  {
		  const FrList *gl = (FrList*)g ;
		  if (gl->first() && gl->first()->symbolp())
		     curr_genre = (FrSymbol*)(gl->first()) ;
		  }
	       else if (g->symbolp())
		  curr_genre = (FrSymbol*)g ;
	       }
	    if (!first_genre)
	       first_genre = curr_genre ;
	    else if (curr_genre && curr_genre != first_genre)
	       single_genre = false ;
	    }
	 else if (i > 0)
	    info[i] = info[i-1] ;
	 }
      if (single_genre)
	 genre = first_genre ;
      }
   else
      {
      FrNoMemory("while collecting morphology info for translation candidates") ;
      morph_spans = 0 ;
      }
   return info ;
}

//----------------------------------------------------------------------

static void delete_morph_info(EbCorpusMorphology **info, size_t N)
{
   if (info)
      {
      for (size_t i = 0 ; i < N ; i++)
	 {
	 if (i == 0 || info[i-1] != info[i])
	    delete info[i] ;
	 }
      FrFree(info) ;
      }
   return ;
}

//----------------------------------------------------------------------

static void retrieval_error(const EbBWTIndex *idx, size_t pos,
			    size_t offset, size_t recnum,
			    size_t srclen, size_t matchlen, 
			    EBMTIndex *index,
			    const EbCorpusMatches *curr_matches,
			    const FrTextSpans *input_lattice)
{
   // this code should never be executed in real life!
#if 1 //FIXME
   if (!quiet_mode)
      {
      size_t startpos = curr_matches->startPosition() ;
      size_t endpos = curr_matches->endPosition() ;
      FrList *text = idx->retrieveSource(pos,index->vocabulary()) ;
      char *srctext = ((FrTextSpans*)input_lattice)->getText(startpos,endpos) ;
      cout << "|  @" << startpos << "/" << endpos << " \"" << srctext
	   << "\" ofs=" << offset << ", srclen(" << recnum << ")="
	   << srclen << ",mtch=" << matchlen << "\tsource=" << text ;
      FrFree(srctext) ;
      free_object(text) ;
      const FrTextSpan *prev_span = 0 ;
      for (size_t i = 0 ; i < matchlen ; i++)
	 {
	 const FrTextSpan *span = curr_matches->span(i) ;
	 if (prev_span && span == prev_span)
	    cout << " <@>" ;
	 else if (span)
	    {
	    char *t = span->getText() ;
	    cout << ' ' << t ;
	    FrFree(t) ;
	    }
	 else
	    cout << " {}" ;
	 prev_span = span ;
	 }
      cout << endl ;
      if (verbose && (idx->haveIndexLocations() || index->setIndexLocations()))
	 {
	 size_t loc = idx->indexLocation(recnum) ;
	 if (loc < idx->numItems())
	    {
	    FrList *fulltext = idx->retrieveSource(loc,index->vocabulary()) ;
	    cout << "||  @@ "<<fulltext<<endl ;
	    free_object(fulltext) ;
	    }
	 else
	    cout << "|| @@@ bad start location " << loc << endl ;
	 }
      }
#endif /* 1 */
   return ;
}

//----------------------------------------------------------------------

static int record_status(size_t pos, size_t offset, size_t recnum,
			 size_t matchlen, size_t &srclen,
			 EBMTIndex *index, const EbBWTIndex *idx,
			 bool complete_matches,
			 const EbCorpusMatches *curr_matches,
			 const FrTextSpans *input_lattice)
{
   if (recnum >= index->numSentencePairs())
      {
      cout << "; bad record number (" << recnum
	   << ") extracted from example"   << endl ;
      return 1 ;			// skip to next record
      }
   else if (recnum < example_limit_lo || recnum > example_limit_hi)
      {
      if (trace_matching)
	 cout << "; skipping record " << recnum
	      << " (not in range " << example_limit_lo << " to "
	      << example_limit_hi << ")" << endl ;
      return 1 ;			// skip to next record
      }
   srclen = index->sourceLength(recnum) ;
   if (!complete_matches && srclen == matchlen)
      return 1 ;		// already converted this match, skip to next
   if (offset > srclen || offset < matchlen)
      {
      retrieval_error(idx,pos,offset,recnum,srclen,matchlen,index,
		      curr_matches,input_lattice) ;
      return 1 ;			// skip to next record
      }
   return 0 ;				// use this record
}

//----------------------------------------------------------------------

static void update_context(const EbCorpusMatches *match, EBMTIndex *index)
{
   assert(match != 0) ;
   EbCorpusMatches *sub = match->extensionOf() ;
   FrCRITSECT_ENTER(mutex) ;
   if (sub)
      sub->addContext(match,index) ;
   sub = match->extensionOfRev() ;
   if (sub)
      sub->addContextRev(match) ;
   FrCRITSECT_LEAVE(mutex) ;
   return ;
}

//----------------------------------------------------------------------

static void update_context(const EbCorpusMatches *match,
			   EBMTIndex *index, size_t loc)
{
   if (context_biases_sampling)
      {
      assert(match != 0) ;
      EbCorpusMatches *sub1 = match->extensionOf() ;
      EbCorpusMatches *sub2 = match->extensionOfRev() ;
      FrBWTLocation location(loc); 
      FrCRITSECT_ENTER(mutex) ;
      if (sub1)
	 sub1->addContext(location,index) ;
      if (sub2)
	 sub2->addContextRev(location) ;
      FrCRITSECT_LEAVE(mutex) ;
      }
   return ;
}

//----------------------------------------------------------------------

static bool create_candidate(size_t pos,size_t matchlen,size_t offset,
			     size_t recnum,size_t startpos,size_t endpos,
			     size_t srclen, size_t input_len,
			     EBMTCorpus *corpus,
			     EBMTIndex *index, EbIndexSpec which,
			     const EbCorpusMatches *curr_matches,
			     bool complete_matches,
			     const EbCorpusMorphology * const *morph_info,
			     size_t morph_spans,
			     EBMTCandidate *&curr_active,
			     bool relaxed_align,
			     const FrSymHashTable *targetvocab,
			     const EBMTCandidate *proto_cand = 0)
{
   if (max_match && curr_matches->inputMatch() > max_match)
      {
      return false ;
      }
   size_t minword = offset - matchlen ;
   // create an EBMTCandidate
   EBMTCandidate *candidate ;
   if (proto_cand)
      {
      candidate = new EBMTCandidate(proto_cand) ;
      if (candidate)
	 {
	 candidate->setSourcePosition(startpos,endpos,minword,matchlen) ;
	 candidate->setCoveredSpans(matchlen,curr_matches->spans()) ;
	 }
      }
   else
      {
      candidate = new EBMTCandidate(pos,which,recnum,startpos,endpos,
				    minword,matchlen,srclen,
				    curr_matches->spans()) ;
      if (candidate)
	 {
	 index->setSourceText(candidate,which) ;
	 }
      }
   if (!candidate)
      {
      FrNoMemory("while converting matches to candidates") ;
      return false ;
      }
   candidate->setInputTextLength(input_len) ;
   candidate->setMatchData(curr_matches) ;
   candidate->setConfidence(curr_matches->probability()) ;
   double doc_context = 10.0 * index->documentWeight(recnum) ;
   candidate->setDocContext(doc_context) ;
   double sent_context = 1.0 ; //FIXME: like doc_context, but in small sliding window
   candidate->setSentContext(sent_context) ;
   int phr_context = EbAlignCacheContext(which,recnum,offset,
					 offset+matchlen-1) ;
   if (phr_context < 0)
      phr_context = 0 ;
   candidate->setPhraseContext(phr_context) ;
   if (candidate->haveGap())
      { KEEP_STATS(gapped_match_count++) ; }
   else
      { KEEP_STATS(ungapped_match_count++) ; }
   if (which == EbIndex_Tagged)
      {
      bool must_backsub
	 = contains_tokens(candidate->sourceWords()) ;
      candidate->loadSentencePair(corpus,
				  complete_matches &&
				  !must_backsub) ;
      align_chunk(candidate,false,relaxed_align,targetvocab) ;
      while (candidate)
	 {
	 // insert_unique changes the next() value if the candidate
	 //   is inserted, so make a copy first
	 EBMTCandidate *next_cand = candidate->next() ;
	 curr_active = insert_unique(candidate,curr_active) ;
	 candidate = next_cand ;
	 }
      }
   //vvv  may want to add 'show_source_text' to alignMatch call
   else if (candidate->alignMatch(corpus,false,relaxed_align,targetvocab))
      {
      // alignMatch can create clones of the candidate if there are multiple
      //   alignments tied for first place, so iterate over all of them
      EBMTCandidate *next_cand ;
      for ( ; candidate ; candidate = next_cand)
	 {
	 next_cand = candidate->next() ;
	 candidate->setNext(0) ;
	 candidate->finishParsingMorphology() ;
	 // ABP: Lookup all morphological variants (includes the
	 //   original)
	 EBMTCandidate *variant = get_variants(candidate, morph_info,
					       morph_spans) ;
	 while (variant) 
	    {
	    // insert_unique changes the next() value if the candidate
	    //   is inserted, so make a copy first
	    EBMTCandidate *next = variant->next() ;
	    curr_active = insert_unique(variant,curr_active) ;
	    variant = next ;
	    }
	 }
      }
   else
      {
      // unalignable, so delete any structures created
      // (the alignment failure was already cached in alignMatch())
      while (candidate)
	 {
	 EBMTCandidate *next = candidate->next() ;
	 delete candidate ;
	 candidate = next ;
	 }
      return false ;
      }
   return true ;
}

//----------------------------------------------------------------------

static void make_candidates(const EbCorpusMatches *curr_matches,
			    EBMTCorpus *corpus, EBMTIndex *index,
			    const FrTextSpans *input_lattice,
			    EBMTCandidate *&active, size_t input_len,
			    bool complete_matches, size_t total_matches,
			    size_t maxdups, size_t &count,
			    bool relaxed_align,
			    const FrSymHashTable *targetvocab)
{		     
   EbIndexSpec which = curr_matches->whichIndex() ;
   FrSymbol *genre ;
   size_t morph_spans = 0 ;
   EbCorpusMorphology **morph_info
      = make_morph_info(curr_matches,morph_spans,genre) ;
   if (genre)
      corpus->selectGenre(genre->symbolName()) ;
   size_t startpos = curr_matches->startPosition() ;
   size_t endpos = curr_matches->endPosition() ;
   const FrBWTLocationList *chunks = curr_matches->matches() ;
   size_t matchlen = curr_matches->matchLength() ;
   const EbBWTIndex *idx = index->selectIndex(which) ;
   double samplestep = 1.0 ;
   if (maxdups && maxdups < total_matches && !complete_matches)
      samplestep = (total_matches / (double)maxdups) ;
   EBMTCandidate *curr_active = 0 ;
   double skip = 0.0 ;
   for (size_t r = chunks->numRanges() ; r > 0 && count < maxdups ; r--)
      {
      FrBWTLocation range = chunks->range(r-1) ;
      size_t first = range.first() ;
      size_t last = range.pastEnd() ;
      if (first > idx->totalItems())
	 first = idx->totalItems() ;
      if (last > idx->totalItems())
	 last = idx->totalItems() ;
      for (double loc = last - skip ;
	   loc > first && count < maxdups ;
	   loc -= samplestep)
	 {
	 size_t pos = (size_t)(loc - 1) ;
	 size_t offset = matchlen ;
	 size_t recnum = idx->recordNumber(pos,&offset) ;
	 size_t srclen ;
	 int status = record_status(pos,offset,recnum,matchlen,srclen,
				    index,idx,complete_matches,curr_matches,
				    input_lattice) ;
	 if (status == 1)
	    {
	    skipped_training_instances++ ;
	    continue ;
	    }
	 else if (!complete_matches || srclen == matchlen)
	    {
	    corpus->addReference(recnum,matchlen) ;
	    update_context(curr_matches,index,pos) ;
	    if (create_candidate(pos,matchlen,offset,recnum,startpos,endpos,
				 srclen,input_len,corpus,index,which,
				 curr_matches,complete_matches,
				 morph_info,morph_spans,
				 curr_active,relaxed_align,targetvocab))
	       {
	       count++ ;	
	       }
	    }
	 }
      size_t div = (size_t)((last - first) / samplestep) ;
      double rem = (last - first) - (div * samplestep) ;
      skip = samplestep - rem - skip - 0.00001 ;
      if (skip < 0.0)
	 skip = 0 ;
      }
   // clean up the candidates produced by the current corpus match
   //  and merge them into the overall list of active candidates
   for (EBMTCandidate *cand = curr_active ; cand ; cand = cand->next())
      {
      cand->freeTargetSentence() ;
      }
   active = curr_active->nconc(active) ;
   if (genre)
      corpus->revertGenre() ;
   delete_morph_info(morph_info,morph_spans) ;
   return ;
}

//----------------------------------------------------------------------

static EBMTCandidate *select_all(const EbCorpusMatches *matches,
				 EBMTCorpus *corpus,
				 bool complete_matches,
				 bool relaxed_align,
				 const FrTextSpans *input_lattice,
				 const FrSymHashTable *targetvocab)
{
   EBMTCandidate *curr_active = 0 ;
   FrSymbol *prev_genre = 0 ;
   size_t input_len = input_lattice->textLength() ;
   EBMTIndex *index = corpus->getIndex() ;
   for (const EbCorpusMatches *curr_matches = matches ;
	curr_matches ;
	curr_matches = curr_matches->next())
      {
//!!!assert(curr_matches->spans() != 0) ;
      const FrBWTLocationList *chunks = curr_matches->matches() ;
      EbIndexSpec which = curr_matches->whichIndex() ;
      size_t matchlen = curr_matches->matchLength() ;
      const EbBWTIndex *idx = index->selectIndex(which) ;
      FrSymbol *genre ;
      size_t morph_spans = 0 ;
      EbCorpusMorphology **morph_info
	 = make_morph_info(curr_matches,morph_spans,genre) ;
      if (genre && genre != prev_genre)
	 {
	 corpus->selectGenre(genre->symbolName(),!prev_genre) ;
	 prev_genre = genre ;
	 }
      if (!curr_matches->subsumed())
	 {
	 for (size_t r = 0 ; r < chunks->numRanges() ; r++)
	    {
	    FrBWTLocation range = chunks->range(r) ;
	    size_t first = range.first() ;
	    size_t last = range.pastEnd() ;
	    if (first > idx->totalItems())
	       first = idx->totalItems() ;
	    if (last > idx->totalItems())
	       last = idx->totalItems() ;
	    for (size_t loc = first ; loc < last ; loc++)
	       {
	       size_t offset ;
	       size_t recnum ;
	       index->getWordLocation(idx,loc,recnum,offset,true) ;
	       size_t srclen = index->sourceLength(recnum) ;
	       if (complete_matches && matchlen < srclen)
		  continue ;		// only want full matches right now
	       if (!complete_matches && srclen == matchlen)
		  continue ;		// we've already processed this one
	       if (offset <= srclen && offset >= matchlen)
		  {
		  corpus->addReference(recnum,matchlen) ;
		  size_t sp = curr_matches->startPosition() ;
		  size_t ep = curr_matches->endPosition() ;
		  create_candidate(loc,matchlen,offset,recnum,sp,ep,srclen,
				   input_len,corpus,index,which,curr_matches,
				   complete_matches,morph_info,
				   morph_spans,curr_active,relaxed_align,
				   targetvocab) ;
		  }
	       else
		  retrieval_error(index->selectIndex(which),loc,offset,recnum,
				  srclen,matchlen,index,curr_matches,
				  input_lattice) ;
	       }
	    }
	 update_context(curr_matches,index) ;
	 }
      if (prev_genre)
	 corpus->revertGenre() ;
      delete_morph_info(morph_info,morph_spans) ;
      }
   // clean up the candidates produced by the current source chunk
   for (EBMTCandidate *cand = curr_active ; cand ; cand = cand->next())
      {
      cand->freeTargetSentence() ;
      }
   return curr_active ;
}

//----------------------------------------------------------------------

static void accumulate_ranks(MatchInfo **info, size_t input_len,
			     const EbCorpusMatches *matches,
			     EBMTIndex *index,
			     EBMTCorpus *corpus,
			     bool complete_matches,
			     bool context_only,
			     bool skip_context,
			     double sample_step)
{
   double skip = 0.0 ;
   for (const EbCorpusMatches *curr_matches = matches ;
	curr_matches ;
	curr_matches = curr_matches->next())
      {
      const FrBWTLocationList *chunks ;
      if (context_only)
	 {
	 // we only need to look at matches with context
	 chunks = curr_matches->context() ;
	 if (!chunks)
	    continue ;
	 }
      else
	 {
	 // we have to look at all matches
	 chunks = curr_matches->matches() ;
	 }
      EbIndexSpec which = curr_matches->whichIndex() ;
      size_t matchlen = curr_matches->matchLength() ;
      EbBWTIndex *idx = index->selectIndex(which) ;
      bool using_align_cache = EbAlignCacheActive() ;
      for (size_t r = 0 ; r < chunks->numRanges() ; r++)
	 {
	 FrBWTLocation range = chunks->range(r) ;
	 size_t numitems = idx->totalItems() ;
	 size_t last = range.pastEnd() ;
	 if (last > numitems)
	    last = numitems ;
	 for (double pos = range.first() + skip ;
	      pos < last ; pos += sample_step)
	    {
	    size_t loc = (size_t)pos ;
	    // for each matched instance, we generate a ranking by mapping
	    //   each hierarchical preference factor to a disjoint range
	    //   and then adding them
	    size_t offset ;
	    size_t recnum ;
	    index->getWordLocation(idx,loc,recnum,offset,
				   using_align_cache) ;
	    if (recnum < example_limit_lo || recnum > example_limit_hi)
	       {
	       if (trace_matching)
		  cout << "; skipping record " << recnum
		       << " (not in range " << example_limit_lo
		       << " to " << example_limit_hi << ")" << endl ;
	       continue ;
	       }
	    size_t srclen = index->sourceLength(recnum) ;
	    bool complete = (srclen == matchlen) ;
	    if (complete_matches && !complete)
	       {
	       continue ;		// don't want to process right now
	       }
	    if (complete && !complete_matches)
	       {
	       continue ;		// already processed
	       }
	    int context = EbAlignCacheContext(which,recnum,offset,
					      offset+matchlen-1) ;
	    if (context < 0)
	       context = corpus->referenceCount(recnum) ;
	    else if (context > 0 && skip_context)
	       continue ;
	    corpus->addReference(recnum,matchlen) ;
	    size_t docrank = index->originRank(recnum,NUM_DOC_RANKS) ;
	    double localscore = EbSourceFeatureScore(curr_matches,index,
						     recnum,offset,input_len) ;
	    EbDocRank rank = MatchInfo::ranking(complete,context,docrank,
					       localscore,recnum) ;
	    info[rank] = new MatchInfo(curr_matches,loc,recnum,offset,
				       info[rank]) ;
	    }
	 size_t div = (size_t)((last - range.first()) / sample_step) ;
	 double rem = (last - range.first()) - (div * sample_step) ;
	 skip = sample_step - rem - skip - 0.00001 ;
	 if (skip < 0.0)
	    skip = 0 ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

static void accumulate_ranks(MatchInfo **info,
			     size_t input_len, size_t maxdups,
			     const EbCorpusMatches *matches,
			     EBMTIndex *index,
			     EBMTCorpus *corpus,
			     bool complete_matches)
{
   // count up the total number of matches that have context available
   size_t total_matches = 0 ;
   size_t total_context = 0 ;
   for (const EbCorpusMatches *curr_matches = matches ;
	curr_matches ;
	curr_matches = curr_matches->next())
      {
      if (curr_matches->matches())
	  total_matches += curr_matches->matches()->totalMatches() ;
      const FrBWTLocationList *context = curr_matches->context() ;
      if (context)
	 total_context += context->totalMatches() ;
      }
   // if we have a huge number of matches, save time by uniformly subsampling
   //   (but still oversampling) the matches before ranking them
   double sample_step = 1.0 ;
   bool skip_context = false ;
   // ensure we get sufficient candidate matches to avoid losing too
   //   many good ones
   double sample_ratio = OVERSAMPLE_RATIO ;
   size_t min_oversample = MIN_OVERSAMPLE ;
   if (!index->haveSourceWeights())
      {
      if (sample_ratio > 2.0)
	 sample_ratio = 2.0 ;
      min_oversample /= 50 ;
      }
   if (total_context < maxdups && total_matches > min_oversample &&
       total_matches > maxdups * sample_ratio)
      {
      if (total_context > 0)
	 {
	 accumulate_ranks(info,input_len,matches,index,corpus,
			  complete_matches,true,false,1.0) ;
	 skip_context = true ;
	 }
      double dups = maxdups * sample_ratio ;
      if (dups < min_oversample)
	 dups = min_oversample ;
      sample_step = total_matches / dups ;
      }
   //FIXME: the following ensures that we find every complete match, but
   //  is not the most efficient way to do so
   if (complete_matches)
      sample_step = 1.0 ;
   // now process the corpus match records
   accumulate_ranks(info,input_len,matches,
		    index,corpus,complete_matches,
		    total_context >= maxdups && !complete_matches,
		    skip_context,sample_step) ;
   return ;
}

//----------------------------------------------------------------------

static EBMTCandidate *select_by_rank(size_t maxdups,
				     const EbCorpusMatches *matches,
				     EBMTCorpus *corpus,
				     bool complete_matches,
				     const FrTextSpans *input_lattice,
				     const FrSymHashTable *targetvocab)
{
   //
   // Phase 2: accumulate ranking info for each match
   //
   FrLocalAllocC(MatchInfo*,info,2048,MatchInfo::rankingLevels()+1) ;
   if (!info)
      {
      // out of memory, so just return
      return 0 ;
      }
   size_t input_len = input_lattice->textLength() ;
   EBMTIndex *index = corpus->getIndex() ;
   accumulate_ranks(info,input_len,maxdups,matches,index,corpus,
		    complete_matches) ;
   //
   // Phase 3: work down the ranked lists of matched training instances
   //
   EBMTCandidate *curr_active = 0 ;
   FrSymbol *prev_genre = 0 ;
   const EbCorpusMatches *prev_srcmatch = 0 ;
   EbCorpusMorphology **morph_info = 0 ;
   size_t morph_spans = 0 ;
   size_t i ;
   size_t totalcount = 0 ;
   for (i = 0 ; totalcount < maxdups && i < MatchInfo::rankingLevels() ; i++ )
      {
      if (!info[i])
	 continue ;
      // figure out what proportion of the current group we want
      size_t count = info[i]->listlength() ;
      double samplestep = 1.0 ;
      if (totalcount + count > maxdups)
	 {
//	 if (!sample_from_end)
	 samplestep = count / (double)(maxdups - totalcount) ;
	 // ensure that we sample uniformly by location in corpus
	 info[i] = FrMergeSort(info[i]) ;
	 }
      // scan down the current group, sampling the appropriate number of
      //   instances
      double skip = 1.0 ;
      MatchInfo *next ;
      for (MatchInfo *inf = info[i] ; inf ; inf = next)
	 {
	 next = inf->next() ;
	 if (--skip > 0.0)
	    {
	    delete inf ;
	    continue ;
	    }
	 skip += samplestep ;
	 const EbCorpusMatches *srcmatch = inf->sourceMatch() ;
	 size_t loc = inf->location() ;
	 size_t recnum = inf->recordNumber() ;
	 size_t offset = inf->offset() ;
	 EbIndexSpec which = srcmatch->whichIndex() ;
	 delete inf ;
	 index->refineWordLocation(which,loc,recnum,offset) ;
	 size_t srclen = index->sourceLength(recnum) ;
	 size_t matchlen = srcmatch->matchLength() ;
	 if (offset <= srclen && offset >= matchlen)
	    {
	    if (srcmatch != prev_srcmatch)
	       {
	       delete_morph_info(morph_info,morph_spans) ;
	       prev_srcmatch = srcmatch ;
	       FrSymbol *genre ;
	       morph_info = make_morph_info(srcmatch,morph_spans,genre) ;
	       if (genre && genre != prev_genre)
		  {
		  corpus->selectGenre(genre->symbolName(),!prev_genre) ;
		  prev_genre = genre ;
		  }
	       }
	    const EBMTCandidate *proto_cand
	       = EbAlignCacheCandidate(which,recnum,offset,offset+matchlen-1) ;
	    update_context(srcmatch,index,loc) ;
	    if (srcmatch->subsumed())
	       continue ;
	    if (create_candidate(loc,matchlen,offset,recnum,
				 srcmatch->startPosition(),
				 srcmatch->endPosition(),srclen,input_len,
				 corpus,index,which,srcmatch,
				 complete_matches,morph_info,morph_spans,
				 curr_active,false,targetvocab,proto_cand))
		totalcount++ ;
	    }
	 else
	    retrieval_error(index->selectIndex(which),loc,offset,recnum,
			    srclen,matchlen,index,srcmatch,input_lattice) ;
	 }
      }
   if (prev_genre)
      corpus->revertGenre() ;
   delete_morph_info(morph_info,morph_spans) ;
   for ( ; i < MatchInfo::rankingLevels() ; i++)
      {
      MatchInfo *inf = info[i] ;
      while (inf)
	 {
	 MatchInfo *next = inf->next() ;
	 delete inf ;
	 inf = next ;
	 }
      }
   FrLocalFree(info) ;
   // clean up the candidates produced by the current source chunk
   for (EBMTCandidate *cand = curr_active ; cand ; cand = cand->next())
      {
      cand->freeTargetSentence() ;
      }
   return curr_active ;
}

//----------------------------------------------------------------------

static EBMTCandidate *quick_select(size_t totalcount, size_t maxdups,
				   EbCorpusMatches *matches,
				   EBMTCorpus *corpus,
				   const FrTextSpans *input_lattice,
				   const FrSymHashTable *targetvocab,
				   bool complete_matches)
{
   EBMTCandidate *active = 0 ;
   //
   // Phase 2: process either the complete or partial matches for the current
   //	source chunk
   //
   size_t count = 0 ;
   size_t input_len = input_lattice->textLength() ;
   EBMTIndex *index = corpus->getIndex() ;
   for (EbCorpusMatches *curr_matches = matches ;
	curr_matches ;
	curr_matches = curr_matches->next())
      {
      make_candidates(curr_matches,corpus,index,input_lattice,active,
		      input_len,complete_matches,totalcount,maxdups,count,
		      false,targetvocab) ;
      }
   return active ;
}

//----------------------------------------------------------------------

static size_t desired_duplicates(const EbCorpusMatches *matches)
{
   if (matches->matchLength() == 1)
      return max_duplicates1 ? max_duplicates1 : UINT_MAX ;
   else
      return max_duplicates ? max_duplicates : UINT_MAX ;
}

//----------------------------------------------------------------------

static void convert_matches(const void * /*input*/, void *output)
{
   MatchesPlusInfo *match_plus_info = (MatchesPlusInfo*)output ;
   EBMTCandidate **candidates = &match_plus_info->candidateList() ;
   EbCorpusMatches *matches = match_plus_info->m_matches ;
   size_t totalcount = match_plus_info->m_totalcount ;
   // start by figuring out how many instances we want to process
   size_t maxdups = desired_duplicates(matches) ;
   // (reduce the limit by the number of instances we've already used)
   const EbMatchFrequency *freqs = match_plus_info->m_freqs ;
   if (freqs)
      {
      size_t used = freqs->frequency(matches) ;
      if (used >= maxdups)
	 maxdups = 0 ;
      else
	 maxdups -= used ;
      }
   // allow a relaxed alignment for less-frequent phrases
   bool relaxed_align = (totalcount < maxdups / 2) && totalcount < 100 ;
   // instead of a sudden, hard cutoff in the number of instances
   //   processed, we want to gradually start subsampling.  So,
   //   tweak maxdups downward if it's big enough and we have at
   //   least 4/5 that many instances available to us for sampling
   if (maxdups >= 50 && totalcount > 0.8 * maxdups)
      {
      // partial sampling between 0.8*maxdups and 1.2*maxdups
      double discount = (totalcount - 0.8 * maxdups) * 0.5 ;
      size_t max = (size_t)(totalcount - discount) ;
      if (max < maxdups)
	 maxdups = max ;
      }
   EBMTCandidate *active ;
   EBMTCandidate *full_active = 0 ;
   const FrSymHashTable *targetvocab = match_plus_info->m_targetvocab ;
   const FrTextSpans *input_lattice = match_plus_info->m_lattice ;
   EBMTCorpus *corpus = match_plus_info->m_corpus ;
   bool complete_matches = match_plus_info->m_complete ;
   if (totalcount <= maxdups)
      {
      if (!complete_matches)
	 full_active = select_all(matches,corpus,true,
				  relaxed_align,input_lattice,targetvocab) ;
      active = select_all(matches,corpus,complete_matches,
			  relaxed_align,input_lattice,targetvocab) ;
      }
   else if (context_biases_sampling)
      {
      if (!complete_matches)
	 full_active = select_by_rank(maxdups,matches,corpus,true,
				      input_lattice,targetvocab) ;
      active = select_by_rank(maxdups,matches,corpus,complete_matches,
			      input_lattice,targetvocab) ;
      }
   else
      {
      if (!complete_matches)
	 full_active = quick_select(totalcount,maxdups,matches,corpus,
				    input_lattice,targetvocab,true) ;
      active = quick_select(totalcount,maxdups,matches,corpus,
			    input_lattice,targetvocab,complete_matches) ;
      }
   active = full_active->nconc(active) ;
   if (active)
      {
      size_t startpos = matches->startPosition() ;
      size_t endpos = matches->endPosition() ;
      remember_matches(startpos,endpos) ;
      }
   (*candidates) = active ;
   return ;
}

//----------------------------------------------------------------------
// link each match to the two one-shorter matches it contains (one direction
//   has already been taken care of during index lookup)
// do this by sorting by decreasing length, then scanning forward from
//   each match record until we find the submatch

static size_t link_matches(EbCorpusMatches *matches)
{
   size_t num_spans = 0 ;
   size_t startpos = (size_t)~0 ;
   size_t endpos = (size_t)~0 ;
   for (EbCorpusMatches *m = matches ; m ; m = m->next())
      {
      if (omit_subsumed)
	 {
	 EbCorpusMatches *ext = m->extensionOf() ;
	 if (ext)
	    ext->markSubsumed() ;
	 }
      for (EbCorpusMatches *nxt = m->next() ; nxt ; nxt = nxt->next())
	 {
	 if (m->isExtensionOf(nxt))
	    {
	    m->extensionOfRev(nxt) ;
	    if (omit_subsumed)
	       {
	       nxt->markSubsumed() ;
	       }
	    break ;
	    }
	 }
      // while we're scanning anyway, count the number of distinct spans
      if (m->startPosition() != startpos || m->endPosition() != endpos)
	 {
	 startpos = m->startPosition() ;
	 endpos = m->endPosition() ;
	 num_spans++ ;
	 }
      }
   return num_spans ;
}

//----------------------------------------------------------------------

static void split_matches(EbCorpusMatches *matches, size_t &num_spans,
			  MatchesPlusInfo *match_lists,
			  EbCorpusMatches *&extraneous)
{
   size_t startpos = matches->startPosition() ;
   size_t endpos = matches->endPosition() ;
   num_spans = 0 ;
   size_t maxdups = desired_duplicates(matches) ;
   size_t prev_tok = 0 ;
   extraneous = 0 ;
   EbCorpusMatches *next_match ;
   for (EbCorpusMatches *m = matches ; m ; m = next_match)
      {
      next_match = m->next() ;
      if (m->startPosition() != startpos || m->endPosition() != endpos)
	 {
	 // un-reverse the list for the current span
	 match_lists[num_spans].m_matches
	    = match_lists[num_spans].m_matches->reverseList() ;
	 // advance to the next span
	 num_spans++ ;
	 startpos = m->startPosition() ;
	 endpos = m->endPosition() ;
	 // reset statistics for the new span
	 maxdups = desired_duplicates(m) ;
	 prev_tok = 0 ;
	 }
      size_t tok = m->numTokens() ;
      // While we're at it, also trim out highly-generalized examples if
      //   there are sufficient less-generalized examples available
      if (match_lists[num_spans].m_totalcount < maxdups || tok == prev_tok)
	 {
	 m->setNext(match_lists[num_spans].m_matches) ;
	 match_lists[num_spans].m_matches = m ;
	 match_lists[num_spans].m_totalcount += m->totalMatches() ;
	 prev_tok = tok ;
	 }
      else
	 {
	 // we have enough instances, and those we've seen already have
	 //   less generalization, so just ignore this match record
	 m->setNext(extraneous) ;
	 extraneous = m ;
	 }
      }
   match_lists[num_spans].m_matches
      = match_lists[num_spans].m_matches->reverseList() ;
   num_spans++ ;
   // link each match list to the list for the shorter matches it contains,
   //   and flag those shorter matches as having prerequisites to ensure
   //   correct order of execution when multi-threading
   for (size_t i = 0 ; i < num_spans ; i++)
      {
      EbCorpusMatches *m = match_lists[i].m_matches ;
      size_t startpos = m->startPosition() ;
      size_t endpos = m->endPosition() ;
      size_t matchlen = m->inputMatch() ;
      int to_find = 2 ;
      // scan for the two one-word-shorter match lists
      for (size_t j = i + 1 ; j < num_spans ; j++)
	 {
	 m = match_lists[j].m_matches ;
	 size_t l = m->inputMatch() ;
	 if (l >= matchlen)
	    continue ;
	 else if (l + 1 < matchlen)
	    break ;
	 // l + 1 == matchlen
	 if (m->startPosition() == startpos ||
	     m->endPosition() == endpos)
	    {
	    thread_pool->addDependency(match_lists[i].workOrder(),
				       match_lists[j].workOrder()) ;
	    if (--to_find <= 0)
	       break ;
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

// When there are more than max_duplicates matching training instances for
//   a given source phrase, we subsample the matches to only look at
//   max_duplicates examples.
// First, process complete matches
// Second, process matches in instances which were already used for the
//   current translation (this handles longer matches containing the current
//   source phrase as well as disjoint matches)
// Third, process uniformly-spaced matches among those not yet processed
//   until max_duplicates is reached
//
// For resource reasons, we don't actually work on all already-used instances
//   in the second step (this would require either doubling the index size
//   or retrieving the record number for every single match by following the
//   pointer chain in the index).  Instead, we limit our processing to those
//   training instances matching the current phrase plus some additional
//   prefix or suffix.  The former comes for free from the nature of the
//   index, the latter can be handled by caching the records which are
//   processed and ordering processing from longest to shortest.

EBMTCandidate *EbMakeCandidates(EbCorpusMatches *matches,
				const FrTextSpans *input_lattice,
				EBMTCorpus *corpus,
				bool complete_matches,
				size_t full_len,
				const EbMatchFrequency *freqs,
				const FrSymHashTable *targetvocab)
{
   FrMessageLoop() ;			// handle any pending events
   if (!matches)
      return 0 ;			// nothing to do!
   //
   // convert the chunks that we found into translation candidates
   // start by cleaning up the list of match records by removing empty matches
   //
   EbCorpusMatches *prev_match = 0 ;
   EbCorpusMatches *next_match ;
   for (EbCorpusMatches *curr = matches ; curr ; curr = next_match)
      {
      next_match = curr->next() ;
      if (!curr->matches() || curr->totalMatches() == 0)
	 {
	 if (prev_match)
	    prev_match->setNext(next_match) ;
	 else
	    matches = next_match ;
	 delete curr ;
	 }
      }
   if (!matches)
      return 0 ;
   // next, link each match to the two one-shorter matches it contains
   //   (one direction has already been taken care of during index lookup)
   matches = FrMergeSort(matches) ;
   size_t num_spans = link_matches(matches) ;
   // set up storage for the individual work units to be dispatched
   FrLocalAllocC(MatchesPlusInfo,match_lists,2048,num_spans) ;
   if (!match_lists)
      {
      FrLocalFree(match_lists) ;
      matches->deleteList() ;
      return 0 ;
      }
   ANNOTATE_NEW_MEMORY(match_lists,num_spans * sizeof(MatchesPlusInfo)) ;
   for (size_t i = 0 ; i < num_spans ; i++)
      {
      match_lists[i].init(convert_matches) ;
      // add the extra parameters needed by the conversion function
      match_lists[i].m_lattice = input_lattice ;
      match_lists[i].m_corpus = corpus ;
      match_lists[i].m_complete = complete_matches ;
      match_lists[i].m_freqs = freqs ;
      match_lists[i].m_targetvocab = targetvocab ;
      }
   // split the match records into a separate list for each distinct
   //   source span
   EbCorpusMatches *extraneous ;
   split_matches(matches,num_spans,match_lists,extraneous) ;
   // process the match records for each distinct source span which has no
   //   prerequisites
   // start by scanning for spans with prerequisites and marking them as not available
   //   for dispatch
   for (size_t i = 0 ; i < num_spans ; i++)
      {
      if (match_lists[i].isDependent())
	 match_lists[i].clearWorkOrder() ;
      }
   thread_pool->limitThreads(thread_pool->numthreads()) ;
   thread_pool->haveDependents() ;
   for (size_t i = 0 ; i < num_spans ; i++)
      {
      if (match_lists[i].workOrder())
	 thread_pool->dispatch(match_lists[i].workOrder()) ;
      }
   // since the conversion process may look at other match records based on
   //   containment relations, we have to wait until all records have been
   //   processed before deleting them
   thread_pool->waitUntilIdle() ;
   for (size_t i = 0 ; i < num_spans ; i++)
      {
      match_lists[i].clearMatchList() ;
      }
   extraneous->deleteList() ;
   // go through the result lists, concatenating them all together into
   //   the first candidate_list to generate our final result
   for (size_t i = num_spans - 1 ; i > 0 ; i--)
      {
      match_lists[i-1].candidateList() =
	 match_lists[i-1].candidateList()->nconc(match_lists[i].candidateList()) ;
      }
   EBMTCandidate *candidates = match_lists[0].candidateList() ;
   FrLocalFree(match_lists) ;
   if (full_len)
      {
      EbOutputSentenceCoverage(match_cover,sizeof(match_cover),full_len) ;
      EbClearMatchCover() ;
      }
   return candidates ;
}

// end of file ebmkcand.cpp //
