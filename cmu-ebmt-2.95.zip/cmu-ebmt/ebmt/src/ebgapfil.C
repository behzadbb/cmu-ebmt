/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebgapfil.cpp	gap-marker/gap-filler functions			*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 2005,2006,2007,2009 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "ebmt.h"
#include "ebglobal.h"

/************************************************************************/
/*	Manifest Constants						*/
/************************************************************************/

#define EBMT_GAP_FILLER_PREFIX	"<@"
#define EBMT_GAP_FILLER_END	'>'
#define EBMT_GAP_FILL_ATLEFT	'-'
#define EBMT_GAP_FILL_ATRIGHT	'+'
#define EBMT_GAP_FILL_EMBED	':'
#define EBMT_GAP_FILL_UNKNOWN	'?'
#define EBMT_GAP_FILL_ABS	'='

#define MAX_GAP_OFFSET	8	// how far outside match may gap filler lie?

/************************************************************************/
/************************************************************************/

size_t EbMaxGapOffset()
{
   size_t sim = EBMT_word_order_similarity ;
   if (sim == 0)
      sim = MAX_GAP_OFFSET ;
   else
      sim += 3 ;
   return sim ;
}

//----------------------------------------------------------------------

bool EbIsGapMarker(const char *word)
{
   if (!word)
      return false ;
#define PREF_LEN (sizeof(EBMT_GAP_FILLER_PREFIX)-1)
   if (word && strncmp(word,EBMT_GAP_FILLER_PREFIX,PREF_LEN) == 0)
      return true ;
   return false ;
}

//----------------------------------------------------------------------

bool EbIsEmbeddedGapMarker(const char *word)
{
   if (!word)
      return false ;
   if (word && strncmp(word,EBMT_GAP_FILLER_PREFIX,PREF_LEN) == 0 &&
       word[PREF_LEN] == EBMT_GAP_FILL_EMBED &&
       Fr_isdigit(word[PREF_LEN+1]))
      return true ;
   return false ;
}

//----------------------------------------------------------------------

bool EbIsUnknownGapMarker(const char *word)
{
   if (!word)
      return false ;
   if (word && strncmp(word,EBMT_GAP_FILLER_PREFIX,PREF_LEN) == 0 &&
       word[PREF_LEN] == EBMT_GAP_FILL_UNKNOWN &&
       word[PREF_LEN+1] == EBMT_GAP_FILLER_END)
      return true ;
   return false ;
}

//----------------------------------------------------------------------

bool EbIsLeftGapMarker(const char *word)
{
   if (!word)
      return false ;
   if (word && strncmp(word,EBMT_GAP_FILLER_PREFIX,PREF_LEN) == 0 &&
       word[PREF_LEN] == EBMT_GAP_FILL_ATLEFT)
      return true ;
   return false ;
}

//----------------------------------------------------------------------

bool EbIsGapMarker(const FrSymbol *word)
{
   if (!word)
      return false ;
   return EbIsGapMarker(word->symbolName()) ;
}

//----------------------------------------------------------------------

static void finish_marker(char *buf, size_t buflen, int offset,
			  const char *restriction)
{
   Fr_sprintf(buf, buflen, "%d%s%.40s>%c",
	      offset, (*restriction?"_":""), restriction, '\0') ;
   return ;
}

//----------------------------------------------------------------------

static void make_gap_marker(char *marker, size_t buflen,
			    int offset, bool absolute,
			    bool embedded, const char *restriction)
{
   strcpy(marker,EBMT_GAP_FILLER_PREFIX) ;
   char *end = marker + sizeof(EBMT_GAP_FILLER_PREFIX) - 1 ;
   if (!restriction)
      restriction = "" ;
   if (absolute)
      {
      *end++ = EBMT_GAP_FILL_ABS ;
      finish_marker(end,buflen-(end-marker),offset,restriction) ;
      }
   else if (embedded)
      {
      *end++ = EBMT_GAP_FILL_EMBED ;
      finish_marker(end,buflen-(end-marker),offset,restriction) ;
      }
   else if (offset == 0)
      {
      *end++ = EBMT_GAP_FILL_UNKNOWN ;
      if (restriction && *restriction)
	 {
	 *end++ = '_' ;
	 size_t len = strlen(restriction) ;
	 if (len > 30)
	    len = 30 ;
	 memcpy(end,restriction,len) ;
	 end += len ;
	 }
      *end++ = '>' ;
      *end = '\0' ;
      }
   else
      {
      *end++ = (offset<0) ? EBMT_GAP_FILL_ATLEFT : EBMT_GAP_FILL_ATRIGHT ;
      finish_marker(end,buflen-(end-marker),
		    (offset<0)?-offset:offset, restriction) ;
      }
   return ;
}

//----------------------------------------------------------------------

FrSymbol *EbMakeGapMarker(int offset, bool absolute, bool embedded,
			  const char *restriction)
{
   char marker[FrMAX_SYMBOLNAME_LEN+1] ;
   make_gap_marker(marker,sizeof(marker),offset,absolute,embedded,
		   restriction) ;
   return FrSymbolTable::add(marker) ;
}

//----------------------------------------------------------------------

FrString *EbMakeGapMarkerStr(int offset, bool absolute, bool embedded,
			     const char *restriction)
{
   char marker[FrMAX_SYMBOLNAME_LEN+1] ;
   make_gap_marker(marker,sizeof(marker),offset,absolute,embedded,
		   restriction) ;
   return new FrString(marker) ;
}

//----------------------------------------------------------------------

FrSymbol *EbMakeGapMarker(FrSymbol *relmarker, size_t start, size_t len)
{
   if (!relmarker)
      return relmarker ;
   const char *marker = relmarker->symbolName() ;
   if (strncmp(marker,EBMT_GAP_FILLER_PREFIX,PREF_LEN) == 0)
      {
      long offset = atol(marker+PREF_LEN) ;
      if (marker[PREF_LEN] == EBMT_GAP_FILL_ATLEFT ||
	  marker[PREF_LEN] == EBMT_GAP_FILL_ATRIGHT)
	 {
	 if (offset < 0)
	    return EbMakeGapMarker(start+offset,true) ;
	 else if (offset > 0)
	    return EbMakeGapMarker(start+len-1+offset,true) ;
	 else
	    return relmarker ;
	 }
      else if (marker[PREF_LEN] == EBMT_GAP_FILL_EMBED)
	 {
	 offset = atol(marker+PREF_LEN+1) ;
	 return EbMakeGapMarker(start+offset,true) ;
	 }
      }
   return relmarker ;
}

//----------------------------------------------------------------------

char *EbGapFillerRestriction(const char *marker)
{
   if (strncmp(marker,EBMT_GAP_FILLER_PREFIX,PREF_LEN) == 0)
      {
      const char *pos = marker + PREF_LEN ;
      char *rest = strchr(pos,'_') ;	// skip position specifier
      if (rest)
	 {
	 if (*rest == '_')
	    rest++ ;
	 char *end = strchr(rest,EBMT_GAP_FILLER_END) ;
	 if (end)
	    {
	    char *restriction = FrNewN(char,end-rest+1) ;
	    if (restriction)
	       {
	       memcpy(restriction,rest,end-rest) ;
	       restriction[end-rest] = '\0' ;
	       return restriction ;
	       }
	    }
	 }
      }
   return 0 ;				// no restriction in place
}

//----------------------------------------------------------------------

size_t EbAbsGapFillerLocation(const char *marker)
{
   return (size_t)atol(marker+PREF_LEN+1) ;
}

//----------------------------------------------------------------------

size_t EbAbsGapFillerLocation(const FrSymbol *marker)
{
   return (marker ? (size_t)atol(marker->symbolName()+PREF_LEN+1)
	   	  : EBMT_GAP_FILLER_NOTGAP) ;
}

//----------------------------------------------------------------------

int EbGapFillerOffset(const char *marker)
{
   if (!EbIsGapMarker(marker))
      return 0 ;
   marker += PREF_LEN ;
   if (*marker == EBMT_GAP_FILL_ATRIGHT || *marker == EBMT_GAP_FILL_ATLEFT)
      return (int)atol(marker) ;
   else
      return 0 ;
}

//----------------------------------------------------------------------

size_t EbGapFillerLocation(const char *marker, size_t start, size_t len)
{
   if (!EbIsGapMarker(marker))
      return EBMT_GAP_FILLER_NOTGAP ;
   marker += PREF_LEN ;
   if (*marker == EBMT_GAP_FILL_ABS)
      return (size_t)atol(marker+1) ;
   else if (*marker == EBMT_GAP_FILL_ATLEFT)
      {
      long offset = atol(marker+1) ;
      return ((size_t)offset <= start) ? start - offset : 0 ;
      }
   else if (*marker == EBMT_GAP_FILL_ATRIGHT)
      {
      long offset = atol(marker+1) ;
      return (start + len - 1) + offset ;
      }
   else if (*marker == EBMT_GAP_FILL_EMBED)
      {
      long offset = atol(marker+1) ;
      return start + offset ;
      }
   else
      return EBMT_GAP_FILLER_UNKNOWN ;
}

//----------------------------------------------------------------------

size_t EbGapFillerLocation(const FrSymbol *filler, size_t start, size_t len)
{
   return (filler ? EbGapFillerLocation(filler->symbolName(),start,len)
		  : EBMT_GAP_FILLER_NOTGAP) ;
}

// end of file ebgapfil.cpp //
