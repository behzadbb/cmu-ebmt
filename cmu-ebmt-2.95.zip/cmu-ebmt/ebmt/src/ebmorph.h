/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation			                */
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebmorph.h	code to analyze morphologial variants	        */
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2001,2002,2003,2004,2005	*/
/*		2006,2007,2009 Ralf Brown and Aaron B. Phillips		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __EBMORPH_H_INCLUDED
#define __EBMORPH_H_INCLUDED

#ifndef __FRAMEPAC_H_INCLUDED
#include "FramepaC.h"
#endif

#ifndef __EBCHUNKS_H_INCLUDED
#include "ebchunks.h"
#endif

//----------------------------------------------------------------------

class EbGeneralizations
{
private:
  // An array indexed by word, then generalization id
  uint32_t *generalizations;
  size_t words;

  void init(size_t w);

public:
  EbGeneralizations(size_t w);
  EbGeneralizations(EbGeneralizations *other);
  ~EbGeneralizations();

  static EbGeneralizations *build(FrList *data);

  // type is one of the enumerated values of EbGeneralization
  bool get(size_t word, size_t type);
  void set(size_t word, size_t type, bool value);

  size_t getWords();
  bool empty();
  int compare(EbGeneralizations *other);
  bool operator<(EbGeneralizations *other);
  bool equal(EbGeneralizations *other);
  double score();
  FrList *display();
  static size_t getType(const char *name);
};

//----------------------------------------------------------------------

class compare_generalizations {
public:
  bool operator()(EbGeneralizations *g1, EbGeneralizations *g2) {
    if(g1 == g2)
      return false;
    if(!g1)
      return true;
    return (g1->compare(g2) < 0);
  }
};

//----------------------------------------------------------------------

void load_generalization_weights();
void clear_generalization_weights();

//----------------------------------------------------------------------

class EbGeneralizationRule
{
private:
  FrSymbol *generalization;
  FrList *src_match;
  FrList *tgt_match;
  static const char *ops;
  FrString *rules[7];
  FrList *repls[7];

  FrList *getWordBoundaries(EBMTCandidate *cand, size_t word);
  FrList *getPhraseBoundaries(EBMTCandidate *cand, size_t word, FrList *boundaries);
  FrList *getUnalignedBoundaries(EBMTCandidate *cand, FrList *boundaries);
  void setRule(size_t last_op, FrString *rule, size_t rule_begin, size_t rule_split, size_t rule_end);
  EBMTCandidate* replace(EBMTCandidate *cand, size_t op, FrList *bounds[], size_t src_pos);
  EBMTCandidate* replace(EBMTCandidate *cand, EBMTCandidate *result,
			 size_t src_pos, size_t elide_pos,
			 size_t insert_pos, FrString *insert_word);

public:
  EbGeneralizationRule(FrSymbol *gen, FrList *src, FrList *tgt, FrString *rule);
  FrList *match(const FrList *features1, const FrList *features2,
		const FrList *feat_diff1, const FrList *feat_diff2);
  EBMTCandidate *apply(EBMTCandidate *cand, size_t word);
};

//----------------------------------------------------------------------

void load_generalization_rules();
void clear_generalization_rules();

//----------------------------------------------------------------------

EBMTCandidate *insert_unique(EBMTCandidate *newcand,
			     EBMTCandidate *candidates,
			     bool update = true);

bool EbMayHaveVariants(const EBMTCandidate *cand,
		       const EbCorpusMorphology* const *morph_info,
		       const size_t morph_spans) ;

EBMTCandidate *get_variants(EBMTCandidate *candidate,
			    const EbCorpusMorphology* const *morph_info,
			    const size_t morph_spans);

//----------------------------------------------------------------------

void load_metainfo();
void clear_metainfo();

//----------------------------------------------------------------------

#endif
