/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebbwtidx.cpp	low-level BWT-based corpus index		*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 2004,2005,2006,2007,2009 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#if defined(__GNUC__)
#  pragma implementation "ebindex.h"
#endif

#include "ebindex.h"
#include "ebglobal.h"

/************************************************************************/
/*	Methods for class EbBWTIndex					*/
/************************************************************************/

EbBWTIndex::EbBWTIndex(const char *filename, bool memory_mapped,
		       bool touch_memory)
{
   init() ;
   load(filename,memory_mapped,touch_memory) ;
   return ;
}

//----------------------------------------------------------------------

EbBWTIndex::EbBWTIndex(uint32_t *items, size_t num_items,
		       FrBWTEORHandling hnd, uint32_t eor, ostream *progress)
{
   init() ;
   makeIndex(items,num_items,hnd,eor,progress) ;
   return ;
}

//----------------------------------------------------------------------

EbBWTIndex::~EbBWTIndex()
{
   FrFree(wordIDs) ;		wordIDs = 0 ;
   idlist->freeIDList() ;	idlist = 0 ;
   freeIndexLocations() ;
   return ;
}

//----------------------------------------------------------------------

void EbBWTIndex::init()
{
   wordIDs = 0 ;
   m_startloc = 0 ;
   m_idcount = 0 ;
   m_numrecs = 0 ;
   idlist = 0 ;
   m_SOR_id = FrVOCAB_WORD_NOT_FOUND ;
   m_changed = false ;
   setEOR(INDEX_EOR_VALUE) ;
   return ;
}

//----------------------------------------------------------------------

const char *EbBWTIndex::signatureString() const
{
   return INDEX_SIGNATURE ;
}

//----------------------------------------------------------------------

bool EbBWTIndex::loadIDs()
{
   size_t datasize = userDataSize() ;
   if (datasize > 0)
      {
      char *IDs = FrNewN(char,datasize) ;
      bool success = false ;
      if (IDs && (size_t)readUserData(0,IDs,datasize) == datasize)
	 {
	 m_idcount = datasize / sizeof(LONGbuffer) ;
	 wordIDs = FrNewN(uint32_t,m_idcount) ;
	 if (wordIDs)
	    {
	    for (size_t i = 0 ; i < m_idcount ; i++)
	       wordIDs[i] = FrLoadLong(IDs + sizeof(LONGbuffer) * i) ;
	    success = true ;
	    }
	 else
	    m_idcount = 0 ;
	 }
      FrFree(IDs) ;
      return success ;
      }
   return true ;
}

//----------------------------------------------------------------------

uint32_t EbBWTIndex::indexLocation(size_t line_num) const
{
   if (m_startloc && line_num < m_numrecs)
      return m_startloc[line_num] ;
   else
      return FrVOCAB_WORD_NOT_FOUND ;
}

//----------------------------------------------------------------------

bool EbBWTIndex::freeIndexLocations()
{
   FrFree(m_startloc) ;
   m_startloc = 0 ;
   m_numrecs = 0 ;
   return true ;
}

//----------------------------------------------------------------------

bool EbBWTIndex::setIndexLocations(size_t numrecs)
{
   freeIndexLocations() ;
	 
   m_startloc = FrNewN(uint32_t,numrecs) ;
   if (!m_startloc)
      return false ;

   FrBWTLocation sor = recordStarts() ;
   if (sor.nonEmpty())
      {
      // take advantage of the presence of start-of-record markers to avoid
      //   scanning through the entire index
      m_numrecs = numrecs ;
      for (size_t i = sor.first() ; i < sor.pastEnd() ; i++)
	 {
	 // point at the true start of the training example, not the marker
	 size_t start = getSuccessor(i) ;
	 size_t recnum = recordNumber(start,0)  ;
	 if (recnum < m_numrecs)
	    m_startloc[recnum] = start ;
	 }
      return true ;
      }
   else
      {
      uint32_t limit ;
      FrBitVector *recstarts = findRecordStarts(limit) ;
      if (recstarts)
	 {
	 m_numrecs = numrecs ;
	 size_t i ;
	 for (i = 0 ; i < m_numrecs ; i++)
	    m_startloc[i] = (uint32_t)~0 ;
	 for (i = 0 ; i < limit ; i++)
	    {
	    if (recstarts->getBit(i))
	       {
	       size_t recnum = recordNumber(i,0)  ;
	       if (recnum < m_numrecs)
		  m_startloc[recnum] = i ;
	       }
	    }
	 delete recstarts ;
	 return true ;
	 }
      delete recstarts ;
      FrFree(m_startloc) ;
      m_startloc = 0 ;
      return false ;
      }
}

//----------------------------------------------------------------------

bool EbBWTIndex::setIndexLocations(size_t numrecs,
				     const LONGbuffer *locations)
{
   freeIndexLocations() ;
   m_startloc = FrNewN(uint32_t,numrecs) ;
   if (m_startloc)
      {
      m_numrecs = numrecs ;
      for (size_t i = 0 ; i < numrecs ; i++)
	 {
	 m_startloc[i] = FrLoadLong(locations + i * sizeof(LONGbuffer)) ;
	 }
      }
   return true ;
}

//----------------------------------------------------------------------

FrBWTLocation EbBWTIndex::recordStarts() const
{
   if (recordStartID() != FrVOCAB_WORD_NOT_FOUND)
      return unigram(m_SOR_id) ;
   else
      return FrBWTLocation(~0,0) ;
}

//----------------------------------------------------------------------

bool EbBWTIndex::addWord(FrObject *w)
{
   const char *word = FrPrintableName(w) ;
   if (word)
      {
      uint32_t id = EbCvtSrcWord2WordID(word) ;
      if (!FrAdd2WordIDList(idlist,id))
	 return false ;
      m_changed = true ;
      }
   return true ;
}

//----------------------------------------------------------------------

bool EbBWTIndex::finishLine(size_t line_num, size_t eor_value)
{
   return FrAdd2WordIDList(idlist,eor_value + line_num) ;
}

//----------------------------------------------------------------------

static bool write_IDs(FILE *fp, void *idx)
{
   if (fp && idx)
      {
      EbBWTIndex *index = (EbBWTIndex*)idx ;
      return index->writeIDs(fp) ;
      }
   return true ;
}

//----------------------------------------------------------------------

bool EbBWTIndex::write(const char *filename, bool keep_IDs,
			 EBMTIndex *index, bool compress_index)
{
   if (filename && *filename)
      {
      if (idlist)
	 {
	 setEOR(INDEX_EOR_VALUE) ;
	 idlist = idlist->reverse() ;
	 if (!wordIDs)
	    {
	    // reserve extra space in the memory allocation so that we don't
	    //   end up fragmenting memory when adding the new items
	    wordIDs = deconstruct(FrCountWordIDs(idlist)+1) ;
	    m_idcount = totalItems() ;
	    }
	 uint32_t *wIDs = FrAugmentWordIDArray(idlist,wordIDs,m_idcount,
					       EORvalue(),true) ;
	 if (!wIDs)
	    {
	    idlist = idlist->reverse() ;
	    return false ;
	    }
	 wordIDs = wIDs ;
	 idlist->freeIDList() ;
	 idlist = 0 ;
	 uint32_t *IDs ;
	 if (keep_IDs)
	    {
	    IDs = FrNewN(uint32_t,m_idcount) ;
	    if (!IDs)
	       {
	       FrNoMemory("generating index to save") ;
	       return false ;
	       }
	    memcpy(IDs,wordIDs,m_idcount*sizeof(uint32_t)) ;
	    }
	 else
	    IDs = wordIDs ;
	 FramepaC_gc() ;
	 makeIndex(IDs,m_idcount,FrBWT_KeepEOR,EORvalue(),quiet_mode?0:&cout) ;
	 if (keep_IDs)
	    FrFree(IDs) ;
	 if (index)
	    {
	    // A side-effect of makeIndex is that it overwrites all
	    //   non-EOR values in 'wordIDs' with pointers to the location
	    //   in the index pointing back at that wordID.  We make use
	    //   of this feature to extract pointers to the beginnings of
	    //   lines, which will later let us reconstruct the matched
	    //   source-language text.
	    size_t linenum = 0 ;
	    size_t i = 0 ;
	    uint32_t eor = EORvalue() ;
	    do {
	       index->setIndexLocation(linenum,wordIDs[i]) ;
	       while (i < m_idcount && wordIDs[i] < eor)
		  i++ ;
	       if (wordIDs[i] >= eor)
		  {
		  linenum = wordIDs[i] - eor ;
		  i++ ;
		  }
	       } while (i < m_idcount) ;
	    }
	 if (compress_index)
	    compress() ;
	 }
      bool success ;
      if (keep_IDs)
	 success = save(filename,write_IDs,this) ;
      else
	 {
	 success = save(filename) ;
	 if (success)
	    {
	    FrFree(wordIDs) ;
	    wordIDs = 0 ;
	    m_idcount = 0 ;
	    }
	 }
      if (success)
	 m_changed = false ;
      return success ;
      }
   return false ;
}

//----------------------------------------------------------------------

bool EbBWTIndex::writeIDs(FILE *fp) const
{
   if (fp)
      {
      if (wordIDs && m_idcount > 0)
	 {
	 char *IDs = FrNewN(char,m_idcount * sizeof(LONGbuffer)) ;
	 if (IDs)
	    {
	    for (size_t i = 0 ; i < m_idcount ; i++)
	       FrStoreLong(wordIDs[i],IDs + sizeof(LONGbuffer) * i) ;
	    bool success = Fr_fwrite(IDs,sizeof(LONGbuffer),m_idcount,fp) ;
	    FrFree(IDs) ;
	    return success ;
	    }
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

FrList *EbBWTIndex::retrieveSource(size_t location, FrVocabulary *vocab,
				   size_t maxlen) const
{
   FrList *source = 0 ;
   size_t count = 0 ;
   if (compressed())
      {
      while (location < EORvalue() && count++ < maxlen)
	 {
	 uint32_t id = getID(location) ;
	 location = getCompressedSuccessor(location) ;
	 if (id != recordStartID())
	    {
	    const char *word = vocab->nameForID(id) ;
	    pushlist(new FrConstString(word),source) ;
	    }
	 }
      }
   else
      {
      while (location < EORvalue() && count++ < maxlen)
	 {
	 uint32_t id = getID(location) ;
	 location = getUncompSuccessor(location) ;
	 if (id != recordStartID())
	    {
	    const char *word = vocab->nameForID(id) ;
	    pushlist(new FrConstString(word),source) ;
	    }
	 }
      }
   return source ;
}

//----------------------------------------------------------------------

bool EbBWTIndex::dump(FILE *fp, const FrVocabulary *vocab,
			bool print_recnum, EBMTIndex *index) const
{
   bool success = false ;
   if (fp && vocab)
      {
      uint32_t *IDs = deconstruct() ;
      if (IDs)
	 {
	 size_t idcount = totalItems() ;
	 size_t count = 0 ;
	 for (size_t i = 0 ; i < idcount ; i++)
	    {
	    if (IDs[i] < EORvalue())
	       {
	       if (IDs[i] == recordStartID())
		  continue ;
	       if (count)
		  fputc(' ',fp) ;
	       const char *word = vocab->nameForID(IDs[i]) ;
	       if (word)
		  fputs(word,fp) ;
	       else
		  fprintf(fp,"<?%lu>",(unsigned long)(IDs[i])) ;
	       count++ ;
	       }
	    else
	       {
	       if (print_recnum)
		  {
		  size_t recnum = IDs[i] - EORvalue() ;
		  fprintf(fp," [%06lu/%lu",(unsigned long)recnum,
			  (unsigned long)count) ;
		  if (index && recnum < index->numSentencePairs() &&
		      index->sourceLength(recnum) != count)
		     fprintf(fp,"*%lu",
			     (unsigned long)index->sourceLength(recnum)) ;
		  fputc(']',fp) ;
		  }
	       fputc('\n',fp) ;
	       count = 0 ;
	       }
	    }
	 if (count)
	    fputc('\n',fp) ;
	 success = true ;
	 FrFree(IDs) ;
	 }
      }
   return success ;
}

// end of file ebbwtidx.cpp //
