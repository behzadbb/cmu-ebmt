/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.91							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebtoken.cpp	word/phrase tokenizer				*/
/*  LastEdit: 11feb10							*/
/*									*/
/*  (c) Copyright 1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,	*/
/*		2006,2007,2008,2009,2010 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#if defined(__GNUC__)
#  pragma implementation "ebtoken.h"
#endif

#include "frassert.h"
#include "frstring.h"
#include "ebcorpus.h"
#include "ebtoken.h"
#include "ebglobal.h"
#include <sys/stat.h>

#ifdef unix
#include <unistd.h>
#endif /* unix */

/************************************************************************/
/*	Global Data for this module					*/
/************************************************************************/

#ifndef NDEBUG
// save space in executable
# undef _FrCURRENT_FILE
//static const char _FrCURRENT_FILE[] = __FILE__ ;
#endif /* NDEBUG */

/************************************************************************/
/************************************************************************/

bool Tokenizer::setTemporaryCorpus(const char *dict_file,
				   const char *parent_dir)
{
   FrFree(m_tempdir) ;
   m_tempdir = FrTempFile("wordclus",parent_dir) ;
   if (m_tempdir)
      {
      // FrTempFile generates a file, not a directory, so remove the file
      //   and create a directory in its place
      Fr_unlink(m_tempdir) ;
      if (mkdir(m_tempdir,0700) == 0)
	 {
	 m_tempcorpus = new EBMTCorpus(m_tempdir, 0, dict_file,
				       true, 0, true);
	 return true ;
	 }
      else
	 {
	 FrFree(m_tempdir); 
	 m_tempdir = 0 ;
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

bool Tokenizer::addTokenization(FrSymbol *class_name,
				const FrList *src, const FrList *trg)
{
   FrList *equiv = new FrList(src,trg) ;
   FrList *equivs = new FrList(equiv) ;
   bool success = addTokenizations(class_name,equivs) ;
   poplist(equivs) ;
   equiv->eraseList(false) ;
   return success ;
}

//----------------------------------------------------------------------

bool Tokenizer::addTokenizations(FrSymbol *class_name,
				 const FrList *equivs, bool reverse)
{
   if (m_tempcorpus && class_name)
      {
      // convert the equivalences into a format which can be fed to EBMTIndex
      for ( ; equivs ; equivs = equivs->rest())
	 {
	 const FrList *equiv = (FrList*)equivs ;
	 const FrList *src = (FrList*)equiv->first() ;
	 const FrList *trg = (FrList*)equiv->second() ;
	 if (src && trg)
	    {
	    if (reverse)
	       {
	       const FrList *tmp = src ;
	       src = trg ;
	       trg = tmp ;
	       }
	    FrString *srcstr ;
	    if (src->consp())
	       srcstr = new FrString(src) ;
	    else
	       srcstr = new FrString(src->printableName()) ;
	    FrString *trgstr ;
	    if (trg->consp())
	       trgstr = new FrString(trg) ;
	    else
	       trgstr = new FrString(trg->printableName()) ;
	    char *tag = Fr_aprintf(";;;(TOKEN %s)",
				   class_name->printableName()) ;
	    FrString *tagstr = new FrString(tag,strlen(tag),1,false);
	    FrList *pair = new FrList(srcstr,trgstr,tagstr) ;
	    pushlist(pair,m_pending) ;
	    }
	 }
      }
   return true ;
}

//----------------------------------------------------------------------

bool Tokenizer::setupComplete(bool force_quiet)
{
   if (m_tempcorpus && m_pending)
      {
      EBMTIndex *index = m_tempcorpus->getIndex() ;
      index->addPairs(m_pending,false,false,true,force_quiet) ;
      m_pending->freeObject() ;
      m_pending = 0 ;
      }
   return true ;
}

// end of file ebtoken2.C //
