/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebcorps2.cpp	EBMT corpus manipulation			*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2009 Ralf Brown				*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#if defined(__GNUC__)
#  pragma implementation "ebcorpus.h"
#endif

#include "dict.h"
#include "ebcorpus.h"
#include "ebglobal.h"

/************************************************************************/
/************************************************************************/

//----------------------------------------------------------------------

static bool only_symbols(const FrList *list)
{
   for ( ; list ; list = list->rest())
      {
      FrObject *obj = list->first() ;
      if (!obj || !obj->symbolp())
	 return false ;
      }
   return true ;
}

//----------------------------------------------------------------------

static bool def_equal(const FrObject *o1, const FrObject *o2)
{
   // input: o1 = translation to check for duplication, without frequency
   //        o2 = definition from current list, including frequency
   if (o1 == o2)
      return true ;
   else if (!o1 || !o2)
      return false ;
   if (o2->consp())
      o2 = o2->car() ;
   return ::equal(o1,o2) ;
}

//----------------------------------------------------------------------

static FrList *preprocess_counted_word_translations(FrList *translations,
						    EBMTCorpus * /*corpus*/)
{
   FrList *result = 0 ;
   symPERIOD = makeSymbol(".") ;
   for ( ; translations ; translations = translations->rest())
      {
      FrObject *translation = translations->first() ;
      if (translation)
	 {
	 FrObjectType otype = translation->objType() ;
	 if ((otype == OT_Symbol && translation != symPERIOD))
	    {
	    if (!result->member(translation))
	       pushlist(new FrList(translation,new FrInteger(0)),result) ;
	    }
	 else if (otype == OT_List || otype == OT_Cons)
	    {
	    FrObject *t = ((FrList*)translation)->first() ;
	    FrObject *count = ((FrList*)translation)->second() ;
	    if (!t || !count)
	       continue ;
	    if (t->consp() && !((FrList*)t)->rest())
	       t = ((FrList*)t)->first() ; // if single item, take out of list
	    if (t->stringp())
	       {
	       const char *str = ((FrString*)t)->stringValue() ;
	       t = FrCvtString2Symbollist(str,word_delimiters) ;
	       if (!t)
		  continue ;
	       if (t->consp() && !((FrList*)t)->rest())
		  {
		  FrList *trans = (FrList*)t ;
		  t = poplist(trans) ;
		  }
	       }
	    else
	       t = t->deepcopy() ;
	    if (!result->member(t,def_equal))
	       pushlist(new FrList(t,count->deepcopy()),result) ;
	    }
	 else if (otype == OT_FrString)
	    {
	    const char *str = ((FrString*)translation)->stringValue() ;
	    FrList *trans = FrCvtString2Symbollist(str,word_delimiters) ;
	    if (trans)
	       {
	       if (trans->rest()) // multi-word definition?
		  {
		  if (!result->member(trans,def_equal))
		     pushlist(new FrList(trans,new FrInteger(0)),result) ;
		  else
		     trans->freeObject() ;
		  }
	       else // single-word definition
		  {
		  FrObject *wrd = poplist(*((FrList**)&trans)) ;
		  if (!result->member(wrd,def_equal))
		     pushlist(new FrList(wrd,new FrInteger(0)),result) ;
		  else if (wrd)
		     wrd->freeObject() ;
		  }
	       }
	    }
	 }
      }
   return listreverse(result) ;
}

//----------------------------------------------------------------------

void EBMTCorpus::addTranslations(FrObject *sword, FrList *twords,
				 bool override_existing)
{
   sword = FrCvt2Symbol(sword,char_encoding) ;
   if (!sword)
      return ;
   if (twords)
      {
      if (!only_symbols(twords))
	 twords = preprocess_word_translations(twords,this) ;
      else
	 {
	 // remove duplicates
	 FrList *tw = 0 ;
	 for ( ; twords ; twords = twords->rest())
	    {
	    FrSymbol *word = (FrSymbol*)twords->first() ;
	    if (word && !tw->member(word))
	       pushlist(word,tw) ;
	    }
	 twords = listreverse(tw) ;
	 }
      }
   if (dictionary)
      {
      if (override_existing)
	 {
	 if (dictionary->defineWord((FrSymbol*)sword,twords))
	    new_translations = true ;
	 }
      else if (dictionary->addDefinitions((FrSymbol*)sword,twords))
	 new_translations = true ;
      }
   free_object(twords) ;
   return ;
}

//----------------------------------------------------------------------

void EBMTCorpus::addTranslationsCounted(FrObject *sword, FrList *twords,
					bool override_existing)
{
   sword = FrCvt2Symbol(sword,char_encoding) ;
   if (!sword || !dictionary)
      return ;
   size_t frequency = 0 ;
   if (twords && twords->first() && twords->first()->numberp())
      {
      frequency = (size_t)(twords->first()->intValue()) ;
      twords = twords->rest() ;
      }
   if (twords)
      twords = preprocess_counted_word_translations(twords,this) ;
   if (override_existing)
      {
      if (dictionary->defineWordCounted((FrSymbol*)sword,twords,frequency))
	 new_translations = true ;
      }
   else if (dictionary->addDefinitionsCounted((FrSymbol*)sword,twords,
					      frequency))
      new_translations = true ;
   free_object(twords) ;
   return ;
}

// end of file ebcorps2.cpp //
