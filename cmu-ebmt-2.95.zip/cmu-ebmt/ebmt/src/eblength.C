/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File eblength.cpp	sentence-length model builder			*/
/*  LastEdit: 08apr10							*/
/*									*/
/*  (c) Copyright 2010 Ralf Brown					*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "ebmt.h"
#include "ebutil.h"
#include "ebglobal.h"

/************************************************************************/
/*	Manifest Constants						*/
/************************************************************************/

#define MAX_SOURCE_WORDS 256

/************************************************************************/
/*	Types for this module						*/
/************************************************************************/

typedef uint64_t LengthCount ;

class EbLengthModel
   {
   private:
      size_t	  m_sentences ;
      size_t	  m_counts[MAX_SOURCE_WORDS] ;
      double      m_byteratio[MAX_SOURCE_WORDS] ;
      double      m_wordratio[MAX_SOURCE_WORDS] ;
      double      m_byte_short[3*MAX_SOURCE_WORDS] ; // count, sum, sum**2 //
      double	  m_byte_long[3*MAX_SOURCE_WORDS] ;  // count, sum, sum**2 //
      double      m_word_short[3*MAX_SOURCE_WORDS] ; // count, sum, sum**2 //
      double	  m_word_long[3*MAX_SOURCE_WORDS] ;  // count, sum, sum**2 //

   public:
      EbLengthModel() ;
      ~EbLengthModel() {}

      // accessors
      size_t totalSentences() const { return m_sentences ; }
      double meanSentenceLength() const ;

      // modifiers
      bool updateCounts(const char *source, const char *target, bool mean) ;
      void computeMeans() ;
      void makeBin(size_t shortest, size_t longest) ;

      // I/O
      bool writeStats(FILE *fp, size_t source_length) const ;
   } ;

/************************************************************************/
/*	Global variables for this module				*/
/************************************************************************/

static EbLengthModel *length_model = 0 ;

/************************************************************************/
/*	Helper functions						*/
/************************************************************************/

static void compute_length(const char *text, size_t &bytes, size_t &words)
{
   bytes = 0 ;
   words = 0 ;
   if (text)
      {
      for (const char *t = text ; *t ; t++)
	 {
	 if (!Fr_isspace(*t))
	    bytes++ ;
	 }
      words = EbWordCount(text) ;
      }
   return ;
}

//----------------------------------------------------------------------

static void update_variance(size_t source_words, double *table,
			    double ratio)
{
   if (ratio >= 1.0)
      ratio -= 1.0 ;
   table[3*source_words] ++ ;
   table[3*source_words+1] += ratio ;
   table[3*source_words+2] += (ratio * ratio) ;
   return ;
}

//----------------------------------------------------------------------

static void add_stats(double *short_table, double *long_table, size_t len,
		      size_t target)
{
   if (target != len)
      {
      short_table[3*target] += short_table[3*len] ;
      short_table[3*target+1] += short_table[3*len+1] ;
      short_table[3*target+2] += short_table[3*len+2] ;
      long_table[3*target] += long_table[3*len] ;
      long_table[3*target+1] += long_table[3*len+1] ;
      long_table[3*target+2] += long_table[3*len+2] ;
      }
   return ;
}

//----------------------------------------------------------------------

static void zero_stats(double *short_table, double *long_table, size_t len)
{
   short_table[3*len] = 0.0 ;
   short_table[3*len+1] = 0.0 ;
   short_table[3*len+2] = 0.0 ;
   long_table[3*len] = 0.0 ;
   long_table[3*len+1] = 0.0 ;
   long_table[3*len+2] = 0.0 ;
   return ;
}

//----------------------------------------------------------------------

static double stddev(const double *stats, size_t source_length)
{
   double count = stats[3*source_length] ;
   double var = stats[3*source_length+2] ;
   if (count > 0)
      {
      return ::sqrt(var / count) ;
      }
   else
      return 1.0 ;
}

/************************************************************************/
/************************************************************************/

EbLengthModel::EbLengthModel()
{
   m_sentences = 0 ;
   for (size_t i = 0 ; i < MAX_SOURCE_WORDS ; i++)
      {
      m_counts[i] = 0 ;
      m_byteratio[i] = 0.0 ;
      m_wordratio[i] = 0.0 ;
      }
   memset(m_byte_short,'\0',sizeof(m_byte_short)) ;
   memset(m_byte_long,'\0',sizeof(m_byte_long)) ;
   memset(m_word_short,'\0',sizeof(m_byte_short)) ;
   memset(m_word_long,'\0',sizeof(m_byte_long)) ;
   return ;
}

//----------------------------------------------------------------------

double EbLengthModel::meanSentenceLength() const
{
   double total = 0.0 ;
   if (m_sentences)
      {
      for (size_t i = 0 ; i < MAX_SOURCE_WORDS ; i++)
	 {
	 total += (i * m_counts[i]) ;
	 }
      total /= m_sentences ;
      }
   return total ;
}

//----------------------------------------------------------------------

bool EbLengthModel::updateCounts(const char *source, const char *target,
				 bool mean)
{
   size_t source_bytes, target_bytes, source_words, target_words ;
   compute_length(source,source_bytes,source_words) ;
   compute_length(target,target_bytes,target_words) ;
   if (source_words >= MAX_SOURCE_WORDS)
      source_words = MAX_SOURCE_WORDS - 1 ;
   double byte_ratio =
      source_bytes ? (target_bytes / (double)source_bytes) : 1.0 ;
   double word_ratio =
      target_bytes ? (target_words / (double)source_words) : 1.0 ;
   if (mean)
      {
      m_sentences++ ;
      m_counts[source_words]++ ;
      m_byteratio[source_words] += byte_ratio ;
      m_wordratio[source_words] += word_ratio ;
      }
   else // compute variance
      {
      if (byte_ratio <= m_byteratio[source_words])
	 {
	 update_variance(source_words,m_byte_short,
			 m_byteratio[source_words]/byte_ratio) ;
	 }
      if (byte_ratio >= m_byteratio[source_words])
	 {
	 update_variance(source_words,m_byte_long,
			 byte_ratio/m_byteratio[source_words]) ;
	 }
      if (word_ratio <= m_wordratio[source_words])
	 {
	 update_variance(source_words,m_word_short,
			 m_wordratio[source_words]/word_ratio) ;
	 }
      if (word_ratio >= m_wordratio[source_words])
	 {
	 update_variance(source_words,m_word_long,
			 word_ratio/m_wordratio[source_words]) ;
	 }
      }
   return true ;
}

//----------------------------------------------------------------------

void EbLengthModel::computeMeans()
{
   for (size_t i = 0 ; i < MAX_SOURCE_WORDS ; i++)
      {
      if (m_counts[i])
	 {
	 m_byteratio[i] /= m_counts[i] ;
	 m_wordratio[i] /= m_counts[i] ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void EbLengthModel::makeBin(size_t shortest, size_t longest)
{
   cout << "; binning lengths " << shortest << " through " << longest << endl ;
   size_t binpos = (shortest + longest + 1) / 2 ;
   size_t binsize = m_counts[binpos] ? 1 : 0 ;
   for (size_t i = shortest ; i <= longest ; i++)
      {
      if (i == binpos || m_counts[i] == 0)
	 continue ;
      binsize++ ;
      add_stats(m_byte_short,m_byte_long,i,binpos) ;
      add_stats(m_word_short,m_word_long,i,binpos) ;
      zero_stats(m_byte_short,m_byte_long,i) ;
      zero_stats(m_word_short,m_word_long,i) ;
      m_counts[binpos] += m_counts[i] ;
      m_byteratio[binpos] += m_byteratio[i] ;
      m_wordratio[binpos] += m_wordratio[i] ;
      m_counts[i] = 0 ;
      m_byteratio[i] = 0.0 ;
      m_wordratio[i] = 0.0 ;
      }
   if (binsize > 0)
      {
      m_byteratio[binpos] /= binsize; 
      m_wordratio[binpos] /= binsize ;
      }
   return ;
}

//----------------------------------------------------------------------

bool EbLengthModel::writeStats(FILE *fp, size_t source_length) const
{
   if (!fp || source_length >= MAX_SOURCE_WORDS)
      return false ;
   if (m_counts[source_length] < 2)
      return false ;
   fprintf(fp,"%3u  %f %f %f %f %f %f  %lu\n",
	   (unsigned)source_length,
	   m_byteratio[source_length],
	   stddev(m_byte_short,source_length),
	   stddev(m_byte_long,source_length),
	   m_wordratio[source_length],
	   stddev(m_word_short,source_length),
	   stddev(m_word_long,source_length),
	   (unsigned long)m_counts[source_length]) ;
   return true ;
}

//----------------------------------------------------------------------

static bool write_length_model(FILE *fp, EbLengthModel *model)
{
   if (fp && model)
      {
      fprintf(fp,"#len b-ratio  b-short  b-long   w-ratio  w-short  w-long    count\n") ;
      for (size_t i = 0 ; i < MAX_SOURCE_WORDS ; i++)
	 {
	 model->writeStats(fp,i) ;
	 }
      fflush(fp) ;
      return true ;
      }
   return false ;
}

/************************************************************************/
/************************************************************************/

void EbLengthModelInit() 
{
   length_model = new EbLengthModel ;
   return ;
}

//----------------------------------------------------------------------

bool EbLengthModelUpdate(const char *filename, bool mean)
{
   if (!length_model)
      {
      cout << "; internal error: length model not initialized" << endl ;
      return false ;
      }
   if (!filename || !*filename)
      return false ;
   FILE *fp = fopen(filename,"r") ;
   if (!fp)
      {
      cout << "; unable to open file " << filename << endl ;
      return false ;
      }
   if (!quiet_mode)
      cout << "; gathering statistics from " << filename << endl ;
   bool read_data = false ;
   while (!feof(fp))
      {
      char *ssent, *tsent, *tags ;
      if (read_EBMT_entry(fp,lowercase_table,ssent,tsent,tags,
			  ignore_source_case,0,0,0))
	 {
	 read_data = true ;
	 length_model->updateCounts(ssent,tsent,mean) ;
	 }
      FrFree(ssent) ;
      FrFree(tsent) ;
      FrFree(tags) ;
      }
   fclose(fp) ;
   return read_data ;
}

//----------------------------------------------------------------------

bool EbLengthModelFinishMeans()
{
   if (length_model)
      {
      length_model->computeMeans() ;
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

bool EbLengthModelFinalize(const char *model_file, bool show_on_stdout)
{
   if (!length_model)
      return false ;
   cout << "; " << length_model->totalSentences()
	<< " sentences, average source length "
	<< length_model->meanSentenceLength() << " words" << endl ;
   length_model->makeBin(3*MAX_SOURCE_WORDS/4,MAX_SOURCE_WORDS-1) ;
   length_model->makeBin(MAX_SOURCE_WORDS/2,3*MAX_SOURCE_WORDS/4-1) ;
   length_model->makeBin(3*MAX_SOURCE_WORDS/8,MAX_SOURCE_WORDS/2-1) ;
   length_model->makeBin(MAX_SOURCE_WORDS/4,3*MAX_SOURCE_WORDS/8-1) ;
   length_model->makeBin(7*MAX_SOURCE_WORDS/32,MAX_SOURCE_WORDS/4-1) ;
   length_model->makeBin(3*MAX_SOURCE_WORDS/16,7*MAX_SOURCE_WORDS/32-1) ;
   FILE *fp = 0 ;
   if (model_file && *model_file)
      fp = fopen(model_file,"w") ;
   if (!fp || show_on_stdout)
      {
      cout << ";##### sentence-length model #####" << endl ;
      write_length_model(stdout,length_model) ;
      cout << ";##### end of length model #####" << endl ;
      }
   if (fp)
      {
      cout << "; writing length model to " << model_file << endl ;
      write_length_model(fp,length_model) ;
      fclose(fp) ;
      }
   else if (model_file)
      cout << "; unable to open '" << model_file << "' for writing." << endl ;
   delete length_model ;
   length_model = 0 ;
   return true ;
}

// end of file eblength.cpp //
