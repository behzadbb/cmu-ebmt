/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebctoken.cpp	tokenizer file converter			*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1996,1997,1998,1999,2000,2002,2003,2004,2005,2006,	*/
/*		2008,2009 Ralf Brown					*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "frfilutl.h"
#include "frregexp.h"
#include "ebindex.h"
#include "ebtoken.h"
#include "ebutil.h"    // for is_number() and remove_punctuation()
#include "ebglobal.h"

#include <wchar.h>
#ifdef unix
#include <unistd.h>
#endif /* unix */

/************************************************************************/
/*	Manifest constants for this module				*/
/************************************************************************/

#define AT_PREFIX "@@"
#define AT_PREF_LEN 2
#define CANON_AT_PREFIX "@ @ "
#define CANON_AT_LEN 4
#define AT_BEGIN AT_PREFIX"begin"
#define AT_BEGIN_LEN 7
#define AT_END AT_PREFIX"end"
#define AT_END_LEN 5

/************************************************************************/
/*	Global Data for this module					*/
/************************************************************************/

static const char token_file_signature[] = TOKEN_FILE_SIGNATURE ;

static const char text_read_mode[] = "r" ;
static const char text_write_mode[] = "w" ;

//#ifndef NDEBUG
// save space in executable
//# undef _FrCURRENT_FILE
//static const char _FrCURRENT_FILE[] = __FILE__ ;
//#endif /* NDEBUG */

/************************************************************************/
/*	Forward/External declarations					*/
/************************************************************************/

FrList *remove_ignored_tokenizer_items(const FrList *symlist) ;

static void do_INCLUDE_command(FrObject *infilename, FILE *outfp,
			       FILE *regexfp, const char *srclang,
			       const char *trglang, const char *basedir,
			       EBMTIndex *index,bool regex_only) ;

static void process_command(FrSymbol *obj1, FrObject *obj2,
			    FrSymbol *&curr_token, FrList *&exceptions,
			    FrSymHashTable *regex_names, FILE *infp,
			    FILE *outfp, FILE *regexfp, bool &warned,
			    bool at_cmd, const char *srclang,
			    const char *trglang, bool reverse,
			    bool unicode = false, const char *basedir = 0,
			    const char *tokfile = 0, EBMTIndex *index = 0) ;

static bool convert_token_file(FILE *infp, FILE *outfp, FILE *regexfp,
				 const char *srclang,const char *trglang,
				 const char *basedir, const char *tokfile,
				 EBMTIndex *index,
				 bool unicode = false,
				 bool check_signature = true,
				 bool regex_only = false) ;

/************************************************************************/
/************************************************************************/

inline const char *skip_whitespace(const char *s)
{
   if (s)
      {
      while (Fr_isspace(*s))
	 s++ ;
      }
   return s ;
}

//----------------------------------------------------------------------

static char *strip_comment(char *line)
{
   // remove any comment at the end of the line
   // need to keep track of whether we're inside a string in double quotes
   char *end = line ;
   bool inside_string = false ;
   bool quoted = false ;
   for ( ; *end && (*end != TOKEN_COMMENT_CHAR || inside_string) ; end++)
      {
      if (quoted)
	 quoted = false ;
      else if (*end == '\\' && inside_string)
	 quoted = true ;
      else if (*end == '"')
	 inside_string = !inside_string ;
      }
   *end = 0 ;
   return end ;
}

//----------------------------------------------------------------------

static bool get_stripped_line(FILE *infp, char *line, size_t len)
{
   line[0] = 0 ;
   if (!Fr_utf8gets(infp,line,len,Unicode_bswap))
      return false ;
   char *end = strip_comment(line) ;
   // remove trailing whitespace
   while (end > line && Fr_isspace(end[-1]))
      *--end = 0 ;
   return true ;
}

//----------------------------------------------------------------------

#if 0
/*inline*/ void insert_quoted_char(char c, char *&s)
{
   if (c == '\0')
      {
      *s++ = '\\' ;
      c = '0' ;
      }
   else if (c == '\'' || c == '"' || c == '\\')
      *s++ = '\\' ;
   *s++ = c ;
   return ;
}
#endif

//----------------------------------------------------------------------

static bool check_token_signature(FILE *fp, char *line, size_t len,
				    const char *srclang, const char *trglang,
				    bool &reverse, bool unicode = false,
				    bool warn = true)
{
   line[0] = '\0' ;
   if (unicode)
      Fr_utf8gets(fp,line,len,Unicode_bswap) ;
   else
      fgets(line,len,fp) ;
   const char *lineptr = line ;
   FrObject *obj = string_to_FrObject(lineptr) ;
   FrConstString signature(token_file_signature) ;
   if (!obj || !obj->stringp() || !::equal(obj,&signature))
      {
      if (warn)
	 {
	 FrWarning("invalid token file") ;
	 free_object(obj) ;
	 }
      return false ;
      }
   free_object(obj) ;
   FrSymbol *symEOF = makeSymbol("*EOF*") ;
   obj = string_to_FrObject(lineptr) ;
   if (obj != symEOF && (srclang || trglang))
      {
      if (obj && obj->stringp())
	 {
	 FrConstString source(srclang) ;
	 FrConstString target(trglang) ;
	 if (EBMT_equal(obj,&target))
	    reverse = true ;
	 else
	    {
	    FrObject *obj2 = string_to_FrObject(lineptr) ;
	    if (!EBMT_equal(obj,&source) ||
		(obj2 && obj2->stringp() && !::equal(obj2,&target)))
	       FrWarningVA("this token file does not appear to translate\n"
			   "\tbetween %s and %s!",srclang,trglang) ;
	    free_object(obj2) ;
	    }
	 }
      }
   free_object(obj) ;
   return true ;
}

//----------------------------------------------------------------------

static FrSymHashTable *convert_regexes(FILE *infp, FILE *outfp,
				       const char *srclang,const char *trglang,
				       const char *basedir, EBMTIndex *index,
				       bool reverse, bool unicode = false)
{
   FrSymHashTable *regex_names = new FrSymHashTable(100) ;
   off_t startpos = ftell(infp) ;
   FrSymbol *symREGEX = makeSymbol("REGEX") ;
   FrSymbol *symREVRE = makeSymbol("REVREGEX") ;
   FrSymbol *symINCLUDE = makeSymbol("INCLUDE") ;
   FrSymbol *symEOF = makeSymbol("*EOF*") ;
   char line[FrMAX_LINE] ;
   while (!feof(infp))
      {
      line[0] = '\0' ;
      char *got ;
      if (unicode)
	 got = (char*)Fr_utf8gets(infp,line,sizeof(line), Unicode_bswap) ;
      else
	 got = fgets(line,sizeof(line),infp) ;
      if (got && !feof(infp))
	 {
	 strip_comment(line) ;
	 const char *lineptr = skip_whitespace(line) ;
	 if (Fr_strnicmp(lineptr,AT_BEGIN,AT_BEGIN_LEN) == 0)
	    {
	    int at_marker ;
	    do {
	       line[0] = '\0' ;
	       fgets(line,sizeof(line),infp) ;
	       lineptr = skip_whitespace(line) ;
	       at_marker = Fr_strnicmp(lineptr,AT_END,AT_END_LEN) ;
	       } while (!feof(infp) && at_marker != 0) ;
	    }
	 else if (strncmp(lineptr,AT_PREFIX,AT_PREF_LEN) == 0)
	    lineptr += AT_PREF_LEN ;
	 FrObject *obj1 = string_to_FrObject(lineptr) ;
	 FrObject *obj2 = string_to_FrObject(lineptr) ;
	 if (((!reverse && obj1==symREGEX) || (reverse && obj1==symREVRE)) &&
	      obj2 && obj2 != symEOF)
	    {
	    FrObject *token = string_to_FrObject(lineptr) ;
	    FrObject *translation = string_to_FrObject(lineptr) ;
	    if (!token || token == symEOF)
	       FrWarning("missing token in REGEX/REVREGEX line") ;
	    else if (!translation || translation == symEOF)
	       FrWarning("missing translation in REGEX/REVREGEX line") ;
	    else
	       {
	       char *printed = obj2->print() ;
	       fputs(printed,outfp) ;
	       FrFree(printed) ;
	       (void)putc(' ',outfp) ;
	       FrSymbol *tokensym = FrCvt2Symbol(token,char_encoding) ;
	       char *token_name = EbStripCoindex(tokensym->symbolName(),
						 char_encoding) ;
	       (void)putc('|',outfp) ;
	       fputs(token_name,outfp) ;
	       (void)putc('|',outfp) ;
	       FrFree(token_name) ;
	       (void)putc(' ',outfp) ;
	       printed = translation->print() ;
	       fputs(printed,outfp) ;
	       FrFree(printed) ;
	       (void)putc('\n',outfp) ;
	       regex_names->add(tokensym,(FrObject*)0) ;
	       }
	    free_object(token) ;
	    free_object(translation) ;
	    }
	 else if (obj1 == symINCLUDE)
	    do_INCLUDE_command(obj2,outfp,outfp,srclang,trglang,basedir,index,
			       true);
	 free_object(obj1) ;
	 free_object(obj2) ;
	 }
      }
   fseek(infp,startpos,SEEK_SET) ;
   return regex_names ;
}

//----------------------------------------------------------------------
// add the given words/phrases to the indexed corpus as a tagged entry
//

static void index_token_entry(EBMTIndex *index, FILE *corpusfp,
			      FrSymbol *token, FrList *src, FrList *trg,
			      bool reverse = false)
{
   if (!src || !trg || !token)
      return ;
   if (reverse)
      {
      FrList *tmp = src ;
      src = trg ;
      trg = tmp ;
      }
   FrList *src2 = remove_ignored_tokenizer_items(src) ;
   FrString *source = new FrString(src2) ;
   src2->eraseList(false) ;
   FrString *target = new FrString(trg) ;
   if (source && target)
      {
      char tags[2*FrMAX_SYMBOLNAME_LEN] ;
      Fr_sprintf(tags,sizeof(tags),
		 ";;;(TOKEN %s)%c",token->symbolName(),'\0') ;
      char *sourcestr = FrDupString(source->stringValue()) ;
      const char *targetstr = target->stringValue() ;
      bool no_tokenizer = true ;
      if (index->indexSentencePair(sourcestr,targetstr,tags,corpusfp,
				   EbIndex_Main,true,true,&no_tokenizer))
	 index->incrTokenFileEntries() ;
      FrFree(sourcestr) ;
      }
   free_object(source) ;
   free_object(target) ;
   return ;
}

//----------------------------------------------------------------------

static void add_to_exceptions(FrList *&exceptions, const FrObject *except)
{
   if (except)
      {
      if (except->symbolp())
	 {
	 pushlist(except,exceptions) ;
	 }
      else if (except->stringp())
	 {
	 const char *string = ((FrString*)except)->stringValue() ;
	 FrList *src = FrCvtString2Symbollist(string,word_delimiters) ;
	 if (src)
	    pushlist(src,exceptions) ;
	 }
      else if (except->consp())
	 {
	 for (const FrList *ex = (FrList*)except ; ex ; ex = ex->rest())
	    {
	    FrObject *ex1 = ex->first() ;
	    if (ex1)
	       {
	       if (ex1->consp())
		  {
		  FrString *str = new FrString((FrList*)ex1,char_encoding) ;
		  add_to_exceptions(exceptions,str) ;
		  free_object(str) ;
		  }
	       else
		  add_to_exceptions(exceptions,ex1) ;
	       }
	    }
	 }
      else
	 {
	 char *line = except->print() ;
	 FrWarningVA("invalid format in EXCEPT line: %s",line) ;
	 FrFree(line) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

static char *remove_blanks(const char *line, size_t len = 0)
{
   if (!line)
      return 0 ;
   if (!len)
      len = strlen(line) ;
   char *result = FrNewN(char,len+1) ;
   if (result)
      {
      char *loc = result ;
      for ( ; *line && len > 0 ; line++, len--)
	 {
	 // skip quoted NULs as well as all whitespace
	 if (line[0] == '\\' && line[1] == '0')
	    line++ ;
	 else if (!Fr_isspace(*line))
	    *loc++ = *line ;
	 }
      *loc = '\0' ;			// ensure proper termination
      }
   return result ;
}

//----------------------------------------------------------------------

static void do_INCLUDE_command(FrObject *infilename, FILE *outfp,
			       FILE *regexfp, const char *srclang,
			       const char *trglang, const char *basedir,
			       EBMTIndex *index,bool convert_regex)
{
   if (!infilename || !infilename->stringp())
      {
      FrWarning("you must specify a filename for INCLUDE") ;
      return ;
      }
   const char *infile = ((FrString*)infilename)->stringValue() ;
   if (!infile || !*infile)
      {
      FrWarning("can't include a file if you give an empty filename") ;
      return ;
      }
   char *full_infile = FrAddDefaultPath(infile,basedir) ;
   FILE *infp = fopen(full_infile,"r") ;
   if (!infp)
      {
      FrWarningVA("INCLUDE command unable to open '%s'",full_infile) ;
      FrFree(full_infile) ;
      return ;
      }
//   cout << "INCLUDEing: " << full_infile << endl ;
   FrFree(full_infile) ;
   FrFILETYPE ft = FrFileType(infp) ;
   bool success = false ;
   if (ft == FrFT_ASCII || ft == FrFT_UTF8)
      success = convert_token_file(infp,outfp,regexfp,srclang,trglang,basedir,
				   infile,index,false,false,convert_regex) ;
   else if (ft == FrFT_UNICODE)
      success = convert_token_file(infp,outfp,regexfp,srclang,trglang,basedir,
				   infile,index,true,false,convert_regex) ;
   else
      FrWarningVA("Tokenization INCLUDE file '%s'"
		  "\tdoes not appear to be either ASCII or Unicode!",
		  infile) ;
   return ;
}

//----------------------------------------------------------------------

static void do_LOAD_command(FrSymbol *token, FrObject *filename,
			    FrList *exceptions, FILE *outfp, EBMTIndex *index,
			    bool /*unicode = false*/, const char *basedir = 0,
			    const char *tokfile = 0)
{
   if (!token)
      FrWarning("LOAD command is only available between BEGIN/END !");
   else if (!filename || filename == makeSymbol("*EOF*"))
      FrWarning("missing filename in LOAD line") ;
   else if (!filename->stringp())
      FrWarning("filename for LOAD must be inside double quotes") ;
   else
      {
      char *fn = remove_blanks(((FrString*)filename)->stringValue(),
			       ((FrString*)filename)->stringLength()) ;
      char *name = FrAddDefaultPath(fn,basedir) ;
      FrFree(fn) ;
      FILE *loadfp = fopen(name,"r") ;
      if (loadfp)
	 {
	 FrFILETYPE ft = FrFileType(loadfp) ;
	 switch (ft)
	    {
	    case FrFT_ASCII:
	    case FrFT_UTF8:
	       while (!feof(loadfp))
		  {
		  char line[FrMAX_LINE] ;
		  line[0] = '\0' ;
		  fgets(line,sizeof(line),loadfp) ;
		  const char *lineptr = skip_whitespace(line) ;
		  // skip comment-only lines
		  strip_comment((char*)lineptr) ;
		  FrList *words = FrCvtString2Wordlist(lineptr,
						       word_delimiters,
						       abbrevs_list,
						       char_encoding) ;
		  if (words)			// skip blank and comment lines
		     {
		     if (!exceptions->member(words,EBMT_equal))
			index_token_entry(index,outfp,token,words,words,false) ;
		     words->freeObject() ;
		     }
		  }
	       break ;
	    case FrFT_UNICODE:
	       while (!feof(loadfp))
		  {
		  char line[3*FrMAX_LINE] ;
		  get_stripped_line(loadfp,line,lengthof(line)) ;
		  const char *lineptr = skip_whitespace(line) ;
		  FrList *words = FrCvtString2Wordlist(lineptr,
						       word_delimiters,
						       abbrevs_list,
						       char_encoding) ;
		  if (words)			// skip blank and comment lines
		     {
		     if (!exceptions->member(words,EBMT_equal))
			index_token_entry(index,outfp,token,words,words,false) ;
		     words->freeObject() ;
		     }
		  }
	       break ;
	    default:
	       FrWarningVA("LOAD file '%s' isn't text!",name) ;
	       break ;
	    }
	 fclose(loadfp) ;
	 }
      else
	 FrWarningVA("unable to open file %s for LOAD in %s",name,tokfile) ;
      FrFree(name) ;
      }
   return ;
}

//----------------------------------------------------------------------

static void get_glossary_entry_Unicode(FILE *fp, FrList *&source,
				       FrList *&target)
{
   char line[3*FrMAX_LINE] ;
   source = 0 ;
   target = 0 ;
   // step 1: skip blank and comment-only lines
   do {
      if (!get_stripped_line(fp,line,lengthof(line)))
	 return ;
      } while (!feof(fp) && line[0] == 0) ;
   if (feof(fp))
      return ;
   // step 2: get all un-indented lines, stopping on any blank or indented line
   do {
      FrString *str = new FrString(line) ;
      source = source->nconc(new FrList(str)) ;
      if (!get_stripped_line(fp,line,lengthof(line)) || line[0] == 0)
	 return ;
      } while (!feof(fp) && !Fr_iswspace(line[0])) ;
   // step 3: get all indented lines, ignoring blank lines
   off_t pos = ftell(fp) ;
   do {
      const char *lineptr = skip_whitespace(line) ;
      FrString *str = new FrString(lineptr) ;
      target = target->nconc(new FrList(str)) ;
      pos = ftell(fp) ;
      if (!get_stripped_line(fp,line,lengthof(line)))
	 {
	 fseek(fp,pos,SEEK_SET) ;
	 return ;
	 }
      } while (!feof(fp) && Fr_iswspace(line[0])) ;
   if (!feof(fp))
      fseek(fp,pos,SEEK_SET) ;
   return ;
}

//----------------------------------------------------------------------

static void convert_begin_end_block(FILE *infp, FILE *outfp, FILE *regexfp,
				    FrSymbol *token,
				    FrSymHashTable *regex_names,
				    bool reverse,
				    const char *srclang,
				    const char *trglang,
				    const char *basedir, const char *tokfile,
				    EBMTIndex *index,  bool unicode = false)
{
   FrList *source ;
   FrList *target ;
   FrList *exceptions = 0 ;
   bool warned = false ;
   while (!feof(infp))
      {
      if (unicode)
	 get_glossary_entry_Unicode(infp,source,target) ;
      else
	 get_glossary_entry(infp,source,target,reverse,true) ;
      if (reverse)
	 {
	 // we had to let get_glossary_entry() switch source&target to get the
	 // <norecognize> & <nogenerate> markers right, but now we need to
	 // unswitch to properly handle the @@ commands, and then let
	 // index_token_entry() re-swap as needed
	 FrList *tmp = source ;
	 source = target ;
	 target = tmp ;
	 }
      while (source)
	 {
	 FrString *src = (FrString*)source->first() ;
	 if (strncmp(src->stringValue(),AT_PREFIX,AT_PREF_LEN) == 0 ||
	     strncmp(src->stringValue(),CANON_AT_PREFIX,CANON_AT_LEN) == 0)
	    {
	    const char *lineptr ;
	    if (strncmp(src->stringValue(),AT_PREFIX,AT_PREF_LEN) == 0)
	       lineptr = src->stringValue()+AT_PREF_LEN ;
	    else
	       lineptr = src->stringValue()+CANON_AT_LEN ;
	    FrObject *obj1 = string_to_FrObject(lineptr) ;
	    FrObject *obj2 = string_to_FrObject(lineptr) ;
	    if (obj1 && obj2 && obj1->symbolp() && obj2 != makeSymbol("*EOF*"))
	       {
	       if (obj1 == makeSymbol("END"))
		  {
		  free_object(obj2) ;
		  free_object(source) ;
		  free_object(target) ;
		  return ;
		  }
	       process_command((FrSymbol*)obj1,obj2,token,exceptions,
			       regex_names,infp,outfp,regexfp,warned,true,
			       srclang,trglang,reverse,unicode,basedir,
			       tokfile,index) ;
	       }
	    else
	       free_object(obj2) ;
	    (void)poplist(source) ;
	    free_object(obj1) ;
	    free_object(src) ;
	    }
	 else
	    break ;
	 }
      if (source)
	 {
	 for (FrList *src = source ; src ; src = src->rest())
	    {
	    for (FrList *trg = target ; trg ; trg = trg->rest())
	       {
	       const char *str ;
	       str = ((FrString*)src->first())->stringValue() ;
	       FrList *s = FrCvtString2Wordlist(str,word_delimiters,
						abbrevs_list,char_encoding) ;
	       str = ((FrString*)trg->first())->stringValue() ;
	       FrList *t = FrCvtString2Wordlist(str,word_delimiters,
						abbrevs_list,char_encoding) ;
	       index_token_entry(index,outfp,token,s,t,reverse) ;
	       free_object(s) ;
	       free_object(t) ;
	       }
	    }
	 source->freeObject() ;
	 }
      free_object(target) ;
      }
   return ;
}

//----------------------------------------------------------------------

static void process_command(FrSymbol *obj1, FrObject *obj2,
			    FrSymbol *&curr_token, FrList *&exceptions,
			    FrSymHashTable *regex_names, FILE *infp,
			    FILE *outfp, FILE *regexfp, bool &warned,
			    bool at_cmd, const char *srclang,
			    const char *trglang, bool reverse,
			    bool unicode, const char *basedir,
			    const char *tokfile,
			    EBMTIndex *index)
{
   FrSymbol *symBEGIN = makeSymbol("BEGIN") ;
   FrSymbol *symEND = makeSymbol("END") ;
   FrSymbol *symINCLUDE = makeSymbol("INCLUDE") ;
   FrSymbol *symLOAD = makeSymbol("LOAD") ;
   FrSymbol *symEXCEPT = makeSymbol("EXCEPT") ;
   FrSymbol *symREGEX = makeSymbol("REGEX") ;
   FrSymbol *symREVRE = makeSymbol("REVREGEX") ;
   if (obj1 == symREGEX || obj1 == symREVRE)
      {
      // skip this line, since we've already processed it
      }
   else if (obj1 == symEXCEPT)
      add_to_exceptions(exceptions,obj2) ;
   else if (obj1 == symINCLUDE)
      {
      if (curr_token)
	 FrWarning("the INCLUDE command may only be used outside of BEGIN/END") ;
      else
	 do_INCLUDE_command(obj2,outfp,regexfp,srclang,trglang,basedir,
			    index,false) ;
      }
   else if (obj1 == symLOAD)
      do_LOAD_command(curr_token,obj2,exceptions,outfp,index,unicode,basedir,
		      tokfile) ;
   else if (obj1 == symBEGIN)
      {
      if (obj2->symbolp())
	 {
	 FrSymbol *prev_token = curr_token ;
	 curr_token = (FrSymbol*)obj2 ;
	 const char *tok_name = curr_token->symbolName() ;
	 const char *end = strchr(tok_name,'\0') ;
	 if (tok_name[0] != EbTOKEN_START || end[-1] != EbTOKEN_END)
	    {
	    char name[FrMAX_SYMBOLNAME_LEN+3] ;
	    if (tok_name[0] != EbTOKEN_START)
	       {
	       name[0] = EbTOKEN_START ;
	       strcpy(name+1,tok_name) ;
	       }
	    else
	       strcpy(name,tok_name) ;
	    if (end[-1] != EbTOKEN_END)
	       {
	       char *last = strchr(name,'\0') ;
	       *last++ = EbTOKEN_END ;
	       *last = '\0' ;
	       }
	    curr_token = FrSymbolTable::add(name) ;
	    if (regex_names->lookup(curr_token))
	       FrWarningVA("equivalence and regex classes may not have\n"
			   "the same name (%s)",name) ;
	    }
	 if (at_cmd)
	    {
	    convert_begin_end_block(infp,outfp,regexfp,curr_token,regex_names,
				    reverse,srclang,trglang,basedir,tokfile,
				    index,unicode);
	    curr_token = prev_token ;
	    }
	 }
      else
	 FrWarning("invalid BEGIN line in token file") ;
      warned = false ;
      }
   else if (obj1 == symEND)
      {
      curr_token = 0 ;
      if (exceptions)
	 {
	 exceptions->freeObject() ;
	 exceptions = 0 ;
	 }
      warned = false ;
      }
   else
      FrWarningVA("unknown command '%s'",obj1->symbolName()) ;
   free_object(obj2) ;
   return ;
}

//----------------------------------------------------------------------

static bool convert_token_file(FILE *infp, FILE *outfp, FILE *regexfp,
				 const char *srclang, const char *trglang,
				 const char *basedir, const char *tokfile,
				 EBMTIndex *index, bool unicode,
				 bool check_signature,
				 bool regex_only)
{
   if (!infp || !outfp)
      return false ;
   char line[FrMAX_LINE] ;
   bool reverse = false ;
   if (!check_token_signature(infp,line,sizeof(line),srclang,trglang,reverse,
			      unicode,check_signature)
       && check_signature)
      return false ;
   // pass 1: gather up all the regular expression definitions
   FrSymHashTable *regex_names = 0 ;
   if (check_signature || regex_only)
      regex_names = convert_regexes(infp,regexfp,srclang,trglang,basedir,
				    index,reverse) ;
   if (!check_signature && regex_only)
      {
      delete regex_names ;
      return true ;
      }
   // pass 2: gather up the BEGIN/END blocks and LOAD commands
   FrSymbol *curr_token = 0 ;
   bool warned = false ;
   FrList *exceptions = 0 ;
   FrSymbol *symEOF = makeSymbol("*EOF*") ;
   while (!feof(infp))
      {
      bool gotline ;
      if (unicode)
	 gotline = get_stripped_line(infp,line,sizeof(line)) != 0 ;
      else
	 gotline = fgets(line,sizeof(line),infp) != 0 ;
      if (gotline && !feof(infp))
	 {
	 const char *lineptr = skip_whitespace(line) ;
	 strip_comment((char*)lineptr) ;
	 if (!*lineptr)
	    continue ;			// skip blank and comment-only lines
	 bool at_cmd = false ;
	 if (strncmp(lineptr,AT_PREFIX,AT_PREF_LEN) == 0)
	    {
	    at_cmd = true ;
	    lineptr += AT_PREF_LEN ;
	    }
	 FrObject *obj1 = string_to_FrObject(lineptr) ;
	 FrObject *obj2 = string_to_FrObject(lineptr) ;
	 if (!obj1 || !obj2 || obj1 == symEOF || obj2 == symEOF)
	    {
	    free_object(obj2) ;
	    FrWarningVA("invalid line in token file, skipped:\n\t%s",line) ;
	    }
	 else if (obj1->symbolp())
	    process_command((FrSymbol*)obj1,obj2,curr_token,exceptions,
			    regex_names,infp,outfp,regexfp,warned,at_cmd,
			    srclang,trglang,reverse,unicode,basedir,tokfile,
			    index) ;
	 else
	    {
	    if (!curr_token && !warned)
	       {
	       warned = true ;
	       free_object(obj1) ;
	       free_object(obj2) ;
	       FrWarningVA("word pair encountered outside BEGIN/END lines:\n"
			   "  %.77s\n",line) ;
	       continue ;
	       }
	    if (!obj1->stringp() || !obj2->stringp())
	       {
	       free_object(obj1) ;
	       free_object(obj2) ;
	       FrWarningVA("both source and target words must be inside quotes:\n"
		         "  %.77s\n",line);
	       continue ;
	       }
	    FrList *src ;
	    src = FrCvtString2Wordlist(((FrString*)obj1)->stringValue(),
				       word_delimiters,abbrevs_list,
				       char_encoding) ;
	    free_object(obj1) ;
	    FrList *trg ;
	    trg = FrCvtString2Wordlist(((FrString*)obj2)->stringValue(),
				       word_delimiters,abbrevs_list,
				       char_encoding) ;
	    free_object(obj2) ;
	    if (strip_punct)
	       {
	       src = remove_punctuation(src) ;
	       trg = remove_punctuation(trg) ;
	       }
	    index_token_entry(index,outfp,curr_token,src,trg,reverse) ;
	    free_object(src) ;
	    free_object(trg) ;
	    }
	 }
      }
   delete regex_names ;
   return true ;
}

//----------------------------------------------------------------------

bool convert_token_file(const char *infile, EBMTIndex *index)
{
   FILE *infp = fopen(infile,text_read_mode) ;
   if (!infp || !index)
      return false ;
   index->beginIndexing() ;
   index->setOrigin(infile) ;
   const char *srclang = index->sourceLanguage() ;
   if (!srclang)
      srclang = corpus_source_language ;
   const char *trglang = index->targetLanguage() ;
   if (!trglang)
      trglang = corpus_target_language ;
   const char *regexfile = index->tokenFileName() ;
   FILE *outfp = index->openFile(0,true) ;
   if (!outfp)
      {
      fclose(infp) ;
      return false ;
      }
   FILE *regexfp = fopen(regexfile,text_write_mode) ;
   if (!regexfp)
      {
      fclose(outfp) ;
      fclose(infp) ;
      return false ;
      }
   FrFILETYPE ft = FrFileType(infp) ;
   bool success = false ;
   char *basedir = FrFileDirectory(infile) ;
   if (ft == FrFT_ASCII || ft == FrFT_UTF8)
      success = convert_token_file(infp,outfp,regexfp,srclang,trglang,basedir,
				   infile,index,false) ;
   else if (ft == FrFT_UNICODE)
      success = convert_token_file(infp,outfp,regexfp,srclang,trglang,basedir,
				   infile,index,true) ;
   else
      FrWarningVA("Tokenization file '%s'"
		  "\tdoes not appear to be either ASCII or Unicode!",
		  infile) ;
   FrFree(basedir) ;
   fflush(outfp) ;
   fclose(outfp) ;
   fclose(infp) ;
   fflush(regexfp) ;
   fclose(regexfp) ;
   if (index->numSentencePairs() > index->tokenFileEntries())
      index->setTokenFileEntries(index->numSentencePairs()) ;
   index->setOrigin(0) ;
   index->finishIndexing(true) ;
   return success ;
}

// end of file ebctoken.cpp //
