/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebgenre.cpp		class EbGenreSettings			*/
/*  LastEdit: 30mar10							*/
/*									*/
/*  (c) Copyright 2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "ebchunks.h"	// for SCORE_PERFECT
#include "ebgenre.h"
#include "ebglobal.h"

/************************************************************************/
/*	Global Variables for class EbGenreSettings			*/
/************************************************************************/

/************************************************************************/
/************************************************************************/

EbGenreSettings::EbGenreSettings(EBMTGlobalVariables *vars, const char *genre)
{
   m_genre = FrDupString(genre) ;
   _example_origin_weights = 0 ;
   _example_weight_start = 1.0 ;
   _example_weight_end = 2.0 ;
   _max_duplicates1 = 500 ;		// max. duplicates of unigram to check
   _max_duplicates = 500 ;		// max. duplicates of chunk to check
   _max_alternatives1 = 3 ;		// max. proposals for a single unigram
   _max_alternatives = 3 ;		// max. proposals for a single chunk
   _max_match = ~0 ;			// max. length of chunk to process
   _max_align_ambig = 3 ;		// max number of aligns for a srcphrase
   _align_ambig_cutoff = 1.0 ;		// ratio between best/worst aligns
   _use_SPA = false ;			// use heuristic aligner
   _align_threshold = 0.15 ;		// output chunks with good alignments
   _example_weight_range = _example_weight_end - _example_weight_start ;

   // insert the next object into the list of all genres
   link(vars) ;
   return ;
}

//----------------------------------------------------------------------

EbGenreSettings::EbGenreSettings(const EbGenreSettings &old,
				 EBMTGlobalVariables *vars,
				 const char *newgenre)
{
   if (!newgenre)
      newgenre = old.m_genre ;
   // copy the elements of the old structure into the new one
   memcpy(this,&old,sizeof(EbGenreSettings)) ;
   if (_example_origin_weights)
      _example_origin_weights = (FrList*)_example_origin_weights->deepcopy() ;
   // set the new genre name
   m_genre = FrDupString(newgenre) ;
   link(vars) ;
   return ;
}

//----------------------------------------------------------------------

EbGenreSettings::~EbGenreSettings()
{
   FrFree(m_genre) ;			m_genre = 0 ;
   free_object(_example_origin_weights) ;
   // unlink from the list of all genres
   if (m_next)
      m_next->m_prev = m_prev ;
   if (m_prev)
      m_prev->m_next = m_next ;
   else if (m_vars)
      m_vars->genre_list = m_next ;
   return ;
}

//----------------------------------------------------------------------

void EbGenreSettings::link(EBMTGlobalVariables *vars)
{
   m_vars = vars ;
   m_prev = 0 ;
   if (vars)
      {
      m_next = vars->genre_list ;
      if (m_next)
	 m_next->m_prev = this ;
      vars->genre_list = this ;
      }
   else
      m_next = 0 ;
   return ;
}

//----------------------------------------------------------------------

EbGenreSettings *EbGenreSettings::find(const char *genre)
{
   for (EbGenreSettings *g = ebmt_vars.genre_list ; g ; g = g->m_next)
      {
      // are we looking for the default genre?
      if ((!genre || (genre[0] == '*' && genre[1] == '\0')) && !g->m_genre)
	 return g ;
      // check whether the names match
      if (genre && g->m_genre && strcmp(genre,g->m_genre) == 0)
	 return g ;
      }
   return 0 ;				// not found
}

//----------------------------------------------------------------------

// end of file ebgenre.cpp //
