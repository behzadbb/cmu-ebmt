/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebmain.cpp	top-level chunking and evaluation code		*/
/*  LastEdit: 13apr10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "ebmt.h"
#include "frsstrm.h"
#include "ebalign.h"
#include "ebconfig.h"
#include "dict.h"
#include "ebcorpus.h"
#include "ebtoken.h"
#include "ebutil.h"
#include "ebglobal.h"
#include "ebmorph.h"

#ifdef FrSTRICT_CPLUSPLUS
#  include <cmath>
#else
#  include <math.h>
#endif

/************************************************************************/
/*	Global Variables						*/
/************************************************************************/

/************************************************************************/
/*	Externals							*/
/************************************************************************/

int perform_EBMT_operation(FrObject *object, ostream &out, istream &in) ;

extern size_t total_alignments_scored ;
extern size_t total_alignments_good ;

/************************************************************************/
/************************************************************************/

static void postprocess_translation(FrString *translation)
{
   size_t pos = (size_t)-1 ;
   FrConstString concat1(CONCATENATION_TOKEN1) ;
   while ((pos = translation->locate(&concat1,pos)) != (size_t)-1)
      {
      translation->elide(pos,pos+sizeof(CONCATENATION_TOKEN1)-2) ;
      pos-- ;				// back up to allow another match
      }
   FrConstString concat2(CONCATENATION_TOKEN2) ;
   while ((pos = translation->locate(&concat2,pos)) != (size_t)-1)
      {
      translation->elide(pos,pos+sizeof(CONCATENATION_TOKEN2)-2) ;
      pos-- ;				// back up to allow another match
      }
   FrConstString failed1(FAILED_CONCAT_TOKEN1) ;
   while ((pos = translation->locate(&failed1,pos)) != (size_t)-1)
      {
      translation->elide(pos,pos+sizeof(FAILED_CONCAT_TOKEN1)-3) ;
      pos-- ;				// back up to allow another match
      }
   FrConstString failed2(FAILED_CONCAT_TOKEN2) ;
   while ((pos = translation->locate(&failed2,pos)) != (size_t)-1)
      {
      translation->elide(pos+1,pos+sizeof(FAILED_CONCAT_TOKEN2)-3) ;
//      pos-- ;				// back up to allow another match
      }
   if (underscore_hack)
      {
      size_t len = translation->stringLength() ;
      const char *str = translation->stringValue() ;
      FrString blank(" ") ;
      for (size_t i = 1 ; i+1 < len ; i++)
	 {
	 if (str[i] == '_' && !Fr_isspace(str[i-1]) && !Fr_isspace(str[i+1]))
	    translation->setNth(i,&blank) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------
// given the list of final chunks, perform post-processing on the
// translations, such as interpreting the concatenation token

static void postprocess_chunk_translations(EBMTCandidate *chunks)
{
   for ( ; chunks ; chunks = chunks->next())
      {
      FrString *translation = chunks->targetWords() ;
      if (translation && translation->stringp())
	 postprocess_translation(translation) ;
      }
   return ;
}

//----------------------------------------------------------------------

static void rescore_chunks(EBMTCandidate *candidates)
{
  EBMTCandidate *next_chunk = 0 ;

  // Iterate over all candidates
  for (EBMTCandidate *chunks = candidates ; chunks ; chunks = next_chunk)
     {
     size_t cand_count = 1 ;
     //
     // Phase 1: find the first candidate that covers a different source
     //   chunk, counting up the total number of cands for the current chunk
     //
     for (next_chunk = chunks->next() ; 
	  next_chunk && next_chunk->inputStart() == chunks->inputStart() &&
	     next_chunk->inputLength() == chunks->inputLength() ;
	  next_chunk = next_chunk->next())
	{
	cand_count++ ;
	}
     FrLocalAllocC(double,xlat_freq,1024,cand_count) ;
     if (!xlat_freq)
	{
	FrNoMemory("while rescoring chunks") ;
	return ;
	}
     //
     // Phase 2: Iterate over all candidates in an input span
     //
     double weight = 0.0;
     double sum_of_freqs = 0.0 ;
     double total_mass = 0.0 ;
     double grand_total_freq = 0.0;
     EBMTCandidate *next = 0 ;
     size_t candnum = 0 ;
     for (EBMTCandidate *cand = chunks ; cand != next_chunk ; cand = next)
	{
	EbGeneralizations *generalizations = cand->generalizations;
	
	// Iterate over all candidates with the same generalization
	double freq = cand->frequency() ;
	total_mass += cand->totalMass() ;
//	double total_freq = freq * cand->confidence() ;
	double total_freq = cand->totalMass() * cand->confidence() ;
	sum_of_freqs += freq ;
	for (next = cand->next() ; next != next_chunk ; next = next->next())
	   {
	   if (!(generalizations->equal(next->generalizations)))
	      break;
	   freq = next->frequency() ;
	   total_mass += next->totalMass() ;
//	   total_freq += freq * next->confidence() ;
	   total_freq += next->totalMass() * next->confidence() ;
	   sum_of_freqs += freq ;
	   }
	
	// Calculate adjustments
	double adjustment = generalizations ? generalizations->score() : 1.0;
	weight += adjustment ;
	if (total_freq > freq_thresh)
	   adjustment *= (freq_thresh / total_freq);
	
	// Save partial results
	for (EBMTCandidate *iter = cand; iter != next; iter = iter->next())
	   {
	   xlat_freq[candnum++] =
//	      adjustment * iter->frequency() * iter->confidence() ;
	      adjustment * iter->totalMass() * iter->confidence() ;
	   }
	grand_total_freq += adjustment * total_freq;
	}
     if (weight > 1.0)
	weight = 1.0;

     // update the scores for all candidates with the current source chunk
     candnum = 0 ;
     for (EBMTCandidate *cand = chunks ; cand != next_chunk ; cand = cand->next())
	{
	size_t freq = cand->frequency() ;
	cand->features()->setValue(featureID_complete,
				   (cand->completeMatch()
				    ? exp(cand->inputLength()) * freq : freq)) ;
	cand->setProbability(freq / sum_of_freqs) ;
	cand->setMass(cand->totalMass() * freq / total_mass) ;
	// Instead of always adding 1, we now have a score_discount
	// parameter that is tuneable
	double score
	   = (xlat_freq[candnum] / (grand_total_freq+score_discount)) ;
	if (score > 1.0)
	   score = 1.0 ;
	cand->setScore(score * weight) ;
	candnum++ ;
	}
     FrLocalFree(xlat_freq) ;
     }
  return ;
}

//----------------------------------------------------------------------
// given the list of final chunks, remove all but the highest-scored
// occurrence of each source-chunk/proposed-translation pair

static EBMTCandidate *merge_duplicate_chunks(EBMTCandidate *chunks,
					     size_t max_alts,
					     size_t max_alts1)
{
   if (!chunks)
      return 0 ;
   EBMTCandidate *result = 0 ;
   chunks = chunks->sortByChunkAlign() ;
   result = chunks ;			// first chunk is never a dup
   chunks = chunks->next() ;
   result->setNext(0) ;
   while (chunks)
      {
      EBMTCandidate *next = chunks->next() ;
      if ((chunks->generalizations->equal(result->generalizations)) &&
	  EbIsDuplicateCandidate(chunks,result))
	 {
	 // accumulate frequency info from the duplicate but lower-scored
	 //   chunk before deleting it
	 result->features()->add(chunks->features()) ;
	 delete chunks ;
	 }
      else
	 {
	 chunks->setNext(result) ;	// add to result list
	 result = chunks ;
	 }
      chunks = next ;
      }
   // take the frequency of translation into account
   rescore_chunks(result) ;
   chunks = result->sortByChunk() ;

   // Merge generalized chunks and clear generalizations
   result = chunks ;			// first chunk is never a dup
   chunks = chunks->next() ;
   result->setNext(0) ;
   while (chunks)
      {
      EBMTCandidate *next = chunks->next() ;
      if (EbIsDuplicateCandidateAnyScore(chunks,result))
	 {
	 // Sum score across generalizations
	 result->setScore(result->score() + chunks->score()) ;
	 delete chunks ;
	 }
      else
	 {
	 chunks->setNext(result) ;	// add to result list
	 result = chunks ;
	 }
      chunks = next ;
      }
   chunks = result->sortByScore() ;
   if (debug_level < 2 && max_alts != (size_t) ~0)
      {
      // finally, if there were lots of alternatives proposed for a particular
      // source chunk, remove all but the 'max_alternatives' proposals with the
      // best scores

      EBMTCandidate *prev = 0 ;
      EBMTCandidate *next ;
      for (result = chunks ; result ; result = next)
	 {
	 prev = result ;
	 size_t count = 1 ;
	 EBMTCandidate *tmp ;
	 size_t max = (result->matchLength() == 1) ? max_alts1 : max_alts ;
	 for (next = result->next() ; next ; next = tmp)
	    {
	    tmp = next->next() ;
	    if (result->inputLength() != next->inputLength() ||
		result->inputStart() != next->inputStart()) // is source chunk
	       break ;					    //  different?
	    if (count < max)
	       {
	       count++;
	       prev = next ;
	       }
	    // Don't remove the candidate if its score is the same as the
	    //   last one (we may want a hard limit here on how many times
	    //   this is allowed)
	    else if (count == max && next->score() == prev->score() &&
		     next->chunkingBonus() == prev->chunkingBonus() &&
		     next->frequency() == prev->frequency() &&
		     next->alignmentQuality() == prev->alignmentQuality())
	       {
	       prev = next;
	       }
	    else
	       {
	       count++;
	       prev->setNext(tmp) ;
	       delete next ;
	       }
	    }
	 }
      }
   return chunks ;
}

//----------------------------------------------------------------------

void write_EBMT_alignments(const EBMTCandidate *chunks, FILE *alignfp)
{
   if (!alignfp)
      return ;
   for ( ; chunks ; chunks = chunks->next())
      {
      // any unique near-'perfect' alignments which are not due to translation
      // memory are added to the corpus
      if (chunks->alignmentScore() >= 0.7*SCORE_PERFECT &&
	  chunks->inputLength() < chunks->sourceLength() &&
	  chunks->targetWords())
	 {
	 const FrList *srcwrds = chunks->sourceWords() ;
	 const FrString *twords = chunks->targetWords() ;
	 FrString *source = srcwrds ? new FrString(srcwrds,char_encoding) : 0 ;
	 FrString *target = (FrString*)twords->deepcopy() ;
	 fprintf(alignfp,";;;(SCORE %g)(FREQ %lu)\n%s\n%s\n",
		 chunks->alignmentScore(),
		 (unsigned long)chunks->frequency(),
		 source->stringValue(), target->stringValue()) ;
	 fflush(alignfp) ;
	 free_object(source) ;
	 free_object(target) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

static bool good_chunk(EBMTCandidate *chunk)
{
   return (chunk->sourceWords() && chunk->targetWords() &&
	   chunk->alignmentScore() >= SCORE_ACCEPTABLE) ;
}

//----------------------------------------------------------------------

FrList *EbFeatureNames(const EBMTCandidate *cand)
{
   const EbFeatureVector *feats = cand->features() ;
   if (feats)
      return feats->featureMap()->featureNames() ;
   else
      return 0 ;
}

//----------------------------------------------------------------------

FrList *EbLinearFeatureNames(const EBMTCandidate *cand)
{
   const EbFeatureVector *feats = cand->features() ;
   if (feats)
      return feats->featureMap()->protectedFeatures() ;
   else
      return 0 ;
}

//----------------------------------------------------------------------

FrList *EbPrintCandidate(EBMTCandidate *cand, const FrTextSpans *input_lattice,
			 bool show_feature_names)
{
   if (!good_chunk(cand))
      return 0 ;
   // dump chunk as an arc in the format
   // (start end "trans" score "slchunk" weight (F f1 f2 ...) (ALIGN ...))
   const FrObject *translation = cand->targetWords() ;
   size_t input_end = cand->inputStart() + cand->inputLength() - 1 ;
   FrList *arc = new FrList(new FrInteger(cand->inputStart())) ;
   pushlist(new FrInteger(input_end),arc) ;
   pushlist(translation->deepcopy(),arc) ;
   pushlist(new FrFloat(cand->score()),arc) ;
   FrString *input ;
   if (cand->sourceWords())
      input = new FrString(cand->sourceWords(),char_encoding) ;
   else
      input = new FrString("{unavailable}") ;
   pushlist(input,arc) ;
   pushlist(new FrFloat(cand->weight()),arc) ;
   FrList *feat = cand->features()->printable(show_feature_names) ;
   pushlist(makeSymbol("F"),feat) ;
   pushlist(feat,arc) ;
   FrList *origin = EbCandidateOrigin(cand) ;
   if (origin)
      pushlist(origin,arc) ;
   FrList *align = EbWordAlignments(cand) ;
   if (align)
      {
      pushlist(makeSymbol("ALIGN"),align) ;
      pushlist(align,arc) ;
      }
   FrList *target_pos = cand->targetRestrictions() ;
   FrList *spans = cand->targetSpans() ;
   FrList *gen_seq = FrCopyList(cand->generalizationSequence()) ;
   if (!gen_seq && show_gen_sequence)
      {
      // compute the generalization sequence for the phrase pair by running
      //   it through the tokenizer and extracting the resulting class markers
      char *input_text ;
      if (input_lattice)
	 input_text = input_lattice->getText(cand->inputStart(),input_end) ;
      else
	 input_text = 0 ;//FIXME
      FrList *input_words = FrCvtSentence2Wordlist(input_text) ;
      FrFree(input_text) ;
      FrTextSpans *lattice = new FrTextSpans(input_words) ;
      free_object(input_words) ;
      BiTextMap *sub_bitext = cand->phraseBitext() ;
      FrList *targetwords
	 = FrCvtSentence2Wordlist(FrPrintableName(translation)) ;
      Tokenizer *tokenizer = cand->getIndex()->getTokenizer() ;
      FrList *tokenized = 0 ;
      if (tokenizer)
	 tokenized = tokenizer->tokenize(lattice, targetwords,
					 cand->sourceCorpus(), sub_bitext) ;
      delete sub_bitext ;
      free_object(targetwords) ;
      delete lattice ;
      // grab the fourth element of 'tokenized', freeing everything else
      FrList *fourth = tokenized->nthcdr(3) ;
      if (fourth)
	 {
	 gen_seq = (FrList*)fourth->first() ;
	 fourth->replaca(0) ;
	 }
      free_object(tokenized) ;
      }
   if (target_pos || spans || gen_seq)
      {
      FrList *alt = 0 ;
      if (target_pos)
	 {
	 pushlist(makeSymbol("RESTRICT"),target_pos) ;
	 pushlist(target_pos,alt) ;
	 }
      if (spans)
	 {
	 pushlist(makeSymbol("SPANS"),spans) ;
	 pushlist(spans,alt) ;
	 }
      if (gen_seq)
	 {
	 pushlist(makeSymbol("GEN"),gen_seq) ;
	 pushlist(gen_seq,alt) ;
	 }
      pushlist(makeSymbol("ALT"),alt) ;
      pushlist(alt,arc) ;
      }
   if (debug_level > 0)
      {
      if(cand->generalizations)
	 {
	 FrList *generalizations = cand->generalizations->display();
	 if(generalizations)
	    {
	    pushlist(makeSymbol("GENERALIZATIONS"), generalizations);
	    pushlist(generalizations, arc);
	    }
	 FrList *generalization = new FrList(makeSymbol("GENERALIZATION"),
					     new FrFloat(cand->generalizations->score()));
	 pushlist(generalization, arc);
	 }
      }
   arc = listreverse(arc) ;
   return new FrList(arc) ;
}

//----------------------------------------------------------------------

void output_chunks(EBMTCandidate *chunks, ostream &out,
		   const FrTextSpans *input_lattice)
{
   // now that we have the maximal chunks, dump them to the output stream
   chunks = chunks->sortByScore() ;
   out << "(" ;
   for ( ; chunks ; chunks = chunks->next())
      {
      FrList *printed = EbPrintCandidate(chunks,input_lattice) ;
      for (const FrList *arc = printed ; arc ; arc = arc->rest())
	 out << ' ' << arc->first() << endl ;
      free_object(printed) ;
      }
   out << ")" << endl ;
   return ;
}

//----------------------------------------------------------------------

// ABP returns the best score of any superset arc
static double best_chunk_score(int start, int end, EBMTCandidate *chunks)
{
   double best_score = SCORE_ACCEPTABLE ;
   for ( ; chunks ; chunks = chunks->next())
      {
      int otherstart = chunks->inputStart() ;
      if (otherstart > start)
	 break ;			// we've passed the last superset chunk
      int otherend = otherstart + chunks->inputLength() - 1 ;
      if (otherend >= end)
	 {
	 // if this chunk is better than best seen yet and does not have
	 //   any gaps, remember its score
	 if (chunks->score() > best_score && chunks->numTokens() == 0)
	    best_score = chunks->score() ;
	 }
      }
   return best_score ;
}

//----------------------------------------------------------------------

static EBMTCandidate *remove_low_chunks(EBMTCandidate *chunks)
{
   if (!chunks || cand_thresh <= 0.0)
      return chunks;			// nothing to prune

   chunks = chunks->sortByScore() ; 	// order by source pos, then score
   EBMTCandidate *all_chunks = chunks ;
   while (chunks)
      {
      size_t chunk_start = chunks->inputStart() ;
      size_t chunk_end = chunk_start + chunks->inputLength() - 1 ;
      double best_score = best_chunk_score(chunk_start, chunk_end, all_chunks);
      // scan down the list for the first chunk that covers the same source
      //   span but has a score below the threshold
      EBMTCandidate *next ;
      for (next = chunks->next() ; next ; next = next->next())
	 {
	 if (next->inputStart() != chunk_start ||
	     next->inputLength() != chunks->inputLength() ||
	     next->score() < best_score * cand_thresh)
	    break ;
	 chunks = next ; 		// remember predecessor for later
	 }
      // now delete all candidates until we get to one covering a different
      //   source span
      while (next)
	 {
	 if (next->inputStart() != chunk_start ||
	     next->inputLength() != chunks->inputLength())
	    break ;
	 // delete the node
	 EBMTCandidate *tmp = next ;
	 next = next->next() ;
	 chunks->setNext(next) ;
	 delete tmp ;
	 }
      chunks = next ;
      }
   return all_chunks ;
}

//----------------------------------------------------------------------

void output_translations(EBMTCandidate *chunks, ostream &out,
			 const FrObject *input_sentence)
{
   bool good_chunks = false ;
   // now that we have the maximal chunks, dump them to the output stream
   while (chunks)
      {
      // dump chunk in the format
      //    "slchunk" (score)
      //       ("tlchunk" ...)
      if (good_chunk(chunks))
	 {
	 good_chunks = true ;
	 FrString *input ;
	 if (chunks->sourceWords())
	    input = new FrString(chunks->sourceWords(),char_encoding) ;
	 else if (input_sentence && input_sentence->stringp())
	    input = (FrString*)input_sentence->deepcopy() ;
	 else
	    input = 0 ;
	 out << input << ' ' ;
	 free_object(input) ;
	 out << '(' << chunks->score() << ')'
	     << "\n  (" << chunks->targetWords() << ")" << endl ;
	 }
      chunks = chunks->next() ;
      }
   if (!good_chunks)
      out << "; no good chunks found" << endl ;
   return ;
}

/************************************************************************/
/*	Methods for class EBMT						*/
/************************************************************************/

EBMT::EBMT()
{
   symtab = 0 ;
   corpus = 0 ;
   active_corpus = 0 ;
   changed = false ;
   return ;
}

//----------------------------------------------------------------------

int check_index_status(EBMTIndex *corpus_index, ostream &err)
{
   if (!corpus_index->indexGood())
      {
      err << "Error opening index file.	 Check for misspelling or "
	    "insufficient privileges" << endl
	    << "(use kinit or klog if necessary)" << endl << endl ;
      return EXIT_FAILURE ;
      }
   else
      return EXIT_SUCCESS ;
}

//----------------------------------------------------------------------

static EBMTCorpus *open_EBMT_corpus(const EBMTConfig *ebmt_config,
				    ostream &err,
				    bool for_indexing = false)
{
   if (!ebmt_config)
      {
      ebmt_config = get_EBMT_config() ;
      if (!ebmt_config)
	 return 0 ;
      }
   const char *dictname = ebmt_config->dictionary_file ;
   if (for_indexing && ebmt_config->indexing_dictionary &&
       FrFileExists(ebmt_config->indexing_dictionary))
      dictname = ebmt_config->indexing_dictionary ;
   const FrList *corpus_dirs = ebmt_config->corpus_directory ;
   EBMTCorpus *prevcorpus = 0 ;
   EBMTCorpus *corpus = 0 ;
   bool warned_roots = false ;
   for ( ; corpus_dirs ; corpus_dirs = corpus_dirs->rest())
      {
      const char *corpusdir = first_corpus_dir(corpus_dirs) ;
      corpus = new EBMTCorpus(corpusdir,ebmt_config->target_roots,dictname,
			      for_indexing,prevcorpus) ;
      if (corpus)
	 {
	 EBMTIndex *corpus_index = corpus->getIndex() ;
	 int status = check_index_status(corpus_index,err) ;
	 if (status == EXIT_FAILURE)
	    {
	    err << "Error accessing EBMT corpus index for " << corpusdir
		<< endl ;
	    delete corpus ;
	    corpus = 0 ;
	    }
	 else
	    {
	    prevcorpus = corpus ;
	    if (ebmt_config->target_roots && !corpus->targetGood())
	       {
	       if (!warned_roots)
		  err << "Error opening Target-Roots: file "
		      << ebmt_config->target_roots
		      << "\nCheck for misspelling or insufficient privileges."
		      << endl << endl ;
	       warned_roots = true ;
	       }
	    if (ebmt_config->source_charmap || ebmt_config->number_charmap)
	       corpus_index->setCharMapping(ebmt_config->source_charmap,
					    ebmt_config->number_charmap) ;
	    corpus->setAlignConstraints(ebmt_config->constraints_filename) ;
	    corpus->setTightlyBoundWords(ebmt_config->tight_bound_left,
					 ebmt_config->tight_bound_right) ;
	    EBMTIndex *index = corpus->getIndex() ;
	    if (index && for_indexing &&
		corpus_dirs == ebmt_config->corpus_directory)
	       {
	       cout << "; augmenting dictionary from tokenizer" << endl ;
	       index->augmentDictionary(corpus->getDictionary()) ;
	       cout << ";    ...done" << endl ;
	       }
	    if (ignore_accents)
	       corpus->setSourceSynonymsUnaccented() ;
	    corpus->loadSourceSynSets(source_synsets_file) ;
	    }
	 }
      else
	 FrNoMemory("while opening EBMT corpus") ;
      }
   return corpus ;
}

//----------------------------------------------------------------------

static void create_index(EBMTConfig *ebmt_config,const char */*argv0*/)
{
   const char *dir = first_corpus_dir(ebmt_config->corpus_directory) ;
   EBMTIndex *index = new EBMTIndex(dir,true,
				    corpus_source_language,
				    corpus_target_language) ;
   delete index ;
   return ;
}

//----------------------------------------------------------------------

EBMT::EBMT(EBMTConfig *ebmt_config, const char *argv0, ostream &err,
	   bool force_creation, bool for_indexing)
{
   FrSymbolTable *oldsymtab = current_symbol_table() ;
   symtab = new FrSymbolTable() ;
   symtab->select() ;
   symTOKEN = makeSymbol("TOKEN") ;
   symALIGN = makeSymbol("ALIGN") ;
   if (force_creation && !for_indexing)
      create_index(ebmt_config,argv0) ;
   EbStartExternalAligner() ;
   corpus = open_EBMT_corpus(ebmt_config,err,for_indexing) ;
   active_corpus = corpus ;
   if (print_EBMT_alignments)
      alignfp = fopen(alignment_filename,"a") ;
   else
      alignfp = 0 ;
   changed = false ;
   load_metainfo();
   load_generalization_rules();
   load_generalization_weights();
   EBfeature_map.finalize(EbFeatureVector::featureSize()) ;
   oldsymtab->select() ;
   return ;
}

//----------------------------------------------------------------------

EBMT::~EBMT()
{
   if (changed)
      save() ;
   clear_metainfo();
   clear_generalization_rules();
   clear_generalization_weights();
   delete corpus ;
   corpus = 0 ;
   active_corpus = 0 ;
   destroy_symbol_table(symtab) ;
   symtab = 0 ;
   if (alignfp)
      {
      fclose(alignfp) ;
      alignfp = 0 ;
      }
   EbStopExternalAligner() ;
   return ;
}

//----------------------------------------------------------------------

EBMTIndex *EBMT::getIndex() const
{
   return active_corpus ? active_corpus->getIndex() : 0 ;
}

//----------------------------------------------------------------------

void EBMT::selectNextCorpus()
{
   if (active_corpus)
      active_corpus = active_corpus->nextCorpus() ;
   return ;
}

//----------------------------------------------------------------------

bool EBMT::selectedCorpusEnabled() const
{
   if (active_corpus)
      return active_corpus->enabled() ;
   else
      return false ;
}

//----------------------------------------------------------------------

EBMTCorpus *EBMT::findCorpus(const char *corpusname, bool strict) const
{
   EBMTCorpus *corp ;
   for (corp = corpus ; corp ; corp = corp->nextCorpus())
      {
      const char *cname = corp->corpusName() ;
      if (strcmp(cname,corpusname) == 0)
	 return corp ;
      }
   if (!strict)
      {
      for (corp = corpus ; corp ; corp = corp->nextCorpus())
	 {
	 const char *cname = FrFileBasename(corp->corpusName()) ;
	 if (strcmp(cname,corpusname) == 0)
	    return corp ;
	 }
      }
   return 0 ;
}

//----------------------------------------------------------------------

bool EBMT::enableCorpus(const char *corpusname, bool disable_rest)
{
   EBMTCorpus *wanted = findCorpus(corpusname,false) ;
   if (!wanted)
      return false ;
   if (disable_rest)
      {
      for (EBMTCorpus *corp = corpus ; corp ; corp = corp->nextCorpus())
	 {
	 if (corp != wanted)
	    corp->disableCorpus() ;
	 }
      }
   wanted->enableCorpus() ;
   return true ;
}

//----------------------------------------------------------------------

bool EBMT::disableCorpus(const char *corpusname, bool enable_rest)
{
   EBMTCorpus *wanted = findCorpus(corpusname,false) ;
   if (!wanted && corpusname)
      return false ;
   if (enable_rest)
      {
      for (EBMTCorpus *corp = corpus ; corp ; corp = corp->nextCorpus())
	 {
	 if (corp != wanted)
	    corp->enableCorpus() ;
	 }
      }
   if (wanted)
      wanted->disableCorpus() ;
   return true ;
}

//----------------------------------------------------------------------

bool EBMT::selectGenre(const char *genre_name)
{
   if (active_corpus)
      return active_corpus->selectGenre(genre_name) ;
   else if (corpus)
      return corpus->selectGenre(genre_name) ;
   else
      return false ;
}

//----------------------------------------------------------------------

char *EBMT::privateCommand(const char *command)
{
   if (command && *command)
      {
      strstream input ;
      input << command << '\0' ;
      strstream output ;
      /*bool status =*/ perform_EBMT_operation(0,output,input) /*!= 0*/ ;
      output << '\0' ;			// ensure proper string termination
      char *res = output.str() ;
      char *result = FrDupString(res) ;
      free(res) ;
      return result ;
      }
   return 0 ;
}

//----------------------------------------------------------------------

bool EBMT::save()
{
   if (changed)
      {
      bool success = true ;
      if (corpus)
	 {
	 success = corpus->storeTranslations() ;
	 if (corpus->getIndex())
	    if (!corpus->getIndex()->saveExampleInfo())
	       success = false ;
	 }
      return success ;
      }
   else
      return true ;			// trivially successful
}

//----------------------------------------------------------------------

FrList *EBMT::lookupDict(const FrTextSpans *words)
{
   FrMessageLoop() ;			// handle any pending OS events
   if (corpus)
      {
      Dictionary *dict = corpus->getDictionary() ;
      return dict ? dict->lookup(words,max_dict_translations) : 0 ;
      }
   return 0 ;
}

//----------------------------------------------------------------------

bool EBMT::exportDictionary(const char *exportfile)
{
   if (corpus)
      {
      Dictionary *dict = corpus->getDictionary() ;
      if (dict)
	 return dict->exportDict(exportfile) ;
      }
   return false ;			// can't export if not loaded
}

//----------------------------------------------------------------------

bool EBMT::dumpIndex(const char *exportfile)
{
   if (corpus)
      {
      EBMTIndex *index = corpus->getIndex() ;
      if (index)
	 return index->dumpIndex(exportfile) ;
      }
   return false ;			// can't export if not loaded
}

//----------------------------------------------------------------------

EBMTCandidate *EBMT::findMatches(FrTextSpans *lattice, size_t max_alts,
				 size_t max_alts1, bool /*keep_sentpair*/)
{
   FrMessageLoop() ;			// handle any pending OS events
   EBMTCandidate *candidates = 0 ;
   EBMTIndex *index = getIndex() ;
   if (lattice && index)
      {
      candidates = find_recursive_chunks(index->getTokenizer(),
					 lattice, getCorpus(),tm_mode) ;
      EBMTCandidate *struc = find_structural_matches(lattice,getCorpus(),
						     candidates,tm_mode) ;
      if (struc)
	 candidates = candidates->nconc(struc) ;
      if (max_alts == 0)
	 max_alts = max_alternatives ;
      if (max_alts1 == 0)
	 max_alts1 = max_alternatives1 ;
      candidates = merge_duplicate_chunks(candidates,max_alts,max_alts1) ;
      }
   if (verbose)
      cout << "; " << candidates->listlength() << " unique translations"
	    << endl ;
   if (print_EBMT_alignments && candidates)
      write_EBMT_alignments(candidates,getAlignFP()) ;
   return candidates ;
}

/************************************************************************/
/************************************************************************/

static bool Initialized = false ;
static EBMT *active_ebmt = 0 ;
static EBMTCorpus *active_corpus = 0 ;

//----------------------------------------------------------------------

void apply_EBMT_configuration(EBMTConfig *config)
{
   if (config)
      {
      ebmt_vars.applyConfiguration(config) ;
      BiTextMap::wantGapsFilled(EBMT_fill_gaps) ;
      if (abbrevs_filename)
	 abbrevs_list = FrLoadAbbreviationList(abbrevs_filename) ;
      }
   return ;
}

//----------------------------------------------------------------------

void identify_EBMT(ostream &out, bool as_comment)
{
   if (as_comment)
      out << "; " ;
   out << "EBMT v" EBMT_VERSION_STR << endl ;
   return ;
}

//----------------------------------------------------------------------

bool initialize_EBMT(const char *argv0, const char *configfile,
		     ostream &err, bool force_creation, bool for_indexing,
		     const char *corpus_create_directory)
{
   if (Initialized)
      return true ;
   bool success = false ;
   if (get_EBMT_config() ||
       get_EBMT_setup_file(configfile,argv0,err))
      {
      EBMTConfig *ebmt_config = (EBMTConfig*)get_EBMT_config() ;
      apply_EBMT_configuration(ebmt_config) ;
      thread_pool = FrCreateGlobalThreadPool(ebmt_config->maxthreads) ;
      if (for_indexing)
	 {
	 load_dict_readonly = false ;
	 load_corpus_readonly = false ;
	 }
      if (corpus_create_directory)
	 {
	 free_object(ebmt_config->corpus_directory) ;
	 ebmt_config->corpus_directory =
	    new FrList(new FrString(corpus_create_directory)) ;
	 }
      if (reverse_languages)
	 {
	 char *tmp = corpus_source_language ;
	 corpus_source_language = corpus_target_language ;
	 corpus_target_language = tmp ;
	 }
      active_ebmt = new EBMT(ebmt_config,argv0,err,force_creation,
			     for_indexing||force_creation) ;
      if (active_ebmt && active_ebmt->OK())
	 {
	 success = true ;
	 Initialized = true ;
	 }
      else
	 {
	 delete active_ebmt ;
	 active_ebmt = 0 ;
	 }
      }
   else
      {
      shutdown_EBMT() ;
      success = false ;
      }
   return success ;
}

//----------------------------------------------------------------------

EBMT *active_EBMT()
{
   return active_ebmt ;
}

//----------------------------------------------------------------------

EBMTCorpus *EbSetActiveEBMTCorpus(EBMTCorpus *corpus)
{
   EBMTCorpus *prev_corpus = active_corpus ;
   active_corpus = corpus ;
   return prev_corpus ;
}

//----------------------------------------------------------------------

EBMTCorpus *active_EBMTCorpus()
{
   return active_ebmt ? active_ebmt->getCorpus() : active_corpus ;
}

//----------------------------------------------------------------------

int EBMT_max_alternatives(int new_max)
{
   int old_max = max_alternatives ;
   max_alternatives = new_max ;
   return old_max ;
}

//----------------------------------------------------------------------

int EBMT_max_alternatives()
{
   return max_alternatives ;
}

//----------------------------------------------------------------------

static void compute_EBMT_coverage(const FrTextSpans *lattice,
				  EBMTCandidate *chunks)
{
   size_t input_len = lattice->textLength() ;
   if (!preparing_for_doc)
      total_bytes += input_len ;
   FrLocalAllocC(bool,byte_covered,1024,input_len) ;
   for ( ; chunks ; chunks = chunks->next())
      {
      if (good_chunk(chunks))
	 {
	 size_t first, last ;
	 chunks->coverage(first,last) ;
	 if (last >= input_len)
	    last = input_len-1 ;
	 size_t arclen = (last - first + 1) ;
	 for (size_t i = first ; i <= last ; i++)
	    byte_covered[i] = true ;
	 total_arcs++ ;
	 if (!preparing_for_doc)
	    total_words_in_arcs += arclen ;
	 }
      }
   const char *origtext = lattice->originalString() ; 
   size_t i ;
   bool covered = false ;
   for (i = 0 ; i < input_len ; i++)
      {
      if (byte_covered[i])
	 {
	 covered_bytes++ ;
	 covered = true ;
	 }
      if (origtext && *origtext)
	 {
	 origtext++ ;
	 if (Fr_isspace(*origtext))
	    {
	    if (!preparing_for_doc)
	       total_words++ ;
	    if (covered)
	       {
	       covered_words++ ;
	       covered = false ;
	       }
	    while (*origtext && Fr_isspace(*origtext))
	       origtext++ ;
	    }
	 }
      }
   if (origtext)
      {
      total_words++ ;
      if (covered)
	 covered_words++ ;
      }
   FrLocalFree(byte_covered) ;
   return ;
}

//----------------------------------------------------------------------

EBMTCandidate *process_sentence_EBMT(FrTextSpans *input_lattice,
				     bool keep_sentpair)
{
   EBMT *ebmt = active_EBMT() ;
   if (ebmt && input_lattice)
      {
      FrSymbolTable *sym_t = ebmt->symbolTable()->select() ;
      ebmt->selectFirstCorpus() ;
      EBMTIndex *index = ebmt->getIndex() ;
      if (!index)
	 return 0 ;
      EBMTCandidate *chunks = 0 ;
      size_t num_corpora = 0 ;
      size_t max_alts = (max_alts_are_global ? ~0 : max_alternatives) ;
      size_t max_alts1 = (max_alts_are_global ? ~0 : max_alternatives1) ;
      if (!preparing_for_doc)
	 total_input_len += input_lattice->textLength() ;
      for ( ; ebmt->getCorpus() ; ebmt->selectNextCorpus())
	 {
	 if (!ebmt->selectedCorpusEnabled())
	    continue ;
	 num_corpora++ ;
	 EBMTCandidate *newchunks = ebmt->findMatches(input_lattice,max_alts,
						      max_alts1,
						      keep_sentpair) ;
	 chunks = newchunks->nconc(chunks) ;
	 }
      ebmt->selectFirstCorpus() ;
      for ( ; ebmt->getCorpus() ; ebmt->selectNextCorpus())
	 ebmt->getCorpus()->resetRefCounts() ;
      ebmt->selectFirstCorpus() ;
      if (num_corpora > 1 || max_alts_are_global)
	 chunks = merge_duplicate_chunks(chunks,
					 (max_alts_are_global
					  ?max_alternatives:~0),
					 (max_alts_are_global
					  ?max_alternatives1:~0)) ;
      for (EBMTCandidate *c = chunks ; c ; c = c->next())
	 c->normalizeFeatureValues() ; 
      chunks = remove_low_chunks(chunks);
      postprocess_chunk_translations(chunks) ;
      if (verbose && showmem)
	 FrMemoryStats(cout) ;
      sym_t->select() ;
      if (compute_coverage)
	 compute_EBMT_coverage(input_lattice,chunks) ;
      (void) EbRemoveExtraSpans(input_lattice) ;
      return chunks ;
      }
   return 0 ;
}

//----------------------------------------------------------------------

bool EbPrepareDocument(bool starting)
{
   if (starting == preparing_for_doc)
      return false ;
   EBMT *ebmt = active_EBMT() ;
   if (ebmt)
      {
      preparing_for_doc = starting ;
      ebmt->selectFirstCorpus() ;
      for ( ; ebmt->getCorpus() ; ebmt->selectNextCorpus())
	 {
	 EBMTCorpus *corpus = ebmt->getCorpus() ;
	 if (!corpus)
	    continue ;
	 corpus->resetRefCounts() ;
	 EBMTIndex *index = corpus->getIndex() ;
	 if (index)
	    {
	    if (starting)
	       index->resetDocWeights() ;
	    else
	       index->normalizeDocWeights() ;
	    }
	 }
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

bool add_EBMT_entry(const FrString *phrase, const FrString *translation,
		      const FrString *tags, ostream &err)
{
   EBMT *ebmt = active_EBMT() ;
   if (ebmt && phrase && translation)
      {
      bool status = false ;
      const char *source = phrase->stringValue() ;
      const char *target = translation->stringValue() ;
      if (source && *source && target && *target)
	 {
	 EBMTCorpus *corpus = ebmt->getCorpus() ;
	 EBMTIndex *index = corpus ? corpus->getIndex() : 0 ;
	 if (index)
	    {
	    FrList *pair = new FrList(phrase,translation,tags) ;
	    FrList *pairs = new FrList(pair) ;
	    index->setOrigin("online-update") ;
	    status = index->addPairs(pairs,true) ;
	    pair->eraseList(false) ;
	    pairs->eraseList(false) ;
	    }
	 }
      return status ;
      }
   else
      {
      err << "Missing parameter -- must specify both source and translation"
	  << endl ;
      return false ;
      }
}

//----------------------------------------------------------------------

bool save_EBMT_updates()
{
   EBMT *ebmt = active_EBMT() ;
   if (ebmt)
      return ebmt->save() ;
   else
      return true ;			// trivially successful
}

//----------------------------------------------------------------------

bool pack_EBMT_index(ostream &out)
{
   EBMT *ebmt = active_EBMT() ;
   if (ebmt)
      {
      EBMTCorpus *corpus = ebmt->getCorpus() ;
      EBMTIndex *index = corpus ? corpus->getIndex() : 0 ;
      if (index)
	 return index->pack(&out) ;
      else
	 return false ;
      }
   else
      return true ;			// trivially successful
}

//----------------------------------------------------------------------

bool shutdown_EBMT()
{
   if (Initialized)
      {
      if (active_ebmt)
	 active_ebmt->save() ;
      if (compute_coverage && !quiet_mode)
	 {
	 double percent = 0.0 ;
	 if (total_input_len > 0)
	    percent = (100.0*total_match_count)/total_input_len ;
	 cout << "; corpus matches: " << total_match_count << " of "
	      << total_input_len << " characters ("
	      << setprecision(4) << percent << "%)" << endl ;
	 percent = 0.0 ;
	 if (total_words > 0)
	    percent = (100.0*covered_words)/total_words ;
	 cout << "; coverage: " << covered_words << " of " << total_words
	      << " words ("
	      << setprecision(4) << percent << "%), "
	      << covered_bytes << " of " << total_bytes << " bytes (" ;
	 percent = 0.0 ;
	 if (total_bytes > 0)
	    percent = (100.0*covered_bytes)/total_bytes ;
	 cout << setprecision(4) << percent << "%)" << endl ;
	 double per_arc = 0.0 ;
	 if (total_arcs > 0)
	    per_arc = total_words_in_arcs/(double)total_arcs ;
	 cout << "; arcs: " << total_arcs << " containing "
	      << total_words_in_arcs << " bytes (average "
	      << setprecision(4) << per_arc << " bytes per arc)"
	      << endl << setprecision(0) ;
	 if (gapped_match_count + ungapped_match_count > 0)
	    cout << "; of the corpus matches, " << gapped_match_count
		 << " contained gaps and " << ungapped_match_count
		 << " did not" << endl ;
	 size_t cache_lookups, cache_hits, cache_inserts ;
	 EbAlignCacheStats(cache_lookups,cache_hits,cache_inserts) ;
	 if (cache_lookups > 0 || cache_inserts > 0)
	    {
	    double hitrate = (cache_lookups
			      ? (cache_hits/(double)cache_lookups*100.0)
			      : 100.0) ;
	    cout << "; aligncache: " << cache_hits << " hits in "
		 << cache_lookups << " lookups (" << setprecision(3)
		 << hitrate << "%), "
		 << cache_inserts << " insertions" << endl ;
	    }
	 if (total_alignments_scored > 0)
	    cout << "; alignments: " << total_alignments_good
		 << " successful of " << total_alignments_scored
		 << " attempted (" << skipped_training_instances
		 << " skipped)" << endl ;
	 compute_coverage = false ;
	 }
      delete active_ebmt ;
      active_ebmt = 0 ;
      unload_EBMT_config() ;
      EbClearAlignmentWeights() ;
      EbClearGappedMatchCache() ;
      EbAlignCacheFree() ;
      DcShutdownDictionary() ;
      FrClearMorphologyMarkers() ;
      FrDestroyGlobalThreadPool(thread_pool) ;
      thread_pool = 0 ;
      ebmt_vars.free() ;
      Initialized = false ;
      }
   return true ;
}

// end of file ebmain.cpp //
