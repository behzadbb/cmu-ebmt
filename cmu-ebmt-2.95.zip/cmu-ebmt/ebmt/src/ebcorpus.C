/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.94							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebcorpus.cpp	EBMT corpus manipulation			*/
/*  LastEdit: 25mar10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#if defined(__GNUC__)
#  pragma implementation "ebcorpus.h"
#endif

#include "frlowio.h"
#include "dict.h"
#include "ebbitext.h"
#include "ebcorpus.h"
#include "ebcrpinf.h"
#include "ebchunks.h"
#include "ebsent.h"
#include "ebtoken.h"
#include "ebutil.h"
#include "ebglobal.h"

#include <fcntl.h>

/************************************************************************/
/*	Manifest Constants						*/
/************************************************************************/

/************************************************************************/
/************************************************************************/

static FrSymHashTable *load_target_hashtable(const char *filename)
{
   FILE *fp = fopen(filename,"r") ;
   if (fp)
      {
      // estimate number of entries we'll need in the hash table
      fseek(fp,0L,SEEK_END) ;
      off_t offset = ftell(fp) ;
      fseek(fp,0L,SEEK_SET) ;
      FrSymHashTable *ht = new FrSymHashTable(offset/30) ;
      current_symbol_table()->expand(offset/40) ;
      FrSymbol *symbolEOF = makeSymbol("*EOF*") ;
      FrSymbol *symbolNIL = makeSymbol("NIL") ;
      size_t iterations = 0 ;
      while (!feof(fp))
	 {
	 // file consist of triples: symbol for word, list of analysis results,
	 // and a number
	 char line[MAX_CORPUS_LINE+1] ;
	 char *tmp ;
	 line[0] = '\0' ;
	 fgets(line,sizeof(line),fp) ;	// get word
	 tmp = line ;
	 FrObject *word = string_to_FrObject(tmp) ;
	 line[0] = '\0' ;
	 fgets(line,sizeof(line),fp) ;	// get analysis results
	 tmp = line ;
	 FrObject *roots = string_to_FrObject(tmp) ;
	 fgets(line,sizeof(line),fp) ;	// ignore number on third line
	 if (!word || !word->symbolp())
	    {
	    free_object(word) ;
	    free_object(roots) ;
	    continue ;			// bad entry, so skip it
	    }
	 if (word == symbolEOF)
	    break ;			// hit end of file, so quit
	 if (roots && roots != symbolNIL)
	    {
	    if (roots->consp())
	       {	
	       FrList *uniq = (FrList*)((FrList*)roots)->removeDuplicates(EBMT_equal) ;
	       roots->freeObject() ;
	       uniq = listremove(uniq,symbolNIL) ;
	       FrList *rootlist = FrCvtWordlist2Symbollist(uniq,
							   char_encoding) ;
	       free_object(uniq) ;
	       roots = rootlist ;
	       }
	    else
	       roots = new FrList(roots) ;
	    FrSymHashEntry *ent = ht->lookup((FrSymbol*)word) ;
	    if (ent)
	       {
	       FrList *rootlist = (FrList*)ent->getValue() ;
	       ent->setValue(rootlist->nconc((FrList*)roots)) ;
	       }
	    else
	       ht->add((FrSymbol*)word,roots) ;
	    }
	 // under Windows, we want to give the UI a chance to process any
	 // messages Windows might have sent, so call the message loop
	 // occasionally
	 if (++iterations >= 1000)
	    {
	    iterations = 0 ;
	    FrMessageLoop() ;
	    }
	 }
      fclose(fp) ;
      return ht ;
      }
   else
      return 0 ;
}

/************************************************************************/
/*    Methods for class EBMTCorpus					*/
/************************************************************************/

EBMTCorpus::EBMTCorpus(const char *corpusdir, const char *targetindex,
		       const char *cachefile, bool force_creation,
		       EBMTCorpus *nxt, bool is_temporary)
{
   constraints = 0 ;
   sourcehash = 0 ;			// will be loaded as needed
   targethash = 0 ;			// will be loaded on demand
   tsyn_filename = 0 ;
   if (FrFileReadable(targetindex))	// remember where to get targethash
      tsyn_filename = FrDupString(targetindex) ;
   dictionary = 0 ;
   if (cachefile)
      {
      dictionary = Dictionary::open(cachefile,load_dict_readonly) ;
      DcSetActiveDictionary(dictionary) ;
      }
   constraints = new EbAlignConstraints(dictionary,0,0) ;
   new_translations = false ;
   m_haverecstarts = false ;
   cache_filename = cachefile ;
   corpus_name = 0 ;
   m_refcounts = 0 ;
   next = nxt ;
   setName(corpusdir) ;
   bool was_created = false ;
   index = new EBMTIndex(corpusdir,force_creation,0,0,&was_created) ;
   m_temporary = (is_temporary && was_created) ;
   if (index)
      {
      index->setCorpus(this) ;
      // copy the indicated token file into the corpus directory if
      //   this is a fresh corpus that hasn't indexed anything yet
      if (index->numSentencePairs() == 0 && token_source_filename &&
	  *token_source_filename)
	 {
	 if (convert_token_file(token_source_filename,index))
	    index->loadTokens(0) ;
	 else
	    {
	    cerr << "; unable to convert input token file "
		 << token_source_filename << " into corpus format" << endl ;
	    }
	 }
      initRefCounts() ;
      if (verbose)
	 cout << ";   opened EBMT corpus in " << corpusdir << " ("
	      << index->numSentencePairs() << " training instances)" << endl ;
      }
   enableCorpus() ;
   return ;
}

//----------------------------------------------------------------------

static bool clear_syn_list(FrSymHashEntry *entry, va_list)
{
   if (entry)
      {
      FrList *syns = (FrList*)entry->getUserData() ;
      entry->setUserData(0) ;
      free_object(syns) ;
      }
   return true ;
}

//----------------------------------------------------------------------

EBMTCorpus::~EBMTCorpus()
{
   freeRecordStarts() ;
   if (sourcehash)
      sourcehash->doHashEntries(clear_syn_list) ;
   if (targethash)
      targethash->doHashEntries(clear_syn_list) ;
   delete m_refcounts ;		m_refcounts = 0 ;
   delete index ;		index = 0 ;
   delete sourcehash ;		sourcehash = 0 ;
   delete targethash ;		targethash = 0 ;
   delete constraints ;		constraints = 0 ;
   if (dictionary)
      {
      if (DcActiveDictionary() == dictionary)
	 DcSetActiveDictionary(0) ;
      dictionary->close() ;	dictionary = 0 ; 
      }
   FrFree(tsyn_filename) ;	tsyn_filename = 0 ;
   FrFree(corpus_name) ;	corpus_name = 0 ;
   delete next ;		next = 0 ;
   return ;
}

//----------------------------------------------------------------------

bool EBMTCorpus::eraseCorpusFiles()
{
   if (!temporary())
      return false ;
   if (!index->eraseFiles())
      return false ;
//FIXME
   return true ;
}

//----------------------------------------------------------------------

#if defined(__SOLARIS__) && 0
void *Fr_memchr(const void *mem, char c, size_t len)
{
   unsigned char uc = (unsigned char)c ;
   const unsigned char *umem = (unsigned char*)mem ;
   while (len > 0)
      {
      if (*umem == uc)
	 return (void*)umem ;
      umem++ ;
      len-- ;
      }
   return 0 ;
}
#else
#define Fr_memchr memchr
#endif

//----------------------------------------------------------------------

void EBMTCorpus::setName(const char *name)
{
   FrFree(corpus_name) ;
   corpus_name = FrDupString(FrFileBasename(name)) ;
   return ;
}

//----------------------------------------------------------------------

void EBMTCorpus::setAlignConstraints(const char *filename)
{
   if (constraints)
      constraints->load(filename) ;
   else
      constraints = new EbAlignConstraints(getDictionary(),filename) ;
   return ;
}

//----------------------------------------------------------------------

void EBMTCorpus::setTightlyBoundWords(const FrList *left,
				      const FrList *right)
{
   if (constraints)
      {
      constraints->addBoundWords(left,true,false,true) ;
      constraints->addBoundWords(right,true,false,false);
      }
   else
      constraints = new EbAlignConstraints(getDictionary(),left,right) ;
   return ;
}

//----------------------------------------------------------------------

bool EBMTCorpus::getExample(uint32_t linenumber, EbSentence *&target,
			    EbCorpusMetaInfo &metainfo, size_t srclen,
			    bool ignore_bitext, bool ignore_morphology) const
{
   uint32_t start ;
   int length ;
   index->getLinePosition(linenumber,start,length) ;
   if ((start == 0 && LINE_IN_SUBFILE(linenumber) != 0) || length > 99000)//!!!
      {
      FrWarningVA("bad corpus pointers for entry %u (start=%u, len=%d)",
		  (unsigned int)linenumber,(unsigned int)start,length) ;
      return false ;
      }
   char *buffer ;
   int filenumber = (int)SUBFILE_NUMBER(linenumber) ;
   bool must_free ;
   bool success = true ;
   if (index->readFile(buffer,filenumber,start,length,must_free))
      {
      const char *end ;
      target = new EbSentence(targetVocabulary(),buffer,&end) ;
      size_t meta_len ;
      bool must_free_meta ;
      const char *meta = index->overridingMetaInfo(linenumber,meta_len,
						   must_free_meta) ;
      if (meta)
	 {
	 metainfo.parse(meta,meta+meta_len,srclen,target->length(),0,
			ignore_bitext,ignore_morphology && !must_free_meta) ;
	 if (must_free_meta)
	    FrFree((char*)meta) ;
	 }
      else if (target && end < buffer + length)
	 metainfo.parse(end,buffer+length,srclen,target->length(),0,
			ignore_bitext,ignore_morphology && !must_free) ;
      }
   else
      {
      FrWarningVA("error reading from corpus.%3.03d @ %ld",
		  filenumber,(long)start) ;
      success = false ;
      }
   if (must_free)
      FrFree(buffer) ;
   return success ;
}

//----------------------------------------------------------------------

bool EBMTCorpus::addSourceSynonym(const char *word, const char *synonym)
{
   if (word && synonym)
      {
      if (!sourcehash)
	 {
	 sourcehash = new FrSymHashTable ;
	 if (!sourcehash)
	    {
	    FrNoMemory("while adding source-side synonym") ;
	    return false ;
	    }
	 }
      if (Fr_stricmp(word,synonym,lowercase_table) != 0)
	 {
	 FrSymbol *wordsym = makeSymbol(word) ;
	 FrSymbol *synsym = makeSymbol(synonym) ;
	 FrSymHashEntry *entry = sourcehash->lookup(wordsym) ;
	 if (entry)
	    {
	    FrList *syn = (FrList*)entry->getUserData() ;
	    if (!syn->member(synsym))
	       {
	       pushlist(synsym,syn) ;
	       entry->setUserData((void*)syn) ;
	       }
	    }
	 else
	    sourcehash->add(wordsym,new FrList(synsym)) ;
	 }
      return true ;
      }
   // if we get here, we weren't able to add the synonym
   return false ;
}

//----------------------------------------------------------------------

bool EBMTCorpus::setSourceSynonymsUnaccented()
{
   EBMTIndex *index = getIndex() ;
   if (index)
      {
      FrVocabulary *voc = index->vocabulary() ;
      if (voc)
	 {
	 voc->createReverseMapping() ;
	 for (size_t i = 0 ; i < voc->numWords() ; i++)
	    {
	    const char *word = voc->nameForID(i) ;
	    if (word && *word)
	       {
	       char *unaccented = unaccent(word) ;
	       addSourceSynonym(word,unaccented) ;
	       addSourceSynonym(unaccented,word) ;
	       }
	    }
	 }
      return true ;
      }
   // if we get here, we were unable to setup synonyms
   return false ;
}

//----------------------------------------------------------------------

static void add_synset(EBMTCorpus *corpus, const FrList *synset)
{
   if (corpus && synset)
      {
      FrCharEncoding enc
	 = ignore_source_case ? char_encoding : FrChEnc_RawOctets ;
      for (const FrList *set = synset ; set ; set = set->rest())
	 {
	 FrObject *wordobj = set->first() ;
	 const char *word = wordobj->printableName() ;
	 if (!word)
	    continue ;
	 for (const FrList *syn = set->rest() ; syn ; syn = syn->rest())
	    {
	    FrObject *synobj = syn->first() ;
	    FrSymbol *synsym = FrCvt2Symbol(synobj,enc) ;
	    if (synsym)
	       {
	       const char *synstr = synsym->symbolName() ;
	       corpus->addSourceSynonym(word,synstr) ;
	       corpus->addSourceSynonym(synstr,word) ;
	       }
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

bool EBMTCorpus::loadSourceSynSets(const char *filename)
{
   if (filename && *filename)
      {
      ifstream in(filename) ;
      bool warned = false ;
      FrCharEncoding enc
	 = ignore_source_case ? char_encoding : FrChEnc_RawOctets ;
      if (in.good())
	 {
	 bool success = false ;
	 FrSymbol *symEOF = makeSymbol("*EOF*") ;
	 while (!in.eof())
	    {
	    FrObject *obj ;
	    in >> obj ;
	    if (obj && obj->consp())
	       {
	       add_synset(this,(FrList*)obj) ;
	       success = true ;
	       }
	    else if (obj == symEOF)
	       break ;
	    else if (obj && (obj->symbolp() || obj->stringp()))
	       {
	       const char *word = obj->printableName() ;
	       if (word && *word)
		  {
		  FrObject *obj2 ;
		  in >> obj2 ;
		  if (obj2 && obj2->consp())
		     {
		     for (FrList *wl = (FrList*)obj2 ; wl ; wl = wl->rest())
			{
			FrSymbol *syn = FrCvt2Symbol(wl->first(),enc) ;
			if (syn)
			   addSourceSynonym(word,syn->symbolName()) ;
			}
		     }
		  else if (FrPrintableName(obj2))
		     {
		     FrSymbol *syn = FrCvt2Symbol(obj2,enc) ;
		     addSourceSynonym(word,syn->symbolName()) ;
		     }
		  free_object(obj2) ;
		  }
	       }
	    else
	       {
	       if (!warned)
		  {
		  char *entry = obj->print() ;
		  FrWarningVA("bad entry %s in %s",entry,filename) ;
		  FrFree(entry) ;
		  }
	       warned = true ;
	       }
	    free_object(obj) ;
	    }
	 in.close() ;
	 return success ;
	 }
      return false ;
      }
   return true ;
}

//----------------------------------------------------------------------

const FrList *EBMTCorpus::sourceSynonyms(const char *word) const
{
   if (sourcehash)
      {
      FrSymbol *wordsym = makeSymbol(word) ;
      if (wordsym)
	 {
	 FrSymHashEntry *entry = sourcehash->lookup(wordsym) ;
	 if (entry)
	    return (const FrList*)entry->getUserData() ;
	 }
      }
   // if we get here, we were unable to lookup synonyms for the word
   return 0 ;
}

//----------------------------------------------------------------------

FrList *EBMTCorpus::getTargetRoots(const FrList *sentence)
{
   FrList *result = 0 ;
   FrList **end = &result ;

   if (!targethash)
      {
      // load target-language roots and synonyms the first time we need them
      if (tsyn_filename)
	 {
	 targethash = load_target_hashtable(tsyn_filename) ;
	 if (!targethash)
	    {
	    FrFree(tsyn_filename) ;
	    tsyn_filename = 0 ;		// unable to load....
	    return 0 ;			// can't get roots without synonym list
	    }
	 }
      else
	 return 0 ;			// can't get roots without synonym list
      }
   for ( ; sentence ; sentence = sentence->rest())
      {
      FrString *wordstring = (FrString*)sentence->first() ;
      FrSymbol *word = FrCvt2Symbol(wordstring,char_encoding) ;
      FrSymHashEntry *entry = targethash->lookup(word) ;
      FrList *roots = entry ? entry->getList() : 0 ;
      result->pushlistend(roots ? roots->deepcopy() : 0,end) ;
      }
   *end = 0 ;				// terminate result list
   return result ;
}

//----------------------------------------------------------------------

void EBMTCorpus::setExampleWeight(EBMTCandidate *cand) const
{
   if (cand)
      {
      uint32_t num_examples = this->index->numSentencePairs() ;
      uint32_t example = cand->exampleNumber() ;
      if (num_examples < 2)
	 num_examples = 1 ;
      else
	 num_examples-- ;
      double freq = cand->frequency() ;
      const EbDataSource *source = originOf(example) ;
      double oweight = originWeight(example,source) ;
      cand->setOriginWeight(freq * oweight) ;
      double multiref = localContextBonus(example) ;
      cand->setMultiRef(freq * multiref) ;
      double srcfeat = EbSourceFeatureScore(cand) ;
      cand->setSourceFeatureScore(freq * srcfeat) ;
      double weight = (1.0 + cand->sentContext()) ;
//      weight *= (1.0 + srcfeat) ;
      double rel_position = example / (double)num_examples ;
      weight *= (rel_position * example_weight_range + example_weight_start) ;
      cand->setMass(freq * weight) ;
      }
   return ;
}

//----------------------------------------------------------------------

bool EBMTCorpus::initRefCounts()
{
   delete m_refcounts ;		m_refcounts = 0 ;
   EBMTIndex *index = getIndex() ;
   if (index)
      {
      size_t pairs = index->numSentencePairs() ;
      m_refcounts = new EbRefCounts(pairs) ;
      }
   return true ;
}

//----------------------------------------------------------------------

bool EBMTCorpus::resetRefCounts()
{
   if (m_refcounts)
      {
      m_refcounts->clearCounts() ;
      }
   return true ;
}

//----------------------------------------------------------------------

void EBMTCorpus::addReference(size_t examplenum, size_t)
{
   if (m_refcounts)
      {
      FrCRITSECT_ENTER(m_mutex) ;
      m_refcounts->addReference(examplenum) ;
      FrCRITSECT_LEAVE(m_mutex) ;
      }
   return ;
}

//----------------------------------------------------------------------

void EBMTCorpus::addReference(const EBMTCandidate *candidate)
{
   if (candidate)
      addReference(candidate->exampleNumber(),candidate->matchLength()) ;
   return ;
}

//----------------------------------------------------------------------

size_t EBMTCorpus::referenceCount(size_t examplenum) const
{
   return (m_refcounts ? m_refcounts->refCount(examplenum) : 0) ;
}

//----------------------------------------------------------------------

double EBMTCorpus::localContextBonus(size_t examplenum) const
{
   size_t refcount = referenceCount(examplenum) ;
   if (refcount) refcount-- ; // it got incremented before we were called
   return refcount ;
}

//----------------------------------------------------------------------

FrList *preprocess_word_translations(const FrList *translations,
				     EBMTCorpus * /*corpus*/)
{
   FrList *result = 0 ;
   for ( ; translations ; translations = translations->rest())
      {
      FrObject *translation = translations->first() ;
      if (translation)
	 {
	 FrObjectType otype = translation->objType() ;
	 if (otype == OT_Symbol && translation != symPERIOD)
	    {
	    if (!result->member(translation))
	       pushlist(translation,result) ;
	    }
	 else if (otype == OT_List || otype == OT_Cons)
	    {
	    if (!((FrList*)translation)->rest())
	       translation = ((FrList*)translation)->first() ;
	    if (!result->member(translation,::equal))
	       pushlist(translation->deepcopy(),result) ;
	    }
	 else if (otype == OT_FrString)
	    {
	    FrString *trans_str = (FrString*)translation ;
	    const char *str = trans_str->stringValue() ;
	    FrList *trans = FrCvtString2Symbollist(str,word_delimiters,
						   !dict_keep_case) ;
	    if (trans)
	       {
	       if (trans->rest()) // multi-word definition?
		  {
		  if (!result->member(trans,::equal))
		     pushlist(trans,result) ;
		  else
		     trans->freeObject() ;
		  }
	       else // single-word definition
		  {
		  FrObject *wrd = poplist(*((FrList**)&trans)) ;
		  if (!result->member(wrd))
		     pushlist(wrd,result) ;
		  else if (wrd)
		     wrd->freeObject() ;
		  }
	       }
	    }
	 }
      }
   return listreverse(result) ;
}

//----------------------------------------------------------------------

bool EBMTCorpus::storeTranslations()
{
   if (new_translations && dictionary)
      {
      if (dictionary->save())
	 new_translations = false ;
      else
	 return false ;
      }
   return true ;
}

//----------------------------------------------------------------------

bool EBMTCorpus::locateRecordStarts()
{
   if (index && index->setIndexLocations())
      {
      m_haverecstarts = true ;
      return true ;
      }
   else
      return false ;
}

//----------------------------------------------------------------------

bool EBMTCorpus::locateRecordStarts(EbBWTIndex *idx)
{
   if (idx)
      {
      if (idx->setIndexLocations(index->numSentencePairs()))
	 {
	 m_haverecstarts = true ;
	 return true ;
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

void EBMTCorpus::freeRecordStarts()
{
   if (index)
      index->freeIndexLocations() ;
   m_haverecstarts = false ;
   return ;
}

//----------------------------------------------------------------------

bool EBMTCorpus::selectGenre(EbGenreSettings *genre)
{
   if (!genre)
      return false ;
   FrCRITSECT_ENTER(m_mutex) ;
   ebmt_vars.genre = genre ;
   EBMTIndex *index = getIndex() ;
   if (index)
      {
      index->clearOriginWeights() ;
      index->setOriginWeights(example_origin_weights) ;
      }
   FrCRITSECT_LEAVE(m_mutex) ;
   return true ;
}

//----------------------------------------------------------------------

bool EBMTCorpus::selectGenre(const char *genre_name, bool remember_prev)
{
   EbGenreSettings *genre = EbGenreSettings::find(genre_name) ;
   if (!genre)
      return false ;
   if (remember_prev)
      ebmt_vars.previous_genre = ebmt_vars.genre ;
   return selectGenre(genre) ;
}

//----------------------------------------------------------------------

bool EBMTCorpus::revertGenre()
{
   EbGenreSettings *genre = ebmt_vars.previous_genre ;
   ebmt_vars.previous_genre = 0 ;
   return selectGenre(genre) ;
}

//----------------------------------------------------------------------

FrList *EBMTCorpus::getTranslations(FrSymbol *sword, size_t max) const
{
   if (!sword || !sword->symbolp())
      return 0 ;
   FrList *xlat = dictionary ? dictionary->lookup(sword,max) : 0 ;
   if (!xlat && is_number((char*)sword->symbolName()))
      return new FrList(new FrList(sword,new FrInteger(0))) ;
   return xlat ;
}

//----------------------------------------------------------------------

// end of file ebcorpus.cpp //
