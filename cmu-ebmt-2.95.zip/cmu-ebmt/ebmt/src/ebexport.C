/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.91							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebexport.cpp	EBMT corpus export to text			*/
/*  LastEdit: 14jan10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#if defined(__GNUC__)
#  pragma implementation "ebcorpus.h"
#endif

#include "ebmt.h"
#include "ebbitext.h"
#include "ebcorpus.h"
#include "ebcrpinf.h"
#include "ebsent.h"
#include "ebglobal.h"

//----------------------------------------------------------------------

static void print_with_prefix(FILE *fp, size_t &tagcount, const char *fmt, ...)
{
   if (tagcount > 8)
      {
      fputc('\n',fp) ;
      tagcount = 0 ;
      }
   if (tagcount == 0)
      fputs(";;;",fp) ;
   tagcount++ ;
   va_list args ;
   va_start(args,fmt) ;
   vfprintf(fp,fmt,args) ;
   va_end(args) ;
   return ;
}

//----------------------------------------------------------------------

bool EBMTCorpus::exportCorpus(FILE *fp, EbIndexSpec which)
{
   EBMTIndex *index = getIndex() ;
   if (fp && index)
      {
      FrVocabulary *vocab = index->vocabulary() ;
      EbBWTIndex *idx = index->selectIndex(which) ;
      EbBWTIndex *struc = index->selectIndex(EbIndex_Struct) ;
      if (struc && !locateRecordStarts(struc)) 	// only use structural index
	 struc = 0 ;				//   if we can find records
      if (idx && vocab && locateRecordStarts(idx))
	 {
	 vocab->createReverseMapping() ;
	 const char *prev_orig = 0 ;
	 for (size_t i = 0 ; i <= index->numSentencePairs() ; i++)
	    {
	    uint32_t start = idx->indexLocation(i) ;
	    if (start == (uint32_t)~0)
	       continue ;
	    FrList *source = idx->retrieveSource(start,vocab,EbEx_LENGTHMASK) ;
	    if (source)
	       {
	       FrList *pos = 0 ;
	       if (struc)
		  pos = struc->retrieveSource(struc->indexLocation(i),vocab,
					      EbEx_LENGTHMASK) ;
	       size_t srclen = source->simplelistlength() ;
	       EbSentence *target = 0 ;
	       EbCorpusMetaInfo metainfo ;
	       if (getExample(i,target,metainfo,srclen) && target)
		  {
		  // check whether we've switched to a new source file,
		  //   and if so, tag the sentence pair so that we can
		  //   properly reconstruct the corpus later
		  if (!metainfo.origin())
		     {
		     const char *orig = index->getOrigin(i) ;
		     if (orig && (!prev_orig || strcmp(orig,prev_orig) != 0))
			{
			metainfo.origin(orig) ;
			metainfo.addField(EbCorpusMetaInfo::origin_tag) ;
			prev_orig = orig ;
			}
		     }
		  size_t tagcount = 0 ;
		  if (metainfo.haveField(EbCorpusMetaInfo::token_tag))
		     {
		     print_with_prefix(fp,tagcount,"(TOKEN %s)",
				       metainfo.token()->symbolName()) ;
		     }
		  if (metainfo.haveField(EbCorpusMetaInfo::score_tag))
		     {
		     print_with_prefix(fp,tagcount,"(SCORE %g)",
				       metainfo.alignmentScore()) ;
		     }
		  if (metainfo.haveField(EbCorpusMetaInfo::freq_tag))
		     {
		     print_with_prefix(fp,tagcount,"(FREQ %lu)",
				       (unsigned long)metainfo.frequency());
		     }
		  if (metainfo.haveField(EbCorpusMetaInfo::origin_tag))
		     {
		     print_with_prefix(fp,tagcount,"(ORIGIN \"%s\")",
				       metainfo.origin()) ;
		     }
		  if (metainfo.haveField(EbCorpusMetaInfo::lcontext_tag))
		     {
		     FrList *c = (FrList*)metainfo.leftContext() ;
		     pushlist(makeSymbol("LCONTEXT"),c) ;
		     char *context = c->print() ;
		     poplist(c) ; // leave return value from metainfo unchanged
		     print_with_prefix(fp,tagcount,"%s",context) ;
		     FrFree(context) ;
		     }
		  if (metainfo.haveField(EbCorpusMetaInfo::rcontext_tag))
		     {
		     FrList *c = (FrList*)metainfo.rightContext() ;
		     pushlist(makeSymbol("RCONTEXT"),c) ;
		     char *context = c->print() ;
		     poplist(c) ; // leave return value from metainfo unchanged
		     print_with_prefix(fp,tagcount,"%s",context) ;
		     FrFree(context) ;
		     }
		  if (metainfo.haveField(EbCorpusMetaInfo::bounds_tag))
		     {
		     FrList *b = metainfo.chunkBoundaries() ;
		     if (b)
			{
			pushlist(makeSymbol("BOUNDS"),b) ;
			char *bounds = b->print() ;
			free_object(b) ;
			print_with_prefix(fp,tagcount,"%s",bounds) ;
			FrFree(bounds) ;
			}
		     }
		  if (metainfo.haveField(EbCorpusMetaInfo::trgspans_tag))
		     {
		     const FrList *sp = metainfo.targetSpans() ;
		     if (sp)
			{
			FrList *spn = (FrList*)sp->deepcopy() ;
			pushlist(makeSymbol("TRGSPANS"),spn) ;
			char *spans = spn->print() ;
			free_object(spn) ;
			print_with_prefix(fp,tagcount,"%s",spans) ;
			FrFree(spans) ;
			}
		     }
		  if (metainfo.numSourceWords() > 0 &&
		      (metainfo.haveField(EbCorpusMetaInfo::pos_tag) ||
		       metainfo.haveField(EbCorpusMetaInfo::person_tag) ||
		       metainfo.haveField(EbCorpusMetaInfo::num_tag) ||
		       metainfo.haveField(EbCorpusMetaInfo::gender_tag) ||
		       metainfo.haveField(EbCorpusMetaInfo::aspect_tag) ||
		       metainfo.haveField(EbCorpusMetaInfo::morph_tag)))
		     {
		     if (tagcount > 0)
			fputs("\n",fp) ;
		     for (size_t i = 0 ; i < metainfo.numSourceWords() ; i++)
			{
			FrList *morph = metainfo.morphology(i) ;
			if (morph)
			   {
			   pushlist(new FrInteger(i),morph) ;
			   pushlist(symMORPH,morph) ;
			   char *m = morph->print() ;
			   free_object(morph) ;
			   tagcount = 0 ;
			   print_with_prefix(fp,tagcount,"%s\n",m) ;
			   FrFree(m) ;
			   }
			}
		     tagcount = 0 ;
		     }
		  if (metainfo.haveField(EbCorpusMetaInfo::exact_tag) ||
		      index->requireExactMatch(i))
		     {
		     print_with_prefix(fp,tagcount,"%s","(EXACT)") ;
		     tagcount++ ;
		     }
		  if (metainfo.haveField(EbCorpusMetaInfo::align_tag))
		     {
		     FrList *align = metainfo.bitext()->alignment() ;
		     if (align)
			{
			pushlist(FrSymbolTable::add("ALIGN"),align) ;
			char *aligntext = align->print() ;
			if (aligntext)
			   print_with_prefix(fp,tagcount,"%s",aligntext) ;
			FrFree(aligntext) ;
			tagcount += align->simplelistlength() ;
			align->freeObject() ;
			}
		     }
		  if (metainfo.haveField(EbCorpusMetaInfo::userscore_tag))
		     {
		     if (metainfo.userScores() && metainfo.numUserScores() > 0)
			{
			FrList *sc = new FrList(FrSymbolTable::add("SC")) ;
			for (size_t i = 0 ; i < metainfo.numUserScores() ; i++)
			   {
			   double score = metainfo.userScore(i) ;
			   pushlist(new FrFloat(score),sc) ;
			   }
			sc = listreverse(sc) ;
			char *sctext = sc->print() ;
			if (sctext)
			   print_with_prefix(fp,tagcount,"%s",sctext) ;
			FrFree(sctext) ;
			tagcount += sc->simplelistlength() ;
			sc->freeObject() ;
			}
		     }
		  if (metainfo.haveField(EbCorpusMetaInfo::phrase_tag))
		     {
		     FrList *phrases = metainfo.phrasalAlignments() ;
		     if (phrases)
			{
			print_with_prefix(fp,tagcount,"(PHRASE") ;
			for (const FrList *phr = phrases ;
			     phr ; 
			     phr=phr->rest())
			   {
			   FrList *phrase = (FrList*)phr->first() ;
			   char *ptext = phrase->print() ;
			   if (ptext)
			      {
			      fputs(ptext,fp) ;
			      FrFree(ptext) ;
			      }
			   tagcount++ ;
			   if (tagcount > 8 && phr->rest())
			      {
			      fputs(")\n;;;(PHRASE",fp) ;
			      tagcount = 0 ;
			      }
			   }
			fputc(')',fp) ;
			phrases->freeObject() ;
			}
		     }
		  if (metainfo.haveField(EbCorpusMetaInfo::source_tag))
		     {
		     const FrList *src = metainfo.sourceTags() ;
		     if (src)
			{
			if (tagcount > 0)
			   {
			   fputc('\n',fp) ;
			   tagcount = 0 ;
			   }
			for ( ; src ; src = src->rest())
			   {
			   const FrList *s = (FrList*)src->first() ;
			   char *stext = s->print() ;
			   if (stext)
			      {
			      fprintf(fp,";;;(SOURCE %s)",stext) ;
			      FrFree(stext) ;
			      if (src->rest())
				 fputc('\n',fp) ;
			      }
			   }
			}
		     }
		  if (metainfo.haveField(EbCorpusMetaInfo::target_tag))
		     {
		     const FrList *trg = metainfo.targetTags() ;
		     if (trg)
			{
			if (tagcount > 0)
			   {
			   fputc('\n',fp) ;
			   tagcount = 0 ;
			   }
			for ( ; trg ; trg = trg->rest())
			   {
			   const FrList *t = (FrList*)trg->first() ;
			   char *ttext = t->print() ;
			   if (ttext)
			      {
			      fprintf(fp,";;;(TARGET %s)",ttext) ;
			      FrFree(ttext) ;
			      if (trg->rest())
				 fputc('\n',fp) ;
			      }
			   }
			}
		     }
		  fputc('\n',fp) ;
		  if (pos)
		     {
		     pushlist(symPOS,pos) ;
		     char *printed = pos->print() ;
		     fprintf(fp,";;;(SOURCE %s)\n",printed) ;
		     FrFree(printed) ;
		     pos->freeObject() ;
		     }
		  FrString *sourcetext = new FrString(source) ;
		  if (sourcetext->stringLength() > 0)
		     fputs(sourcetext->stringValue(),fp) ;
		  else
		     fputs("<notrans>",fp) ;
		  free_object(sourcetext) ;
		  fputc('\n',fp) ;
		  char *targettext = target->print() ;
		  fputs(targettext,fp) ;
		  FrFree(targettext) ;
		  fputc('\n',fp) ;
		  fputc('\n',fp) ;
		  }
	       delete target ;
	       source->freeObject() ;
	       }
	    }
	 return true ;
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

bool EBMTCorpus::exportCorpus(const char *exportfile)
{
   FILE *fp = fopen(exportfile,"w") ;
   if (fp)
      {
      bool success = exportCorpus(fp,EbIndex_Main) ;
      if (success)
	 success = exportCorpus(fp,EbIndex_Updates) ;
      fclose(fp) ;
      return success ;
      }
   return false ;
}

/************************************************************************/
/*	Methods for class EBMT						*/
/************************************************************************/

bool EBMT::exportCorpus(const char *exportfile)
{
   if (corpus)
      return corpus->exportCorpus(exportfile) ;
   return false ;			// can't export if not loaded
}

// end of file ebexport.cpp //
