/************************************************************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebbitxt2.cpp	bitext-mapping support functions		*/
/*  LastEdit: 08apr10							*/
/*									*/
/*  (c) Copyright 2006,2008,2009,2010 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "FramepaC.h"
#include "ebbitext.h"
#include "dict.h"
#include "ebutil.h"
#include "ebglobal.h"

/************************************************************************/
/*	Manifest constants						*/
/************************************************************************/

#define LINK_CUTOFF 	0.8
#define SMOOTHING	0.1	// slightly reduce reported probabilities
				//   on low-frequency words

#define SYNONYM_DISCOUNT 	0.5
#define UNACCENTED_DISCOUNT 	0.5

/************************************************************************/
/*	Helper functions						*/
/************************************************************************/

#ifdef DEBUG
#  define DEBUG_TRACE(s,t,cond,val) \
	cerr << "translation_prob(" << s << "," << t << ") " << cond \
	     << val << endl
#else
#  define DEBUG_TRACE(s,t,cond,val)
#endif

extern bool unaccented_match(const FrObject *o1, const FrObject *o2) ;

static void set_translation_probability(double *probs,
					const char *sword,
					const FrList *twords,
					const DictionaryEntry *translations,
					size_t numtrans,
					const FrSymbol *trans_num,
					const FrList *synonyms,
					bool &identity_match)
{
   identity_match = false ;
   for (size_t i = 0 ; i < numtrans ; i++)
      {
      const FrObject *translation = translations[i].translation() ;
      if (!translation)
	 break ;
      double prob = translations[i].probability() ;
      if (translation->consp())
	 {
	 const FrList *xlat = (FrList*)translation ;
	 size_t match = 0 ;
	 for (const FrList *tw = twords ;
	      tw && xlat ; 
	      tw = tw->rest(), xlat = xlat->rest())
	    {
	    if (tw->first() == xlat->first() ||
		(match_accented && 
		  unaccented_match(tw->first(),xlat->first())))
	       match++ ;
	    else
	       {
	       match = 0 ;
	       break ;
	       }
	    }
	 if (match > 0)
	    {
	    DEBUG_TRACE(sword,twords,"==> phrase match: ",prob) ;
	    for (size_t i = 0 ; i < match ; i++)
	       {
	       if (prob > probs[i])
		  probs[i] = prob ;
	       }
	    }
	 return ;
	 }
      if (translation == twords->first())
	 {
	 const char *tword = ((FrSymbol*)twords->first())->symbolName() ;
	 identity_match = (Fr_stricmp(sword,tword,lowercase_table) == 0) ;
	 }
      else if (synonyms->member(translation,EBMT_equal))
	 prob *= SYNONYM_DISCOUNT ;
      else if (match_accented && 
	       unaccented_match(twords->first(),translation))
	 prob *= UNACCENTED_DISCOUNT ;
      else
	 continue ;
      // we get to this point only if the words match, so 'prob' is valid
      DEBUG_TRACE(sword,twords->first(),"= ",prob) ;
      if (prob > *probs)
	 *probs = prob ;
      return ;
      }
   // if we get here, there is no match between the target words and the
   //   given translations, but we might still be able to infer a translation
   //   if the source is a number or there is a cognate relationship between
   //   source and target
   const char *tword = ((FrSymbol*)twords->first())->symbolName() ;
   double prob = 0.0 ;
   if (Fr_stricmp(sword,tword,lowercase_table) == 0)
      {
      identity_match = true ;
      prob = is_number(sword) ? 0.9 : 0.5 ;
      DEBUG_TRACE(sword,tword,"==> identity match: ",prob) ;
      }
   else if (trans_num &&
	    Fr_stricmp(tword,trans_num->symbolName(),lowercase_table) == 0)
      {
      prob = 0.9 ;
      DEBUG_TRACE(sword,tword,"==> number match: ",prob) ;
      }
   else if (allow_cognates && cognate_threshold < 1.0)
      {
      double cog = FrCognateScore(sword,tword) ;
      if (cog >= cognate_threshold)
	 {
	 prob = cog / 10.0 ;
	 DEBUG_TRACE(sword,tword,"==> cognate match: ",prob) ;
	 }
      }
   if (prob > *probs)
      *probs = prob ;
   return ;
}

/************************************************************************/
/*	Procedural interface 						*/
/************************************************************************/

BiTextMap *EbMakeBitext(const FrList *source, const FrList *target,
			const FrList *trg_synonyms,
			FrCasemapTable number_charmap,
			const EbAlignConstraints *constraints)
{
   const Dictionary *dict = constraints ? constraints->dictionary() : 0 ;
   if (!dict)
      return 0 ;
   size_t srclen = source->simplelistlength() ;
   size_t trglen = target->simplelistlength() ;
   size_t total_entries = srclen * trglen ;
   FrLocalAllocC(double,probs,4096,total_entries) ;
   if (!probs)
      {
      FrNoMemory("while generating probability table for bitext map") ;
      return 0 ;
      }
   FrCharEncoding enc = dict_keep_case ? FrChEnc_RawOctets : char_encoding ;
   FrList *swords = FrCvtWordlist2Symbollist(source,char_encoding) ;
   FrList *twords = FrCvtWordlist2Symbollist(target,enc) ;
   size_t i ;
   const FrList *sw ;
   for (i = 0, sw = swords ; sw ; i++, sw = sw->rest())
      {
      const char *sword = ((FrSymbol*)sw->first())->symbolName() ;
      size_t numtrans ;
      DictionaryEntry *translations = dict->lookupProbabilities(sword,numtrans,
								SMOOTHING) ;
      const FrSymbol *trans_number = 0 ;
      if (is_number(sword))
	 trans_number = map_number(sword,number_charmap) ;
      size_t j ;
      const FrList *tw ;
      const FrList *syn = trg_synonyms ;
      bool identity_match = false ;
      for (j = 0, tw = twords ; tw ; j++, tw = tw->rest())
	 {
	 if (identity_match)
	    {
	    probs[i*trglen + j] = 0.0 ;
	    identity_match = false ;
	    }
	 else
	    set_translation_probability(&probs[i*trglen+j],sword,tw,
					translations,numtrans,trans_number,
					syn?(FrList*)syn->first():0,
					identity_match) ;
	 // if the word is translated as itself, it is very unlikely that
	 //   the neighboring words are part of the translation, but the
	 //   statistical dictionary tends to include them anyway.  Thus, we
	 //   zap the neighboring words
	 if (identity_match && j > 0)
	    probs[i*trglen + j - 1] = 0.0 ;
         if (syn)
	    syn = syn->rest() ;
	 }
      delete [] translations ;
      }
   BiTextMap *bitext = new BiTextMap(srclen,trglen,probs,swords,twords,
				     LINK_CUTOFF,-1,constraints) ;
   FrLocalFree(probs) ;
   if (!bitext)
      {
      free_object(swords) ;
      free_object(twords) ;
      }
   return bitext ;
}

// end of file ebbitxt2.C //
