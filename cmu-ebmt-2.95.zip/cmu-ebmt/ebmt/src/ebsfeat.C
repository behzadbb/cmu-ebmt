/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebsfeat.cpp		source-feature scoring			*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 2008 Ralf Brown					*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "ebcmatch.h"
#include "ebmt.h"
#include "ebglobal.h"

#ifdef FrSTRICT_CPLUSPLUS
# include <cmath>
#else
# include <math.h>
#endif

/************************************************************************/
/*   Feature evaluation functions					*/
/************************************************************************/

static double source_location(size_t rec_offset, size_t matchlen,
			      size_t rec_len, size_t input_start,
			      size_t input_end, size_t input_len)
{
   if (rec_len > 0 && input_len > 0)
      {
      // treat each match as a two-element vector of (proportional) starting
      //   and ending position on a pi/2 radian arc, and compute the angles
      //   between them
      double start1 = rec_offset / (double)rec_len * M_PI_2 ;
      double start2 = input_start / (double)input_len * M_PI_2 ;
      double end1 = (rec_offset + matchlen - 1) / (double)rec_len * M_PI_2 ;
      double end2 = input_end / (double)input_len * M_PI_2 ;
      double start_angle = (start2 - start1) ;
//      double mid_angle = ((start2 + end2) / 2) - ((start1 + end1) / 2) ;
      double end_angle = (end2 - end1) ;
//      double avg_diff = (start_angle + mid_angle + end_angle) / 3.0 ;
      double avg_diff = (start_angle + end_angle) / 2.0 ;
      return ::cos(avg_diff) ;
      }
   else
      return 1.0 ;			// can't tell, so use default
}

/************************************************************************/
/*	Procedural interface						*/
/************************************************************************/

//----------------------------------------------------------------------
// this version of the scoring should look only at quick-to-compute
//   features; the features it scores should be a subset of the ones
//   scored by the in-depth scoring function below
// return value should preferably be in [0.0,1.0] (must be >= 0.0)

double EbSourceFeatureScore(const EbCorpusMatches *matches,
			    const EBMTIndex *index,
			    size_t recnum, size_t offset, size_t input_len)
{
   if (matches)
      {
      double sc_location = 0.0 ;
      if (srcfeat_position > 0.0)
	 {
	 size_t rec_len = index->sourceLength(recnum) ;
	 size_t input_start = matches->startPosition() ;
	 size_t input_end = matches->endPosition() ;
	 sc_location = source_location(offset,matches->matchLength(),rec_len,
				       input_start,input_end,input_len) ;
	 sc_location = srcfeat_position * EBMTCandidate::log(sc_location) ;
	 }
      // other features go here
      return ::exp(sc_location) ;
      }
   else
      return 1.0 ;
}

//----------------------------------------------------------------------
// this version may look at any features that are available
// return value should preferably be in [0.0,1.0] (must be >= 0.0)

double EbSourceFeatureScore(const EBMTCandidate *cand)
{
   if (cand)
      {
      double sc_location = 0.0 ;
      if (srcfeat_position > 0.0 &&
	  cand->exampleNumber() != DUMMY_EXAMPLE_NUMBER)
	 {
	 const EBMTIndex *index = cand->getIndex() ;
	 size_t recnum = cand->exampleNumber() ;
	 size_t offset = cand->sourceOffset() ;
	 size_t rec_len = index->sourceLength(recnum) ;
	 size_t input_start = cand->inputStart() ;
	 size_t input_end = input_start + cand->inputLength() - 1 ;
	 size_t input_len = cand->inputTextLength() ;
	 double srcloc = source_location(offset,cand->matchLength(),rec_len,
					 input_start,input_end,input_len) ;
	 sc_location = srcfeat_position * EBMTCandidate::log(srcloc) ;
	 }
      // other features go here
      return ::exp(sc_location) ;
      }
   else
      return 1.0 ;
}

// end of file ebsfeat.cpp //
