/************************************************************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebsource.cpp		EBMT data source records		*/
/*  LastEdit: 19apr10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2006,	*/
/*		2007,2008,2009,2010 Ralf Brown				*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include <math.h>
#ifdef unix
# include <unistd.h>
#elif defined(__MSDOS__) || defined(__WINDOWS__)
# include <io.h>
#endif
#include "FramepaC.h"
#include "ebsource.h"
#include "ebglobal.h"

/************************************************************************/
/*	Manifest Constants						*/
/************************************************************************/

#define SOURCE_FORMAT  1
#define SOURCE_SIGNATURE "Glossary Source Files\n\032"

/************************************************************************/
/*	Global Data for this module					*/
/************************************************************************/

static const char fopen_read_mode[] = FrFOPEN_READ_MODE ;
static const char fopen_write_mode[] = FrFOPEN_WRITE_MODE ;

/************************************************************************/
/*    Methods for class EbDataSource 					*/
/************************************************************************/

EbDataSource::EbDataSource(const char *file, off_t s, off_t e)
{
   m_weight = 0.0 ;
   m_rank = 0 ;
   if (file && *file)
      {
      m_start = s ;
      m_end = e ;
      size_t len = strlen(file)+1 ;
      m_sourcename = FrNewN(char,len) ;
      memcpy(m_sourcename,file,len) ;
      // remove trailing whitespace
      char *end = m_sourcename + len - 2 ;
      while (end >= m_sourcename && Fr_isspace(*end))
	 end-- ;
      end[1] = '\0' ;
      }
   else
      {
      m_start = m_end = 0 ;
      m_sourcename = 0 ;
      }
   return ;
}

//----------------------------------------------------------------------

EbDataSource::~EbDataSource()
{
   FrFree(m_sourcename) ;
   return ;
}

//----------------------------------------------------------------------

bool EbDataSource::save(const char *filename, size_t num_sources) const
{
   FILE *fp = fopen(filename,fopen_write_mode) ;
   if (!fp)
      return false ;
   // write the file header
   fseek(fp,0L,SEEK_SET) ;
   char version = SOURCE_FORMAT ;
   char pad1[3] ;
   LONGbuffer count ;
   char pad2[32] ;
   memset(pad1,'\0',sizeof(pad1)) ;
   FrStoreLong(num_sources,count) ;
   memset(pad2,'\0',sizeof(pad2)) ;
   if (!Fr_fwrite(SOURCE_SIGNATURE,1,sizeof(SOURCE_SIGNATURE),fp) ||
       !Fr_fwrite(&version,1,sizeof(version),fp) ||
       !Fr_fwrite(pad1,1,sizeof(pad1),fp) ||
       !Fr_fwrite(count,1,sizeof(count),fp) ||
       !Fr_fwrite(pad2,1,sizeof(pad2),fp))
      {
      fclose(fp) ;
      return false ;
      }
   const EbDataSource *source = this ;
   for (size_t i = num_sources ; i > 0 ; i--, source++)
      {
      const char *name = source->getName() ;
      if (!name)
	 continue ;
      LONGbuffer range[2] ;
      FrStoreLong(source->startLoc(),range[0]) ;
      FrStoreLong(source->endLoc(),range[1]) ;
      size_t len = strlen(name)+1 ;
      if (!Fr_fwrite(range,1,sizeof(range),fp) ||
	  !Fr_fwrite(name,1,len,fp))
	 {
	 fflush(fp) ;
	 fclose(fp) ;
	 return false ;
	 }
      }
   fflush(fp) ;
   fclose(fp) ;
   return true ;
}

//----------------------------------------------------------------------

bool EbDataSource::sameSource(const char *file, off_t strt)
{
   // say this is the same source document if the filename is the same
   // and the new segment abuts the existing one (this minimizes duplication,
   // especially in the case where the user is adding pairs one at a time)
   if ((strt == endLoc() || strt == endLoc()+1) &&
       FrSameFile(file,getName()))
      return true ;
   else
      return false ;
}

//----------------------------------------------------------------------

bool EbDataSource::sameSource(const char *file)
{
   return FrSameFile(file,getName()) ;
}

//----------------------------------------------------------------------

static bool read_source_header(FILE *srcfp, size_t &num_entries,
				 const char *filename)
{
   if (!srcfp)
      return false ;
   fseek(srcfp,0L,SEEK_SET) ;
   char signature[sizeof(SOURCE_SIGNATURE)] ;
   char version ;
   char pad1[3] ;
   LONGbuffer entrycount ;
   char pad2[32] ;
   if (fread(signature,sizeof(char),sizeof(signature),srcfp) < sizeof(signature) ||
       strcmp(signature,SOURCE_SIGNATURE) != 0)
      {
      FrWarningVA("corrupted data-source file (%s)",filename) ;
      return false ;
      }
   if (fread(&version,sizeof(char),sizeof(version),srcfp) < sizeof(version) ||
       version != SOURCE_FORMAT)
      {
      FrWarning("data-source file has incorrect version code") ;
      return false ;
      }
   if (fread(pad1,sizeof(char),sizeof(pad1),srcfp) < sizeof(pad1) ||
       fread(entrycount,sizeof(entrycount),1,srcfp) < 1 ||
       fread(pad2,sizeof(char),sizeof(pad2),srcfp) < sizeof(pad2))
      {
      FrWarningVA("read error in data-source file (%s) header",filename) ;
      return false ;
      }
   num_entries = (size_t)FrLoadLong(entrycount) ;
   return true ;
}

//----------------------------------------------------------------------

static bool write_source_header(FILE *srcfp, const char *filename)
{
   if (!srcfp)
      return false ;
   fseek(srcfp,0L,SEEK_SET) ;
   char version = SOURCE_FORMAT ;
   char pad1[3] ;
   LONGbuffer entrycount ;
   char pad2[32] ;
   memset(pad1,'\0',sizeof(pad1)) ;
   FrStoreLong(0,entrycount) ;
   memset(pad2,'\0',sizeof(pad2)) ;
   if (!Fr_fwrite(SOURCE_SIGNATURE,1,sizeof(SOURCE_SIGNATURE),srcfp) ||
       !Fr_fwrite(&version,1,sizeof(version),srcfp) ||
       !Fr_fwrite(pad1,1,sizeof(pad1),srcfp) ||
       !Fr_fwrite(entrycount,1,sizeof(entrycount),srcfp) ||
       !Fr_fwrite(pad2,1,sizeof(pad2),srcfp))
      {
      FrWarningVA("error writing header for %s",filename) ;
      return false ;
      }
   return true ;
}

//----------------------------------------------------------------------

static bool read_source_name(FILE *srcfp, EbDataSource *source)
{
   if (!srcfp || feof(srcfp))
      return false ;
   LONGbuffer range[2] ;
   if (fread(range,sizeof(LONGbuffer),2,srcfp) < 2)
      return false ;
   char sourcename[500] ;
   for (size_t i = 0 ; i < sizeof(sourcename)-1 ; i++)
      {
      if ((sourcename[i] = (char)fgetc(srcfp)) == '\0')
	 break ;
      }
   sourcename[sizeof(sourcename)-1] = '\0' ; // ensure proper termination
   off_t start = (off_t)FrLoadLong(range[0]) ;
   off_t end = (off_t)FrLoadLong(range[1]) ;
   new(source) EbDataSource(sourcename,start,end) ;
   return true ;
}

//----------------------------------------------------------------------

size_t EbLoadDataSources(const char *filename, EbDataSource *&sources,
			 bool force_creation)
{
   size_t num_sources = 0 ;
   sources = 0 ;
   FILE *srcfp = fopen(filename,fopen_read_mode) ;
   if (!srcfp)
      {
      if (force_creation)
	 {
	 srcfp = FrOpenFile(filename) ;
	 if (srcfp)
	    {
	    bool success = write_source_header(srcfp,filename) ;
	    fclose(srcfp) ;
	    if (success)
	       srcfp = fopen(filename,fopen_read_mode) ;
	    else
	       srcfp = 0 ;
	    }
	 if (!srcfp)
	    return 0 ;
	 }
      else
	 return 0 ;
      }
   if (!read_source_header(srcfp,num_sources,filename))
      {
      fclose(srcfp) ;
      return 0 ;
      }
   if (num_sources > 0)
      {
      sources = FrNewN(EbDataSource,num_sources) ;
      for (size_t i = 0 ; i < num_sources ; i++)
	 {
	 if (!read_source_name(srcfp,&sources[i]))
	    {
	    FrWarning("read error--source files may be reported incorrectly") ;
	    for (size_t j = i ; j < num_sources ; j++)
	       new(&sources[i]) EbDataSource() ;
	    break ;
	    }
	 }
      }
   if (srcfp)
      fclose(srcfp) ;
   return num_sources ;
}

/************************************************************************/
/*    Methods for class EbDataSourceList				*/
/************************************************************************/

EbDataSourceList::EbDataSourceList()
{
   num_sources = 0 ;
   sources = 0 ;
   m_loaded = false ;
   m_changed = false ;
   m_have_weights = false ;
   return ;
}

//----------------------------------------------------------------------

EbDataSourceList::~EbDataSourceList()
{
   if (sources)
      {
      for (size_t i = 0 ; i < num_sources ; i++)
	 sources[i].clear() ;
      FrFree(sources) ;
      sources = 0 ;
      num_sources = 0 ;
      m_loaded = false ;
      m_changed = false ;
      m_have_weights = false ;
      }
   return ;
}

//----------------------------------------------------------------------

bool EbDataSourceList::load(const char *filename, bool force_creation)
{
   if (filename && *filename)
      {
      num_sources = EbLoadDataSources(filename,sources,force_creation) ;
      m_loaded = true ;
      m_changed = false ;
      m_have_weights = false ;
      }
   return false ;
}

//----------------------------------------------------------------------

bool EbDataSourceList::save(const char *filename)
{
   if (sources)
      return sources->save(filename,num_sources) ;
   return false ;
}

//----------------------------------------------------------------------

const EbDataSource *EbDataSourceList::find(off_t location) const
{
   if (sources)
      {
      // perform a binary search for the location
      size_t lo = 0 ;
      size_t hi = num_sources ;
      while (hi > lo)
	 {
	 size_t mid = (hi + lo) / 2 ;
	 if (location < sources[mid].startLoc())
	    hi = mid ;
	 else if (location > sources[mid].endLoc())
	    lo = mid+1 ;
	 else
	    return &sources[mid] ;
	 }
      }
   return 0 ;				// no match found
}

//----------------------------------------------------------------------

EbDataSource *EbDataSourceList::find(off_t location)
{
   if (sources)
      {
      // perform a binary search for the location
      size_t lo = 0 ;
      size_t hi = num_sources ;
      while (hi > lo)
	 {
	 size_t mid = (hi + lo) / 2 ;
	 if (location < sources[mid].startLoc())
	    hi = mid ;
	 else if (location > sources[mid].endLoc())
	    lo = mid+1 ;
	 else
	    return &sources[mid] ;
	 }
      }
   return 0 ;				// no match found
}

//----------------------------------------------------------------------

bool EbDataSourceList::addSource(const char *filename,
				   off_t start, off_t end)
{
   char *file = FrDupString(filename ? filename : "") ;
   // skip any leading and trailing whitespace in filename
   filename = FrTrimWhitespace(file) ;
   bool success = false ;
   if (sources && num_sources > 0 &&
       sources[num_sources-1].sameSource(filename,start))
      {
      sources[num_sources-1].expandSource(end) ;
      m_changed = true ;
      success = true ;
      }
   else
      {
      EbDataSource *newsrc = FrNewR(EbDataSource,sources,num_sources+1) ;
      if (newsrc)
	 {
	 sources = newsrc ;
	 new(&sources[num_sources++]) EbDataSource(filename,start,end) ;
	 m_changed = true ;
	 success = true ;
	 }
      }
   FrFree(file) ;
   return success ;
}

//----------------------------------------------------------------------

bool EbDataSourceList::addSource(const char *filename, FILE *fp)
{
   fseek(fp,0L,SEEK_END) ;
   off_t new_end = ftell(fp) ;
   if (sources && sources[num_sources-1].sameSource(filename))
      {
      sources[num_sources-1].expandSource(new_end) ;
      m_changed = true ;
      return true ;
      }
   EbDataSource *newsrc = FrNewR(EbDataSource,sources,num_sources+1) ;
   if (newsrc)
      {
      off_t start = 0 ;
      if (sources && num_sources)
	 start = sources[num_sources-1].endLoc() ;
      sources = newsrc ;
      new(&sources[num_sources++]) EbDataSource(filename,start,new_end) ;
      m_changed = true ;
      return true ;
      }
   else
      return false ;
}

//----------------------------------------------------------------------

void EbDataSourceList::resetWeights()
{
   if (haveWeights())
      {
      for (size_t i = 0 ; i < num_sources ; i++)
	 sources[i].setWeight(0.0) ;
      }
   m_have_weights = false ;
   return ;
}

//----------------------------------------------------------------------

void EbDataSourceList::incrWeight(size_t example_number)
{
   EbDataSource *source = find(example_number) ;
   if (source)
      {
      source->incrWeight() ;
      m_have_weights = true ;
      }
   return ;
}

//----------------------------------------------------------------------

static int compare_weight(const EbDataSource *s1, const EbDataSource *s2)
{
   // sort by increasing ranking: put higher weights later in array
   double cmp = s1->weight() - s2->weight() ;
   if (cmp > 0)
      return +1 ;
   else if (cmp < 0)
      return -1 ;
   // same weight, so prefer the more-recently added source
   if (s1->startLoc() > s2->startLoc())
      return +1 ;
   else if (s1->startLoc() < s2->startLoc())
      return -1 ;
   return 0 ;
}

//----------------------------------------------------------------------

void EbDataSourceList::rankSources()
{
   FrLocalAlloc(EbDataSource*,src,100000,numSources()) ;
   if (!src)
      {
      for (size_t i = 0 ; i < numSources() ; i++)
	 sources[i].setRank(0) ;
      return ;
      }
   for (size_t i = 0 ; i < numSources() ; i++)
      src[i] = &sources[i] ;
   FrQuickSortPtr(src,numSources(),compare_weight) ;
   size_t rank = 0 ;
   for (size_t i = 0 ; i < numSources() ; i++)
      {
      if (i > 0 && src[i]->weight() > src[i-1]->weight())
	 rank = i ;
      src[i]->setRank(rank) ;
      }
   FrLocalFree(src) ;
   return ;
}

//----------------------------------------------------------------------

void EbDataSourceList::normalizeWeights()
{
   // since we don't want long documents to totally dominate the weighting,
   //   divide the counts by an adjustment factor which is only slightly
   //   smaller than the number of sentences in the corresponding document
   double maxwt = 0.0 ;
   for (size_t i = 0 ; i < numSources() ; i++)
      {
      size_t len = sources[i].sourceLength() ;
      double adj = (len >= 10) ? (len - 4) : (3.5 + (len / 4.0)) ;
      if (adj > 0.0)
	 sources[i].setWeight(sources[i].weight() / adj) ;
      if (sources[i].weight() > maxwt)
	 maxwt = sources[i].weight() ;
      }
   if (maxwt < 0.02)
      maxwt = 0.02 ;
   // normalize the scores into the range [0,1] (except where the maximum
   //   un-normalized score is really low)
   for (size_t i = 0 ; i < num_sources ; i++)
      {
      sources[i].setWeight(sources[i].weight() / maxwt) ;
      }
   return ;
}

//----------------------------------------------------------------------

bool EbDataSourceList::OK() const
{
   return (sources && num_sources != 0) || m_loaded ;
}

//----------------------------------------------------------------------

// end of file ebsource.cpp //
