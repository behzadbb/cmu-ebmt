/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebconfig.h							*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 2009 Ralf Brown					*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __EBSTATS_H_INCLUDED
#define __EBSTATS_H_INCLUDED

#include "FramepaC.h"


/************************************************************************/

class EBMTCorpus ;

class EbMatchStatistics
   {
   private:
      size_t    m_length ;
      char     *m_text ;
      unsigned *m_stats ;
      unsigned  m_dummy ;
   public:
      EbMatchStatistics(size_t length, const char *text) ;
      ~EbMatchStatistics() ;

      size_t length() const { return m_length ; }
      unsigned getCount(size_t start, size_t length) const ;
      void incrCount(size_t start, size_t length, size_t incr) ;
      unsigned &count(size_t start, size_t length) ;
      bool covered(size_t start, size_t length) const ;
      const char *text() const { return m_text ; }
   } ;

//----------------------------------------------------------------------

class EbMatchStatisticsEngine
   {
   private:
      EBMTCorpus *m_corpus ;

   public:
      EbMatchStatisticsEngine(const char *corpusdir) ;
      ~EbMatchStatisticsEngine() ;

      bool OK() const { return m_corpus != 0 ; }
      EbMatchStatistics *getStatistics(FrTextSpans *lattice) ;
      EbMatchStatistics *getStatistics(const char *text) ;
      EbMatchStatistics *getStatistics(const FrList *words) ;
   } ;


#endif /* !__EBSTATS_H_INCLUDED */

// end of file ebstats.h //
