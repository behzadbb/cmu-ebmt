/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebgaps.cpp	functions for handling gapped matches		*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 2007,2009 Ralf Brown					*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "ebmt.h"
#include "ebglobal.h"

/************************************************************************/
/*	Manifest constants for this module				*/
/************************************************************************/

#define CACHE_SIZE 8009

/************************************************************************/
/*	Types local to this module					*/
/************************************************************************/

class EbGappedMatchList
   {
   private:
      static FrAllocator allocator ;
      EbGappedMatchList *m_next ;
      EbGappedMatchList *m_next_by_use ;
      EbGappedMatchList *m_prev_by_use ;
      FrBWTLocation m_before ;		// pointer to word prior to the gap
      FrBWTLocation m_after ;		// pointer to word following the gap
      FrBWTLocationList *m_occurrences ;// list of all matches
   public:
      void *operator new(size_t) { return allocator.allocate() ; }
      void operator delete(void *blk) { allocator.release(blk) ; }
      EbGappedMatchList(FrBWTLocation before, FrBWTLocation after,
			const FrBWTLocationList *occurrences) ;
      ~EbGappedMatchList() ;

      // accessors
      EbGappedMatchList *next() const { return m_next ; }
      EbGappedMatchList *nextRU() const { return m_next_by_use ; }
      EbGappedMatchList *prevRU() const { return m_prev_by_use ; }
      FrBWTLocation before() const { return m_before ; }
      FrBWTLocation after() const { return m_after ; }
      const FrBWTLocationList *occur() const { return m_occurrences ; }

      // manipulators
      void next(EbGappedMatchList *nxt) { m_next = nxt ; }
      void nextRU(EbGappedMatchList *nxt) { m_next_by_use = nxt ; }
      void prevRU(EbGappedMatchList *prv) { m_prev_by_use = prv ; }
   } ;

/************************************************************************/
/*	Global variables for this module				*/
/************************************************************************/

FrAllocator EbGappedMatchList::allocator("EbGappedMatchList",
					 sizeof(EbGappedMatchList)) ;

static EbGappedMatchList *match_cache[CACHE_SIZE] = { 0 } ;
static EbGappedMatchList *cache_LRU_head = 0 ;
static EbGappedMatchList *cache_LRU_tail = 0 ;
static size_t cache_entries = 0 ;

/************************************************************************/
/*	Methods for class EbGappedMatchList				*/
/************************************************************************/

EbGappedMatchList::EbGappedMatchList(FrBWTLocation before,
				     FrBWTLocation after,
				     const FrBWTLocationList *occur)
{
   next(0) ;
   nextRU(0) ;
   prevRU(0) ;
   m_before = before ;
   m_after = after ;
   m_occurrences = occur ? new FrBWTLocationList(*occur) : 0 ;
   return ;
}

//----------------------------------------------------------------------

EbGappedMatchList::~EbGappedMatchList()
{
   delete m_occurrences ;
   m_occurrences = 0 ;
   return ;
}

/************************************************************************/
/*	Helper functions						*/
/************************************************************************/

static size_t rotate_left(size_t val, size_t count)
{
#define bits (sizeof(size_t) * CHAR_BIT)
   return (val << count) | (val >> (bits - count)) ;
}

//----------------------------------------------------------------------

static size_t hash_index(FrBWTLocation before, FrBWTLocation after)
{
   size_t val = (before.first() ^
		 rotate_left(before.pastEnd(),5) ^
		 rotate_left(after.first(),10) ^
		 rotate_left(after.pastEnd(),15)) ;
   return val % CACHE_SIZE ;
}

//----------------------------------------------------------------------

static bool same_match(const EbGappedMatchList *item,
			 FrBWTLocation before,
			 FrBWTLocation after)
{
   return (item->before().first() == before.first() &&
	   item->before().pastEnd() == before.pastEnd() &&
	   item->after().first() == after.first() &&
	   item->after().pastEnd() == after.pastEnd()) ;
}

//----------------------------------------------------------------------

static size_t hash_index(EbGappedMatchList *item)
{
   return item ? hash_index(item->before(),item->after()) : 0 ;
}

//----------------------------------------------------------------------

static EbGappedMatchList *pop_LRU_head()
{
   EbGappedMatchList *old_head = cache_LRU_head ;
   cache_LRU_head = cache_LRU_head->nextRU() ;
   old_head->nextRU(0) ;
   if (cache_LRU_head)
      cache_LRU_head->prevRU(0) ;
   else
      cache_LRU_tail = 0 ;
   return old_head ;
}

//----------------------------------------------------------------------

static void trim_cache()
{
   // trim out the least-recently used entry if the cache is already full
   while (cache_entries >= 2*CACHE_SIZE)
      {
      EbGappedMatchList *discard = pop_LRU_head() ;
      // remove from hash table
      size_t idx = hash_index(discard) ;
      EbGappedMatchList *prev = 0 ;
      for (EbGappedMatchList *items = match_cache[idx] ;
	   items ;
	   items = items->next())
	 {
	 if (items == discard)
	    {
	    if (prev)
	       prev->next(items->next()) ;
	    else
	       match_cache[idx] = items->next() ;
	    break ;
	    }
	 else
	    prev = items ;
	 }
      delete discard ;
      cache_entries-- ;
      }
   return ;
}

//----------------------------------------------------------------------

static void move_to_tail(EbGappedMatchList *element)
{
   if (element && element != cache_LRU_tail)
      {
      if (element == cache_LRU_head)
	 (void)pop_LRU_head() ;
      else
	 {
	 // chop the element out of the list
	 EbGappedMatchList *prev = element->prevRU() ;
	 EbGappedMatchList *next = element->nextRU() ;
         if (prev)
	    prev->nextRU(next) ;
	 if (next)
	    next->prevRU(prev) ;
	 }
      cache_LRU_tail->nextRU(element) ;
      element->prevRU(cache_LRU_tail) ;
      element->nextRU(0) ;
      cache_LRU_tail = element ;
      }
   return ;
}

/************************************************************************/
/*	Procedural Interface						*/
/************************************************************************/

bool EbCacheGappedMatch(FrBWTLocation before, FrBWTLocation after,
			  const FrBWTLocationList *occur)
{
   EbGappedMatchList *item = new EbGappedMatchList(before,after,occur) ;
   if (!item)
      return false ;
   trim_cache() ;
   // insert item at tail of LRU list (since it's the most-recently used)
   if (cache_LRU_tail)
      {
      cache_LRU_tail->nextRU(item) ;
      item->prevRU(cache_LRU_tail) ;
      cache_LRU_tail = item ;
      }
   else
      cache_LRU_head = cache_LRU_tail = item ;
   // add the item to the hash table
   size_t idx = hash_index(item) ;
   item->next(match_cache[idx]) ;
   match_cache[idx] = item ;
   cache_entries++ ;
   return true ; 
}

//----------------------------------------------------------------------

FrBWTLocationList *EbCachedGappedMatch(FrBWTLocation before,
				       FrBWTLocation after)
{
   size_t idx = hash_index(before,after) ;
   for (EbGappedMatchList *items = match_cache[idx] ;
	items ;
	items = items->next())
      {
      if (same_match(items,before,after))
	 {
	 move_to_tail(items) ;
	 return new FrBWTLocationList(*items->occur()) ;
	 }
      }
   return 0 ;
}

//----------------------------------------------------------------------

bool EbClearGappedMatchCache()
{
   for (size_t i = 0 ; i < CACHE_SIZE ; i++)
      {
      while (match_cache[i])
	 {
	 EbGappedMatchList *next = match_cache[i]->next() ;
	 delete match_cache[i] ;
	 match_cache[i] = next ;
	 }
      }
   cache_LRU_head = cache_LRU_tail = 0 ;
   return false ;
}

// end of file ebgaps.C //
