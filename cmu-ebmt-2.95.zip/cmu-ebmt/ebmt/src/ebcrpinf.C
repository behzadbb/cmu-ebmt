/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.94							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebcrpinf.cpp	class EbCorpusMetaInfo				*/
/*  LastEdit: 21mar10							*/
/*									*/
/*  (c) Copyright 2003,2004,2005,2006,2007,2008,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#if defined(__GNUC__)
#  pragma implementation "ebcrpinf.h"
#endif

#include "ebbitext.h"
#include "ebcrpinf.h"
#include "ebutil.h"
#include "ebglobal.h"

#ifdef FrSTRICT_CPLUSPLUS
#  include <cmath>
#else
#  include <math.h>
#endif

/************************************************************************/
/************************************************************************/

typedef unsigned char SHORTbuffer[2] ;

#define PHRASE_SCORE_ZERO 0
#define MANTISSA_BITS 7
#define MANTISSA_MASK 0x007F
#define EXPONENT_BITS 9
#define EXPONENT_MASK 0xFF80
#define MANTISSA_SCALE ((double)(1 << MANTISSA_BITS))
#define EXPONENT_MAX (EXPONENT_MASK >> MANTISSA_BITS)

#define USERSCORE_LIMIT 1024.0
#define USERSCORE_SCALE ((1<<31) / USERSCORE_LIMIT)

struct EbCorpMorphParser
   {
      const char *name ;
      size_t bits ;
   } ;

/************************************************************************/
/*	Global Data for this module					*/
/************************************************************************/

static EbCorpMorphParser names_pos[] =
   {
      { "UNKNOWN",	EbCORPUS_POS 		},
      { "N",		EbCORPUS_POS_NOUN 	},
      { "NN",		EbCORPUS_POS_NOUN 	},
      { "NOUN",		EbCORPUS_POS_NOUN 	},
      { "V",		EbCORPUS_POS_VERB 	},
      { "VB",		EbCORPUS_POS_VERB 	},
      { "VRB",		EbCORPUS_POS_VERB 	},
      { "VERB",		EbCORPUS_POS_VERB 	},
      { "J",		EbCORPUS_POS_ADJ 	},
      { "ADJ",		EbCORPUS_POS_ADJ 	},
      { "ADJECTIVE",	EbCORPUS_POS_ADJ 	},
      { "A",		EbCORPUS_POS_ADV 	},
      { "ADV",		EbCORPUS_POS_ADV 	},
      { "ADVERB",	EbCORPUS_POS_ADJ 	},
      { "DT",		EbCORPUS_POS_DET 	},
      { "DET",		EbCORPUS_POS_DET 	},
      { "DETERMINER",	EbCORPUS_POS_DET 	},
      { "ART",		EbCORPUS_POS_DET 	},
      { "ARTICLE",	EbCORPUS_POS_DET 	},
      { "PP",		EbCORPUS_POS_PREP 	},
      { "PREP",		EbCORPUS_POS_PREP 	},
      { "PREPOS",	EbCORPUS_POS_PREP 	},
      { "PREPOSITION",	EbCORPUS_POS_PREP 	},
      { "POST",		EbCORPUS_POS_POST 	},
      { "POSTPOS",	EbCORPUS_POS_POST 	},
      { "POSTPOSITION",	EbCORPUS_POS_POST 	},
      { "CONJ",		EbCORPUS_POS_CONJ 	},
      { "CONJUNC",	EbCORPUS_POS_CONJ 	},
      { "CONJUNCT",	EbCORPUS_POS_CONJ 	},
      { "CONJUNCTION",	EbCORPUS_POS_CONJ 	},
      { 0,		0			},
   } ;

static EbCorpMorphParser names_number[] =
   {
      { "UNKNOWN",	EbCORPUS_NUM 		},
      { "S",		EbCORPUS_NUM_SINGULAR 	},
      { "SG",		EbCORPUS_NUM_SINGULAR 	},
      { "SING",		EbCORPUS_NUM_SINGULAR 	},
      { "SINGULAR",	EbCORPUS_NUM_SINGULAR 	},
      { "P",		EbCORPUS_NUM_PLURAL 	},
      { "PL",		EbCORPUS_NUM_PLURAL 	},
      { "PLU",		EbCORPUS_NUM_PLURAL 	},
      { "PLUR",		EbCORPUS_NUM_PLURAL 	},
      { "PLURAL",	EbCORPUS_NUM_PLURAL 	},
      { "D",		EbCORPUS_NUM_DUAL 	},
      { "DU",		EbCORPUS_NUM_DUAL 	},
      { "DUAL",		EbCORPUS_NUM_DUAL 	},
      { "PAU",		EbCORPUS_NUM_PAUCAL 	},
      { "PAUC",		EbCORPUS_NUM_PAUCAL 	},
      { "PAUCAL",	EbCORPUS_NUM_PAUCAL 	},
      { 0,		0			},
   } ;

static EbCorpMorphParser names_person[] =
   {
      { "UNKNOWN",	EbCORPUS_PERS 		},
      { "1",		EbCORPUS_PERS_FIRST	},
      { "1ST",		EbCORPUS_PERS_FIRST	},
      { "FIRST",	EbCORPUS_PERS_FIRST	},
      { "2",		EbCORPUS_PERS_SECOND	},
      { "2ND",		EbCORPUS_PERS_SECOND	},
      { "SECOND",	EbCORPUS_PERS_SECOND	},
      { "3",		EbCORPUS_PERS_THIRD	},
      { "3RD",		EbCORPUS_PERS_THIRD	},
      { "THIRD",	EbCORPUS_PERS_THIRD	},
      { "4",		EbCORPUS_PERS_FOURTH	},
      { "4TH",		EbCORPUS_PERS_FOURTH	},
      { "FOURTH",	EbCORPUS_PERS_FOURTH	},
      { 0,		0			},
   } ;

static EbCorpMorphParser names_gender[] =
   {
      { "UNKNOWN",	EbCORPUS_GENDER		},
      { "M",		EbCORPUS_GENDER_MASC 	},
      { "MASC",		EbCORPUS_GENDER_MASC 	},
      { "MASCULINE",	EbCORPUS_GENDER_MASC 	},
      { "MALE",		EbCORPUS_GENDER_MASC 	},
      { "F",		EbCORPUS_GENDER_FEM 	},
      { "FEM",		EbCORPUS_GENDER_FEM 	},
      { "FEMIN",	EbCORPUS_GENDER_FEM 	},
      { "FEMININE",	EbCORPUS_GENDER_FEM 	},
      { "FEMALE",	EbCORPUS_GENDER_FEM 	},
      { "N",		EbCORPUS_GENDER_NEUT 	},
      { "NEUT",		EbCORPUS_GENDER_NEUT 	},
      { "NEUTER",	EbCORPUS_GENDER_NEUT 	},
      { 0,		0			},
   } ;

static EbCorpMorphParser names_aspect[] =
   {
      { "UNKNOWN",	EbCORPUS_ASPECT		},
      { "BEG",		EbCORPUS_ASPECT_BEGIN 	},
      { "BEGIN",	EbCORPUS_ASPECT_BEGIN 	},
      { "PROG",		EbCORPUS_ASPECT_PROG 	},
      { "PROGRESS",	EbCORPUS_ASPECT_PROG 	},
      { "PROGRESSIVE",	EbCORPUS_ASPECT_PROG 	},
      { "PROGRESSING",	EbCORPUS_ASPECT_PROG 	},
      { "END",		EbCORPUS_ASPECT_END 	},
      { "CONT",		EbCORPUS_ASPECT_CONT 	},
      { "CONTINUE",	EbCORPUS_ASPECT_CONT 	},
      { "CONTINUAL",	EbCORPUS_ASPECT_CONT 	},
      { "CONTINUOUS",	EbCORPUS_ASPECT_CONT 	},
      { "CONTINUING",	EbCORPUS_ASPECT_CONT 	},
      { "RECUR",	EbCORPUS_ASPECT_RECUR 	},
      { "RECURRING",	EbCORPUS_ASPECT_RECUR 	},
      { 0,		0			},
   } ;

/************************************************************************/
/*	Helper Functions						*/
/************************************************************************/

static size_t make_phrase_score(double score)
{
   // first, limit value to the valid range
   if (score > 1.99)
      score = 1.99 ;
   else if (score <= 0.0)
      return PHRASE_SCORE_ZERO ;	// shiftcount=0&&mantissa=0 means 0.0
   size_t shifts = 0 ;
   // now perform a rough shifting to get near the desired range
   score *= MANTISSA_SCALE ;
   while (score < 1.0 && shifts+MANTISSA_BITS <= EXPONENT_MAX)
      {
      score *= MANTISSA_SCALE ;
      shifts += MANTISSA_BITS ;
      }
   // now a finer shifting; we desire a value between 256 and 512 so that
   //   we can omit the high bit from the stored value (implicit 1)
   while (score < MANTISSA_SCALE && shifts < EXPONENT_MAX)
      {
      score *= 2.0 ;
      shifts++ ;
      }
   size_t mantissa = ((size_t)(score + 0.5)) ;
   return ((EXPONENT_MAX-shifts)<<MANTISSA_BITS)|(mantissa&MANTISSA_MASK) ;
}

//----------------------------------------------------------------------

static double eval_phrase_score(size_t stored)
{
   if (stored == PHRASE_SCORE_ZERO)
      return 0.0 ;
   size_t shifts = EXPONENT_MAX - ((stored&EXPONENT_MASK)>>MANTISSA_BITS) ;
   size_t mantissa = stored & MANTISSA_MASK ;
   if (shifts < EXPONENT_MAX)
      mantissa |= (1 << MANTISSA_BITS) ;	// put back the implicit 1
   double divisor = MANTISSA_SCALE ;
   while (shifts > 32)
      {
      divisor *= (65536.0 * 65536.0) ;
      shifts -= 32 ;
      }
   if (shifts >= 16)
      {
      divisor *= 65536.0 ;
      shifts -= 16 ;
      }
   if (shifts >= 8)
      {
      divisor *= 256.0 ;
      shifts -= 8 ;
      }
   if (shifts >= 4)
      {
      divisor *= 16.0 ;
      shifts -= 4 ;
      }
   if (shifts >= 2)
      {
      divisor *= 4.0 ;
      shifts -= 2 ;
      }
   if (shifts >= 1)
      {
      divisor *= 2.0 ;
      }
   return mantissa / divisor ;
}

//----------------------------------------------------------------------

int32_t pack_user_score(double uscore)
{
   if (uscore > USERSCORE_LIMIT)
      uscore = USERSCORE_LIMIT ;
   else if (uscore < -USERSCORE_LIMIT)
      uscore = -USERSCORE_LIMIT ;
   return (int32_t)(uscore * USERSCORE_SCALE) ;
}

//----------------------------------------------------------------------

double unpack_user_score(int32_t score)
{
   return score / USERSCORE_SCALE ;
}

//----------------------------------------------------------------------

static FrList *validate_phrase_tag(const FrList *tag, FrList *phrases)
{
   for ( ; tag ; tag = tag->rest())
      {
      FrList *phrase = (FrList*)tag->first() ;
      if (phrase && phrase->consp() && phrase->first() &&
	  phrase->first()->consp())
	 {
	 const FrObject *second = phrase->second() ;
	 const FrObject *third = phrase->third() ;
	 if (second && third && second->consp() && third->numberp() &&
	     third->floatValue() > 0.0 &&
	     make_phrase_score(third->floatValue())!=PHRASE_SCORE_ZERO)
	    pushlist(phrase->deepcopy(),phrases) ;
	 }
      }
   return phrases ;
}

//----------------------------------------------------------------------

static void extract_phrase_extent(const FrList *phr,
				  size_t &start, size_t &end)
{
   size_t min = ~0 ;
   size_t max = 0 ;
   for ( ; phr ; phr = phr->rest())
      {
      FrObject *pos = phr->first() ;
      if (pos && pos->numberp())
	 {
	 size_t position = pos->intValue() ;
	 if (position < min)
	    min = position ;
	 if (position > max)
	    max = position ;
	 }
      }
   if (min <= max)
      {
      if (min > 0 && max > 0)
	 {
	 // adjust from 1-origin in PHRASE tag to 0-origin used in indexed
	 //   corpus
	 min-- ;
	 max-- ;
	 }
      start = min ;
      end = max ;
      }
   else
      {
      start = 0 ;
      end = 0 ;
      }
   return ;
}

//----------------------------------------------------------------------

static int compare_phrases(const FrObject *o1, const FrObject *o2)
{
   const FrList *l1 = (FrList*)o1 ;
   const FrList *l2 = (FrList*)o2 ;
   size_t start1, end1 ;
   size_t start2, end2 ;
   extract_phrase_extent((FrList*)l1->first(),start1,end1) ;
   extract_phrase_extent((FrList*)l2->first(),start2,end2) ;
   if (start1 < start2)
      return -1 ;
   else if (start1 > start2)
      return +1 ;
   // same starting position, so check on ending position; sort such that
   //   longer phrases come first
   if (end1 > end2)
      return -1 ;
   else if (end1 < end2)
      return +1 ;
   // if the source phrase is the same, sort by decreasing score
   const FrObject *fr1 = l1->third() ;
   const FrObject *fr2 = l2->third() ;
   double freq1 = fr1 && fr1->numberp() ? fr1->floatValue() : -9999.9 ;
   double freq2 = fr2 && fr2->numberp() ? fr2->floatValue() : -9999.9 ;
   if (freq1 > freq2)
      return -1 ;
   else if (freq2 < freq1)
      return +1 ;
   return 0 ;
}

//----------------------------------------------------------------------

static void parse_tag(const FrList *items, const EbCorpMorphParser *table,
		      FrBYTE &flags)
{
   for ( ; items ; items = items->rest())
      {
      const char *item = FrPrintableName(items->first()) ;
      if (item)
	 {
	 bool invert = false ;
	 if (*item == '-' || *item == '!')
	    {
	    invert = true ;
	    item++ ;
	    }
	 for (const EbCorpMorphParser *t = table ; t->name ; t++)
	    {
	    if (Fr_stricmp(item,t->name,lowercase_table) == 0)
	       {
	       if (invert)
		  flags &= !t->bits ;
	       else
		  flags |= (FrBYTE)t->bits ;
	       break ;
	       }
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

static FrList *unparse_pos(size_t pos)
{
   FrList *unparsed = 0 ;
   if (EbCORPUS_UNKNOWN(pos,EbCORPUS_POS))
      unparsed = new FrList(makeSymbol("UNKNOWN")) ;
   else
      {
      if (pos & EbCORPUS_POS_CONJ)
	 pushlist(makeSymbol("CONJ"),unparsed) ;
      if (pos & EbCORPUS_POS_DET)
	 pushlist(makeSymbol("DET"),unparsed) ;
      if (pos & EbCORPUS_POS_POST)
	 pushlist(makeSymbol("POST"),unparsed) ;
      if (pos & EbCORPUS_POS_PREP)
	 pushlist(makeSymbol("PREP"),unparsed) ;
      if (pos & EbCORPUS_POS_ADV)
	 pushlist(makeSymbol("ADV"),unparsed) ;
      if (pos & EbCORPUS_POS_ADJ)
	 pushlist(makeSymbol("ADJ"),unparsed) ;
      if (pos & EbCORPUS_POS_VERB)
	 pushlist(makeSymbol("V"),unparsed) ;
      if (pos & EbCORPUS_POS_NOUN)
	 pushlist(makeSymbol("N"),unparsed) ;
      }
   if (!unparsed)
      unparsed = new FrList(makeSymbol("UNSPECIFIED")) ;
   pushlist(symPOS,unparsed) ;
   return unparsed ;
}

//----------------------------------------------------------------------

static FrList *unparse_person(size_t person)
{
   FrList *unparsed = 0 ;
   if (EbCORPUS_UNKNOWN(person,EbCORPUS_PERS))
      unparsed = new FrList(makeSymbol("UNKNOWN")) ;
   else
      {
      if (person & EbCORPUS_PERS_FOURTH)
	 pushlist(makeSymbol("4"),unparsed) ;
      if (person & EbCORPUS_PERS_THIRD)
	 pushlist(makeSymbol("3"),unparsed) ;
      if (person & EbCORPUS_PERS_SECOND)
	 pushlist(makeSymbol("2"),unparsed) ;
      if (person & EbCORPUS_PERS_FIRST)
	 pushlist(makeSymbol("1"),unparsed) ;
      }
   if (!unparsed)
      unparsed = new FrList(makeSymbol("UNSPECIFIED")) ;
   pushlist(symPERSON,unparsed) ;
   return unparsed ;
}

//----------------------------------------------------------------------

static FrList *unparse_number(size_t number)
{
   FrList *unparsed = 0 ;
   if (EbCORPUS_UNKNOWN(number,EbCORPUS_NUM))
      unparsed = new FrList(makeSymbol("UNKNOWN")) ;
   else
      {
      if (number & EbCORPUS_NUM_PAUCAL)
	 pushlist(makeSymbol("PAUCAL"),unparsed) ;
      if (number & EbCORPUS_NUM_DUAL)
	 pushlist(makeSymbol("DUAL"),unparsed) ;
      if (number & EbCORPUS_NUM_PLURAL)
	 pushlist(makeSymbol("PL"),unparsed) ;
      if (number & EbCORPUS_NUM_SINGULAR)
	 pushlist(makeSymbol("SG"),unparsed) ;
      }
   if (!unparsed)
      unparsed = new FrList(makeSymbol("UNSPECIFIED")) ;
   pushlist(symNUMBER,unparsed) ;
   return unparsed ;
}

//----------------------------------------------------------------------

static FrList *unparse_gender(size_t gender)
{
   FrList *unparsed = 0 ;
   if (EbCORPUS_UNKNOWN(gender,EbCORPUS_GENDER))
      unparsed = new FrList(makeSymbol("UNKNOWN")) ;
   else
      {
      if (gender & EbCORPUS_GENDER_NEUT)
	 pushlist(makeSymbol("N"),unparsed) ;
      if (gender & EbCORPUS_GENDER_FEM)
	 pushlist(makeSymbol("F"),unparsed) ;
      if (gender & EbCORPUS_GENDER_MASC)
	 pushlist(makeSymbol("M"),unparsed) ;
      }
   if (!unparsed)
      unparsed = new FrList(makeSymbol("UNSPECIFIED")) ;
   pushlist(symGENDER,unparsed) ;
   return unparsed ;
}

//----------------------------------------------------------------------

static FrList *unparse_aspect(size_t aspect)
{
   FrList *unparsed = 0 ;
   if (EbCORPUS_UNKNOWN(aspect,EbCORPUS_ASPECT))
      unparsed = new FrList(makeSymbol("UNKNOWN")) ;
   else
      {
      if (aspect & EbCORPUS_ASPECT_RECUR)
	 pushlist(makeSymbol("RECUR"),unparsed) ;
      if (aspect & EbCORPUS_ASPECT_CONT)
	 pushlist(makeSymbol("CONT"),unparsed) ;
      if (aspect & EbCORPUS_ASPECT_END)
	 pushlist(makeSymbol("END"),unparsed) ;
      if (aspect & EbCORPUS_ASPECT_PROG)
	 pushlist(makeSymbol("PROG"),unparsed) ;
      if (aspect & EbCORPUS_ASPECT_BEGIN)
	 pushlist(makeSymbol("BEGIN"),unparsed) ;
      }
   if (!unparsed)
      unparsed = new FrList(makeSymbol("UNSPECIFIED")) ;
   pushlist(symASPECT,unparsed) ;
   return unparsed ;
}

/************************************************************************/
/*	Methods for class EbCorpusMorphology				*/
/************************************************************************/

EbCorpusMorphology::EbCorpusMorphology()
{
   m_other = 0 ;
   m_pos = 0 ;
   m_pers_num = 0 ;
   m_gend_asp = 0 ;
   return ;
}

//----------------------------------------------------------------------

EbCorpusMorphology::EbCorpusMorphology(const FrList *tags)
{
   m_other = 0 ;
   init(tags) ;
   return ;
}

//----------------------------------------------------------------------

EbCorpusMorphology::EbCorpusMorphology(const FrStruct *tagstruct)
{
   m_other = 0 ;
   init(tagstruct) ;
   return ; 
}

//----------------------------------------------------------------------

EbCorpusMorphology &EbCorpusMorphology::operator = (const EbCorpusMorphology &old)
{
   m_pos = old.m_pos ;
   m_pers_num = old.m_pers_num ;
   m_gend_asp = old.m_gend_asp ;
   m_other = old.m_other ? (FrList*)old.m_other->deepcopy() : 0 ;
   return *this ;
}

//----------------------------------------------------------------------

void EbCorpusMorphology::setOther(const FrList *other)
{
   free_object(m_other) ;
   m_other = other ? (FrList*)other->deepcopy() : 0 ;
   return ;
}

//----------------------------------------------------------------------

void EbCorpusMorphology::init(const FrList *tags)
{
   m_pos = 0 ;
   m_pers_num = 0 ;
   m_gend_asp = 0 ;
   for ( ; tags ; tags = tags->rest())
      {
      const FrList *data = (FrList*)tags->first() ;
      if (!data || !data->consp())
	 continue ;
      const char *tag = FrPrintableName(data->first()) ;
      if (!tag)
	 continue ;
      if (Fr_stricmp(tag,"POS") == 0)
	 parse_tag(data->rest(),names_pos,m_pos) ;
      else if (Fr_strnicmp(tag,"PERSON",3) == 0)
	 parse_tag(data->rest(),names_person,m_pers_num) ;
      else if (Fr_strnicmp(tag,"NUMBER",3) == 0)
	 parse_tag(data->rest(),names_number,m_pers_num) ;
      else if (Fr_strnicmp(tag,"GENDER",3) == 0)
	 parse_tag(data->rest(),names_gender,m_gend_asp) ;
      else if (Fr_strnicmp(tag,"ASPECT",3) == 0)
	 parse_tag(data->rest(),names_aspect,m_gend_asp) ;
      else
	 pushlist(data->deepcopy(),m_other) ;
      }
   return ;
}

//----------------------------------------------------------------------

void EbCorpusMorphology::init(const FrStruct *tagstruct)
{
   FrList *taglist = 0 ;
   if (tagstruct)
      {
      FrList *keys = tagstruct->fieldNames() ;
      while (keys)
	 {
	 FrSymbol *key = (FrSymbol*)poplist(keys) ;
	 FrList *data = (FrList*)tagstruct->get(key) ;
	 if (data && data->consp())
	    {
	    data = (FrList*)data->deepcopy() ;
	    pushlist(key,data) ;
	    pushlist(data,taglist) ;
	    }
	 }
      }
   init(taglist) ;
   free_object(taglist) ;
   return ;
}

//----------------------------------------------------------------------

const FrList *EbCorpusMorphology::other(FrSymbol *tag) const
{
   FrList *data = (FrList*)m_other->assoc(tag) ;
   if (data)
      return data->rest() ;
   // if we get here, the desired tag was not found
   return 0 ;
}

//----------------------------------------------------------------------

FrList *EbCorpusMorphology::get(FrSymbol *tag) const
{
   FrList *data ;
   if (tag == symPOS)
      data = unparse_pos(partOfSpeech()) ;
   else if (tag == symNUMBER)
      data = unparse_number(number()) ;
   else if (tag == symPERSON)
      data = unparse_person(person()) ;
   else if (tag == symGENDER)
      data = unparse_gender(gender()) ;
   else if (tag == symASPECT)
      data = unparse_aspect(aspect()) ;
   else
      {
      data = (FrList*)m_other->assoc(tag) ;
      if (data) data = (FrList*)data->deepcopy() ;
      }
   poplist(data) ;			// get rid of the tag on the list
   return data ;
}

//----------------------------------------------------------------------

FrList *EbCorpusMorphology::morphology() const
{
   FrList *m = m_other ? (FrList*)m_other->deepcopy() : 0 ;
   if (aspect())
      pushlist(unparse_aspect(aspect()),m) ;
   if (gender())
      pushlist(unparse_gender(gender()),m) ;
   if (number())
      pushlist(unparse_number(number()),m) ;
   if (person())
      pushlist(unparse_person(person()),m) ;
   if (partOfSpeech())
      pushlist(unparse_pos(partOfSpeech()),m) ;
   return m ;
}

/************************************************************************/
/*	Methods for class EbCorpusMetaInfo				*/
/************************************************************************/

EbCorpusMetaInfo::EbCorpusMetaInfo(const EbCorpusMetaInfo *original)
{
   if (original)
      {
      m_unparsed_morph = 0 ; 
      m_origin = FrDupString(original->m_origin) ;
      m_bitext = original->m_bitext ? new BiTextMap(original->m_bitext) : 0 ;
      m_wordalign = (original->wordAlignments()
		     ? (FrList*)original->wordAlignments()->deepcopy() : 0) ;
      m_sourceinfo = (original->m_sourceinfo
		      ? (FrList*)original->m_sourceinfo->deepcopy() : 0) ;
      m_targetinfo = (original->m_targetinfo
		      ? (FrList*)original->m_targetinfo->deepcopy() : 0) ;
      m_numuserscores = original->m_numuserscores ;
      if (m_numuserscores && original->m_userscores)
	 {
	 m_userscores = FrNewN(double,m_numuserscores) ;
	 if (m_userscores)
	    {
	    memcpy(m_userscores,original->m_userscores,
		   m_numuserscores * sizeof(m_userscores[0])) ;
	    }
	 else
	    m_numuserscores = 0 ;
	 }
      else
	 {
	 m_numuserscores = 0 ;
	 m_userscores = 0 ;
	 }
      m_phrasemap = 0 ;
      if (original->m_phrasecount && original->m_phrasemap)
	 {
	 size_t entrysize = phraseMapEntrySize() ;
	 m_phrasecount = original->m_phrasecount ;
	 m_phrasemap = FrNewN(char,entrysize * m_phrasecount) ;
	 if (m_phrasemap)
	    memcpy(m_phrasemap,original->m_phrasemap,
		   entrysize * m_phrasecount) ;
	 else
	    m_phrasecount = 0 ;
	 }
      m_phrasemap2 = 0 ;
      if (original->m_phrasecount && original->m_phrasemap2)
	 {
	 size_t entrysize = phraseMap2EntrySize() ;
	 m_phrasecount = original->m_phrasecount ;
	 m_phrasemap2 = FrNewN(char,entrysize * m_phrasecount) ;
	 if (m_phrasemap2)
	    memcpy(m_phrasemap2,original->m_phrasemap2,
		   entrysize * m_phrasecount) ;
	 else
	    m_phrasecount = 0 ;
	 }
      m_targetpos = 0 ; //FIXME
      m_token = original->m_token ;
      m_alignscore = original->m_alignscore ;
      m_score = original->m_score ;
      m_frequency = original->m_frequency ;
      fields = original->fields ;
      m_phrases = 
	 original->m_phrases ? (FrList*)original->m_phrases->deepcopy() : 0 ;
      m_lcontext =
	 original->m_lcontext ? (FrList*)original->m_lcontext->deepcopy() : 0 ;
      m_rcontext =
	 original->m_rcontext ? (FrList*)original->m_rcontext->deepcopy() : 0 ;
      m_sourcewords = original->m_sourcewords ;
      m_morph = new EbCorpusMorphology[m_sourcewords] ;
      if (m_morph)
	 {
	 for (size_t i = 0 ; i < m_sourcewords ; i++)
	    m_morph[i] = original->m_morph[i] ;
	 }
      else
	 m_sourcewords = 0 ;
	 m_chunkbounds = 0 ;
	 m_chunklabels = 0 ;
      if (original->m_chunkbounds)
	 {
	 size_t count = original->numChunkBounds() ;
	 m_chunkbounds = FrNewC(uint16_t,count+1) ;
	 m_chunklabels = FrNewC(FrSymbol*,count+1) ;
	 if (m_chunkbounds && m_chunklabels)
	    {
	    memcpy(m_chunkbounds,original->m_chunkbounds,
		   (count+1) * sizeof(m_chunkbounds[0])) ;
	    if (original->m_chunklabels)
	       memcpy(m_chunklabels,original->m_chunklabels,
		      (count+1) * sizeof(m_chunklabels[0])) ;
	    }
	 }
      m_trgspans =
	 original->m_trgspans ? (FrList*)original->m_trgspans->deepcopy() : 0 ;
      }
   else
      init() ;
   return ;
}

//----------------------------------------------------------------------

EbCorpusMetaInfo::EbCorpusMetaInfo(const char *tags, size_t src_words,
				   bool report_errors)
{
   init(src_words) ;
   parse(tags,report_errors) ;
   return ;
}

//----------------------------------------------------------------------

void EbCorpusMetaInfo::init(size_t src_words)
{ 
   m_alignscore = 1.0 ;		// full example has perfect alignment
   m_score = 1.0 ;		// full example has perfect overall score
   m_userscores = 0 ;
   m_numuserscores = 0 ;
   m_token = 0 ;
   m_frequency = 1 ;	// by default, one occurrence
   m_phrases = 0 ;
   m_phrasemap = 0 ;
   m_phrasemap2 = 0 ;
   m_bitext = 0 ;
   m_sourceinfo = 0 ;
   m_targetinfo = 0 ;
   m_targetpos = 0 ;
   m_wordalign = 0 ;
   m_origin = 0 ;
   m_lcontext = m_rcontext = 0 ;
   m_morph = 0 ;
   m_chunkbounds = 0 ;
   m_chunklabels = 0 ;
   m_trgspans = 0 ;
   m_unparsed_morph = 0 ; 
   m_sourcewords = src_words ;
   if (src_words)
      m_morph = new EbCorpusMorphology[src_words] ;
   m_phrasecount = 0 ;
   fields = 0 ; 
   return ;
}

//----------------------------------------------------------------------

EbCorpusMetaInfo::~EbCorpusMetaInfo()
{
   delete m_bitext ;		m_bitext = 0 ;
   free_object(m_wordalign) ;	m_wordalign = 0 ;
   free_object(m_phrases) ;	m_phrases = 0 ;
   free_object(m_lcontext) ;	m_lcontext = 0 ;
   free_object(m_rcontext) ;	m_rcontext = 0 ;
   free_object(m_sourceinfo) ;	m_sourceinfo = 0 ;
   free_object(m_targetinfo) ;	m_targetinfo = 0 ;
   FrFree(m_phrasemap) ;	m_phrasemap = 0 ;
   FrFree(m_phrasemap2) ;	m_phrasemap2 = 0 ;
   FrFree(m_origin) ;		m_origin = 0 ;
   FrFree(m_userscores) ; 	m_userscores = 0 ;
   FrFree(m_chunkbounds) ;	m_chunkbounds = 0 ;
   FrFree(m_chunklabels) ;	m_chunklabels = 0 ;
   free_object(m_trgspans) ;	m_trgspans = 0 ;
   delete [] m_morph ;		m_morph = 0 ;
   return ;
}

//----------------------------------------------------------------------

EbCorpusMetaInfo &EbCorpusMetaInfo::operator = (const EbCorpusMetaInfo &orig)
{
   m_alignscore = orig.m_alignscore ;
   m_score = orig.m_score ;
   m_token = orig.m_token ;
   m_bitext = orig.m_bitext ? new BiTextMap(orig.m_bitext) : 0 ;
   m_wordalign = (orig.wordAlignments()
		  ? (FrList*)orig.wordAlignments()->deepcopy() : 0) ;
   m_frequency = orig.m_frequency ;
   return *this ;
}

//----------------------------------------------------------------------

static long bound_value(const FrObject *o)
{
   if (o)
      {
      if (o->numberp())
	 return o->intValue() ;
      else if (o->consp() && ((FrList*)o)->first() &&
	       ((FrList*)o)->first()->numberp())
	 return ((FrList*)o)->first()->intValue() ;
      }
   return LONG_MIN ;
}

//----------------------------------------------------------------------

static int compare_bounds(const FrObject *o1, const FrObject *o2)
{
   long bound1 = bound_value(o1) ;
   long bound2 = bound_value(o2) ;
   return (bound1 < bound2) ? -1 : ((bound1 > bound2) ? +1 : 0) ;
}

//----------------------------------------------------------------------

static bool valid_bound(const FrObject *bound)
{
   if (bound)
      {
      // only positive numbers and lists starting with a positive number are
      //   valid boundary specs (the boundary at 0 is always implicit and
      //   never stored)
      if (bound->numberp())
	 return bound->intValue() > 0 ;
      else if (bound->consp())
	 {
	 const FrObject * b = ((FrList*)bound)->first() ;
	 return (b && b->numberp() && b->intValue() > 0) ;
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

void EbCorpusMetaInfo::parseChunkBounds(FrList *bounds)
{
   FrList *filtered = 0 ;
   // remove non-numbers and non-positive numbers from list
   while (bounds)
      {
      FrObject *bound = poplist(bounds) ;
      if (valid_bound(bound))
	 pushlist(bound,filtered) ;
      else
	 free_object(bound) ;
      }
   bounds = filtered->sort(compare_bounds) ;
   size_t count = bounds->simplelistlength() ;
   m_chunkbounds = FrNewC(uint16_t,count+1) ;
   m_chunklabels = FrNewC(FrSymbol*,count+1) ;
   if (m_chunkbounds && m_chunklabels)
      {
      m_chunkbounds[0] = (uint16_t)count ;
      for (size_t i = 1 ; i <= count ; i++)
	 {
	 FrObject *bound = poplist(bounds) ;
	 if (bound)
	    {
	    if (bound->numberp())
	       m_chunkbounds[i] = (uint16_t)bound->intValue() ;
	    else
	       {
	       FrList *b = (FrList*)bound ;
	       m_chunkbounds[i] = (uint16_t)(b->first()->intValue()) ;
	       const char *label = FrPrintableName(b->second()) ;
	       if (label)
		  {
		  m_chunklabels[i-1] = FrSymbolTable::add(label) ;
		  addField(labels_tag) ;
		  }
	       }
	    }
	 }
      addField(bounds_tag) ;
      }
   else
      {
      free_object(bounds) ;
      FrFree(m_chunkbounds) ; m_chunkbounds = 0 ;
      FrFree(m_chunklabels) ; m_chunklabels = 0 ;
      }
   return ;
}

//----------------------------------------------------------------------

bool EbCorpusMetaInfo::parse(const char *tags, bool report_errors)
{
   bool changed = false ;
   if (tags)
      {
      const char *orig_tags = tags ;
      FrSymbol *symBOUNDS = makeSymbol("BOUNDS") ;
      FrSymbol *symCOMMENT = makeSymbol("COMMENT") ;
      FrSymbol *symEXACT = makeSymbol("EXACT") ;
      FrSymbol *symLITERAL = makeSymbol("LITERAL") ;
      FrSymbol *symORIGIN = makeSymbol("ORIGIN") ;
      FrSymbol *symSCORE = makeSymbol("SCORE") ;
      FrSymbol *symSC = makeSymbol("SC") ;
      FrSymbol *symFREQ = makeSymbol("FREQ") ;
      FrSymbol *symPHRASE = makeSymbol("PHRASE") ;
      FrSymbol *symP = makeSymbol("P") ;
      FrSymbol *symLCONTEXT = makeSymbol("LCONTEXT") ;
      FrSymbol *symRCONTEXT = makeSymbol("RCONTEXT") ;
      FrSymbol *symSOURCE = makeSymbol("SOURCE") ;
      FrSymbol *symTARGET = makeSymbol("TARGET") ;
      FrSymbol *symTRGSPANS = makeSymbol("TRGSPANS") ;
#undef symMORPH
      FrSymbol *symMORPH = makeSymbol("MORPH") ;
      do {
         while (*tags && (*tags == ';' || Fr_isspace(*tags)))
	    tags++ ;
	 if (*tags)
	    {
	    const char *prev_tag = tags ;
	    FrObject *obj = string_to_FrObject(tags) ;
	    if (obj && obj->consp())
	       {
	       FrList *item = (FrList*)obj ;
	       FrSymbol *type = (FrSymbol*)item->first() ;
	       if (!type || !type->symbolp())
		  {
		  if (report_errors)
		     FrWarningVA("malformed tag at '%s'",prev_tag) ;
		  continue ;
		  }
	       if (type == symTOKEN)
		  {
		  token(FrCvt2Symbol(item->second(),char_encoding)) ;
		  addField(token_tag) ;
		  changed = true ;
		  }
	       else if (type == symORIGIN)
		  {
		  FrObject *org = item->second() ;
		  if (org && org->stringp())
		     origin(((FrString*)org)->stringValue()) ;
		  else if (report_errors)
		     FrWarningVA("ORIGIN should be a string: %s",prev_tag) ;
		  addField(origin_tag) ;
		  changed = true ;
		  }
	       else if (type == symSCORE)
		  {
		  FrObject *sc = item->second() ;
		  if (sc && sc->numberp())
		     {
		     alignmentScore(sc->floatValue()) ;
		     addField(score_tag) ;
		     changed = true ;
		     }
		  else if (report_errors)
		     FrWarning("SCORE tag without a score!") ;
		  }
	       else if (type == symFREQ)
		  {
		  const FrObject *f1 = item->second() ;
		  const FrObject *f2 = item->third() ;
		  if (!f2)
		     f2 = f1 ;
		  if (f1 && f2 && f1->numberp() && f2->numberp())
		     {
		     frequency(f1->intValue()) ;
		     addField(freq_tag) ;
		     changed = true ;
		     }
		  else if (report_errors)
		     {
		     char *value = item->print() ;
		     FrWarningVA("need two numbers for FREQ tag, but got\n"
				 "\t%s",value) ;
		     FrFree(value) ;
		     }
		  }
	       else if (type == symPOS)
		  {
		  // future expansion, do nothing just yet //
		  addField(pos_tag) ;
		  //changed = true ;
		  }
	       else if (type == symCOMMENT)
		  {
		  // do nothing
		  addField(comment_tag) ;
		  //changed = true ;
		  }
	       else if (type == symALIGN)
		  {
		  // do nothing, handled elsewhere //
		  addField(align_tag) ;
		  //changed = true ;
		  }
	       else if (type == symPHRASE || type == symP)
		  {
		  m_phrases = validate_phrase_tag(item->rest(),m_phrases) ;
		  addField(phrase_tag) ;
		  changed = true ;
		  }
	       else if (type == symMORPH)
		  {
		  FrObject *obj = item->second() ;
		  size_t which = obj ? obj->intValue() : ~0 ;
		  if (which < numSourceWords())
		     {
		     m_morph[which].init(item->nthcdr(2)) ;
		     if (m_morph[which].other())
			addField(morph_tag) ;
		     if (EbCORPUS_SPECIFIED(m_morph[which].partOfSpeech(),
					    EbCORPUS_POS))
			addField(pos_tag) ;
		     if (EbCORPUS_SPECIFIED(m_morph[which].person(),
					    EbCORPUS_PERS))
			addField(person_tag) ;
		     if (EbCORPUS_SPECIFIED(m_morph[which].gender(),
					    EbCORPUS_GENDER))
			addField(gender_tag) ;
		     if (EbCORPUS_SPECIFIED(m_morph[which].number(),
					    EbCORPUS_NUM))
			addField(num_tag) ;
		     if (EbCORPUS_SPECIFIED(m_morph[which].aspect(),
					    EbCORPUS_ASPECT))
			addField(aspect_tag) ;
		     changed = true ;
		     }
		  else
		     {
		     char *text = item->print() ;
		     FrWarningVA("invalid word index: %s",text) ;
		     FrFree(text) ;
		     }
		  }
	       else if (type == symLCONTEXT)
		  {
		  m_lcontext = item->rest() ;
		  if (m_lcontext) m_lcontext = (FrList*)m_lcontext->deepcopy();
		  addField(lcontext_tag) ;
		  changed = true ;
		  }
	       else if (type == symRCONTEXT)
		  {
		  m_rcontext = item->rest() ;
		  if (m_rcontext) m_rcontext = (FrList*)m_rcontext->deepcopy();
		  addField(rcontext_tag) ;
		  changed = true ;
		  }
	       else if (type == symSOURCE)
		  {
		  m_sourceinfo = item->rest() ;
		  if (m_sourceinfo)
		     m_sourceinfo = (FrList*)m_sourceinfo->deepcopy();
		  addField(source_tag) ;
		  changed = true ;
		  }
	       else if (type == symTARGET)
		  {
		  m_targetinfo = item->rest() ;
		  if (m_targetinfo)
		     m_targetinfo = (FrList*)m_targetinfo->deepcopy();
		  addField(target_tag) ;
		  changed = true ;
		  }
	       else if (type == symBOUNDS)
		  {
		  FrList *bounds = item->rest() ;
		  item->replacd(0) ;	// cut off the tail
		  parseChunkBounds(bounds) ;
		  changed = true ;
		  }
	       else if (type == symTRGSPANS)
		  {
		  free_object(m_trgspans) ;
		  m_trgspans = item->rest() ;
		  item->replacd(0) ;    // cut off the tail
		  addField(trgspans_tag) ;
		  changed = true ;
		  }
	       else if (type == symEXACT)
		  {
		  addField(exact_tag) ;
		  changed = true ;
		  }
	       else if (type == symSC)
		  {
		  const FrList *itm = item->rest() ;
		  size_t count = itm->simplelistlength() ;
		  m_numuserscores = 0 ;
		  if (count > 0)
		     {
		     m_userscores = FrNewN(double,count) ;
		     if (m_userscores)
			{
			m_numuserscores = count ;
			for (size_t i = 0 ; i < count ; i++)
			   {
			   const FrObject *sc = itm->first() ;
			   itm = itm->rest() ;
			   if (sc && sc->numberp())
			      m_userscores[i] = sc->floatValue() ;
			   else
			      m_userscores[i] = 0.0 ;
			   }
			addField(userscore_tag) ;
			changed = true ;
			}
		     }
		  }
	       else if (type == symLITERAL)
		  {
		  addField(literal_tag) ;
		  changed = true ;
		  }
	       else if (report_errors)
		  FrWarningVA("unrecognized tag %s -- ignored",
			      type->symbolName()) ;
	       }
	    else if (report_errors)
	       {
	       char *text = obj->print() ;
	       FrWarningVA("invalid tag information '%s' @ %s",orig_tags,text);
	       FrFree(text) ;
	       }
	    free_object(obj) ;
	    }
         } while (*tags) ;
      }
   if (haveField(phrase_tag))
      m_phrases = m_phrases->sort(compare_phrases) ;
   return changed ;
}

//----------------------------------------------------------------------

bool EbCorpusMetaInfo::parse(const FrList *tags)
{
   if (tags)
      {
      if (tags->consp() && tags->first() && tags->first()->consp())
	 {
	 bool success = false ;
	 for ( ; tags ; tags = tags->rest())
	    {
	    if (parse((FrList*)tags->first()))
	       success = true ;
	    }
	 return success ;
	 }
      char *tagstr = tags->print() ;
      bool changed = parse(tagstr,false) ;
      FrFree(tagstr) ;
      return changed ;
      }
   return false ;
}

//----------------------------------------------------------------------
// important note: 'ignore_morphology' must not be set if 'info' will be
//   freed between this call and a call to finishParsingMorphology();
//   in practice, that means the corpus must be memory-mapped

void EbCorpusMetaInfo::parse(const char *info, const char *end,
			     int source_len, int target_len,
			     const FrList *sentence, bool ignore_bitext,
			     bool ignore_morphology)
{
   while (info && info < end)
      {
      unsigned char type = *(unsigned char*)info ;
      if (type < EbCORPUS_EXTRA_TAGS
#if EbCORPUS_EXTRA_BITEXT > 0
	  && type >= EbCORPUS_EXTRA_BITEXT
#endif
	 )
	 {
	 if (ignore_bitext)
	    {
	    info++ ;			// consume the type byte
	    while (*((unsigned char*)info++) != (unsigned char)0xFF &&
		   info < end)
	       ;
	    }
	 else
	    {
	    const char *info_end = end ;
	    bitext(new BiTextMap(info,source_len,target_len,&info_end)) ;
	    info = info_end ;
	    addField(align_tag) ;
	    }
	 continue ;
	 }
      info++ ;
      if (type == EbCORPUS_EXTRA_TAGS_RECURSE)
	 {
	 size_t len = strlen(info) ;
	 token(FrSymbolTable::add(info)) ;
	 addField(EbCorpusMetaInfo::token_tag) ;
	 info += len+1 ;
	 }
      else if (type == EbCORPUS_EXTRA_SCORE)
	 {
	 alignmentScore(FrLoadLong(info) / (double)EbCORPUS_SCORE_SCALE) ;
	 addField(EbCorpusMetaInfo::score_tag) ;
	 info += sizeof(LONGbuffer) ;
	 }
      else if (type == EbCORPUS_EXTRA_FREQ)
	 {
	 uint32_t xlat = FrLoadLong(info) ;
	 uint32_t tot = FrLoadLong(info + sizeof(LONGbuffer)) ;
	 if (xlat > tot)
	    tot = xlat ;
	 frequency(tot) ;
	 addField(EbCorpusMetaInfo::freq_tag) ;
	 info += 2 * sizeof(LONGbuffer) ;
	 }
      else if (type == EbCORPUS_EXTRA_PHRASES)
	 {
	 size_t entrysize = phraseMapEntrySize() ;
	 m_phrasecount = FrLoadShort(info) ;
	 m_phrasemap = FrNewN(char,entrysize*m_phrasecount) ;
	 if (m_phrasemap)
	    {
	    memcpy(m_phrasemap,info+sizeof(SHORTbuffer),
		   entrysize*m_phrasecount) ;
	    addField(EbCorpusMetaInfo::phrase_tag) ;
	    }
	 info += entrysize * m_phrasecount + sizeof(SHORTbuffer) ;
	 }
      else if (type == EbCORPUS_EXTRA_PHRASES2)
	 {
	 size_t entrysize = phraseMap2EntrySize() ;
	 m_phrasecount = FrLoadShort(info) ;
	 m_phrasemap2 = FrNewN(char,entrysize*m_phrasecount) ;
	 if (m_phrasemap2)
	    {
	    memcpy(m_phrasemap2,info+sizeof(SHORTbuffer),
		   entrysize*m_phrasecount) ;
	    addField(EbCorpusMetaInfo::phrase_tag) ;
	    }
	 info += entrysize * m_phrasecount + sizeof(SHORTbuffer) ;
	 }
      else if (type == EbCORPUS_EXTRA_LCONTEXT)
	 {
	 const char *ctxt = info ;
	 info = strchr(info,'\0') + 1 ;	// skip past terminating NUL
	 m_lcontext = (FrList*)string_to_FrObject(ctxt) ;
	 addField(EbCorpusMetaInfo::lcontext_tag) ;
	 }
      else if (type == EbCORPUS_EXTRA_RCONTEXT)
	 {
	 const char *ctxt = info ;
	 info = strchr(info,'\0') + 1 ;	// skip past terminating NUL
	 m_rcontext = (FrList*)string_to_FrObject(ctxt) ;
	 addField(EbCorpusMetaInfo::rcontext_tag) ;
	 }
      else if (type == EbCORPUS_EXTRA_SOURCE)
	 {
	 const char *inf = info ;
	 info = strchr(info,'\0') + 1 ;	// skip past terminating NUL
	 m_sourceinfo = (FrList*)string_to_FrObject(inf) ;
	 addField(EbCorpusMetaInfo::source_tag) ;
	 }
      else if (type == EbCORPUS_EXTRA_TARGET)
	 {
	 const char *inf = info ;
	 info = strchr(info,'\0') + 1 ;	// skip past terminating NUL
	 m_targetinfo = (FrList*)string_to_FrObject(inf) ;
	 addField(EbCorpusMetaInfo::target_tag) ;
	 }
      else if (type == EbCORPUS_EXTRA_BOUNDS1 ||
	       type == EbCORPUS_EXTRA_BOUNDS2)
	 {
	 size_t count = FrLoadShort(info) ;
	 info += sizeof(SHORTbuffer) ;
	 m_chunkbounds = FrNewC(uint16_t,count+1) ;
	 if (m_chunkbounds)
	    {
	    addField(EbCorpusMetaInfo::bounds_tag) ;
	    m_chunkbounds[0] = (uint16_t)count ;
	    for (size_t i = 1 ; i <= count && info < end ; i++)
	       {
	       uint16_t val ;
	       if (type == EbCORPUS_EXTRA_BOUNDS2)
		  {
		  val = FrLoadShort(info) ;
		  info += sizeof(uint16_t) ;
		  }
	       else
		  {
		  val = *((unsigned char *)info) ;
		  info++ ;
		  }
	       m_chunkbounds[i] = val ;
	       }
	    }
	 else if (type == EbCORPUS_EXTRA_BOUNDS1)
	    info += count ;
	 else
	    info += count * sizeof(uint16_t) ;
	 }
      else if (type == EbCORPUS_EXTRA_LABELS)
	 {
	 size_t count = FrLoadShort(info) ;
	 info += sizeof(SHORTbuffer) ;
	 m_chunklabels = FrNewC(FrSymbol*,count+1) ;
	 for (size_t i = 0 ; i < count ; i++)
	    {
	    const char *label = info ;
	    info = strchr(info,'\0') + 1 ;
	    if (m_chunklabels && *label)
	       m_chunklabels[i] = FrSymbolTable::add(label) ;
	    }
	 }
      else if (type == EbCORPUS_EXTRA_TRGSPANS)
	 {
	 free_object(m_trgspans) ;
	 m_trgspans = (FrList*)string_to_FrObject(info) ;
	 if (*info != '\0' || (m_trgspans && !m_trgspans->consp()))
	    {
	    FrWarning("corrupted TRGSPANS meta in index") ;
	    }
	 else
	    {
	    info++ ; // skip the NUL
	    addField(EbCorpusMetaInfo::trgspans_tag) ;
	    }
	 }
      else if (type == EbCORPUS_EXTRA_EXACT)
	 {
	 addField(EbCorpusMetaInfo::exact_tag) ;
	 }
      else if (type == EbCORPUS_EXTRA_TARGETPOS)
	 {
//FIXME: not yet implemented
	 }
      else if (type == EbCORPUS_EXTRA_USERSCORE)
	 {
	 unsigned count = *info++ ;
	 FrFree(m_userscores) ;
	 m_userscores = FrNewN(double,count) ;
	 if (m_userscores)
	    {
	    for (size_t i = 0 ; i < count && info < end ; i++)
	       {
	       m_userscores[i] = unpack_user_score(FrLoadLong(info)) ;
	       info += sizeof(LONGbuffer) ;
	       }
	    m_numuserscores = count ;
	    addField(EbCorpusMetaInfo::userscore_tag) ;
	    }
	 else
	    {
	    m_numuserscores = 0 ;
	    clearField(EbCorpusMetaInfo::userscore_tag) ;
	    }
	 }
      else if (type == EbCORPUS_EXTRA_MORPH)
	 {
	 if (numSourceWords() == 0) setSourceWords(source_len) ;
	 if (!ignore_morphology)
	    parseMorph(info) ;
	 else
	    m_unparsed_morph = info ;
	 size_t len = strlen(info) ;
	 info += len+1 ;		// skip the string and trailing NUL
	 addField(EbCorpusMetaInfo::morph_tag) ;
	 }
      else if (type == EbCORPUS_EXTRA_POS)
	 {
	 if (numSourceWords() == 0) setSourceWords(source_len) ;
	 for (size_t i = 0 ; i < m_sourcewords ; i++)
	    m_morph[i].partOfSpeech(info[i]) ;
	 info += m_sourcewords ;
	 addField(EbCorpusMetaInfo::pos_tag) ;
	 }
      else if (type == EbCORPUS_EXTRA_PERS_NUM)
	 {
	 if (numSourceWords() == 0) setSourceWords(source_len) ;
	 for (size_t i = 0 ; i < m_sourcewords ; i++)
	    m_morph[i].personAndNumber(info[i]) ;
	 info += m_sourcewords ;
	 addField(EbCorpusMetaInfo::person_tag) ;
	 addField(EbCorpusMetaInfo::num_tag) ;
	 }
      else if (type == EbCORPUS_EXTRA_GENDER_ASPECT)
	 {
	 if (numSourceWords() == 0) setSourceWords(source_len) ;
	 for (size_t i = 0 ; i < m_sourcewords ; i++)
	    m_morph[i].genderAndAspect(info[i]) ;
	 info += m_sourcewords ;
	 addField(EbCorpusMetaInfo::gender_tag) ;
	 addField(EbCorpusMetaInfo::aspect_tag) ;
	 }
      else if (type == EbCORPUS_EXTRA_FILLER)
	 continue ;
      else if (type >= EbCORPUS_EXTRA_RSVD)
	 {
	 FrString *targetstr = new FrString((FrList*)sentence,
					    char_encoding) ;
	 FrWarningVA("corrupted ancillary data for sentence pair!\n"
		     "\t(%u words)\n\t%.70s\n",source_len,
		     targetstr->stringValue()) ;
	 free_object(targetstr) ;
	 break ;
	 }
      else
	 FrWarningVA("invalid tag type (%2.02X) for sentence pair!",type) ;
      }
   return ;
}

//----------------------------------------------------------------------

bool EbCorpusMetaInfo::parseMorph(const char *morph)
{
   bool success = true ;
   for (size_t i = 0 ; morph && *morph && i < m_sourcewords ; i++)
      {
      FrObject *m = string_to_FrObject(morph) ;
      if (m)
	 {
	 if (m->consp())
	    m_morph[i].setOther((const FrList*)m) ;
	 m->freeObject() ;
	 }
      }
   return success ;
}

//----------------------------------------------------------------------

bool EbCorpusMetaInfo::setMorphology(size_t N, const FrStruct *morph)
{
   if (N < numSourceWords() && morph && morph->structp())
      {
      m_morph[N].init(morph) ;
      if (EbCORPUS_SPECIFIED(m_morph[N].partOfSpeech(),EbCORPUS_POS))
	 addField(pos_tag) ;
      if (EbCORPUS_SPECIFIED(m_morph[N].person(),EbCORPUS_PERS))
	 addField(person_tag) ;
      if (EbCORPUS_SPECIFIED(m_morph[N].number(),EbCORPUS_NUM))
	 addField(num_tag) ;
      if (EbCORPUS_SPECIFIED(m_morph[N].gender(),EbCORPUS_GENDER))
	 addField(gender_tag) ;
      if (EbCORPUS_SPECIFIED(m_morph[N].aspect(),EbCORPUS_ASPECT))
	 addField(aspect_tag) ;
      if (m_morph[N].other())
	 addField(morph_tag) ;
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

static bool write_token_tag(FILE *fp,FrSymbol *token)
{
   fputc((char)EbCORPUS_EXTRA_TAGS_RECURSE,fp) ;
   if (ignore_source_case)
      {
      char name[FrMAX_SYMBOLNAME_LEN+1] ;
      strncpy(name,token->symbolName(),sizeof(name)) ;
      name[sizeof(name)-1] = '\0' ;
      Fr_strlwr(name,char_encoding) ;
      fputs(name,fp) ;
      }
   else
      fputs(token->symbolName(),fp) ;
   fputc('\0',fp) ;
   return true ;
}

//----------------------------------------------------------------------

static size_t token_tag_length(FrSymbol *token)
{
   return sizeof(char) + strlen(token->symbolName()) + 1 ;
}

//----------------------------------------------------------------------

static bool store_token_tag(char *&buf, FrSymbol *token)
{
   *buf++ = (char)EbCORPUS_EXTRA_TAGS_RECURSE ;
   strcpy(buf,token->symbolName()) ;
   if (ignore_source_case)
      Fr_strlwr(buf,char_encoding) ;
   buf = strchr(buf,'\0') + 1 ;
   return true ;
}

//----------------------------------------------------------------------

static bool write_score_tag(FILE *fp, double score)
{
   fputc((char)EbCORPUS_EXTRA_SCORE,fp) ;
   LONGbuffer sc ;
   FrStoreLong((size_t)(score * EbCORPUS_SCORE_SCALE + 0.5),sc) ;
   return Fr_fwrite(sc,sizeof(sc),fp) ;
}

//----------------------------------------------------------------------

static bool store_score_tag(char *&buf, double score)
{
   *buf++ = (char)EbCORPUS_EXTRA_SCORE ;
   FrStoreLong((size_t)(score * EbCORPUS_SCORE_SCALE + 0.5),buf) ;
   buf += sizeof(LONGbuffer) ;
   return true ;
}

//----------------------------------------------------------------------

static bool write_freq_tag(FILE *fp, uint32_t xlat_freq, uint32_t total_freq)
{
   fputc((char)EbCORPUS_EXTRA_FREQ,fp) ;
   LONGbuffer freq ;
   FrStoreLong(xlat_freq,freq) ;
   if (Fr_fwrite(freq,1,sizeof(freq),fp))
      {
      FrStoreLong(total_freq,freq) ;
      return Fr_fwrite(freq,1,sizeof(freq),fp) ;
      }
   else
      return false ;
}

//----------------------------------------------------------------------

static bool store_freq_tag(char *&buf,uint32_t xlat_freq,uint32_t total_freq)
{
   *buf++ = (char)EbCORPUS_EXTRA_FREQ ;
   FrStoreLong(xlat_freq,buf) ;
   buf += sizeof(LONGbuffer) ;
   FrStoreLong(total_freq,buf) ;
   buf += sizeof(LONGbuffer) ;
   return true ;
}

//----------------------------------------------------------------------

static bool contiguous(size_t mask)
{
   for (size_t i = 0 ; mask && i < CHAR_BIT * sizeof(mask) ; i++)
      {
      if ((mask & 1) == 0 && (mask & ~1) != 0)
	 return false ;
      mask >>= 1 ;
      }
   return true ;
}

//----------------------------------------------------------------------

static void extract_phrase_mask(const FrList *phr, size_t &start, size_t &mask)
{
   size_t max ;
   extract_phrase_extent(phr,start,max) ;
   mask = 0 ;
   if (max - start > CHAR_BIT * sizeof(uint16_t))
      {
      start = ~0 ;
      return ;
      }
   for (const FrList *p = phr ; p ; p = p->rest())
      {
      int offset ;
      if (p->first())
	 {
	 offset = (int)p->first()->intValue() ;
	 if (offset > 0)
	    offset-- ;
	 }
      else
	 offset = -1 ;
      if (offset > (int)start)
	 {
	 int bit = (offset - start - 1) ;
	 mask |= (1 << bit) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

static bool contiguous_phrases(const FrList *phrases)
{
   FrSymbol *symDASH = makeSymbol("-") ;
   for ( ; phrases ; phrases = phrases->rest())
      {
      const FrList *phrase = (FrList*)phrases->first() ;
      if (phrase && phrase->consp())
	 {
	 const FrList *target = (FrList*)phrase->second() ;
	 if (target && target->consp() &&
	     (target->simplelistlength() != 3 || !target->member(symDASH)))
	    {
	    // check whether there are any gaps in the sequence
	    size_t start, mask ;
	    extract_phrase_mask(target,start,mask) ;
	    if (start != (size_t)~0 && !contiguous(mask))
	       return false ;	// one non-contig forces use of new fmt
	    }
	 }
      }
   return true ;
}

//----------------------------------------------------------------------

static bool write_phrase_tag(FILE *fp, const FrList *phrases)
{
   bool contiguous = contiguous_phrases(phrases) ;
   if (contiguous)
      fputc((char)EbCORPUS_EXTRA_PHRASES,fp) ;
   else
      fputc((char)EbCORPUS_EXTRA_PHRASES2,fp) ;
   SHORTbuffer s ;
   size_t num_phrases = phrases->simplelistlength() ;
   FrStoreShort(num_phrases,s) ;
   if (!Fr_fwrite(s,1,sizeof(s),fp))
      return false ;
   bool success = true ;
   for ( ; phrases && success ; phrases = phrases->rest())
      {
      const FrList *phrase = (FrList*)phrases->first() ;
      FrObject *freq = phrase->third() ;
      size_t f = 0 ;
      if (freq)
	 {
	 double fr = freq->floatValue() ;
	 if (fr > 1.0)
	    fr = 1.0 ;
	 f = make_phrase_score(fr) ;
	 }
      FrStoreShort(f,s) ;
      size_t src_start, src_end ;
      extract_phrase_extent((FrList*)phrase->first(),src_start,src_end) ;
      if (contiguous)
	 {
	 size_t trg_start, trg_end ;
	 extract_phrase_extent((FrList*)phrase->second(),trg_start,trg_end) ;
	 if (fputc((FrBYTE)src_start,fp) == EOF ||
	     fputc((FrBYTE)src_end,fp) == EOF ||
	     fputc((FrBYTE)trg_start,fp) == EOF ||
	     fputc((FrBYTE)trg_end,fp) == EOF ||
	     !Fr_fwrite(s,1,sizeof(s),fp))
	    success = false ;
	 }
      else
	 {
	 size_t trg_start, trg_mask ;
	 extract_phrase_mask((FrList*)phrase->second(),trg_start,trg_mask) ;
	 SHORTbuffer start, mask ;
	 FrStoreShort(trg_start,start) ;
	 FrStoreShort(trg_mask,mask) ;
	 if (fputc((FrBYTE)src_start,fp) == EOF ||
	     fputc((FrBYTE)src_end,fp) == EOF ||
	     !Fr_fwrite(start,1,sizeof(start),fp) ||
	     !Fr_fwrite(s,1,sizeof(s),fp) ||
	     !Fr_fwrite(mask,1,sizeof(mask),fp))
	    success = false ;
	 }
      }
   return success ;
}

//----------------------------------------------------------------------

static size_t phrase_tag_length(const FrList *phrases)
{
   size_t len = 1 + sizeof(SHORTbuffer) ;// the record type and record length
   size_t num_phrases = phrases->simplelistlength() ;
   bool contiguous = contiguous_phrases(phrases) ;
   if (contiguous)
      len += num_phrases * (sizeof(SHORTbuffer) + 4) ;
   else
      len += num_phrases * (3*sizeof(SHORTbuffer) + 2) ;
   return len ;
}

//----------------------------------------------------------------------

static bool store_phrase_tag(char *&buf, const FrList *phrases)
{
   bool contiguous = contiguous_phrases(phrases) ;
   if (contiguous)
      *buf++ = (char)EbCORPUS_EXTRA_PHRASES ;
   else
      *buf++ = (char)EbCORPUS_EXTRA_PHRASES2 ;
   size_t num_phrases = phrases->simplelistlength() ;
   FrStoreShort(num_phrases,buf) ;
   buf += sizeof(SHORTbuffer) ;
   bool success = true ;
   for ( ; phrases && success ; phrases = phrases->rest())
      {
      const FrList *phrase = (FrList*)phrases->first() ;
      FrObject *freq = phrase->third() ;
      size_t f = 0 ;
      if (freq)
	 {
	 double fr = freq->floatValue() ;
	 if (fr > 1.0)
	    fr = 1.0 ;
	 f = make_phrase_score(fr) ;
	 }
      size_t src_start, src_end ;
      extract_phrase_extent((FrList*)phrase->first(),src_start,src_end) ;
      if (contiguous)
	 {
	 size_t trg_start, trg_end ;
	 extract_phrase_extent((FrList*)phrase->second(),trg_start,trg_end) ;
	 *buf++ = (FrBYTE)src_start ;
	 *buf++ = (FrBYTE)src_end ;
	 *buf++ = (FrBYTE)trg_start ;
	 *buf++ = (FrBYTE)trg_end ;
	 FrStoreShort(f,buf) ;
	 buf += sizeof(SHORTbuffer) ;
	 }
      else
	 {
	 size_t trg_start, trg_mask ;
	 extract_phrase_mask((FrList*)phrase->second(),trg_start,trg_mask) ;
	 *buf++ = (FrBYTE)src_start ;
	 *buf++ = (FrBYTE)src_end ;
	 FrStoreShort(trg_start,buf) ;
	 buf += sizeof(SHORTbuffer) ;
	 FrStoreShort(f,buf) ;
	 buf += sizeof(SHORTbuffer) ;
	 FrStoreShort(trg_mask,buf) ;
	 buf += sizeof(SHORTbuffer) ;
	 }
      }
   return success ;
}

//----------------------------------------------------------------------

#if 0 // we don't actually write the origin to the sentence pair's metadata
static bool write_origin_tag(FILE *fp, const char *origin)
{
   fputc((char)EbCORPUS_EXTRA_ORIGIN,fp) ;
   fputs(origin,fp) ;
   fputc('\0',fp) ;
   return true ;
}
#endif

//----------------------------------------------------------------------

static bool store_origin_tag(char *&buf, const char *origin)
{
   *buf++ = (char)EbCORPUS_EXTRA_ORIGIN ;
   strcpy(buf,origin) ;
   buf = strchr(buf,'\0') + 1 ;
   return true ;
}

//----------------------------------------------------------------------

static bool write_lcontext_tag(FILE *fp, const FrList *context)
{
   fputc((char)EbCORPUS_EXTRA_RCONTEXT,fp) ;
   char *c = context->print() ;
   fputs(c,fp) ;
   fputc('\0',fp) ;
   FrFree(c) ;
   return true ;
}

//----------------------------------------------------------------------

static bool store_lcontext_tag(char *&buf, const FrList *context)
{
   *buf++ = (char)EbCORPUS_EXTRA_LCONTEXT ;
   char *c = context->print() ;
   size_t len = strlen(c) ;
   memcpy(buf,c,len) ;
   buf += len ;
   *buf++ = '\0' ;
   FrFree(c) ;
   return true ;
}

//----------------------------------------------------------------------

static bool write_rcontext_tag(FILE *fp, const FrList *context)
{
   fputc((char)EbCORPUS_EXTRA_RCONTEXT,fp) ;
   char *c = context->print() ;
   fputs(c,fp) ;
   fputc('\0',fp) ;
   FrFree(c) ;
   return true ;
}

//----------------------------------------------------------------------

static bool store_rcontext_tag(char *&buf, const FrList *context)
{
   *buf++ = (char)EbCORPUS_EXTRA_RCONTEXT ;
   char *c = context->print() ;
   size_t len = strlen(c) ;
   memcpy(buf,c,len) ;
   buf += len ;
   *buf++ = '\0' ;
   FrFree(c) ;
   return true ;
}

//----------------------------------------------------------------------

static FrList *remove_pos(const FrList *info)
{
   FrList *result ;
   FrList **end = &result ;
   for ( ; info ; info = info->rest())
      {
      FrObject *inf = info->first() ;
      if (inf)
	 {
	 FrObject *head = ((FrList*)inf)->first() ;
	 if (head && EBMT_equal(head,symPOS))
	    continue ;
	 result->pushlistend(inf->deepcopy(),end) ;
	 }
      }
   *end = 0 ;				// properly terminate the list
   return result ;
}

//----------------------------------------------------------------------

static bool write_source_tag(FILE *fp, const FrList *info)
{
   FrList *inf = remove_pos(info) ;
   if (inf)
      {
      fputc((char)EbCORPUS_EXTRA_SOURCE,fp) ;
      char *c = inf->print() ;
      inf->freeObject() ;
      fputs(c,fp) ;
      fputc('\0',fp) ;
      FrFree(c) ;
      }
   return true ;
}

//----------------------------------------------------------------------

static bool store_source_tag(char *&buf, const FrList *info)
{
   FrList *inf = remove_pos(info) ;
   if (inf)
      {
      *buf++ = (char)EbCORPUS_EXTRA_SOURCE ;
      char *c = inf->print() ;
      free_object(inf) ;
      size_t len = strlen(c) ;
      memcpy(buf,c,len) ;
      buf += len ;
      *buf++ = '\0' ;
      FrFree(c) ;
      }
   return true ;
}

//----------------------------------------------------------------------

static bool write_target_tag(FILE *fp, const FrList *info)
{
   fputc((char)EbCORPUS_EXTRA_TARGET,fp) ;
   char *c = info->print() ;
   fputs(c,fp) ;
   fputc('\0',fp) ;
   FrFree(c) ;
   return true ;
}

//----------------------------------------------------------------------

static bool store_target_tag(char *&buf, const FrList *info)
{
   *buf++ = (char)EbCORPUS_EXTRA_TARGET ;
   char *c = info->print() ;
   size_t len = strlen(c) ;
   memcpy(buf,c,len) ;
   buf += len ;
   *buf++ = '\0' ;
   FrFree(c) ;
   return true ;
}

//----------------------------------------------------------------------

static bool write_bounds_tag(FILE *fp, const EbCorpusMetaInfo *info)
{
   bool success = true ;
   const uint16_t *bounds = info->chunkBounds() ;
   if (bounds)
      {
      // for now, always generate the two-byte version, even if we could save
      //   space by using the one-byte version
      fputc((char)EbCORPUS_EXTRA_BOUNDS2,fp) ;
      SHORTbuffer val ;
      uint16_t count = bounds[0] ;
      FrStoreShort(count,val) ;
      if (!Fr_fwrite(val,sizeof(val),fp))
	 success = false ;
      else
	 {
	 for (size_t i = 1 ; i <= count ; i++)
	    {
	    FrStoreShort(bounds[i],val) ;
	    if (!Fr_fwrite(val,sizeof(val),fp))
	       success = false ;
	    }
	 }
      }
   return success ;
}

//----------------------------------------------------------------------

static bool store_bounds_tag(char *&buf, const EbCorpusMetaInfo *info)
{
   const uint16_t *bounds = info->chunkBounds() ;
   if (bounds)
      {
      // for now, always generate the two-byte version, even if we could save
      //   space by using the one-byte version
      *buf++ = (char)EbCORPUS_EXTRA_BOUNDS2 ;
      uint16_t count = bounds[0] ;
      FrStoreShort(count,buf) ;
      buf += sizeof(uint16_t) ;
      for (size_t i = 1 ; i <= count ; i++)
	 {
	 FrStoreShort(bounds[i],buf) ;
	 buf += sizeof(uint16_t) ;
	 }
      }
   return true ;
}

//----------------------------------------------------------------------

static bool write_labels_tag(FILE *fp, const EbCorpusMetaInfo *info)
{
   bool success = true ;
   uint16_t count = info->numChunkBounds() ;
   FrSymbol const * const *labels = info->chunkLabels() ;
   if (count > 0 && labels)
      {
      fputc((char)EbCORPUS_EXTRA_LABELS,fp) ;
      SHORTbuffer val ;
      FrStoreShort(count,val) ;
      if (!Fr_fwrite(val,sizeof(val),fp))
	 success = false ;
      else
	 {
	 for (size_t i = 0 ; i < count ; i++)
	    {
	    const char *str = labels[i] ? labels[i]->printableName() : "" ;
	    Fr_fwrite(str,strlen(str)+1,fp) ;
	    }
	 }
      }
   return success ;
}

//----------------------------------------------------------------------

static bool store_labels_tag(char *&buf, const EbCorpusMetaInfo *info)
{
   uint16_t count = info->numChunkBounds() ;
   FrSymbol const * const *labels = info->chunkLabels() ;
   if (count > 0 && labels)
      {
      *buf++ = (char)EbCORPUS_EXTRA_LABELS ;
      FrStoreShort(count,buf) ;
      buf += sizeof(uint16_t) ;
      for (size_t i = 0 ; i < count ; i++)
	 {
	 const char *str = labels[i] ? labels[i]->printableName() : "" ;
	 size_t len = strlen(str) + 1 ;
	 memcpy(buf,str,len) ;
	 buf += len ;
	 }
      }
   return true ;
}

//----------------------------------------------------------------------

static bool write_trgspans_tag(FILE *fp, const EbCorpusMetaInfo *info)
{
   bool success = true ;
   if (info->targetSpans())
      {
      fputc((char)EbCORPUS_EXTRA_TRGSPANS,fp) ;
      char *printed = info->targetSpans()->print() ;
      fputs(printed,fp) ;
      fputc('\0',fp) ;
      FrFree(printed) ;
      }
   return success ;
}

//----------------------------------------------------------------------

static bool store_trgspans_tag(char *&buf, const EbCorpusMetaInfo *info)
{
   if (info->targetSpans())
      {
      *buf++ = (char)EbCORPUS_EXTRA_TRGSPANS ;
      char *printed = info->targetSpans()->print() ;
      size_t len = strlen(printed) + 1 ;
      memcpy(buf,printed,len) ;
      buf += len ;
      FrFree(printed) ;
      }
   return true ;
}

//----------------------------------------------------------------------

static bool write_exact_tag(FILE *fp)
{
   fputc((char)EbCORPUS_EXTRA_EXACT,fp) ;
   return true ;
}

//----------------------------------------------------------------------

static bool store_exact_tag(char *&buf)
{
   *buf++ = (char)EbCORPUS_EXTRA_EXACT ;
   return true ;
}

//----------------------------------------------------------------------

static bool write_userscore_tag(FILE *fp, const EbCorpusMetaInfo *info)
{
   bool success = true ;
   if (info)
      {
      if (info->numUserScores() > 0)
	 {
	 fputc((char)EbCORPUS_EXTRA_USERSCORE,fp) ;
	 fputc((char)info->numUserScores(),fp) ;
	 for (size_t i = 0 ; i < info->numUserScores() ; i++)
	    {
	    LONGbuffer val ;
	    FrStoreLong(pack_user_score(info->userScore(i)),val) ;
	    if (!Fr_fwrite(val,sizeof(val),fp))
	       {
	       success = false ;
	       break ;
	       }
	    }
	 }
      }
   else
      success = false ;
   return success ;
}

//----------------------------------------------------------------------

static bool store_userscore_tag(char *&buf, const EbCorpusMetaInfo *info)
{
   if (info)
      {
      if (info->numUserScores() > 0)
	 {
	 *buf++ = (char)EbCORPUS_EXTRA_USERSCORE ;
	 *buf++ = (char)info->numUserScores() ;
	 for (size_t i = 0 ; i < info->numUserScores() ; i++)
	    {
	    FrStoreLong(pack_user_score(info->userScore(i)),buf) ;
	    buf += sizeof(LONGbuffer) ;
	    }
	 }
      return true ;
      }
   else
      return false ;
}

//----------------------------------------------------------------------

static bool write_pos_tag(FILE *fp, const EbCorpusMetaInfo *meta)
{
   if (meta)
      {
      fputc((char)EbCORPUS_EXTRA_POS,fp) ;
      size_t numwords = meta->numSourceWords() ;
      for (size_t i = 0 ; i < numwords ; i++)
	 fputc((char)meta->partOfSpeech(i),fp) ;
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

static bool store_pos_tag(char *&buf, const EbCorpusMetaInfo *meta)
{
   if (meta)
      {
      *buf++ = (char)EbCORPUS_EXTRA_POS ;
      size_t numwords = meta->numSourceWords() ;
      for (size_t i = 0 ; i < numwords ; i++)
	 *buf++ = (char)meta->partOfSpeech(i) ;
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

static bool write_pers_tag(FILE *fp, const EbCorpusMetaInfo *meta)
{
   if (meta)
      {
      fputc((char)EbCORPUS_EXTRA_PERS_NUM,fp) ;
      size_t numwords = meta->numSourceWords() ;
      for (size_t i = 0 ; i < numwords ; i++)
	 fputc((char)meta->personAndNumber(i),fp) ;
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

static bool store_pers_tag(char *&buf, const EbCorpusMetaInfo *meta)
{
   if (meta)
      {
      *buf++ = (char)EbCORPUS_EXTRA_PERS_NUM ;
      size_t numwords = meta->numSourceWords() ;
      for (size_t i = 0 ; i < numwords ; i++)
	 *buf++ = (char)meta->personAndNumber(i) ;
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

static bool write_gender_tag(FILE *fp, const EbCorpusMetaInfo *meta)
{
   if (meta)
      {
      fputc((char)EbCORPUS_EXTRA_GENDER_ASPECT,fp) ;
      size_t numwords = meta->numSourceWords() ;
      for (size_t i = 0 ; i < numwords ; i++)
	 fputc((char)meta->genderAndAspect(i),fp) ;
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

static bool store_gender_tag(char *&buf, const EbCorpusMetaInfo *meta)
{
   if (meta)
      {
      *buf++ = (char)EbCORPUS_EXTRA_GENDER_ASPECT ;
      size_t numwords = meta->numSourceWords() ;
      for (size_t i = 0 ; i < numwords ; i++)
	 *buf++ = (char)meta->genderAndAspect(i) ;
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

static bool write_morph_tag(FILE *fp, const EbCorpusMetaInfo *meta)
{
   if (meta)
      {
      fputc((char)EbCORPUS_EXTRA_MORPH,fp) ;
      size_t numwords = meta->numSourceWords() ;
      for (size_t i = 0 ; i < numwords ; i++)
	 {
	 const FrList *other = meta->otherMorphology(i) ;
	 char *info = other->print() ;
	 fputs(info,fp) ;
	 FrFree(info) ;
	 }
      fputc('\0',fp) ;
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

static bool store_morph_tag(char *&buf, const EbCorpusMetaInfo *meta)
{
   if (meta)
      {
      *buf++ = (char)EbCORPUS_EXTRA_MORPH ;
      size_t numwords = meta->numSourceWords() ;
      for (size_t i = 0 ; i < numwords ; i++)
	 {
	 const FrList *other = meta->otherMorphology(i) ;
	 char *info = other->print() ;
	 size_t len = strlen(info) ;
	 memcpy(buf,info,len) ;
	 buf += len ;
	 FrFree(info) ;
	 }
      *buf++ = '\0' ;
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

bool EbCorpusMetaInfo::write(FILE *fp) const
{
   bool successful_conversion = goodParse() ;
   if (!successful_conversion || !fp)
      return false ;
   if (haveField(token_tag) && !write_token_tag(fp,token()))
      successful_conversion = false ;
   if (haveField(score_tag) && !write_score_tag(fp,alignmentScore()))
      successful_conversion = false ;
   if (haveField(freq_tag) &&
       !write_freq_tag(fp,frequency(),frequency()))
      successful_conversion = false ;
   if (haveField(phrase_tag) && m_phrases &&
       !write_phrase_tag(fp,m_phrases))
      successful_conversion = false ;
#if 0 // we don't actually store the origin with the sentence pair, it gets
      //   put in the corpus.src file by other code
   if (haveField(origin_tag) && !write_origin_tag(fp,m_origin))
      successful_conversion = false ;
#endif
   if (haveField(pos_tag) && !write_pos_tag(fp,this))
      successful_conversion = false ;
   if ((haveField(num_tag) || haveField(person_tag)) &&
       !write_pers_tag(fp,this))
      successful_conversion = false ;
   if ((haveField(gender_tag) || haveField(aspect_tag)) &&
       !write_gender_tag(fp,this))
      successful_conversion = false ;
   if (haveField(morph_tag) && !write_morph_tag(fp,this))
      successful_conversion = false ;
   if (haveField(lcontext_tag) && !write_lcontext_tag(fp,m_lcontext))
      successful_conversion = false ;
   if (haveField(rcontext_tag) && !write_rcontext_tag(fp,m_rcontext))
      successful_conversion = false ;
   if (haveField(source_tag) && !write_source_tag(fp,m_sourceinfo))
      successful_conversion = false ;
   if (haveField(target_tag) && !write_target_tag(fp,m_targetinfo))
      successful_conversion = false ;
   if (haveField(bounds_tag) && !write_bounds_tag(fp,this))
      successful_conversion = false ;
   if (haveField(labels_tag) && !write_labels_tag(fp,this))
      successful_conversion = false ;
   if (haveField(trgspans_tag) && !write_trgspans_tag(fp,this))
      successful_conversion = false ;
   if (haveField(userscore_tag) && !write_userscore_tag(fp,this))
      successful_conversion = false ;
   // we are actually storing the "exact" flag with the per-sentence info, so
   //   there is no need to store it in the main corpus file
   if (haveField(exact_tag) && 0 && !write_exact_tag(fp))
      successful_conversion = false ;
   return successful_conversion ;
}

//----------------------------------------------------------------------

static size_t labels_length(FrSymbol const * const *labels, size_t count)
{
   size_t length = count ; // a NUL byte for each position
   for (size_t i = 0 ; i < count ; i++)
      {
      if (labels[i])
	 length += strlen(FrPrintableName(labels[i])) ;
      }
   return length ;
}

//----------------------------------------------------------------------

char *EbCorpusMetaInfo::store(size_t &length) const
{
   bool successful_conversion = goodParse() ;
   if (!successful_conversion)
      return 0 ;
   size_t len = 0 ;
   size_t bitext_len = 0 ;
   char *bitext_data = 0 ;
   if (haveField(token_tag))
      len += token_tag_length(token()) ;
   if (haveField(score_tag))
      len += sizeof(char) + sizeof(LONGbuffer) ;
   if (haveField(freq_tag))
      len += sizeof(char) + 2*sizeof(LONGbuffer) ;
   if (haveField(phrase_tag) && m_phrases)
      len += phrase_tag_length(m_phrases) ;
   if (haveField(origin_tag) && m_origin)
      len += sizeof(char) + strlen(m_origin) + sizeof(char) ;
   if (haveField(pos_tag) && numSourceWords() > 0)
      len += numSourceWords() + sizeof(char) ;
   if ((haveField(person_tag) || haveField(num_tag)) && numSourceWords() > 0)
      len += numSourceWords() + sizeof(char) ;
   if ((haveField(gender_tag) || haveField(aspect_tag))
       && numSourceWords() > 0)
      len += numSourceWords() + sizeof(char) ;
   if (haveField(morph_tag))
      {
      for (size_t i = 0 ; i < numSourceWords() ; i++)
	 {
	 const FrList *morph = otherMorphology(i) ;
	 len += morph->displayLength() + 2*sizeof(char) ;
	 }
      }
   if (haveField(lcontext_tag))
      len += (m_lcontext ? m_lcontext->displayLength() : 0) + 2*sizeof(char) ;
   if (haveField(rcontext_tag))
      len += (m_rcontext ? m_rcontext->displayLength() : 0) + 2*sizeof(char) ;
   if (haveField(source_tag))
      len += (m_sourceinfo ? m_sourceinfo->displayLength() : 0) + sizeof(char);
   if (haveField(target_tag))
      len += (m_targetinfo ? m_targetinfo->displayLength() : 0) + sizeof(char);
   size_t count = numChunkBounds() ;
   if (haveField(bounds_tag) && count > 0)
      {
      len += (count+1)*sizeof(m_chunkbounds[0]) ;
      if (haveField(labels_tag) && m_chunklabels)
	 len += labels_length(m_chunklabels,count) ;
      }
   if (haveField(align_tag) && m_bitext)
      {
      bitext_len += m_bitext->compress(bitext_data) ;
      len += bitext_len ;
      }
   char *buffer = FrNewN(char,len) ;
   char *buf = buffer ;
   if (haveField(token_tag) && !store_token_tag(buf,token()))
      successful_conversion = false ;
   if (haveField(score_tag) && !store_score_tag(buf,alignmentScore()))
      successful_conversion = false ;
   if (haveField(freq_tag) &&
       !store_freq_tag(buf,frequency(),frequency()))
      successful_conversion = false ;
   if (haveField(phrase_tag) && m_phrases &&
       !store_phrase_tag(buf,m_phrases))
      successful_conversion = false ;
   if (haveField(origin_tag) && m_origin &&
       !store_origin_tag(buf,m_origin))
      successful_conversion = false ;
   if (haveField(pos_tag) && numSourceWords() > 0 &&
       !store_pos_tag(buf,this))
      successful_conversion = false ;
   if ((haveField(person_tag) || haveField(num_tag)) &&
       numSourceWords() > 0 && !store_pers_tag(buf,this))
      successful_conversion = false ;
   if ((haveField(gender_tag) || haveField(aspect_tag)) &&
       numSourceWords() > 0 && !store_gender_tag(buf,this))
      successful_conversion = false ;
   if (haveField(morph_tag) && !store_morph_tag(buf,this))
      successful_conversion = false ;
   if (haveField(lcontext_tag) && !store_lcontext_tag(buf,m_lcontext))
      successful_conversion = false ;
   if (haveField(rcontext_tag) && !store_rcontext_tag(buf,m_rcontext))
      successful_conversion = false ;
   if (haveField(source_tag) && !store_source_tag(buf,m_sourceinfo))
      successful_conversion = false ;
   if (haveField(target_tag) && !store_target_tag(buf,m_targetinfo))
      successful_conversion = false ;
   if (haveField(bounds_tag) && !store_bounds_tag(buf,this))
      successful_conversion = false ;
   if (haveField(labels_tag) && !store_labels_tag(buf,this))
      successful_conversion = false ;
   if (haveField(trgspans_tag) && !store_trgspans_tag(buf,this))
      successful_conversion = false ;
   if (haveField(userscore_tag) && !store_userscore_tag(buf,this))
      successful_conversion = false ;
   if (haveField(exact_tag) && !store_exact_tag(buf))
      successful_conversion = false ;
   if (haveField(align_tag) && bitext_data)
      memcpy(buf,bitext_data,bitext_len) ;
   if (successful_conversion)
      {
      length = len ;
      return buffer ;
      }
   else
      {
      FrFree(buffer) ;
      length = 0 ;
      return 0 ;
      }
}

//----------------------------------------------------------------------

void EbCorpusMetaInfo::setSourceWords(size_t N)
{
   if (N <= m_sourcewords && m_morph)	// don't delete already-stored data
      return ;
   m_sourcewords = N ;
   delete [] m_morph ;
   m_morph = (N > 0) ? new EbCorpusMorphology[m_sourcewords] : 0 ;
   return ;
}

//----------------------------------------------------------------------

void EbCorpusMetaInfo::finishParsingMorphology()
{
   if (m_unparsed_morph)
      {
      parseMorph(m_unparsed_morph) ;
      m_unparsed_morph = 0 ;
      }
   return ;
}

//----------------------------------------------------------------------

void EbCorpusMetaInfo::origin(const char *new_origin)
{
   FrFree(m_origin) ;
   m_origin = FrDupString(new_origin) ;
   return ;
}

//----------------------------------------------------------------------

bool EbCorpusMetaInfo::phraseAlignIncludes(size_t start, size_t end) const
{
   if (phraseMap2())
      {
      for (size_t i = 0 ; i < m_phrasecount ; i++)
	 {
	 const char *map = phraseMap2(i) ;
	 size_t e = phraseSrcEnd(map) ;
	 size_t s = phraseSrcStart(map) ;
	 if (e < start)
	    continue ;			// no overlap
	 if (s > end)
	    break ;			// no more possible overlaps
	 if (s <= start && e >= end)
	    continue ;			// it's a valid substring
	 if (s >= start && e <= end)
	    continue ;			// it's a valid superstring
	 return true ;			// it crosses the phrase
	 }
      }
   else if (phraseMap())
      {
      for (size_t i = 0 ; i < m_phrasecount ; i++)
	 {
	 const char *map = phraseMap(i) ;
	 size_t e = phraseSrcEnd(map) ;
	 size_t s = phraseSrcStart(map) ;
	 if (e < start)
	    continue ;			// no overlap
	 if (s > end)
	    break ;			// no more possible overlaps
	 if (s <= start && e >= end)
	    continue ;			// it's a valid substring
	 if (s >= start && e <= end)
	    continue ;			// it's a valid superstring
	 return true ;			// it crosses the phrase
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

static size_t find_phrasemap_entry(const char *phrasemap, size_t maplen,
				   size_t entrysize, size_t start,
				   size_t src_end)
{
   size_t hi = maplen ;
   size_t lo = 0 ;
   while (hi > lo)
      {
      size_t mid = (lo + hi) / 2 ;
      const char *map = phrasemap + entrysize * mid ;
      if (!map)
	 break ;
      size_t s = EbCorpusMetaInfo::phraseSrcStart(map) ;
      size_t e = EbCorpusMetaInfo::phraseSrcEnd(map) ;
      if (start < s || (start == s && src_end >= e))
	 hi = mid ;
      else // if (start > s || (start == s && src_end < e))
	 lo = mid + 1 ;
      }
   return lo ;
}

//----------------------------------------------------------------------

double EbCorpusMetaInfo::phraseAlign(size_t start, size_t src_end,
				     size_t &trg_start, size_t &trg_end,
				     size_t &trg_mask, size_t alt_num)
   const
{
   const char *map ;
   if (phraseMap2())
      {
      size_t entrynum = find_phrasemap_entry(phraseMap2(),m_phrasecount,
					     phraseMap2EntrySize(),
					     start,src_end) ; 
      map = phraseMap2(entrynum + alt_num) ;
      if (map && phraseSrcStart(map) == start && phraseSrcEnd(map) == src_end)
	 {
	 trg_start = phrase2TrgStart(map) ;
	 trg_end = trg_start ;
	 trg_mask = phrase2TargetMask(map) ;
	 for (size_t i = 0 ; i < sizeof(uint16_t)*CHAR_BIT ; i++)
	    {
	    if ((trg_mask & (1 << i)) != 0)
	       trg_end = trg_start + i + 1 ;
	    }
	 return eval_phrase_score(phraseScore(map)) ;
	 }
      }
   else if (phraseMap())
      {
      size_t entrynum = find_phrasemap_entry(phraseMap(),m_phrasecount,
					     phraseMapEntrySize(),
					     start,src_end) ;
      map = phraseMap(entrynum + alt_num) ;
      if (map && phraseSrcStart(map) == start && phraseSrcEnd(map) == src_end)
	 {
	 trg_start = phraseTrgStart(map) ;
	 trg_end = phraseTrgEnd(map) ;
	 trg_mask = 0 ;
	 for (size_t i = 0 ; i < trg_end-trg_start ; i++)
	    trg_mask |= (1 << i) ;
	 return eval_phrase_score(phraseScore(map)) ;
	 }
      }
   trg_mask = 0 ;
   return -1.0 ;			// unable to align
}

//----------------------------------------------------------------------

FrList *EbCorpusMetaInfo::phrase2TargetWords(const char *map) const
{
   size_t first = phrase2TrgStart(map) + 1 ;
   FrList *target = 0 ;
   FrList **end = &target ;
   target->pushlistend(new FrInteger(first),end) ;
   size_t bits = phrase2TargetMask(map) ;
   for (size_t i = 0 ; i < sizeof(uint16_t)*CHAR_BIT ; i++)
      {
      if ((bits & (1 << i)) != 0)
	 target->pushlistend(new FrInteger(first+i+1),end) ;
      }
   *end = 0 ;				// terminate the list
   return target ;
}

//----------------------------------------------------------------------

FrList *EbCorpusMetaInfo::phrasalAlignments() const
{
   if (m_phrases)
      return (FrList*)m_phrases->deepcopy() ;
   FrSymbol *symDASH = makeSymbol("-") ;
   FrList *result ;
   FrList **end = &result ;
   if (m_phrasemap2 && m_phrasecount > 0)
      {
      for (size_t i = 0 ; i < m_phrasecount ; i++)
	 {
	 const char *map = phraseMap2(i) ;
	 if (!map)
	    continue ;
	 FrList *src = new FrList(new FrInteger(phraseSrcStart(map)+1),
				  symDASH,
				  new FrInteger(phraseSrcEnd(map)+1)) ;
	 FrList *trg = phrase2TargetWords(map) ;
	 FrFloat *score = new FrFloat(eval_phrase_score(phraseScore(map))) ;
	 result->pushlistend(new FrList(src,trg,score),end) ;
	 }
      }
   else if (m_phrasemap && m_phrasecount > 0)
      {
      for (size_t i = 0 ; i < m_phrasecount ; i++)
	 {
	 const char *map = phraseMap(i) ;
	 if (!map)
	    continue ;
	 FrList *src = new FrList(new FrInteger(phraseSrcStart(map)+1),
				  symDASH,
				  new FrInteger(phraseSrcEnd(map)+1)) ;
	 FrList *trg = new FrList(new FrInteger(phraseTrgStart(map)+1),
				  symDASH,
				  new FrInteger(phraseTrgEnd(map)+1)) ;
	 FrFloat *score = new FrFloat(eval_phrase_score(phraseScore(map))) ;
	 result->pushlistend(new FrList(src,trg,score),end) ;
	 }
      }
   *end = 0 ;				// properly terminate the list
   return result ;
}

//----------------------------------------------------------------------

FrList *EbCorpusMetaInfo::sourceStructure() const
{
   if (m_sourceinfo)
      {
      const FrList *pos = (FrList*)m_sourceinfo->assoc(makeSymbol("POS"),
						       EBMT_equal) ;
      if (pos)
	 {
	 FrList *struc = 0 ;
	 FrList **end = &struc ;
	 // make a copy of the part-of-speech list, taking only the first
	 //   item at each position
	 for (pos = pos->rest() ; pos ; pos = pos->rest())
	    {
	    FrObject *p = pos->first() ;
	    if (p && p->consp())
	       p = ((FrList*)p)->first() ;
	    struc->pushlistend(p,end) ;
	    }
	 *end = 0 ;			// properly terminate the list
	 return struc ;
	 }
      }
   return 0 ;
}

//----------------------------------------------------------------------

FrList *EbCorpusMetaInfo::targetRestrictions(size_t t_start,
					     size_t t_end) const
{
   if (targetPoS())
      {
//FIXME: not yet implemented
      }
   const FrList *tags = targetTags() ;
   FrList *restric ;
   FrList **r_end = &restric ;
   for ( ; tags ; tags = tags->rest())
      {
      FrList *tag = (FrList*)tags->first() ;
      if (!tag)
	 continue ;
      const char *tagname = tag->first()->printableName() ;
      if (tagname && Fr_stricmp(tagname,"POS") == 0)
	 {
	 const FrList *pos = tag->rest() ;
	 FrList *fixed_pos = EbFixDottedList(pos) ;
	 FrList *p = fixed_pos->nthcdr(t_start) ;
	 for (size_t i = t_start ; i <= t_end && p ; i++, p = p->rest())
	    {
	    FrObject *elt = p->first() ;
	    if (elt && elt->stringp() && 
		((FrString*)elt)->stringLength() == 0)
	       {
	       if (((FrString*)elt)->charWidth() == 4)
		  elt = makeSymbol("DQ") ;
	       else if (((FrString*)elt)->charWidth() == 2)
		  elt = makeSymbol("DQ") ;
	       }
	    restric->pushlistend(elt ? elt->deepcopy() : 0,r_end) ;
	    }
	 free_object(fixed_pos) ;
	 break ;
	 }
      }
   *r_end = 0 ;				// terminate the list
   return restric ;
}

//----------------------------------------------------------------------

size_t EbCorpusMetaInfo::chunkBound(size_t N, size_t sentlen) const
{
   if (N == 0)
      return 0 ;
   else if (chunkBounds() && N <= m_chunkbounds[0])
      return m_chunkbounds[N] ;
   else
      return sentlen ;
}

//----------------------------------------------------------------------

FrSymbol *EbCorpusMetaInfo::chunkLabel(size_t N) const
{
   if (N > 0 && chunkLabels() && N <= numChunkBounds())
      return m_chunklabels[N-1] ;
   return 0 ;
}

//----------------------------------------------------------------------

FrList *EbCorpusMetaInfo::targetSpans(size_t s_start, size_t s_end) const
{
   FrList *spans = 0 ;
   FrList **sp_end = &spans ;
   size_t length = s_end - s_start + 1 ;
   FrLocalAlloc(bool,covered,1024,length) ;
   for (const FrList *trgspn = targetSpans() ; trgspn ; trgspn=trgspn->rest())
      {
      FrList *spn = (FrList*)trgspn->first() ;
      if (!spn || !spn->consp())
	 continue ;
      FrSymbol *label = (FrSymbol*)spn->first() ;
      if (!label || !label->symbolp())
	 continue ;
      memset(covered,'\0',length) ;
      bool have_coverage = false ;
      for (spn = spn->rest() ; spn ; spn = spn->rest())
	 {
	 FrObject *loc = spn->first() ;
	 if (loc && loc->numberp())
	    {
	    long location = loc->intValue() - 1 ;
	    if (location >= (long)s_start && location <= (long)s_end)
	       {
	       covered[location - s_start] = true ;
	       have_coverage = true ;
	       }
	    }
	 }
      if (have_coverage)
	 {
	 FrList *span = 0 ;
	 FrList **span_end = &span ;
	 for (size_t i = 0 ; i < length ; i++)
	    {
	    if (covered[i])
	       span->pushlistend(new FrInteger(i),span_end) ;
	    }
	 *span_end = 0 ;
	 pushlist(label,span) ;
	 spans->pushlistend(span,sp_end) ;
	 }
      }
   *sp_end = 0 ;			// properly terminate result
   FrLocalFree(covered) ;
   return spans ; 
}

//----------------------------------------------------------------------

static size_t find_bound(const uint16_t *bounds, size_t pos,
			 size_t above = false)
{
   if (pos == 0 && !above)
      return 0 ;
   size_t lo = 1 ;
   size_t hi = bounds[0] ;
   while (hi > lo)
      {
      size_t mid = (hi + lo) / 2 ;
      if (pos > bounds[mid])
	 lo = mid + 1 ;
      else // (pos <= bounds[mid])
	 hi = mid ;
      }
   if (above && pos > bounds[lo])
      lo++ ;
   return lo ;
}

//----------------------------------------------------------------------

bool EbCorpusMetaInfo::chunksCovered(size_t start, size_t end,
				       size_t sentlen,
				       size_t &fully_covered,
				       size_t &partly_covered,
				       double &weighted_coverage,
				       bool weight_cover) const
{
   fully_covered = 0 ;
   partly_covered = 0 ;
   weighted_coverage = 0.0 ;
   if (chunkBounds())
      {
      size_t first_bound = find_bound(chunkBounds(),start) ;
      size_t last_bound = find_bound(chunkBounds(),end+1) ;
      // check for partial first chunk
      if (start > chunkBound(first_bound))
	 {
	 partly_covered = 1 ;
	 first_bound++ ;
	 }
      // check for partial last chunk
      if (last_bound > first_bound && end + 1 < chunkBound(last_bound,sentlen))
	 {
	 partly_covered++ ;
	 last_bound-- ;
	 }
      // scan the complete chunks
      for ( ; first_bound < last_bound ; first_bound++)
	 {
	 fully_covered++ ;
	 if (weight_cover)
	    {
	    size_t len = (chunkBound(first_bound+1) -
			  chunkBound(first_bound)) ;
	    weighted_coverage += ::exp(len) ;
	    }
	 else
	    weighted_coverage++ ;
	 }
      return true ;
      }
   else
      {
      fully_covered = (end - start + 1) ;
      weighted_coverage = fully_covered ;
      }
   return false ;
}

//----------------------------------------------------------------------

FrList *EbCorpusMetaInfo::chunkBoundaries() const
{
   FrList *bounds ;
   FrList **b_end = &bounds ;
   FrSymbol const * const *labels = chunkLabels() ;
   if (chunkBounds())
      {
      for (size_t i = 1 ; i <= m_chunkbounds[0] ; i++)
	 {
	 const FrSymbol *label = labels ? labels[i-1] : 0 ;
	 FrObject *b = new FrInteger(m_chunkbounds[i]) ;
	 if (label)
	    b = new FrList(b,label) ;
	 bounds->pushlistend(b,b_end) ;
	 }
      }
   *b_end = 0 ;				// terminate the list
   return bounds ;
}

/************************************************************************/
/*	Procedural Interface						*/
/************************************************************************/

FrList *EbExtractMetadataTag(const char *tags, const char *tagname)
{
   if (tags && tagname)
      {
      FrSymbol *sym = FrSymbolTable::add(tagname) ;
      do {
         while (*tags && (*tags == ';' || Fr_isspace(*tags)))
	    tags++ ;
	 if (*tags)
	    {
	    FrObject *obj = string_to_FrObject(tags) ;
	    if (obj && obj->consp())
	       {
	       FrList *item = (FrList*)obj ;
	       FrSymbol *type = (FrSymbol*)poplist(item) ;
	       if (type == sym)
		  return item ;
	       free_object(item) ;
	       }
	    else
	       free_object(obj) ;
	    }
         } while (*tags) ;
      }
   // if we get here, there was no matching tag
   return 0 ;
}

//----------------------------------------------------------------------

bool EbExtractMetadataFlag(const char *tags, const char *name)
{
   if (tags)
      {
      FrSymbol *flag = FrSymbolTable::add(name) ;
      do {
         while (*tags && (*tags == ';' || Fr_isspace(*tags)))
	    tags++ ;
	 if (*tags)
	    {
	    FrObject *obj = string_to_FrObject(tags) ;
	    if (obj == flag)
	       return true ;
	    if (obj && obj->consp())
	       {
	       FrList *item = (FrList*)obj ;
	       bool match = (item->first() == flag) ;
	       free_object(item) ;
	       if (match)
		  return true ;
	       }
	    else
	       free_object(obj) ;
	    }
         } while (*tags) ;
      }
   return false ;			// tag not present
}

//----------------------------------------------------------------------

FrSymbol *EbExtractTokenTag(const char *tags)
{
   if (tags)
      {
      do {
         while (*tags && (*tags == ';' || Fr_isspace(*tags)))
	    tags++ ;
	 if (*tags)
	    {
	    FrObject *obj = string_to_FrObject(tags) ;
	    if (obj && obj->consp())
	       {
	       FrList *item = (FrList*)obj ;
	       FrSymbol *type = (FrSymbol*)item->first() ;
	       if (type == symTOKEN)
		  {
		  FrSymbol *tok = FrCvt2Symbol(item->second(),char_encoding) ;
		  free_object(obj) ;
		  return tok ;
		  }
	       }
	    free_object(obj) ;
	    }
         } while (*tags) ;
      }
   // if we get here, there was no TOKEN tag
   return 0 ;
}

//----------------------------------------------------------------------

FrList *EbExtractAlignTag(const char *tags)
{
   return EbExtractMetadataTag(tags,"ALIGN") ;
}

//----------------------------------------------------------------------

bool EbExtractLiteralTag(const char *tags)
{
   return EbExtractMetadataFlag(tags,"LITERAL") ;
}

//----------------------------------------------------------------------

FrList *EbExtractUserScoreTag(const char *tags)
{
   return EbExtractMetadataTag(tags,"SC") ;
}

//----------------------------------------------------------------------

FrList *EbExtractPhraseTag(const char *tags)
{
   FrList *phrases = 0 ;
   if (tags)
      {
      FrSymbol *symP = makeSymbol("P") ;
      FrSymbol *symPHRASE = makeSymbol("PHRASE") ;
      do {
         while (*tags && (*tags == ';' || Fr_isspace(*tags)))
	    tags++ ;
	 if (*tags)
	    {
	    FrObject *obj = string_to_FrObject(tags) ;
	    if (obj && obj->consp())
	       {
	       FrList *item = (FrList*)obj ;
	       FrSymbol *type = (FrSymbol*)item->first() ;
	       if (type == symP || type == symPHRASE)
		  phrases = validate_phrase_tag(item->rest(),phrases) ;
	       }
	    free_object(obj) ;
	    }
         } while (*tags) ;
      }
   return phrases->sort(compare_phrases) ;
}

//----------------------------------------------------------------------

FrString *EbExtractOriginTag(const char *tags)
{
   FrList *origin = EbExtractMetadataTag(tags,"ORIGIN") ;
   if (origin)
      {
      FrObject *org = poplist(origin) ;
      free_object(origin) ;	// ignore any further elements
      if (org && org->stringp())
	 return (FrString*)org ;
      free_object(org) ;
      }
   // if we get here, there was no valid ORIGIN tag
   return 0 ;
}

//----------------------------------------------------------------------

double EbExtractScoreTag(const char *tags, bool *present)
{
   if (present)
      *present = false ;
   if (tags)
      {
      FrSymbol *symSCORE = makeSymbol("SCORE") ;
      do {
         while (*tags && (*tags == ';' || Fr_isspace(*tags)))
	    tags++ ;
	 if (*tags)
	    {
	    FrObject *obj = string_to_FrObject(tags) ;
	    if (obj && obj->consp())
	       {
	       FrList *item = (FrList*)obj ;
	       FrSymbol *type = (FrSymbol*)item->first() ;
	       if (type == symSCORE)
		  {
		  poplist(item) ;
		  FrObject *score = poplist(item) ;
		  free_object(item) ;	// ignore any further elements
		  double score_value = 1.0 ;
		  if (score && score->numberp())
		     {
		     score_value = score->floatValue() ;
		     if (present)
			*present = true ;
		     }
		  free_object(score) ;
		  return score_value ;
		  }
	       }
	    free_object(obj) ;
	    }
         } while (*tags) ;
      }
   // if we get here, there was no SCORE tag
   return 1.0 ;
}

//----------------------------------------------------------------------

bool EbExtractFreqTag(const char *tags, uint32_t &xlat, uint32_t &total)
{
   xlat = 1 ;
   total = 1 ;
   FrList *freqs = EbExtractMetadataTag(tags,"FREQ") ;
   if (freqs)
      {
      FrObject *x = poplist(freqs) ;
      FrObject *t = poplist(freqs) ;
      free_object(freqs) ;	// ignore any further elements
      bool present = false ;
      if (x && x->numberp())
	 {
	 xlat = (uint32_t)x->intValue() ;
	 if (t && t->numberp())
	    total = (uint32_t)t->intValue() ;
	 else
	    total = xlat ;
	 present = true ;
	 }
      free_object(x) ;
      free_object(t) ;
      return present ;
      }
   // if we get here, there was no FREQ tag
   return false ;
}

// end of file ebcrpinf.cpp //
