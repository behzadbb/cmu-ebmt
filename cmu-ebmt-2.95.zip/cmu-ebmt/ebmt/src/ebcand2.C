/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.92							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebcand2.cpp	class EBMTCandidate				*/
/*  LastEdit: 18mar10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#if defined(__GNUC__)
#  pragma implementation "ebchunks.h"
#endif

#define IMPLEMENT_EBCHUNKS
#include "ebchunks.h"
#include "ebmorph.h"

/************************************************************************/
/*    Global data for classes						*/
/************************************************************************/

/************************************************************************/
/************************************************************************/

void EBMTCandidate::setAlignScores(const double *scores,
				   size_t num_align)
{
   if (!scores)
      return ;
   double freq = frequency() ;
   EbFeatureVector *feats = features() ;
   for (size_t i = 0 ; i < num_align ; i++)
      {
      feats->setValue(align_featureIDs[i],
		      make_align_quality(scores[i],freq)) ;
      }
   return ;
}

/************************************************************************/
/************************************************************************/

EBMTCandidate *EbCopyCandidates(const EBMTCandidate *cand)
{
   if (!cand)
      return 0;

   // Make a new list of candidates
   EBMTCandidate *newcand = new EBMTCandidate(cand);
   EBMTCandidate *newcand_iter = newcand;
   for (EBMTCandidate *cand_iter = cand->next() ;
	cand_iter ;
	cand_iter = cand_iter->next())
      {
      EBMTCandidate *next = new EBMTCandidate(cand_iter);
      newcand_iter->setNext(next);
      newcand_iter = next;
      }
   return newcand;
}

//----------------------------------------------------------------------

void EbAdjustFrequency(EBMTCandidate *cand)
{
   if (!cand)
      return;

   size_t total_variants = 0 ;
   for(EBMTCandidate *iter = cand; iter; iter = iter->next())
      total_variants++;

   double total_mass = cand->totalMass() / total_variants ;
   size_t total_frequency =
      (size_t)((double)cand->frequency() / total_variants + 0.5) ;
   if (total_frequency == 0) { total_frequency = 1 ; }

   for(EBMTCandidate *iter = cand; iter; iter = iter->next())
      {
      iter->setFrequency(total_frequency) ;
      iter->setMass(total_mass) ;
      }
   return;
}

//----------------------------------------------------------------------

EBMTCandidate *insert_unique(EBMTCandidate *newcand,
			     EBMTCandidate *candidates, bool update)
{
   if (!newcand)
      return candidates;

   EBMTCandidate *prev = 0 ;
   EBMTCandidate *cand = candidates ;
   while (cand)
      {
      if (newcand->generalizations->equal(cand->generalizations) &&
	  ::equal(newcand->targetWords(),cand->targetWords()))
	 // matching is no longer case-insensitive
	 {
	 double sc1 = newcand->alignmentScore() * newcand->confidence() ;
	 double sc2 = cand->alignmentScore() * cand->confidence() ;
	 if (sc1 > sc2 ||
	     (sc1 == sc2 &&
	      newcand->frequency() >= cand->frequency()))
	    {
	    // duplicate with better score than what's already there
	    if (prev)
	       prev->setNext(newcand) ;
	    else
	       candidates = newcand ;
	    newcand->setNext(cand->next()) ;
	    cand->setNext(0) ;
	    EBMTCandidate *tmp = cand ;	// swap the new and existing candidate
	    cand = newcand ;
	    newcand = tmp ;
	    }
	 // accumulate frequency and weight info from the duplicate but
	 //   lower-scored candidate before deleting it
	 if (update)
	    {
	    cand->features()->add(newcand->features()) ;
	    }
	 delete newcand ;
	 return candidates ;
	 }
       
      prev = cand ;
      cand = cand->next() ;
      }

   // If we have not already returned, then we need to add the new candidate
   newcand->setNext(candidates) ;
   return newcand ;
}


// end of file ebcand2.cpp //
