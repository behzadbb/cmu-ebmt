/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebtokinf.cpp	class TokenInfo					*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#if defined(__GNUC__)
#  pragma implementation "ebtoken.h"
#endif

#include "ebtoken.h"
#include "ebglobal.h"

#ifndef NDEBUG
# undef _FrCURRENT_FILE
static const char _FrCURRENT_FILE[] = __FILE__ ; // save memory
#endif /* NDEBUG */

/************************************************************************/
/*    Global data for classes						*/
/************************************************************************/

FrAllocator TokenInfo::allocator("TokenInfo",sizeof(TokenInfo)) ;

/************************************************************************/
/*	Methods for class TokenInfo					*/
/************************************************************************/

void TokenInfo::init(size_t len, uint32_t id, size_t srcwords)
{
   m_span = 0 ;
   m_length = len ;
   m_sourcewords = 1 ;
   m_inputwords = srcwords ;
   m_istok = false ;
   m_equivclass = 0 ;
   m_wordIDs = FrNewN(uint32_t,m_sourcewords) ;
   if (m_wordIDs)
      {
      m_wordIDs[0] = id ;
      for (size_t i = 1 ; i < m_sourcewords ; i++)
	 m_wordIDs[i] = (uint32_t)FrVOCAB_WORD_NOT_FOUND ;
      }
   else
      m_sourcewords = m_length = 0 ;
   return ;
}

//----------------------------------------------------------------------

TokenInfo::TokenInfo(uint32_t id,size_t len,const FrList *trg,TokenInfo *nxt)
{
   init(len,id) ;
   FrString *s = new FrString(trg) ;
   m_trg = s ? new FrList(s) : 0 ;
   m_next = nxt ;
   return ;
}

//----------------------------------------------------------------------

TokenInfo::TokenInfo(uint32_t id, size_t len, FrString *trg, TokenInfo *nxt,
		     size_t srcwords)
{
   init(len,id,srcwords) ;
   m_trg = trg ? new FrList(trg) : 0 ;
   m_next = nxt ;
   return ;
}

//----------------------------------------------------------------------

TokenInfo::TokenInfo(size_t words, const uint32_t* ids, size_t len,
		     FrString *trg, TokenInfo *nxt)
{
   assertq(words == 0 || ids != 0) ;
   m_span = 0 ;
   m_length = len ;
   m_sourcewords = words ;
   m_inputwords = words ;
   m_istok = false ;
   m_equivclass = 0 ;
   m_wordIDs = FrNewN(uint32_t,words) ;
   if (m_wordIDs)
      {
      for (size_t i = 0 ; i < words ; i++)
	 m_wordIDs[i] = ids[i] ;
      }
   else
      {
      m_sourcewords = m_length = 0 ;
      }
   m_trg = trg ? new FrList(trg) : 0 ;
   m_next = nxt ;
   return ;
}

//----------------------------------------------------------------------

TokenInfo::~TokenInfo()
{
   free_object(m_trg) ; 	m_trg = 0 ;
   if (m_next)
      {
      delete m_next ;
      m_next=0 ;
      }
   FrFree(m_wordIDs) ;		m_wordIDs = 0 ;
   m_span = 0 ;
   return ;
}

//----------------------------------------------------------------------

int TokenInfo::compare(const TokenInfo &tok1, const TokenInfo &tok2)
{
   size_t len1 = tok1.sourceWords() ;
   size_t len2 = tok2.sourceWords() ;
   size_t minlen = len1 ;
   if (len2 < minlen)
      minlen = len2 ;
   for (size_t i = 0 ; i < minlen ; i++)
      {
      uint32_t id1 = tok1.wordID(i) ;
      uint32_t id2 = tok2.wordID(i) ;
      if (id1 < id2)
	 return -1 ;
      else if (id1 > id2)
	 return +1 ;
      }
   // if the first one is longer, we want it to come later in the sorted list
   if (len1 > len2)
      return +1 ;
   else if (len1 < len2)
      return -1 ;
   // same length, so the list of IDs was identical
   return 0 ;
}

//----------------------------------------------------------------------

void TokenInfo::dump(ostream &out) const
{
   out << "TokenInfo<" << m_trg << ",len=" << m_length << ",m_srcw="
       << m_sourcewords << ",tok=" << (m_istok?"T":"F") << ">" << endl ;
   return ;
}

// end of file ebtokinf.cpp //
