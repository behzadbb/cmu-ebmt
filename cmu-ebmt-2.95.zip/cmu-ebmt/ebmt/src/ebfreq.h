/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebfreq.h	match-frequency statistics			*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 2007,2009 Ralf Brown					*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __EBFREQ_H_INCLUDED
#define __EBFREQ_H_INCLUDED

class EBMTCandidate ;
class EbCorpusMatches ;

class EbMatchFrequency
   {
   private:
      size_t m_desired ;
      size_t m_desired1 ;
      size_t m_inputlen ;
      uint16_t *m_counts ;

   public: // members
      EbMatchFrequency(const EBMTCandidate *cands, size_t inputlen,
		       size_t desired, size_t desired_uni) ;
      EbMatchFrequency(const EbCorpusMatches *matches, size_t inputlen,
		       size_t desired, size_t desired_uni) ;
      ~EbMatchFrequency() ;

      size_t desiredMatches() const { return m_desired ; }
      size_t desiredUnigramMatches() const { return m_desired1 ; }
      void updateFrequency(const EbCorpusMatches *) ;
      void updateFrequencies(const EbCorpusMatches *,
			     const EbCorpusMatches *prev_matches = 0) ;
      size_t frequency(const EbCorpusMatches *) const ;
      bool wantMore(const EbCorpusMatches *) const ;
   } ;


#endif /* !__EBFREQ_H_INCLUDED */

// end of file ebfreq.h //
