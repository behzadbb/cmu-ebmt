/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.91							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebtoken.cpp	word/phrase tokenizer				*/
/*  LastEdit: 16feb10							*/
/*									*/
/*  (c) Copyright 1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,	*/
/*		2006,2007,2008,2009,2010 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#if defined(__GNUC__)
#  pragma implementation "ebtoken.h"
#endif

#include "frassert.h"
#include "frregexp.h"
#include "frstring.h"
#include "ebchunks.h"
#include "ebcorpus.h"
#include "ebtoken.h"
#include "ebutil.h"    // for is_number() and remove_punctuation()
#include "ebbitext.h"
#include "ebglobal.h"

#ifdef unix
#include <unistd.h>
#endif /* unix */

/************************************************************************/
/*	Manifest constants for this module				*/
/************************************************************************/

/************************************************************************/
/*	Types for this module						*/
/************************************************************************/

class EbReplacement : public FrObject
   {
   private:
      static FrAllocator allocator ;
      EbReplacement *m_next ;
      size_t    m_length ;
      size_t    m_trglength ;
      FrSymbol *m_equivclass ;
      FrList   *m_source ;
      FrList   *m_translation ;
      FrList   *m_stripped_xlat ;
   public:
      void *operator new(size_t) { return allocator.allocate() ; }
      void operator delete(void *blk) { allocator.release(blk) ; }
      EbReplacement(size_t length, FrSymbol *token, FrList *source,
		    FrList *translation, EbReplacement *next = 0) ;
      virtual ~EbReplacement() ;

      virtual void freeObject() { delete this ; }

      static int compare(const EbReplacement &r1, const EbReplacement &r2) ;

      // accessors
      EbReplacement *next() const { return m_next ; }
      size_t length() const { return m_length ; }
      size_t targetLength() const { return m_trglength ; }
      FrSymbol *equivClass() const { return m_equivclass ; }
      const FrList *source() const { return m_source ; }
      const FrList *translation() const { return m_translation ; }
      const FrList *strippedTranslation() const { return m_stripped_xlat ; }
      bool listContains(size_t length, FrSymbol *token, const FrList *src,
			  const FrList *translation) const ;

      // modifiers
      void setNext(EbReplacement *next) { m_next = next ; }

      // I/O
      virtual ostream &printValue(ostream &output) const ;
      bool print(ostream &out) const ;
   } ;

//----------------------------------------------------------------------

class EbReplacements : public FrArray
{
   public:
      EbReplacements(size_t numwords = 1) ;
      ~EbReplacements() ;

      virtual void freeObject() { delete this ; }

      bool add(size_t position, size_t length, FrSymbol *token,
	       FrList *source, FrList *translation) ;

      bool apply(FrList *&words, FrArray *morph, const size_t *wordmap) ;
      bool apply(FrList *&srcwords, FrList *&trgwords, FrArray *morph,
		 BiTextMap *bitext, const size_t *wordmap,
		 FrList *&genseq, const EbAlignConstraints * = 0) ;

      void sort() ;
} ;

/************************************************************************/
/*	Global Data for this module					*/
/************************************************************************/

static const char text_read_mode[] = "r" ;

#ifndef NDEBUG
// save space in executable
# undef _FrCURRENT_FILE
//static const char _FrCURRENT_FILE[] = __FILE__ ;
#endif /* NDEBUG */

FrAllocator Tokenizer::allocator("Tokenizer",sizeof(Tokenizer)) ;
FrAllocator EbReplacement::allocator("EbReplacement",sizeof(EbReplacement)) ;

/************************************************************************/
/*	helper functions	 					*/
/************************************************************************/

bool is_token(const char *word)
{
   return (word && word[0] == EbTOKEN_START && word[1] != '\0' &&
           strchr(word+1,EbTOKEN_END) != 0) ;
}

//----------------------------------------------------------------------

bool is_token(FrSymbol *word)
{
   return word && is_token(word->symbolName()) ;
}

//----------------------------------------------------------------------

bool is_token(const FrObject *obj)
{
   return obj && is_token(obj->printableName()) ;
}

//----------------------------------------------------------------------

bool contains_tokens(const FrList *words)
{
   FrSymbol *concat = makeSymbol(CONCATENATION_MARKER) ;
   for ( ; words ; words = words->rest())
      {
      FrObject *word = words->first() ;
      if (is_token(word) && !EBMT_equal(word,concat))
	 return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

static size_t count_tokens(const FrList *wordlist)
{
   size_t count = 0 ;
   FrSymbol *concat = makeSymbol(CONCATENATION_MARKER) ;
   for ( ; wordlist ; wordlist = wordlist->rest())
      {
      FrObject *word = wordlist->first() ;
      if (is_token(word) && !EBMT_equal(word,concat))
	 count++ ;
      }
   return count ;
}

//----------------------------------------------------------------------

char *EbStripCoindex(const char *word, FrCharEncoding encoding)
{
   if (!word)
      return 0 ;
   char name[FrMAX_SYMBOLNAME_LEN+2] ;
   strncpy(name,word,sizeof(name)) ;
   name[sizeof(name)-1] = '\0' ;
   if (word[0] == EbTOKEN_START)
      {
      char *end = strrchr(name,EbTOKEN_END) ;
      if (end)
	 {
	 // OK, we have a token which has been decorated with a co-index
	 // so strip off the co-index
	 end[1] = '\0' ;
	 }
      }
   Fr_strlwr(name,encoding) ;
   return FrDupString(name) ;
}

//----------------------------------------------------------------------

bool token_equal(FrSymbol *s1, FrSymbol *s2)
{
   if (s1 == s2)
      return true ;
   else if (s1 && s2)
      {
      const char *str1 = s1->symbolName() ;
      const char *str2 = s2->symbolName() ;
      const char *end = FrTruncationPoint(str1,EbTOKEN_END) ;
      return memcmp(str1,str2,(end-str1+1)) == 0 ;
      }
   else
      return false ;
}

//----------------------------------------------------------------------

bool token_equal(FrSymbol *o1, const FrObject *o2)
{
   if (o1 == o2)
      return true ;
   else if (o1 && o2)
      {
      const char *s2 = o2->printableName() ;
      if (s2)
	 {
	 // we can avoid the computational expense of generating new
	 //   symbols sans any coindices, and just directly check the
	 //   names against each other
	 const char *s1 = o1->symbolName() ;
	 const char *end = FrTruncationPoint(s1,EbTOKEN_END) ;
	 return Fr_strnicmp(s1,s2,(end-s1+1),lowercase_table) == 0 ;
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

bool token_equal(const FrObject *o1, const FrObject *o2)
{
   if (o1 == o2)
      return true ;
   else if (o1 && o2)
      {
      const char *s1 = o1->printableName() ;
      const char *s2 = o2->printableName() ;
      if (s1 && s2)
	 {
	 // if both are symbols or strings, we can avoid the computational
	 //   expense of generating new symbols sans any coindices, and
	 //   just directly check the names against each other
	 const char *end = FrTruncationPoint(s1,EbTOKEN_END) ;
	 return Fr_strnicmp(s1,s2,(end-s1+1),lowercase_table) == 0 ;
	 }
      if (o1->consp() && o2->consp())
	 {
	 FrList *l1 = (FrList*)o1 ;
	 FrList *l2 = (FrList*)o2 ;
	 while (l1 && l2)
	    {
	    if (!token_equal(l1->first(),l2->first()))
	       return false ;
	    l1 = l1->rest() ;
	    l2 = l2->rest() ;
	    }
	 return true ;
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

FrList *remove_ignored_tokenizer_items(const FrList *symlist)
{
   FrList *stripped = 0 ;
   FrList **end = &stripped ;
   FrSymbol *concat = makeSymbol(CONCATENATION_MARKER) ;
   for ( ; symlist ; symlist = symlist->rest())
      {
      FrObject *first = symlist->first() ;
      if (!EBMT_equal(first,concat))
	 stripped->pushlistend(first,end) ;
      }
   *end = 0 ;				// terminate resultlist
   return stripped ;
}

//----------------------------------------------------------------------

FrList *strip_ignored_tokenizer_items(const FrList *symlist)
{
   FrList *stripped = 0 ;
   FrList **end = &stripped ;
   FrSymbol *concat = makeSymbol(CONCATENATION_MARKER) ;
   for ( ; symlist ; symlist = symlist->rest())
      {
      FrObject *first = symlist->first() ;
      if (first && !EBMT_equal(first,concat))
	 stripped->pushlistend(first->deepcopy(),end) ;
      }
   *end = 0 ;				// terminate resultlist
   return stripped ;
}

//----------------------------------------------------------------------

FrList *EbMakeGeneralizationSeq(FrObject *token, size_t offset, size_t len)
{
   FrList *gen = 0 ;
   if (token)
      {
      for (size_t i = offset ; i < offset + len ; i++)
	 {
	 pushlist(new FrInteger(i),gen) ;
	 }
      gen = listreverse(gen) ;
      pushlist(token->deepcopy(),gen) ;
      }
   return gen ;
}

/************************************************************************/
/*	methods for class EbReplacement					*/
/************************************************************************/

EbReplacement::EbReplacement(size_t length, FrSymbol *token, FrList *source,
			     FrList *translation, EbReplacement *next)
{
   m_length = length ;
   m_equivclass = token ;
   m_source = source ;
   m_translation = translation ;
   m_stripped_xlat = strip_ignored_tokenizer_items(translation) ;
   m_trglength = m_stripped_xlat->simplelistlength() ;
   m_next = next ;
   return ;
}

//----------------------------------------------------------------------

EbReplacement::~EbReplacement()
{
   free_object(m_source) ;
   free_object(m_translation) ;
   free_object(m_stripped_xlat) ;
   if (m_next)
      delete m_next ;
   return ;
}

//----------------------------------------------------------------------

int EbReplacement::compare(const EbReplacement &r1, const EbReplacement &r2)
{
   if (r1.length() < r2.length())
      return +1 ;
   else if (r1.length() > r2.length())
      return -1 ;
   size_t tok1 = count_tokens(r1.m_source) ;
   size_t tok2 = count_tokens(r2.m_source) ;
   if (tok1 < tok2)
      return -1 ;
   else if (tok1 > tok2)
      return +1 ;
   // we don't really care about ordering except that it should be by
   //   decreasing length and increasing generalization, so say that the two
   //   are equal
   return 0 ;
}

//----------------------------------------------------------------------

bool EbReplacement::listContains(size_t length, FrSymbol *token,
				   const FrList *src,
				   const FrList *trans) const
{
   const EbReplacement *repl = this ;
   for ( ; repl ; repl = repl->next())
      {
      if ((!length || length == repl->length()) &&
	  (!token || token == repl->equivClass()) &&
	  (!src || EBMT_equal(src,repl->source())) &&
	  (!trans || EBMT_equal(trans,repl->translation())))
	 return true ;
      }
   // if we get to this point, there was no matching entry
   return false ;
}

//----------------------------------------------------------------------

bool EbReplacement::print(ostream &out) const
{
   out << source() << " == " << equivClass() << " == "
       << translation() << " @ " << length() << endl ;
   return true ;
}

//----------------------------------------------------------------------

ostream &EbReplacement::printValue(ostream &output) const
{
   output << "#EbReplacement<" << source() << " == " << equivClass() << " == "
	  << translation() << " @ " << length() ;
   if (next())
      {
      output << " " ;
      next()->printValue(output) ;
      }
   return output << ">" ;
}

/************************************************************************/
/*	methods for class EbReplacements				*/
/************************************************************************/

EbReplacements::EbReplacements(size_t numwords) : FrArray(numwords)
{
   return ;
}

//----------------------------------------------------------------------

EbReplacements::~EbReplacements()
{
   for (size_t i = 0 ; i < arrayLength() ; i++)
      {
      free_object(getNth(i)) ;
      setNth(i,0) ;
      }
   return ;
}

//----------------------------------------------------------------------

bool EbReplacements::add(size_t position, size_t length, FrSymbol *token,
			   FrList *source, FrList *translation)
{
   if (translation->member(token,EBMT_equal))
      {
      free_object(source) ;
      free_object(translation) ;
      return false ;			// avoid infinite recursions
      }
   if (position >= arrayLength())
      expandTo(position+1) ;
   EbReplacement *prevrepl = (EbReplacement*)getNth(position) ;
   if (prevrepl->listContains(length,token,source,translation))
      {
      free_object(source) ;
      free_object(translation) ;
      return false ;			// already in set of replacements
      }
   char *stripped = EbStripCoindex(token ? token->symbolName() : "",
				   char_encoding) ;
   token = FrSymbolTable::add(stripped) ;
   FrFree(stripped) ;
   m_array[position] = new EbReplacement(length,token,source,translation,
					 prevrepl) ;
   return true ;
}

//----------------------------------------------------------------------

static bool conflicts(const EbReplacement *repl, size_t startpos,
			const FrBitVector *cover)
{
   if (!repl || !cover)
      return true ;
   for (size_t i = startpos ; i < startpos + repl->length() ; i++)
      {
      if (cover->getBit(i))
	 return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

static bool bitext_allows(const BiTextMap *bitext,
			    const size_t *wordmap,
			    size_t srcstart, size_t srclen,
			    size_t trgstart, size_t trglen)
{
   if (!bitext)
      return true ;
   size_t pastend = wordmap[srcstart + srclen] ;
   if (pastend > bitext->sourceLength())
      pastend = bitext->sourceLength() ;
   size_t trgend = trgstart + trglen - 1 ;
   size_t count = 0 ;
   for (size_t i = wordmap[srcstart] ; i < pastend ; i++)
      {
      size_t numcorr = bitext->numTargetCorrespondences(i) ;
      if (numcorr == 0 ||
	  bitext->numTargetCorrespondences(i,trgstart,trgend) > 0)
	 count++ ;
      }
   // allowed if a majority of the source words either have a correspondence
   //   in the desired target phrase or no known correspondences at all
   return (count > srclen/2) ;
}

//----------------------------------------------------------------------

static bool bitext_prohibits(const BiTextMap *bitext,
			       const size_t *wordmap,
			       size_t srcstart, size_t srclen,
			       size_t trgstart, size_t trglen)
{
   size_t pastend = wordmap[srcstart + srclen] ;
   if (pastend > bitext->sourceLength())
      pastend = bitext->sourceLength() ;
   size_t trgend = trgstart + trglen - 1 ;
   for (size_t i = wordmap[srcstart] ; i < pastend ; i++)
      {
      size_t numcorr = bitext->numTargetCorrespondences(i) ;
      if (numcorr > 0 &&
	  bitext->numTargetCorrespondences(i,trgstart,trgend) == 0)
	 return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

static bool unique_replacement(const EbReplacement *repl,
				 size_t srcloc, const FrList *trgwords,
				 const BiTextMap *bitext,
				 const size_t *wordmap, size_t &trgloc)
{
   trgloc = (size_t)~0 ;
   const FrList *xlat = repl->strippedTranslation() ;
   size_t occur = trgwords->locate(xlat,EBMT_equal) ;
   if (occur == (size_t)-1 || !bitext)
      return false ;			// no match at all
   size_t trglength = repl->targetLength() ;
   // see whether the bitext map indicates that only a single one of
   //    the possible occurrences of the translation is not categorically
   //    prohibited
   size_t allowed = (size_t)~0 ;
   do {
      if (!bitext_prohibits(bitext,wordmap,srcloc,trglength,occur,trglength))
	 {
	 if (allowed != (size_t)~0)
	    return false ;		// ambiguous
	 allowed = occur ;
	 }
      occur = trgwords->locate(xlat,EBMT_equal,occur) ;
      } while (occur != (size_t)-1) ;
   trgloc = allowed ;
   return (allowed != (size_t)~0) ;
}

//----------------------------------------------------------------------

static bool possible_replacement(const EbReplacement *repl,
				   size_t srcloc, const FrList *trgwords,
				   const BiTextMap *bitext,
				   const size_t *wordmap, size_t &trgloc)
{
   trgloc = (size_t)~0 ;
   const FrList *xlat = repl->strippedTranslation() ;
   size_t occur = trgwords->locate(xlat,EBMT_equal) ;
   if (occur == (size_t)-1)
      return false ;			// no match at all
   size_t trglength = repl->targetLength() ;
   // see whether the bitext map indicates that only a single one of
   //    the possible occurrences of the translation might correspond
   size_t allowed = (size_t)~0 ;
   do {
      if (bitext_allows(bitext,wordmap,srcloc,trglength,occur,trglength))
	 {
	 if (allowed != (size_t)~0)
	    return false ;		// ambiguous
	 allowed = occur ;
	 }
      occur = trgwords->locate(xlat,EBMT_equal,occur) ;
      } while (occur != (size_t)-1) ;
   if (allowed == (size_t)~0)
      return false ;
   trgloc = allowed ;
   return true ;
}

//----------------------------------------------------------------------

static void insert_replacement(FrList *words, FrSymbol *eqclass, size_t len)
{
   free_object(words->first()) ;
   words->replaca(eqclass) ;
   for (size_t i = 1 ; i < len && words->rest() ; i++)
      {
      words = words->rest() ;
      free_object(words->first()) ;
      words->replaca(0) ;
      }
   return ;
}

//----------------------------------------------------------------------

static void apply_replacement(const EbReplacement *repl, size_t srcloc,
			      FrList *srcwords, FrArray *morph,
			      const size_t *wordmap)
{
   srcloc = wordmap[srcloc] ;
   srcwords = srcwords->nthcdr(srcloc) ;
   FrSymbol *eqclass = repl->equivClass() ;
   if (srcwords && eqclass != makeSymbol(WILDCARD_TOKEN))
      {
      free_object(morph->getNth(srcloc)) ;
      morph->setNth(srcloc,0) ; //FIXME: should insert new morph
      insert_replacement(srcwords,eqclass,repl->length()) ;
      }
   return ;
}

//----------------------------------------------------------------------

static void apply_replacement(const EbReplacement *repl, size_t srcloc,
			      FrList *srcwords, size_t trgloc,
			      FrList *trgwords, FrArray *morph,
			      BiTextMap *bitext, const size_t *wordmap,
			      FrList *&genseq)
{
   srcloc = wordmap[srcloc] ;
   srcwords = srcwords->nthcdr(srcloc) ;
   trgwords = trgwords->nthcdr(trgloc) ;
   FrSymbol *eqclass = repl->equivClass() ;
   if (srcwords && trgwords && eqclass != makeSymbol(WILDCARD_TOKEN))
      {
      free_object(morph->getNth(srcloc)) ;
      morph->setNth(srcloc,0) ; //FIXME: should insert new morph
      insert_replacement(srcwords,eqclass,repl->length()) ;
      insert_replacement(trgwords,eqclass,repl->targetLength()) ;
      pushlist(EbMakeGeneralizationSeq(eqclass,trgloc,repl->targetLength()),
	       genseq) ;
      if (bitext && srcloc < bitext->sourceLength() &&
	  trgloc < bitext->targetLength())
	 {
	 for (size_t src = 0 ; src < bitext->sourceLength() ; src++)
	    {
	    if (src == srcloc)
	       bitext->setCorrespondence(srcloc,trgloc) ;
	    else
	       bitext->clearCorrespondence(src,trgloc) ;
	    }
	 for (size_t trg = 0 ; trg < bitext->targetLength() ; trg++)
	    {
	    if (trg != trgloc)
	       bitext->clearCorrespondence(srcloc,trg) ;
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

bool EbReplacements::apply(FrList *&words, FrArray *morph,
			   const size_t *wordmap)
{
   bool generalized = false ;
   if (words)
      {
      sort() ;
      FrBitVector covered(arrayLength()) ;
      // scan left to right, greedily applying the longest replacement
      //   at each position
      size_t maxlen = 0 ;
      for (size_t i = 0 ; i < arrayLength() ; i++)
	 {
	 EbReplacement *repl = (EbReplacement*)getNth(i) ;
	 if (repl && repl->length() > maxlen)
	    maxlen = repl->length() ;
	 }
      size_t len ;
      for (len = maxlen ; len > 0 ; len--)
	 {
	 for (size_t i = 0 ; i <= arrayLength() - len ; i++)
	    {
	    EbReplacement *repl = (EbReplacement*)getNth(i) ;
	    for ( ; repl ; repl = repl->next())
	       {
	       if (repl->length() < len) // sorted by decreasing length
		  break ;		//   so can stop once length too short
	       else if (repl->length() > len || conflicts(repl,i,&covered))
		  continue ;
	       apply_replacement(repl,i,words,morph,wordmap) ;
	       covered.setRange(i,i+len-1) ;
	       generalized = true ;
	       break ;			// we can only apply once at this pos
	       }
	    }
	 }
      if (generalized)
	 {
	 // remove now-unused elements of the morphology information
	 size_t i = 0 ;
	 for (FrList *sw = words ; sw ; sw = sw->rest())
	    {
	    if (sw->first())
	       i++ ;
	    else
	       morph->elide(i,i) ;
	    }
	 // clean up the word list
	 words = FrFlattenListInPlace(words,true) ;
	 }
      }
   return generalized ;
}

//----------------------------------------------------------------------

bool EbReplacements::apply(FrList *&srcwords, FrList *&trgwords,
			   FrArray *morph, BiTextMap *bitext,
			   const size_t *wordmap, FrList *&genseq,
			   const EbAlignConstraints *constraints)
{
   bool generalized = false ;
   if (srcwords && trgwords)
      {
      sort() ;
      FrBitVector covered(arrayLength()) ;
      // scan left to right, greedily applying the longest replacement
      //   possible at each position
      // do so by first finding the longest replacement of all, then
      //   iterating from that length down to 1
      size_t maxlen = 0 ;
      for (size_t i = 0 ; i < arrayLength() ; i++)
	 {
	 EbReplacement *repl = (EbReplacement*)getNth(i) ;
	 if (repl && repl->length() > maxlen)
	    maxlen = repl->length() ;
	 }
      // look for unambiguous correspondences
      size_t len ;
      for (len = maxlen ; len > 0 ; len--)
	 {
	 for (size_t i = 0 ; i <= arrayLength() - len ; i++)
	    {
	    EbReplacement *repl = (EbReplacement*)getNth(i) ;
	    for ( ; repl ; repl = repl->next())
	       {
	       if (repl->length() < len) // sorted by decreasing length
		  break ;		//   so can stop once length too short
	       else if (repl->length() > len || conflicts(repl,i,&covered))
		  continue ;
	       size_t trgloc ;
	       if (!unique_replacement(repl,i,trgwords,bitext,wordmap,trgloc))
		  continue ;
	       apply_replacement(repl,i,srcwords,trgloc,trgwords,morph,bitext,
				 wordmap,genseq) ;
	       covered.setRange(i,i+len-1) ;
	       generalized = true ;
	       break ;			// we can only apply once at this pos
	       }
	    }
	 }
      // now, if there are any remaining generalization candidates, pick the
      //  ones that best fit the bitext mapping
      for (len = maxlen ; len > 0 ; len--)
	 {
	 for (size_t i = 0 ; i <= arrayLength() - len ; i++)
	    {
	    EbReplacement *repl = (EbReplacement*)getNth(i) ;
	    for ( ; repl ; repl = repl->next())
	       {
	       if (repl->length() < len) // sorted by decreasing length
		  break ;		//   so can stop once length too short
	       else if (repl->length() > len || conflicts(repl,i,&covered))
		  continue ;
	       size_t trgloc ;
	       if (!possible_replacement(repl,i,trgwords,bitext,wordmap,
					 trgloc))
		  continue ;
	       apply_replacement(repl,i,srcwords,trgloc,trgwords,morph,bitext,
				 wordmap,genseq) ;
	       covered.setRange(i,i+len-1) ;
	       generalized = true ;
	       break ;			// we can only apply once at this pos
	       }
	    }
	 }
      if (generalized)
	 {
	 // collapse away now-unused rows and columns of the bitext map
	 size_t i = 0 ;
	 for (FrList *sw = srcwords ; sw ; sw = sw->rest())
	    {
	    if (sw->first())
	       i++ ;
	    else
	       {
	       if (bitext)
		  bitext->elideSourceWord(i) ;
	       morph->elide(i,i) ;
	       }
	    }
	 i = 0 ;
	 for (FrList *tw = trgwords ; tw ; tw = tw->rest())
	    {
	    if (tw->first())
	       i++ ;
	    else if (bitext)
	       bitext->elideTargetWord(i) ;
	    }
	 if (bitext)
	    bitext->removeOutliers(constraints) ;
	 // clean up the source and target word lists
	 srcwords = FrFlattenListInPlace(srcwords,true) ;
	 trgwords = FrFlattenListInPlace(trgwords,true) ;
	 }
      }
   return generalized ;
}

//----------------------------------------------------------------------

void EbReplacements::sort()
{
   for (size_t i = 0 ; i < arrayLength() ; i++)
      {
      EbReplacement *repl = (EbReplacement*)m_array[i] ;
      if (repl)
	 m_array[i] = FrMergeSort(repl) ;
      }
   return ;
}

/************************************************************************/
/*	methods for class Tokenizer 					*/
/************************************************************************/

Tokenizer::Tokenizer(const char *filename)
{
   init() ;
   loadTokens(filename) ;
   return ;
}

//----------------------------------------------------------------------

void Tokenizer::init()
{
   m_regexlist = 0 ;
   m_tempcorpus = 0 ;
   m_tempdir = 0 ;
   m_pending = 0 ;
   return ;
}

//----------------------------------------------------------------------

Tokenizer::~Tokenizer()
{
   while (m_regexlist)
      {
      FrRegExp *regex = m_regexlist ;
      m_regexlist = m_regexlist->next() ;
      delete regex ;
      }
   if (m_tempcorpus)
      {
      m_tempcorpus->eraseCorpusFiles() ;
      delete m_tempcorpus ;
      m_tempcorpus = 0 ;
      if (m_tempdir)
	 {
	 (void)rmdir(m_tempdir) ;
	 FrFree(m_tempdir) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

bool Tokenizer::loadTokens(const char *filename)
{
   if (!filename || !*filename)
      return false ;			// can't load if no filename!
   FILE *tokenfp = fopen(filename,text_read_mode) ;
   if (tokenfp)
      {
      while (!feof(tokenfp))
	 {
	 char line[FrMAX_LINE] ;
	 if (fgets(line,sizeof(line),tokenfp) && !feof(tokenfp))
	    {
	    const char *lineptr = line ;
	    FrObject *src = string_to_FrObject(lineptr) ;
	    FrSymbol *tok = (FrSymbol*)string_to_FrObject(lineptr) ;
	    FrObject *replacement = string_to_FrObject(lineptr) ;
	    if (src && src->stringp())
	       {
	       const char *repl = FrPrintableName(replacement) ;
	       if (repl)
		  {
		  const char *regex = ((FrString*)src)->stringValue() ;
		  FrSymbol *token = FrCvt2Symbol(tok,char_encoding) ;
		  m_regexlist = new FrRegExp(regex,repl,token,m_regexlist) ;
		  }
	       else
		  FrWarning("missing replacement for *REGEX* in token file");
	       }
	    else
	       FrWarning("invalid value for REGEX in corpus token file") ;
	    free_object(src) ;
	    free_object(tok) ;
	    free_object(replacement) ;
	    }
	 }
      fclose(tokenfp) ;
      return true ;
      }
   else
      return false ;
}

//----------------------------------------------------------------------

bool Tokenizer::augmentDictionary(Dictionary *dict) const
{
   (void)dict;
   return false ;
}

//----------------------------------------------------------------------

FrSymbol *Tokenizer::regexGeneralization(const char *word,
					 FrCasemapTable number_charmap,
					 FrString *&translation) const
{
   if (word)
      {
      for (const FrRegExp *re = m_regexlist ; re ; re = re->next())
	 {
	 translation = (FrString*)re->match(word) ;
	 if (translation)
	    return re->token() ;
	 }
      // no regular expression match, but we might still be able to match
      //   it as a generic digit-string number
      if (is_number(word))
	 {
	 if (number_charmap)
	    {
	    char newnum[FrMAX_SYMBOLNAME_LEN+2] ;
	    strncpy(newnum,word,sizeof(newnum)) ;
	    newnum[sizeof(newnum)-1] = '\0' ;
	    FrMapString(newnum,number_charmap) ;
	    translation = new FrString(newnum) ;
	    }
	 else
	    translation = new FrString(word) ;
	 return FrSymbolTable::add(NUMBER_TOKEN) ;
	 }
      }
   // if we get here, there was no regular expression that matches the word
   translation = 0 ;
   return 0 ;
}

//----------------------------------------------------------------------

static void accumulate_generalizations(TokenInfo **tokens,
				       size_t full_len,
				       EbReplacements &replacements,
				       FrVocabulary *vocab)
{
   vocab->createReverseMapping() ;
   for (size_t i = 0 ; i < full_len ; i++)
      {
      for (const TokenInfo *tok = tokens[i] ; tok ; tok = tok->next())
	 {
	 if (tok->isToken() &&
	     tok->equivalenceClass() != FrVOCAB_WORD_NOT_FOUND)
	    {
	    const char *eqv = vocab->nameForID(tok->equivalenceClass()) ;
	    if (!eqv)
	       continue ;
	    FrSymbol *eqclass = FrSymbolTable::add(eqv) ;
	    FrList *source = 0 ; 
	    FrList **end = &source ;
	    for (size_t w = 0 ; w < tok->sourceWords() ; w++)
	       {
	       uint32_t id = tok->wordID(w) ;
	       const char *name = vocab->nameForID(id) ;
	       if (!name)
		  {
		  name = "<?>" ;
		  }
	       FrSymbol *word = FrSymbolTable::add(name) ;
	       source->pushlistend(word,end) ;
	       }
	    *end = 0 ;
	    if (tok->translations())
	       {
	       bool multi = false ;
	       for (const FrList *translations = tok->translations() ;
		    translations ;
		    translations = translations->rest())
		  {
		  FrString *tr = (FrString*)translations->first() ;
		  FrList *trans = 0 ;
		  if (tr)
		     trans = FrCvtSentence2Wordlist(tr->stringValue()) ;
		  FrList *src = multi ? (FrList*)source->deepcopy() : source ; 
		  replacements.add(i,tok->inputWords(),eqclass,src,trans) ;
		  multi = true ;
		  }
	       }
	    else
	       replacements.add(i,tok->inputWords(),eqclass,source,0) ;
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

static void copy_morphology(FrArray *morph, const FrTextSpans *lattice)
{
   for (size_t i = 0 ; i < lattice->spanCount() ; i++)
      {
      const FrTextSpan *span = lattice->getSpan(i) ;
      if (span)
	 {
	 free_object(morph->getNth(i)) ;
	 morph->setNth(i,span->metaData()) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

FrList *Tokenizer::tokenize(FrTextSpans *stext,
			    const FrList *targetwords,
			    EBMTCorpus *corpus, BiTextMap *bitext) const
{
   FrList *twords = targetwords ? (FrList*)targetwords->deepcopy() : 0 ;
   if (!stext || stext->textLength() == 0)
      return new FrList(0,twords,0,0) ;
   size_t full_len = stext->textLength() ;
   // active chunks will be split into N lists in an array, indexed by the
   //    END of the chunk in the original untokenized input
   FrLocalAllocC(TokenInfo*,tokens,1024,full_len+1) ;
   if (!tokens)
      {
      FrNoMemory("building token information array") ;
      free_object(twords) ;
      return 0 ;
      }
   FrList *swords = stext->wordList() ;
   FrArray *morph = new FrArray(swords->simplelistlength()) ;
   copy_morphology(morph,stext) ;
   FrList *genseq = 0 ;
   if (!corpus)
      corpus = m_tempcorpus ;
   if (corpus)
      {
      EBMTIndex *index = corpus->getIndex() ;
      EBMTCandidate *matches = find_generalized_chunks(stext,corpus,this,
						       tokens,
						       index->numberCharMap(),
						       targetwords);
      if (matches)
	 {
	 EbReplacements replacements(stext->textLength()) ;
	 // insert the tokens we've found as replacements
	 accumulate_generalizations(tokens,full_len,replacements,
				    index->vocabulary()) ;
	 size_t *wordmap = stext->wordMapping(true) ;
	 // then apply the best possible set of replacements to the
	 //  sentence pair
	 (void)replacements.apply(swords,twords,morph,bitext,wordmap,
				  genseq,corpus->alignConstraints()) ;
	 FrFree(wordmap) ;
	 }
      matches->deleteList() ;
      for (size_t location = 0 ; location < full_len ; location++)
	 {
	 delete tokens[location] ;
	 tokens[location] = 0 ;
	 }
      }
   FrLocalFree(tokens) ;
   return new FrList(swords,twords,morph,genseq) ;
}

//----------------------------------------------------------------------

FrList *Tokenizer::tokenize(FrTextSpans *stext, EBMTCorpus *corpus) const
{
   if (!stext || stext->textLength() == 0)
      return new FrList(0,0) ;
   size_t full_len = stext->textLength() ;
   // active chunks will be split into N lists in an array, indexed by the
   //    END of the chunk in the original untokenized input
   FrLocalAllocC(TokenInfo*,tokens,1024,full_len+1) ;
   if (!tokens)
      {
      FrNoMemory("building token information array") ;
      return 0 ;
      }
   EBMTIndex *index = corpus->getIndex() ;
   EBMTCandidate *matches = find_generalized_chunks(stext,corpus,this,tokens,
						    index->numberCharMap(),
						    0);
   FrList *swords = stext->wordList() ;
   FrArray *morph = new FrArray(swords->simplelistlength()) ;
   copy_morphology(morph,stext) ;
   if (matches)
      {
      EbReplacements replacements(stext->textLength()) ;
      // insert the tokens we've found as replacements
      accumulate_generalizations(tokens,full_len,replacements,
				 index->vocabulary()) ;
      size_t *wordmap = stext->wordMapping(true) ;
      // then apply the best possible set of replacements to the sentence pair
      (void)replacements.apply(swords,morph,wordmap) ;
      FrFree(wordmap) ;
      }
   matches->deleteList() ;
   for (size_t location = 0 ; location < full_len ; location++)
      {
      delete tokens[location] ;
      tokens[location] = 0 ;
      }
   FrLocalFree(tokens) ;
   return new FrList(swords,morph) ;
}

//----------------------------------------------------------------------

// end of file ebtoken.cpp //
