/************************************************************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebdict.cpp	EBMT translation dictionary			*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2006,2007,2008,2009 Ralf Brown				*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#if defined(__GNUC__)
#  pragma implementation "dict.h"
#  pragma implementation "ebdict.h"
#endif

#include "dict.h"
#include "ebdict.h"
#include "ebutil.h"
#include "ebglobal.h"

/************************************************************************/
/************************************************************************/

/*
   Old Dictionary File format:
	line 1:	 signature "Pangloss-Lite Dictionary (Format 1)"
	line 2:	 number of definition lines (ASCII)
	N lines: individual definitions (eg. WORD or (A PHRASE), not full xlat)
	line J:	 blank line as separator
	binary data: signature + words + compacted definition lists

   Binary Data format:
	9 BYTEs	  ASCIZ signature "@!DEFS!@"
	  DWORD	  number of words defined
	  DWORD	  number of definition list entries ('K')
	N BYTEs	  word entries
       6K BYTEs	  definition list entries

   Word entry:
	  DWORD	  entry number of start of word's definition list
	  BYTE	  length of following name for word
	N BYTEs	  name of word (append NUL for use by makeSymbol)

   Definition List entry:
	3 BYTEs	  translation index +
		 bit 23: flag -- end of definition list
		 bits 22-20: case
		 	000 unknown/other
			001 nominative
			010 genitive
			011 dative
			100 accusative
			101 locative
			110 instrumental
			111 vocative
		 bits 19-0: index into definition table (0-1M)
	3 BYTEs	  occurrence count +
		 bits 23-20: word's part of speech for this translation
		       0000 unknown
		       0001 Noun
		       0010 Verb
		       0011 Adjective
		       0100 Adverb
		       0101 Conjunction
		       0110 Determiner
		       0111 Preposition
		       1000 Post-Modifier
		       ...
		 bits 19-0: number of occurrences of this particular xlation

===========
   New Dictionary File format:
	line 1: signature "Pangloss-Lite Dictionary (Format 2)"
	       plus optional comment "; This is a binary file.  DO NOT EDIT."
	line 2: number of definition lines (ASCII)
	N lines: individual definitions, as in V1
	blank line as separator
	binary data: signature + word info + compacted definition lists + words

   Binary Data format:
	9  BYTEs  ASCIZ signature "@!DEFS!@"
	   DWORD  number of words defined ('W')
	   DWORD  number of definition list entries ('K')
	9W BYTEs  word entries (i'th one corresponds to i'th line of headwords)
	6K BYTEs  definition list entries
	   DWORD  number of bytes in following headword names
	 W ASCIZ  headwords
      
   Word entry:
        BYTE[3] offset of word name in headwords list
	BYTE[3]	entry number of start of word's definition list
	BYTE[3]	total frequency of word in training corpus

   Definition List entry:  as for V1

===========
   Newer Dictionary File format:
   	same as V2, except 12W BYTEs for word entries and
	7K BYTEs for definition list entries, and 
	line 1: signature "Pangloss-Lite Dictionary (Format 3)"

   Word entry in V3:
        LONG  offset of word name in headwords list
	LONG  entry number of start of word's definition list
	LONG  total frequency of word in training corpus

   Definition List entry in V3:
	3 BYTEs	  translation index +
		 bit 23: flag -- end of definition list
		 bits 22-0: index into definition table (0-8M)
	4 BYTEs	  occurrence count +
		 bits 31-29: case
		 	000 unknown/other
			001 nominative
			010 genitive
			011 dative
			100 accusative
			101 locative
			110 instrumental
			111 vocative
		 bits 28-25: word's part of speech for this translation
		       0000 unknown
		       0001 Noun
		       0010 Verb
		       0011 Adjective
		       0100 Adverb
		       0101 Conjunction
		       0110 Determiner
		       0111 Preposition
		       1000 Post-Modifier
		       ...
		 bits 24-0: number of occurrences of this particular xlation

*/

/************************************************************************/
/*	Manifest Constants						*/
/************************************************************************/

#define DICTIONARY_SIGNATURE "Pangloss-Lite Dictionary (Format 1)"
#define DICTIONARY_SIGNATURE2 "Pangloss-Lite Dictionary (Format 2)"
#define DICTIONARY_SIGNATURE3 "Pangloss-Lite Dictionary (Format 3)"
#define DICT_BINARY_SIGNATURE "@!DEFS!@"

#define MAX_LINE 16384

/************************************************************************/
/*	Types for this module						*/
/************************************************************************/

/************************************************************************/
/*	Global data							*/
/************************************************************************/

static const char tmp_extension[] = "tmp" ;

static const char errmsg_nomem_loading[] = "while loading dictionary" ;
static const char errmsg_corrupted[] =
   "Dictionary file corrupted or not a valid dictionary" ;

Dictionary *Dictionary::dictionaries = 0 ;

const char *DictWordInfo::names = 0 ;

static bool Initialized = false ;
static Dictionary *dictionary = 0 ;

/************************************************************************/
/*	Helper Functions						*/
/************************************************************************/

//----------------------------------------------------------------------

static FrSymbol *make_CASE_symbol(int CASE)
{
   switch (CASE)
      {
      case CASE_unknown:
	 return 0 ;
      case CASE_nominative:
	 return makeSymbol("NOM") ;
      case CASE_genitive:
	 return makeSymbol("GEN") ;
      case CASE_dative:
	 return makeSymbol("DAT") ;
      case CASE_accusative:
	 return makeSymbol("ACC") ;
      case CASE_locative:
	 return makeSymbol("LOC") ;
      case CASE_vocative:
	 return makeSymbol("VOC") ;
      case CASE_instrumental:
	 return makeSymbol("INS") ;
      default:
	 return 0 ;			// unknown case marker
      }
}

//----------------------------------------------------------------------

static FrSymbol *make_POS_symbol(int POS)
{
   switch (POS)
      {
      case POS_unknown:
	 return 0 ;
      case POS_Noun:
	 return makeSymbol("NOUN") ;
      case POS_Verb:
	 return makeSymbol("VERB") ;
      case POS_Adjective:
	 return makeSymbol("ADJ") ;
      case POS_Adverb:
	 return makeSymbol("ADV") ;
      case POS_Conjunction:
	 return makeSymbol("CONJ") ;
      case POS_Determiner:
	 return makeSymbol("DET") ;
      case POS_Preposition:
	 return makeSymbol("PREP") ;
      case POS_Postmod:
	 return makeSymbol("POSTMOD") ;
      default:
	 return 0 ;			// unknown POS marker
      }
}

//----------------------------------------------------------------------

static void fix_penultimate_period(FrObject *obj)
{
   if (obj && obj->consp())
      {
      // Lists containing a period in the next-to-last position get
      // read as a dotted list, which we need to turn back into a list
      // containing an actual period
      FrList *last = (FrList*)obj ;
      FrList *next ;
      while ((next = last->rest()) != 0 && next->consp())
	 last = next ;
      if (last->rest()) // dotted list?
	 last->replacd(new FrList(symPERIOD,last->rest())) ;
      }
   return ;
}

/************************************************************************/
/*	Methods for class DictWordInfo					*/
/************************************************************************/

DictWordInfo::DictWordInfo(size_t offset, uint32_t index, uint32_t freq)
{
   setNameOffset(offset) ;
   setIndex(index) ;
   setFrequency(freq) ;
   return ;
}

//----------------------------------------------------------------------

void DictWordInfo::incrFreq(uint32_t incr)
{
   setFrequency(frequency() + incr) ;
   return ;
}

/************************************************************************/
/*	Methods for class DictDefItem					*/
/************************************************************************/

DictDefItem::DictDefItem(size_t count, size_t def_index, int POS,
			 int CASE, bool is_last)
{
   if (count > DICT_MAX_COUNT)
      count = DICT_MAX_COUNT ;
#ifdef DICT_V3
   uint32_t occ = (((POS << DICT_POS_SHIFT) & DICT_POS_MASK) |
		   ((CASE << DICT_CASE_SHIFT) & DICT_CASE_MASK) |
		   (count & DICT_COUNT_MASK)) ;
   uint32_t idx = (def_index & DICT_INDEX_MASK) ;
#else
   uint32_t occ = (((POS << DICT_POS_SHIFT) & DICT_POS_MASK) |
		   (count & DICT_COUNT_MASK)) ;
   uint32_t idx = (((CASE << DICT_CASE_SHIFT) & DICT_CASE_MASK) |
		   (def_index & DICT_INDEX_MASK)) ;
#endif /* DICT_V3 */
   if (is_last)
      idx |= DICT_LAST_MASK ;
   FrStoreThreebyte(idx,m_index) ;
   FrStoreThreebyte(occ,m_occur) ;
   return ;
}

//----------------------------------------------------------------------

uint32_t DictDefItem::getCount() const
{
#ifdef DICT_V3
   return FrLoadLong(m_occur) & DICT_COUNT_MASK ;
#else
   return FrLoadThreebyte(m_occur) & DICT_COUNT_MASK ;
#endif /* DICT_V3 */
}

//----------------------------------------------------------------------

const FrObject *DictDefItem::getDef(FrObject **defs) const
{
   size_t def_index = FrLoadThreebyte(m_index) & DICT_INDEX_MASK ;
   return defs[def_index] ;
}

//----------------------------------------------------------------------

size_t DictDefItem::getDefIndex() const
{
   return FrLoadThreebyte(m_index) & DICT_INDEX_MASK ;
}

//----------------------------------------------------------------------

void DictDefItem::incrCount()
{
#ifdef DICT_V3
   uint32_t value = FrLoadThreebyte(m_occur) ;
#else
   uint32_t value = FrLoadLong(m_occur) ;
#endif /* DICT_V3 */
   uint32_t count = value & DICT_COUNT_MASK ;
   if (count < DICT_MAX_COUNT)
      {
      count++ ;
      value &= ~DICT_COUNT_MASK ;
      value |= count ;
#ifdef DICT_V3
      FrStoreLong(value,m_occur) ;
#else
      FrStoreThreebyte(value,m_occur) ;
#endif /* DICT_V3 */
      }
   return ;
}

//----------------------------------------------------------------------

void DictDefItem::setCount(uint32_t newcount)
{
#ifdef DICT_V3
   uint32_t value = FrLoadLong(m_occur) ;
#else
   uint32_t value = FrLoadThreebyte(m_occur) ;
#endif /* DICT_V3 */
   if (newcount > DICT_MAX_COUNT)
      newcount = DICT_MAX_COUNT ;
   value = (value & ~DICT_COUNT_MASK) | (newcount & DICT_COUNT_MASK) ;
#ifdef DICT_V3
   FrStoreLong(value,m_occur) ;
#else
   FrStoreThreebyte(value,m_occur) ;
#endif /* DICT_V3 */
   return ;
}

//----------------------------------------------------------------------

void DictDefItem::setPOS(int POS)
{
   m_occur[0] &= ~DICT_POS_MASK0 ;	// mask out previous part of speech
   m_occur[0] |= (char)((POS << DICT_POS_SHIFT0) & DICT_POS_MASK0) ;
   return ;
}

//----------------------------------------------------------------------

void DictDefItem::setCase(int CASE)
{
#ifdef DICT_V3
   m_occur[0] &= ~DICT_CASE_MASK0 ;	// mask out previous part of speech
   m_occur[0] |= (char)((CASE << DICT_CASE_SHIFT0) & DICT_CASE_MASK0) ;
#else
   m_index[0] &= ~DICT_CASE_MASK0 ;	// mask out previous part of speech
   m_index[0] |= (char)((CASE << DICT_CASE_SHIFT0) & DICT_CASE_MASK0) ;
#endif /* DICT_V3 */
   return ;
}

/************************************************************************/
/*	Methods for class DictionaryEntry				*/
/************************************************************************/

int DictionaryEntry::compare(DictionaryEntry &x, DictionaryEntry &y)
{ 
   double diff = x.probability() - y.probability() ; 
   if (diff > 0.0)
      return -1 ;
   else if (diff < 0.0)
      return +1 ;
   // phrases should sort before single words if they have the same score
   const FrObject *trans1 = x.translation() ;
   bool phrase1 = (trans1 && trans1->consp() && ((FrList*)trans1)->rest()) ;
   const FrObject *trans2 = y.translation() ;
   bool phrase2 = (trans2 && trans2->consp() && ((FrList*)trans2)->rest()) ;
   if (phrase1 && !phrase2)
      return -1 ;
   else if (!phrase1 && phrase2)
      return +1 ;
   return 0 ;
}

/************************************************************************/
/*	Methods for class Dictionary					*/
/************************************************************************/

void Dictionary::init(bool complete)
{
   dictfile = 0 ;
   defs = 0 ;
   defs_size = 0 ;
   numdefs = 0 ;
   availdefs = 0 ;
   defhash = 0 ;
   definition_size = 0 ;
   definition_items = 0 ;
   numheads = 0 ;
   heads_size = 0 ;
   headinfo = 0 ;
   names_size = 0 ;
   names_alloc = 0 ;
   headwordnames = 0 ;
   mapped_dict = 0 ;
   readonly = false ;
   heads_mapped = false ;
   names_mapped = false ;
   definitions_mapped = false ;
   _good = false ;
   if (complete)
      {
      next_dict = dictionaries ;
      prev_dict_next = &dictionaries ;
      if (dictionaries)
	 dictionaries->prev_dict_next = &next_dict ;
      dictionaries = this ;
      refcount = 1 ;
      definitions = FrNewC(DictDefItem,DEFINITION_SLACK) ;
      if (definitions)
	 definition_size = DEFINITION_SLACK ;
      }
   else
      {
      definitions = 0 ;
      }
   return ;
}

//----------------------------------------------------------------------

Dictionary::Dictionary()
{
   init() ;
   dict_changed = false ;
   return ;
}

//----------------------------------------------------------------------

Dictionary::Dictionary(const char *filename, bool load_readonly)
{
   init() ;
   load(filename,load_readonly) ;
   dict_changed = false ;
   return ;
}

//----------------------------------------------------------------------

Dictionary::~Dictionary()
{
   save() ;
   delete defhash ;
   FrFree(dictfile) ;
   dictfile = 0 ;
   if (!mapped_dict)
      {
      for (size_t i = 0 ; i < numdefs ; i++)
	 free_object(defs[i]) ;
      }
   FrFree(defs) ;
   defs = 0 ;
   if (!heads_mapped)
      FrFree(headinfo) ;
   headinfo = 0 ;
   if (!definitions_mapped)
      FrFree(definitions) ;
   definitions = 0 ;
   if (!names_mapped)
      FrFree(headwordnames) ;
   headwordnames = 0 ;
   FrUnmapFile(mapped_dict) ;
   mapped_dict = 0 ;
   if (next_dict)
      next_dict->prev_dict_next = prev_dict_next ;
   *prev_dict_next = next_dict ;
   return ;
}

//----------------------------------------------------------------------

bool Dictionary::load(const char *filename, bool load_readonly)
{
   if (filename && *filename)
      {
      size_t i = 0 ;
      if (defs)
	 {
	 for (size_t d = 0 ; d < numdefs ; d++)
	    free_object(defs[d]) ;
	 FrFree(defs) ;
	 }
      if (!mapped_dict)
	 {
	 FrFree(definitions) ;
	 FrFree(headwordnames) ;
	 }
      FrFree(dictfile) ;
      FrFree(headinfo) ;
      init(false) ;
      dictfile = FrDupString(filename) ;
      if (!dictfile)
	 {
	 FrNoMemory(errmsg_nomem_loading) ;
	 return false ;
	 }
      readonly = load_readonly ;
      mapped_addr = 0 ;
      if (!FrFileExists(filename))
	 {
	 dict_changed = true ;
	 save() ;
	 }
      if (!FrFileWriteable(filename)) // read-only data file?
	 readonly = true ;
      FILE *in = fopen(filename,FrFOPEN_READ_MODE) ;
      if (!in)
	 return false ;
      if (allow_memory_mapping)
	 {
	 mapped_dict = FrMapFile(dictfile,FrM_READONLY) ;
	 if (mapped_dict)
	    {
	    mapped_addr = FrMappedAddress(mapped_dict) ;
	    end_mapping = ((char*)mapped_addr) + FrMappingSize(mapped_dict) ;
	    }
	 }
      else
	 mapped_dict = 0 ;
      size_t slack = readonly ? 0 : DICTIONARY_SLACK ;
      size_t number_of_words = 0 ;
      size_t buflen ;
      dict_changed = false ;
      char line[MAX_LINE+1]	;
      line[0] = '\0' ;		// catch EOF
      fgets(line,MAX_LINE,in) ;	// get file signature
      line[sizeof(DICTIONARY_SIGNATURE)-1] = '\0' ; // strip trailing \n
      if (feof(in) || 
	  (strcmp(line,DICTIONARY_SIGNATURE) != 0 &&
	   strcmp(line,DICTIONARY_SIGNATURE2) != 0 &&
	   strcmp(line,DICTIONARY_SIGNATURE3) != 0))
	 goto corrupted ;
      if (strcmp(line,DICTIONARY_SIGNATURE) == 0
#ifdef DICT_V3
	  || strcmp(line,DICTIONARY_SIGNATURE2) == 0
#endif /* DICT_V3 */
	 )
	 {
	 FrWarningVA("obsolete dictionary format in %s",filename) ;
	 goto error_exit ;
	 }
      line[0] = '\0' ;		// catch EOF
      fgets(line,MAX_LINE,in) ;	// get number of definition lines
      char *end ;
      numdefs = (size_t)strtol(line,&end,10) ;
      if (feof(in) || end == line)
	 goto corrupted ;
      defs_size = numdefs ;
      if (!mapped_addr)
	 {
	 defs_size += DICTIONARY_SLACK ;
	 FrSymbolTable::current()->expandTo(defs_size) ;
	 }
      defs = FrNewC(FrObject*,defs_size) ;
      if (!defs)
	 goto nomem_loading ;
      for (i = 0 ; i < numdefs ; i++)
	 {
	 char *rawdef = ((char*)mapped_addr) + ftell(in) ;
	 line[0] = '\0' ;		// catch EOF
	 fgets(line,MAX_LINE,in) ;	// get next definition
	 const char *l = line ;
	 if (feof(in))
	    goto corrupted ;
	 else if (line[0] == '\n')
	    break ;
	 if (mapped_addr)
	    defs[i] = (FrObject*)rawdef ;	// cvt translations as needed
	 else
	    {
	    defs[i] = string_to_FrObject(l) ;
	    fix_penultimate_period(defs[i]) ;
	    }
	 }
      fgets(line,MAX_LINE,in) ;	// blank line as separator
      if (feof(in) || (line[0] != '\n' && line[0] != '\r'))
	 goto corrupted ;
      (void)Fr_fread(line,sizeof(DICT_BINARY_SIGNATURE),in) ;
      LONGbuffer num_words, num_defs ;
      if (feof(in) ||
	  memcmp(line,DICT_BINARY_SIGNATURE,
		 sizeof(DICT_BINARY_SIGNATURE)) != 0 ||
	  !Fr_fread_var(num_words,in) || !Fr_fread_var(num_defs,in))
	 goto corrupted ;
      number_of_words = FrLoadLong(num_words) ;
      definition_size = definition_items = FrLoadLong(num_defs) ;
      // load the words into the hash table
      if (mapped_dict)
	 {
	 headinfo = (DictWordInfo*)(((char*)mapped_addr) + ftell(in)) ;
	 fseek(in,number_of_words*sizeof(DictWordInfo),SEEK_CUR) ;
	 heads_size = number_of_words ;
	 numheads = number_of_words ;
	 heads_mapped = true ;
	 }
      else
	 {
	 headinfo = FrNewN(DictWordInfo,number_of_words + slack) ;
	 if (!headinfo)
	    goto nomem_loading ;
	 if (Fr_fread_array(headinfo,number_of_words,in))
	    {
	    heads_size = number_of_words + slack ;
	    numheads = number_of_words ;
	    }
	 else
	    goto corrupted ;
	 }
      if (mapped_dict)
	 {
	 char *d = ((char*)FrMappedAddress(mapped_dict)) + ftell(in) ;
	 definitions = (DictDefItem*)d ;
	 fseek(in,definition_items*sizeof(DictDefItem),SEEK_CUR) ;
	 definitions_mapped = true ;
	 }
      else
	 {
	 definitions = FrNewC(DictDefItem,definition_size) ;
	 if (!definitions)
	    {
	    definition_size = 0 ;
	    goto nomem_loading ;
	    }
	 if (!Fr_fread_array(definitions,definition_items,in))
	    goto corrupted ;
	 }
      // load the actual headword names
      LONGbuffer namebuflength ;
      if (!Fr_fread_var(namebuflength,in))
	 goto corrupted ;
      buflen = FrLoadLong(namebuflength) ;
      if (mapped_dict)
	 {
	 off_t offset = ftell(in) ;
	 fseek(in,buflen,SEEK_CUR) ;
	 if (ftell(in) != (off_t)(offset + buflen))
	    goto corrupted ;
	 headwordnames = ((char*)FrMappedAddress(mapped_dict)) + offset ;
	 names_size = buflen ;
	 names_alloc = buflen ;
	 names_mapped = true ;
	 }
      else
	 {
	 headwordnames = FrNewN(char,buflen + HEADNAMES_INCR) ;
	 if (!headwordnames)
	    goto nomem_loading ;
	 if (!Fr_fread_array(headwordnames,buflen,in))
	    goto corrupted ;
	 names_size = buflen ;
	 names_alloc = buflen + HEADNAMES_INCR ;
	 }
      fclose(in) ;
      _good = true ;
      if (!_good)
	 {
//	 const char *msg = 0 ;
corrupted:
	 FrWarning(errmsg_corrupted) ;
error_exit:
	 fclose(in) ;
	 _good = false ;
	 return false ;
nomem_loading:
	 FrNoMemory(errmsg_nomem_loading) ;
	 goto error_exit ;
	 }
      }
   DcLoadWordstems(dict_stems_file) ;
   return true ;
}

//----------------------------------------------------------------------

bool Dictionary::save()
{
   bool success = true ;
   if (dict_changed)
      {
      if (!dictfile)
	 return false ;
      char *tmpname = FrForceFilenameExt(dictfile,tmp_extension) ;
      FILE *out = fopen(tmpname,FrFOPEN_WRITE_MODE) ;
      if (out)
	 {
#ifdef DICT_V3
	 fputs(DICTIONARY_SIGNATURE3,out) ;
#else
	 fputs(DICTIONARY_SIGNATURE2,out) ;
#endif /* DICT_V3 */
	 fprintf(out," ; This is a binary file.  DO NOT EDIT.\n%ld\n",
		 (long)numdefs) ;
	 size_t i ;
	 for (i = 0 ; i < numdefs ; i++)
	    {
	    char line[MAX_LINE+2] ;
	    if (mapped_addr && defs[i] >= mapped_addr && defs[i] < end_mapping)
	       {
	       char *end = FrTruncationPoint((char*)defs[i],'\n') ;
	       size_t len = end - (char*)defs[i] ;
	       if (len >= sizeof(line))
		  len = sizeof(line) - 1 ;
	       memcpy(line,(char*)defs[i],len) ;
	       line[len] = '\0' ;
	       }
	    else
	       defs[i]->print(line) ;
	    if (!*line)
	       strcpy(line,"||") ;
	    if (fputs(line,out) == EOF)	// error, such as disk full?
	       {
	       success = false ;
	       break ;
	       }
	    fputc('\n',out) ;
	    }
	 fputc('\n',out) ;		// blank line as separator
	 LONGbuffer num_words, num_defs ;
	 FrStoreLong(definition_items,num_defs) ;
	 FrStoreLong(numheads,num_words) ;
	 if (!Fr_fwrite_var(DICT_BINARY_SIGNATURE,out) ||
	     !Fr_fwrite_var(num_words,out) ||
	     !Fr_fwrite_var(num_defs,out))
	    success = false ;
	 // store the info for the individual SL words
	 if (success && numheads > 0 &&
	     !Fr_fwrite_array(headinfo,numheads,out))
	    success = false ;
	 // store the definition lists
	 if (success && definition_items > 0 &&
	     !Fr_fwrite_array(definitions,definition_items,out))
	    success = false ;
	 LONGbuffer namebuflength ;
	 FrStoreLong(names_size,namebuflength) ;
	 if (success && !Fr_fwrite_var(namebuflength,out))
	    success = false ;
	 // and finally, store the head words themselves
	 if (success && !Fr_fwrite(headwordnames,names_size,out))
	    success = false ;
	 fflush(out) ;
	 fclose(out) ;
	 if (success)
	    {
	    if (FrSafelyReplaceFile(tmpname,dictfile))
	       dict_changed = false ;
	    }
	 else
	    Fr_unlink(tmpname) ;
	 }
      else
	 success = false ;
      FrFree(tmpname) ;
      }
   return success ;
}

//----------------------------------------------------------------------

const char *Dictionary::wordName(size_t wordnum) const
{
   return headwordnames + headinfo[wordnum].nameOffset() ;
}

//----------------------------------------------------------------------

Dictionary *Dictionary::findDictionary(const char *filename)
{
   for (Dictionary *d = dictionaries ; d ; d = d->next())
      {
      if (FrSameFile(filename,d->dictfile))
	 return d ;
      }
   // if we get to this point, the requested dictionary is not in memory
   return 0 ;
}

//----------------------------------------------------------------------

Dictionary *Dictionary::open(const char *filename, bool load_readonly)
{
   if (!filename || !*filename)
      return new Dictionary() ;
   Dictionary *dict = findDictionary(filename) ;
   if (dict)
      dict->addReference() ;
   else
      dict = new Dictionary(filename,load_readonly) ;
   return dict ;
}

//----------------------------------------------------------------------

bool Dictionary::close()
{
   if (refcount <= 1)
      {
      delete this ;
      return true ;
      }
   refcount-- ;
   return true ;
}

//----------------------------------------------------------------------

bool Dictionary::exportDict(const char *filename)
{
   if (filename && *filename)
      {
      FILE *fp ;
      if (strcmp(filename,"-") == 0)
	 fp = stdout ;
      else
	 fp = fopen(filename,"w") ;
      if (fp)
	 {
	 fputs("; Pangloss-Lite translation dictionary (exported to text)\n",
	       fp) ;
	 for (size_t i = 0 ; i < numheads ; i++)
	    {
	    FrSymbol *word = makeSymbol(wordName(i)) ;
	    char wordstr[FrMAX_SYMBOLNAME_LEN+3] ;
	    word->print(wordstr) ;
	    fprintf(fp,"(%s %lu",wordstr,
		    (unsigned long)headinfo[i].frequency()) ;
	    for (size_t j = headinfo[i].index() ; j < definition_items ; j++)
	       {
	       bool is_copy ;
	       FrObject *d = retrieveTranslation(&definitions[j],false,
						 &is_copy) ;
	       if (d)
		  {
		  char *translation = d->print() ;
		  fprintf(fp,"(%s %ld)",translation,
			  (long)definitions[j].getCount()) ;
		  if (is_copy)
		     d->freeObject() ;
		  }
	       if (definitions[j].isLast())
		  break ;
	       }
	    fputs(")\n",fp) ;
	    }
	 if (fp != stdout)
	    fclose(fp) ;
	 }
      }
   return true ;			// successfully exported as requested
}

//----------------------------------------------------------------------

size_t Dictionary::getIndex(const FrObject *definition)
{
   if (!defhash)
      {
      // the first time we add something to the dictionary, construct a
      // hash table for quick lookups
      defhash = new FrHashTable ;
      if (!defhash)
	 {
	 FrNoMemory("indexing dictionary translations") ;
	 return (size_t)-1 ;
	 }
      defhash->expandTo(numdefs+DICTIONARY_SLACK) ;
      for (size_t i = 0 ; i < numdefs ; i++)
	 {
	 bool is_copy ;
         FrObject *trans = retrieveTranslation(i,false,&is_copy) ;
	 FrHashEntryObject item(trans,(void*)i) ;
	 defhash->add(&item) ;
	 if (is_copy)
	    free_object(trans) ;
	 }
      }
   FrHashEntryObject key(definition) ;
   FrHashEntryObject *entry = (FrHashEntryObject*)defhash->lookup(&key) ;
   if (entry)
      return (size_t)entry->getUserData() ;
   else
      return (size_t)-1 ;
}

//----------------------------------------------------------------------

size_t Dictionary::definition_length(size_t index) const
{
   size_t len = 0 ;
   for (size_t i = index ; i < definition_items ; i++)
      {
      len++ ;
      if (definitions[i].isLast())
	 break ;
      }
   return len ;
}

//----------------------------------------------------------------------

size_t Dictionary::findWord(const char *word) const
{
   if (numheads == 0 || strcmp(word,wordName(0)) < 0)
      return FrVOCAB_WORD_NOT_FOUND ;
   size_t lo = 0 ;
   size_t hi = numheads ;
   do {
      size_t mid = (hi + lo) / 2 ;
      int cmp = strcmp(word,wordName(mid)) ;
      if (cmp > 0)
	 lo = mid+1 ;
      else if (cmp < 0)
	 hi = mid ;
      else
	 return mid ;
      } while (hi > lo) ;
   return FrVOCAB_WORD_NOT_FOUND ;
}

//----------------------------------------------------------------------

size_t Dictionary::insertionPoint(const char *name) const
{
   if (numheads == 0 || strcmp(name,wordName(0)) <= 0)
      return 0 ;
   size_t lo = 0 ;
   size_t hi = numheads ;
   do {
      size_t mid = (hi + lo) / 2 ;
      int cmp = strcmp(name,wordName(mid)) ;
      if (cmp > 0)
	 lo = mid+1 ;
      else
	 hi = mid ;
      } while (hi > lo) ;
//   assertq(lo == N || strcmp(name,wordName(lo)) <= 0) ;
   return lo ;
}

//----------------------------------------------------------------------

static int compare_freq(const FrObject *o1, const FrObject *o2)
{
   const FrList *xlat_1 = (FrList*)o1 ;
   const FrList *xlat_2 = (FrList*)o2 ;
   const FrObject *count_1 = xlat_1->second() ;
   const FrObject *count_2 = xlat_2->second() ;
   long c1 = count_1 ? count_1->intValue() : -1 ;
   long c2 = count_2 ? count_2->intValue() : -1 ;
   return (c1 < c2) ? -1 : (c1 > c2 ? +1 : 0) ;
}

//----------------------------------------------------------------------

DictionaryEntry *Dictionary::lookupProbabilities(const char *word,
						 size_t &numtrans,
						 double smoothing,
						 int wanted_POS) const
{
   size_t entry_index = findWord(word) ;
   if (entry_index != FrVOCAB_WORD_NOT_FOUND)
      {
      size_t loc = headinfo[entry_index].index() ;
      size_t numdefs = 0 ;
      for (size_t endloc = loc ; endloc < definition_items ; endloc++)
	 {
	 int POS = definitions[endloc].getPOS() ;
	 if (wanted_POS == POS_unknown || POS == POS_unknown ||
	     POS == wanted_POS)
	    numdefs++ ;
	 if (definitions[endloc].isLast()) // end of definitions for word?
	    break ;
	 }
      DictionaryEntry *entries = new DictionaryEntry[numdefs+1] ;
      if (!entries)
	 {
	 FrNoMemory("while looking up probabilities in dictionary") ;
	 numdefs = 0 ;
	 }
      numtrans = numdefs ;
      if (numdefs == 0)
	 return entries ;
      numdefs = 0 ;
      double srccount = (double)headinfo[entry_index].frequency() ;
      if (srccount == 0)
	 srccount = 1 ;
      srccount += smoothing ;
      for ( ; loc < definition_items ; loc++)
	 {
	 int POS = definitions[loc].getPOS() ;
	 if (wanted_POS == POS_unknown || POS == POS_unknown ||
	     POS == wanted_POS)
	    {
	    FrObject *translation =
	       retrieveTranslation(&definitions[loc],true) ;
	    if (translation && translation->consp() &&
		!((FrList*)translation)->rest())
	       {
	       FrList *trans = (FrList*)translation ;
	       translation = poplist(trans) ;
	       }
	    double probability = definitions[loc].getCount() / srccount ;
	    if (probability > 1.0)
	       probability = 1.0 ;
	    else if (probability == 0.0)
	       probability = default_dict_score ;
	    int POS = definitions[loc].getPOS() ;
	    new (&entries[numdefs]) DictionaryEntry(translation,
						    probability,POS) ;
	    numdefs++ ;
	    }
	 if (definitions[loc].isLast())	// end of definitions for word?
	    break ;
	 }
      FrQuickSort(entries,numdefs) ;
      numtrans = numdefs ;
      return entries ;
      } 
   numtrans = 0 ;
   return 0 ;				// word not found in dictionary
}

//----------------------------------------------------------------------

FrList *Dictionary::lookup(const char *word, size_t max_xlat,
			   int wanted_POS) const
{
   size_t entry_index = findWord(word) ;
   if (entry_index != FrVOCAB_WORD_NOT_FOUND)
      {
      size_t loc = headinfo[entry_index].index() ;
      size_t numdefs = 0 ;
      FrList *word_defs ;
      FrList **last_def = &word_defs ;
      for ( ; loc < definition_items ; loc++)
	 {
	 int POS = definitions[loc].getPOS() ;
	 if (wanted_POS == POS_unknown || POS == POS_unknown ||
	     POS == wanted_POS)
	    {
	    int word_case = definitions[loc].getCase() ;
	    FrObject *word_def = retrieveTranslation(&definitions[loc],true) ;
	    FrList *this_def ;
	    if (POS != POS_unknown)
	       this_def = new FrList(word_def,
				     new FrInteger(definitions[loc].getCount()),
				     make_POS_symbol(POS)) ;
	    else
	       this_def = new FrList(word_def,
				     new FrInteger(definitions[loc].getCount()));
	    if (word_case != CASE_unknown)
	       {
	       FrSymbol *casesym = make_CASE_symbol(word_case) ;
	       this_def = this_def->nconc(new FrList(casesym)) ;
	       }
	    word_defs->pushlistend(this_def,last_def) ;
	    numdefs++ ;
	    }
	 if (definitions[loc].isLast()) // end of definitions for word?
	    break ;
	 }
      *last_def = 0 ;
      if (word_defs && numdefs > max_xlat)
	 {
	 // remove the lowest-frequency translations until we get down to
	 //   the specified limit
	 word_defs = word_defs->sort(compare_freq) ;
	 size_t discard = numdefs - max_xlat ;
	 FrList *ptr = word_defs ;
	 FrList *prev_ptr = word_defs ;
	 FrList *def = (FrList*)ptr->first() ;
	 long prev_freq = def->second()->intValue() ;
	 do {
	    ptr = ptr->rest() ;
	    def = (FrList*)ptr->first() ;
	    long freq = def->second()->intValue() ;
	    if (freq != prev_freq)
	       {
	       prev_ptr = ptr ;
	       prev_freq = freq ;
	       }
	    } while (--discard > 0) ;
	 while (word_defs != prev_ptr)
	    free_object(poplist(word_defs)) ;
	 word_defs = listreverse(word_defs) ;
	 }
      pushlist(new FrInteger(headinfo[entry_index].frequency()),word_defs) ;
      return word_defs ;
      }
   return 0 ;				// no such word to look up....
}

//----------------------------------------------------------------------

static bool self_translation(const FrObject *word,
			       const FrObject *translation)
{
   const char *wordstr = FrPrintableName(word) ;
   if (wordstr && translation && translation->consp())
      {
      const FrList *tr = (FrList*)translation ;
      const char *xlat = FrPrintableName(tr->first()) ;
      if (xlat && Fr_stricmp(wordstr,xlat,lowercase_table))
	 return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

static void convert_to_arcs(const FrTextSpan *span, const char *word,
			    FrSymbol *wordsym,
			    FrList *fulltrans, FrList *&translations,
			    double confidence = 1.0)
{
   FrObject *frequency = 0 ;
   if (fulltrans && fulltrans->first() && fulltrans->first()->numberp())
      frequency = poplist(fulltrans) ;
   size_t totalfreq = frequency ? frequency->intValue() : 0 ;
   free_object(frequency) ;
   double quality = totalfreq ? totalfreq / 100.0 : 0.5 / 100.0 ;
   if (quality > 0.5) quality = 0.5 ; 	// keep DICT from outweighing EBMT
   if (is_number(word) && !fulltrans->member(wordsym,self_translation))
      {
      fulltrans = pushlist(new FrList(wordsym,new FrInteger(0)),
			   fulltrans) ;
      }
   while (fulltrans)
      {
      FrList *trans = (FrList*)poplist(fulltrans) ;
      FrObject *target = poplist(trans) ;
      size_t freq = trans->first()->intValue() ;
      if (target)
	 {
	 if (target->symbolp())
	    target = new FrString(((FrSymbol*)target)->symbolName()) ;
	 else if (target->consp())
	    {
	    FrList *trglist = (FrList*)target ;
	    target = new FrString(trglist,true,false) ;
	    trglist->freeObject() ;
	    }
	 else
	    target = target->deepcopy() ;
	 }
      free_object(trans) ;
      double score = ((totalfreq && freq)
		      ? (freq / (double)totalfreq)
		      : default_dict_score) ;
      score *= confidence ;
      trans = new FrList(new FrFloat(score),new FrString(word),
			 new FrFloat(span->weight()),
			 new FrList(makeSymbol("Q"),new FrFloat(quality))) ;
      pushlist(target,trans) ;
      pushlist(new FrInteger(span->end()),trans) ;
      pushlist(new FrInteger(span->start()),trans) ;
      pushlist(trans,translations) ;
      }
   return ;
}

//----------------------------------------------------------------------

FrList *Dictionary::lookup(const FrTextSpans *words, size_t max_xlat,
			   int POS) const
{
   FrList *translations = 0 ;
   if (words)
      {
      for (size_t i = 0 ; i < words->spanCount() ; i++)
	 {
	 const FrTextSpan *span = words->getSpan(i) ;
	 if (!span)
	    continue ;
	 char *word = span->getText() ;
	 if (!word || strchr(word,' ') != 0)
	    {
	    FrFree(word) ;
	    continue ;			// can't handle phrases yet
	    }
	 Fr_strupr(word,char_encoding) ; // all dict headwords are all-caps
	 FrSymbol *wordsym = FrSymbolTable::add(word) ;
	 FrList *fulltrans = lookup(wordsym,max_xlat,POS) ;
	 if (fulltrans)
	    convert_to_arcs(span,word,wordsym,fulltrans,translations,
			    span->score()) ;
	 else if (!*word)
	    {
	    // handle the null word to deal with epsilon arcs in lattices
	    FrList *trans = new FrList(new FrString(""),
				       new FrFloat(span->score()),
				       new FrString(word),
				       new FrFloat(span->weight())) ;
	    pushlist(new FrInteger(span->end()),trans) ;
	    pushlist(new FrInteger(span->start()),trans) ;
	    pushlist(trans,translations) ;
	    }
	 else if (stemword_ht)
	    {
	    // try backing off to root/stem
	    FrSymHashEntry *stem_entry = stemword_ht->lookup(wordsym) ;
	    if (stem_entry)
	       {
	       FrList *stem = (FrList*)stem_entry->getUserData() ;
	       FrSymbol *root = FrCvt2Symbol(stem->first(),char_encoding) ;
	       if (root && root != wordsym)
		  {
		  fulltrans = lookup(root,max_xlat,POS) ;
		  convert_to_arcs(span,root->symbolName(),root,fulltrans,
				  translations,dict_score_root*span->score()) ;
		  }
	       }
	    }
	 FrFree(word) ;
	 }
      }
   return listreverse(translations) ;
}

//----------------------------------------------------------------------

FrList *Dictionary::lookupTranslations(const FrSymbol *word,
				       int wanted_POS) const
{
   size_t entry_index = findWord(word) ;
   if (entry_index != FrVOCAB_WORD_NOT_FOUND)
      {
      size_t loc = headinfo[entry_index].index() ;
      FrList *word_defs ;
      FrList **last_def = &word_defs ;
      for ( ; loc < definition_items ; loc++)
	 {
	 int POS = definitions[loc].getPOS() ;
	 if (wanted_POS == POS_unknown || POS == POS_unknown ||
	     POS == wanted_POS)
	    {
	    FrObject *word_def = retrieveTranslation(&definitions[loc],true) ;
	    word_defs->pushlistend(word_def,last_def) ;
	    }
	 if (definitions[loc].isLast()) // end of definitions for word?
	    break ;
	 }
      *last_def = 0 ;
      return word_defs ;
      }
   return 0 ;				// no such word to look up....
}

//----------------------------------------------------------------------

bool Dictionary::isTranslation(const FrSymbol *srcword,
				 FrSymbol *trgword) const
{
   size_t entry_index = findWord(srcword) ;
   if (entry_index != FrVOCAB_WORD_NOT_FOUND)
      {
      size_t loc = headinfo[entry_index].index() ;
      for ( ; loc < definition_items ; loc++)
	 {
	 bool iscopy = false ;
	 FrObject *word_def = retrieveTranslation(&definitions[loc],false,
						  &iscopy) ;
	 bool found = ((word_def == trgword) ||
			 strcmp(word_def->printableName(),
				trgword->printableName()) == 0) ;
	 if (iscopy)
	    free_object(word_def) ;
	 if (found)
	    return true ;
	 if (definitions[loc].isLast()) // end of definitions for word?
	    break ;
	 }
      }
   return false ;			// source word unknown, or not xlated
}

//----------------------------------------------------------------------

bool Dictionary::isTranslation(const FrSymbol *srcword,
				 FrSymbol *trgword, bool fold_case) const
{
   size_t entry_index = findWord(srcword) ;
   if (entry_index != FrVOCAB_WORD_NOT_FOUND)
      {
      size_t loc = headinfo[entry_index].index() ;
      for ( ; loc < definition_items ; loc++)
	 {
	 bool iscopy = false ;
	 FrObject *word_def = retrieveTranslation(&definitions[loc],false,
						  &iscopy) ;
	 bool found ;
	 if (fold_case)
	    found = ::EBMT_equal(word_def,trgword) ;
	 else
	    found = ((word_def == trgword) ||
		     strcmp(word_def->printableName(),
			    trgword->printableName()) == 0) ;
	 if (iscopy)
	    free_object(word_def) ;
	 if (found)
	    return true ;
	 if (definitions[loc].isLast()) // end of definitions for word?
	    break ;
	 }
      }
   return false ;			// source word unknown, or not xlated
}

//----------------------------------------------------------------------

FrObject *Dictionary::retrieveTranslation(size_t defnum,
					  bool always_copy,
					  bool *is_copy) const
{
   void *objref = defs[defnum] ;
   if (mapped_addr && objref >= mapped_addr && objref < end_mapping)
      {
      char *string = (char*)objref ;
      FrObject *def = string_to_FrObject(string) ;
      if (def)
	 {
	 if (def->symbolp())
	    defs[defnum] = def ;	// cache the symbol
	 else
	    fix_penultimate_period(def) ;
	 }
      if (is_copy) *is_copy = true ;
      return def ;
      }
   else if (always_copy && objref)
      {
      if (is_copy) *is_copy = true ;
      return ((FrObject*)objref)->deepcopy() ;
      }
   else
      {
      if (is_copy) *is_copy = false ;
      return (FrObject*)objref ;
      }
}

//----------------------------------------------------------------------

bool Dictionary::sameTranslation(const DictDefItem *defitem,
				   const FrObject *translation) const
{
   bool is_copy ;
   FrObject *def = retrieveTranslation(defitem,false,&is_copy) ;
   bool same = (def && (def == translation || ::equal(def,translation))) ;
   if (is_copy)
      free_object(def) ;
   return same ;
}

//----------------------------------------------------------------------

bool Dictionary::isDefined(const FrSymbol *word) const
{
   return (findWord(word) != FrVOCAB_WORD_NOT_FOUND) ;
}

//----------------------------------------------------------------------

bool Dictionary::iterateVA(DictIteratorFunc func, va_list args) const
{
   for (size_t i = 0 ; i < numheads ; i++)
      {
      FrSymbol *word = makeSymbol(wordName(i)) ;
      FrList *translations = 0 ;
      FrList **lasttrans = &translations ;
      for (size_t j = headinfo[i].index() ; j < definition_items ; j++)
	 {
	 FrObject *d = retrieveTranslation(&definitions[j],true) ;
	 if (d)
	    FrList::pushlistend(d,lasttrans) ;
	 if (definitions[j].isLast())
	    break ;
	 }
      *lasttrans = 0 ;
      FrSafeVAList(args) ;
      bool success = func(word,translations,FrSafeVarArgs(args)) ;
      FrSafeVAListEnd(args) ;
      free_object(translations) ;
      if (!success)
	 return false ;
      }
   return true ;
}

//----------------------------------------------------------------------

bool __FrCDECL Dictionary::iterate(DictIteratorFunc func, ...) const
{
   va_list args ;
   va_start(args,func) ;
   bool success = iterateVA(func,args) ;
   va_end(args) ;
   return success ;
}

/************************************************************************/
/*	procedural interface						*/
/************************************************************************/

void DcLoadWordstems(const char *filename)
{
   if (!filename)
      return ;
   istream *in = new ifstream(filename) ;
   if (in && in->good())
      {
      FrObject *obj ;
      (*in) >> obj ;
      FrString *sig1 = new FrString(STEMWORD_SIGNATURE1) ;
      FrString *sig2 = new FrString(STEMWORD_SIGNATURE2) ;
      bool good = true ;
      if (!obj || (!::equal(obj,sig1) && !::equal(obj,sig2)))
	 {
	 FrWarningVA("Invalid stemword file '%s'.\n\tWill continue without it.",
		     filename) ;
	 good = false ;
	 }
      free_object(obj) ;
      free_object(sig1) ;
      free_object(sig2) ;
      if (!good)
	 return ;
      }
   DcFreeWordstems() ;
   stemword_ht = new FrSymHashTable ;
   stemword_ht->expandTo(100) ;
   FrSymbol *symEOF = makeSymbol("*EOF*") ;
   while (!in->eof() && !in->fail())
      {
      FrObject *obj ;
      (*in) >> obj ;
      if (obj)
	 {
	 if (obj->consp())
	    {
	    FrList *stem = (FrList*)obj ;
	    FrObject *surf = poplist(stem) ;
	    FrSymbol *surface = FrCvt2Symbol(surf,char_encoding) ;
	    free_object(surf) ;
	    if (surface)
	       {
	       // delete any previous stemming info for the word
	       FrSymHashEntry *item = stemword_ht->lookup(surface) ;
	       if (item)
		  {
		  free_object((FrObject*)item->getUserData()) ;
		  item->setUserData(0) ;
		  }
	       stemword_ht->add(surface,stem) ;
	       }
	    else
	       free_object(stem) ;
	    }
	 else if (obj == symEOF)		// end of file?
	    break ;
	 else if (obj->numberp())
	    {
	    stemword_ht->expandTo((int)((FrNumber*)obj)->intValue()) ;
	    obj->freeObject() ;
	    }
	 else
	    obj->freeObject() ;
	 }
      }
   delete in ;
   return ;
}

//----------------------------------------------------------------------

static bool clear_stems(FrSymHashEntry *entry, va_list)
{
   if (entry)
      free_object((FrObject*)entry->getUserData()) ;
   return true ;			// continue iterating
}

//----------------------------------------------------------------------

void DcFreeWordstems()
{
   if (stemword_ht)
      {
      stemword_ht->doHashEntries(clear_stems,0) ;
      delete stemword_ht ;
      stemword_ht = 0 ;
      }
   return ;
}

//----------------------------------------------------------------------

void DcIdentifyDictionary(ostream &out, bool as_comment)
{
   if (as_comment)
      out << "; " ;
   out << "Dictionary v" DICT_VERSION_STR << endl ;
}

//----------------------------------------------------------------------

bool DcInitializeDictionary(const char *dictfile, bool load_readonly)
{
   if (Initialized)
      return true ;
   if (!dictfile || !*dictfile)
      {
      FrWarning("no dictionary file specified!") ;
      return false ;
      }
   dictionary = Dictionary::open(dictfile,load_readonly) ;
   if (!dictionary)
      {
      FrWarningVA("unable to load dictionary %s",dictfile) ;
      return false ;
      }
   Initialized = true ;
   return true ;
}

//----------------------------------------------------------------------

Dictionary *DcActiveDictionary()
{
   return dictionary ;
}

//----------------------------------------------------------------------

void DcSetActiveDictionary(Dictionary *dict)
{
   dictionary = dict ;
   return ;
}

//----------------------------------------------------------------------

FrList *process_sentence_dictionary(const FrList *sentence)
{
   if (!dictionary)
      return 0 ;
   FrList *translations = 0 ;
   FrList **end = &translations ;
   for ( ; sentence ; sentence = sentence->rest())
      {
      FrObject *word = sentence->first() ;
      if (word)
	 {
	 FrSymbol *wordsym = FrCvt2Symbol(word,char_encoding) ;
	 translations->pushlistend(dictionary->lookupTranslations(wordsym),
				   end) ;
	 }
      else
	 translations->pushlistend(0,end) ;
      }
   *end = 0 ;				// terminate result list
   return translations ;
}

//----------------------------------------------------------------------

bool DcSaveDictionaryUpdates()
{
   if (dictionary)
      return dictionary->save() ;
   return true ;
}


//----------------------------------------------------------------------

bool DcExportDictionary(const char *filename, Dictionary *dict)
{
   if (!dict)
      dict = dictionary ;
   if (dict)
      return dict->exportDict(filename) ;
   return false ;			// dictionary NOT exported
}

//----------------------------------------------------------------------

bool DcKeepCase(bool keep)
{
   bool old_keep = dict_keep_case ;
   dict_keep_case = keep ;
   return old_keep ;
}

//----------------------------------------------------------------------

bool DcShutdownDictionary()
{
   if (Initialized)
      {
      DcSaveDictionaryUpdates() ;
      dictionary->close() ;
      dictionary = 0 ;
      Initialized = false ;
      }
   DcFreeWordstems() ;
   return true ;
}

// end of file ebdict.cpp //
