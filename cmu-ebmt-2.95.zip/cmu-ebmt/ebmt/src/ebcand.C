/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebcand.cpp	class EBMTCandidate				*/
/*  LastEdit: 29mar10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#if defined(__GNUC__)
#  pragma implementation "ebchunks.h"
#endif

#define IMPLEMENT_EBCHUNKS
#include <limits.h>
#include <math.h>
#include "ebcmatch.h"
#include "ebalign.h"
#include "ebcorpus.h"
#include "ebsent.h"
#include "ebtoken.h"
#include "ebutil.h"
#include "ebmt.h"
#include "ebglobal.h"
#include "ebmorph.h"

#ifndef NDEBUG
# undef _FrCURRENT_FILE
static const char _FrCURRENT_FILE[] = __FILE__ ; // save memory
#endif /* NDEBUG */

/************************************************************************/
/*	Manifest Constants						*/
/************************************************************************/

#define BACKSUB_AMBIG_LIMIT 32

/************************************************************************/
/*    Global data for classes						*/
/************************************************************************/

FrAllocator EBMTCandidate::allocator("EBMTCandidate",sizeof(EBMTCandidate)) ;

/************************************************************************/
/*    Helper Functions							*/
/************************************************************************/

static int compare_numbers(const FrObject *o1, const FrObject *o2)
{
   long val1 = o1->intValue() ;
   long val2 = o2->intValue() ;
   return (val1 < val2) ? -1 : ((val1 > val2) ? +1 : 0) ;
}

/************************************************************************/
/*    Methods for class EBMTCandidate					*/
/************************************************************************/

EBMTCandidate::EBMTCandidate()
{
   initCommon() ;
   source_words = 0 ;
   m_next = 0 ;
   // don't need to initialize other members here, as the only thing we
   //   use the default ctor for is making a dummy list head
   return ;
}

//----------------------------------------------------------------------

void EBMTCandidate::initCommon()
{
   // initialize feature values
   m_features.init(&EBfeature_map) ;
   setFrequency(1) ;
   setWeight(1.0) ;
   setConfidence(1.0) ;
   setDocContext(0.0) ;
   setSentContext(1.0) ;
   setPhraseContext(0) ;
   clearAlignQuality() ;
   setChunkingBonus(0.0) ;
   // initialize other members
   target_sentence = 0 ;
   target_words = 0 ;
   m_generalizationseq = 0 ;
   gapPositions(NO_GAP) ;
   numTokens(0) ;
   target_offset = 0 ;
   m_spans = 0 ;
   m_numspans = 0 ;
   m_backsubs = 0 ;
   m_inputwords = 0 ;
   m_inputtext = 0 ;
   generalizations = 0;
   return ;
}

//----------------------------------------------------------------------

EBMTCandidate::EBMTCandidate(const EBMTCandidate *orig, bool min_copy)
   : metainfo(orig ? &orig->metainfo : 0)
{
   m_next = 0 ;
   if (!orig)
      {
      initCommon() ;
      source_words = 0 ;
      target_words = 0 ;
      }
   else
      {
      m_features.init(orig->m_features) ;
      if (min_copy)
	 {
	 m_spans = 0 ;
	 m_numspans = 0 ;
	 m_backsubs = 0 ;
	 }
      else
	 {
	 if (orig->m_spans)
	    {
	    m_spans = FrNewN(const FrTextSpan *,orig->spansCovered()+1) ;
	    if (m_spans)
	       {
	       memcpy(m_spans,orig->m_spans,
		      orig->spansCovered()*sizeof(m_spans[0]));
	       m_numspans = (EbUSHORT)orig->spansCovered() ;
	       }
	    else
	       m_numspans = 0 ;
	    }
	 else
	    {
	    m_spans = 0 ;
	    m_numspans = 0 ;
	    }
	 if (orig->m_backsubs)
	    {
	    m_backsubs = FrNewN(const FrList *,orig->matchLength()) ;
	    if (m_backsubs)
	       memcpy(m_backsubs,orig->m_backsubs,
		      orig->matchLength()*sizeof(m_backsubs[0])) ;
	    }
	 else
	    m_backsubs = FrNewC(const FrList *,orig->matchLength()) ;
	 }
      source_words = FrCopyList(orig->source_words) ;
      target_words = (orig->target_words 
		      ? (FrString*)orig->target_words->deepcopy() : 0) ;
      m_generalizationseq = FrCopyList(orig->generalizationSequence()) ;
      m_corpus = orig->sourceCorpus() ;
      example_number = orig->exampleNumber() ;
      m_indexloc = orig->indexLocation() ;
      m_whichindex = orig->m_whichindex ;
      gapPositions(orig->gapPositions()) ;
      m_start = (EbUSHORT)orig->inputStart() ;
      orig_length = (EbUSHORT)orig->inputLength() ;
      setSourceOffset(orig->sourceOffset()) ;
      match_length = (EbUSHORT)orig->matchLength() ;
      setInputWords(orig->inputWords()) ;
      numTokens((EbUSHORT)orig->numTokens()) ;
      source_length = orig->sourceLength() ;
      m_inputtext = orig->inputTextLength() ;
      target_offset = (EbUSHORT)orig->targetOffset() ;
      target_end = (EbUSHORT)orig->targetEnd() ;
      target_sentence = 0;
      equivClass(orig->equivClass()) ;
#if 0
      if (orig->bitext())
	 this->setBiTextMap(orig->bitext()) ;
#endif
      setAlignScore(orig->alignmentScore()) ;
      setAlignQuality(orig) ;
      if (orig->generalizations)
	 generalizations = new EbGeneralizations(orig->generalizations);
      else
	 generalizations = 0 ;
      }
   return ;
}

//----------------------------------------------------------------------

EBMTCandidate::EBMTCandidate(uint32_t indexloc, EbIndexSpec which,
			     uint32_t ex_number,
			     size_t startpos, size_t endpos,  // in input
			     size_t matchstart, size_t matchlen,
			     size_t srclen, const FrTextSpan * const *spans)
{
   initCommon() ;
   m_indexloc = indexloc ;
   m_whichindex = which ;
   m_corpus = active_EBMTCorpus() ;
   example_number = ex_number ;
   setSourcePosition(startpos,endpos,matchstart,matchlen) ;
   source_words = 0 ;
   source_length = (EbUSHORT)srclen ;
   clearTargetWords() ;
   m_next = 0 ;
   assert(sourceOffset() < sourceLength()) ;
   setCoveredSpans(matchlen,spans) ;
   return ;
}

//----------------------------------------------------------------------

EBMTCandidate::EBMTCandidate(size_t startpos, const FrString *srcword,
			     const FrString *trgword, EBMTCandidate *next)
{
   initCommon() ;
   m_indexloc = ~0 ;
   m_whichindex = EbIndex_None ;
   m_corpus = active_EBMTCorpus() ;
   example_number = DUMMY_EXAMPLE_NUMBER ;
   m_start = (EbUSHORT)startpos ;
   match_length = 1;
   m_inputwords = 1 ;
   orig_length = (EbUSHORT)(srcword ? srcword->stringLength() : 1) ;
   setSourceOffset(0) ;
   source_words = srcword ? new FrList(srcword->deepcopy()) : 0 ;
   m_inputtext = 1 ;
   source_length = 1 ;
   setTargetWords(trgword ? (FrString*)trgword->deepcopy() : 0,0,0) ;
   setScore(SCORE_ACCEPTABLE) ;
   m_next = next ;
   return ;
}

//----------------------------------------------------------------------

static size_t count_nonwhite(const FrList *phrase)
{
   size_t count(0) ;
   for ( ; phrase ; phrase = phrase->rest())
      {
      const char *word = FrPrintableName(phrase->first()) ;
      if (word)
	 count += strlen(word) ;
      }
   return count ;
}

//----------------------------------------------------------------------

EBMTCandidate::EBMTCandidate(const FrList *ssent, const FrList *tsent,
			     const FrList *sphrase, size_t matchstart,
			     BiTextMap *bitext, FrVocabulary *vocab)
{
   initCommon() ;
   m_indexloc = ((uint32_t)~0L) ;
   m_whichindex = EbIndex_None ;
   m_corpus = active_EBMTCorpus() ;
   example_number = DUMMY_EXAMPLE_NUMBER ;
   m_start = 0 ;
   match_length = (EbUSHORT)sphrase->simplelistlength() ;
   m_inputwords = matchLength() ;
   orig_length = (EbUSHORT)count_nonwhite(sphrase) ;
   setSourceOffset(matchstart) ;
   source_length = (EbUSHORT)ssent->simplelistlength() ;
   target_sentence = new EbSentence(vocab,tsent) ;
   target_end = (EbUSHORT)target_sentence->length() ;
   if (target_end > 0) target_end-- ;
   source_words = FrCopyList(sphrase) ;
   setTargetWords((FrString*)0,0,0) ;
   setScore(SCORE_UNALIGNABLE) ;
   metainfo.bitext(bitext) ;
   m_next = 0 ;
   return ;
}

//----------------------------------------------------------------------

EBMTCandidate::~EBMTCandidate()
{
   delete target_sentence ;
   free_object(source_words) ;
   free_object(target_words) ;
   setGeneralizationSequence(0) ;
   FrFree(m_spans) ;
   FrFree(m_backsubs) ;
   m_numspans = 0 ;
   delete generalizations;
   return ;
}

//----------------------------------------------------------------------

void EBMTCandidate::deleteList()
{
   FrLinkListDelete(this) ;
   return ;
}

//----------------------------------------------------------------------

EBMTCandidate *EBMTCandidate::reverseList()
{
   return FrLinkListReverse(this) ;
}

//----------------------------------------------------------------------

EBMTCandidate *EBMTCandidate::nconc(EBMTCandidate *rest)
{
   return FrLinkListNconc(this,rest) ;
}

//----------------------------------------------------------------------

int EBMTCandidate::listlength() const
{
   return FrLinkListLength(this) ;
}

//----------------------------------------------------------------------

EBMTIndex *EBMTCandidate::getIndex() const
{ 
   return m_corpus ? m_corpus->getIndex() : 0 ; 
}

//----------------------------------------------------------------------

void EBMTCandidate::setMatchData(const EbCorpusMatches *matches)
{
   gapPositions(matches->gapPositions()) ;
   numTokens(matches->numTokens()) ;
   setInputWords(matches->inputMatch()) ;
   setBackSubstitutions(matches) ;
   return ;
}

//----------------------------------------------------------------------

void EBMTCandidate::setSourceWords(FrList *source, size_t gaps)
{
   free_object(source_words) ;
   source_words = source ;
   gapPositions(gaps) ;
   // now set token count after calling the setSourceText() which calls us
   numTokens(0) ;
   for ( ; source ; source = source->rest())
      {
      if (is_token(source->first()))
	 numTokens(numTokens()+1) ;
      }
   return ;
}

//----------------------------------------------------------------------

void EBMTCandidate::setBiTextMap(const BiTextMap *new_bitext)
{
   metainfo.bitext(new_bitext ? new BiTextMap(new_bitext) : 0) ;
   return ;
}

//----------------------------------------------------------------------

void EBMTCandidate::setFrequency(size_t len, size_t freq)
{
   (void)freq ;
   switch (len)
      {
#if 0 // having per-length frequencies seems to destabilize optimization
      case 0:
	 break ;
      case 1:
	 m_features.setValue(featureID_frequency1,freq) ;
	 break ;
      case 2:
	 m_features.setValue(featureID_frequency2,freq) ;
	 break ;
      case 3:
	 m_features.setValue(featureID_frequency3,freq) ;
	 break ;
      case 4:
	 m_features.setValue(featureID_frequency4,freq) ;
	 break ;
      case 5:
	 m_features.setValue(featureID_frequency5,freq) ;
	 break ;
      default:
	 m_features.setValue(featureID_frequencylong,freq) ;
	 break ;
#endif
      }
   return ;
}

//----------------------------------------------------------------------

void EBMTCandidate::setPhraseContext(size_t context_size)
{
   m_features.setValue(featureID_phrcontext,::exp(context_size)) ;
   switch (context_size)
      {
      default:
	 m_features.setValue(featureID_phrcontextplus,1.0) ;
	 /*fallthrough*/
      case 6:
	 m_features.setValue(featureID_phrcontext6,1.0) ;
	 /*fallthrough*/
      case 5:
	 m_features.setValue(featureID_phrcontext5,1.0) ;
	 /*fallthrough*/
      case 4:
	 m_features.setValue(featureID_phrcontext4,1.0) ;
	 /*fallthrough*/
      case 3:
	 m_features.setValue(featureID_phrcontext3,1.0) ;
	 /*fallthrough*/
      case 2:
	 m_features.setValue(featureID_phrcontext2,1.0) ;
	 /*fallthrough*/
      case 1:
	 m_features.setValue(featureID_phrcontext1,1.0) ;
	 /*fallthrough*/
      case 0:
	 break ;
      }
}

//----------------------------------------------------------------------

void EBMTCandidate::setSourcePosition(size_t startpos, size_t endpos,//in input
				      size_t matchstart, size_t matchlen)
{
   m_start = (EbUSHORT)startpos ;
   orig_length = (EbUSHORT)((endpos - startpos) + 1) ;
   match_length = (EbUSHORT)matchlen ;
   setSourceOffset(matchstart) ;
   return ;
}

//----------------------------------------------------------------------

void EBMTCandidate::setBackSubstitutions(const EbCorpusMatches *match)
{
   if (!m_backsubs)
      m_backsubs = FrNewC(const FrList*,matchLength()) ;
   if (match && m_backsubs)
      {
      for (size_t i = 0 ; i < matchLength() ; i++)
	 m_backsubs[i] = match->backSubstitutions(i) ;
      }
   return ;
}

//----------------------------------------------------------------------

double EbSpanConfidence(size_t N, const FrTextSpan * const *spans,
			size_t &words, double &weight)
{
   double wt ;
   double conf ;
   words = 0 ;
   if (span_scores_geometric_mean || span_scores_product)
      {
      wt = 1.0 ;
      conf = 1.0 ;
      for (size_t i = 0 ; i < N ; i++)
	 {
	 const FrTextSpan *span = spans[i] ;
	 if (span)
	    {
	    size_t len = span->wordCount() ;
	    words += len ;
	    if (span_scores_product)
	       len = 1 ;
	    for (size_t j = 1 ; j <= len ; j++)
	       {
	       wt *= span->weight() ;
	       conf *= span->score() ;
	       }
	    }
	 }
      if (words > 0 && !span_scores_product)
	 {
	 wt = pow(wt,1.0/words) ;
	 conf = pow(conf,1.0/words) ;
	 }
      }
   else
      {
      wt = 0.0 ;
      conf = 0.0 ;
      for (size_t i = 0 ; i < N ; i++)
	 {
	 const FrTextSpan *span = spans[i] ;
	 if (span)
	    {
	    size_t len = span->wordCount() ;
	    wt += span->weight() * len ;
	    conf += span->score() * len ;
	    words += len ;
	    }
	 }
      if (words > 0)
	 {
	 wt /= words ;
	 conf /= words ;
	 }
      }
   weight = wt ;
   return conf ;
}

//----------------------------------------------------------------------

void EBMTCandidate::setCoveredSpans(size_t N, const FrTextSpan * const *spans)
{
   FrFree(m_spans) ;
   m_numspans = 0 ;
   m_spans = FrNewN(const FrTextSpan*,N) ;
   m_inputwords = 0 ;
   if (m_spans)
      {
      m_numspans = (EbUSHORT)N ;
      for (size_t i = 0 ; i < N ; i++)
	 m_spans[i] = spans[i] ;
      double wt ;
      size_t words ;
      double conf = EbSpanConfidence(N,spans,words,wt) ;
      m_inputwords = (EbUSHORT)words ;
//      setFrequency(words,1) ;
      setWeight(wt) ;
      setConfidence(conf) ;
      }
   return ;
}

//----------------------------------------------------------------------
// makeBiText()
// input: source = list of symbols
//	  target = list of strings

BiTextMap *EBMTCandidate::makeBiText(EBMTCorpus *corpus,
				     const FrList *source,const FrList *target,
				     FrCasemapTable number_charmap,
				     const FrList *alignment,
				     bool reverse_alignment)
{
   BiTextMap *corresp ;
   const EbAlignConstraints *constraints
	 = corpus ? corpus->alignConstraints() : 0 ;
   if (alignment)
      {
      corresp = new BiTextMap(source,target,alignment,1,1.0,constraints,
			      reverse_alignment) ;
      }
   else
      {
      FrList *troots = corpus ? corpus->getTargetRoots(target) : 0 ;
      corresp = EbMakeBitext(source,target,troots,number_charmap,constraints);
      if (troots)
	 troots->freeObject() ;
      }
   return corresp ;
}

//----------------------------------------------------------------------

void EBMTCandidate::freeTargetSentence()
{
   delete target_sentence ;
   target_sentence = 0 ;
   return ;
}

//----------------------------------------------------------------------

bool EBMTCandidate::loadSentencePair(EBMTCorpus *corpus,
				     bool ignore_bitext,
				     bool ignore_morphology)
{
   freeCorrespondences() ;		// get rid of any old corr. table
   if (sourceLength() > 0 &&
       corpus->getExample(exampleNumber(),target_sentence,metainfo,
			  sourceLength(),ignore_bitext,ignore_morphology) &&
       target_sentence)
      {
      size_t target_length = (EbUSHORT)target_sentence->length() ;
      target_end = target_length > 0 ? target_length - 1 : 0 ;
      size_t chunks_covered, chunks_partly_covered ;
      double weighted_cover ;
      if (metainfo.chunksCovered(sourceOffset(),sourceEnd(),sourceLength(),
				 chunks_covered, chunks_partly_covered,
				 weighted_cover,true))
	 setChunkingBonus(weighted_cover / matchLength()) ;
      setFrequency(metainfo.frequency()) ;
      setFrequency(matchLength(),metainfo.frequency()) ;
      if (metainfo.userScores())
	 {
	 for (size_t i = 0 ; i < metainfo.numUserScores() ; i++)
	    {
	    //FIXME: set feature corresponding to i'th user score
	    }
	 }
      EBMTIndex *index = corpus->getIndex() ;
      if (EbExternalAlignerRunning() &&
	  !index->overridingMetaInfo(exampleNumber()))
	 {
	 FrVocabulary *vocab = index->vocabulary() ;
	 if (corpus->haveRecordStarts() || corpus->locateRecordStarts())
	    {
	    EbIndexSpec which = sourceIndex() ;
	    if (which == EbIndex_None)
	       which = EbIndex_Main ;
	    uint32_t start = corpus->recordStart(exampleNumber(),which) ;
	    if (start != (uint32_t)~0)
	       {
	       vocab->createReverseMapping() ;
	       EbBWTIndex *idx = index->selectIndex(which) ;
	       FrList *src = idx->retrieveSource(start,vocab) ;
	       FrList *trg = target_sentence->wordList() ;
	       if (trace_matching)
		  {
		  cout << "Asking external aligner about example "
		       << exampleNumber() << ": " << src << endl ;
		  }
	       FrList *xalign = EbApplyExternalAligner(src,trg) ;
	       const FrList *alignments = (FrList*)xalign->assoc(symALIGN) ;
	       if (trace_matching)
		  {
		  if (verbose)
		     cout << "  aligner result: " << xalign << endl ;
		  else
		     cout << "   alignments: " << alignments << endl ;
		  }
	       bool have_align = false ;
	       if (alignments)
		  {
		  BiTextMap *bitext
		     = EBMTCandidate::makeBiText(corpus, src, trg, 0,
						 alignments->rest(),
						 reverse_languages);
		  if (bitext)
		     {
		     metainfo.bitext(bitext) ;
		     have_align = true ;
		     }
		  }
	       free_object(trg) ;
	       free_object(src) ;
	       if (metainfo.parse(xalign) || have_align)
		  index->addOverride(exampleNumber(),&metainfo) ;
	       free_object(xalign) ;
	       }
	    }
	 }
      else if (trace_matching && verbose && metainfo.bitext())
	 {
	 metainfo.bitext()->dump() ;
	 }
      corpus->setExampleWeight(this) ;
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

bool EBMTCandidate::haveBackSubstitutions() const
{
   if (m_backsubs)
      {
      for (size_t i = 0 ; i < matchLength() ; i++)
	 if (m_backsubs[i])
	    return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

static bool in_target_vocab(const FrObject *sub,
			      const FrSymHashTable *targetvocab)
{
   if (!targetvocab)
      return true ;			// allow any word if no vocab
   assertq(sub != 0) ;
   if (sub->consp())
      {
      const FrList *sublist = reinterpret_cast<const FrList*>(sub) ;
      for ( ; sublist ; sublist = sublist->rest())
	 {
	 if (!in_target_vocab(sublist->first(),targetvocab))
	    {
	    return false ;
	    }
	 }
      return true ;
      }
   else if (sub->printableName())
      {
      FrList *words = EbCvtString2Symbollist(sub) ;
      bool in_target = true ;
      for (FrList *wl = words ; wl ; wl = wl->rest())
	 {
	 FrSymbol *word = reinterpret_cast<FrSymbol*>(wl->first()) ;
	 if (!targetvocab->lookup(word))
	    {
	    in_target = false ;
	    break ;
	    }
	 }
      free_object(words) ;
      return in_target ;
      }
   return false ;
}

//----------------------------------------------------------------------

static FrList *backsub(const FrList *original, size_t offset,
		       const BiTextMap *bitext, size_t trgpos,
		       size_t srcoffset, size_t matchlen,
		       FrSymbol *symCONCAT,
		       const FrList **backsubs, size_t limit,
		       const FrSymHashTable *targetvocab)
{
   if (!original)
      return new FrList(0,0) ;
   FrObject *word = original->first() ;
   bool must_sub = (is_token(word) && !EBMT_equal(word,symCONCAT) &&
		      !EbIsGapMarker(FrPrintableName(word))) ;
   size_t sub_loc = (size_t)~0 ;
   size_t sublimit = limit ;
   if (must_sub)
      {
      // find the source word corresponding to the current target position
      //   and retrieve the replacement for that source location
      size_t srcpos = bitext->firstSourceCorrespondence(trgpos,srcoffset) ;
      if (srcpos >= srcoffset && srcpos - srcoffset < matchlen &&
	  bitext->wordsCorrespond(srcpos,trgpos) &&
	  backsubs[srcpos - srcoffset])
	 {
	 sub_loc = srcpos - srcoffset ;
	 if (backsubs[sub_loc]->rest())
	    sublimit /= 2 ;		// distribute our allotment more fairly
	 }
      }
   FrList *tails = backsub(original->rest(),offset+1,bitext,trgpos+1,srcoffset,
			   matchlen,symCONCAT,backsubs,sublimit,targetvocab) ;
   if (!tails)
      return 0 ;			// we had a substitution error
   FrList *result ;
   FrList **res_end = &result ;
   if (sub_loc != (size_t)~0)
      {
      // add each backsubstitution at the front of each tail we've been given
      size_t alts = 0 ;
      for (const FrList *bs = backsubs[sub_loc] ; bs ; bs = bs->rest())
	 {
	 const FrObject *b = bs->first() ;
	 if (!b || !in_target_vocab(b,targetvocab))
	    continue ;
	 for (FrList *t = tails ; t ; t = t->rest())
	    {
	    FrList *tail = FrCopyList((FrList*)t->first()) ;
	    pushlist(b->deepcopy(),tail) ;
	    result->pushlistend(tail,res_end) ;
	    if (++alts >= limit)	// avoid combinatorial explosion
	       break ;
	    }
	 if (alts >= limit)
	    break ;
	 }
      free_object(tails) ;
      backsubs[sub_loc] = 0 ;		// use any given replacement only once
      }
   else if (must_sub)
      {
      free_object(tails) ;
      tails = 0 ;
      }
   else
      {
      // add the current word at the front of each tail we've been given
      while (tails)
	 {
	 FrList *tail = (FrList*)poplist(tails) ;
	 pushlist(word?word->deepcopy():0,tail) ;
	 result->pushlistend(tail,res_end) ;
	 }
      }
   *res_end = 0 ;			// terminate the result list
   return result ;
}

//----------------------------------------------------------------------

static FrSymbol *generate_gap_marker(int where, const char *word)
{
   char type[FrMAX_SYMBOLNAME_LEN+1] ;
   if (word[0] == EbTOKEN_START)
      word++ ;
   strncpy(type,word,sizeof(type)) ;
   type[sizeof(type)-1] = '\0' ;
   char *end = strchr(type,EbTOKEN_END) ;
   if (end)
      *end = '\0' ;
   return EbMakeGapMarker(where,true,true,type) ;
}

//----------------------------------------------------------------------

static void clear_align_links(BiTextMap *bitext, size_t trgpos,
			      size_t srcoffset, size_t matchlen,
			      size_t keep_pos)
{
   for (size_t i = srcoffset ; i < srcoffset + matchlen ; i++)
      {
      if (i != keep_pos && bitext->wordsCorrespond(i,trgpos))
	 bitext->clearCorrespondence(i,trgpos) ;
      }
   return ;
}

//----------------------------------------------------------------------

static FrList *set_gap_markers(EBMTCandidate *cand, const FrList *translation,
			       FrSymbol *symCONCAT)
{
   BiTextMap *bitext = cand->bitext() ;
   // replace generalization markers with gap markers
   FrList *adjusted = 0 ;
   size_t trgpos = cand->targetOffset() ;
   size_t srcoffset = cand->sourceOffset() ;
   for ( ; translation ; translation = translation->rest(), trgpos++)
      {
      const FrObject *word = translation->first() ;
      if (is_token(word) && !EBMT_equal(word,symCONCAT) &&
	  !EbIsGapMarker(FrPrintableName(word)))
	 {
	 // get the position of the corresponding source and generate
	 //   a gap marker (or markers, in the case of a phrasal
	 //   substitution) if the source word is not the same token
	 //   as the target word
	 size_t srcpos = 
	    bitext->firstSourceCorrespondence(trgpos,srcoffset) ;
	 if (srcpos >= srcoffset && srcpos - srcoffset < cand->matchLength())
	    {
	    const FrObject *srcword = cand->sourceWords()->nth(srcpos-srcoffset) ;
	    FrSymbol *gap = 0 ;
	    if (!EBMT_equal(srcword,word))
	       {
	       size_t matchlen = cand->matchLength() ;
	       if (bitext->numSourceCorrespondences(trgpos) > 1)
		  {
		  // see whether one of the other source words matches
		  //   the token, if so, wipe out all alignment links
		  //   but that one
		  do {
		     srcpos = bitext->firstSourceCorrespondence(trgpos,
								srcpos+1) ;
		     if (srcpos - srcoffset < matchlen)
			{
			srcword = cand->sourceWords()->nth(srcpos-srcoffset) ;
			if (EBMT_equal(srcword,word))
			   {
			   clear_align_links(bitext,trgpos,srcoffset,matchlen,
					     srcpos) ;
			   break ;
			   }
			}
		     } while (srcpos - srcoffset < matchlen) ;
		  }
	       if (srcpos - srcoffset < matchlen)
		  gap = generate_gap_marker(srcpos - srcoffset,
					    word->printableName()) ;
	       }
	    pushlist(gap ? gap : word->deepcopy(),adjusted) ;
	    }
	 else
	    pushlist(word->deepcopy(), adjusted) ;
	 }
      else
	 {
	 pushlist(word ? word->deepcopy() : 0, adjusted) ;
	 }
      }
   return adjusted ;
}

//----------------------------------------------------------------------

BiTextMap *EBMTCandidate::phraseBitext() const
{
   if (bitext())
      return new BiTextMap(bitext(),sourceOffset(),sourceEnd(),
			   targetOffset(),targetEnd()) ;
   else
      return 0 ;
}

//----------------------------------------------------------------------

FrList *EBMTCandidate::backsubstitute(const FrList *translation,
				      const FrSymHashTable *targetvocab,
				      size_t trg_start)
{
   if (!bitext())
      {
      if (haveBackSubstitutions() && is_token(translation->first()) &&
	  !EbIsGapMarker(FrPrintableName(translation->first())))
	 {
	 FrList *substituted = 0 ;
	 if (matchLength() == 1 && translation->simplelistlength() == 1)
	    {
	    if (apply_backsubs && m_backsubs[0])
	       {
	       for (const FrList *bs = m_backsubs[0] ; bs ; bs = bs->rest())
		  {
		  const FrObject *backsub = bs->first() ;
		  if (backsub)
		     {
		     pushlist(new FrList(backsub->deepcopy()),substituted) ;
		     }
		  }
	       }
	    else
	       {
	       const char *word = FrPrintableName(translation->first()) ;
	       pushlist(new FrList(generate_gap_marker(0,word)),substituted) ;
	       }
	    }
	 return substituted ;
	 }
      else
	 return translation ? new FrList(translation->deepcopy()) : 0 ;
      }
   FrSymbol *symCONCAT = makeSymbol(CONCATENATION_MARKER) ;
   if (apply_backsubs)
      {
      size_t limit = BACKSUB_AMBIG_LIMIT ;
      if (trg_start == (size_t)~0)
	 trg_start = targetOffset() ;
      if (targetvocab)
	 limit *= 8 ;
      FrList *substituted = backsub(translation,0,bitext(),trg_start,
				    sourceOffset(),matchLength(),
				    symCONCAT,m_backsubs,limit,targetvocab) ;
      for (FrList *sub = substituted ; sub ; sub = sub->rest()->rest())
	 {
	 FrList *s = (FrList*)sub->first() ;
	 sub->replaca(FrFlattenListInPlace(s,true)) ;
	 }
      return substituted ;
      }
   else if (bitext())
      {
      FrList *adjusted = set_gap_markers(this,translation,symCONCAT) ;
      return adjusted ? new FrList(listreverse(adjusted)) : 0 ;
      }
   else
      return translation ? new FrList(translation->deepcopy()) : 0 ;
}

//----------------------------------------------------------------------

bool EBMTCandidate::alignMatch(EBMTCorpus *corpus,
			       bool keep_sentpair,
			       bool relaxed,
			       const FrSymHashTable *targetvocab)
{
   if (!targetSentence())
      {
      // check whether this example is only allowed to match in its entirety
      EBMTIndex *index = getIndex() ;
      if (index && index->requireExactMatch(exampleNumber()) &&
	  index->sourceLength(exampleNumber()) > matchLength())
	 {
	 markUnalignable() ;
	 return false ;
	 }
      // read the candidate sentence pair from the corpus file
      if (!loadSentencePair(corpus,false,true))
	 {
	 if (!quiet_mode)
	    FrWarningVA("unable to load sentence pair %u",
			(unsigned int)exampleNumber()) ;
	 return false ;
	 }
      }
   align_chunk(this,keep_sentpair,relaxed,targetvocab) ;
   return (alignmentScore() >= align_threshold && targetWords() != 0) ;
}

//----------------------------------------------------------------------

static FrList *collect_input(const EBMTCandidate *cand)
{
   FrList *input ;
   FrList **inp_end = &input ;
   for (size_t i = 0 ; i < cand->spansCovered() ; i++)
      {
      const FrTextSpan *span = cand->span(i) ;
      if (span)
	 {
	 char *text = span->initialText() ;
	 if (ignore_source_case)
	    Fr_strlwr(text,char_encoding) ;
	 input->pushlistend(new FrString(text),inp_end) ;
	 FrFree(text) ;
	 }
      }
   *inp_end = 0 ;			// terminate list
   FrString *input_str = new FrString(input) ;
   free_object(input) ;
   input = FrCvtSentence2Wordlist(input_str->stringValue()) ;
   free_object(input_str) ;
   return input ;
}

//----------------------------------------------------------------------

static FrList *lexicalize_structure(const FrList *tags,
				    EBMTCandidate *cand,
				    bool &full_lexicalization)
{
   if (!tags)
      {
      full_lexicalization = false ;
      return 0 ;			// nothing to do
      }
   EBMTIndex *index = cand->getIndex() ;
   EbBWTIndex *idx_m = index ? index->selectIndex(EbIndex_Main) : 0 ;
   EbBWTIndex *idx_u = index ? index->selectIndex(EbIndex_Updates) : 0 ;
   const EbSentence *target_sent = cand->targetSentence() ;
   if (!idx_m ||
       (!idx_m->haveIndexLocations() && !index->setIndexLocations()) ||
       !target_sent)
      return (FrList*)tags->deepcopy() ; // can't lexicalize
   // find the start of the record
   EbBWTIndex *idx = idx_m ; 
   uint32_t loc = idx_m->indexLocation(cand->exampleNumber()) ;
   if (loc == (uint32_t)~0 && idx_u)
      {
      loc = idx_u->indexLocation(cand->exampleNumber()) ;
      idx = idx_u ;
      }
   size_t s_start = cand->sourceOffset() ;
   size_t t_start = cand->targetOffset() ;
   size_t t_end = cand->targetEnd() ;
   FrList *lex_input = collect_input(cand) ;
   FrList *ex_source = idx->retrieveSource(loc,index->vocabulary()) ;
   FrList *ex_target = target_sent->wordList(t_start,t_end) ;
   for (size_t i = 0 ; i < s_start ; i++)
      free_object(poplist(ex_source)) ;
   FrList *result ;
   FrList **res_end = &result ;
   size_t totalcount = 0 ;
   size_t lexcount = 0 ;
   for ( ; tags ; tags = tags->rest())
      {
      totalcount++ ;
      const FrObject *tag = tags->first() ;
      const char *tagstr = FrPrintableName(tag) ;
      if (tagstr && EbIsEmbeddedGapMarker(tagstr))
	 {
	 cand->numTokens(cand->numTokens()+1) ;
	 size_t ofs = EbGapFillerLocation(tagstr,0,0) ;
	 FrObject *inpword = lex_input->nth(ofs) ;
	 FrObject *srcword = ex_source->nth(ofs) ;
         if (equal(inpword,srcword))
	    {
	    tag = ex_target->first() ;
	    lexcount++ ;
	    }
	 result->pushlistend(tag?tag->deepcopy():0,res_end) ;
	 }
      else
	 result->pushlistend(tag?tag->deepcopy():0,res_end) ;
      free_object(poplist(ex_target)) ;
      }
   *res_end = 0 ;			// terminate the list
   size_t min_lex = (min_struct_lex >= 1.0 
		     ? (size_t)min_struct_lex 
		     : (size_t)(min_struct_lex * totalcount + 0.9)) ;
   full_lexicalization = (lexcount == totalcount) || (lexcount < min_lex) ;
   free_object(lex_input) ;
   free_object(ex_source) ;
   free_object(ex_target) ;
   return result ;
}

//----------------------------------------------------------------------

static FrList *map_to_gap_markers(const FrList *tags,
				  EBMTCandidate *cand, bool &ambig)
{
   const BiTextMap *bitext = cand->bitext() ;
   size_t s_start = cand->sourceOffset() ;
   size_t s_end = cand->sourceEnd() ;
   size_t t_end = cand->targetEnd() ;
   FrList *result ;
   FrList **res_end = &result ;
   for (size_t t_pos = cand->targetOffset() ;
	tags && t_pos <= t_end ;
	tags = tags->rest(), t_pos++)
      {
      const FrObject *tag = tags->first() ;
      FrString *marker = 0 ;
      size_t count = 0 ;
      if (bitext)			// complete-match cands have no bitext
	 {
	 // if there's an unambiguous source alignment for the current target
	 //   tag, grab its location and build a marker
	 count = bitext->numSourceCorrespondences(t_pos,s_start,s_end) ;
	 if (count == 0 && bitext->numSourceCorrespondences(t_pos) == 1)
	    {
	    // we have a unique link outside the source match, so check whether
	    //   to replace it with a gap marker pointing outside the source
	    size_t s_pos = bitext->firstSourceCorrespondence(t_pos,0) ;
	    long offset ;
	    if (s_pos < s_start)
	       offset = s_pos - s_start ;
	    else
	       offset = s_pos - s_end ;
	    if ((size_t)abs(offset) > EBMT_word_order_similarity)
	       ambig = true ;
	    else
	       marker = EbMakeGapMarkerStr(offset,false,false,
					   FrPrintableName(tag)) ;
	    }
	 else if (count != 1)
	    ambig = true ;
	 }
      else
	 count = 0 ;
      if (count >= 1)
	 {
	 size_t s_loc
	    = bitext->firstSourceCorrespondence(t_pos,s_start) - s_start ;
	 marker = EbMakeGapMarkerStr(s_loc,false,true,FrPrintableName(tag)) ;
	 }
      else if (!marker)
	 {
	 marker = new FrString(FrPrintableName(tag)) ;
	 }
      result->pushlistend(marker,res_end) ;
      }
   *res_end = 0 ;			// properly terminate the list
   return result ;
}

//----------------------------------------------------------------------

static void elide_noncorresponding(FrList *&submatch, EBMTCandidate *candidate,
				   size_t start, size_t end, size_t mask)
{
   if (!submatch)
      return ;
   size_t additional_words = end - start ;
   if (additional_words > CHAR_BIT * sizeof(mask))
      additional_words = CHAR_BIT * sizeof(mask) ;
   FrList *sub = submatch->rest() ; // mask starts with second word, skip first
   size_t sim = EbMaxGapOffset() ;
   size_t src_start = candidate->sourceOffset() ;
   size_t src_end = candidate->sourceEnd() ;
   for (size_t i = 0 ; i < additional_words && sub ; i++, sub = sub->rest())
      {
      if ((mask & (1L << i)) == 0)
	 {
	 free_object(sub->first()) ;
	 if (candidate->numSourceCorrespondences(start+i+1) == 1)
	    {
	    // check whether the unique correspondence is just outside the
	    //   source chunk; if so, instead of completely eliding the target
	    //   word, we'll insert a marker for the decoder to try to fill
	    //   in an appropriate translation from another candidate
	    size_t src = candidate->firstSourceCorrespondence(start+i+1) ;
	    if (src < src_start && src_start - src <= sim)
	       sub->replaca(EbMakeGapMarker((int)(src-src_start))) ;
	    else if (src > src_end && src - src_end <= sim)
	       sub->replaca(EbMakeGapMarker((int)(src-src_end))) ;
	    else
	       sub->replaca(EbMakeGapMarker(0)) ;
	    }
	 else
	    sub->replaca(EbMakeGapMarker(0)) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void EBMTCandidate::clearTargetWords()
{
   free_object(target_words) ;
   target_words = 0 ;
   target_offset = target_end = (EbUSHORT)0 ;
   return ;
}

//----------------------------------------------------------------------

void EBMTCandidate::setTargetWords(FrString *tw, size_t offset, size_t end,
				   size_t mask)
{ 
   free_object(target_words) ;
   target_words = tw ;
   target_offset = (EbUSHORT)offset ;
   target_end = (EbUSHORT)end ;
   if (!tw)
      return ;				// this was a simple init call
   if (sourceIndex() == EbIndex_Struct)
      {
      FrList *restric = targetRestrictions() ;
      if (restric)
	 {
	 // replace the given target words with the structural tags (since
	 //   the given words will be meaningless anyway)
	 free_object(target_words) ;
	 bool ambig = false ;
	 // convert simple tags into <@:n_POS> markers by looking at the
	 //   bitext map
	 FrList *r = map_to_gap_markers(restric,this,ambig) ;
	 restric->freeObject() ;
	 if (r && !ambig)
	    {
	    bool fully_lexed = false ;
	    FrList *lex_r = lexicalize_structure(r,this,fully_lexed) ;
	    if (fully_lexed)
	       {
	       // we don't want to use this one, since it duplicates a
	       //   non-structural match anyway
	       // (!!! is that always the case? )
	       markUnalignable() ;
	       }
	    free_object(r) ;
	    target_words = new FrString(lex_r,char_encoding) ;
	    free_object(lex_r) ;
	    }
	 else
	    {
	    free_object(r) ;
	    target_words = 0 ;
	    markUnalignable() ;
	    }
	 }
      }
   else if (tw && mask != (size_t)~0)
      {
      FrList *twords = FrCvtSentence2Wordlist(tw->stringValue()) ;
      elide_noncorresponding(twords,this,offset,end,mask) ;
      free_object(target_words) ;
      target_words = new FrString(twords) ;
      free_object(twords) ;
      }
   return ;
}

//----------------------------------------------------------------------

void EBMTCandidate::setGeneralizationSequence(FrList *gen_seq)
{
   free_object(m_generalizationseq) ;
   m_generalizationseq = gen_seq ;
   return ;
}

//----------------------------------------------------------------------

bool EBMTCandidate::havePhraseAlignments() const
{
   return metainfo.haveField(EbCorpusMetaInfo::phrase_tag) ;
}

//----------------------------------------------------------------------

double EBMTCandidate::phraseAlignSuperset(size_t &trg_start,size_t &trg_end,
					  size_t &trg_mask)
   const
{
#define MAX_PHRASE 17
   trg_start = 0 ;
   trg_end = 0 ;
   if (!havePhraseAlignments() || matchLength() >= MAX_PHRASE)
      return -1.0 ;			// can't extend any
   // find the best-scoring phrasal alignment that has as its source phrase
   //   a superset of the indicated range
   // to bias the selection toward shorter phrases (fewer extraneous words),
   //   discount the score by dividing by the number of extra words
//!!! should also try intersecting two phrasal alignments with, respectively,
//   very little left extension and very little right extension
   double best_score = -0.1 ;
   double best_left = 0 ;
   double best_right = sourceLength() - matchLength() ;
   size_t best_trg_start = ~0 ;
   size_t best_trg_end = 0 ;
   size_t best_trg_mask = 0 ;
   size_t src_end = sourceEnd() ;
   size_t max_extension = MAX_PHRASE - matchLength() ;
   size_t max_left = sourceOffset() < max_extension ? sourceOffset() : max_extension ;
   for (size_t left = 0 ; left < max_left ; left++)
      {
      size_t max_right = ((sourceLength()-src_end < max_extension - left)
			  ? (size_t)(sourceLength()-src_end)
			  : max_extension - left) ;
      for (size_t right = 0 ; right < max_right ; right++)
	 {
	 size_t t_start, t_end, t_mask ;
	 // get the best-scoring alignment for the desired source phrase
	 double align = metainfo.phraseAlign(sourceOffset()-left,src_end+right,
					     t_start,t_end,t_mask) ;
	 if (left+right > 0)
	    align /= (left + right + 0.1) ;
	 if (align > best_score)
	    {
	    best_score = align ;
	    best_left = left ;
	    best_right = right ;
	    best_trg_start = t_start ;
	    best_trg_end = t_end ;
	    best_trg_mask = t_mask ;
	    }
	 }
      }
   if (best_score > 0.0 && best_trg_start < targetLength() &&
       best_trg_end < targetLength())
      {
      trg_start = best_trg_start ;
      trg_end = best_trg_end ;
      trg_mask = best_trg_mask ;
      }
   return best_score ;
}

//----------------------------------------------------------------------

bool EBMTCandidate::crossesPhrases() const
{
   return (havePhraseAlignments() &&
	   metainfo.phraseAlignIncludes(sourceOffset(),sourceEnd())) ;
}

//----------------------------------------------------------------------

static int cmp_stri(const FrString *s1, const FrString *s2) {
  if(s1 == s2)
    return 0;
  if(!s1)
    return +1;
  if(!s2)
    return -1;

  const char *c1 = s1->printableName();
  const char *c2 = s2->printableName();

  if(c1 == c2)
    return 0;
  if(!c1)
    return +1;
  if(!c2)
    return -1;

  return Fr_stricmp(c1, c2, uppercase_table);
}

//----------------------------------------------------------------------

static int compare_chunk(const EBMTCandidate *c1, const EBMTCandidate *c2)
{
   int cmp = c1->inputStart() - c2->inputStart() ;
   if (cmp != 0)
      return cmp ;
   cmp = c1->inputLength() - c2->inputLength() ;
   if (cmp == 0)
      {
      cmp = cmp_stri(c1->targetWords(), c2->targetWords());
      if (cmp == 0)
	 {
	 double diff = c1->score() - c2->score() ;
	 cmp = (diff < 0.0) ? +1 : ((diff > 0.0) ? -1 : 0) ;

	 if((cmp == 0) && (c1->generalizations != c2->generalizations))
	   {      
	     if(!c1->generalizations)
	       cmp = -1;
	     else
	       cmp = c1->generalizations->compare(c2->generalizations);
	   }
	 }
      }
   return cmp ;
}

//----------------------------------------------------------------------

static int compare_chunk_align(const EBMTCandidate *c1,
			       const EBMTCandidate *c2)
{
   int cmp = c1->inputStart() - c2->inputStart() ;
   if (cmp != 0)
      return cmp ;
   cmp = c1->inputLength() - c2->inputLength() ;
   if (cmp == 0)
      {
      // Check Generalizations
      if (c1->generalizations != c2->generalizations)
	 {
	 if (c1->generalizations)
	    cmp = c1->generalizations->compare(c2->generalizations) ;
	 else
	    cmp = -1 ;
	 }
      if (cmp == 0)
	 {
	 cmp = cmp_stri(c1->targetWords(), c2->targetWords()) ;
	 if (cmp == 0)
	    {
	    double diff = (c1->alignmentScore() * c1->confidence() -
			   c2->alignmentScore() * c2->confidence()) ;
	    cmp = (diff < 0.0) ? +1 : ((diff > 0.0) ? -1 : 0) ;
	    }
	 }
      }
   return cmp ;
}

//----------------------------------------------------------------------

static int compare_score(const EBMTCandidate *cand1,
			 const EBMTCandidate *cand2)
{
   int comp = cand1->inputStart() - cand2->inputStart() ;
   if (comp != 0)
      return comp ;
   comp = cand1->inputLength() - cand2->inputLength() ;
   if (comp != 0)
      return comp ;
   double cmp = cand1->score() - cand2->score() ;
   if (cmp == 0.0)
      {
      // if the scores are the same, sort by decreasing confidence
      cmp = cand1->confidence() - cand2->confidence() ;
      if (cmp == 0.0)
	 {
	 // next, sort by decreasing chunking bonus
	 cmp = cand1->chunkingBonus() - cand2->chunkingBonus() ;
	 if (cmp == 0.0)
	    {
	    // and if the bonuses are the same as well, sort by decreasing
	    //   alignment quality
	    cmp = cand1->alignmentQuality() - cand2->alignmentQuality() ;
	    if (cmp == 0.0)
	       {
	       // finally, sort by decreasing frequency
	       cmp = cand1->frequency() - cand2->frequency() ;
	       }
	    }
	 }
      }
   return (cmp < 0.0) ? +1 : ((cmp > 0.0) ? -1 : 0) ;
}

//----------------------------------------------------------------------

EBMTCandidate *EBMTCandidate::sortByChunk()
{
   return FrMergeSortPtr(this,compare_chunk) ;
}

//----------------------------------------------------------------------

EBMTCandidate *EBMTCandidate::sortByChunkAlign()
{
   return FrMergeSortPtr(this,compare_chunk_align) ;
}

//----------------------------------------------------------------------

EBMTCandidate *EBMTCandidate::sortByScore()
{
   return FrMergeSortPtr(this,compare_score) ;
}

//----------------------------------------------------------------------

EBMTCandidate *EBMTCandidate::sortByChunkPosition()
{
   EBMTCandidate *c1 = (EBMTCandidate *)this ;

   if (!c1)				// empty list?
      return c1 ;			// if yes, it's already sorted
   EBMTCandidate *end = c1->next() ;
   if (!end)				// one-element list?
      return c1 ;			// if yes, it's already sorted
   EBMTCandidate *c2 = c1 ;
   // find mid-point of list by advancing 'end' two chunks for each chunk that
   // 'c2' (middle) advances
   while (end)
      {
      end = end->next() ;
      if (!end)
	 break ;
      end = end->next() ;
      c2 = c2->next() ;
      }
   end = c2->next() ;
   c2->setNext(0) ;
   if (c2 != c1)
      c1 = c1->sortByChunkPosition() ;
   c2 = end->sortByChunkPosition() ;

   EBMTCandidate *result ;
   EBMTCandidate **l = &result ;
   while (c1 && c2)			// as long as we have two lists....
      {
      // sort by position within the sentence to be translated, then by
      // reverse chunk size, and finally by reverse position within the
      // corpus for identical chunks
      int cmp = c1->inputStart() - c2->inputStart() ;
      if (cmp == 0)
	 {
	 cmp = c2->matchLength() - c1->matchLength() ;
	 if (cmp == 0)
	    {
	    bool comp1 = c1->completeMatch() ;
	    bool comp2 = c2->completeMatch() ;
	    if (comp1)
	       {
	       if (!comp2)
		  cmp = -1 ;
	       }
	    else if (comp2)
	       cmp = +1 ;
	    else
	       {
	       uint32_t loc1 = c1->exampleNumber() ;
	       uint32_t loc2 = c2->exampleNumber() ;
	       if (loc1 < loc2)
		  cmp = +1 ;
	       else if (loc1 > loc2)
		  cmp = -1 ;
	       }
	    }
	 }
      // determine which list contains the next item for the merged list
      if (cmp <= 0)
	 {
	 *l = c1 ;			// glue item onto end of results list
	 l = c1->nextPtr() ;
	 c1 = c1->next() ;		// advance down list1
	 }
      else
	 {
	 *l = c2 ;			// glue item onto end of results list
	 l = c2->nextPtr() ;
	 c2 = c2->next() ;		// advance down list2
	 }
      }
   if (c1)				// anything left over in first list?
      *l = c1 ;				//   append remainder to merged list
   else // if (c2)			// anything left over in second list?
      *l = c2 ;				//   append remainder to merged list
   return result ;
}

//----------------------------------------------------------------------

void EBMTCandidate::normalizeFeatureValues()
{
   EbFeatureVector *fv = features() ;
   double scale = 1.0 / fv->value(featureID_frequency) ;
   for (size_t i = 0 ; i < fv->numFeatures() ; i++)
      {
      //FIXME: this could be done more efficiently
      if (i != featureID_score && i != featureID_quality &&
	  i != featureID_probability && i != featureID_frequency &&
	  i != featureID_frequency1 && i != featureID_frequency2 &&
	  i != featureID_frequency3 && /* i != featureID_frequency4 &&
	  i != featureID_frequency5 &&*/ i != featureID_frequencylong)
	 {
	 fv->scaleValue(i,scale) ;
	 }
      }
   normalizeAlignQuality() ;
   return ;
}

//----------------------------------------------------------------------

double EBMTCandidate::log(double x)
{
   // avoid infinities and other problems by restricting the input to be
   //  a number large enough to produce a valid logarithm
   if (x < DBL_MIN)
      x = DBL_MIN ;
   return ::log(x) ;
}

//----------------------------------------------------------------------

ostream &EBMTCandidate::dumpCandidate(ostream &out) const
{
   out << "Candidate Chunk (" << exampleNumber() << ' '
       << inputStart() << ':' << inputStart()+matchLength()-1 << ')'
       << endl ;
   out << "  source words: " << sourceWords() << ", input cover: "
       << inputWords() << endl ;
   FrList *trg = targetSentence() ? targetSentence()->wordList() : 0 ;
   out << "  target sentence: " << trg << endl ;
   free_object(trg) ;
   out << "  source chunk [" << sourceOffset() << ',' << sourceEnd() << "]: "
       << sourceWords() << endl ;
   if (bitext())
      out << "  [have bitext map]" << endl ;
   if (targetWords())
      out << "	target chunks [" << score() << "]: " << targetWords() << endl ;
   return out ;
}

//----------------------------------------------------------------------

void EBMTCandidate::_() const
{
   (void)dumpCandidate(cout) ;
   return ;
}

//----------------------------------------------------------------------

FrList *EBMTCandidate::targetRestrictions() const
{
   return metainfo.targetRestrictions(targetOffset(),targetEnd()) ;
}

//----------------------------------------------------------------------

FrList *EBMTCandidate::targetSpans() const
{
   // if we have explicitly labeled target spans, use them
   FrList *spans = metainfo.targetSpans(targetOffset(),targetEnd()) ;
   // if there are no explicit target labels, check for chunk
   //   boundaries and add any chunk labels for the source match to
   //   the list of target span labels
   if (!spans && bitext())
      {
      FrList **sp_end = &spans ;
      size_t s_start = 0 ;
      size_t numchunks = metainfo.numChunkBounds() ;
      size_t t_end = targetEnd() ;
      for (size_t i = 1 ; i <= numchunks && s_start <= sourceEnd() ; i++)
	 {
	 size_t s_end = metainfo.chunkBound(i,sourceEnd()) ;
	 FrSymbol *label = metainfo.chunkLabel(i) ;
	 if (label && s_end > sourceOffset())
	    {
	    // find the target positions which align only to the
	    //   current source chunk and add them to the list of
	    //   spans
	    FrList *span = 0 ;
	    for (size_t j = targetOffset() ; j <= t_end ; j++)
	       {
	       int count = numSourceCorrespondences(j) ;
	       if (count > 0 && count == numSourceCorrespondences(j,s_start,s_end-1))
		  pushlist(new FrInteger(j - targetOffset()),span) ;
	       }
	    // if we have any target words for the source chunk, add the
	    //   span information to the list of spans
	    if (span)
	       {
	       span = span->sort(compare_numbers) ;
	       pushlist(label,span) ;
               spans->pushlistend(span,sp_end) ;
	       }
	    }
	 s_start = s_end ;
	 }
      *sp_end = 0 ; // properly terminate list at 'span'
      }
   // if we did any generalization, add in the equivalence class names
   //   on the appropriate spans

   //FIXME spans = spans->nconc( spans-from-generalization ) ;
   return spans ;
}

/************************************************************************/
/************************************************************************/

FrList *EbCandidateOrigin(const EBMTCandidate *candidate)
{
   if (candidate)
      {
      EBMTCorpus *corpus = candidate->sourceCorpus() ;
      if (!corpus)
	 corpus = active_EBMTCorpus() ;
      if (corpus)
	 {
	 EBMTIndex *index = corpus->getIndex() ;
	 if (index)
	    {
	    uint32_t location = candidate->exampleNumber() ;
	    const char *sourcefile = index->getOrigin(location) ;
	    if (!sourcefile) sourcefile = "" ;
	    return new FrList(makeSymbol("ORIGIN"),new FrString(sourcefile),
			      new FrInteger(location)) ;
	    }
	 }
      }
   return 0 ;
}

// end of file ebcand.cpp //
