/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File dict.h		EBMT translation dictionary			*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2006,2007,2008,2009 Ralf Brown				*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __DICT_H_INCLUDED
#define __DICT_H_INCLUDED

#ifndef __FRAMEPAC_H_INCLUDED
#include "FramepaC.h"
#endif

#if defined(__GNUC__)
#  pragma interface
#endif

//#define DICT_V3

//----------------------------------------------------------------------

#define DICT_VERSION_STR "2.10"

#define DEFAULT_DICT_NAME "default.dct"

#define STEMWORD_SIGNATURE1 "Pangloss-Lite Word Stems"
#define STEMWORD_SIGNATURE2 "Word Stems"

//----------------------------------------------------------------------

#define POS_unknown	0
#define POS_Noun        1
#define POS_Verb	2
#define POS_Adjective	3
#define POS_Adverb	4
#define POS_Conjunction	5
#define POS_Determiner	6
#define POS_Preposition	7
#define POS_Postmod	8

#define CASE_unknown	0
#define CASE_nominative	1
#define CASE_genitive	2
#define CASE_dative	3
#define CASE_accusative	4
#define CASE_locative	5
#define CASE_instrumental 6
#define CASE_vocative	7

//----------------------------------------------------------------------

#define DICT_LAST_MASK	0x00800000
#define DICT_LAST_MASK0 0x80

#ifdef DICT_V3
#define DICT_CASE_MASK	0xE0000000
#define DICT_CASE_MASK0 0xE0
#define DICT_CASE_SHIFT 29
#define DICT_CASE_SHIFT0 5

#define DICT_POS_MASK   0x1E000000
#define DICT_POS_MASK0  0x1E
#define DICT_POS_SHIFT	25
#define DICT_POS_SHIFT0 1

#define DICT_INDEX_MASK	0x007FFFFF
#define DICT_MAX_INDEX	0x007FFFFE

#define DICT_COUNT_MASK 0x01FFFFFF
#define DICT_MAX_COUNT	0x01FFFFFF

#else /* version 2 dictionary */
#define DICT_CASE_MASK	0x00700000
#define DICT_CASE_MASK0 0x70
#define DICT_CASE_SHIFT 20
#define DICT_CASE_SHIFT0 4

#define DICT_POS_MASK   0x00F00000
#define DICT_POS_MASK0  0xF0
#define DICT_POS_SHIFT	20
#define DICT_POS_SHIFT0 4

#define DICT_INDEX_MASK	0x000FFFFF
#define DICT_MAX_INDEX	0x000FFFFE

#define DICT_COUNT_MASK 0x000FFFFF
#define DICT_MAX_COUNT	0x000FFFFF
#endif /* DICT_V3 */

//----------------------------------------------------------------------

typedef unsigned char LONGbuffer[4] ;

typedef bool DictIteratorFunc(FrSymbol *word, const FrList *defs,
				va_list args) ;

//----------------------------------------------------------------------

class DictDefItem			// see ebdict.cpp for dict format
   {
   private:
      unsigned char m_index[3] ;
#ifdef DICT_V3
      LONGbuffer m_occur ;
#else
      unsigned char m_occur[3] ;
#endif /* DICT_V3 */
   public:
      void *operator new(size_t,void *where) { return where ; }
      DictDefItem() {}
      DictDefItem(size_t count, size_t def_index, int pos, int wordcase,
		  bool is_last) ;
      ~DictDefItem() {}

      // access to current state
      uint32_t getCount() const ;
      const FrObject *getDef(FrObject **defs) const ;
      size_t getDefIndex() const ;
      int getPOS() const
	    { return (m_occur[0] & DICT_POS_MASK0) >> DICT_POS_SHIFT0 ; }
#ifdef DICT_V3
      int getCase() const
	 { return (m_occur[0] & DICT_POS_MASK0) >> DICT_POS_SHIFT0 ; }
#else
      int getCase() const
  	    { return (m_index[0] & DICT_CASE_MASK0) >> DICT_CASE_SHIFT0 ; }
#endif
      bool isLast() const { return (m_index[0] & DICT_LAST_MASK0) != 0 ; }

      // state-update functions
      void incrCount() ;
      void setCount(uint32_t newcount) ;
      void setPOS(int POS) ;
      void setCase(int CASE) ;
      void setLast(bool last)
	    { if (last)
	         m_index[0] |= DICT_LAST_MASK0 ;
	      else m_index[0] &= ~DICT_LAST_MASK0 ; }
   } ;

//----------------------------------------------------------------------

class DictionaryEntry
   {
   private:
      double m_probability ;
      FrObject *m_translation ;
      int m_POS ;
   public:
      void *operator new(size_t, void *where) { return where ; }
      DictionaryEntry()
	 { m_probability = 0.0 ; m_translation = 0 ; m_POS = POS_unknown ; }
      DictionaryEntry(const DictionaryEntry &old)
         { m_probability = old.m_probability ;
	   m_translation = old.m_translation ;
	   m_POS = old.m_POS ; }
      DictionaryEntry(FrObject *trans, double prob, int POS)
	 { m_translation = trans ; m_probability = prob ; m_POS = POS ; }
      ~DictionaryEntry() { free_object(m_translation) ; m_translation = 0 ; }

      // accessors
      double probability() const { return m_probability ; }
      const FrObject *translation() const { return m_translation ; }
      int POS() const { return m_POS ; }

      // support for FrQuickSort
      static int compare(DictionaryEntry &x, DictionaryEntry &y) ;
      static void swap(DictionaryEntry &x, DictionaryEntry &y)
         { double prob = x.m_probability ;
	   FrObject *trans = x.m_translation ;
	   int pos = x.m_POS ;
	   x.m_probability = y.m_probability ;
	   x.m_translation = y.m_translation ;
	   x.m_POS = y.m_POS ;
	   y.m_probability = prob ;
	   y.m_translation = trans ;
	   y.m_POS = pos ; }
   } ;

//----------------------------------------------------------------------

class DictWordInfo ;

class Dictionary
   {
   private:
      static Dictionary *dictionaries ;
      Dictionary *next_dict ;
      Dictionary **prev_dict_next ;
      char    *headwordnames ;		// base of the SL word-name strings
      DictWordInfo *headinfo ;		// name/defn-list index/freq of heads
      DictDefItem *definitions ;	// array of word-definition lists
      FrObject **defs ;			// array of unique TL definitions
      FrHashTable *defhash ;		// index into 'defs' by TL value
      char    *dictfile ;		// disk file containing dictionary
      void    *mapped_addr ;
      void    *end_mapping ;
      FrFileMapping *mapped_dict ;
      size_t   refcount ;
      size_t   defs_size ;		// size of defs array
      size_t   numdefs ;		// number of items used in defs
      size_t   availdefs ;		// number of empty items w/in numdefs
      size_t   heads_size ;		// size of headinfo arrays
      size_t   numheads ;		// number of head words in use
      size_t   names_size ;		// bytes in use for 'headwordnames'
      size_t   names_alloc ;		// bytes allocated for 'headwordnames'
      size_t   definition_size ;	// size of 'definitions' buffer
      size_t   definition_items ;	// amount of 'definitions' in use
      bool   readonly ;		// dictionary can't be modified
      bool   heads_mapped ;		// 'headinfo' memory-mapped?
      bool   definitions_mapped ;	// 'definitions' memory-mapped?
      bool   names_mapped ;		// 'headwordnames' memory-mapped?
      bool   dict_changed ;
      bool   _good ;
   private:
      void init(bool complete = true) ;
      void addReference() { refcount++ ; }
      size_t add_dict_definition(const FrObject *translation) ;
      size_t definition_length(size_t loc) const ;
      bool unmapDefinitions(size_t expand_by = 0) ;
      bool unmapHeads() ;
      bool shiftDefItems(size_t boundary, size_t oldsize, size_t newsize) ;
      bool expandDefsBuffer() ;
      bool expandDefinitionBuffer(size_t extra) ;
      const char *wordName(size_t wordnum) const ;
      size_t findWord(const char *word) const ;
      size_t findWord(const FrSymbol *word) const
	 { return findWord(word?word->symbolName():"") ; }
      size_t insertionPoint(const char *word) const ;
      size_t newHeadWord(const FrSymbol *word, size_t frequency = 0,
			 bool already_sorted = false) ;
      size_t getIndex(const FrObject *definition) ;
      void adjustLoc(size_t boundary, int adjust) ;
      FrObject *retrieveTranslation(size_t defnum,
				    bool alwayscopy = false,
				    bool *is_copy = 0) const ;
      FrObject *retrieveTranslation(const DictDefItem *def,
				    bool alwayscopy = false,
				    bool *is_copy = 0) const
         {
	 return retrieveTranslation(def->getDefIndex(),alwayscopy,is_copy) ;
	 }
      bool sameTranslation(const DictDefItem *, const FrObject *) const ;
   public:
      Dictionary() ;
      Dictionary(const char *filename, bool readonly = false) ;
      ~Dictionary() ;
      bool load(const char *filename, bool readonly = false) ;
      bool save() ;
      void cancelSave() { dict_changed = false ; }
      bool exportDict(const char *filename) ;
      bool defineWord(const FrSymbol *word, const FrList *translations,
			size_t frequency = 0, size_t count = 0,
			int POS = POS_unknown, int CASE = CASE_unknown) ;
      bool defineWord(const char *word, const FrList *translations,
			size_t frequency = 0, size_t count = 0,
			int POS = POS_unknown, int CASE = CASE_unknown)
	    { return defineWord(makeSymbol(word),translations,frequency,count,
				POS,CASE);}
      bool defineWordCounted(const FrSymbol *word,
			       const FrList *translations,
			       size_t frequency = 0) ;
      bool addDefinition(const FrSymbol *word, const FrObject *translation,
			   size_t frequency = 0, size_t count = 0,
			   int POS = POS_unknown, int CASE = CASE_unknown) ;
      bool addDefinitionCounted(const FrSymbol *word,
				  const FrList *translation,
				  size_t frequency = 0) ;
      bool addDefinition(const char *word, const char *translation) ;
      bool addDefinitions(const FrSymbol *word, const FrList *translations) ;
      bool addDefinitionsCounted(const FrSymbol *word,
				   const FrList *translations,
				   size_t frequency) ;
      bool addInstance(const FrSymbol *word, const FrObject *translation) ;
      bool setCount(const FrSymbol *word, size_t freq = 1) ;
      bool setCount(const FrSymbol *word, const FrObject *translation,
		      size_t freq = 1) ;
      bool clearCounts(const FrSymbol *word) ;
      bool clearCounts() ;		// clear counts for all words
      FrList *lookup(const char *word, size_t max_xlat = ~0,
		     int POS = POS_unknown) const ;
      FrList *lookup(const FrSymbol *word, size_t max_xlat = ~0,
		     int POS = POS_unknown) const
	    { return lookup(word?word->symbolName():"",max_xlat,POS) ; }
      FrList *lookup(const FrTextSpans *words, size_t max_xlat = ~0,
		     int POS = POS_unknown) const ;
      DictionaryEntry *lookupProbabilities(const char *word,
					   size_t &numtrans,
					   double smoothing = 0.0,
					   int POS = POS_unknown) const ;
      FrList *lookupTranslations(const FrSymbol *word,
				 int POS = POS_unknown) const ;
      bool isTranslation(const FrSymbol *srcword, FrSymbol *trgword) const ;
      bool isTranslation(const FrSymbol *srcword, FrSymbol *trgword,
			   bool fold_case) const ;

      bool iterateVA(DictIteratorFunc func, va_list args) const ;
      bool __FrCDECL iterate(DictIteratorFunc func, ...) const ;

      // access to internal state
      Dictionary *next() { return next_dict ; }
      const Dictionary *next() const { return next_dict ; }
      bool OK() const { return _good ; }
      bool changed() const { return dict_changed ; }
      size_t dictSize() const { return numheads ; }
      bool isDefined(const FrSymbol *word) const ;
      const char *dictFileName() const { return dictfile ; }
      bool isReadOnly() const { return readonly ; }

      // multi-dictionary functions
      static Dictionary *findDictionary(const char *filename) ;
      static Dictionary *open(const char *filename,
			      bool load_readonly = false) ;
      bool close() ;
   } ;

//----------------------------------------------------------------------

class DictConfig : public FrConfiguration
   {
   private:
      static FrConfigurationTable DICT_def[] ;
   public: // data
      char *char_enc ;
      char *dictionary_file ;
      long int options ;
      long int socketnum ;
      FrList *dict_sstoplist ;
      FrList *dict_tstoplist ;
      int	last_local_var ;	// must be last in list
   public: // methods
      DictConfig(const char *base_dir) : FrConfiguration(base_dir) {}
      virtual ~DictConfig() ;
      virtual void init() ;
      virtual void resetState() ;
      virtual size_t lastLocalVar() const ;
      virtual bool onChange(FrConfigVariableType, void *where) ;
      virtual ostream &dump(ostream &out) const ;
   } ;

//----------------------------------------------------------------------

void DcIdentifyDictionary(ostream &out, bool as_comment = false) ;

bool DcInitializeDictionary(const char *dictfile,
			      bool load_readonly = false) ;
Dictionary *DcActiveDictionary() ;
void DcSetActiveDictionary(Dictionary *dict) ;

FrList *process_sentence_dictionary(const FrList *sentence) ;

bool DcSaveDictionaryUpdates() ;
bool DcExportDictionary(const char *filename, Dictionary *dict = 0) ;
bool DcShutdownDictionary() ;

bool DcKeepCase(bool keep) ;

void DcLoadWordstems(const char *filename) ;
void DcFreeWordstems() ;

#endif /* !__EBDICT_H_INCLUDED */

// end of file dict.h //
