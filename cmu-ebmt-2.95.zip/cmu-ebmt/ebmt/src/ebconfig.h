/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebconfig.h							*/
/*  LastEdit: 20apr10							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,1999,2000,2001,2002,2003	*/
/*		2004,2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*  with contributions by Aaron B. Phillips				*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __EBCONFIG_H_INCLUDED
#define __EBCONFIG_H_INCLUDED

#include "FramepaC.h"

#ifndef __EBGENRE_H_INCLUDED
#  include "ebgenre.h"
#endif

#ifdef FrSTRICT_CPLUSPLUS
# include <cstdio>
#else
# include <stdio.h>
#endif /* FrSTRICT_CPLUSPLUS */

#if defined(__GNUC__)
#  pragma interface
#endif

//-----------------------------------------------------------------------

class EBMTConfig : public FrConfiguration
   {
   public:
      EbGenreSettings genre ;
      double ex_weight_start ;
      double ex_weight_end ;
      char *char_enc ;
      char *target_roots ;
      char *dictionary_file ;
      char *indexing_dictionary ;
      char *reverse_dictionary ;
      char *source_regex ;
      char *target_regex ;
      char *constraints_filename ;
      char *cognates_filename ;
      char *ne_spec ;
      long int options ;
      long int index_options ;
      long int output_options ;
      long int socketnum ;
      long int phrase_cache_size ;
      long int maxthreads ;
      FrList *corpus_directory ;
      FrList *number_charmap ;
      FrList *source_charmap ;
      FrList *tight_bound_left ;
      FrList *tight_bound_right ;
      FrList *source_suffixes ;
      FrList *dict_sstoplist ;
      FrList *dict_tstoplist ;
      FrList *word_delim ;
      int	last_local_var ;	// must be last in list
   private:
      static FrConfigurationTable EBMT_def[] ;
   public: // methods
      EBMTConfig(const char *base_dir) : FrConfiguration(base_dir) {}
      virtual ~EBMTConfig() ;
      virtual void init() ;
      virtual void resetState() ;
      virtual size_t lastLocalVar() const ;
      virtual bool onRead(FrConfigVariableType, void *where) ;
      virtual bool onChange(FrConfigVariableType, void *where) ;
      virtual ostream &dump(ostream &out) const ;
   } ;

//-----------------------------------------------------------------------

#define EB_VERBOSE		 0x0001	 // run verbosely
#define EB_QUIET		 0x0002  // run quietly
#define EB_IGNORE_CASE		 0x0004	 // ignore case in source sentence
#define EB_COMBINE	         0x0008	 // merge partially-overlapping chunks
#define EB_TOUCHMEM		 0x0010  // touch all memory at startup
#define EB_BRUTE_ALIGN		 0x0020  // allow brute-force alignments
#define EB_MMAP			 0x0040  // use memory-mapped files
#define EB_GLOBAL_MAXALTS	 0x0080
#define EB_MATCH_ACCENTS	 0x0100  // match accented/unac in indexing
#define EB_IGNORE_ACCENTS	 0x0200  // match accented/unac in retrieval
#define EB_UPPERCASE_MORPH	 0x0400
#define EB_GLOBAL_MORPH		 0x0800  // always put morph tag in catchall
#define EB_GAPPED_MATCHES	 0x1000  // allow gaps in matches
#define EB_CONTEXT_SAMPLE	 0x2000  // use context to bias sampling?
#define EB_KEEP_UNMORPHED	 0x4000
#define EB_KEEP_UNIGRAMS	 0x8000
#define EB_PHRASE_BOUNDS	0x10000 // matches must respect PHRASE tags
#define EB_SPAN_MULTIPLY	0x20000 // comb. span score as product not avg
#define EB_SPAN_GEOMEAN		0x40000 // comb. span score as geometric mean
#define EB_DISC_AMBIG_ALIGN	0x80000 //
#define EB_WEIGHTED_LINKS      0x100000	// use weighted alignment links
#define EB_LINK_PROBS	       0x200000 // use link probabilities in score
#define EB_USE_SPA	       0x400000 // use SPA instead of heuristics
#define EB_RESCOREPHRASES      0x800000 // override scores for PHRASE tags

#define EB_READONLYDICT	       0x1000000
#define EB_READONLYCORPUS      0x2000000
#define EB_MAPCORPUS	       0x4000000 // memory-mapped corpus files
#define EB_USE_MORPH	       0x8000000 // use morphology information // ABP

#define EB_SHOWCOVERAGE		 0x0001
#define EB_TRACEMATCHES		 0x0002
#define EB_UNDERSCORE_HACK	 0x0004  // convert embedded underscore to " "
#define EB_OMITSUBSUMED		 0x0010
#define EB_SHOWALIGNSCORES	 0x0020  // indiv align scores -> user scores
#define EB_BACKSUBSTITUTE	 0x0040  // apply backsubs to generalized match
#define EB_ALTRANK		 0x0080  // use alternate ranking for top-N
#define EB_SHOWGENSEQ		 0x0100  // include generalization seq. in arc

#define EB_INDEXORIG		 0x0002  // index untokenized sentences
#define EB_FULLRECURSION	 0x0004  // allow single token to rec. match
#define EB_STRIP_PUNCT		 0x0008  // strip punctuation on indexing
#define EB_COMPRESS_INDEX	 0x0020
#define EB_COGNATE_ALIGN	 0x0040	 // allow use of cognates in alignment
#define EB_DBLCOUNT_PHRASES      0x0080  // count indiv.words in a phrase
#define EB_DICT_KEEP_CASE	 0x0100  // preserve case in dictionary

//-----------------------------------------------------------------------

EBMTConfig *get_EBMT_setup_file(const char *filespec, const char *argv0,
				ostream &err) ;
EBMTConfig *get_EBMT_config() ;
void unload_EBMT_config() ;

#endif /* !__EBCONFIG_H_INCLUDED */

// end of file ebconfig.h //
