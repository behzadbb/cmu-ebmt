/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.91							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebsent.cpp		EbSentence class			*/
/*  LastEdit: 04feb10							*/
/*									*/
/*  (c) Copyright 2001,2004,2006,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "ebindex.h"
#include "ebsent.h"
#include "ebglobal.h"

/************************************************************************/
/*	Global Variables						*/
/************************************************************************/

FrAllocator EbSentence::allocator("EbSentence",sizeof(EbSentence)) ;

/************************************************************************/
/************************************************************************/

static size_t compute_encoded_length(size_t numwords, EbWordID_t *wordIDs,
				     size_t minsize, size_t maxsize)
{
   if (minsize > maxsize)
      minsize = maxsize ;
   size_t controlbits = maxsize - minsize ; // correct only for 0-2!
   size_t totalsize = sizeof(uint16_t) ;
   if (controlbits == 1)
      totalsize += (numwords + 7) / 8 ;
   else if (controlbits == 2)
      totalsize += (numwords + 3) / 4 ;
   for (size_t i = 0 ; i < numwords ; i++)
      {
      EbWordID_t ID = wordIDs[i] ;
      size_t sz = maxsize ;
      if (minsize == 1 && ID <= 0xFF)
	 sz = 1 ;
      else if (minsize <= 2 && ID <= 0x0000FFFF)
	 sz = 2 ;
      else if (minsize <= 3 && ID <= 0x00FFFFFF)
	 sz = 3 ;
      totalsize += sz ;
      }
   return totalsize ;
}

//----------------------------------------------------------------------

static size_t encode_fixed(size_t numwords, EbWordID_t *wordIDs,
			   size_t wordsize, char *packed)
{
   FrStoreShort((numwords & 0x0FFF) + ((wordsize-1) << 12),packed) ;
   char *data = packed + sizeof(uint16_t) ;
   for (size_t i = 0 ; i < numwords ; i++)
      {
      EbWordID_t ID = wordIDs[i] ;
      if (wordsize == 1)
	 *data = (char)ID ;
      else if (wordsize == 2)
	 {
	 FrStoreShort(ID,data) ;
	 }
      else // if (wordsize == 3)
	 {
	 FrStoreThreebyte(ID,data) ;
	 }
      data += wordsize ;
      }
   return numwords + sizeof(uint16_t) ;
}

//----------------------------------------------------------------------

static void encode_var_1(size_t numwords,EbWordID_t *wordIDs,
			 size_t minsize, char *&packed)
{
   FrStoreShort((numwords & 0x0FFF) + ((minsize+3)<<12),packed) ;
   char *data = packed + sizeof(uint16_t) ;
   char *control = data++ ;
   int shift = 0 ;
   *control = (char)0 ;
   for (size_t i = 0 ; i < numwords ; i++)
      {
      if (shift >= 8)
	 {
	 control = data++ ;
	 *control = (char)0 ;
	 shift = 0 ;
	 }
      EbWordID_t ID = wordIDs[i] ;
      if (minsize == 1)
	 {
	 if (ID <= 0xFF)
	    *data++ = (char)ID ;
	 else
	    {
	    FrStoreShort(ID,data) ;
	    data += 2 ;
	    *control |= (char)(1 << shift) ;
	    }
	 }
      else if (minsize == 2)
	 {
	 if (ID <= 0xFFFF)
	    {
	    FrStoreShort(ID,data) ;
	    data += 2 ;
	    }
	 else
	    {
	    FrStoreThreebyte(ID,data) ;
	    data += 3 ;
	    *control |= (char)(1 << shift) ;
	    }
	 }
      else if (minsize == 3)
	 {
	 if (ID <= 0xFFFFFF)
	    {
	    FrStoreThreebyte(ID,data) ;
	    data += 3 ;
	    }
	 else
	    {
	    FrStoreLong(ID,data) ;
	    data += 4 ;
	    *control |= (char)(1 << shift) ;
	    }
	 }
      shift++ ;
      }
   return ;
}

//----------------------------------------------------------------------

static char *encode_var_2(size_t numwords, EbWordID_t *wordIDs, size_t minsize,
			  char *packed)
{
   FrStoreShort((numwords & 0x0FFF) + ((minsize+6)<<12),packed) ;
   char *data = packed + sizeof(uint16_t) ;
   unsigned char *control = (unsigned char*)data++ ;
   *control = (unsigned char)0 ;
   int shift = 0 ;
   for (size_t i = 0 ; i < numwords ; i++)
      {
      if (shift >= 8)
	 {
	 control = (unsigned char*)data++ ;
	 *control = (unsigned char)0 ;
	 shift = 0 ;
	 }
      EbWordID_t ID = wordIDs[i] ;
      if (ID <= 0xFF)
	 {
	 *data++ = (char)ID ;
	 }
      else if (ID <= 0xFFFF)
	 {
	 FrStoreShort(ID,data) ;
	 data += 2 ;
	 *control |= (unsigned char)(1 << shift) ;
	 }
      else // if (ID <= 0xFFFFFF)
	 {
	 FrStoreThreebyte(ID,data) ;
	 data += 3 ;
	 *control |= (unsigned char)(2 << shift) ;
	 }
      shift += 2 ;
      }
   return data ;
}

//----------------------------------------------------------------------

static size_t pack_encoding(size_t numwords, EbWordID_t *wordIDs, char *&packed,
			    bool compress = true)
{
   size_t i ;
   size_t minID = ~0 ;
   size_t maxID = 0 ;
   for (i = 0 ; i < numwords ; i++)
      {
      EbWordID_t ID = wordIDs[i] ;
      if (ID > maxID)
	 maxID = ID ;
      if (ID < minID)
	 minID = ID ;
      }
   size_t minsize = (minID <= 0xFF ? 1 : (minID <= 0xFFFF ? 2 : ((minID <= 0xFFFFFFUL) ? 3 : 4))) ;
   size_t maxsize = (maxID <= 0xFF ? 1 : (maxID <= 0xFFFF ? 2 : ((maxID <= 0xFFFFFFUL) ? 3 : 4))) ;
   size_t packedlen = ~0 ;
   size_t bestmin = 0 ;
   if (compress)
      {
      for (size_t sz = minsize ; sz <= maxsize ; sz++)
	 {
	 size_t len = compute_encoded_length(numwords,wordIDs,sz,maxsize) ;
	 if (len < packedlen)
	    {
	    bestmin = sz ;
	    packedlen = len ;
	    }
	 }
      }
   else
      packedlen = sizeof(uint16_t) + numwords * maxsize ;
   packed = FrNewN(char,packedlen) ;
   minsize = bestmin ;
   if (packed)
      {
      if (minsize == maxsize || !compress)
	 encode_fixed(numwords,wordIDs,maxsize,packed) ;
      else if (maxsize - minsize == 1)
	 encode_var_1(numwords,wordIDs,minsize,packed) ;
      else // if (maxsize - minsize == 2)
	 packedlen = encode_var_2(numwords,wordIDs,minsize,packed) - packed ;
      }
   else
      {
      FrNoMemory("packing sentence encoding") ;
      packedlen = 0 ;
      }
   return packedlen ;
}

//----------------------------------------------------------------------

EbWordID_t *decode_fixed(const char *packed, size_t wordsize, size_t numwords,
			 const char **eod)
{
   EbWordID_t *decoded = FrNewN(EbWordID_t,numwords) ;
   if (!decoded)
      return 0 ;
   size_t i ;
   switch (wordsize)
      {
      case 1:
	 for (i = 0 ; i < numwords ; i++)
	    {
	    decoded[i] = *(unsigned char*)packed ;
	    packed++ ;
	    }
	 break ;
      case 2:
	 for (i = 0 ; i < numwords ; i++)
	    {
	    decoded[i] = FrLoadShort(packed) & 0xFFFF ;
	    packed += wordsize ;
	    }
	 break ;
      case 3:
	 for (i = 0 ; i < numwords ; i++)
	    {
	    decoded[i] = FrLoadThreebyte(packed) & 0xFFFFFF ;
	    packed += wordsize ;
	    }
	 break ;
      case 4:
	 for (i = 0 ; i < numwords ; i++)
	    {
	    decoded[i] = FrLoadLong(packed) ;
	    packed += wordsize ;
	    }
	 break ;
      default:
	 FrMissedCase("decode_fixed") ;
	 break ;
      }
   if (eod)
      *eod = packed ;
   return decoded ;
}

//----------------------------------------------------------------------

EbWordID_t *decode_var_1(const char *packed, size_t minsize, size_t numwords,
			 const char **eod)
{
   EbWordID_t *decoded = FrNewN(EbWordID_t,numwords) ;
   if (decoded)
      {
      size_t shift = 8 ;
      unsigned char control = 0 ;
      for (size_t i = 0 ; i < numwords ; i++)
	 {
	 if (shift >= 8)
	    {
	    control = *(unsigned char*)packed ;
	    packed++ ;
	    shift = 0 ;
	    }
	 size_t size = minsize + ((control >> shift) & 0x01) ;
	 shift++ ;
	 switch (size)
	    {
	    case 1: decoded[i] = *(unsigned char*)packed ;	      break ;
	    case 2: decoded[i] = FrLoadShort(packed) & 0xFFFF ;	      break ;
	    case 3: decoded[i] = FrLoadThreebyte(packed) & 0xFFFFFF ; break ;
	    case 4: decoded[i] = FrLoadLong(packed) ;		      break ;
	    default: FrMissedCase("decode_var_1") ;		      break ;
	    }
	 packed += size ;
	 }
      if (eod)
	 *eod = packed ;
      }
   return decoded ;
}

//----------------------------------------------------------------------

EbWordID_t *decode_var_2(const char *packed, size_t minsize, size_t numwords,
			 const char **eod)
{
   EbWordID_t *decoded = FrNewN(EbWordID_t,numwords) ;
   if (decoded)
      {
      size_t shift = 8 ;
      unsigned char control = 0 ;
      for (size_t i = 0 ; i < numwords ; i++)
	 {
	 if (shift >= 8)
	    {
	    control = *(unsigned char*)packed ;
	    packed++ ;
	    shift = 0 ;
	    }
	 size_t size = minsize + ((control >> shift) & 0x03) ;
	 shift += 2 ;
	 switch (size)
	    {
	    case 1: decoded[i] = *(unsigned char*)packed ;	      break ;
	    case 2: decoded[i] = FrLoadShort(packed) & 0xFFFF ;	      break ;
	    case 3: decoded[i] = FrLoadThreebyte(packed) & 0xFFFFFF ; break ;
	    case 4: decoded[i] = FrLoadLong(packed) ;		      break ;
	    case 5:
	    case 6:
	    case 7: FrWarning("bad compression record in corpus") ;   break ;
	    default: FrMissedCase("decode_var_2") ;		      break ;
	    }
	 packed += size ;
	 }
      if (eod)
	 *eod = packed ;
      }
   return decoded ;
}

//----------------------------------------------------------------------

size_t decode(const char *packed, EbWordID_t *&decoded, const char **eod = 0)
{
   size_t size_type = FrLoadShort(packed) ;
   packed += sizeof(uint16_t) ;
   size_t type = (size_type >> 12) & 0x0F ;
   size_t numwords = size_type & 0x0FFF ;
   size_t minsize = 3 ;
   size_t maxsize = 3 ;
   static size_t warned = 0 ;
   switch (type)
      {
      case 0:	minsize = 1 ; maxsize = 1 ;	break ;
      case 1:	minsize = 2 ; maxsize = 2 ;	break ;
      case 2:	minsize = 3 ; maxsize = 3 ;	break ;
      case 3:	minsize = 4 ; maxsize = 4 ;	break ;
      case 4:	minsize = 1 ; maxsize = 2 ;	break ;
      case 5:	minsize = 2 ; maxsize = 3 ;	break ;
      case 6:	minsize = 3 ; maxsize = 4 ;	break ;
      case 7:	minsize = 1 ; maxsize = 3 ;	break ;
      case 8:	minsize = 2 ; maxsize = 4 ;	break ;
      default:
	 if (warned++ < 5)
	    {
	    FrMissedCase("decode") ;
	    cerr << "type == " << type << endl ;
	    }
	 return 0 ;
      }
   size_t controlbits = (maxsize - minsize) ; // only correct for 0-2!
   if (controlbits == 0)
      decoded = decode_fixed(packed,minsize,numwords,eod) ;
   else if (controlbits == 1)
      decoded = decode_var_1(packed,minsize,numwords,eod) ;
   else
      decoded = decode_var_2(packed,minsize,numwords,eod) ;
   return numwords ;
}

/************************************************************************/
/*	Methods for class EbSentence					*/
/************************************************************************/

EbSentence::EbSentence(const EbSentence &orig, size_t start, size_t end)
{
   if (start >= orig.length())
      start = orig.length() - 1 ;
   if (end < start)
      end = start ;
   numwords = end - start + 1 ;
   wordIDs = FrNewN(EbWordID_t,numwords) ;
   vocabulary = orig.vocabulary ;
   if (wordIDs)
      memcpy(wordIDs,&orig.wordIDs[start],numwords*sizeof(wordIDs[0])) ;
   else
      numwords = 0 ;
   return ;
}

//----------------------------------------------------------------------

EbSentence::EbSentence(const FrVocabulary *vocab, const FrList *words)
{
   vocabulary = vocab ;
   numwords = words->listlength() ;
   wordIDs = FrNewN(EbWordID_t,numwords) ;
   if (wordIDs)
      {
      for (size_t i = 0 ; words ; i++, words = words->rest())
	 {
	 const char *word = FrPrintableName(words->first()) ;
	 wordIDs[i] = vocabulary->findID(word) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

EbSentence::EbSentence(FrVocabulary *vocab, const FrList *words,
		       bool update_vocab, bool /*targetlang*/)
{
   vocabulary = vocab ;
   numwords = words->listlength() ;
   wordIDs = FrNewN(EbWordID_t,numwords) ;
   if (wordIDs)
      {
      for (size_t i = 0 ; words ; i++, words = words->rest())
	 {
	 const char *word = FrPrintableName(words->first()) ;
	 wordIDs[i] = vocab->findID(word,update_vocab) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

EbSentence::EbSentence(FrSymHashTable *vocab, const FrList *words,
		       bool update_vocab)
{
   vocabulary = 0 ;
   numwords = words->listlength() ;
   wordIDs = FrNewN(EbWordID_t,numwords) ;
   if (wordIDs)
      {
      for (size_t i = 0 ; words ; i++, words = words->rest())
	 {
	 const char *wordstr = FrPrintableName(words->first()) ;
	 if (!wordstr)
	    continue ;
	 FrSymbol *word = FrSymbolTable::add(wordstr) ;
	 FrSymHashEntry *entry = vocab->lookup(word) ;
	 uint32_t id ;
	 if (entry)
	    id = (uint32_t)entry->getCount() ;
	 else if (update_vocab)
	    {
	    id = vocab->currentSize() ;
	    vocab->add(word,id) ;
	    }
	 else
	    id = FrVOCAB_WORD_NOT_FOUND ;
	 wordIDs[i] = id ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

EbSentence::EbSentence(const FrVocabulary *vocab, const char *packed_data,
		       const char **end_of_data)
{
   vocabulary = vocab ;
   numwords = decode(packed_data,wordIDs,end_of_data) ;
   return ;
}

//----------------------------------------------------------------------

EbSentence::~EbSentence()
{
   vocabulary = 0 ;
   FrFree(wordIDs) ;
   wordIDs = 0 ;
   numwords = 0 ;
   return ;
}

//----------------------------------------------------------------------

const char *EbSentence::word(size_t N) const
{
   if (N >= numwords || !vocabulary)
      return 0 ;
   return vocabulary->nameForID(wordIDs[N]) ;
}

//----------------------------------------------------------------------

FrList *EbSentence::wordList(size_t first, size_t last) const
{
   FrList *result ;
   FrList **end = &result ;
   if (vocabulary && length() > 0)
      {
      if (last >= length())
	 last = length() - 1 ;
      for (size_t i = first ; i <= last ; i++)
	 {
	 const char *word = vocabulary->nameForID(wordIDs[i]) ;
	 if (!word)
	    word = "<?>" ;
	 result->pushlistend(new FrConstString(word),end) ;
	 }
      }
   *end = 0 ;				// ensure proper termination of list
   return result ;
}

//----------------------------------------------------------------------

FrList *EbSentence::wordList() const
{
   return wordList(0,length()-1) ;
}

//----------------------------------------------------------------------

EbSentence *EbSentence::subseq(size_t start, size_t end) const
{
   return new EbSentence(*this,start,end) ;
}

//----------------------------------------------------------------------

size_t EbSentence::locate(const FrList *phrase) const
{
   if (!phrase)
      return 0 ;
   size_t phraselen = phrase->simplelistlength() ;
   size_t end = length() - phraselen ;
   for (size_t i = 0 ; i < end ; i++)
      {
      size_t pos = i ;
      bool match = true ;
      for (const FrList *phr = phrase ; phr ; phr = phr->rest(), pos++)
	 {
	 const char *wrd = FrPrintableName(phr->first()) ;
	 if (!wrd || Fr_stricmp(wrd,word(pos),lowercase_table) != 0)
	    {
	    match = false ;
	    break ;
	    }
	 }
      if (match)
	 return i ;
      }
   return ~0 ;
}

//----------------------------------------------------------------------

bool EbSentence::write(FILE *fp) const
{
   if (fp)
      {
      char *packed ;
      size_t length = pack_encoding(numwords,wordIDs,packed /*,
				    use_compressed_index*/) ;
      if (packed)
	 {
	 bool success = Fr_fwrite(packed,length,fp) ;
	 FrFree(packed) ;
	 return success ;
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

char *EbSentence::print() const
{
   size_t printlen = numwords ;		// spaces betw words & terminating NUL
   size_t i ;
   for (i = 0 ; i < numwords ; i++)
      {
      const char *wrd = word(i) ;
      if (wrd)
	 printlen += strlen(wrd) ;
      }
   char *buffer = FrNewN(char,printlen) ;
   char *currpos = buffer ;
   for (i = 0 ; i < numwords ; i++)
      {
      if (i > 0)
	 *currpos++ = ' ' ;
      const char *wrd = word(i) ;
      if (wrd)
	 {
	 strcpy(currpos,wrd) ;
	 currpos += strlen(wrd) ;
	 }
      }
   *currpos = '\0' ;
   return buffer ;
}

// end of file ebsent.cpp //
