/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.94							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebcontxt.C		context-dependent weightings		*/
/*  LastEdit: 25mar10							*/
/*									*/
/*  (c) Copyright 2005,2006,2007,2009,2010 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#if defined(__GNUC__)
#  pragma implementation "ebcorpus.h"
#endif

#include "ebcorpus.h"

/************************************************************************/
/*	Manifest Constants						*/
/************************************************************************/

/************************************************************************/
/*	Methods for class EbRefCounts					*/
/************************************************************************/

EbRefCounts::EbRefCounts(size_t num_examples)
{ 
   m_counts = FrNewC(unsigned char,num_examples) ;
   m_examples = m_counts ? num_examples : 0 ;
   return ;
}

//----------------------------------------------------------------------

EbRefCounts::~EbRefCounts()
{ 
   FrFree(m_counts) ; m_counts = 0 ; 
   m_examples = 0 ; 
   return ;
}

//----------------------------------------------------------------------

void EbRefCounts::clearCounts()
{
   if (m_counts)
      {
#if DEBUG
      size_t hist[256] ;
      size_t i ;
      for (i = 0 ; i < 256 ; i++)
	 hist[i] = 0 ;
      bool nonzero = false ;
      for (i = 0 ; i < numExamples() ; i++)
	 {
	 if (m_counts[i]) nonzero = true ;
	 hist[m_counts[i]]++ ;
	 }
      if (nonzero)
	 for (i = 0 ; i < 256 ; i++)
	    if (hist[i])
	       cout << "hist[" << i << "] = " << hist[i] << endl ;
#endif
      memset(m_counts,'\0',numExamples()) ;
      }
   return ;
}

// end of file ebcontxt.cpp //
