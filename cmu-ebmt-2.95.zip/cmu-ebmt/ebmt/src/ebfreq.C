/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebfreq.cpp	match-frequency statistics			*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 2007,2009 Ralf Brown					*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "ebchunks.h"
#include "ebcmatch.h"
#include "ebfreq.h"

/************************************************************************/
/************************************************************************/

inline size_t min(size_t x, size_t y) { return (x <= y) ? x : y ; }

/************************************************************************/
/*	Member functions for class EbMatchFrequency			*/
/************************************************************************/

EbMatchFrequency::EbMatchFrequency(const EBMTCandidate *cands,
				   size_t inputlen,
				   size_t desired, size_t desired_uni)
{
   m_inputlen = inputlen ;
   m_desired = desired ;
   m_desired1 = desired_uni ;
   m_counts = FrNewC(uint16_t,m_inputlen * m_inputlen) ;
   if (m_counts)
      {
      for ( ; cands ; cands = cands->next())
	 {
	 size_t first = cands->inputStart() ;
	 size_t last = first + cands->matchLength() - 1 ;
	 if (first < m_inputlen && last < m_inputlen)
	    m_counts[first * m_inputlen + last] += cands->frequency() ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

EbMatchFrequency::EbMatchFrequency(const EbCorpusMatches *matches,
				   size_t inputlen,
				   size_t desired, size_t desired_uni)
{
   (void)matches ;	//FIXME: need to implement usage tracking
   m_inputlen = inputlen ;
   m_desired = desired ;
   m_desired1 = desired_uni ;
   m_counts = FrNewC(uint16_t,m_inputlen * m_inputlen) ;
   return ;
}

//----------------------------------------------------------------------

EbMatchFrequency::~EbMatchFrequency()
{
   FrFree(m_counts) ;	m_counts = 0 ;
   m_inputlen = 0 ;
   return ;
}

//----------------------------------------------------------------------

void EbMatchFrequency::updateFrequency(const EbCorpusMatches *matches)
{
   if (matches)
      {
      size_t first = matches->startPosition() ;
      size_t last = matches->endPosition() ;
      if (m_counts && first < m_inputlen && last < m_inputlen)
	 {
	 size_t newcount = min(m_counts[first * m_inputlen + last]
			       + matches->totalMatches(),UINT16_MAX) ;
	 m_counts[first * m_inputlen + last] = newcount ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void EbMatchFrequency::updateFrequencies(const EbCorpusMatches *matches,
					 const EbCorpusMatches *prev_matches)
{
   for ( ; matches && matches != prev_matches ; matches = matches->next())
      updateFrequency(matches) ;
   return ;
}

//----------------------------------------------------------------------

size_t EbMatchFrequency::frequency(const EbCorpusMatches *matches) const
{
   size_t first = matches->startPosition() ;
   size_t last = matches->endPosition() ;
   if (m_counts && first < m_inputlen && last < m_inputlen)
      return m_counts[first * m_inputlen + last] ;
   return 0 ;
}

//----------------------------------------------------------------------

bool EbMatchFrequency::wantMore(const EbCorpusMatches *matches) const
{
   if (matches && matches->matchLength() == 1)
      return (frequency(matches) < desiredUnigramMatches()) ;
   else
      return (frequency(matches) < desiredMatches()) ;
}

// end of file ebfreq.cpp //
