/************************************************************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebbitext.cpp	bi-text maps					*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#if defined(__GNUC__)
#  pragma implementation "ebbitext.h"
#endif

#include "FramepaC.h"
#include "dict.h"
#include "ebalign.h"
#include "ebbitext.h"
#include "ebcrpinf.h"
#include "ebdict.h"
#include "ebutil.h"
#include "ebglobal.h"

#ifdef FrSTRICT_CPLUSPLUS
#  include <cmath>
#else
#  include <math.h>
#endif

//#define DEBUG_CORRESP
//#define DEBUG_CORRESP2
//#define DEBUG_OUTLIERS
//#define DEBUG_FILL
//#define DEBUG_TIEBREAKER
//#define DEBUG_PRUNEFREQ

#define KEEP_ONLY_SELF_XLAT

/************************************************************************/
/*    Manifest constant for this module					*/
/************************************************************************/

#define DEFAULT_CORR_SCORE	'\xFF'	// maximum
#define CORR_SCALE		1000000

#define NO_CORR ((size_t)~0)

#define RLE2_CONTINUED  0xF0 /*240*/
#define RLE2_MAXRUN 	(RLE2_CONTINUED-1)
#define RLE2_SETVALUE   0xF1 /*241*/
#define RLE2_ENDMARKER  0xFF /*255*/

/************************************************************************/
/************************************************************************/

#ifdef DEBUG_OUTLIERS
#  define DO_DEBUG_OUTLIERS(x) x
#else
#  define DO_DEBUG_OUTLIERS(x)
#endif

#ifdef DEBUG_CORRESP
#  define DO_DEBUG_CORRESP(x) x
#else
#  define DO_DEBUG_CORRESP(x)
#endif

/************************************************************************/
/*    Global data for classes						*/
/************************************************************************/

FrAllocator BiTextMap::allocator("BiTextMap",sizeof(BiTextMap)) ;

//bool BiTextMap::fill_gaps = true ;
bool BiTextMap::fill_gaps = false ;

static double alignlink_scores[256] ;
static double alignlink_scores_log[256] ;

/************************************************************************/
/*	 Utility functions						*/
/************************************************************************/

inline size_t minimum(size_t a, size_t b) { return a < b ? a : b ; }
inline size_t maximum(size_t a, size_t b) { return a > b ? a : b ; }

//----------------------------------------------------------------------

#if defined(DEBUG_CORRESP) || defined(DEBUG_OUTLIERS)
static void DEBUG_dump_list(const FrList *list, bool newline)
{
   char *buf = list->print() ;
   fputs(buf,stderr) ;
   FrFree(buf) ;
   if (newline)
      fputc('\n',stderr) ;
   return ;
}
#else
#define DEBUG_dump_list(list,newline)
#endif /* DEBUG_CORRESP || DEBUG_OUTLIERS */

//----------------------------------------------------------------------

bool unaccented_match(const FrObject *o1, const FrObject *o2)
{
   FrSymbol *word1 = (FrSymbol*)o1 ;
   FrSymbol *word2 = (FrSymbol*)o2 ;
   if (!word1 || !word2)
      return false ;
   const char *s1 = word1->symbolName() ;
   const char *s2 = word2->symbolName() ;
   if (char_encoding == FrChEnc_Latin2)
      {
      while (*s1 && *s2)
	 {
	 if (Fr_unaccent_Latin2(*s1) != Fr_unaccent_Latin2(*s2))
	    return false ;
	 s1++ ;
	 s2++ ;
	 }
      }
   else
      {
      while (*s1 && *s2)
	 {
	 if (Fr_unaccent_Latin1(*s1) != Fr_unaccent_Latin1(*s2))
	    return false ;
	 s1++ ;
	 s2++ ;
	 }
      }
   return true ;
}

//----------------------------------------------------------------------

void EbInitAlignlinkScores()
{
   static bool initialized = false ;

   if (!initialized)
      {
      alignlink_scores_log[0] = ::log(0.25 / (0xFF * 0xFF)) ;
      for (size_t i = 0 ; i < lengthof(alignlink_scores) ; i++)
	 {
	 double scaled = i / (double)0xFF ;
	 alignlink_scores[i] = scaled * scaled ;
	 if (i)
	    alignlink_scores_log[i] = ::log(scaled * scaled) ;
	 }
      initialized = true ;
      }
   return ;
}

//----------------------------------------------------------------------

unsigned char EbMakeAlignlinkScore(double score)
{
   if (score <= 0.0)
      return (unsigned char)0 ;
   else if (score >= 1.0)
      return (unsigned char)0xFF ;
   // increase the number of significant bits retained in lower values by
   //   taking the square root of the score; this yields ~5 bits for 0.01
   //   instead of ~1.5
   double scaled = ::sqrt(score) ;
   unsigned char val = (unsigned char)(0xFF * scaled) ;
   return val ? val : 1 ;
}

//----------------------------------------------------------------------

double EbEvalAlignlinkScore(unsigned char stored)
{
   return alignlink_scores[stored] ;
}

//----------------------------------------------------------------------

double EbEvalAlignlinkScoreLog(unsigned char stored)
{
   return alignlink_scores_log[stored] ;
}

/************************************************************************/
/*    Methods for class BiTextMap					*/
/************************************************************************/

BiTextMap::BiTextMap(const BiTextMap *oldmap)
{
   EbInitAlignlinkScores() ;
   source_length = oldmap->sourceLength() ;
   target_length = oldmap->targetLength() ;
   size_t tablesize = (sourceLength()+1) * (targetLength()+1) ;
   word_order_similarity = oldmap->word_order_similarity ;
   correspondences = FrNewN(unsigned char,tablesize) ;
   complete_map = oldmap->complete_map ;
   if (correspondences)
      {
      memcpy(correspondences,oldmap->correspondences,tablesize) ;
      source_counts = &correspondences[sourceLength()*targetLength()] ;
      target_counts = &source_counts[sourceLength()] ;
      source_words = (oldmap->source_words
		      ? (FrList*)oldmap->source_words->deepcopy()
		      : 0) ;
      target_words = (oldmap->target_words
		      ? (FrList*)oldmap->target_words->deepcopy()
		      : 0) ;
      }
   else
      {
      source_counts = 0 ;
      target_counts = 0 ;
      source_words = 0 ;
      target_words = 0 ;
      FrNoMemory("copying bitext map") ;
      }
   return ;
}

//----------------------------------------------------------------------

BiTextMap::BiTextMap(const BiTextMap *oldmap, size_t srcstart, size_t srcend,
		     size_t trgstart, size_t trgend)
{
   EbInitAlignlinkScores() ;
   source_length = (srcend - srcstart) + 1 ;
   target_length = (trgend - trgstart) + 1 ;
   if (trgend < trgstart)
      target_length = 0 ;
   size_t tablesize = (sourceLength()+1) * (targetLength()+1) ;
   word_order_similarity = oldmap->word_order_similarity ;
   correspondences = FrNewC(unsigned char,tablesize) ;
   complete_map = oldmap->complete_map ;
   source_words = 0 ;
   target_words = 0 ;
   if (correspondences)
      {
      size_t i ;
      source_counts = &correspondences[sourceLength()*targetLength()] ;
      target_counts = &source_counts[sourceLength()] ;
      for (i = 0 ; i < sourceLength() ; i++)
	 {
	 size_t count = 0 ;
	 for (size_t j = 0 ; j < targetLength() ; j++)
	    {
	    char corr = (char)oldmap->wordsCorrespond(srcstart+i,trgstart+j) ;
	    setCorrespondenceRawScore(i,j,corr) ;
	    if (corr)
	       {
	       count++ ;
	       target_counts[j]++ ;
	       }
	    }
	 source_counts[i] = (unsigned char)count ;
	 }
      if (oldmap->source_words)
	 source_words = (FrList*)oldmap->source_words->subseq(srcstart,srcend);
      if (oldmap->target_words)
	 target_words = (FrList*)oldmap->target_words->subseq(trgstart,trgend);
      }
   else
      {
      source_counts = 0 ;
      target_counts = 0 ;
      FrNoMemory("copying bitext map") ;
      }
   return ;
}

//----------------------------------------------------------------------

BiTextMap::BiTextMap(size_t srclen, size_t trglen, const double *probabilities,
		     FrList *source, FrList *target, double link_cutoff,
		     int similarity, const EbAlignConstraints *constraints)
{
   EbInitAlignlinkScores() ;
   source_length = srclen ;
   target_length = trglen ;
   correspondences = 0 ;
   source_counts = 0 ;
   target_counts = 0 ;
   source_words = source ;
   target_words = target ;
   complete_map = false ;
   if (similarity >= 0)
      word_order_similarity = similarity ;
   else
      word_order_similarity = EBMT_word_order_similarity ;
   if (probabilities)
      {
      correspondences = FrNewC(unsigned char,(srclen+1)*(trglen+1)) ;
      if (correspondences)
	 {
	 source_counts = &correspondences[srclen*trglen] ;
	 target_counts = &source_counts[srclen] ;
	 // first pass: convert probabilities
	 for (size_t i = 0 ; i < srclen ; i++)
	    {
	    int curr_row = i * trglen ;
	    for (size_t j = 0 ; j < trglen ; j++)
	       {
	       double prob = probabilities[curr_row + j] ;
	       if (prob > 0.0)
		  {
		  correspondences[curr_row + j] = EbMakeAlignlinkScore(prob) ;
		  source_counts[i]++ ;
		  target_counts[j]++ ;
		  }
	       }
	    }
	 size_t removed ;
	 do {
	    // second pass: apply standard outlier filtering
 	    removed = removeOutliers(constraints) ;
	    // third pass: disambiguate based on relative probabilities
	    //    ("Competitive Disambiguation")
	    if (link_cutoff > 0.0 && link_cutoff < 1.0)
	       {
	       FrLocalAllocC(double,maxprob_row,1000,srclen+trglen) ;
	       if (maxprob_row)
		  {
		  double *maxprob_col = maxprob_row + srclen ;
		  for (size_t i = 0 ; i < srclen ; i++)
		     {
		     int curr_row = i * trglen ;
		     for (size_t j = 0 ; j < trglen ; j++)
			{
			double prob = probabilities[curr_row + j] ;
			if (prob > maxprob_col[j])
			   maxprob_col[j] = prob ;
			if (prob > maxprob_row[i])
			   maxprob_row[i] = prob ;
			}
		     }
		  //  start disambiguating by removing links where the words on
		  //   both ends each have another link that is substantially
		  //   stronger
		  for (size_t i = 0 ; i < srclen ; i++)
		     {
		     int curr_row = i * trglen ;
		     double threshold = link_cutoff * maxprob_row[i] ;
		     for (size_t j = 0 ; j < trglen ; j++)
			{
			double prob = probabilities[curr_row + j] ;
			if (prob > 0.0 && correspondences[curr_row + j] &&
			    prob <= threshold &&
			    prob <= link_cutoff * maxprob_col[j])
			   {
			   // wipe out the link from i to j
			   correspondences[curr_row + j] = (char)0 ;
			   source_counts[i]-- ;
			   target_counts[j]-- ;
			   removed++ ;
			   }
			}
		     }
		  }
	       FrLocalFree(maxprob_row) ;
	       }
	    } while (removed) ;
	 // fourth pass: standard gap filling
	 fillGaps(constraints) ;
	 // final processing
	 recountCorrespondences() ;
	 }
      DO_DEBUG_CORRESP(dump(stderr) ;)
      }
   return ;
}

//----------------------------------------------------------------------

BiTextMap::BiTextMap(const FrList *source, const FrList *target,
		     const FrList *alignment, int origin,
		     double def_score, const EbAlignConstraints *constr,
		     bool reverse_alignment)
{
   EbInitAlignlinkScores() ;
   DEBUG_dump_list(source,true) ;
   source_length = source->simplelistlength() ;
   target_length = target->simplelistlength() ;
   correspondences = FrNewC(unsigned char,
			    (sourceLength()+1)*(targetLength()+1)) ;
   source_counts = &correspondences[sourceLength()*targetLength()] ;
   target_counts = &source_counts[sourceLength()] ;
   source_words = FrCvtWordlist2Symbollist(source,char_encoding) ;
   target_words = FrCvtWordlist2Symbollist(target,char_encoding) ;
   complete_map = false ;
   if (correspondences)
      {
      size_t align_len = alignment->listlength() ;
      size_t i ;
      const FrList *align = alignment ;
      size_t slen = reverse_alignment ? targetLength() : sourceLength() ;
      FrSymbol *comma = makeSymbol(",") ;
      bool have_comma = false ;
      if (align->first() && align->first()->consp() &&
	  ((FrList*)align->first())->member(comma))
	 have_comma = true ;
      size_t maxlen ;
      if (!have_comma)
	 {
	 if (align_len < slen)
	    {
	    FrWarning("alignment info shorter than source sentence") ;
	    slen = align_len ;
	    }
	 else if (align_len > slen)
	    FrWarning("alignment info longer than source sentence") ;
	 maxlen = slen ;
	 }
      else
	 maxlen = align_len ;
      for (i = 0 ; i < maxlen && align ; i++, align = align->rest())
	 {
	 FrList *a = (FrList*)align->first() ;
	 if (a && a->consp() && a->member(comma))
	    setMultiCorrespondence(a,1,def_score,constr,false,
				   reverse_alignment) ;
	 else if (i < slen && a && (FrSymbol*)a != comma)
	    setCorrespondence(i,a,origin,def_score,constr,false,
			      reverse_alignment) ;
	 }
      // second pass, set only those items that are explicitly listed as
      //   having no correspondence
      if (!have_comma)
	 {
	 align = alignment ;
	 for (i = 0 ; i < maxlen ; i++, align = align->rest())
	    {
	    FrObject *a = align->first() ;
	    if (a && a != comma)
	       setCorrespondence(i,a,origin,def_score,constr,true,
				 reverse_alignment) ;
	    }
	 }
      DO_DEBUG_CORRESP(dump(stderr) ;)
      }
   else
      FrNoMemory("building bitext map") ;
   return ;
}

//----------------------------------------------------------------------

BiTextMap::BiTextMap(const char *RLEdata, int source_len, int target_len,
		     const char **RLEend, int similarity)
{
   EbInitAlignlinkScores() ;
   if (similarity >= 0)
      word_order_similarity = similarity ;
   else
      word_order_similarity = EBMT_word_order_similarity ;
   source_length = source_len ;
   target_length = target_len ;
   source_words = 0 ;
   target_words = 0 ;
   correspondences = FrNewC(unsigned char,
			    (sourceLength()+1)*(targetLength()+1));
   source_counts = &correspondences[sourceLength()*targetLength()] ;
   target_counts = &source_counts[sourceLength()] ;
   complete_map = false ;
   const char *tmp_end = (char*)~0 ;
   if (!RLEend)
      RLEend = &tmp_end ;
   if (correspondences)
      {
      int n = *RLEdata++ ;
      unsigned char *corr = correspondences ;
      const unsigned char *RLE = (unsigned char*)RLEdata ;
      if (n == EbCORPUS_EXTRA_BITEXT_FLOAT1 ||
	  n == EbCORPUS_EXTRA_BITEXT_FLOAT2)
	 {
	 for (size_t i = 0 ; i < sourceLength() && (char*)RLE < *RLEend ; i++)
	    {
	    size_t entries = *RLE++ ;
	    for (size_t j = 0 ; j < entries ; j++)
	       {
	       size_t tword ;
	       if (n == EbCORPUS_EXTRA_BITEXT_FLOAT2)
		  {
		  tword = FrLoadShort(RLE) ;
		  RLE += 2 ;
		  }
	       else
		  tword = *RLE++ ;
	       unsigned char raw_sc = *RLE++ ;
	       if (tword < targetLength())
		  setCorrespondenceRawScore(i,tword,raw_sc) ;
	       }
	    }
	 }
      else if (n == EbCORPUS_EXTRA_BITEXT_RLE2) // compressed with RLE2 ?
	 {
	 unsigned char cellvalue = (unsigned char)1 ;
	 while ((n = *RLE++) != RLE2_ENDMARKER)
	    {
	    if (n <= RLE2_MAXRUN)
	       {
	       corr += n ;		// skip indicated number of zero bytes
	       if (corr >= source_counts)
	          {			// sanity check
		  FrWarning("compressed bitext data is corrupt!") ;
		  break ;
		  }
	       unsigned char cv = (cellvalue > 0 ? DEFAULT_CORR_SCORE : 0) ;
	       *corr = cv ;
	       if (cellvalue > 1)
		  {
		  unsigned char *tmp_corr = corr + 1 ;
		  for (unsigned char j = cellvalue / 2 ; j > 0 ; j >>= 1)
		     *tmp_corr++ = (j & 1) != 0 ? cv : 0 ;
		  }
	       cellvalue = (unsigned char)1 ;
	       corr++ ;
	       }
	    else if (n == RLE2_CONTINUED)
	       corr += n ;
	    else
	       {
	       cellvalue = (char)(n - RLE2_SETVALUE + 1) ;
	       if (cellvalue == 1)
		  cellvalue = *RLE++ ;
	       }
	    }
	 }
      else if (n == EbCORPUS_EXTRA_BITEXT_UNCOMP)  // uncompressed data?
	 {
	 while (corr < source_counts)
	    *corr++ = (*RLE++ ? DEFAULT_CORR_SCORE : 0) ;
	 if (*RLE != RLE2_ENDMARKER)
	    {
	    FrWarning("uncompressed bitext data is corrupt!") ;
	    }
	 }
      else
	 {
	 FrWarning("incorrect type of compressed data for bitext map") ;
	 *RLEend = RLEdata ;
	 // just leave the correspondence array blank
	 return ;
	 }
      RLEdata = (const char*)RLE ;
      // rebuild the source_counts and target_counts arrays from corr. array
      corr = correspondences ;
      for (size_t i = 0 ; i < sourceLength() ; i++)
	 {
	 int sc = 0 ;
	 for (size_t j = 0 ; j < targetLength() ; j++)
	    {
	    if (*corr++)
	       {
	       sc++ ;
	       target_counts[j]++ ;
	       }
	    }
	 source_counts[i] = (char)sc ;
	 }
      }
   else
      FrNoMemory("while decompressing bitext map") ;
   DO_DEBUG_CORRESP(dump(stderr) ;)
   *RLEend = RLEdata ;
   return ;
}

//----------------------------------------------------------------------

size_t BiTextMap::firstCorrespondence(size_t wordnum) const
{
   if (wordnum >= sourceLength())
      return 0 ;
   const unsigned char *corr = sourceCorrespondences(wordnum) ;
   for (size_t i = 0 ; i < targetLength() ; i++)
      if (corr[i])
	 return i ;
   return 0 ;
}

//----------------------------------------------------------------------

size_t BiTextMap::lastCorrespondence(size_t wordnum) const
{
   if (wordnum < sourceLength())
      {
      const unsigned char *corr = sourceCorrespondences(wordnum) ;
      for (size_t i = target_length ; i > 0 ; i--)
	 {
	 if (corr[i-1])
	    return i-1 ;
	 }
      }
   return targetLength() ;
}

//----------------------------------------------------------------------

size_t BiTextMap::firstSourceCorrespondence(size_t wordnum) const
{
   if (wordnum >= targetLength())
      return NO_CORR ;
   const unsigned char *corr = &correspondences[wordnum] ;
   for (size_t i = 0 ; i < sourceLength() ; i++)
      {
      if (*corr)
	 return i ;
      corr += targetLength() ;
      }
   return NO_CORR ;
}

//----------------------------------------------------------------------

size_t BiTextMap::firstSourceCorrespondence(size_t wordnum, size_t start) const
{
   if (wordnum >= targetLength())
      return NO_CORR ;
   const unsigned char *corr
	 = &correspondences[start * targetLength() + wordnum] ;
   for (size_t i = start ; i < sourceLength() ; i++)
      {
      if (*corr)
	 return i ;
      corr += targetLength() ;
      }
   return NO_CORR ;
}

//----------------------------------------------------------------------

size_t BiTextMap::lastSourceCorrespondence(size_t wordnum) const
{
   if (wordnum < targetLength())
      {
      const unsigned char *corr ;
      corr = &correspondences[sourceLength()*targetLength()+wordnum] ;
      for (size_t i = sourceLength() ; i > 0 ; i--)
	 {
	 corr -= targetLength() ;
	 if (*corr)
	    return i-1 ;
	 }
      }
   return sourceLength() ;
}

//----------------------------------------------------------------------

void BiTextMap::setCorrespondenceScore(int sword, int tword,
				       double score)
{
   correspondences[sword*targetLength()+tword] = EbMakeAlignlinkScore(score) ;
}

//----------------------------------------------------------------------

double BiTextMap::correspondenceScore(int sword, int tword) const
{
   return EbEvalAlignlinkScore(correspondences[sword*targetLength()+tword]) ;
}

//----------------------------------------------------------------------

double BiTextMap::correspondenceLogScore(int sword, int tword) const
{
   unsigned char raw_sc = correspondences[sword*targetLength()+tword] ;
   return EbEvalAlignlinkScoreLog(raw_sc) ;
}

//----------------------------------------------------------------------

size_t BiTextMap::numAnchors() const
{
   size_t anchors = 0 ;
   for (size_t i = 0 ; i < sourceLength() ; i++)
      if (numTargetCorrespondences(i) == 1)
	 {
	 // unique translation for the source word, but is it the unique
	 // translation of that target word?
	 const unsigned char *corr = sourceCorrespondences(i) ;
	 for (size_t j = 0 ; j < targetLength() ; j++)
	    {
	    if (corr[j])
	       {
	       if (numSourceCorrespondences(j) == 1)
		  anchors++ ;
	       break ;
	       }
	    }
	 }
   return anchors ;
}

//----------------------------------------------------------------------

size_t BiTextMap::removeTargetOutliers(size_t row, size_t low, size_t high,
				       size_t word_shift)
{
   if (low > word_shift)
      low -= word_shift ;
   else
      low = 0 ;
   high += word_shift ;
   size_t removed = 0 ;
   if (low > 0 || high < targetLength()-1)
      {
      if (high >= targetLength())
	 high = targetLength() - 1 ;
      int inside = numTargetCorrespondences(row,low,high) ;
      if (inside != 0 && inside != numTargetCorrespondences(row))
	 {
	 // OK, we've found one or more outliers, so go remove them
	 // (unless the outlier is the only known translation for the
	 // target-language word)
	 size_t j ;
	 unsigned char *corr = (unsigned char*)sourceCorrespondences(row) ;
	 for (j = 0 ; j < low ; j++)
	    {
	    if (corr[j] && numSourceCorrespondences(j) > 1)
	       {
	       corr[j] = 0 ;
	       source_counts[row]-- ;
	       target_counts[j]-- ;
	       removed++ ;
	       }
	    }
	 for (j = high+1 ; j < targetLength() ; j++)
	    {
	    if (corr[j] && numSourceCorrespondences(j) > 1)
	       {
	       corr[j] = 0 ;
	       source_counts[row]-- ;
	       target_counts[j]-- ;
	       removed++ ;
	       }
	    }
	 }
      }
   return removed ;
}

//----------------------------------------------------------------------

size_t BiTextMap::removeSourceOutliers(size_t col, size_t low, size_t high,
				       size_t word_shift)
{
   if (low > high)			// if invalid range,
      return 0 ;			//   we have nothing to remove
   if (low > word_shift)
      low -= word_shift ;
   else
      low = 0 ;
   high += word_shift ;
   size_t removed = 0 ;
   if (low > 0 || high < sourceLength() - 1)
      {
      if (high >= sourceLength())
	 high = sourceLength() - 1 ;
      int inside = numSourceCorrespondences(col,low,high) ;
      if (inside != 0 && inside != numSourceCorrespondences(col))
	 {
	 // OK, we've found one or more outliers, so go remove them
	 // (unless the outlier is the only known translation for the
	 // source-language word)
	 size_t i ;
	 for (i = 0 ; i < low ; i++)
	    {
	    if (numTargetCorrespondences(i) > 1)
	       removed += clearCorrespondence(i,col) ;
	    }
	 for (i = high+1 ; i < sourceLength() ; i++)
	    {
	    if (numTargetCorrespondences(i) > 1)
	       removed += clearCorrespondence(i,col) ;
	    }
	 }
      }
   return removed ;
}

//----------------------------------------------------------------------

void BiTextMap::getSourceRange(size_t col, size_t &low, size_t &high,
			       size_t word_shift) const
{
   size_t l1, l2, h1, h2 ;
   if (target_counts[col-1] == 0 && col > 1)
      {
      l1 = firstSourceCorrespondence(col-2) ;
      if (l1 == NO_CORR) l1 = 0 ;
      h1 = lastSourceCorrespondence(col-2) + word_shift ;
      l1 = (l1 > word_shift) ? l1 - word_shift : 0 ;
      }
   else
      {
      l1 = firstSourceCorrespondence(col-1) ;
      if (l1 == NO_CORR) l1 = 0 ;
      h1 = lastSourceCorrespondence(col-1) ;
      }
   if (source_counts[col+1] == 0 && col < targetLength()-2)
      {
      l2 = firstSourceCorrespondence(col+2) ;
      if (l2 == NO_CORR) l2 = 0 ;
      h2 = lastSourceCorrespondence(col+2) + word_shift ;
      l2 = (l2 > word_shift) ? l2 - word_shift : 0 ;
      }
   else
      {
      l2 = firstSourceCorrespondence(col+1) ;
      if (l2 == NO_CORR) l2 = 0 ;
      h2 = lastSourceCorrespondence(col+1) ;
      }
   low = minimum(l1,l2) ;
   high = maximum(h1,h2) ;
   return ;
}

//----------------------------------------------------------------------

void BiTextMap::getTargetRange(size_t row, size_t &low, size_t &high,
			       size_t word_shift) const
{
   size_t l1, l2, h1, h2 ;
   if (source_counts[row-1] == 0 && row > 1)
      {
      l1 = firstCorrespondence(row-2) ;
      h1 = lastCorrespondence(row-2) + word_shift ;
      l1 = (l1 > word_shift) ? l1 - word_shift : 0 ;
      }
   else
      {
      l1 = firstCorrespondence(row-1) ;
      h1 = lastCorrespondence(row-1) ;
      }
   if (source_counts[row+1] == 0 && row < sourceLength() - 2)
      {
      l2 = firstCorrespondence(row+2) ;
      h2 = lastCorrespondence(row+2) + word_shift ;
      l2 = (l2 > word_shift) ? l2 - word_shift : 0 ;
      }
   else
      {
      l2 = firstCorrespondence(row+1) ;
      h2 = lastCorrespondence(row+1) ;
      }
   low = minimum(l1,l2) ;
   high = maximum(h1,h2) ;
   return ;
}

//----------------------------------------------------------------------

static size_t furthest_outlier(const BiTextMap *bitext, size_t word)
{
   size_t totalcorr = 0 ;
   if (word > 0)
      totalcorr = bitext->numTargetCorrespondences(word-1) ;
   if (word < bitext->sourceLength()-1)
      totalcorr += bitext->numTargetCorrespondences(word+1) ;
   if (totalcorr == 0)
      return (size_t)-1 ;
   size_t furthest = (size_t)-1 ;
   size_t furthestdist = 0 ;
   size_t tlen = bitext->targetLength() ;
   const unsigned char *prevcorr ;
   const unsigned char *corr = bitext->sourceCorrespondences(word) ;
   const unsigned char *nextcorr = bitext->sourceCorrespondences(word+1) ;
   prevcorr = word > 0 ? bitext->sourceCorrespondences(word-1) : 0 ;
   for (size_t i = 0 ; i < tlen ; i++)
      {
      if (corr[i])
	 {
	 size_t totaldist = 0 ;
	 size_t j ;
	 for (j = 0 ; j < i ; j++)
	    {
	    if (prevcorr && prevcorr[j])
	       totaldist += (i-j) ;
	    if (nextcorr[j])
	       totaldist += (i-j) ;
	    }
	 for (j = i+1 ; j < tlen ; j++)
	    {
	    if (prevcorr && prevcorr[j])
	       totaldist += (j-i) ;
	    if (nextcorr[j])
	       totaldist += (j-i) ;
	    }
	 if (totaldist > furthestdist)
	    {
	    furthestdist = totaldist ;
	    furthest = i ;
	    }
	 }
      }
   return furthest ;
}

//----------------------------------------------------------------------

size_t BiTextMap::clearCorrespondence(size_t src, size_t trg)
{
   unsigned char *corr = &correspondences[src * targetLength() + trg] ;
   if (*corr)
      {
      *corr = 0 ;
      source_counts[src]-- ;
      target_counts[trg]-- ;
      return 1 ;
      }
   return 0 ;
}

//----------------------------------------------------------------------

size_t BiTextMap::clearCorrespondences(size_t src,size_t trgstart,
				       size_t trgend)
{
   size_t removed = 0 ;
   for (size_t trg = trgstart ; trg < trgend ; trg++)
      {
      if (numSourceCorrespondences(trg) > 1)
	 removed += clearCorrespondence(src,trg) ;
      }
   return removed ;
}

//----------------------------------------------------------------------

static int compare_freq(const FrObject *o1, const FrObject *o2)
{
   const FrList *l1 = (FrList*)o1 ;
   const FrList *l2 = (FrList*)o2 ;
   size_t freq1 = 0 ;
   size_t freq2 = 0 ;
   if (l1->second())
      freq1 = (size_t)l1->second()->intValue() ;
   if (l2->second())
      freq2 = (size_t)l2->second()->intValue() ;
   if (freq1 > freq2)
      return -1 ;
   else if (freq1 < freq2)
      return +1 ;
   return 0 ;
}

//----------------------------------------------------------------------

size_t BiTextMap::pruneByFreq(size_t src1, size_t src2,
			      const Dictionary *dict)
{
   // look for a pair of target-language words that are listed as
   //   possible translations for both source-language words such that
   //   the dictionary has a higher frequency for one SL word translating
   //   as one of the pair and a higher frequency for the other SL word
   //   translating as the other of the pair
   size_t removed = 0 ;
   if (dict && src1 != src2)
      {
      FrSymbol *srcword1 = sourceWord(src1) ;
      FrSymbol *srcword2 = sourceWord(src2) ;
      if (srcword1 != srcword2)
	 {
	 FrList *trans1 = dict->lookup(srcword1) ;
	 FrList *trans2 = dict->lookup(srcword2) ;
	 if (trans1 && trans2)
	    {
	    size_t src1freq = 0 ;
	    size_t src2freq = 0 ;
	    if (trans1->first() && trans1->first()->numberp())
	       src1freq = (size_t)trans1->first()->intValue() ;
	    if (trans2->first() && trans2->first()->numberp())
	       src2freq = (size_t)trans2->first()->intValue() ;
	    if (src1freq && src2freq)
	       {
	       FrList *poss1 = 0 ;
	       FrList *poss2 = 0 ;
	       for (size_t i = 0 ; i < targetLength() ; i++)
		  {
		  if (wordsCorrespond(src1,i))
		     {
		     FrSymbol *trgword = targetWord(i) ;
		     FrList *trgdef = (FrList*)trans1->assoc(trgword) ;
		     if (trgdef)
			pushlist(trgdef->deepcopy(),poss1) ;
		     }
		  if (wordsCorrespond(src2,i))
		     {
		     FrSymbol *trgword = targetWord(i) ;
		     FrList *trgdef = (FrList*)trans2->assoc(trgword) ;
		     if (trgdef)
			pushlist(trgdef->deepcopy(),poss2) ;
		     }
		  }
	       poss1 = poss1->sort(compare_freq) ;
	       poss2 = poss2->sort(compare_freq) ;
	       // check whether the top-frequency translation for each
	       //   source word is other than the top-freq for the other
               FrObject *def1 = poss1? ((FrList*)poss1->first())->first() : 0;
               FrObject *def2 = poss2? ((FrList*)poss2->first())->first() : 0;
	       FrSymbol *top1 = FrCvt2Symbol(def1,char_encoding) ;
	       FrSymbol *top2 = FrCvt2Symbol(def2,char_encoding) ;
	       const FrList *match1 = (FrList*)poss2->assoc(top1) ;
	       const FrList *match2 = (FrList*)poss1->assoc(top2) ;
	       if (match1 && match2 && match1 != (FrList*)poss2->first() &&
		   match2 != (FrList*)poss1->first())
		  {
#ifdef DEBUG_PRUNEFREQ
		  dump(stderr) ;
#endif /* DEBUG_PRUNEFREQ */
		  for (size_t i = 0 ; i < targetLength() ; i++)
		     {
		     FrSymbol *tword = targetWord(i) ;
		     if (tword == top2)
			removed += clearCorrespondence(src1,i) ;
		     if (tword == top1)
			removed += clearCorrespondence(src2,i) ;
		     }
#ifdef DEBUG_PRUNEFREQ
		  fprintf(stderr,"----after dict-pruning----\n") ;
		  dump(stderr) ;
		  fprintf(stderr,"===========================\n") ;
#endif /* DEBUG_PRUNEFREQ */
		  }
	       free_object(poss1) ;
	       free_object(poss2) ;
	       }
	    }
	 free_object(trans1) ;
	 free_object(trans2) ;
	 }
      }
   return removed ;
}

//----------------------------------------------------------------------

size_t BiTextMap::removeOutliers(const EbAlignConstraints *constr)
{
   size_t word_shift = (size_t)word_order_similarity ;
   if (word_shift == (size_t)-1 || word_shift == 0 ||
       ((size_t)sourceLength() < 1+word_shift &&
	(size_t)targetLength() < 1+word_shift) ||
       sourceLength() < 3 || targetLength() < 3)
      {
      DO_DEBUG_OUTLIERS((cerr << "removeOutliers skipped" << endl)) ;
      return 0 ;			// too short to do anything
      }
   if (!constr)
      return 0 ;
   const Dictionary *dict = constr->dictionary() ;
   size_t total_removed = 0 ;
   DO_DEBUG_OUTLIERS(size_t start_anchors = numAnchors() ;)
   size_t removed ;
   do {
      removed = 0 ;
      size_t i, low, high ;
      low = firstCorrespondence(1) ;
      high = lastCorrespondence(1) ;
      removed += removeTargetOutliers(0,low,high,2*word_shift) ;
      for (i = 1 ; i < sourceLength()-1 ; i++)
	 {
	 getTargetRange(i,low,high,word_shift) ;
	 removed += removeTargetOutliers(i,low,high,word_shift) ;
	 }
      low = firstCorrespondence(sourceLength()-2) ;
      high = lastCorrespondence(sourceLength()-2) ;
      removed += removeTargetOutliers(sourceLength()-1,low,high,2*word_shift) ;
      low = firstSourceCorrespondence(1) ;
      high = lastSourceCorrespondence(1) ;
      removed += removeSourceOutliers(0,low,high,2*word_shift) ;
      for (size_t j = 1 ; j + 1 < targetLength() ; j++)
	 {
	 getSourceRange(j,low,high,word_shift) ;
	 removed += removeSourceOutliers(j,low,high,word_shift) ;
	 }
      low = firstSourceCorrespondence(targetLength()-2) ;
      high = lastSourceCorrespondence(targetLength()-2) ;
      removed += removeSourceOutliers(targetLength()-1,low,high,2*word_shift) ;
      // now see whether we can break any "ties" -- pairs of source words
      // which have exactly the same target correspondences
      const FrList *swords = source_words ;
      for (i = 0 ;
	   i < sourceLength()-1 && swords ;
	   i++, swords = swords->rest())
	 {
	 size_t tcorr = numTargetCorrespondences(i) ;
	 if (tcorr < 2)
	    continue ;			// don't bother further if no ambig.
	 FrSymbol *word1 = (FrSymbol*)swords->first() ;
	 const FrList *sw = swords->rest() ;
	 for (size_t j = i+1 ; j < sourceLength() ; j++,sw = sw->rest())
	    {
	    FrSymbol *word2 = (FrSymbol*)sw->first() ;
	    if ((word1 == word2 || tcorr > 4 || j == i+1) &&
		sameCorrespondences(i,j))
	       {
  	       // see if we can break the tie by dictionary frequencies
	       if (word1 != word2 && pruneByFreq(i,j,dict))
		  break ;
	       // break the tie by removing the correspondence for each word
	       // which is furthest from the correspondences for the adjacent
	       // words
	       size_t corr1 = furthest_outlier(this,i) ;
	       size_t corr2 = furthest_outlier(this,j) ;
	       if (corr1 != corr2)
		  {
#ifdef DEBUG_TIEBREAKER
		  cerr << "tiebreaker:  " << i<< "/" << corr1 << ","
		       << j << "/" << corr2 << endl ;
#endif /* DEBUG_TIEBREAKER */
		  if (corr1 != (size_t)-1)
		     removed += clearCorrespondence(i,corr1) ;
		  if (corr2 != (size_t)-1)
		     removed += clearCorrespondence(j,corr2) ;
		  }
	       break ;
	       }
	    }
	 }
#ifdef KEEP_ONLY_SELF_XLAT
      // finally, check whether we have a word translating as both itself
      //   and other words
      swords = source_words ;
      for (i = 0 ;
	   i < sourceLength()-1 && swords ;
	   i++, swords = swords->rest())
	 {
	 size_t tcorr = numTargetCorrespondences(i) ;
	 if (tcorr < 2)
	    continue ;			// don't bother further if no ambig.
	 FrSymbol *word1 = (FrSymbol*)swords->first() ; // original input
	 bool same = false ;
	 const FrList *tw = target_words ;
	 size_t j ;
	 for (j = 0 ; j < targetLength() && tw ; j++, tw = tw->rest())
	    {
	    if (wordsCorrespond(i,j))
	       {
	       FrSymbol *tw1 = (FrSymbol*)tw->first() ;
	       if (tw1 && word1 == tw1)
		  {
		  same = true ;
		  break ;
		  }
	       }
	    }
	 if (!same)
	    continue ;
	 tw = target_words ;
	 for (j = 0 ; j < targetLength() && tw ; j++, tw = tw->rest())
	    {
	    if (wordsCorrespond(i,j))
	       {
	       FrSymbol *tw1 = (FrSymbol*)tw->first() ;
	       if (tw1 && word1 != tw1)
		  removed += clearCorrespondence(i,j) ;
	       }
	    }
	 }
#endif /* KEEP_ONLY_SELF_XLAT */
      removed += applyAlignmentConstraints(constr) ;
      total_removed += removed ;
      } while (removed > 0) ;
   DO_DEBUG_OUTLIERS((cerr << "; removed " << total_removed
		           << " outliers; anchors went from "
		           << start_anchors << " to " << numAnchors()
		           << endl)) ;
   return total_removed ;
}

//----------------------------------------------------------------------

size_t BiTextMap::applyAlignmentConstraints(const EbAlignConstraints *constr)
{
   size_t removed = 0 ;
   if (constr->sourceLeftBindings())
      {
      const FrList *sw = source_words ;
      for (size_t i = 0 ; i < sourceLength()-1 ; i++, sw = sw->rest())
	 {
	 FrSymbol *sword = (FrSymbol*)sw->first() ;
	 if (!constr->isSourceBoundLeft(sword))
	    continue ;
	 if (numTargetCorrespondences(i) >= 1 &&
	     numTargetCorrespondences(i+1) > 1 &&
	     hasTargetCorrespondences(i+1,firstCorrespondence(i)+1,
				      targetLength()))
	    {
	    // remove correspondences for the tightly bound word's
	    //   righthand neighbor which are to the left of the
	    //  leftmost possible translation
	    removed += clearCorrespondences(i+1,0,firstCorrespondence(i)+1);
	    }
	 if (numTargetCorrespondences(i) < 2)
	    continue ;		// don't bother further if no ambig.
	 // remove any occurrences to the right of the last possibility
	 //   for the righthand neighbor
	 removed += clearCorrespondences(i,lastCorrespondence(i+1),
					 targetLength()-1) ;
	 // remove any occurrences to the left of the last occurrence
	 //   prior to the first possibility for the neighbor
	 size_t first = firstCorrespondence(i+1) ;
	 while (first > 0 && !wordsCorrespond(i,first))
	    first-- ;
	 removed += clearCorrespondences(i,0,first) ;
	 }
      }
   else if (constr->sourceLeftReversals())
      {
      const FrList *sw = source_words ;
      for (size_t i = 0 ; i < sourceLength()-1 ; i++, sw = sw->rest())
	 {
	 FrSymbol *sword = (FrSymbol*)sw->first() ;
	 if (!constr->isSourceReversedLeft(sword))
	    continue ;
	 if (numTargetCorrespondences(i) >= 1 &&
	     numTargetCorrespondences(i+1) > 1 &&
	     hasTargetCorrespondences(i+1,0,lastCorrespondence(i)-1))
	    {
	    // remove correspondences for the reverse-bound word's
	    //   righthand neighbor which are to the right of the
	    //  rightmost possible translation
	    removed += clearCorrespondences(i+1,firstCorrespondence(i)+1,
					    sourceLength()-1);
	    }
	 if (numTargetCorrespondences(i) < 2)
	    continue ;		// don't bother further if no ambig.
	 // remove any occurrences to the left of the first possibility
	 //   for the righthand neighbor
	 size_t neighbor = firstCorrespondence(i+1) ;
	 if (neighbor > 0)
	    neighbor-- ;
	 removed += clearCorrespondences(i,0,neighbor) ;
	 }
      }
   if (constr->sourceRightBindings())
      {
      const FrList *sw = source_words->rest() ;
      for (size_t i = 1 ; i < sourceLength() ; i++, sw = sw->rest())
	 {
	 FrSymbol *sword = (FrSymbol*)sw->first() ;
	 if (!constr->isSourceBoundRight(sword))
	    continue ;
	 if (numTargetCorrespondences(i) >= 1 &&
	     numTargetCorrespondences(i-1) > 1 &&
	     hasTargetCorrespondences(i-1,0,lastCorrespondence(i)-1))
	    {
	    // remove correspondences for the tightly bound word's
	    //   lefthand neighbor which are to the right of the rightmost
	    //   possible translation
	    removed += clearCorrespondences(i-1,lastCorrespondence(i),
					    targetLength()) ;
	    }
	 if (numTargetCorrespondences(i) < 2)
	    continue ;		// don't bother further if no ambig.
	 // remove any occurrences to the left of the first possibility
	 removed += clearCorrespondences(i,0,firstCorrespondence(i-1)+1) ;
	 // remove any occurrences to the right of the first occurrence
	 //   after the last possibility for the neighbor
	 size_t last = lastCorrespondence(i-1) ;
	 while (last < targetLength() && !wordsCorrespond(i,last))
	    last++ ;
	 removed += clearCorrespondences(i,last+1,targetLength()) ;
	 }
      }
   else if (constr->sourceRightReversals())
      {
      const FrList *sw = source_words->rest() ;
      for (size_t i = 1 ; i < sourceLength() ; i++, sw = sw->rest())
	 {
	 FrSymbol *sword = (FrSymbol*)sw->first() ;
	 if (!constr->isSourceReversedRight(sword))
	    continue ;
	 if (numTargetCorrespondences(i) >= 1 &&
	     numTargetCorrespondences(i-1) > 1 &&
	     hasTargetCorrespondences(i-1,firstCorrespondence(i),
				      targetLength()-1))
	    {
	    // remove correspondences for the tightly bound word's
	    //   lefthand neighbor which are to the left of the leftmost
	    //   possible translation
	    removed += clearCorrespondences(i-1,0,firstCorrespondence(i)-1) ;
	    }
	 if (numTargetCorrespondences(i) < 2)
	    continue ;		// don't bother further if no ambig.
	 // remove any occurrences to the right of the last possibility
	 //   for the lefthand neighbor
	 removed += clearCorrespondences(i,lastCorrespondence(i-1)+1,
					 targetLength()-1) ;
	 }
      }
   if (constr->targetLeftBindings())
      {
//FIXME: apply constraints
      }
   else if (constr->targetLeftReversals())
      {
      }
   if (constr->targetRightBindings())
      {
      }
   else if (constr->targetRightReversals())
      {
      }
   return removed ;
}

//----------------------------------------------------------------------

void BiTextMap::pruneTarget(size_t s_start, size_t s_end,
			    size_t t_start, size_t t_end)
{
   for (size_t s = s_start ; s <= s_end ; s++)
      {
      size_t t ;
      for (t = 0 ; t < t_start ; t++)
	 {
	 clearCorrespondence(s,t) ;
	 }
      for (t = t_end + 1 ; t < targetLength() ; t++)
	 {
	 clearCorrespondence(s,t) ;
	 }
      }
}

//----------------------------------------------------------------------

static size_t count_gaps(const unsigned char *counts, int length)
{
   size_t gaps = 0 ;
   for (int i = 0 ; i < length ; i++)
      if (counts[i] == 0)
	 gaps++ ;
   return gaps ;
}

//----------------------------------------------------------------------

static size_t find_gap(const unsigned char *counts, int length)
{
   for (int i = 0 ; i < length ; i++)
      if (counts[i] == 0)
	 return i ;
   return length ;
}

//----------------------------------------------------------------------

void BiTextMap::fillGaps(const EbAlignConstraints *constraints)
{
   if (!wantGapsFilled())
      return ;
   // 1: find the rows/columns of the table with no entries
   size_t sgaps = count_gaps(source_counts,sourceLength()) ;
   size_t tgaps = count_gaps(target_counts,targetLength()) ;
   if (sgaps == 0 || tgaps == 0)	// need at least one gap in each
      {					//   dimension to do anything...
#ifdef DEBUG_FILL
      cerr << "; fillGaps() : gaps " << sgaps << ',' << tgaps << endl ;
#endif /* DEBUG_FILL */
      return ;
      }
   unsigned raw_sc = EbMakeAlignlinkScore(0.1 / (sgaps * tgaps)) ;
   if (sgaps == 1 && tgaps == 1)
      {
      // 2: if only a single row and single column, declare the intersection
      //     to be a correspondence, and return
      size_t sgap = find_gap(source_counts,sourceLength()) ;
      size_t tgap = find_gap(target_counts,targetLength()) ;
      addCorrespondence(sgap,tgap,raw_sc) ;
      }
   else if (sgaps < 4 && tgaps < 4 && sgaps < sourceLength()/4)
      {
      // 3: if multiple gaps, match each source gap to each target gap, and
      //    then remove the outliers....
      for (size_t i = 0 ; i < sourceLength() ; i++)
	 if (source_counts[i] == 0 &&
	     (i == 0 || source_counts[i-1] > 0) &&
	     (i == sourceLength()-1 || source_counts[i+1] > 0))
	    {
	    for (size_t j = 0 ; j < targetLength() ; j++)
	       if (target_counts[j] == 0 &&
		   (j == 0 || target_counts[j-1] > 0) &&
		   (j == targetLength()-1 || target_counts[j+1] > 0))
		  {
		  correspondences[i*targetLength() + j] = raw_sc ;
		  source_counts[i]++ ;
		  target_counts[j]++ ;
		  }
	    }
      removeOutliers(constraints) ;
      }
#ifdef DEBUG_FILL
   size_t sgaps2 = count_gaps(source_counts,sourceLength()) ;
   size_t tgaps2 = count_gaps(target_counts,targetLength()) ;
   if (sgaps2 == sgaps && tgaps2 == tgaps)
      cerr << "; fillGaps() : gaps " << sgaps << ','
           << tgaps << endl ;
   else
      cerr << "; fillGaps() : gaps went from "
	   << sgaps << ',' << tgaps << " to " << sgaps2 << ',' << tgaps2
	   << endl ;
#endif /* DEBUG_FILL */
   return ;
}

//----------------------------------------------------------------------

void BiTextMap::recountCorrespondences()
{
   size_t i ;
   for (i = 0 ; i < sourceLength() ; i++)
      source_counts[i] = (char)numTargetCorrespondences(i,0,targetLength()-1) ;
   for (i = 0 ; i < targetLength() ; i++)
      target_counts[i] = (char)numSourceCorrespondences(i,0,sourceLength()-1) ;
   return ;
}

//----------------------------------------------------------------------

void BiTextMap::setText(FrList *src, FrList *trg)
{
   free_object(source_words) ;
   source_words = src ;
   free_object(target_words) ;
   target_words = trg ;
   return ;
}

//----------------------------------------------------------------------

void BiTextMap::setCorrespondence(size_t src, const FrObject *align,
				  int origin, double default_score,
				  const EbAlignConstraints *constr,
				  bool second_pass, bool reverse_alignment)
{
   if (align)
      {
      double score = default_score ;
      if (align->numberp())
	 setCorrespondence(src,align->intValue() - origin, score,
			   constr,second_pass,reverse_alignment) ;
      else if (align->consp())
	 {
	 FrSymbol *symEQUAL = FrSymbolTable::add("=") ;
	 FrSymbol *symHASH = FrSymbolTable::add("#") ;
	 FrList *e = ((FrList*)align)->member(symEQUAL) ;
	 if (e && e->rest() && e->rest()->first())
	    {
	    e = e->rest() ;
	    score = e->first()->floatValue() ;
	    if (score > 1.0)
	       score = (score + 0.5) / CORR_SCALE ;
	    }
	 FrList *h = ((FrList*)align)->member(symHASH) ;
	 if (h && h->rest() && h->rest()->first())
	    {
	    h = h->rest() ;
	    score = h->first()->floatValue() ;
	    // do we have a second score?
	    if (score <= 1.0 && h->rest() && h->rest()->first() &&
		h->rest()->first()->numberp())
	       {
	       h = h->rest() ;
	       // compute the geometric mean of the two scores (we want to
	       //   drag the composite down if one direction's score is
	       //   extremely low, e.g. epsilon)
	       double score2 = h->first()->floatValue() ;
	       score = sqrt(score * score2) ;
	       }
	    if (score > 1.0)
	       score = (score + 0.5) / CORR_SCALE ;
	    }
	 for (const FrList *al = (FrList*)align ; al ; al = al->rest())
	    {
	    FrObject *a = al->first() ;
	    if (EBMT_equal(a,symEQUAL))
	       al = al->rest() ;	//  skip eq.sign and following value
	    else if (a == symHASH)
	       {
	       al = al->rest() ;
	       if (al)
		  al = al->rest() ;
	       if (!al)
		  break ;
	       }
	    else if (a->numberp())
	       {
	       setCorrespondence(src,a->intValue() - origin, score, constr,
				 second_pass,reverse_alignment) ;
	       }
	    else if (a->consp())
	       {
	       setCorrespondence(src,a,origin,score,constr,
				 second_pass,reverse_alignment) ;
	       }
	    }
	 }
      else if (!second_pass)
	 {
	 char *item = align->print() ;
	 FrWarningVA("expected number or list in aligment info, got\n"
		     "\t%s",item) ;
	 FrFree(item) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void BiTextMap::setMultiCorrespondence(const FrList *align, int origin,
				       double def_score,
				       const EbAlignConstraints *constr,
				       bool second_pass,
				       bool reverse_alignment)
{
   if (align)
      {
      FrSymbol *comma = makeSymbol(",") ;
      FrList *target = align->member(comma) ;
      if (!target)
	 return ;
      target = target->rest() ;
      for (const FrList *al = align ; al->first() != comma ; al=al->rest())
	 {
	 FrObject *a = al->first() ;
	 if (a->numberp())
	    {
	    setCorrespondence(a->intValue() - origin, target, origin,
			      def_score, constr, second_pass,
			      reverse_alignment) ;
	    }
	 else if (!second_pass)
	    {
	    char *item = align->print() ;
	    FrWarningVA("expected number in aligment info element, got\n"
			"\t%s",item) ;
	    FrFree(item) ;
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void BiTextMap::addCorrespondence(int src, int trg, unsigned char sc)
{
   if ((size_t)trg >= targetLength())
      return ;
   unsigned char *corr = &correspondences[src*targetLength() + trg] ;
   if (sc > *corr)
      {
      if (*corr == 0)
	 {
	 source_counts[src]++ ;
	 target_counts[trg]++ ;
	 }
      *corr = sc ;
      }
   return ;
}

//----------------------------------------------------------------------

void BiTextMap::setCorrespondence(size_t src, long trg, double score,
				  const EbAlignConstraints *constr,
				  bool second_pass, bool reverse_alignment)
{
   if (reverse_alignment)
      {
      size_t tmp = trg ;
      trg = src ;
      src = tmp ;
      }
   if (!correspondences || src >= sourceLength() ||
       (size_t)trg >= targetLength())
      return ;
   unsigned char sc = EbMakeAlignlinkScore(score) ;
   if (trg >= 0 && !second_pass)
      addCorrespondence(src,trg,sc) ;
   else if (trg < 0 && second_pass && constr &&
	    (constr->sourceLeftBindings() || constr->sourceRightBindings()))
      {
      // word explicitly has no correspondence, but see if we should
      //   glom onto one of its neighbors
      FrSymbol *word = (FrSymbol*)source_words->nth(src) ;
      if (src+1 < sourceLength() && source_counts[src+1] == 1 &&
	  constr && constr->isSourceBoundRight(word))
	 {
	 size_t loc = firstCorrespondence(src+1) ;
	 addCorrespondence(src,loc,sc) ;
	 }
      else if (src > 0 && source_counts[src-1] == 1 &&
	       constr && constr->isSourceBoundLeft(word))
	 {
	 size_t loc = firstCorrespondence(src-1) ;
	 addCorrespondence(src,loc,sc) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void BiTextMap::elideSourceWord(size_t src)
{
   if (src < sourceLength())
      {
      // adjust counts for all columns affected by the elided row
      unsigned char *removal_point = &correspondences[src * targetLength()] ;
      for (size_t j = 0 ; j < targetLength() ; j++)
	 {
	 if (removal_point[j])
	    target_counts[j]-- ;
	 }
      // remove the specified row from the correspondence table
      size_t remainder = ((sourceLength() - src) * targetLength() +
			  sourceLength()) ;
      memmove(removal_point, removal_point + targetLength(), remainder) ;
      source_counts -= targetLength() ;
      target_counts -= targetLength() ;
      removal_point = source_counts + src ;
      memmove(removal_point, removal_point + 1,
	     targetLength() + sourceLength() - src) ;
      target_counts-- ;
      source_length-- ;
      if (source_words)
	 source_words = (FrList*)source_words->elide(src,src) ;
      }
   return ;
}

//----------------------------------------------------------------------

void BiTextMap::elideTargetWord(size_t trg)
{
   if (trg < targetLength())
      {
      // adjust counts for all rows affected by the elided column
      for (size_t j = 0 ; j < sourceLength() ; j++)
	 {
	 if (wordsCorrespond(j,trg))
	    source_counts[j]-- ;
	 }
      // remove the specified column from the correspondence table
      unsigned char *corr = correspondences ;
      unsigned char *row = correspondences ;
      for (size_t i = 0 ; i < sourceLength() ; i++)
	 {
	 size_t j ;
	 for (j = 0 ; j < trg ; j++)
	    *corr++ = row[j] ;
	 for (j = trg + 1 ; j < targetLength() ; j++)
	    *corr++ = row[j] ;
	 row += targetLength() ;
	 }
      source_counts -= sourceLength() ;
      target_counts -= sourceLength() ;
      memmove(source_counts,source_counts+sourceLength(),
	      sourceLength()+targetLength()) ;
      memmove(target_counts+trg,target_counts+trg+1,targetLength()-trg) ;
      target_length-- ;
      if (target_words)
	 target_words = (FrList*)target_words->elide(trg,trg) ;
      }
   return ;
}

//----------------------------------------------------------------------

bool BiTextMap::insertTargetWord(size_t trg)
{
   if (trg < targetLength())
      {
      unsigned char *new_corr = FrNewN(unsigned char,
				       (sourceLength()+1)*(targetLength()+2)) ;
      if (new_corr)
	 {
	 // generate new count arrays
	 unsigned char *new_src_counts
	    = &new_corr[sourceLength()*(targetLength()+1)] ;
	 unsigned char *new_trg_counts
	    = &new_src_counts[sourceLength()] ;
	 memcpy(new_src_counts,source_counts,sourceLength()) ;
	 if (trg > 0)
	    memcpy(new_trg_counts,target_counts,trg) ;
	 new_trg_counts[trg] = 0 ;
	 memcpy(new_trg_counts+trg+1,target_counts+trg,targetLength()-trg) ;
	 source_counts = new_src_counts ;
	 target_counts = new_trg_counts ;
	 // generate the new correspondence table
	 for (size_t i = 0 ; i < sourceLength() ; i++)
	    {
	    unsigned char *row = &correspondences[i * targetLength()] ;
	    unsigned char *newrow = &new_corr[i * (targetLength()+1)] ;
	    for (size_t j = 0 ; j < trg ; j++)
	       {
	       newrow[j] = row[j] ;
	       }
	    newrow[trg] = (unsigned char)0 ;
	    for (size_t j = trg ; j < targetLength() ; j++)
	       {
	       newrow[j+1] = row[j] ;
	       }
	    }
	 // adjust the stored text, if present
	 if (target_words)
	    {
	    target_words = (FrList*)target_words->insert(new FrString(""),
							 trg) ;
	    }
	 // final clean-up
	 FrFree(correspondences) ;
	 correspondences = new_corr ;
	 target_length++ ;
	 return true ;
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

int BiTextMap::firstTargetCorrespondence(int sword) const
{
   unsigned char *corr = &correspondences[sword * targetLength()] ;
   if (source_counts[sword])
      {
      for (size_t i = 0 ; i < targetLength() ; i++)
	 if (corr[i] != 0)
	    return i ;
      }
   // if we get here, there were no target correspondences...
   return -1 ;
}

//----------------------------------------------------------------------

int BiTextMap::nextTargetCorrespondence(int sword, int prev) const
{
   unsigned char *corr = &correspondences[sword * targetLength()] ;
   for (size_t i = prev+1 ; i < targetLength() ; i++)
      {
      if (corr[i] != 0)
	 return i ;
      }
   // if we get here, there were no target correspondences in range...
   return -1 ;
}

//----------------------------------------------------------------------

int BiTextMap::numTargetCorrespondences(int sword, int t_start,
					int t_end) const
{
   int count = 0 ;
   unsigned char *corr = &correspondences[sword * targetLength() + t_start] ;
   size_t total = t_end - t_start ;
   for (size_t i = 0 ; i <= total ; i++)
      {
      if (*corr++ != 0)
	 count++ ;
      }
   return count ;
}

//----------------------------------------------------------------------

bool BiTextMap::hasTargetCorrespondences(int sword, int t_start,
					   int t_end) const
{
   unsigned char *corr = &correspondences[sword * targetLength() + t_start] ;
   for (int i = t_end-t_start ; i >= 0 ; i--)
      {
      if (*corr)
	 return true ;
      corr++ ;
      }
   return false ;
}

//----------------------------------------------------------------------

int BiTextMap::maxTargetCorrespondence(int sword, int t_start,
				       int t_end) const
{
   int max = 0 ;
   unsigned char *corr = &correspondences[sword * targetLength() + t_start] ;
   for (int i = t_end-t_start ; i >= 0 ; i--)
      {
      if (*corr > max)
	 max = *corr ;
      corr++ ;
      }
   return max ;
}

//----------------------------------------------------------------------

double BiTextMap::totalTargetCorrespondences(int sword, int t_start,
					     int t_end) const
{
   double total = 0.0 ;
   unsigned char *corr = &correspondences[sword * targetLength() + t_start] ;
   for (int i = t_end-t_start ; i >= 0 ; i--)
      {
      total += alignlink_scores[*corr] ;
      corr++ ;
      }
   return total ;
}

//----------------------------------------------------------------------

int BiTextMap::numSourceCorrespondences(int tword,int s_start, int s_end) const
{
   int count = 0 ;
   unsigned char *corr = &correspondences[s_start * targetLength() + tword] ;
   for (int i = s_start ; i <= s_end ; i++)
      {
      if (*corr)
	 count++ ;
      corr += targetLength() ;
      }
   return count ;
}

//----------------------------------------------------------------------

bool BiTextMap::hasSourceCorrespondences(int tword, int s_start,
					   int s_end) const
{
   unsigned char *corr = &correspondences[s_start * targetLength() + tword] ;
   for (int i = s_start ; i <= s_end ; i++)
      {
      if (*corr)
	 return true ;
      corr += targetLength() ;
      }
   return false ;
}

//----------------------------------------------------------------------

int BiTextMap::maxSourceCorrespondence(int tword,int s_start, int s_end) const
{
   int max = 0 ;
   unsigned char *corr = &correspondences[s_start * targetLength() + tword] ;
   for (int i = s_start ; i <= s_end ; i++)
      {
      if (*corr > max)
	 max = *corr ;
      corr += targetLength() ;
      }
   return max ;
}

//----------------------------------------------------------------------

double BiTextMap::totalSourceCorrespondences(int tword,int s_start, int s_end) const
{
   double total = 0.0 ;
   unsigned char *corr = &correspondences[s_start * targetLength() + tword] ;
   for (int i = s_start ; i <= s_end ; i++)
      {
      total += alignlink_scores[*corr] ;
      corr += targetLength() ;
      }
   return total ;
}

//----------------------------------------------------------------------

bool BiTextMap::sameCorrespondences(size_t word1, size_t word2) const
{
   if (word1 >= sourceLength() || word2 >= sourceLength())
      return false ;
   const unsigned char *corr1 = sourceCorrespondences(word1) ;
   const unsigned char *corr2 = sourceCorrespondences(word2) ;
   for (size_t j = 0 ; j < targetLength() ; j++)
      {
      bool corr_1 = (corr1[j] != 0) ;
      // Note: if both "!=0" expressions are put inside the if(), the Watcom
      //    compiler complains about adjacent comparison operator, even when
      //    parenthesized!
      if (corr_1 != (corr2[j] != 0))
	 return false ;
      }
   return true ;
}

//----------------------------------------------------------------------

size_t BiTextMap::compress(char *&compressed, bool /*resizemem*/) const
{
   size_t type = (targetLength() > 255) ? EbCORPUS_EXTRA_BITEXT_FLOAT2
      				       : EbCORPUS_EXTRA_BITEXT_FLOAT1 ;
   size_t ofs_size = (targetLength() > 255) ? 2 : 1 ;
   size_t len = sourceLength() + 1 ;	// need a byte per word for counts
   for (size_t s = 0 ; s < sourceLength() ; s++)
      {
      len += numTargetCorrespondences(s) * (ofs_size + 1) ;
      }
   compressed = FrNewN(char,len) ;
   if (!compressed)
      {
      FrWarning("ran out of memory while compressing bitext map") ;
      return 0 ;
      }
   unsigned char *comp = (unsigned char*)compressed ;
   *comp++ = type ;
   for (size_t s = 0 ; s < sourceLength() ; s++)
      {
      *comp++ = numTargetCorrespondences(s) ;
      for (size_t t = 0 ; t < targetLength() ; t++)
	 {
	 unsigned char corr = wordsCorrespond(s,t) ;
	 if (corr)
	    {
	    if (ofs_size == 2)
	       {
	       FrStoreShort(t,comp) ;
	       comp += 2 ;
	       }
	    else
	       *comp++ = t ;
	    *comp++ = corr ;
	    }
	 }
      }
   return len ;
}

//----------------------------------------------------------------------

FrList *BiTextMap::alignment() const
{
   FrList *align ;
   FrList **align_end = &align ;
   FrSymbol *symEQUAL = FrSymbolTable::add("=") ;
   for (size_t i = 0 ; i < sourceLength() ; i++)
      {
      FrList *a  ;
      FrList **a_end = &a ;
      for (size_t j = 0 ; j < targetLength() ; j++)
	 {
	 if (wordsCorrespond(i,j))
	    {
	    double sc = correspondenceScore(i,j) ;
	    if (sc != 1.0)
	       {
	       sc = (sc * CORR_SCALE) + 0.5 ;
	       FrList *link = new FrList(new FrInteger(j+1),symEQUAL,
					 new FrInteger((long)sc)) ;
	       a->pushlistend(link,a_end) ;
	       }
	    else
	       a->pushlistend(new FrInteger(j+1),a_end) ;
	    }
	 }
      *a_end = 0 ; 			// properly terminate the list
      if (a && !a->rest())
	 {
	 FrObject *head = a->first() ;
	 a->replaca(0) ;
	 free_object(a) ;
	 align->pushlistend(head,align_end) ;
	 }
      else
	 align->pushlistend(a,align_end) ;
      }
   *align_end = 0 ;			// properly terminate the list
   return align ;
}

//----------------------------------------------------------------------

bool BiTextMap::equal(const BiTextMap *other) const
{
   if (!other ||
       sourceLength() != other->sourceLength() ||
       targetLength() != other->targetLength() ||
       !correspondences || !other->correspondences)
      return false ;
   size_t count = (sourceLength() * targetLength()) ;
   for (size_t i = 0 ; i < count ; i++)
      {
      bool link1 = (correspondences[i] != 0) ;
      bool link2 = (other->correspondences[i] != 0) ;
      if (link1 != link2)
	 return false ;
      }
   return true ;
}

//----------------------------------------------------------------------

bool BiTextMap::equal(const BiTextMap *other,
			size_t sstart, size_t osstart, size_t slen,
			size_t tstart, size_t otstart, size_t tlen) const
{
   if (!other || sstart + slen > sourceLength() ||
       tstart + tlen > targetLength() ||
       osstart + slen > other->sourceLength() ||
       otstart + tlen > other->targetLength() ||
       !correspondences || !other->correspondences)
      return false ;

   // There are two options for how strictly the alignments are checked

   int max = ((targetLength()-tstart > other->targetLength()-otstart)
	      ? target_length-tstart : other->target_length-otstart) ;
   int min = (-tstart < -otstart) ? -tstart : -otstart;

   // Correct Source->Target Mapping
   for (size_t s = 0 ; s < slen ; s++)
     {
       for (int t = min ; t < max ; t++)
	 {
	   bool corr = false;
	   if (/*(tstart+t) >= 0 &&*/ (tstart+t) < targetLength())
	     corr = wordsCorrespond(sstart+s,tstart+t) != 0;

	   bool ocorr = false;
	   if (/*(otstart+t) >= 0 &&*/ (otstart+t) < other->targetLength())
	     ocorr = other->wordsCorrespond(osstart+s,otstart+t) != 0;

	   if (corr != ocorr)
	     return false ;
	 }
     }

   max = ((sourceLength()-sstart > other->sourceLength()-osstart)
	  ? sourceLength()-sstart : other->sourceLength()-osstart) ;
   min = (-sstart < -osstart) ? -sstart : -osstart;

   // Correct Source->Target Mapping
   for (size_t t = 0 ; t < tlen ; t++)
     {
       for (int s = min ; s < max ; s++)
	 {
	   bool corr = false;
	   if (/*(sstart+s) >= 0 &&*/ (sstart+s) < sourceLength())
	     corr = wordsCorrespond(sstart+s,tstart+t) != 0;

	   bool ocorr = false;
	   if (/*(osstart+s) >= 0 &&*/ (osstart+s) < other->sourceLength())
	     ocorr = other->wordsCorrespond(osstart+s,otstart+t) != 0;

	   if (corr != ocorr)
	     return false ;
	 }
     }

#if 0
   // Target alignments outside of region must both exist
   for (int t = 0 ; t < tlen ; t++)
      {
      int s = 0;
      bool c = false;
      while (!c && s < sourceLength())
	 {
	 if (wordsCorrespond(s,tstart+t))
	    c = true;
	 (s == sstart - 1) ? s = sstart+slen : s++;
	 }

      int os = 0;
      bool oc = false;
      while (!oc && os < other->sourceLength())
	 {
	 if (other->wordsCorrespond(os,otstart+t))
	    oc = true;
	 (os == osstart - 1) ? os = osstart+slen : os++;
	 }
      if (c != oc)
	 return false;
      }
#endif

   return true ;
}

//----------------------------------------------------------------------

void BiTextMap::dump(FILE *fp) const
{
   if (source_words)
      {
      char *sw = source_words->print() ;
      fprintf(fp,"From: %s\n",sw) ;
      FrFree(sw) ;
      }
   if (target_words)
      {
      char *tw = target_words->print() ;
      fprintf(fp,"  To: %s\n",tw) ;
      FrFree(tw) ;
      }
   if (correspondences)
      {
      fputs("  ",fp) ;
      for (size_t k = 0 ; k < targetLength() ; k++)
	 fputc(target_counts[k]+'0',fp) ;
      fputc('\n',fp) ;
      for (size_t l = 0 ; l < sourceLength() ; l++)
	 {
	 fputc(source_counts[l]+'0',fp) ;
	 fputc(' ',fp) ;
	 for (size_t k = 0 ; k < targetLength() ; k++)
	    {
	    char link = '.' ;
	    double sc = correspondenceScore(l,k) ;
	    if (sc > 0.0)
	       {
	       link = (char)((sc * 10.0) + '0') ;
	       if (link > '9')
		  link = '*' ;
	       }
	    fputc(link,fp) ;
	    }
	 fputc('\n',fp) ;
	 }
      fputc('\n',fp) ;
      }
   else
      fputs("--no correspondence table--\n",fp) ;
   return ;
}

//----------------------------------------------------------------------

void BiTextMap::dump() const
{
   dump(stderr) ;
   return ;
}

// end of file ebbitext.cpp //
