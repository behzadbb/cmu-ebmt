/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebmt.h	     general declarations				*/
/*  LastEdit: 08apr10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __EBMT_H_INCLUDED
#define __EBMT_H_INCLUDED

#ifndef __FRAMEPAC_H_INCLUDED
#include "FramepaC.h"
#endif

#ifndef __EBCHUNKS_H_INCLUDED
#include "ebchunks.h"
#endif

/************************************************************************/
/*    Manifest constants for this module				*/
/************************************************************************/

#define EBMT_VERSION_STR 	"2.95"

#define EBMT_GAP_FILLER_UNKNOWN ((size_t)~0)
#define EBMT_GAP_FILLER_NOTGAP	(((size_t)~0)-1)

/************************************************************************/
/*    Types								*/
/************************************************************************/

class Dictionary ;
class EBMTCandidate ;
class EBMTConfig ;
class EBMTCorpus ;
class EBMTGlobalVariables ;
class EBMTIndex ;
class EbSentence ;

/************************************************************************/
/************************************************************************/

class EBMT
   {
   private:
      EBMTGlobalVariables *vars ;
      FrSymbolTable *symtab ;
      EBMTCorpus *corpus ;
      EBMTCorpus *active_corpus ;
      FILE *alignfp ;
      bool changed ;
   public:
      EBMT() ;
      EBMT(EBMTConfig *config, const char *argv0, ostream &err,
	   bool force_creation = false, bool for_indexing = false) ;
      ~EBMT() ;
      bool save() ;

      FrList *lookupDict(const FrTextSpans *lattice) ;
      bool exportDictionary(const char *exportfile) ;

      bool dumpIndex(const char *exportfile) ;
      bool exportCorpus(const char *exportfile) ;

      EBMTCandidate *findMatches(FrTextSpans *lattice, size_t max_alts = 0,
				 size_t max_alts1 = 0,
				 bool keep_sentpair = false) ;

      void selectFirstCorpus() { active_corpus = corpus ; }
      void selectNextCorpus() ;
      bool selectedCorpusEnabled() const ;

      EBMTCorpus *findCorpus(const char *corpusname,bool strict=true) const ;
      bool enableCorpus(const char *corpusname,
			  bool disable_all_others = false) ;
      bool disableCorpus(const char *corpusname,
			   bool enable_all_others = false) ;

      bool selectGenre(const char *genre_name) ;

      char *privateCommand(const char *command) ;

      // access to internal state
      bool OK() const { return corpus != 0 ; }
      EBMTCorpus *getCorpus() const { return active_corpus ; }
      EBMTIndex *getIndex() const ;
      FrSymbolTable *symbolTable() const { return symtab ; }
      FILE *getAlignFP() const { return alignfp ; }
   } ;

/************************************************************************/
/************************************************************************/

void apply_EBMT_configuration(EBMTConfig *config) ;
void identify_EBMT(ostream &out, bool as_comment = false) ;
bool initialize_EBMT(const char *argv0, const char *configfile,
		     ostream &err, bool force_creation,
		     bool for_indexing = false,
		     const char *corpus_create_directory = 0) ;

EBMT *active_EBMT() ;
int EBMT_max_alternatives() ;
int EBMT_max_alternatives(int new_max) ;

EBMTCorpus *EbSetActiveEBMTCorpus(EBMTCorpus *) ;
EBMTCorpus *active_EBMTCorpus() ;

void EBMT_set_word_delimiters(FrCharEncoding enc) ;
void EBMT_set_word_delimiters(const char *delim) ;

EBMTCandidate *EbCombineChunks(EBMTCandidate *chunks, const FrList *sentence);
EBMTCandidate *process_sentence_EBMT(FrTextSpans *lattice,
				     bool keep_sentpair = false) ;
void EbProcessSpecialOption(FrSymbol *option, EBMTCorpus *corpus,
			    istream &in, ostream &out) ;
void EbProcessSentence(const FrObject *sent, ostream &out) ;
int perform_EBMT(EBMT *ebmt, ostream &out, istream &in) ;
int compute_global_match_stats(EBMT *ebmt, istream &in, ostream &out) ;

void EbSetArgv0(const char *a) ;
void EbNetworkServerMode(bool net) ;
void EbSetConfigFilename(const char *cfg) ;
void EbSetActiveCorpus(EBMTCorpus *) ;
EBMTCorpus *EbActiveCorpus() ;
void EbDeleteActiveCorpus() ;

bool EbTerseOutput() ;
bool EbNetworkServerMode() ;
int EbSentencesProcessed() ;

void EbDisplayBanner(ostream &out, bool as_comment = false) ;

bool add_EBMT_entry(const FrString *phrase, const FrString *translation,
		      const FrString *tags, ostream &err) ;
bool add_dict_entry(const FrString *word, const FrList *translation,
		      size_t count, ostream &err) ;
bool save_EBMT_updates() ;
bool pack_EBMT_index(ostream &out) ;
bool shutdown_EBMT() ;

EBMTCandidate *find_full_chunks(const uint32_t *IDs, size_t N,
				const FrTextSpans *original_lattice,
				EBMTCorpus *corpus,
				EbIndexSpec = EbIndex_Main) ;
void write_EBMT_alignments(const EBMTCandidate *chunks, FILE *fp = 0) ;
void output_chunks(EBMTCandidate *chunks, ostream &out,
		   const FrTextSpans *input_lattice = 0) ;
FrList *EbPrintCandidate(EBMTCandidate *cand,
			 const FrTextSpans *input_lattice = 0,
			 bool show_feature_names = true) ;
FrList *EbFeatureNames(const EBMTCandidate *cand) ;
FrList *EbLinearFeatureNames(const EBMTCandidate *cand) ;

void output_translations(EBMTCandidate *chunks, ostream &out,
			 const FrObject *input_sentence) ;
void EbOutputSentenceCoverage(const char *cover, size_t cover_size,
			      size_t sentence_length) ;

int check_index_status(EBMTIndex *corpus_index, ostream &err) ;

bool extract_MMR_lines(const char *outfile, FILE *infp, size_t desired,
			 size_t max_allowed, size_t max_passes) ;

bool EbBuildMutualInfoTable(FILE *fp, ostream *out, bool finish = false,
			      double threshold = 0.1, size_t minfreq = 1,
			      bool chi_sq = false) ;
Dictionary *EbGetMutualInfoTable() ;
void EbFreeDictionarySymbolTable() ;

size_t EbMaxGapOffset() ;
bool EbIsGapMarker(const char *word) ;
bool EbIsGapMarker(const FrSymbol *word) ;
bool EbIsLeftGapMarker(const char *word) ;
bool EbIsEmbeddedGapMarker(const char *word) ;
bool EbIsUnknownGapMarker(const char *word) ;
FrSymbol *EbMakeGapMarker(int offset, bool absolute = false,
			  bool embedded = false,
			  const char *restriction = 0) ;
FrSymbol *EbMakeGapMarker(FrSymbol *relmarker, size_t start, size_t len) ;
FrString *EbMakeGapMarkerStr(int offset, bool absolute = false,
			     bool embedded = false,
			     const char *restriction = 0) ;
size_t EbAbsGapFillerLocation(const char *marker) ;
size_t EbAbsGapFillerLocation(const FrSymbol *marker) ;
int EbGapFillerOffset(const char *marker) ;
size_t EbGapFillerLocation(const char *marker, size_t start, size_t len) ;
size_t EbGapFillerLocation(const FrSymbol *marker, size_t start, size_t len) ;
char *EbGapFillerRestriction(const char *marker) ; // use FrFree on result

bool EbCacheGappedMatch(FrBWTLocation before, FrBWTLocation after,
			  const FrBWTLocationList *occur) ;
FrBWTLocationList *EbCachedGappedMatch(FrBWTLocation before,
				       FrBWTLocation after) ;
bool EbClearGappedMatchCache() ;

bool EbAlignCacheInit() ;
bool EbAlignCacheActive() ;
int EbAlignCacheContext(EbIndexSpec which, size_t recnum,
			size_t startpos, size_t endpos) ;
const EBMTCandidate *EbAlignCacheCandidate(EbIndexSpec which, size_t recnum,
					   size_t startpos, size_t endpos) ;
void EbAlignCacheStats(size_t &lookups, size_t &hits, size_t &inserts) ;
bool EbAlignCacheClear() ;
bool EbAlignCacheFree() ;

FrList *EbWordAlignments(const EBMTCandidate *) ;
FrList *EbWordAlignments(const EBMTCandidate *, size_t s_start, size_t s_end) ;
FrList *EbCandidateOrigin(const EBMTCandidate *) ;

double EbSourceFeatureScore(const class EbCorpusMatches *matches,
			    const class EBMTIndex *index,
			    size_t recnum, size_t offset, size_t input_len) ;
double EbSourceFeatureScore(const EBMTCandidate *) ;

void EbSetCharEncoding(const char *enc_name) ;
bool EBMT_quiet_mode(bool newmode) ;

void EbAddAlignmentFeatures() ;

bool EbPrepareDocument(bool starting) ;

bool EbInsertExtraSpan(FrTextSpans *input_lattice, FrTextSpan *new_span) ;
bool EbRemoveExtraSpans(FrTextSpans *input_lattice) ;

// sentence-length modeling
void EbLengthModelInit() ;
bool EbLengthModelUpdate(const char *filename, bool mean) ;
bool EbLengthModelFinishMeans() ;
bool EbLengthModelFinalize(const char *model_file, bool show_on_stdout) ;

// utility functions for 8-bit probabilities
void EbInitAlignlinkScores() ;
unsigned char EbMakeAlignlinkScore(double score) ;
double EbEvalAlignlinkScore(unsigned char stored) ;
double EbEvalAlignlinkScoreLog(unsigned char stored) ;


void EbRunNetworkServer(EBMT *ebmt,int port_number) ;
void shutdown__EBMT() ;

#endif /* !__EBMT_H_INCLUDED */

// end of file ebmt.h //
