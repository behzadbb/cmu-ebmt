/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.92							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebmkdict.h	generate translation dictionary	from corpus	*/
/*  LastEdit: 17mar10							*/
/*									*/
/*  (c) Copyright 1996,1997,1998,1999,2002,2003,2006,2009,2010		*/
/*		 Ralf Brown						*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __EBMKDICT_H_INCLUDED
#define __EBMKDICT_H_INCLUDED

#ifndef __FRCOMMON_H_INCLUDED
#include "frcommon.h"
#endif

#ifdef FrSTRICT_CPLUSPLUS
# include <cstdio>
#else
# include <stdio.h>
#endif /* FrSTRICT_CPLUSPLUS */

#define DEFAULT_MUTUAL_INFO_WINDOW 100

class EBMTConfig ;

//----------------------------------------------------------------------

bool load_dict_thresholds(const char *filename) ;

void EbInitDictionarySymbolTable() ;
FrSymbolTable *EbSelectDictionarySymbolTable() ;
void EbFreeDictionarySymbolTable() ;

int create_dictionary(const EBMTConfig *ebmt_config,
		      bool create_HF_dictionary_requested,
		      const char *refine_to_dict,
		      const char *align_save_filename,
		      bool using_stdin, istream &filelist, ostream &out) ;

		      
#endif /* !__EBMKDICT_H_INCLUDED */

// end of ebmkdict.h //
