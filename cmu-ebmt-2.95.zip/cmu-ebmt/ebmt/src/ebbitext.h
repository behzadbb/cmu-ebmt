/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebbitext.h	bi-text maps					*/
/*  LastEdit: 08apr10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2003,2004,2005,	*/
/*		2006,2007,2009,2010 Ralf Brown				*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __EBBITEXT_H_INCLUDED
#define __EBBITEXT_H_INCLUDED

#include <stdio.h>

#ifndef __FRLIST_H_INCLUDED
#include "frlist.h"
#endif

#ifndef __FRSYMHSH_H_INCLUDED
#include "frsymhsh.h"
#endif

#if defined(__GNUC__)
#  pragma interface
#endif

//----------------------------------------------------------------------

class BiTextMap ;
class Dictionary ;

//----------------------------------------------------------------------

class EbAlignConstraints
   {
   public:
      enum { ct_none = 0,
	     ct_boundleft = 1,
	     ct_boundright = 2,
	     ct_reverseleft = 4,
	     ct_reverseright = 8 } ;
   private:
      const Dictionary *m_dict ;
      FrSymHashTable *m_source ;
      FrSymHashTable *m_target ;
      FrSymHashTable *m_source_stats ;
      FrSymHashTable *m_target_stats ;
      int m_source_types ;
      int m_target_types ;

   protected:
      FrSymHashTable *sourceConstraints() const { return m_source ; }
      FrSymHashTable *targetConstraints() const { return m_target ; }

   public:
      EbAlignConstraints(const Dictionary *dict,
			 const char *constraints_filename) ;
      EbAlignConstraints(const Dictionary *dict,
			 const FrList *src_left, const FrList *src_right,
			 const FrList *trg_left = 0,
			 const FrList *trg_right = 0) ;
      ~EbAlignConstraints() ;

      void clear() ;			// delete all constraints
      bool load(FILE *fp) ;
      bool load(const char *filename) ;
      bool save(FILE *fp) const ;
      bool save(const char *filename) const ;

      // manipulators
      void constrain(const BiTextMap *constraints) ;
      void dictionary(const Dictionary *dict) { m_dict = dict ; }
      void addBoundWord(const char *line, bool source_lang = true,
			bool reverse_order = false, bool on_left = true) ;
      void addBoundWords(const FrList *words, bool source_lang = true,
			bool reverse_order = false, bool on_left = true) ;

      void addStats(FrSymbol *word, bool source_lang, bool unambiguous) ;
      void addSourceStats(FrSymbol *word, bool on_left,
			  bool bound, bool reversed) ;
      void addTargetStats(FrSymbol *word, bool on_left,
			  bool bound, bool reversed) ;

      bool inferConstraints(size_t min_freq, double max_contra) ;

      // accessors
      const Dictionary *dictionary() const { return m_dict ; }
      bool sourceLeftBindings() const
	 { return (m_source_types & ct_boundleft) != 0 ; }
      bool sourceRightBindings() const
	 { return (m_source_types & ct_boundright) != 0 ; }
      bool sourceLeftReversals() const
	 { return (m_source_types & ct_reverseleft) != 0 ; }
      bool sourceRightReversals() const
	 { return (m_source_types & ct_reverseright) != 0 ; }
      bool targetLeftBindings() const
	 { return (m_target_types & ct_boundleft) != 0 ; }
      bool targetRightBindings() const
	 { return (m_target_types & ct_boundright) != 0 ; }
      bool targetLeftReversals() const
	 { return (m_target_types & ct_reverseleft) != 0 ; }
      bool targetRightReversals() const
	 { return (m_target_types & ct_reverseright) != 0 ; }

      bool isSourceBoundLeft(FrSymbol *word) const ;
      bool isSourceBoundRight(FrSymbol *word) const ;
      bool isTargetBoundLeft(FrSymbol *word) const ;
      bool isTargetBoundRight(FrSymbol *word) const ;
      bool isSourceReversedLeft(FrSymbol *word) const ;
      bool isSourceReversedRight(FrSymbol *word) const ;
      bool isTargetReversedLeft(FrSymbol *word) const ;
      bool isTargetReversedRight(FrSymbol *word) const ;
   } ;

//----------------------------------------------------------------------

typedef void BiTextErrFunc(BiTextMap *,size_t /*srcpos*/, size_t /*trgpos*/) ;

class BiTextMap
   {
   private:
      static FrAllocator allocator ;
      static bool fill_gaps ;
      unsigned char *correspondences ;
      unsigned char *source_counts ;
      unsigned char *target_counts ;
      FrList *source_words ;
      FrList *target_words ;
      int   source_length ;
      int   target_length ;
      int   word_order_similarity ;
      bool complete_map ;
   private: // methods
      size_t clearCorrespondences(size_t src, size_t trgstart, size_t trgend) ;
      size_t pruneByFreq(size_t src1, size_t src2, const Dictionary *dict) ;
      size_t applyAlignmentConstraints(const EbAlignConstraints *constr) ;
      size_t numAnchors() const ;
      size_t firstCorrespondence(size_t wordnum) const ;
      size_t lastCorrespondence(size_t wordnum) const ;
      size_t removeSourceOutliers(size_t col, size_t low, size_t high,
				  size_t word_shift) ;
      size_t removeTargetOutliers(size_t row, size_t low, size_t high,
				  size_t word_shift) ;
      void getSourceRange(size_t col, size_t &low, size_t &high,
			  size_t word_shift) const ;
      void getTargetRange(size_t row, size_t &low, size_t &high,
			  size_t word_shift) const ;
      void setCorrespondence(size_t src, const FrObject *align,
			     int origin, double default_score = 1.0,
			     const EbAlignConstraints * = 0,
			     bool set_tightbound_only = false,
			     bool reverse_alignment = false) ;
      void setMultiCorrespondence(const FrList *align, int origin,
				  double def_score = 1.0,
				  const EbAlignConstraints * = 0,
				  bool set_tightbound_only = false,
				  bool reverse_alignment = false) ;
   public:
      void *operator new(size_t) { return allocator.allocate() ; }
      void operator delete(void *blk) { allocator.release(blk) ; }
      BiTextMap(const BiTextMap *) ;
      BiTextMap(const BiTextMap *, size_t srcstart, size_t srcend,
		size_t trgstart, size_t trgend) ;
      BiTextMap(const FrList *source, const FrList *s_analysis,
		const FrList *target, const FrList *t_analysis,
		int similarity = -1, const EbAlignConstraints * = 0) ;
      BiTextMap(const FrList *source, const FrList *target,
		const FrList *alignment, int origin = 0,
		double def_score = 1.0,
		const EbAlignConstraints * = 0,
		bool reverse_alignment = false) ;
      BiTextMap(size_t srclen, size_t trglen, const double *probs,
		FrList *source, FrList *target, double link_cutoff,
		int similarity = -1, const EbAlignConstraints * = 0) ;
      BiTextMap(const char *RLEdata, int source_len, int target_len,
		const char **RLEend, int similarity = -1);
      ~BiTextMap()
	 { FrFree(correspondences) ; free_object(source_words) ;
	   free_object(target_words) ; }
      size_t removeOutliers(const EbAlignConstraints *) ;
      void pruneTarget(size_t s_start, size_t s_end,
		       size_t t_start, size_t t_end) ;
      void fillGaps(const EbAlignConstraints *) ;
      void recountCorrespondences() ;  // a quick workaround for a bug....
      void completeMapping(bool complete = true) { complete_map = complete; }
      void setText(FrList *src, FrList *trg) ; // must be lists of FrSymbol
      void setCorrespondence(size_t src, long trg, double score = 1.0,
			     const EbAlignConstraints * = 0,
			     bool set_tightbound_only = false,
			     bool reverse_alignment = false) ;
      void setCorrespondenceScore(int sword, int tword, double score) ;
      void setCorrespondenceRawScore(int sword, int tword,
				     unsigned char score)
	 { correspondences[sword*target_length+tword] = score ; }
      size_t clearCorrespondence(size_t src, size_t trg) ;
      void elideSourceWord(size_t src) ;
      void elideTargetWord(size_t trg) ;
      // insert a one-word gap prior to word number 'trg' (0=first)
      bool insertTargetWord(size_t trg) ;
      bool isCompleteMap() const { return complete_map ; }
      int firstTargetCorrespondence(int sword) const ;
      int nextTargetCorrespondence(int sword, int prev) const ;
      size_t lastTargetCorrespondence(size_t wordnum) const
	    { return lastCorrespondence(wordnum) ; }
      size_t firstSourceCorrespondence(size_t wordnum) const ;
      size_t firstSourceCorrespondence(size_t wordnum, size_t start) const ;
      size_t lastSourceCorrespondence(size_t wordnum) const ;
      int numTargetCorrespondences(int sword) const
	    { return source_counts[sword] ; }
      int numTargetCorrespondences(int sword, int t_start, int t_end) const ;
      int maxTargetCorrespondence(int sword, int t_start, int t_end) const ;
      double totalTargetCorrespondences(int sword, int t_start,
					int t_end) const ;
      bool hasTargetCorrespondences(int sword, int t_start, int t_end) const;
      int numSourceCorrespondences(int tword) const
	    { return target_counts[tword] ; }
      int numSourceCorrespondences(int tword, int s_start, int s_end) const ;
      int maxSourceCorrespondence(int tword, int s_start, int s_end) const ;
      double totalSourceCorrespondences(int tword, int s_start,
					int s_end) const ;
      bool hasSourceCorrespondences(int tword, int s_start, int s_end) const;
      const unsigned char *sourceCorrespondences(int sword) const
   	    { return &correspondences[sword*target_length] ; }
      unsigned char wordsCorrespond(int sword, int tword) const
	    { return correspondences[sword*target_length+tword] ; }
      double correspondenceScore(int sword, int tword) const ;
      double correspondenceLogScore(int sword, int tword) const ;
      void addCorrespondence(int sword, int tword, unsigned char raw_score) ;
      bool sameCorrespondences(size_t word1, size_t word2) const ;
      bool equal(const BiTextMap *other) const ;
      bool equal(const BiTextMap *other,
		   size_t sstart, size_t osstart, size_t slen,
		   size_t tstart, size_t otstart, size_t tlen) const ;

      static bool wantGapsFilled() { return fill_gaps ; }
      static void wantGapsFilled(bool fill) { fill_gaps = fill ; }

      size_t compress(char *&compressed, bool resizemem = false) const ;
      void dump(FILE *fp) const ;
      void dump() const ; // dump(stderr)
      FrList *alignment() const ;  // use free_object() on result when done

      size_t sourceLength() const { return (size_t)source_length ; }
      size_t targetLength() const { return (size_t)target_length ; }
      FrSymbol *sourceWord(size_t N) const
	 { return source_words ? (FrSymbol*)source_words->nth(N) : 0 ; }
      FrSymbol *targetWord(size_t N) const
	 { return target_words ? (FrSymbol*)target_words->nth(N) : 0 ; }
      // static member functions
      static int maxLength() { return CHAR_BIT ; } // max length of corresp.
   } ;

//----------------------------------------------------------------------

BiTextMap *EbMakeBitext(const FrList *swords, const FrList *twords,
			const FrList *analyzed_target,
			FrCasemapTable number_charmap,
			const EbAlignConstraints *constraints) ;

bool EBMT_equal(const FrObject *s1, const FrObject *s2) ;

#endif /* !__EBBITEXT_H_INCLUDED */

// end of file ebbitext.h //

