/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.91							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebcmd.cpp	run-time command processing			*/
/*  LastEdit: 11feb10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "dict.h"
#include "ebconfig.h"
#include "ebalign.h"
#include "ebcmatch.h"
#include "ebcorpus.h"
#include "ebutil.h"
#include "ebmt.h"
#include "ebglobal.h"

/************************************************************************/
/*	Types for this module						*/
/************************************************************************/

struct General_Command
   {
     const char *name ;
     void (*func)(istream &in, ostream &out) ;
   } ;

struct EBMT_Command
   {
     const char *name ;
     void (*func)(EBMTCorpus *corpus, istream &in, ostream &out) ;
   } ;

class EBMTServer : public FrNetworkServer
   {
   private:
      EBMT *_ebmt ;
   public:
      // [only allow one connection at a time, since there is currently lots
      // of code which will block until all input data is received]
      EBMTServer(EBMT *ebmt,int portnum) : FrNetworkServer(portnum,1)
         { _ebmt = ebmt ;
	   readObjects(true) ; }

      // network activity callbacks
      virtual void onConnect(size_t conn) ;
//      virtual void onDisconnect(size_t conn) ;
      virtual bool onObjectReceived(size_t conn, FrObject *object) ;
   } ;

/************************************************************************/
/*	Forward Declarations						*/
/************************************************************************/

static void process_EBMT_help(EBMTCorpus *, istream &, ostream &out) ;

int perform_EBMT_operation(FrObject *object, ostream &out, istream &in);

/************************************************************************/
/*	Global Variables						*/
/************************************************************************/

static bool terse_output = false ;
static EBMTServer *active_server ;
static ostream *current_outstream = 0 ;
static const char *config_filename = 0 ;

static EBMTCorpus *active_corpus = 0 ;

const char *argv0 = 0 ;
static bool network_server_mode = false ;

static int sentences_processed = 0 ;

/************************************************************************/
/*	Global Data							*/
/************************************************************************/

static const char error_bang[] = "Error!" ;
static const char ready_bang[] = "Ready!" ;
static const char done_bang[] = "Done!" ;
static const char cmt_ready_bang[] = "; Ready!" ;

static const char str_Ok[] = "Ok" ;
static const char str_Error[] = "Error" ;
static const char str_EOF[] = "*EOF*" ;
static const char str_emptylist[] = "()" ;

/************************************************************************/
/************************************************************************/

void shutdown__EBMT()
{
   EbDeleteActiveCorpus() ;
   shutdown_EBMT() ;
   FrShutdown() ;
   return ;
}

//----------------------------------------------------------------------

static bool is_subsumed_chunk(EBMTCandidate *chunk, EBMTCandidate *allchunks)
{
   int start = chunk->inputStart() ;
   int end = start + chunk->inputLength() - 1 ;
   for ( ; allchunks ; allchunks = allchunks->next())
      {
      int otherstart = allchunks->inputStart() ;
      int otherend = otherstart + allchunks->inputLength() - 1 ;
      if (start == otherstart && end == otherend)
	 return true ;
      else if (start >= otherstart && end <= otherend)
         return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

static EBMTCandidate *remove_subsumed_chunks(EBMTCandidate *chunks)
{
   EBMTCandidate *result = 0 ;
   chunks = chunks->sortByChunkPosition() ;
   while (chunks)
      {
      EBMTCandidate *next = chunks->next() ;
      if (result && is_subsumed_chunk(chunks,result))
	 delete chunks ;
      else
	 {
	 chunks->setNext(result) ;	// add to result list
	 result = chunks ;
	 }
      chunks = next ;
      }
   return result->reverseList() ;
}

/************************************************************************/
/*	Methods for class EBMTServer					*/
/************************************************************************/

void EBMTServer::onConnect(size_t conn)
{
   FrNetworkServer::onConnect(conn) ;
   FrOSockStream *out = outputStream(conn) ;
   if (out)
      {
      EbDisplayBanner(*out,true) ;
      (*out) << ready_bang << endl ;
      }
   return ;
}

//----------------------------------------------------------------------

bool EBMTServer::onObjectReceived(size_t conn, FrObject *object)
{
   FrISockStream *in = inputStream(conn) ;
   FrOSockStream *out = outputStream(conn) ;
   if (in && out && _ebmt && _ebmt->OK())
      {
      active_corpus = _ebmt->getCorpus() ;
      current_outstream = out ;
      bool status = perform_EBMT_operation(object,*out,*in) ;
      current_outstream = 0 ;
      active_corpus = 0 ;
      return status ;
      }
   else
      return false ;
}

/************************************************************************/
/************************************************************************/

void EbDisplayBanner(ostream &out, bool as_comment)
{
   identify_EBMT(out,as_comment) ;
   return ;
}

/************************************************************************/
/************************************************************************/

void EbProcessSentence(const FrObject *sent, ostream &out)
{
   if (!sent)
      return ;
   FrTextSpans *lattice = EbMakeLattice(sent,morph_classes,morph_global_info) ;
   if (pending_metadata)
      {
      lattice->addMetaData(pending_metadata) ;
      pending_metadata->freeObject() ;
      pending_metadata = 0 ;
      }
   EBMTCandidate *chunks = process_sentence_EBMT(lattice,show_source_text) ;
   if ((EbTerseOutput() || omit_subsumed) && chunks)
      chunks = remove_subsumed_chunks(chunks) ;
   output_chunks(chunks,out,lattice) ;
   chunks->deleteList() ;
   EbFreeLattice(lattice) ;
   EBMTCandidate::zapAll() ;		// no more objs in use, make mem avail
   sentences_processed++ ;
   return ;
}

//----------------------------------------------------------------------

static void translate_text(istream &in, ostream &out, bool showsrc,
			   const char *cmdname)
{
   FrObject *obj ;
   in >> obj ;
   if (obj)
      {
      show_source_text = showsrc ;
      if (obj->consp())
	 {
	 FrList *sentence = (FrList*)obj->deepcopy() ;
	 EbProcessSentence(sentence,out) ;
	 free_object(sentence) ;
	 }
      else if (obj->stringp())
	 {
	 FrString *sent = (FrString*)obj ;
	 EbProcessSentence(sent,out) ;
	 }
      else if (obj == makeSymbol("?"))
	 out << "Usage:\t" << cmdname << " \"string to translate\"\n"
	     << "\tor\n"
	     << "\t" << cmdname <<" (\"word1\" \"word2\" ...)\n"
	     << endl ;
      else
	 out << error_bang << endl ;
      obj->freeObject() ;
      show_source_text = false ;
      }
   else
      out << "NIL" << endl ;
   return ;
}

//----------------------------------------------------------------------

static void process_chunks_command(EBMTCorpus *, istream &in, ostream &out)
{
   translate_text(in,out,false,"CHUNKS") ;
   return ;
}

//----------------------------------------------------------------------

static void process_src_command(EBMTCorpus *, istream &in, ostream &out)
{
   translate_text(in,out,true,"SRC") ;
   return ;
}

//----------------------------------------------------------------------

static void process_setcorpus_command(EBMTCorpus *, istream &in, ostream &out)
{
   FrObject *obj ;
   in >> obj ;
   if (obj)
      {
      if (obj->stringp())
	 {
	 const char *corpusname = ((FrString*)obj)->stringValue() ;
	 EBMT *ebmt = active_EBMT() ;
	 if (ebmt)
	    {
	    bool success = ebmt->enableCorpus(corpusname,true) ;
	    if (success)
	       out << "\"Corpus selected\"" << endl ;
	    else
	       out << "\"Error selecting corpus\"" << endl ;
	    }
	 }
      else
	 out << "\"SETCORPUS command requires a string with the corpus name\""
	     << endl ;
      }
   return ;
}

//----------------------------------------------------------------------

static void process_setdict_command(EBMTCorpus *, istream &in, ostream &out)
{
   FrObject *obj ;
   in >> obj ;
   if (obj)
      {
      if (obj->stringp())
	 {
	 const char *dictname = ((FrString*)obj)->stringValue() ;
	 EBMT *ebmt = active_EBMT() ;
	 if (ebmt)
	    {
(void)dictname;
//!!!	    bool success = ebmt->selectDictionary(dictname,true) ;
	    bool success = false ;
	    if (success)
	       out << "\"Dictionary selected\"" << endl ;
	    else
	       out << "\"Error selecting dictionary\"" << endl ;
	    }
	 }
      else
	 out << "\"SETDICT command requires a string with the dictionary name\""
	     << endl ;
      }
   return ;
}

//----------------------------------------------------------------------

// in:   ALIGNPHRASE ("source sent" "target sent" "source phrase")
// out:  (startword endword "translation")
//   where 'startword' and 'endword' are the word numbers in the target
//   sentence covered by 'translation'.

static void process_alignphrase_command(EBMTCorpus *corpus, istream &in,
					ostream &out)
{
   FrObject *what ;

   in >> what ;
   if (what == makeSymbol("?") || !what || !what->consp())
      {
      out << "Usage: ALIGNPHRASE (\"sourcesent\" \"targetsent\" \"sourcephrase\")"
	  << endl ;
      }
   else
      {
      const FrObject *ssent = ((FrList*)what)->first() ;
      const FrObject *tsent = ((FrList*)what)->second() ;
      const FrObject *phrase = ((FrList*)what)->third() ;
      if (!ssent || !tsent || !phrase)
	 out << "(-1 -1 \"ERROR: Must provide source, target, and phrase to align\")"
	     << endl ;
      else
	 {
	 FrList *swords = FrCvtString2Wordlist(ssent->printableName(),
					       word_delimiters,abbrevs_list,
					       char_encoding) ;
	 FrList *source = FrCvtWordlist2Symbollist(swords,char_encoding) ;
	 FrList *target = FrCvtString2Wordlist(tsent->printableName(),
					       word_delimiters,abbrevs_list,
					       char_encoding) ;
	 FrList *phr = FrCvtString2Wordlist(phrase->printableName(),
					    word_delimiters,abbrevs_list,
					    char_encoding) ;
	 EBMTIndex *index = corpus->getIndex() ;
	 FrCasemapTable number_charmap = index->numberCharMap() ;
	 BiTextMap *bitext = EBMTCandidate::makeBiText(corpus, source, target,
						       number_charmap,0,
						       false) ;
	 size_t offset = swords->locate(phr,EBMT_equal) ;
	 free_object(swords) ;
	 if (!bitext)
	    out << "(-1 -1 \"ERROR: Unable to create bitext mapping\")"
		<< endl ;
	 else if (offset == (size_t)~0)
	    {
	    out << "(-1 -1 \"ERROR: Phrase not found in source sentence\")"
		<< endl ;
	    delete bitext ;
	    }
	 else
	    {
	    EBMTCandidate cand(source,target,phr,offset,bitext,
			       index->vocabulary()) ;
	    align_chunk(&cand,false) ;
	    if (cand.targetWords())
	       {
	       const FrString *xlat = cand.targetWords() ;
	       FrList *tmp = FrCvtSentence2Wordlist(xlat->printableName()) ;
	       size_t xlatlen = tmp->simplelistlength() ;
	       free_object(tmp) ;
	       out << "(" << cand.targetOffset() << " "
		     << cand.targetOffset() + xlatlen - 1 << " "
		     << xlat << ")" << endl ;
	       }
	    else
	       out << "(-1 -1 \"ERROR: alignment failed\")" << endl ;
	    }
	 free_object(source) ;
	 free_object(target) ;
	 free_object(phr) ;
	 }
      }
   free_object(what) ;
   return ;
}

//----------------------------------------------------------------------

static void process_context_command(EBMTCorpus *corpus,
				    istream &in, ostream &out)
{
   FrObject *which ;
   in >> which ;
   if (which == makeSymbol("?") || !which || !which->numberp())
      {
      out << "Usage: CONTEXT examplenumber range" << endl ;
      return ;
      }
   FrObject *amount ;
   in >> amount ;
   size_t range = 4 ;
   if (amount && amount->numberp() && amount->intValue() > 0)
      range = amount->intValue() ;
   if (range > 20)
      range = 20 ;
   EBMTIndex *index = corpus->getIndex() ;
   if (index)
      {
      FrList *context = index->getContext(which->intValue(),range) ;
      out << context ;
      free_object(context) ;
      }
   else
      out << "\"Error: no active index\"" << endl ;
   return ;
}

//----------------------------------------------------------------------

bool add_dict_entry(const FrString *word, const FrList *translation,
		      size_t count, ostream &err)
{
   if (word && translation)
      {
      Dictionary *dict = DcActiveDictionary() ;
      if (!dict && default_dictionary &&
	  DcInitializeDictionary(default_dictionary))
	 dict = DcActiveDictionary() ;
      bool status = false ;
      if (dict)
	 {
	 FrString *wrd = new FrString(word) ;
	 FrObject *xlat = FrCvtWordlist2Symbollist(translation,char_encoding) ;
	 status = dict->addDefinition(FrCvt2Symbol(wrd,char_encoding),
				      xlat,count,count) ;
	 free_object(xlat) ;
	 free_object(wrd) ;
	 }
      return status ;
      }
   else
      {
      err << "Missing parameter -- must specify both source and translation"
	  << endl ;
      return false ;
      }
}

//----------------------------------------------------------------------

static void process_dict_command(EBMTCorpus *, istream &in, ostream &out)
{
   if (DcActiveDictionary())
      {
      if ((!DcActiveDictionary() &&
	   !DcInitializeDictionary(default_dictionary)) ||
	  !active_EBMT())
	 {
	 out << "No dictionary available" << endl ;
	 return ;
	 }
      FrObject *obj ;
      in >> obj ;
      if (obj == makeSymbol("?"))
	 out << "Usage: DICT \"sentence\" or DICT (\"word1\" \"word2\" ...)"
	     << endl ;
      else if (!obj)
	 out << "NIL" << endl ;
      else if (obj->consp() || obj->stringp())
	 {
	 FrTextSpans *lattice = EbMakeLattice(obj,morph_classes,
					      morph_global_info) ;
	 FrList *translations = DcActiveDictionary()->lookup(lattice) ;
	 out << translations << endl ;
	 free_object(translations) ;
	 EbFreeLattice(lattice) ;
	 }
      else
	 out << error_bang << endl ;
      free_object(obj) ;
      }
   else
      out << "\"No active dictionary\"" << endl ;
   return ;
}

//----------------------------------------------------------------------

static void process_wfw(EBMTCorpus *corpus, istream &in, ostream &out)
{
   FrObject *wfw_list ;
   in >> wfw_list ;
   if (!wfw_list || wfw_list->consp())
      {
      for (FrList *wfw = (FrList*)wfw_list ; wfw ; wfw = wfw->rest())
	 {
	 FrList *trans = (FrList*)wfw->first() ;
	 if (trans && trans->consp() && !trans->first()->consp())
	    corpus->addTranslations(trans->first(),trans->rest(),true) ;
	 }
      out << str_Ok << endl ;
      }
   else if (wfw_list == makeSymbol("?"))
      out << "Usage: WFW (....)" << endl ;
   else
      out << str_Error << endl ;
   if (wfw_list)
      wfw_list->freeObject() ;
   return ;
}

//----------------------------------------------------------------------

static void process_wfwc(EBMTCorpus *corpus, istream &in, ostream &out)
{
   FrObject *wfw_list ;
   in >> wfw_list ;
   if (!wfw_list || wfw_list->consp())
      {
      for (FrList *wfw = (FrList*)wfw_list ; wfw ; wfw = wfw->rest())
	 {
	 FrList *trans = (FrList*)wfw->first() ;
	 if (trans && trans->consp() && !trans->first()->consp())
	    {
	    corpus->addTranslationsCounted(trans->first(),trans->rest(),
					   true) ;
	    if (verbose)
	       cout << "added " << trans->first() << endl ;
	    }
	 }
      out << str_Ok << endl ;
      }
   else if (wfw_list == makeSymbol("?"))
      out << "Usage: WFWC (....)" << endl ;
   else
      out << str_Error << endl ;
   if (wfw_list)
      wfw_list->freeObject() ;
   return ;
}

//----------------------------------------------------------------------

static void process_addwfw(EBMTCorpus *corpus, istream &in, ostream &out)
{
   FrObject *wfw_list ;
   in >> wfw_list ;
   if (!wfw_list || wfw_list->consp())
      {
      for (FrList *wfw = (FrList*)wfw_list ; wfw ; wfw = wfw->rest())
	 {
	 FrList *trans = (FrList*)wfw->first() ;
	 if (trans && trans->consp() && !trans->first()->consp())
	    corpus->addTranslations(trans->first(),trans->rest()) ;
	 }
      out << str_Ok << endl ;
      }
   else if (wfw_list == makeSymbol("?"))
      out << "Usage: ADDWFW (....)" << endl ;
   else
      out << str_Error << endl ;
   if (wfw_list)
      wfw_list->freeObject() ;
   return ;
}

//----------------------------------------------------------------------

static void process_addwfwc(EBMTCorpus *corpus, istream &in, ostream &out)
{
   FrObject *wfw_list ;
   in >> wfw_list ;
   if (!wfw_list || wfw_list->consp())
      {
      for (FrList *wfw = (FrList*)wfw_list ; wfw ; wfw = wfw->rest())
	 {
	 FrList *trans = (FrList*)wfw->first() ;
	 if (trans && trans->consp() && !trans->first()->consp())
	    corpus->addTranslationsCounted(trans->first(),trans->rest()) ;
	 }
      out << str_Ok << endl ;
      }
   else if (wfw_list == makeSymbol("?"))
      out << "Usage: ADDWFWC (....)" << endl ;
   else
      out << str_Error << endl ;
   if (wfw_list)
      wfw_list->freeObject() ;
   return ;
}

//----------------------------------------------------------------------

static void process_root_command(EBMTCorpus *corpus, istream &in, ostream &out)
{
   FrObject *root_list ;
   in >> root_list ;
   if (!root_list || root_list->consp())
      {
      for (FrList *root = (FrList*)root_list ; root ; root = root->rest())
	 {
	 FrList *r = (FrList*)root->first() ;
	 if (r && r->consp())
	    {
	    //!!! add the root to the roots file
	    (void)corpus ;
	    }
	 }
      out << str_Ok << endl ;
      }
   else if (root_list == makeSymbol("?"))
      out << "Usage: ROOT (\"word1\" \"word2\" ...)" << endl ;
   else
      out << str_Error << endl ;
   if (root_list)
      root_list->freeObject() ;
   return ;
}

//----------------------------------------------------------------------

static void process_example_command(EBMTCorpus *corpus, istream &in,
				    ostream &out)
{
   FrObject *example_list ;
   in >> example_list ;
   if (!example_list)
      out << str_Ok << endl ;
   else if (example_list->consp())
      {
      FrObject *head = example_list->car() ;
      if (head && !head->consp())
	 example_list = new FrList(example_list) ;
      corpus->getIndex()->addPairs((FrList*)example_list,true) ;
      out << str_Ok << endl ;
      }
   else if (example_list == makeSymbol("?"))
      {
      out << "Usage: EXAMPLE ((\"source\" \"target\") ...)" << endl ;
      }
   else
      out << str_Error << endl ;
   if (example_list)
      example_list->freeObject() ;
   return ;
}

//----------------------------------------------------------------------

static void process_genre_command(EBMTCorpus *corpus,istream &in,ostream &out)
{
   FrObject *genreID ;
   in >> genreID ;
   bool success = false ;
   if (genreID && genreID->printableName())
      success = corpus->selectGenre(genreID->printableName()) ;
   if (success)
      out << "Genre selected" << endl ;
   else
      {
      // we need to make sure that the echoed ID is all on one line, so
      //   convert it to a string first
      char *genre = genreID->print() ;
      out << "Unable to select genre " << genre << endl ;
      FrFree(genre) ;
      }
   return ;
}

//----------------------------------------------------------------------

static void process_meta_command(EBMTCorpus * /*corpus*/, istream &in,
				 ostream &out)
{
   FrObject *keyobj ;
   in >> keyobj ;
   if (keyobj == makeSymbol("?"))
      {
      out << "Usage: META key value" << endl ;
      if (pending_metadata)
	 out << "Currently stored: " << pending_metadata << endl ;
      else
	 out << "No stored metadata" << endl ;
      return;
      }
   FrObject *value ;
   in >> value ;
   FrSymbol *key = (keyobj && keyobj->symbolp()) ? (FrSymbol*)keyobj : 0 ;
   if (key != makeSymbol("*EOF*") && value)
      {
      if (!pending_metadata)
	 pending_metadata = new FrStruct(makeSymbol("METADATA")) ;
      if (pending_metadata)
	 {
	 pending_metadata->put(key,value) ;
	 out << "; Metadata stored" << endl ;
	 }
      else
	 out << "; problem storing metadata" << endl ;
      }
   else
      out << "must supply both a key and a value to META" <<endl ;
   free_object(key) ;
   free_object(value) ;
   return ;
}

//----------------------------------------------------------------------

static void process_genres_command(EBMTCorpus *,istream &,ostream &out)
{
   out << "Available Genres: " ;
   for (EbGenreSettings *g = ebmt_vars.genre_list ; g ; g = g->next())
      {
      out << ' ' ;
      if (!g->name())
	 out << '*' ;
      else
	 out << g->name() ;
      }
   out << endl ;
   return ;
}

//----------------------------------------------------------------------

static void process_pack_command(EBMTCorpus *corpus, istream &, ostream &out)
{
   EBMTIndex *index = corpus ? corpus->getIndex() : 0 ;
   if (index)
      {
      if (index->pack(&out))
	 out << "\nOk" << endl ;
      else
	 out << "\nError!" << endl ;
      }
   else
      out << "Error!" << endl ;
   return ;
}

//----------------------------------------------------------------------

static void process_prepdoc_command(EBMTCorpus *, istream &, ostream &out)
{
   if (EbPrepareDocument(true))
      out << "\nOk" << endl ;
   else
      out << "\nError \"Already preparing document\"" << endl ;
   return ;
}

//----------------------------------------------------------------------

static void process_endprep_command(EBMTCorpus *, istream &, ostream &out)
{
   if (EbPrepareDocument(false))
      out << "\nOk" << endl ;
   else
      out << "\nError \"Not preparing document\"" << endl ;
   return ;
}

//----------------------------------------------------------------------

static void process_terse_command(EBMTCorpus *, istream &, ostream &out)
{
   terse_output = !terse_output ;
   if (terse_output)
      out << ": Default output will be in Terse format" << endl ;
   else
      out << ": Default output will be in Full format" << endl ;
   return ;
}

//----------------------------------------------------------------------

static void process_listparms_command(istream &, ostream &out)
{
   const EBMTConfig *config = get_EBMT_config() ;
   if (!config)
      out << "Unable to list parameters -- no configuration loaded" << endl ;
   else
      {
      FrList *params = config->listParameters() ;
      out << params << endl << endl ;;
      free_object(params) ;
      }
   return ;
}

//----------------------------------------------------------------------

static void process_describe_command(istream &in, ostream &out)
{
   EBMTConfig *config = get_EBMT_config() ;
   if (!config)
      {
      out << "Unable to describe parameters -- no configuration loaded"
	  << endl ;
      return ;
      }
   FrObject *obj ;
   in >> obj ;
   if (obj && obj != makeSymbol("?") && obj->printableName())
      {
      const char *param = obj->printableName() ;
      FrList *description =  config->describeParameter(param) ;
      out << description << endl << endl ;
      free_object(description) ;
      }
   else
      out << "Usage: DESCRIBE \"parameter\"\n" << endl ;
   return ;
}

//----------------------------------------------------------------------

static void process_show_command(istream &in, ostream &out)
{
   EBMTConfig *config = get_EBMT_config() ;
   if (!config)
      {
      out << "Unable to show parameters -- no configuration loaded\n"
	  << endl ;
      return ;
      }
   FrObject *obj ;
   in >> obj ;
   if (obj && obj != makeSymbol("?") && obj->printableName())
      {
      char *value = config->currentValue(obj->printableName()) ;
      if (value)
	 out << "( " << obj->printableName() << " = " << value << " )\n"
	     << endl;
      else
	 out << "( unknown parameter )\n" << endl ;
      FrFree(value) ;
      }
   else
      out << "Usage: SHOW \"parameter\"\n" << endl ;
   return ;
}

//----------------------------------------------------------------------

static void process_set_command(istream &in, ostream &out)
{
   EBMTConfig *config = get_EBMT_config() ;
   if (!config)
      {
      out << "Unable to show parameters -- no configuration loaded"
	  << endl ;
      return ;
      }
   FrObject *obj ;
   in >> obj ;
   if (obj && obj != makeSymbol("?") && obj->printableName())
      {
      const char *param_name = obj->printableName() ;
      FrObject *obj2 ;
      in >> obj2 ;
      if (obj2 && obj2->printableName())
	 {
	 if (config->setParameter(param_name,obj2->printableName(),&out))
	    {
	    char *value = config->currentValue(param_name) ;
	    out << "( " << param_name << " <= " << value << " )" << endl  ;
	    FrFree(value) ;
	    }
	 else
	    out << "( error )" << endl ;
	 return ;
	 }
      }
   out << "Usage: SET \"parameter\" \"new-value\"\n" << endl ;
   return ;
}

//----------------------------------------------------------------------

static void process_help_command(istream &, ostream &out)
{
   out << "Type COMMANDS to list the available commands or PARAMS to list\n"
       << "the available program settings.  Most commands accept a question\n"
       << "mark as an option to list their usage summary.\n"
       << endl ;
   return ;
}

/************************************************************************/
/************************************************************************/

static General_Command general_commands[] =
   {
     { "DESCRIBE",	process_describe_command },
     { "HELP",	  	process_help_command },
     { "LISTPARAMS", 	process_listparms_command },
     { "LISTPARMS", 	process_listparms_command },
     { "PARAMS",  	process_listparms_command },
     { "SET",     	process_set_command },
     { "SHOW",     	process_show_command },
     { "?",	  	process_help_command },
     { 0,		0 }
   } ;

static EBMT_Command special_options[] =
   {
     { "ADDWFW",  	process_addwfw },
     { "ADDWFWC", 	process_addwfwc },
     { "ALIGNPHRASE",	process_alignphrase_command },
     { "CHUNKS",  	process_chunks_command },
     { "COMMANDS",	process_EBMT_help },
     { "CONTEXT",	process_context_command },
     { "DICT",	  	process_dict_command },
     { "DICTC",	  	process_dict_command }, // backward compat, of sorts
     { "ENDPREP",	process_endprep_command },
     { "EXAMPLE", 	process_example_command },
     { "GENRE",		process_genre_command },
     { "GENRES",	process_genres_command },
     { "META",		process_meta_command },
     { "PACK",    	process_pack_command },
     { "PREPDOC",	process_prepdoc_command },
     { "ROOT",	  	process_root_command },
     { "SETCORPUS", 	process_setcorpus_command },
     { "SETDICT", 	process_setdict_command },
     { "SRC",	  	process_src_command },
     { "TERSE",   	process_terse_command },
     { "WFW",	  	process_wfw },
     { "WFWC",	  	process_wfwc },
     { 0,	  	0 }
   } ;

//----------------------------------------------------------------------

static void word_wrap(ostream &out, size_t &pos, const char *word)
{
   if (word && (&out == &cout || &out == &cerr))
      {
      size_t len = strlen(word) + 1 ;
      pos += len ;
      if (pos > 75)
	 {
	 out << endl ;
	 pos = len ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

static void process_EBMT_help(EBMTCorpus *, istream &, ostream &out)
{
   out << "The valid commands in EBMT mode are:\n" ;
   size_t i ;
   size_t pos = 0 ;
   for (i = 0 ; general_commands[i].name ; i++)
      {
      word_wrap(out,pos,general_commands[i].name) ;
      out << ' ' << general_commands[i].name ;
      }
   for (i = 0 ; special_options[i].name ; i++)
      {
      word_wrap(out,pos,special_options[i].name) ;
      out << ' ' << special_options[i].name ;
      }
   out << endl << endl ;
   return ;
}

//----------------------------------------------------------------------

static bool process_general_command(FrSymbol *option, istream &in,
				      ostream &out)
{
   for (General_Command *cmd = general_commands ; cmd->name ; cmd++)
      {
      if (*option == cmd->name)
	 {
	 if (cmd->func)
	    cmd->func(in,out) ;
	 return true ;
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

static bool process_ebmt_command(FrSymbol *option, EBMTCorpus *corpus,
				   istream &in, ostream &out)
{
   for (EBMT_Command *cmd = special_options ; cmd->name ; cmd++)
      {
      if (*option == cmd->name)
	 {
	 if (!corpus)
	    out << "\"EBMT commands not available\"" << endl ;
	 else if (cmd->func)
	    {
	    FrSymbolTable *sym_t = active_EBMT()->symbolTable()->select() ;
	    cmd->func(corpus,in,out) ;
	    sym_t->select() ;
	    }
	 return true ;
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

void EbProcessSpecialOption(FrSymbol *option, EBMTCorpus *corpus,
			    istream &in, ostream &out)
{
   if (process_general_command(option,in,out))
      return ;
   if (process_ebmt_command(option,corpus,in,out))
      return ;
   if (network_server_mode && option == findSymbol(":SHUTDOWN"))
      {
      if (active_server)
	 active_server->requestShutdown() ;
      out << "\"EBMT server is shutting down\"" << endl ;
      cout << "; shutdown was requested" << endl ;
      }
   else if (option != makeSymbol("*EOF*"))
      out << "\"Unknown option " << option << '\"' << endl ;
   return ;
}

//----------------------------------------------------------------------

void EbRunNetworkServer(EBMT *ebmt,int port_number)
{
   EBMTServer *server = new EBMTServer(ebmt,port_number) ;
   if (server && server->good())
      {
      active_server = server ;
      FrMinimizeWindow() ;
      do {
	 // keep looping every time that the wait for a new connection times
	 // out
	 } while (!server->run()) ;
      active_server = 0 ;
      }
   else
      {
      cerr << "; Unable to start server on port " << port_number << "!"
	   << endl ;
      }
   delete server ;
   return ;
}

//----------------------------------------------------------------------

static void translate_sentence(FrString *sent, ostream &out)
{
   int orig_max_alt = EBMT_max_alternatives(1) ;
   FrTextSpans *lattice = EbMakeLattice(sent,morph_classes,
					morph_global_info) ;
   EBMTCandidate *chunks = process_sentence_EBMT(lattice) ;
   if (chunks)
      {
      chunks = chunks->sortByChunkPosition() ;
      if ((EbTerseOutput() || omit_subsumed) && chunks)
	 chunks = remove_subsumed_chunks(chunks) ;
      chunks = chunks->sortByScore() ;
      output_translations(chunks,out,sent) ;
      chunks->deleteList() ;
      out << cmt_ready_bang << endl ;
      }
   else
      out << "; No matches found" << endl ;
   EbFreeLattice(lattice) ;
   EBMTCandidate::zapAll() ;		// no more objs in use, make mem avail
   sentences_processed++ ;
   EBMT_max_alternatives(orig_max_alt) ;
   if (verbose && showmem)
      FrMemoryStats(out) ;
   return ;
}

//----------------------------------------------------------------------

int perform_EBMT_operation(FrObject *object, ostream &out, istream &in)
{
   FrObject *obj ;
   if (object)
      obj = object ;
   else
      in >> obj ;
   if (!obj)
      return true ;
   if (network_server_mode)
      cout << "-> " << obj << endl ;
   if (obj->consp())
      {
      FrString *sentence = new FrString((FrList*)obj) ;
      // the above ensures that the preprocessing regexes are applied
      EbProcessSentence(sentence,out) ;
      free_object(sentence) ;
      }
   else if (obj->symbolp())
      {
      FrSymbol *symbolEOF = makeSymbol(str_EOF) ;
      if (obj != symbolEOF)
	 {
	 EBMTCorpus *corp = active_corpus ;
	 if (!corp && active_EBMT()) corp = active_EBMT()->getCorpus() ;
	 EbProcessSpecialOption((FrSymbol*)obj,corp,in,out) ;
	 }
      else
	 return false ;
      }
   else if (obj->stringp())
      translate_sentence((FrString*)obj,out) ;
   else
      out << str_emptylist << endl ; // give *something* back to caller
   if (!object)
      obj->freeObject() ;
   return true ;
}

//----------------------------------------------------------------------

static bool make_location_map(EBMT *ebmt, uint32_t *&loc_map,
				size_t &map_size, size_t *&cum_counts,
				size_t &count_size)
{
   EBMTCorpus *corpus = ebmt->getCorpus() ;
   EBMTIndex *index = corpus->getIndex() ;
   count_size = index->numSentencePairs() ;
   EbBWTIndex *idx = index->selectIndex(EbIndex_Main) ;
   if (!idx || (!idx->haveIndexLocations() &&
		!idx->setIndexLocations(count_size)))
      return false ;
   cum_counts = FrNewC(size_t,count_size+1) ;
   if (cum_counts)
      {
      size_t total = 0 ;
      for (size_t i = 0 ; i < count_size ; i++)
	 {
	 cum_counts[i] = total ;
	 const EbExampleInfo *info = index->info(i) ;
	 if (info)
	    total += info->length() ;
	 }
      cum_counts[count_size] = total ;
      map_size = idx->totalItems() ;
      loc_map = FrNewC(uint32_t,map_size) ;
      if (loc_map)
	 {
	 size_t pos = 0 ;
	 for (size_t i = 0 ; i < count_size ; i++)
	    {
	    uint32_t loc = idx->indexLocation(i) ;
	    while (loc < map_size && !idx->isEOR(loc))
	       {
	       loc_map[loc] = pos++ ;
	       loc = idx->getSuccessor(loc) ;
	       }
	    }
	 return true ;
	 }
      else
	 {
	 FrFree(cum_counts) ;
	 cum_counts = 0 ;
	 map_size = 0 ;
	 count_size = 0 ;
	 }
      }
   else
      {
      loc_map = 0 ;
      map_size = 0 ;
      }
   return false ;
}

//----------------------------------------------------------------------

#define MAX_SENT_LEN 255

typedef size_t count_matrix[(MAX_SENT_LEN+1)*(MAX_SENT_LEN+1)] ;

#define COUNT(i,j) (counts[i*(MAX_SENT_LEN+1)+j])

static void accumulate_counts(const FrBitVector &coverage,
			      const size_t *cum_counts,
			      size_t count_size,
			      count_matrix &counts)
{
   // accumulate the raw counts into histograms split by sentence length
   for (size_t line = 0 ; line < count_size ; line++)
      {
      size_t len = cum_counts[line+1] - cum_counts[line] ;
      if (len > MAX_SENT_LEN)
	 len = MAX_SENT_LEN ;
      size_t count = 0 ;
      for (size_t elt = cum_counts[line] ; elt < cum_counts[line+1] ; elt++)
	 {
	 if (coverage.getBit(elt))
	    count++ ;
	 }
      if (count > MAX_SENT_LEN)
	 count = MAX_SENT_LEN ;
      COUNT(len,count)++ ;
      }
   return ;
}

//----------------------------------------------------------------------

static void update_global_match_stats(EbCorpusMatches *matches,
				      const uint32_t *loc_map, size_t map_size,
				      size_t *cum_counts, size_t count_size,
				      FrBitVector &coverage,
				      count_matrix &counts)
{
   coverage.clear() ;
   size_t num_entries = cum_counts[count_size] ;
   while (matches)
      {
      EbCorpusMatches *next = matches->next() ;
      FrBWTLocationList *ranges = matches->matches() ;
      size_t matchlen = matches->matchLength() ;
      if (ranges)
	 {
	 for (size_t r = 0 ; r < ranges->numRanges() ; r++)
	    {
	    FrBWTLocation range = ranges->range(r) ;
	    for (size_t pos = range.first() ;
		 pos < range.pastEnd() ;
		 pos++)
	       {
	       if (pos < map_size)
		  {
		  uint32_t loc = loc_map[pos] ;
		  if (loc < num_entries)
		     {
		     for (size_t l = loc ; l < loc + matchlen ; l++)
			coverage.setBit(l) ;
		     }
		  }
	       }
	    }
	 }
      delete matches ;
      matches = next ;
      }
   accumulate_counts(coverage,cum_counts,count_size,counts) ;
   return ;
}

//----------------------------------------------------------------------

static size_t highest_nonzero(const size_t *counts, size_t highest_count)
{
   for (size_t i = highest_count ; i > 0 ; i--)
      {
      if (counts[i] != 0)
	 return i ;
      }
   return 0 ;
}

//----------------------------------------------------------------------

static void print_histogram_line(ostream &out, size_t index, size_t count,
				 size_t total)
{
   out << setw(4) << index << ' ' << setw(10) << count << '\t' ;
   size_t bar = (size_t)(60.0 * count / total + 0.5) ;
   bool extra = false ;
   if (bar > 60)
      {
      extra = true ;
      bar = 60 ;
      }
   if (bar == 0 && count > 0)
      out << '.' ;
   else
      {
      for (size_t i = 0 ; i < bar ; i++)
	 out << '*' ;
      }
   if (extra)
      out << '>' ;
   out << endl ;
   return ;
}

//----------------------------------------------------------------------

static void show_coverage(const count_matrix counts,
			  size_t first, size_t last)
{
   size_t max = 0 ;
   size_t total = 0 ;
   bool nonempty = false ;
   if (last > MAX_SENT_LEN)
      last = MAX_SENT_LEN ;
   for (size_t j = 0 ; j <= last ; j++)
      {
      size_t c = 0 ;
      for (size_t k = first ; k <= last ; k++)
	 c += COUNT(k,j) ;
      total += c ;
      if (c > max)
	 max = c ;
      if (j > 0 && c > 0)
	 nonempty = true ;
      }
   (void)max ; (void)total ;
   if (nonempty)
      {
      cout << "Coverage of sentences with length " << first ;
      if (last > first)
	 cout << " to " << last ;
      cout << endl ;
      for (size_t j = 0 ;
	   j <= highest_nonzero(&counts[first*(MAX_SENT_LEN+1)],last) ;
	   j++)
	 {
	 size_t c = 0 ;
	 for (size_t k = first ; k <= last ; k++)
	    c += COUNT(k,j) ;
	 print_histogram_line(cout,j,c,total) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

static void show_global_match_stats(count_matrix &counts)
{
   // compute and print the average coverage of each sentence length
   cout << "Average cover by sentence length:" << endl ;
   for (size_t i = 0 ; i <= MAX_SENT_LEN ; i++)
      {
      size_t total = 0 ;
      size_t max = 0 ;
      size_t sum = 0 ;
      for (size_t j = 0 ; j <= i ; j++)
	 {
	 size_t c = COUNT(i,j) ;
	 sum += j * c ;
	 total += c ;
	 if (c > 0 && j > max)
	    max = j ; 
	 }
      if (total > 0)
	 {
	 double avg = sum / (double)total ;
	 if (i < MAX_SENT_LEN)
	    cout << setw(5) << i << "  " ;
	 else
	    cout << setw(5) << i << "+ " ;
	 cout << setprecision(7) << avg << " \t"
	      << (100.0 * avg / i) << "%" 
	      << "\tmax " << max << " (among " << total << " instances)"
	      << endl ;
	 }
      }
   cout << endl ;
   // now output the histograms, doing some binning in order to avoid huge
   //   amounts of hard-to-interpret output
#define STEP_SIZE 10
   // start with raw counts for very short sentences
   for (size_t i = 1 ; i < STEP_SIZE ; i++)
      show_coverage(counts,i,i) ;
   for (size_t i = STEP_SIZE ; i <= MAX_SENT_LEN ; i += STEP_SIZE)
      show_coverage(counts,i,i+STEP_SIZE-1) ;
   return ; 
}

//----------------------------------------------------------------------

int compute_global_match_stats(EBMT *ebmt, istream &in, ostream &out)
{
   if (ebmt && ebmt->OK())
      {
      // prepare for statistics collection by figuring out which example
      //   each word in the corpus belongs to and allocating space for
      //   all the counts we will be keeping
      out << "Preparing...." << endl ;
      uint32_t *loc_map ;
      size_t *cum_counts ;
      size_t map_size ;
      size_t count_size ;
      if (!make_location_map(ebmt,loc_map,map_size,cum_counts,count_size))
	 return EXIT_FAILURE ;
      FrBitVector coverage(cum_counts[count_size]) ;
      active_corpus = ebmt->getCorpus() ;
      out << ready_bang << endl ;
      bool warned = false ;
      count_matrix counts ;
      for (size_t i = 0 ; i < lengthof(counts) ; i++)
	 counts[i] = 0 ;
      while (!in.eof())
	 {
	 FrObject *sent ;
	 in >> sent ;
	 if (sent && (sent->stringp() || sent->consp()))
	    {
	    FrTextSpans *lattice = EbMakeLattice(sent,morph_classes,
						 morph_global_info) ;
	    ebmt->selectFirstCorpus() ;
	    EbCorpusMatches *matches
	       = find_recursive_matches(0,lattice,ebmt->getCorpus(),tm_mode) ;
	    EbFreeLattice(lattice) ;
	    update_global_match_stats(matches,loc_map,map_size,cum_counts,
				      count_size,coverage,counts) ;
	    }
	 else if (sent == makeSymbol("*EOF*"))
	    break ;
	 else if (sent != makeSymbol("CHUNKS") && !warned)
	    {
	    out << ";; commands are not processed in compute-statistics mode"
		<< endl ;
	    warned = true ;
	    }
	 }
      FrFree(loc_map) ;
      if (verbose)
	 out << "; " << EbSentencesProcessed() << " sentences processed" ;
      // print out the overall statistics
      show_global_match_stats(counts) ;
      FrFree(cum_counts) ;
      out << endl ;
      active_corpus = 0 ;
      shutdown__EBMT() ;
      out << done_bang ;
      return EXIT_SUCCESS ;
      }
   else
      {
      out << "Error opening corpus!" << endl ;
      shutdown__EBMT() ;
      EbNetworkServerMode(false) ;
      return EXIT_FAILURE ;
      }
}

//----------------------------------------------------------------------

void EbSetArgv0(const char *a)
{
   argv0 = a ;
   return ;
}

//----------------------------------------------------------------------

void EbNetworkServerMode(bool net)
{
   network_server_mode = net ;
   return ;
}

//----------------------------------------------------------------------

bool EbTerseOutput()
{
   return terse_output ;
}

//----------------------------------------------------------------------

bool EbTerseOutput(bool terse)
{
   bool old_terse = terse_output ;
   terse_output = terse ;
   return old_terse ;
}

//----------------------------------------------------------------------

int EbSentencesProcessed()
{
   return sentences_processed ;
}

//----------------------------------------------------------------------

bool EbNetworkServerMode()
{
   return network_server_mode ;
}

//----------------------------------------------------------------------

void EbSetConfigFilename(const char *cfg)
{
   config_filename = cfg ;
   return ;
}

//----------------------------------------------------------------------

EBMTCorpus *EbActiveCorpus()
{
   return active_corpus ;
}

//----------------------------------------------------------------------

void EbSetActiveCorpus(EBMTCorpus *corpus)
{
   active_corpus = corpus ;
}

//----------------------------------------------------------------------

void EbDeleteActiveCorpus()
{
   delete active_corpus ;
   active_corpus = 0 ;
   return ;
}

// end of file ebcmd.cpp //
