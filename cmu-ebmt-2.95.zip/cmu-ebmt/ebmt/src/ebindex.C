/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebindex.cpp	EBMT corpus index				*/
/*  LastEdit: 19apr10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#if defined(__GNUC__)
#  pragma implementation "ebindex.h"
#endif

#include <fcntl.h>
#include "frlowio.h"		// needed under WatcomC++
#include "ebindex.h"
#include "ebsent.h"
#include "ebtoken.h"
#include "ebutil.h"
#include "ebmt.h"   // for monolingual_data and reverse_languages
#include "ebglobal.h"

/************************************************************************/
/*    Manifest Constants						*/
/************************************************************************/

#define NULL_TRANS_MARKER "<notrans>"

// we need a fairly large granularity to keep down the number of reallocations
//   so that we don't run into memory fragmentation issues when indexing tens
//   of millions of short training instances (e.g. phrase tables)
#define INFO_ALLOC_GRANULARITY (LINES_PER_SUBFILE*3)

#ifndef O_BINARY
// for unix-like systems that don't distinguish between text and binary
//   files
#  define O_BINARY 0
#endif /* O_BINARY */

// set up a special start-of-record marker for use in finding complete matches
//   since we'll never actually output this marker, it can and should be a
//   string which will never occur as a word in our training or input text
#define SOR_TOKEN "\n\n"

// definitions for how the record number and offset within the record are
//   packed into the location information for a source word
#define LOCINFO_RECNUM_MASK 0x01FFFFFF
#define LOCINFO_OFS_MASK    0xFE000000
#define LOCINFO_OFS_SHIFT	25
#define LOCINFO_MAX_RECNUM  LOCINFO_RECNUM_MASK
#define LOCINFO_MAX_OFFSET  (LOCINFO_OFS_MASK >> LOCINFO_OFS_SHIFT)


/************************************************************************/
/*    types local to this module					*/
/************************************************************************/

/************************************************************************/
/*    Forward Declarations						*/
/************************************************************************/

/************************************************************************/
/*    Global data							*/
/************************************************************************/

static const char index_info_signature[] = INDEX_INFO_SIGNATURE ;

static const char index_svocab_name[] = INDEX_SVOCAB_NAME ;
static const char index_tvocab_name[] = INDEX_TVOCAB_NAME ;
static const char index_info_name[] = INDEX_INFO_NAME ;
static const char index_locations_name[] = INDEX_LOCATIONS_NAME ;
static const char index_file_name[] = INDEX_FILE_NAME ;
static const char index_tagged_name[] = INDEX_TAGGED_NAME ;
static const char index_updates_name[] = INDEX_UPDATES_NAME ;
static const char index_struct_name[] = INDEX_STRUCT_NAME ;
static const char token_file_name[] = TOKEN_FILE_NAME ;
static const char origins_file_name[] = ORIGINS_FILE_NAME ;
static const char overrides_file_name[] = OVERRIDES_FILE_NAME ;

static const char text_read_mode[] = "r" ;

static const char corpus_filename_template[] = "%s/corpus.%03d" ;

static size_t skipped_due_to_length = 0 ;
static size_t skipped_due_to_ratio = 0 ;

/************************************************************************/
/*    Helper functions							*/
/************************************************************************/

static void warn_with_s_t(const char *fmt, const FrObject *src,
			  const FrObject *trg, const FrObject *tag = 0)
{
   char *s = src->print() ;
   char *t = trg->print() ;
   char *tg = tag->print() ;
   FrWarningVA(fmt,s,t,tg) ;
   FrFree(s) ;
   FrFree(t) ;
   FrFree(tg) ;
   return ;
}

//----------------------------------------------------------------------

static void warn_with_s_t(const char *fmt, int value, const FrObject *src,
			  const FrObject *trg, const FrObject *tag = 0)
{
   char *s = src->print() ;
   char *t = trg->print() ;
   char *tg = tag->print() ;
   FrWarningVA(fmt,value,s,t,tg) ;
   FrFree(s) ;
   FrFree(t) ;
   FrFree(tg) ;
   return ;
}

//----------------------------------------------------------------------

static void warn_with_s_t(const char *fmt, size_t sentpair,
			  int value, const FrObject *src,
			  const FrObject *trg, const FrObject *tag = 0)
{
   char *s = src->print() ;
   char *t = trg->print() ;
   char *tg = tag->print() ;
   FrWarningVA(fmt,sentpair,value,s,t,tg) ;
   FrFree(s) ;
   FrFree(t) ;
   FrFree(tg) ;
   return ;
}

//----------------------------------------------------------------------

static void warn_string(const char *fmt, const char *str, size_t maxlen)
{
   if (!str) str = "" ;
   if (maxlen < 4) maxlen = 4 ;
   size_t len = strlen(str) ;
   if (len > maxlen)
      {
      FrLocalAlloc(char,str2,1024,maxlen+1) ;
      if (str2)
	 {
	 memcpy(str2,str,maxlen-3) ;
	 strcpy(str2+maxlen-3,"...") ;
	 FrWarningVA(fmt,str2) ;
	 FrLocalFree(str2) ;
	 return ;
	 }
      }
   FrWarningVA(fmt,str) ;
   return ;
}

//----------------------------------------------------------------------

static bool clear_origin_weight(FrHashEntry *entry, va_list)
{
   const FrObject *name = ((FrHashEntryObject*)entry)->getObject() ;
   const char *namestr = FrPrintableName(name) ;
   if (namestr && !*namestr)
      {
      FrList *wt = (FrList*)((FrHashEntryObject*)entry)->getUserData() ;
      if (wt)
	 wt->freeObject() ;
      }
   ((FrHashEntryObject*)entry)->setUserData(0) ;
   return true ;			// continue iterating
}

//----------------------------------------------------------------------

void store_location(char *locations, size_t loc,
		    size_t recnum, size_t offset)
{
   if (offset > LOCINFO_MAX_OFFSET)
      offset = LOCINFO_MAX_OFFSET ;
   if (recnum > LOCINFO_MAX_RECNUM)
      recnum = LOCINFO_MAX_RECNUM ;
   uint32_t locinfo = (offset << LOCINFO_OFS_SHIFT) & LOCINFO_OFS_MASK ;
   locinfo |= (recnum & LOCINFO_RECNUM_MASK) ;
   FrStoreLong(locinfo,locations + (loc * sizeof(LONGbuffer))) ;
   return ;
}

//----------------------------------------------------------------------

static void get_location(const char *locations, size_t loc,
			 size_t &recnum, size_t &offset)
{
   uint32_t locinfo = FrLoadLong(locations + loc * sizeof(LONGbuffer)) ;
   recnum = (locinfo & LOCINFO_RECNUM_MASK) ;
   offset = (locinfo & LOCINFO_OFS_MASK) >> LOCINFO_OFS_SHIFT ;
   return ;
}

/************************************************************************/
/************************************************************************/

static FrSymHashTable *sword_tab = 0 ;
static FrSymHashTable *tword_tab = 0 ;
static FrVocabulary *tword_vocab = 0 ;
static size_t word_count = 0 ;
static bool vocab_continued = false ;

//----------------------------------------------------------------------

size_t EbCvtSrcWord2WordID(const char *word)
{
   if (word && sword_tab)
      {
      FrSymbol *wordsym ;
      if (ignore_source_case || *word == EbTOKEN_START)
	 {
	 char *word2 = EbStripCoindex(word,char_encoding) ;
	 if (!word2)
	    return FrVOCAB_WORD_NOT_FOUND ;
	 wordsym = FrSymbolTable::add(word2) ;
	 FrFree(word2) ;
	 }
      else
	 wordsym = FrSymbolTable::add(word) ;
      FrSymHashEntry *entry = sword_tab->lookup(wordsym) ;
      if (entry)
	 return entry->getCount() ;
      else
	 {
	 size_t id = word_count++ ;
	 sword_tab->add(wordsym,id) ;
	 return id ;
	 }
      }
   return FrVOCAB_WORD_NOT_FOUND ;
}

//----------------------------------------------------------------------

static size_t EbCvtTrgWord2WordID(const char *word)
{
   if (word && tword_tab)
      {
      FrSymbol *wordsym ;
      if (*word == EbTOKEN_START)
	 {
	 char *word2 = EbStripCoindex(word,char_encoding) ;
	 wordsym = FrSymbolTable::add(word2) ;
	 FrFree(word2) ;
	 }
      else
	 wordsym = FrSymbolTable::add(word) ;
      FrSymHashEntry *entry = tword_tab->lookup(wordsym) ;
      if (entry)
	 return entry->getCount() ;
      size_t id = tword_vocab->addWord(wordsym->symbolName(),
				       tword_vocab->numWords()) ;
      if (id != FrVOCAB_WORD_NOT_FOUND)
	 tword_tab->add(wordsym,id) ;
      return id ;
      }
   return FrVOCAB_WORD_NOT_FOUND ;
}

//----------------------------------------------------------------------

bool EbBeginText2WordIDs(FrVocabulary *seedvocab, bool target_lang = false)
{
   if (vocab_continued)
      return true ;
   if (target_lang)
      {
      if (!tword_tab)
	 tword_tab = new FrSymHashTable ;
      if (seedvocab)
	 {
	 for (size_t i = 0 ; i < seedvocab->numWords() ; i++)
	    {
	    const char *ent = seedvocab->indexEntry(i) ;
	    if (ent && tword_tab)
	       {
	       const char *name = seedvocab->getNameFromIndexEntry(ent) ;
	       size_t ID = seedvocab->getID(ent) ;
	       tword_tab->add(FrSymbolTable::add(name),ID) ;
	       }
	    }
	 }
      else
	 {
	 seedvocab = new FrVocabulary ;
	 if (seedvocab)
	    {
	    seedvocab->useNameAsID(true) ;
	    seedvocab->setScaleFactor(2) ;
	    }
	 }
      if (!seedvocab || !tword_tab)
	 {
	 FrNoMemory("while setting up target-language vocabulary") ;
	 return false ;
	 }
      tword_vocab = seedvocab ;
      // ensure that the wildcard marker is present in the vocabulary
      EbCvtTrgWord2WordID(WILDCARD_TOKEN) ;
      }
   else
      {
      delete sword_tab ;
      sword_tab = new FrSymHashTable ;
      if (!sword_tab)
	 {
	 FrNoMemory("while setting up source-language vocabulary") ;
	 return false ;
	 }
      word_count = 0 ;
      if (seedvocab)
	 {
	 seedvocab->createReverseMapping() ;
	 size_t wc = seedvocab->numWords() ;
	 word_count = wc ;
	 for (size_t i = 0 ; i < wc ; i++)
	    {
	    const char *idx = seedvocab->indexEntry(i) ;
	    const char *word = seedvocab->getNameFromIndexEntry(idx) ;
	    size_t id = seedvocab->getID(idx) ;
	    FrSymbol *wordsym = FrSymbolTable::add(word) ;
	    sword_tab->add(wordsym,id) ;
	    if (id >= word_count)
	       word_count = id + 1 ;
	    }
	 }
      // ensure that the start-of-record marker is present in the vocabulary
      EbCvtSrcWord2WordID(SOR_TOKEN) ;
      // ensure that the wildcard marker is present in the vocabulary
      EbCvtSrcWord2WordID(WILDCARD_TOKEN) ;
      }
   return true ;
}

//----------------------------------------------------------------------

size_t EbCvtWord2WordID(const char *word, bool target_lang)
{
   if (!word)
      return FrVOCAB_WORD_NOT_FOUND ;
   FrSymHashTable *ht ;
   bool must_strip ;
   if (target_lang)
      {
      ht = tword_tab ;
      must_strip = (*word == EbTOKEN_START) ;
      }
   else
      {
      ht = sword_tab ;
      must_strip = (ignore_source_case || *word == EbTOKEN_START) ;
      }
   if (ht)
      {
      FrSymbol *wordsym ;
      if (must_strip)
	 {
	 char *word2 = EbStripCoindex(word,char_encoding) ;
	 wordsym = FrSymbolTable::add(word2) ;
	 FrFree(word2) ;
	 }
      else
	 wordsym = FrSymbolTable::add(word) ;
      FrSymHashEntry *entry = ht->lookup(wordsym) ;
      if (entry)
	 return entry->getCount() ;
      }
   return FrVOCAB_WORD_NOT_FOUND ;
}

//----------------------------------------------------------------------

static bool add_to_vocab(FrSymHashEntry *entry, va_list args)
{
   FrVarArg(FrVocabulary *,vocab) ;
   FrVarArg(size_t,prevcount) ;
   size_t id = entry->getCount() ;
   if (id >= prevcount)
      vocab->addWord(entry->getName()->symbolName(),id) ;
   return true ;			// continue iterating
}

//----------------------------------------------------------------------

static FrVocabulary *EbGatherVocabulary()
{
   FrVocabulary *vocab = new FrVocabulary ;
   if (sword_tab && vocab && vocab->startBatchUpdate())
      {
      sword_tab->doHashEntries(add_to_vocab,vocab,(size_t)0) ;
      vocab->finishBatchUpdate() ;
      }
   return vocab ;
}

//----------------------------------------------------------------------

FrVocabulary *EbFinishText2WordIDs(FrVocabulary *vocab,
				   bool target_lang = false,
				   bool completely_done = false)
{
   if (!vocab && (vocab = new FrVocabulary()) == 0)
      {
      FrNoMemory("while finishing vocabulary creation") ;
      return 0 ;
      }
   if (target_lang)
      {
      if (completely_done)
	 {
	 vocab->finishBatchUpdate() ;
	 delete tword_tab ;
	 tword_tab = 0 ;
	 if (vocab != tword_vocab)
	    delete tword_vocab ;
	 tword_vocab = 0 ;
	 }
      }
   else
      {
      if (sword_tab && vocab->startBatchUpdate())
	 {
	 size_t prevcount = vocab->numWords() ;
	 sword_tab->doHashEntries(add_to_vocab,vocab,prevcount) ;
	 vocab->finishBatchUpdate() ;
	 }
      if (completely_done)
	 {
	 delete sword_tab ;
	 sword_tab = 0 ;
	 }
      }
   return vocab ;
}

/************************************************************************/
/*	Methods for class EbExampleInfo					*/
/************************************************************************/

EbExampleInfo::EbExampleInfo(uint32_t corpoffset, size_t length, size_t flags)
{
   FrStoreLong(corpoffset,m_corpusoffset) ;
//   FrStoreLong(0,m_indexloc) ;
   FrStoreShort((length&EbEx_LENGTHMASK) | (flags & EbEx_FLAGSMASK),
		m_length_flags) ;
   return ;
}

//----------------------------------------------------------------------

EbExampleInfo::EbExampleInfo(uint32_t corpoffset, uint32_t indexloc,
			     size_t length, size_t flags)
{
   FrStoreLong(corpoffset,m_corpusoffset) ;
#ifdef EbINDEX_INCLUDES_LOCATION 
   FrStoreLong(indexloc,m_indexloc) ;
#else
   (void)indexloc ;
#endif /* EbINDEX_INCLUDES_LOCATION */
   FrStoreShort((length&EbEx_LENGTHMASK) | (flags & EbEx_FLAGSMASK),
		m_length_flags) ;
   return ;
}

//----------------------------------------------------------------------

bool EbExampleInfo::write(FILE *fp) const
{
   if (!fp)
      return false ;
   return Fr_fwrite(this,sizeof(EbExampleInfo),fp) ;
}

//----------------------------------------------------------------------

void EbExampleInfo::setCorpusOffset(uint32_t off)
{
   FrStoreLong(off,m_corpusoffset) ;
   return ;
}

//----------------------------------------------------------------------

void EbExampleInfo::setIndexLoc(uint32_t loc)
{
#ifdef EbINDEX_INCLUDES_LOCATION
   FrStoreLong(loc,m_indexloc) ;
#else
   (void)loc ;
#endif /* EbINDEX_INCLUDES_LOCATION */
   return ;
}

//----------------------------------------------------------------------

void EbExampleInfo::setLength(size_t len)
{
   size_t flags = FrLoadShort(m_length_flags) & ~EbEx_LENGTHMASK ;
   len &= EbEx_LENGTHMASK ;
   FrStoreShort(len | flags,m_length_flags) ;
   return ;
}

//----------------------------------------------------------------------

void EbExampleInfo::setFlags(size_t enable, size_t disable)
{
   enable &= EbEx_FLAGSMASK ;
   disable &= EbEx_FLAGSMASK ;
   size_t lenflg = FrLoadShort(m_length_flags) ;
   lenflg &= ~disable ;
   lenflg |= enable ;
   FrStoreShort(lenflg,m_length_flags) ;
   return ;
}

/************************************************************************/
/*	Methods for class EBMTIndex					*/
/************************************************************************/

EBMTIndex::EBMTIndex(const char *corpusdir, bool force_creation,
		     const char *srclang, const char *trglang,
		     bool *was_created)
{
   m_good = false ;
   m_indexing = false ;
   corpus = 0 ;
   m_info = 0 ;
   m_locations = 0 ;
   m_index = 0 ;
   m_tagged = 0 ;
   m_updates = 0 ;
   m_struct = 0 ;
   m_infomap = 0 ;
   m_locmap = 0 ;
   subfile_maps = 0 ;
   m_overridemap = 0 ;
   m_metadata_overrides = 0 ;
   m_override_index = 0 ;
   m_num_overrides = 0 ;
   m_exampleranks = 0 ;
   m_deforiginweight = 1.0 ;
   origin_ht = 0 ;
   current_origin = 0 ;
   num_pairs = 0 ;
   token_file_entries = 0 ;
   source_language = FrDupString(srclang) ;
   target_language = FrDupString(trglang) ;
   m_readonly = load_corpus_readonly && !force_creation ;
   symtab = current_symbol_table() ;
   FrSymbolTable::selectDefault() ;
   symtab->select() ;			// force proper update of delete hook
   base_dir = FrDupString(corpusdir ? corpusdir : "") ;
   info_file = FrAddDefaultPath(index_info_name,corpusdir) ;
   locations_file = FrAddDefaultPath(index_locations_name,corpusdir) ;
   index_file = FrAddDefaultPath(index_file_name,corpusdir) ;
   tagged_file = FrAddDefaultPath(index_tagged_name,corpusdir) ;
   updates_file = FrAddDefaultPath(index_updates_name,corpusdir) ;
   struct_file = FrAddDefaultPath(index_struct_name,corpusdir) ;
   svocab_file = FrAddDefaultPath(index_svocab_name,corpusdir) ;
   tvocab_file = FrAddDefaultPath(index_tvocab_name,corpusdir) ;
   token_file = FrAddDefaultPath(token_file_name,corpusdir) ;
   origins_file = FrAddDefaultPath(origins_file_name,corpusdir) ;
   overrides_file = FrAddDefaultPath(overrides_file_name,corpusdir) ;
   m_SOR_token = new FrString(SOR_TOKEN) ;
   tokenizer = 0 ; //new Tokenizer() ;
   info_alloc = 0 ;
   last_filenumber = (size_t)~0 ;
   last_fp = 0 ;
   character_map = 0 ;
   number_charmap = 0 ;
   m_modified = false ;
   bool created = false ;
   if (force_creation)
      {
      (void)FrCreatePath(corpusdir) ;	// create dir if needed
      if (!FrFileExists(info_file))	// does line-pointers file exist?
	 {
	 FILE *fp = FrOpenFile(info_file) ;
	 if (fp)
	    {
	    if (Fr_fwrite(index_info_signature,
			  sizeof(index_info_signature),fp))
	       {
	       created = true ;
	       // any extra setup goes here
	       }
	    fclose(fp) ;
	    }
	 }
      if (!FrFileExists(svocab_file))	// does index directory file exist?
	 {
	 m_svocab = new FrVocabulary ;
	 if (!m_svocab)
	    {
	    FrNoMemory("setting up vocabulary for EBMT index") ;
	    return ;
	    }
	 m_svocab->save(svocab_file) ;
	 delete m_svocab ;
	 m_svocab = 0 ;
	 created = true ;
	 }
      if (!FrFileExists(tvocab_file))	// does index directory file exist?
	 {
	 m_tvocab = new FrVocabulary ;
	 if (!m_tvocab)
	    {
	    FrNoMemory("setting up vocabulary for EBMT index") ;
	    return ;
	    }
	 m_tvocab->useNameAsID(true) ;
	 m_tvocab->setScaleFactor(2) ;	// align names on four-byte boundaries
	 m_tvocab->save(tvocab_file) ;
	 delete m_tvocab ;
	 m_tvocab = 0 ;
	 created = true ;
	 }
      }
   m_svocab = new FrVocabulary(svocab_file,0,isReadOnly(),
			       allow_memory_mapping) ;
   m_tvocab = new FrVocabulary(tvocab_file,0,isReadOnly(),
			       allow_memory_mapping && load_corpus_readonly) ;
   openIndex(EbIndex_Main,force_creation) ;
   openIndex(EbIndex_Tagged,force_creation) ;
   openIndex(EbIndex_Updates,force_creation) ;
   openIndex(EbIndex_Struct,false) ;
   if (FrFileExists(origins_file))
      m_origins.load(origins_file) ;
   size_t info_size = FrFileSize(info_file) ;
   if (info_size > sizeof(index_info_signature))
      num_pairs = ((info_size - sizeof(index_info_signature)) /
		   sizeof(EbExampleInfo)) ;
   highest_file = SUBFILE_NUMBER(num_pairs) ;
   setOriginWeights(example_origin_weights) ;
   loadExampleInfo(allow_memory_mapping) ;
   loadLocations(allow_memory_mapping,force_creation) ;
   override_fp = 0 ;
   m_overridemap = 0 ;
   loadOverrides(overrides_file,allow_memory_mapping,force_creation) ;
   m_good = ((force_creation || m_info != 0) &&
	     m_index != 0 && m_index->good()) ;
   if (m_good)
      {
      mapCorpus() ;
      loadTokens(0) ;
      }
   if (was_created)
      *was_created = created ;
   return ;
}

//----------------------------------------------------------------------

EBMTIndex::~EBMTIndex()
{
   if (m_indexing)
      {
      finishIndexing() ;
      }
   if (m_origins.changed())
      m_origins.save(origins_file) ;
   if (m_modified)
      {
      saveExampleInfo() ;
      m_modified = false ;
      }
   if (last_fp)
      {
      fclose(last_fp) ;
      last_fp = 0 ;
      }
   if (override_fp)
      saveOverrides() ;
   clearOriginWeights() ;
   delete m_index ;		m_index = 0 ;
   delete m_tagged ;		m_tagged = 0 ;
   delete m_updates ;		m_updates = 0 ;
   delete m_struct ;		m_struct = 0 ;
   delete m_svocab ;		m_svocab = 0 ;
   delete m_tvocab ;		m_tvocab = 0 ;
   last_filenumber = (size_t)~0 ;
   FrFree(base_dir) ;		base_dir = 0 ;
   FrFree(svocab_file) ;	svocab_file = 0 ;
   FrFree(tvocab_file) ;	tvocab_file = 0 ;
   FrFree(info_file) ;		info_file = 0 ;
   FrFree(locations_file) ;	locations_file = 0 ;
   FrFree(index_file) ;		index_file = 0 ;
   FrFree(tagged_file) ;	tagged_file = 0 ;
   FrFree(updates_file) ;	updates_file = 0 ;
   FrFree(struct_file) ;	struct_file = 0 ;
   FrFree(token_file) ;		token_file = 0 ;
   FrFree(origins_file) ;	origins_file = 0 ;
   FrFree(overrides_file) ;	overrides_file = 0 ;
   FrFree(source_language) ;	source_language = 0 ;
   FrFree(target_language) ;	target_language = 0 ;
   FrFree(current_origin) ;	current_origin = 0 ;
   free_object(origin_ht) ;	origin_ht = 0 ;
   FrFree(m_exampleranks) ;	m_exampleranks = 0 ;
   free_object(m_SOR_token) ;	m_SOR_token = 0 ;
   unmapCorpus() ;
   freeOverrides() ;
   freeExampleInfo() ;
   freeLocations() ;
   if (character_map)
      FrDestroyCharacterMap(character_map) ;
   if (number_charmap)
      FrDestroyCharacterMap(number_charmap) ;
   delete tokenizer ;
   tokenizer = 0 ;
   return ;
}

//----------------------------------------------------------------------

bool EBMTIndex::eraseFiles()
{
   Fr_unlink(info_file) ;
   Fr_unlink(locations_file) ;
   Fr_unlink(index_file) ;
   Fr_unlink(tagged_file) ;
   Fr_unlink(updates_file) ;
   Fr_unlink(struct_file) ;
   Fr_unlink(svocab_file) ;
   Fr_unlink(tvocab_file) ;
   Fr_unlink(token_file) ;
   Fr_unlink(origins_file); 
   Fr_unlink(overrides_file); 
   for (size_t i = 0 ; i <= highest_file ; i++)
      {
      char *subfile = getFileName(i) ;
      Fr_unlink(subfile) ;
      FrFree(subfile) ;
      }
   return true ;
}

//----------------------------------------------------------------------

void EBMTIndex::setCharMapping(const FrList *map, const FrList *num_map)
{
   if (map)
      character_map = FrMakeCharacterMap(map) ;
   else
      character_map = 0 ;
   if (num_map)
      number_charmap = FrMakeCharacterMap(num_map) ;
   else
      number_charmap = 0 ;
}

//----------------------------------------------------------------------

void EBMTIndex::setSourceLanguage(const char *language)
{
   if (source_language)
      {
      FrFree(source_language) ;
      source_language = 0 ;
      }
   if (!language)
      return ;
   source_language = FrDupString(language) ;
   return ;
}

//----------------------------------------------------------------------

void EBMTIndex::setTargetLanguage(const char *language)
{
   if (target_language)
      {
      FrFree(target_language) ;
      target_language = 0 ;
      }
   if (!language)
      return ;
   target_language = FrDupString(language) ;
   return ;
}

//----------------------------------------------------------------------

bool EBMTIndex::newSubFile()
{
   highest_file++ ;
   return true ;
}

//----------------------------------------------------------------------

bool EBMTIndex::loadTokens(const char *filename)
{
   if (filename && *filename && !FrFileExists(token_file))
      return false ;
   delete tokenizer ;
   tokenizer = new Tokenizer() ;
   // load the tokens from the default token file in the corpus directory
   if (tokenizer)
      return tokenizer->loadTokens(token_file) ;
   else
      return false ;		// unable to load because no tokenizer
}

//----------------------------------------------------------------------

bool EBMTIndex::mapCorpus(bool interim_map)
{
   if (interim_map || (map_corpus_subfiles && isReadOnly()))
      {
      if (interim_map)
	 unmapCorpus() ;
      subfile_maps = FrNewC(FrFileMapping*,numSubFiles()) ;
      if (subfile_maps)
	 {
	 bool success = false ;
	 for (size_t i = 0 ; i < numSubFiles() ; i++)
	    {
	    char *filename = getFileName(i) ;
	    if (filename)
	       {
	       subfile_maps[i] = FrMapFile(filename,FrM_READONLY) ;
	       FrFree(filename) ;
	       if (subfile_maps[i])
		  {
		  if (touch_all_memory)
		     FrTouchMappedMemory(subfile_maps[i]) ;
		  success = true ;
		  }
	       }
	    }
	 return success ;
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

void EBMTIndex::unmapCorpus()
{
   if (subfile_maps)
      {
      for (size_t i = 0 ; i < numSubFiles() ; i++)
	 {
	 if (subfile_maps[i])
	    FrUnmapFile(subfile_maps[i]) ;
	 }
      FrFree(subfile_maps) ;
      subfile_maps = 0 ;
      }
   return ;
}

//----------------------------------------------------------------------

bool EBMTIndex::exampleInfoLoaded() const
{
   return (m_infomap || m_info) ;
}

//----------------------------------------------------------------------

bool EBMTIndex::unmapExampleInfo()
{
   if (m_infomap || !m_info)
      return loadExampleInfo(false) ;
   return true ;
}

//----------------------------------------------------------------------

bool EBMTIndex::loadOverrides(const char *filename, bool memmap,
				bool force_creation) 
{
   freeOverrides() ;
   if (force_creation && !FrFileExists(filename))
      {
      override_fp = fopen(filename,FrFOPEN_WRITE_MODE) ;
      if (override_fp)
	 {
	 saveOverrides(override_fp) ;
	 fclose(override_fp) ;
	 override_fp = 0 ;
	 }
      }
   if (FrFileExists(filename))
      {
      if (memmap && allow_memory_mapping)
	 m_overridemap = FrMapFile(filename,FrM_READONLY) ;
      if (m_overridemap)
	 {
	 m_override_data = (char*)FrMappedAddress(m_overridemap) ;
	 m_override_index = FrLoadLong(m_override_data) ;
	 m_num_overrides = FrLoadLong(m_override_data+sizeof(LONGbuffer)) ;
	 m_metadata_overrides = m_override_data + m_override_index ;
	 if (touch_all_memory)
	    FrTouchMappedMemory(m_overridemap) ;
	 return true ;
	 }
      else
	 {
	 override_fp = fopen(filename,"rb+") ;
	 if (override_fp)
	    {
	    LONGbuffer offset ;
	    LONGbuffer numrecs ;
	    if (fread(offset,sizeof(char),sizeof(offset),override_fp) == sizeof(offset) &&
		fread(numrecs,sizeof(char),sizeof(numrecs),override_fp) == sizeof(numrecs))
	       {
	       m_override_index = FrLoadLong(offset) ;
	       m_num_overrides = FrLoadLong(numrecs) ;
	       fseek(override_fp,m_override_index,SEEK_SET) ;
	       m_metadata_overrides =
		  FrNewN(char,sizeof(LONGbuffer)*m_num_overrides) ;
	       if (m_metadata_overrides && 
		   fread(m_metadata_overrides,sizeof(LONGbuffer),
			 m_num_overrides,override_fp) == m_num_overrides)
		  return true ;
	       else
		  {
		  FrFree(m_metadata_overrides) ;
		  m_num_overrides = 0 ;
		  }
	       }
	    }
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

bool EBMTIndex::addOverride(uint32_t linenumber,
			      const EbCorpusMetaInfo *metainfo) 
{
   if (!metainfo)
      return true ;			// trivially successful
   if (!override_fp)
      {
      loadOverrides(overrides_file,false,true) ;
      if (!override_fp)
	 return false ;
      }
   if (m_overridemap)
      {
      // unmap the file and copy its contents into memory
      loadOverrides(overrides_file,false) ;
      }
   if (linenumber > m_num_overrides)
      {
      // expand the array
      char *new_overrides = FrNewR(char,m_metadata_overrides,
				   (linenumber+1)*sizeof(LONGbuffer)) ;
      if (!new_overrides)
	 return false ;			// unable to add the override
      for (size_t i = m_num_overrides ; i <= linenumber ; i++)
	 FrStoreLong(0,new_overrides+i*sizeof(LONGbuffer)) ;
      m_metadata_overrides = new_overrides ;
      m_num_overrides = linenumber + 1 ;
      }
   size_t metalen ;
   bool success = false ;
   char *meta = metainfo->store(metalen) ;
   // check whether we have an existing record that is at least as big as
   //   the new one
   uint32_t oldoffset = overridingMetaInfo(linenumber) ;
   size_t oldlen ;
   if (m_override_data)
      oldlen = (size_t)FrLoadLong(m_override_data + oldoffset) ;
   else if (oldoffset == 0)
      oldlen = 0 ;
   else
      {
      LONGbuffer off ;
      fseek(override_fp,oldoffset,SEEK_SET) ;
      if (fread(off,sizeof(char),sizeof(off),override_fp) == sizeof(off))
	 oldlen = (size_t)FrLoadLong(off) ;
      else
	 oldlen = 0 ;
      }
   LONGbuffer len ;
   FrStoreLong(metalen,len) ;
   if (oldoffset != 0 && m_override_data && oldlen >= metalen)
      {
      // overwrite the previous override record
      fseek(override_fp,oldoffset,SEEK_SET) ;
      if (Fr_fwrite(len,sizeof(char),sizeof(len),override_fp) &&
	  Fr_fwrite(meta,sizeof(char),metalen,override_fp))
	 {
	 success = true ;
	 // update the in-memory copy as well
	 if (m_override_data)
	    memcpy(m_override_data + oldoffset, meta, metalen) ;
	 }
      }
   else
      {
      // append a new override record
      fseek(override_fp,m_override_index,SEEK_SET) ;
      if (Fr_fwrite(len,sizeof(char),sizeof(len),override_fp) &&
	  Fr_fwrite(meta,sizeof(char),metalen,override_fp))
	 {
#if 0
	 if (m_override_data)
	    // stop updating the in-memory copy (!!! for now?)
	    m_override_data = 0 ;
#endif
	 success = true ;
	 // update the offset of the index within the file to point
	 //   just beyond the end of the new record
	 overrideOffset(linenumber,m_override_index) ;
	 m_override_index += metalen + sizeof(len) ;
	 }
      }
   FrFree(meta) ;
   return success ;
}

//----------------------------------------------------------------------

bool EBMTIndex::saveOverrides(FILE *fp)
{
   // since all updates of the actual data records were written to the
   //  on-disk file, all we need to do is append the new index (which
   //  has been maintained in memory) and update the file header to
   //  reflect the new offset and length of the index
   LONGbuffer offset ;
   LONGbuffer numrecs ;
   if (m_num_overrides == 0 || m_override_index < 2*sizeof(LONGbuffer))
      m_override_index = 2*sizeof(LONGbuffer) ;
   FrStoreLong(m_override_index,offset) ;
   FrStoreLong(m_num_overrides,numrecs) ;
   fseek(fp,0L,SEEK_SET) ;
   if (Fr_fwrite(offset,sizeof(char),sizeof(offset),fp) &&
       Fr_fwrite(numrecs,sizeof(char),sizeof(numrecs),fp))
      {
      fseek(fp,m_override_index,SEEK_SET) ;
      if (Fr_fwrite(m_metadata_overrides,sizeof(LONGbuffer),
		    m_num_overrides,fp))
	 {
	 fflush(fp) ;
	 return true ;
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

bool EBMTIndex::saveOverrides()
{
   if (override_fp)
      return saveOverrides(override_fp) ;
   else
      return true ;			// nothing to do, trivially successful
}

//----------------------------------------------------------------------

void EBMTIndex::freeOverrides()
{
   if (m_overridemap)
      {
      FrUnmapFile(m_overridemap) ;
      m_overridemap = 0 ;
      }
   else
      FrFree(m_metadata_overrides) ;
   if (override_fp)
      fclose(override_fp) ;
   override_fp = 0 ;
   m_override_data = 0 ;
   m_metadata_overrides = 0 ;
   m_num_overrides = 0 ;
   return ;
}

//----------------------------------------------------------------------

bool EBMTIndex::writeLocations(const char *filename)
{
   if (!filename || !*filename ||
       !m_index->setIndexLocations(numSentencePairs()))
      return false ;
   FILE *fp = fopen(locations_file,"wb") ;
   if (!fp)
      return false ;
   size_t infolen = m_index->numItems() * sizeof(LONGbuffer) ;
   char *loc_buf = FrNewN(char,infolen) ;
   for (size_t i = 0 ; i < m_index->numItems() ; i++)
      store_location(loc_buf,i,~0,~0) ;
   for (size_t i = 0 ; i < numSentencePairs() ; i++)
      {
      uint32_t loc = m_index->indexLocation(i) ;
      size_t offset = this->sourceLength(i) ;
      while (loc < m_index->EORvalue())
	 {
	 if (offset == 0)
	    {
	    // Oops, the recorded sentence length doesn't match the actual
	    //  length of the pointer chain!
	    cout << "; warning: record " << i << " is longer than the "
		 << sourceLength(i) << " words expected." << endl ;
	    break ;
	    }
	 store_location(loc_buf,loc,i,offset--) ;
	 loc = m_index->getSuccessor(loc) ;
	 }
      if (offset > 0)
	 {
	 // Oops, the recorded sentence length doesn't match the actual
	 //  length of the pointer chain!
	 cout << "; warning: record " << i << " is shorter than the "
	      << sourceLength(i) << " words expected." << endl ;
	 }
      }
   bool success = Fr_fwrite(loc_buf,sizeof(char),infolen,fp) ;
   FrFree(loc_buf) ;
   fclose(fp) ;
   if (!success)
      return false ;
   return true ;
}

//----------------------------------------------------------------------

bool EBMTIndex::loadLocations(bool memory_mapped, bool create)
{
   freeLocations() ;
   if (!m_index)
      return false ;
   if (create && !FrFileExists(locations_file))
      {
      if (!writeLocations(locations_file))
	 return false ;
      }
   size_t infolen = m_index->numItems() * sizeof(LONGbuffer) ;
   if (memory_mapped)
      {
      m_locmap = FrMapFile(locations_file,FrM_READONLY) ;
      if (m_locmap && FrMappingSize(m_locmap) >= infolen)
	 {
	 m_locations = (char*)FrMappedAddress(m_locmap) ;
	 return true ;
	 }
      else if (m_locmap)
	 FrUnmapFile(m_locmap) ;
      }
   int fd = open(locations_file,O_RDONLY|O_BINARY) ;
   if (fd != EOF)
      {
      off_t size = lseek(fd,0L,SEEK_END) ;
      if (size >= (off_t)infolen)
	 {
	 m_locations = FrNewN(char,size) ;
	 if (m_locations)
	    {
	    lseek(fd,0L,SEEK_SET) ;
	    if (::read(fd,m_locations,size) != size)
	       {
	       FrFree(m_locations) ;
	       m_locations = 0 ;
	       }
	    }
	 }
      close(fd) ;
      }
   return m_locations != 0 ;
}

//----------------------------------------------------------------------

void EBMTIndex::freeLocations()
{
   if (m_locmap)
      FrUnmapFile(m_locmap) ;
   else
      FrFree(m_locations) ;
   m_locmap = 0 ;
   m_locations = 0 ;
   return ;
}

//----------------------------------------------------------------------

bool EBMTIndex::loadExampleInfo(bool memory_mapped)
{
   freeExampleInfo() ;
   info_alloc = 0 ;
   if (memory_mapped)
      {
      m_infomap = FrMapFile(info_file,FrM_READONLY) ;
      if (m_infomap)
	 {
	 char *inf = (char*)FrMappedAddress(m_infomap) ;
	 if (inf)
	    {
	    inf += sizeof(index_info_signature) ;
	    m_info = (EbExampleInfo*)inf ;
	    if (touch_all_memory)
	       FrTouchMappedMemory(m_infomap) ;
	    return true ;
	    }
	 FrUnmapFile(m_infomap) ;
	 m_infomap = 0 ;
	 }
      }
   int fd = open(info_file,O_RDONLY|O_BINARY) ;
   if (fd != EOF)
      {
      off_t size = lseek(fd,0L,SEEK_END) ;
      if ((size_t)size > sizeof(index_info_signature))
	 {
	 size -= sizeof(index_info_signature) ;
	 m_info = FrNewN(EbExampleInfo,size / sizeof(EbExampleInfo) + 1) ;
	 if (m_info)
	    {
	    lseek(fd,sizeof(index_info_signature),SEEK_SET) ;
	    if (::read(fd,m_info,size) == size)
	       info_alloc = size / sizeof(EbExampleInfo) ;
	    else
	       {
	       FrFree(m_info) ;
	       m_info = 0 ;
	       }
	    }
	 }
      else
	 m_info = 0 ;
      close(fd) ;
      }
   return m_info != 0 ;
}

//----------------------------------------------------------------------

void EBMTIndex::setOriginWeights(const FrList *weights)
{
   if (!origin_ht)
      {
      origin_ht = new FrHashTable ;
      if (!origin_ht)
	 {
	 FrNoMemory("while setting example-origin weights") ;
	 return ;
	 }
      origin_ht->expand(200) ;
      }
   double maxweight = weights ? 0.00001 : 1.0 ;
   for (const FrList *wt = weights ; wt ; wt = wt->rest())
      {
      const FrList *w = (FrList*)wt->first() ;
      if (w && w->consp() && w->first() && w->rest())
	 {
	 double origin_wt = w->second()->floatValue() ;
	 if (origin_wt > maxweight)
	    maxweight = origin_wt ;
	 }
      }
   m_deforiginweight = 1.0 / maxweight ;
   for ( ; weights ; weights = weights->rest())
      {
      const FrList *weight = (FrList*)weights->first() ;
      if (!weight || !weight->consp() || !weight->first() || !weight->rest())
	 {
	 char *wt = weight->print() ;
	 FrWarningVA("malformed origin weight %s",wt) ;
	 FrFree(wt) ;
	 continue ;
	 }
      const char *origin = weight->first()->printableName() ;
      double origin_wt = weight->second()->floatValue() / maxweight ;
      size_t origin_weight = (size_t)(origin_wt * ORIGIN_WEIGHT_SCALE + 0.5) ;
      if (origin_wt > 0.0 && origin_weight == 0)
	 origin_weight = 1 ;
      if (strchr(origin,'*') || strchr(origin,'?'))
	 {
	 // wildcard entries need to be handled separately, so maintain a list
	 //   keyed to the empty string
	 FrConstString nullstr("") ;
	 FrHashEntryObject key(&nullstr,(void*)0) ;
	 FrHashEntryObject *entry
	    = (FrHashEntryObject*)origin_ht->lookup(&key) ;
	 FrList *newitem = new FrList(new FrString(origin),
				      new FrFloat(origin_wt)) ;
	 if (entry)
	    {
	    FrList *value = (FrList*)entry->getUserData() ;
	    pushlist(newitem,value) ;
	    entry->setUserData(value) ;
	    }
	 else
	    {
	    FrList *value = new FrList(newitem) ;
	    FrHashEntryObject key(&nullstr,value) ;
	    (void)origin_ht->add(&key) ;
	    }
	 }
      else
	 {
	 FrConstString originstr(origin) ;
	 FrHashEntryObject key(&originstr,(void*)origin_weight) ;
	 (void)origin_ht->add(&key) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void EBMTIndex::clearOriginWeights()
{
   if (origin_ht)
      {
      origin_ht->doHashEntries(clear_origin_weight) ;
      delete origin_ht ;
      origin_ht = 0 ;
      }
   return ;
}

//----------------------------------------------------------------------

void EBMTIndex::setExampleRanks(size_t num_ranks)
{
   if (!num_ranks)
      return ;
   if (!m_exampleranks)
      m_exampleranks = FrNewN(EbDocRank,numSentencePairs()) ;
   if (!m_exampleranks)
      return ;
   size_t srcnum = 0 ;
   const EbDataSource *source = m_origins.source(srcnum) ;
   if (source)
      {
      size_t i ;
      for (i = 0 ; i < (size_t)source->startLoc() ; i++)
	 {
	 m_exampleranks[i] = 0 ;
	 }
      double per_level = ((double)m_origins.numSources()) / num_ranks ;
      size_t rank = (size_t)(source->rank() / per_level) ;
      for ( ; i < numSentencePairs() ; i++)
	 {
	 if (i > (size_t)source->endLoc())
	    {
	    source = m_origins.find(i) ;
	    rank = (size_t)(source->rank() / per_level) ;
	    }
	 m_exampleranks[i] = rank ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void EBMTIndex::setOrigin(const char *orig)
{
   FrFree(current_origin) ;
   current_origin = FrDupString(orig) ;
   return ;
}

//----------------------------------------------------------------------

bool EBMTIndex::augmentDictionary(Dictionary *dict) const
{
   return tokenizer ? tokenizer->augmentDictionary(dict) : false ;
}

//----------------------------------------------------------------------

static bool save_example_info(FILE *fp, void *user_data)
{
   if (fp && user_data)
      {
      if (!Fr_fwrite(index_info_signature,1,
		     sizeof(index_info_signature),fp))
	 return false ;
      EBMTIndex *index = (EBMTIndex*)user_data ;
      for (size_t i = 0 ; i < index->numSentencePairs() ; i++)
	 {
	 const EbExampleInfo *inf = index->info(i) ;
	 if (inf && !inf->write(fp))
	    return false ;
	 }
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

bool EBMTIndex::saveExampleInfo()
{
   return FrSafelyRewriteFile(info_file,save_example_info,this) ;
}

//----------------------------------------------------------------------

void EBMTIndex::freeExampleInfo()
{
   if (m_infomap)
      FrUnmapFile(m_infomap) ;
   else
      FrFree(m_info) ;
   m_infomap = 0 ;
   m_info = 0 ;
   return ;
}

//----------------------------------------------------------------------

void EBMTIndex::getWordLocation(const EbBWTIndex *idx, size_t location,
				size_t &recnum, size_t &offset,
				bool exact) const
{
   if (idx == m_index && m_locations)
      {
      get_location(m_locations,location,recnum,offset) ;
      if (!exact ||
	  (recnum < LOCINFO_MAX_RECNUM && offset < LOCINFO_MAX_OFFSET))
	  return ;
      }
   if (idx)
      recnum = idx->recordNumber(location,&offset) ;
   else
      recnum = (uint32_t)~0 ;
   return ;
}

//----------------------------------------------------------------------

void EBMTIndex::getWordLocation(EbIndexSpec which, size_t location,
				size_t &recnum, size_t &offset,
				bool exact) const
{
   getWordLocation(selectIndex(which),location,recnum,offset,exact) ;
}

//----------------------------------------------------------------------

size_t EBMTIndex::recordNumber(EbBWTIndex *idx, size_t location) const
{
   if (idx == m_index && m_locations)
      {
      size_t offset ;
      size_t recnum ;
      get_location(m_locations,location,recnum,offset) ;
      if (recnum < LOCINFO_MAX_RECNUM)
	 return recnum ;
      }
   if (idx)
      return idx->recordNumber(location,0) ;
   else
      return (uint32_t)~0 ;
}

//----------------------------------------------------------------------

void EBMTIndex::refineWordLocation(EbIndexSpec which, size_t location,
				   size_t &recnum, size_t &offset) const
{
   if (which == EbIndex_Main &&
       (recnum >= LOCINFO_MAX_RECNUM || offset >= LOCINFO_MAX_OFFSET))
      {
      EbBWTIndex *idx = selectIndex(which) ;
      if (idx)
	 recnum = idx->recordNumber(location,&offset) ;
      }
   return ;
}

//----------------------------------------------------------------------

FrList *EBMTIndex::tokenize(FrTextSpans *source, const FrList *target,
			    BiTextMap *bitext) const
{
   if (!source || source->textLength() == 0)
      return 0 ;
   if (!tokenizer)
      return new FrList(source->wordList(),
			target ? target->deepcopy() : 0) ;
   FrList *tokenized = tokenizer->tokenize(source,target,getCorpus(),bitext) ;
   if (!tokenized)
      {
      if (!quiet_mode)
	 {
	 FrList *swords = source->wordList() ;
	 char *src = swords->print() ;
	 free_object(swords) ;
	 FrWarningVA("unable to tokenize input!\n;\t%.70s",src) ;
	 FrFree(src) ;
	 }
      return new FrList(source->wordList(),
			target ? target->deepcopy() : 0, 0, 0) ;
      }
   return tokenized ;
}

//----------------------------------------------------------------------

FrBWTLocation EBMTIndex::getInstanceRange(const FrSymbol *word,
					  EbIndexSpec which) const
{
   if (!word || !m_svocab)
      return FrBWTLocation(~0,0) ;
   size_t wordID = m_svocab->findID(word->symbolName()) ;
   switch (which)
      {
      case EbIndex_Main:
	 return m_index ? m_index->unigram(wordID) : FrBWTLocation(~0,0) ;
      case EbIndex_Tagged:
	 return m_tagged ? m_tagged->unigram(wordID) : FrBWTLocation(~0,0) ;
      case EbIndex_Updates:
	 return m_updates ? m_updates->unigram(wordID) : FrBWTLocation(~0,0) ;
      case EbIndex_Struct:
	 return m_struct ? m_struct->unigram(wordID) : FrBWTLocation(~0,0) ;
      default:
	 FrMissedCase("EBMTIndex::getInstanceRange") ;
	 return FrBWTLocation(~0,0) ;
      }
}

//----------------------------------------------------------------------

FrBWTLocation EBMTIndex::getInstanceRange(size_t ID, EbIndexSpec which) const
{
   switch (which)
      {
      case EbIndex_Main:
	 return m_index ? m_index->unigram(ID) : FrBWTLocation(~0,0) ;
      case EbIndex_Tagged:
	 return m_tagged ? m_tagged->unigram(ID) : FrBWTLocation(~0,0) ;
      case EbIndex_Updates:
	 return m_updates ? m_updates->unigram(ID) : FrBWTLocation(~0,0) ;
      case EbIndex_Struct:
	 return m_struct ? m_struct->unigram(ID) : FrBWTLocation(~0,0) ;
      default:
	 FrMissedCase("EBMTIndex::getInstanceRange") ;
	 return FrBWTLocation(~0,0) ;
      }
}

//----------------------------------------------------------------------

bool EBMTIndex::setSourceText(EBMTCandidate *cand, EbIndexSpec which) const
{
   if (!cand)
      return false ;
   EbBWTIndex *idx = selectIndex(which) ;
   if (!idx)
      return false ;
   FrVocabulary *vocab = vocabulary() ;
   if (!vocab)
      return false ;
   vocab->createReverseMapping() ;
   uint32_t indexloc = cand->indexLocation() ;
   cand->setSourceWords(idx->retrieveSource(indexloc,vocab,
					    cand->matchLength())) ;
   return true ;
}

//----------------------------------------------------------------------

char *EBMTIndex::getFileName(uint32_t filenumber)
{
   return Fr_aprintf(corpus_filename_template,base_dir,(int)filenumber) ;
}

//----------------------------------------------------------------------

FILE *EBMTIndex::openFile(uint32_t filenumber, bool write)
{
   char *filename = getFileName(filenumber) ;
   FILE *fp = filename ? FrOpenFile(filename,write,write) : 0 ;
   FrFree(filename) ;
   if (fp && write)
      {
      setvbuf(fp,NULL,_IOFBF,64*BUFSIZ) ;
      fseek(fp,0L,SEEK_END) ;		// append to corpus
      }
   return fp ;
}

//----------------------------------------------------------------------

//#define ALWAYS_COPY

bool EBMTIndex::readFile(char *&buffer, size_t filenumber, uint32_t start,
			   int length, bool &must_free)
{
   must_free = false ;
#ifdef ALWAYS_COPY
   // somehow, we end up with much worse memory fragmentation if we point at
   //   the memory-mapped data directly instead of copying it to a malloc()ed
   //   buffer, which also results in slightly slower translation
   buffer = FrNewN(char,length) ;
   if (!buffer)
      return false ;
   must_free = true ;
#endif /* ALWAYS_COPY */
   if (subfile_maps && filenumber < numSubFiles() &&
       subfile_maps[filenumber])
      {
      char *base = (char*)FrMappedAddress(subfile_maps[filenumber]) ;
      if (base && start + length <= FrMappingSize(subfile_maps[filenumber]))
	 {
#ifdef ALWAYS_COPY
	 memcpy(buffer,base+start,length) ;
#else
	 buffer = base + start ;
#endif /* ALWAYS_COPY */
	 return true ;
	 }
      }
#ifndef ALWAYS_COPY
   buffer = FrNewN(char,length) ;
   if (!buffer)
      return false ;
   must_free = true ;
#endif /* !ALWAYS_COPY */
   if (length == 0)
      return true ;
   FILE *fp ;
   if (filenumber != last_filenumber)
      {
      fp = openFile(filenumber,false) ;
      if (!fp)
	 return false ;
      if (last_fp)
	 fclose(last_fp) ;
      last_filenumber = filenumber ;
      last_fp = fp ;
      }
   else
      fp = last_fp ;
   int fd = fileno(fp) ;
   lseek(fd,start,SEEK_SET) ;
   buffer[0] = '\0' ;			// sentinel in case EOF reached
   int count = ::read(fd,buffer,length) ;
   return count == length ;
}

//----------------------------------------------------------------------

void EBMTIndex::unmemmap()
{
   unmapExampleInfo() ;
   return ;
}

//----------------------------------------------------------------------

void EBMTIndex::overrideOffset(size_t linenum, uint32_t offset)
{
   if (m_metadata_overrides && linenum < m_num_overrides)
      FrStoreLong(offset, m_metadata_overrides + linenum*sizeof(LONGbuffer)) ;
   return ;
}

//----------------------------------------------------------------------

uint32_t EBMTIndex::overridingMetaInfo(uint32_t linenumber) const
{
   return (m_metadata_overrides && linenumber < m_num_overrides 
	   ? FrLoadLong(m_metadata_overrides+linenumber*sizeof(LONGbuffer))
	   : 0) ;
}

//----------------------------------------------------------------------

const char *EBMTIndex::overridingMetaInfo(uint32_t linenumber,
					  size_t &meta_len,
					  bool &must_free) const
{
   must_free = false ;
   uint32_t offset = overridingMetaInfo(linenumber) ;
   if (offset)
      {
      if (m_overridemap && m_override_data &&
	  offset < FrMappingSize(m_overridemap))
	 {
	 meta_len = FrLoadLong(m_override_data + offset) ;
	 return m_override_data + offset + sizeof(LONGbuffer) ;
	 }
      else
	 {
	 LONGbuffer buf ;
	 fseek(override_fp,offset,SEEK_SET) ;
	 if (fread(buf,sizeof(char),sizeof(buf),override_fp) == sizeof(buf))
	    {
	    uint32_t len = FrLoadLong(buf) ;
	    char *meta = FrNewN(char,len+1) ;
	    if (meta && fread(meta,sizeof(char),len,override_fp) == len)
	       {
	       must_free = true ;
	       meta_len = len ;
	       return meta ;
	       }
	    FrFree(meta) ;
	    }
	 }
      }
   // no override record found
   meta_len = 0 ;
   return 0 ;
}

//----------------------------------------------------------------------

uint32_t EBMTIndex::numOccurrences(FrSymbol *word) const
{
   uint32_t count = 0 ;
   if (word && m_svocab)
      {
      size_t wordID = m_svocab->findID(word->symbolName()) ;
      if (m_index)
	 count = m_index->unigramFrequency(wordID) ;
      if (m_updates)
	 count += m_updates->unigramFrequency(wordID) ;
      }
   return count ;
}

//----------------------------------------------------------------------

bool EBMTIndex::getLinePosition(uint32_t location, uint32_t &start,
				  int &length) const
{
   if (!m_info || location >= numSentencePairs())
      return false ;
   if (LINE_IN_SUBFILE(location) == 0)
      {
      start = 0 ;
      length = m_info[location].corpusOffset() ;
      }
   else
      {
      start = m_info[location-1].corpusOffset() ;
      length = m_info[location].corpusOffset() - start ;
      }
   return true ;
}

//----------------------------------------------------------------------

bool EBMTIndex::beginIndexing()
{
   if (!m_indexing)
      {
      EbBeginText2WordIDs(m_svocab,false) ;
      EbBeginText2WordIDs(m_tvocab,true) ;
      loadExampleInfo(false) ;
      if (m_tvocab)
	 m_tvocab->startBatchUpdate() ;
      m_indexing = true ;
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

bool EBMTIndex::finishIndexing(bool completely_done)
{
   if (m_indexing)
      {
      FrTimer timer ;
      if (!quiet_mode && m_modified)
	 cout << "; saving index" << endl ;
      m_svocab = EbFinishText2WordIDs(m_svocab,false,completely_done) ;
      m_tvocab = EbFinishText2WordIDs(m_tvocab,true,completely_done) ;
      size_t sor_ID = m_svocab->findID(SOR_TOKEN) ;
      m_index->setRecordStartID(sor_ID) ;
      if (completely_done)
	 {
	 vocab_continued = false ;
	 if (m_svocab && m_svocab->changed())
	    {
	    m_svocab->freeReverseMapping() ;
	    m_svocab->save(svocab_file) ;
	    }
	 if (m_tvocab && m_tvocab->changed())
	    m_tvocab->save(tvocab_file) ;
	 // help defragment memory before we go save the big index
	 if (m_index && m_index->changed())
	    {
	    delete m_svocab ;
	    m_svocab = 0 ;
	    delete m_tvocab ;
	    m_tvocab = 0 ;
	    }
	 }
      else
	 vocab_continued = true ;
      saveExampleInfo() ;
      bool keep_IDs = !completely_done ;
      if (m_tagged && m_tagged->changed())
	 {
	 m_tagged->setRecordStartID(sor_ID) ;
         m_tagged->write(tagged_file,false,0,false) ;
	 }
      if (m_updates && m_updates->changed())
	 {
	 m_updates->setRecordStartID(sor_ID) ;
	 m_updates->write(updates_file,keep_IDs,this,false) ;
	 }
      if (m_struct && m_struct->changed())
	 {
	 m_struct->setRecordStartID(sor_ID) ;
         m_struct->write(struct_file,false,0,false) ;
	 }
      bool comp = completely_done ? use_compressed_index : false ;
      if (m_index && completely_done && m_index->changed())
	 {
	 keep_IDs = false ;
	 m_index->write(index_file,keep_IDs,this,comp) ;
	 writeLocations(locations_file) ;
	 freeExampleInfo() ;
	 }
     if (completely_done && !m_svocab)
	 {
	 m_svocab = new FrVocabulary(svocab_file,0,isReadOnly(),
				     allow_memory_mapping) ;
	 m_tvocab = new FrVocabulary(tvocab_file,0,isReadOnly(),
				     allow_memory_mapping) ;
	 }
      if (!quiet_mode)
	 {
	 cout << "; index saved (" << timer.readsec() << " seconds)" << endl ;
	 if (comp)
	    {
	    size_t uncomp_size ;
	    size_t comp_size ;
	    if (m_index && m_index->compressionStats(uncomp_size,comp_size))
	       cout << "; compression reduced main index from "
		     << uncomp_size << " to " << comp_size << " bytes ("
		     << 100.0 - (100.0 * comp_size / uncomp_size)
		     << "%)" << endl ;
	    }
	 }
      m_modified = false ;
      m_indexing = false ;
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

bool EBMTIndex::pack(ostream *out)
{
   // merge m_updates into m_index
   //  Eventually, there will be a BWTIndex::merge() function which can
   //    merge two sets of BWT data directly, but for now we'll have to
   //    reconstruct the original ID sequences, concatenate them, and
   //    then build a new BWT index from that
   if (m_updates && m_updates->numItems() > 0)
      {
      uint32_t *IDs = m_index->deconstruct(m_updates->totalItems()) ;
      if (IDs)
	 {
	 if (m_updates->deconstruct(IDs + m_index->totalItems(),
				    m_updates->totalItems()))
	    {
	    size_t idcount = m_index->totalItems() + m_updates->totalItems() ;
	    m_index->makeIndex(IDs,idcount,FrBWT_KeepEOR,
			       m_index->EORvalue(),out) ;
	    FrFree(IDs) ;
	    if (use_compressed_index)
	       m_index->compress() ;
	    bool success = m_index->save(index_file) ;
	    if (success)
	       {
	       delete m_updates ;
	       m_updates = new EbBWTIndex() ;
	       m_updates->save(updates_file) ;
	       }
	    return success ;
	    }
	 else
	    FrFree(IDs) ;
	 }
      if (out)
	 (*out) << "; unable to pack index (out of memory or other error)"
		  << endl ;
      return false ;
      }
   else if (*out)
      (*out) << "; index is already packed" << endl ;
   return true ;
}

//----------------------------------------------------------------------

bool EBMTIndex::dumpIndex(const char *exportfile, bool lexical_sort)
{
   // make sure we can convert word IDs back to strings
   if (!m_svocab || !m_svocab->createReverseMapping())
      return false ;
   FILE *fp = fopen(exportfile,"w") ;
   bool success = false ;
   if (fp)
      {
      if (lexical_sort)
	 {
	 // dump index entries sorted lexically
	 if (m_index->dump(fp,m_svocab,true,this) &&
	     m_updates->dump(fp,m_svocab,true,this))
	    success = true ;
	 }
      else
	 {
	 // make sure we can retrieve by record number
	 EbBWTIndex *main = selectIndex(EbIndex_Main) ;
	 EbBWTIndex *upd = selectIndex(EbIndex_Updates) ;
	 EbBWTIndex *struc = selectIndex(EbIndex_Struct) ;
	 if (!setIndexLocations())
	    {
	    fclose(fp) ;
	    return false ;
	    }
	 success = true ;
	 // dump index entries sorted by record number
	 for (size_t i = 0 ; i < numSentencePairs() ; i++)
	    {
	    FrList *src = main->retrieveSource(main->indexLocation(i),
					       m_svocab) ;
	    if (!src && upd)
	       src = upd->retrieveSource(upd->indexLocation(i),m_svocab) ;
	    if (src)
	       {
	       FrList *pos = 0 ;
	       if (struc)
		  {
		  pos = struc->retrieveSource(struc->indexLocation(i),
					      m_svocab) ;
		  if (pos)
		     {
		     pushlist(symPOS,pos) ;
		     char *printed = pos->print() ;
		     fprintf(fp,";;;(SOURCE %s)\n",printed) ;
		     FrFree(printed) ;
		     pos->freeObject() ;
		     }
		  }
	       for (FrList *s = src ; s ; s = s->rest())
		  {
		  fputs(FrPrintableName(s->first()),fp) ;
		  if (s->rest())
		     fputc(' ',fp) ;
		  }
	       }
	    }
	 }
      fclose(fp) ;
      }
   return success ;
}

//----------------------------------------------------------------------

void EBMTIndex::indexSentence(const FrList *wordlist, size_t line_num,
			      EbIndexSpec which_index, bool force_create)
{
   if (!wordlist || isReadOnly() || !m_indexing || !m_svocab)
      return ;
   EbBWTIndex *idx = selectIndex(which_index) ;
   if (!idx && force_create)
      idx = openIndex(which_index,force_create) ;
   if (idx)
      {
      for ( ; wordlist ; wordlist = wordlist->rest())
	 {
	 if (!idx->addWord(wordlist->first()))
	    break ;
	 }
      if (m_SOR_token)
	 (void)idx->addWord(m_SOR_token) ;// put start-of-record token last,
      					  //   because words will be reversed
      idx->finishLine(line_num,idx->EORvalue()) ;
      }
   return ;
}

//----------------------------------------------------------------------

void EBMTIndex::storeLineInfo(size_t line_num, size_t corpus_offset,
			      size_t length)
{
   // remember the length of this line
   if (line_num >= info_alloc)
      {
      size_t new_alloc = INFO_ALLOC_GRANULARITY *
			 ((line_num + INFO_ALLOC_GRANULARITY) /
			  INFO_ALLOC_GRANULARITY) ;
      EbExampleInfo *newinfo = FrNewR(EbExampleInfo,m_info,new_alloc) ;
      if (newinfo)
	 {
	 memset(newinfo+info_alloc,'\0',
		(new_alloc-info_alloc)*sizeof(EbExampleInfo)) ;
	 info_alloc = new_alloc ;
	 m_info = newinfo ;
	 }
      else
	 return ;
      }
   m_info[line_num].setCorpusOffset(corpus_offset) ;
   m_info[line_num].setLength(length) ;
   return ;
}

//----------------------------------------------------------------------

static bool null_translation(const FrList *words)
{
   if (words && !words->rest())		// single-element list?
      {
      const char *trans = FrPrintableName(words->first()) ;
      if (trans)
	 return Fr_stricmp(trans,NULL_TRANS_MARKER) == 0 ;
      }
   return false ;			// not a null-translation marker
}

//----------------------------------------------------------------------

inline bool ignoreable_sentence_pair(const FrList *src, const FrList *trg)
{
   // skip any sentence pairs where the source tokenizes down to a single
   //   token, since we'll never be able to match it anyway
   if (src && !src->rest() && is_token(src->first()))
      return true ;
   // skip any sentence pairs where the target tokenizes down to a single
   //   token and the source remains multiple words, since it's probable
   //   that we'll get into trouble if we do match the source side....
   if (trg && !trg->rest() && is_token(trg->first()))
      return true ;
   return false ;
}

//----------------------------------------------------------------------
// if skip_tokenizer != NULL, then
//     in:  if (skip_tokenizer) index text as-is
//     out: if (skip_tokenizer) caller should call again

bool EBMTIndex::indexSentencePair(char *source, const char *target,
				  const char *tags,
				  FILE *corpusfp,
				  EbIndexSpec which_index,
				  bool report_failures,
				  bool /*recursive_match*/,
				  bool *skip_tokenizer)
{
   if (!source || !target || isReadOnly())
      return false ;
   FrSymbolTable *sym_t = symtab->select() ;
   if (ignore_source_case)
      FrMapString(source,lowercase_table) ;
   FrList *swords = FrCvtSentence2Wordlist(source) ;
   FrList *twords = FrCvtSentence2Wordlist(target) ;
   if (strip_punct)
      {
      // remove the punctuation (for use with a speech recognizer, which
      // doesn't generate punctuation)
      swords = remove_punctuation(swords) ;
      twords = remove_punctuation(twords) ;
      }
   if (!swords || !twords)
      {
      warn_with_s_t("both source and target must be non-empty for indexSentencePair!\n"
		    "  source = %.66s\n"
		    "  target = %.66s",swords,twords) ;
      free_object(swords) ;
      free_object(twords) ;
      sym_t->select() ;
      return false ;
      }
   size_t slen = swords->simplelistlength() ;
   size_t tlen = twords->simplelistlength() ;
   if (slen > max_sentence_length || tlen > max_sentence_length)
      {
      skipped_due_to_length++ ;
      if (!quiet_mode)
	 {
	 FrString *ssent = new FrString(swords) ;
	 FrString *tsent = new FrString(twords) ;
	 warn_with_s_t("sentence %d longer than specified maximum of %d (skipped):\n"
		       "  source = %.66s\n"
		       "  target = %.66s",numSentencePairs(),
		       max_sentence_length,ssent,tsent) ;
	 free_object(ssent) ;
	 free_object(tsent) ;
	 }
      free_object(swords) ;
      free_object(twords) ;
      sym_t->select() ;
      return false ;
      }
   else if (slen >= 8 &&
	    (tlen < min_sentence_ratio * slen ||
	     tlen > max_sentence_ratio * slen))
      {
      skipped_due_to_ratio++ ;
      if (verbose)
	 {
	 FrString *ssent = new FrString(swords) ;
	 FrString *tsent = new FrString(twords) ;
	 warn_with_s_t("sentence %d lengths mismatch by too much (skipped):\n"
		       "  source = %.66s\n"
		       "  target = %.66s",numSentencePairs(),ssent,tsent) ;
	 free_object(ssent) ;
	 free_object(tsent) ;
	 }
      free_object(swords) ;
      free_object(twords) ;
      sym_t->select() ;
      return false ;
      }
   else if (null_translation(swords) || null_translation(twords))
      {
      if (verbose)
	 {
	 const char *xlat = null_translation(swords) ? target : source ;
	 warn_string("skipping (null translation): %s",xlat,40) ;
	 }
      free_object(swords) ;
      free_object(twords) ;
      sym_t->select() ;
      return false ;			// sorry, didn't index the sentences
      }
   FrList *alignment = EbExtractAlignTag(tags) ;
   // since we may have morphological tags on the words, we need to
   //   parse them off
   FrTextSpans *slattice = EbMakeLattice(swords,morph_classes,
					 morph_global_info) ;
   FrList *src = slattice->wordList() ;
   FrList *src1 = FrCvtWordlist2Symbollist(src,char_encoding) ;
   free_object(src) ;
   BiTextMap *bitext = EBMTCandidate::makeBiText(getCorpus(), src1, twords,
						 number_charmap,alignment,
						 reverse_languages) ;
   bool have_alignment = (alignment != 0) ;
   free_object(alignment) ;
   free_object(src1) ;
   if (!bitext)
      {
      FrWarning("unable to create bitext map for sentence pair!") ;
      free_object(swords) ;
      free_object(twords) ;
      sym_t->select() ;
      EbFreeLattice(slattice) ;
      return false ;			// precomputed bitext is now mandatory
      }
   bool success = true ;
   bool report_errors = report_failures&&!(skip_tokenizer&&*skip_tokenizer) ;
   bool token_recursion_OK = (allow_token_recursion ||
				which_index == EbIndex_Tagged) ;
   EbCorpusMetaInfo meta(tags,swords->simplelistlength(),report_errors) ;
   if (have_alignment) meta.addField(EbCorpusMetaInfo::align_tag) ;
   if (swords && !swords->rest() && is_token(swords->first()))
      token_recursion_OK = allow_token_recursion ;
   src = 0 ;
   FrList *trg = 0 ;
   FrSymbol *token = meta.token() ;
   if (token)
      {
      // ensure that the token is in both source and target vocabularies
      char *tokenstr = EbStripCoindex(token->symbolName(),char_encoding) ;
      (void)EbCvtSrcWord2WordID(tokenstr) ;
      (void)EbCvtTrgWord2WordID(tokenstr) ;
      FrFree(tokenstr) ;
      }
   if (!skip_tokenizer || !*skip_tokenizer)
      {
      FrList *tok = tokenizer->tokenize(slattice,twords,getCorpus(),bitext) ;
      free_object(twords) ;
      if (tok)
	 {
	 src = (FrList*)poplist(tok) ;
	 trg = (FrList*)poplist(tok) ;
	 FrArray *morph_info = (FrArray*)poplist(tok) ;
	 free_object(tok) ;
	 meta.setSourceWords(src->simplelistlength()) ;
	 for (size_t i = 0 ; i < morph_info->arrayLength() ; i++)
	    {
	    FrStruct *morph = (FrStruct*)morph_info->getNth(i) ;
	    if (morph)
	       meta.setMorphology(i,morph) ;
	    }
	 free_object(morph_info) ;
	 if (skip_tokenizer && (/*token ||!!!*/index_original) &&
	     !EBMT_equal(src,swords))
	    *skip_tokenizer = true ;
	 }
      else
	 {
	 success = false ;
	 warn_string("unable to tokenize sentence: %s",source,40) ;
	 src = 0 ;
	 trg = 0 ;
	 }
      free_object(swords) ;
      }
   else if (morph_intro_str && *morph_intro_str)
      {
      free_object(swords) ;
      src = slattice->wordList() ;
      trg = twords ;
      meta.setSourceWords(slattice->spanCount()) ;
      for (size_t i = 0 ; i < slattice->spanCount() ; i++)
	 {
	 FrTextSpan *span = slattice->getSpan(i) ;
	 if (span)
	    {
	    const FrStruct *morph = span->metaData() ;
	    if (morph)
	       meta.setMorphology(i,morph) ;
	    }
	 }
      }
   else
      {
      src = swords ;
      trg = twords ;
      }
   EbFreeLattice(slattice) ;
   if (success && token)
      {
      if (src && !src->rest() && token_equal(token,src->first()))
	 {
//	 if (!quiet_mode)
//	    warn_string("entry tokenizes to its own tag: %s",source,35) ;
	 success = false ;
	 }
      }
   // don't bother indexing this sentence if it tokenizes to a single token
   // that translates as itself
   if (success && !token_recursion_OK && ignoreable_sentence_pair(src,trg))
      {
      if (verbose)
	 warn_string("ignoring fully-tokenized entry: %s",source,40) ;
      success = false ;
      }
   else if (success)
      {
      size_t trglen = trg->simplelistlength() ;
      EbWordID_t *IDs = FrNewN(EbWordID_t,trglen) ;
      size_t i = 0 ;
      // to ensure that all the words are in our target-lang hash table,
      //    explicitly convert words to IDs instead of just passing the
      //    word list to the EbSentence ctor
      for (const FrList *t = trg ; t ; t = t->rest(), i++)
	 IDs[i] = EbCvtTrgWord2WordID(FrPrintableName(t->first())) ;
      EbSentence sent(tword_vocab,IDs,trglen) ;
      if (!sent.write(corpusfp))
	 success = false ;
      else
	 {
	 // convert the given tags into the format in which they are stored
	 //   in the corpus
	 if ((tags || meta.haveMorphology()) && !meta.write(corpusfp))
	    {
	    FrWarningVA("unable to convert information on tag line\n%s",tags) ;
	    }
	 // compress the previously-built bitext map and store it in the corpus
	 // for later retrieval
	 char *correspondences = 0 ;
	 size_t len = bitext->compress(correspondences) ;
	 if (len > 0)
	    {
	    if (!Fr_fwrite(correspondences,sizeof(char),len,corpusfp))
	       FrWarning("error writing to corpus file") ;
	    }
	 FrFree(correspondences) ;
	 // now that the example has been stored, generate the index
	 //   entries for the words in the sentence
	 indexSentence(src,numSentencePairs(),which_index) ;
	 fseek(corpusfp,0L,SEEK_CUR) ;	// force ftell to return correct value
	 off_t corpus_offset = ftell(corpusfp) ;
	 storeLineInfo(numSentencePairs(),corpus_offset,
		       src->simplelistlength()) ;
	 // check whether we need to add anything to the tagged-entry index
	 if (token)
	    {
	    indexSentence(src,numSentencePairs(),EbIndex_Tagged) ;
	    if (numSentencePairs() < info_alloc)
	       m_info[numSentencePairs()].setFlags(EbEx_HAVETOKEN) ;
	    }
	 FrList *restrict = meta.sourceStructure() ;
	 if (restrict)
	    {
	    indexSentence(restrict,numSentencePairs(),EbIndex_Struct,true) ;
	    restrict->eraseList(false) ;
	    if (numSentencePairs() < info_alloc)
	       m_info[numSentencePairs()].setFlags(EbEx_HAVESTRUCT) ;
	    }
	 if (meta.haveField(EbCorpusMetaInfo::exact_tag))
	    m_info[numSentencePairs()].setFlags(EbEx_EXACTMATCH) ;
	 num_pairs++ ;
	 }
      }
   delete bitext ;
   free_object(src) ;
   free_object(trg) ;
   sym_t->select() ;
   return success ;
}

//----------------------------------------------------------------------

bool EBMTIndex::addPairs(const FrList *pairs, bool must_canonicalize,
			   bool recursive_match, bool skip_tokenization,
			   bool force_quiet)
{
   if (!pairs)
      return true ;			// trivially successful
   if (isReadOnly() || m_indexing)	// can we update the index right now?
      return false ;
   bool old_quiet = quiet_mode ;
   if (force_quiet)
      quiet_mode = true ;
   FrSymbolTable *sym_t = symtab->select() ;
   beginIndexing() ;
   unmemmap() ;
   bool done = false ;
   bool success = true ;
   m_indexing = true ;
   size_t first_pair = numSentencePairs() ;
   do {
      FILE *corpusfp = openFile(highest_file,true) ;
      if (!corpusfp)			// were we able to open file?
	 {
	 sym_t->select() ;
	 return false ;			// if not, bail out
	 }
      for ( ; pairs && success ; pairs = pairs->rest())
	 {
	 const FrList *pair = (FrList*)pairs->first() ;
	 if (pair && pair->consp())
	    {
	    char *ssent, *tsent ;
	    if (must_canonicalize)
	       {
	       ssent = FrCanonicalizeSentence(FrPrintableName(pair->first()),
					      char_encoding,false,
					      word_delimiters,abbrevs_list) ;
	       tsent = FrCanonicalizeSentence(FrPrintableName(pair->second()),
					      char_encoding,false,
					      word_delimiters,abbrevs_list);
	       }
	    else
	       {
	       ssent = FrDupString(FrPrintableName(pair->first())) ;
	       tsent = FrDupString(FrPrintableName(pair->second())) ;
	       }
	    const char *tags = FrPrintableName(pair->third()) ;
	    bool *skip_tok = (skip_tokenization
				? &skip_tokenization
				: 0) ;
	    if (!skip_tok && EbExtractLiteralTag(tags))
	       {
	       skip_tok = &skip_tokenization ;
	       skip_tokenization = true ;
	       }
	    if (ssent && tsent && *ssent && *tsent)
	       {
	       success = indexSentencePair(ssent,tsent,tags,corpusfp,
					   EbIndex_Updates,verbose,
					   recursive_match,skip_tok) ;
	       m_modified = true ;
	       }
	    else
	       success = true ;		// say OK since we did nothing
	    FrFree(ssent) ;
	    FrFree(tsent) ;
	    if (LINE_IN_SUBFILE(numSentencePairs()) == 0)
	       break ;			// we've hit the end of a subfile
	    }
	 }
      fflush(corpusfp) ;
      fclose(corpusfp) ;
      if (!success)
	 break ;
      done = (pairs == 0) ;
      if (!done)
	 newSubFile() ;
      } while (!done) ;
   if (numSentencePairs() > first_pair)
      m_origins.addSource(currentOrigin(),first_pair,numSentencePairs()-1) ;
   finishIndexing() ;
   quiet_mode = old_quiet ;
   sym_t->select() ;
   return success ;
}

//----------------------------------------------------------------------

bool EBMTIndex::addDocument(const char *document, FILE *docfp,
			    bool incremental_update)
{
   if (isReadOnly() || !docfp || !m_index)
      return false ;			// unable to index!
   setOrigin(FrFileBasename(document)) ;
   bool continued = false ;
   size_t first_pair = numSentencePairs() ;
   EbIndexSpec which = incremental_update ? EbIndex_Updates : EbIndex_Main ;
   skipped_due_to_length = 0 ;
   skipped_due_to_ratio = 0 ;
   do {
      FILE *corpusfp = openFile(highest_file,true) ;
      if (!corpusfp)			// were we able to open file?
	 return false ;			// if not, bail out
      bool added_line ;
      do {
         char *ssent, *tsent, *tags ;
	 added_line = false ;
	 if (read_EBMT_entry(docfp,character_map,ssent,tsent,tags,
			     !ignore_source_case,source_regex_list,
			     target_regex_list,abbrevs_list))
	    {
	    // if we have an explicit tag for the origin of the example,
	    //   update our record appropriately
	    FrString *origin = EbExtractOriginTag(tags) ;
	    if (origin)
	       {
	       if (numSentencePairs() > first_pair)
		  m_origins.addSource(currentOrigin(),first_pair,
				      numSentencePairs()-1) ;
	       first_pair = numSentencePairs() ;
	       setOrigin(origin->stringValue()) ;
	       origin->freeObject() ;
	       }
	    bool index_without_tokens = false ;
	    bool skipped_generalization = false ;
	    if (EbExtractLiteralTag(tags))
	       {
	       index_without_tokens = true ;
	       skipped_generalization = true ;
	       }
	    if (indexSentencePair(ssent,tsent,tags,corpusfp,which,true,true,
				  &index_without_tokens))
	       {
	       added_line = true ;
	       if (index_without_tokens && !skipped_generalization &&
		   LINE_IN_SUBFILE(numSentencePairs()) != 0)
		  {
		  // the indexer asked that we call it again, telling it to
		  //   skip the tokenization step
		  indexSentencePair(ssent,tsent,tags,corpusfp,which,
				    true,false,&index_without_tokens) ;
		  }
	       }
	    }
	 FrFree(ssent) ;
	 FrFree(tsent) ;
	 FrFree(tags) ;
         } while (!feof(docfp) &&
		  (!added_line || LINE_IN_SUBFILE(numSentencePairs()) != 0)) ;
      fclose(corpusfp) ;
      if (numSentencePairs() > first_pair)
	 {
	 m_origins.addSource(currentOrigin(),first_pair,numSentencePairs()-1) ;
	 size_t filenum = highest_file ;
	 if (numSentencePairs() && LINE_IN_SUBFILE(numSentencePairs()) == 0)
	    {
	    unmapCorpus() ;
	    newSubFile() ;
	    continued = (ftell(docfp) < FrFileSize(docfp)) ;
	    }
	 if (m_tagged && m_tagged->changed())
	    {
	    // make sure that any tagged entries from this file are available
	    //   to all subsequent files
	    m_tagged->write(tagged_file,true,0,false) ;
	    // also make sure that the vocabulary is available to subsequent
	    //   files when matching against the tagged entries
	    FrVocabulary *new_vocab = EbGatherVocabulary() ;
	    if (new_vocab)
	       {
	       delete m_svocab ;
	       m_svocab = new_vocab ;
	       }
	    // and finally make sure we mmap the portions of the corpus that
	    //   have already been written in order to maintain speed
	    mapCorpus(true) ;
	    }
	 if (m_struct && m_struct->changed())
	    {
	    // make sure that any structural entries from this file are
	    //   available to all subsequent files
	    m_struct->write(struct_file,true,0,false) ;
	    }
	 cout << "; document " << document << " indexed to file "
	      << filenum << endl ;
	 if (verbose && showmem)
	    {
	    cout << "#|" << endl ;
	    FrMemoryStats(cout) ;
	    cout << "|#" << endl ;
	    }
	 first_pair = numSentencePairs() ;
	 }
      else
	 continued = false ;
      } while (continued) ;
   m_modified = true ;
   if (skipped_due_to_length || skipped_due_to_ratio)
      cout << ";  (" << skipped_due_to_length
	   << " pairs skipped for excessive length, "
	   << skipped_due_to_ratio << " for bad length ratio)" << endl ;
   fclose(docfp) ;
   if (verbose)
      FrMemoryStats(cerr) ;
   return true ;			// successfully indexed
}

//----------------------------------------------------------------------

bool EBMTIndex::addDocument(const char *document, bool incr_update)
{
   if (!document || !*document)
      return false ;
   unmemmap() ;
   FrSkipWhitespace(document) ;
   if (!*document || *document == '#' || *document == ';')
      return true ;			// trivially successful
   if (isReadOnly())
      {
      cout << "; can't update a read-only corpus!" << endl ;
      return false ;
      }
#ifdef __WATCOMC__ // FrIsDirectory broken under Watcom+Windows
   if (FrIsDirectory(document))
      {
      cout << "; skipping directory " << document << endl ;
      return false ;
      }
#endif
   FILE *docfp = fopen(document,text_read_mode) ;
   if (docfp)
      {
      setvbuf(docfp,NULL,_IOFBF,64*BUFSIZ) ;
      return addDocument(document,docfp,incr_update) ;
      }
   else
      cout << "; Error opening document: " << document << endl ;
   return false ;			// unable to index!
}

//----------------------------------------------------------------------

bool EBMTIndex::tokenizeSentence(ostream &out, char *line)
{
   if (ignore_source_case)
      FrMapString(line,lowercase_table) ;
   FrList *words = FrCvtString2Wordlist(line) ;
   if (strip_punct)
      words = remove_punctuation(words) ;
   bool success = true ;
   if (!words)
      {
      out << endl ;
      }
   else
      {
      FrTextSpans *lattice = EbMakeLattice(words,morph_classes,
					   morph_global_info) ;
      FrList *tok = tokenizer->tokenize(lattice,getCorpus()) ;
      if (tok)
	 {
	 FrList *src = (FrList*)poplist(tok) ;
	 free_object(tok) ;
	 FrString *tokenized = new FrString(src) ;
	 if (tokenized && tokenized->stringValue())
	    out << tokenized->stringValue() << endl ;
	 else
	    success = false ;
	 free_object(src) ;
	 }
      else
	 out << line << endl ;
      EbFreeLattice(lattice) ;
      }
   return success ;
}

//----------------------------------------------------------------------

bool EBMTIndex::tokenizeDocument(const char *document, FILE *docfp,
				 ostream &out, bool show_doc_origin)
{
   if (show_doc_origin)
      out << ";;;(ORIGIN \"" << FrFileBasename(document) << "\")" << endl ;
   while (!feof(docfp))
      {
      char line[FrMAX_LINE] ;
      line[0] = '\0' ;
      if (!fgets(line,sizeof(line),docfp))
	 break ;
      if (!tokenizeSentence(out,line))
	 {
	 cerr << "; error while tokenizing the following line:\n"
	      << "; =>\t" << line << endl ;
	 break ;
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

bool EBMTIndex::tokenizeDocument(const char *document, ostream &out,
				 bool show_doc_origin)
{
   if (!document || !*document)
      return false ;
   FrSkipWhitespace(document) ;
   if (!*document || *document == '#' || *document == ';')
      return true ;			// trivially successful
#ifdef __WATCOMC__ // FrIsDirectory broken under Watcom+Windows
   if (FrIsDirectory(document))
      {
      cout << "; skipping directory " << document << endl ;
      return false ;
      }
#endif
   FILE *docfp = fopen(document,text_read_mode) ;
   if (docfp)
      {
      setvbuf(docfp,NULL,_IOFBF,64*BUFSIZ) ;
      return tokenizeDocument(document,docfp,out,show_doc_origin) ;
      }
   else
      cout << "; Error opening document: " << document << endl ;
   return false ;			// unable to index!
}

//----------------------------------------------------------------------

bool EBMTIndex::enumerateNGrams(EbIndexSpec which, size_t N, size_t minfreq,
				  bool include_EOR,
				  FrBWTNGramIterFunc fn, va_list args) const
{
   EbBWTIndex *idx = selectIndex(which) ;
   if (idx)
      return idx->enumerateNGrams(N,minfreq,include_EOR,fn,args) != 0 ;
   else
      return false ;
}

//----------------------------------------------------------------------

bool EBMTIndex::enumerateNGrams(EbIndexSpec which, size_t N, size_t minfreq,
				  bool include_EOR,
				  FrBWTNGramIterFunc fn, ...) const
{
   va_list args ;
   va_start(args,fn) ;
   bool success = enumerateNGrams(which,N,minfreq,include_EOR,fn,args) ;
   va_end(args) ;
   return success ;
}

//----------------------------------------------------------------------

size_t EBMTIndex::wordID(FrSymbol *word) const
{
   if (word && m_svocab)
      return m_svocab->findID(word->symbolName()) ;
   else
      return EbINDEX_NO_SUCH_RECORD ;
}

//----------------------------------------------------------------------

void EBMTIndex::setIndexLocation(size_t linenum, uint32_t entrynum)
{
#ifdef EbINDEX_INCLUDES_LOCATION
   if (m_infomap)			// ensure that we have a writeable
      unmapExampleInfo() ;		//  copy of the per-example info
   if (m_info)
      {
      m_info[linenum].setIndexLoc(entrynum) ;
      modified = true ;
      }
#else
   (void)linenum ; (void)entrynum ;
#endif /* EbINDEX_INCLUDES_LOCATION */
   return ;
}

//----------------------------------------------------------------------

bool EBMTIndex::setIndexLocations()
{
   bool success = true ;
   if (m_index && !m_index->setIndexLocations(numSentencePairs()))
      success = false ;
   if (m_tagged && !m_tagged->setIndexLocations(numSentencePairs()))
      success = false ;
   if (m_updates && !m_updates->setIndexLocations(numSentencePairs()))
      success = false ;
   if (m_struct && !m_struct->setIndexLocations(numSentencePairs()))
      success = false ;
   return success ;
}

//----------------------------------------------------------------------

void EBMTIndex::freeIndexLocations()
{
   if (m_index)
      m_index->freeIndexLocations() ;
   if (m_tagged)
      m_tagged->freeIndexLocations() ;
   if (m_updates)
      m_updates->freeIndexLocations() ;
   if (m_struct)
      m_struct->freeIndexLocations() ;
   return ;
}

//----------------------------------------------------------------------

EbBWTIndex *EBMTIndex::openIndex(EbBWTIndex *&idx, const char *filename,
				 bool force_create)
{
   if (force_create && !FrFileExists(filename))
      {
      EbBWTIndex dummyindex ;
      dummyindex.save(filename) ;
      }
   if (FrFileExists(filename))
      {
      idx = new EbBWTIndex(filename,allow_memory_mapping,touch_all_memory) ;
      if (idx && m_svocab)
	 idx->setRecordStartID(m_svocab->findID(SOR_TOKEN)) ;
      }
   return idx ;
}

//----------------------------------------------------------------------

EbBWTIndex *EBMTIndex::openIndex(EbIndexSpec which,
				 bool force_create)
{
   switch (which)
      {
      case EbIndex_None:
	 return 0 ;
      case EbIndex_Main:
	 return openIndex(m_index,index_file,force_create) ;
      case EbIndex_Tagged:
	 return openIndex(m_tagged,tagged_file,force_create) ;
      case EbIndex_Updates:
	 return openIndex(m_updates,updates_file,force_create) ;
      case EbIndex_Struct:
	 return openIndex(m_struct,struct_file,force_create) ;
      default:
	 FrMissedCase("EBMTIndex::openIndex") ;
	 return 0 ;
      }
}

//----------------------------------------------------------------------

EbBWTIndex *EBMTIndex::selectIndex(EbIndexSpec which) const
{
   switch (which)
      {
      case EbIndex_None:
	 return 0 ;
      case EbIndex_Main:
	 return m_index ;
      case EbIndex_Tagged:
	 return m_tagged ;
      case EbIndex_Updates:
	 return m_updates ;
      case EbIndex_Struct:
	 return m_struct ;
      default:
	 FrMissedCase("EBMTIndex::selectIndex") ;
	 return 0 ;
      }
}

//----------------------------------------------------------------------

uint32_t EBMTIndex::indexLocation(EbIndexSpec which, size_t N) const
{
#define NSR ((uint32_t)EbINDEX_NO_SUCH_RECORD)
   switch (which)
      {
      case EbIndex_None:
	 return NSR ;
      case EbIndex_Main:
	 return m_index ? m_index->indexLocation(N) : NSR ;
      case EbIndex_Tagged:
	 return m_tagged ? m_tagged->indexLocation(N) : NSR ;
      case EbIndex_Updates:
	 return m_updates ? m_updates->indexLocation(N) : NSR ;
      case EbIndex_Struct:
	 return m_struct ? m_struct->indexLocation(N) : NSR ;
      default:
	 FrMissedCase("EBMTIndex::selectIndex") ;
	 return (uint32_t)EbINDEX_NO_SUCH_RECORD ;
      }
#undef NSR
}

//----------------------------------------------------------------------
// ABP

FrList *EBMTIndex::getContext(uint32_t exampleNumber, uint32_t lines)
{
   FrList *clist = 0 ;
   uint32_t first = (exampleNumber > lines) ? exampleNumber - lines : 0 ;
   uint32_t last = exampleNumber + lines ;
   if (last >= numSentencePairs())
      last = numSentencePairs() - 1 ;
   for (uint32_t x = first ; x <= last ; x++)
      {
      // I had errors when I tried using getExample so I just borrowed
      //    the relevant code
      // I still get the following from EbSentence (on numbers?):
      // Programming Error: missed case in switch statement in decode_var_2

      uint32_t start = 0;
      int length = 0;

      EBMTIndex::getLinePosition(x, start, length);
      int fileNumber = (int)SUBFILE_NUMBER(x);

      char *buffer = 0;
      bool mustFree;
      if (EBMTIndex::readFile(buffer, fileNumber, start, length, mustFree))
	 {
	 EbSentence *target = new EbSentence(targetVocabulary(), buffer) ;
	 char *context = target->print() ;
	 pushlist(new FrString(context),clist) ;
	 FrFree(context) ;
	 }
      if (mustFree)
	 { 
	 FrFree(buffer); 
	 }

     /*
       EbSentence *target = 0 ;
       EbCorpusMetaInfo metainfo ;
       if(getCorpus()->getExample(x, target, metainfo, 0, true))
	  {
	  *context += FrString(target->print()) + FrString("\n");
	  }
     */
      }
   return listreverse(clist) ;
}

// ABP

//----------------------------------------------------------------------

const char *EBMTIndex::getOrigin(uint32_t example_number) const
{
   // look up the original origin of the specified translation example
   const EbDataSource *source = m_origins.find(example_number) ;
   if (source)
      return source->getName() ;
   // if we get here, the indicated example was not found
   return 0 ;
}

//----------------------------------------------------------------------

void EBMTIndex::resetDocWeights()
{
   if (!origin_ht)
      setOriginWeights(0) ;
   m_origins.resetWeights() ;
   return ;
}

//----------------------------------------------------------------------

void EBMTIndex::incrDocWeight(size_t example_number)
{
   m_origins.incrWeight(example_number) ;
   return ;
}

//----------------------------------------------------------------------

void EBMTIndex::normalizeDocWeights()
{
   m_origins.normalizeWeights() ;
   m_origins.rankSources() ;
   setExampleRanks(NUM_DOC_RANKS) ;
   return ;
}

//----------------------------------------------------------------------

double EBMTIndex::originWeight(const EbDataSource *source) const
{
   if (origin_ht && source)
      {
      // find the weight associated with the example's origin
      FrConstString sourcename(source->getName()) ;
      FrHashEntryObject key(&sourcename) ;
      FrHashEntryObject *entry = (FrHashEntryObject*)origin_ht->lookup(&key) ;
      if (entry)
	 {
	 size_t wt = (size_t)entry->getUserData() ;
	 return wt / (double)ORIGIN_WEIGHT_SCALE ;
	 }
      FrConstString nullstr("") ;
      FrHashEntryObject wildkey(&nullstr) ;
      entry = (FrHashEntryObject*)origin_ht->lookup(&wildkey) ;
      if (entry)
	 {
	 // check for wildcard matches
	 const FrList *origins = (FrList*)entry->getUserData() ;
	 for ( ; origins ; origins = origins->rest())
	    {
	    const FrList *orig = (FrList*)origins->first() ;
	    const char *pattern = orig->first()->printableName() ;
	    if (FrWildcardMatch(pattern,source->getName(),false))
	       {
	       // cache the lookup in the hash table
	       double wt = orig->second()->floatValue() ;
	       size_t o_wt = (size_t)(wt * ORIGIN_WEIGHT_SCALE + 0.5) ;
	       key.setUserData((void*)o_wt) ;
	       origin_ht->add(&key) ;
	       return wt ;
	       }
	    }
	 }
      }
   return m_deforiginweight ;
}

//----------------------------------------------------------------------

double EBMTIndex::documentWeight(size_t example_number) const
{
   if (m_origins.haveWeights())
      {
      const EbDataSource *source = m_origins.find(example_number) ;
      if (source)
	 return source->weight() ;
      }
   return 0.0 ;
}

//----------------------------------------------------------------------

double EBMTIndex::originWeight(size_t example_number,
			       const EbDataSource *source) const
{
   // look up the original origin of the specified translation example
   if (!source)
      source = m_origins.find(example_number) ;
   return originWeight(source) ;
}

//----------------------------------------------------------------------

size_t EBMTIndex::originRank(size_t example_number, size_t num_ranks) const
{
   if (m_exampleranks && example_number < numSentencePairs())
      return m_exampleranks[example_number] ;
   const EbDataSource *source = m_origins.find(example_number) ;
   if (!source)
      return 0 ;
   size_t rank = source->rank() ;
   if (m_origins.haveWeights())
      {
      double per_level = 1.0 ;
      if (num_ranks)
	 per_level = ((double)m_origins.numSources()) / num_ranks ;
      return (size_t)(rank / per_level) ;
      }
   else
      {
      if (num_ranks == 0)
	 num_ranks = 100 ;
      return (size_t)(originWeight(source) * (num_ranks - 1)) ;
      }
}

// end of file ebindex.cpp //
