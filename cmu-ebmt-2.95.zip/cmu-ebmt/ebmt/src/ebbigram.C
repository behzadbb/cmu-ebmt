/************************************************************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.91							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebbigram.cpp	filtering by inverse bigram frequency		*/
/*  LastEdit: 14feb10							*/
/*									*/
/*  (c) Copyright 1998,1999,2000,2001,2004,2006,2007,2009,2010		*/
/*		 Ralf Brown						*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "FramepaC.h"
#include "ebcorpus.h"
#include "ebtoken.h"
#include "ebutil.h"
#include "ebmt.h"
#include "ebglobal.h"

/************************************************************************/
/*	Manifest constants						*/
/************************************************************************/

#ifndef PATH_MAX
#  define PATH_MAX 127
#endif

#define SCALE_FACTOR 1000000
#define UNSEEN_SCORE (12*SCALE_FACTOR)	// this*255 should be less than 2**32

#define INITIAL_SYMTAB_SIZE 500000

#define DISCARDED ((uint32_t)~0U)

#define MMR_CHUNK_SIZE	1000		// (re)alloc MMR scores in multiples

/************************************************************************/
/*    helper functions							*/
/************************************************************************/

static bool erase_count(const FrObject *obj, va_list)
{
   FrSymbol *sym = (FrSymbol*)obj ;
   sym->setFrame(0) ;
   return true ;			// continue iteration
}

//----------------------------------------------------------------------

static void erase_count_symtab(FrSymbolTable *symtab)
{
   if (symtab)
      symtab->iterate(erase_count,0) ;
}

/************************************************************************/
/************************************************************************/

static size_t tokenize_sentences(FILE *infp, FILE *outfp)
{
   size_t num_sents = 0 ;
   if (!active_EBMT())
      return 0 ;
   EBMTCorpus *corpus = active_EBMT()->getCorpus() ;
   if (!corpus)
      return 0 ;
   EBMTIndex *index = corpus->getIndex() ;
   while (!feof(infp))
      {
      char *ssent, *tsent, *tags ;
      if (read_EBMT_entry(infp,0,ssent,tsent,tags,true,
			  source_regex_list,target_regex_list,abbrevs_list))
	 {
	 FrList *swords = FrCvtSentence2Wordlist(ssent) ;
	 FrTextSpans *slattice = new FrTextSpans(swords) ;
	 FrList *twords = FrCvtSentence2Symbollist(tsent,char_encoding) ;
	 BiTextMap *bitext = 0 ;
	 bitext = new BiTextMap(swords,swords,twords,0) ; // do we need this?
	 free_object(swords) ;
	 FrList *tok = index->tokenize(slattice,twords,bitext) ;
	 delete bitext ;
	 delete slattice ;
	 free_object(twords) ;
	 if (tok && tok->first())
	    {
	    FrString *source = new FrString((FrList*)tok->first()) ;
	    //!!! if Unicode, we need to decanonicalize the strings....
	    const char *printed = source->stringValue() ;
	    fputs(printed ? printed : "",outfp) ;
	    free_object(source) ;
	    fputc('\n',outfp) ;
	    num_sents++ ;
	    }
	 free_object(tok) ;
	 }
      FrFree(ssent) ;
      FrFree(tsent) ;
      FrFree(tags) ;
      }
   if (verbose && showmem)
      FrMemoryStats() ;
   return num_sents ;
}

//----------------------------------------------------------------------

static uint32_t compute_MMR(const FrList *words, uint32_t scale_factor,
			    uint32_t unseen_score)
{
   size_t len = words->listlength() ;
   uint32_t score = 0 ;
   if (len > 1)
      {
      FrSymbol *word1 = (FrSymbol*)words->first() ;
      words = words->rest() ;
      for (size_t i = 1 ; i < len ; i++, words = words->rest())
	 {
	 FrSymbol *word2 = (FrSymbol*)words->first() ;
	 char bigram_name[FrMAX_SYMBOLNAME_LEN+2] ;
	 if (word1 && word2 && word1->symbolp() && word2->symbolp())
	    {
	    size_t word1len = strlen(word1->symbolName()) ;
	    memcpy(bigram_name,word1->symbolName(),word1len) ;
	    bigram_name[word1len] = ' ' ;
	    strncpy(bigram_name+word1len+1,word2->symbolName(),
		    FrMAX_SYMBOLNAME_LEN-word1len) ;
	    bigram_name[FrMAX_SYMBOLNAME_LEN+1] = '\0' ;
	    FrSymbol *bigram = FrSymbolTable::add(bigram_name) ;
	    if (bigram)
	       {
	       // ugly hack to save space&time: stuff count into "frame" field
	       size_t count = (size_t)bigram->symbolFrame() ;
	       if (count == 0)
		  score += unseen_score ;
	       else
		  score += (scale_factor + count/2) / count ;
	       bigram->setFrame((FrFrame*)(count+1)) ;
	       }
	    }
	 word1 = word2 ;
	 }
      len-- ;
      return (score + len/2) / len ;
      }
   else
      return score ;
}

//----------------------------------------------------------------------

static size_t compute_MMRs(FILE *tokfp, FrSymbolTable *bigrams,
			   uint32_t *&MMRs,size_t num_MMRs,uint32_t threshold)
{
   if (!MMRs)
      {
      MMRs = FrNewC(uint32_t,num_MMRs+1) ;
      if (!MMRs)
	 {
	 FrNoMemory("while computing MMR scores") ;
	 return num_MMRs ;
	 }
      }
   fseek(tokfp,0L,SEEK_SET) ;
   size_t i = 0 ;
   size_t remaining = 0 ;
   FrSymbolTable *sym_t = bigrams->select() ;
   while (!feof(tokfp) && i < num_MMRs)
      {
      char ssent[FrMAX_LINE] ;
      if (!fgets(ssent,sizeof(ssent),tokfp))
	 break ;
      if (MMRs[i] != DISCARDED)
	 {
	 const char *source = ssent ;
	 FrList *swords = (FrList*)string_to_FrObject(source) ;
	 if (swords)
	    {
	    FrList *src = EbFixDottedList(swords) ;
	    swords->freeObject() ;
	    MMRs[i] = compute_MMR(src,SCALE_FACTOR,UNSEEN_SCORE) ;
	    free_object(src) ;
	    }
	 else
	    MMRs[i] = 0 ;
	 if (MMRs[i] >= threshold)
	    remaining++ ;
	 else
	    MMRs[i] = DISCARDED ;
	 }
      i++ ;
      }
   erase_count_symtab(bigrams) ;	// clear all counts
   sym_t->select() ;
   return remaining ;
}

//----------------------------------------------------------------------

static void sort_MMRs(uint32_t *elements, size_t numelements)
{
   static uint32_t tmp_entry ;

#define swap(x,y) { tmp_entry = x ; x = y ; y = tmp_entry ; }
   // perform a QuickSort
   while (numelements > 2)
      {
      // find a partitioning element
      uint32_t *mid = &elements[numelements/2] ;
      uint32_t *right = &elements[numelements-1] ;
      if (elements[0] < *mid)
	 swap(elements[0],*mid) ;
      if (elements[0] < *right)
	 swap(elements[0],*right) ;
      if (*mid < *right)
	 swap(*mid,*right) ;
      if (numelements <= 3)
	 break ;			// we already sorted the entire range
      // partition the array
      swap(*mid,*right) ;		// put partition elt at end of array
      uint32_t partval = *right ;
      size_t part = 0 ;
      right-- ;
      do {
	 while (elements[part] >= partval &&
		&elements[part] <= right)
	    part++ ;
	 while (*right <= partval && right >= &elements[part])
	    right-- ;
	 swap(elements[part],*right) ;
	 } while (&elements[part] < right) ;
      swap(*right,elements[part]) ;
      swap(elements[part],elements[numelements-1]) ;
      // sort each half of the array
      if (part >= numelements-part)
	 {
	 // left half is larger, so recurse on smaller right half
	 size_t half = numelements-part-1 ;
	 if (half > 1)			// no need to recurse if only one elt
	    sort_MMRs(elements+part+1,half) ;
	 numelements = part ;
	 }
      else
	 {
	 // right half is larger, so recurse on smaller left half
	 if (part > 1)			// no need to recurse if only one elt
	    sort_MMRs(elements,part) ;
	 elements += part+1 ;
	 numelements -= part+1 ;
	 }
      }
   // when we get to this point, we have at most two items left;
   // a single item is already sorted by definition, and two items need at
   //   most a simple swap
   if (numelements == 2 && elements[0] < elements[1])
      swap(elements[0],elements[1]) ;
#undef swap
   return ;
}

//----------------------------------------------------------------------

static uint32_t find_MMR_threshold(const uint32_t *MMRs, size_t num_MMRs,
				   size_t desired)
{
   if (verbose)
      cout << ";\tdetermining threshold score" << endl ;
   // step 1: see whether any pruning is needed
   if (desired >= num_MMRs)
      return 0 ;			// keep all
   // step 2: sort the MMR scores into descending order
   FrLocalAlloc(uint32_t,sortedMMRs,250000,num_MMRs) ;
   if (!sortedMMRs)
      {
      FrNoMemory("while sorting scores") ;
      return 0 ;
      }
   for (size_t i = 0 ; i < num_MMRs ; i++)
      sortedMMRs[i] = (MMRs[i] == DISCARDED) ? 0 : MMRs[i] ;
   sort_MMRs(sortedMMRs,num_MMRs) ;
   // step 3: find the 'desired'th score and return that as threshold
   if (desired == 0)
      desired = 1 ;
   uint32_t threshold = sortedMMRs[desired-1] ;
   FrLocalFree(sortedMMRs) ;
   if (verbose)
      cout << ";\tthreshold = " << threshold << endl ;
   return threshold ;
}

//----------------------------------------------------------------------

static size_t extract_MMR(const uint32_t *MMRs, size_t num_MMRs,
			  size_t &sentcount, FILE *infp, FILE *outfp)
{
   size_t num_extracted = 0 ;
   while (!feof(infp))
      {
      char *ssent, *tsent, *tags ;
      if (read_EBMT_entry(infp,0,ssent,tsent,tags,true,
			  source_regex_list,target_regex_list,abbrevs_list))
	 {
	 if (sentcount < num_MMRs && MMRs[sentcount++] != DISCARDED)
	    {
	    //!!! if Unicode, we need to decanonicalize the strings....
	    if (tags)
	       {
	       fputs(tags,outfp) ;
	       fputc('\n',outfp) ;
	       }
	    fputs(ssent,outfp) ;
	    fputc('\n',outfp) ;
	    if (!monolingual_data)
	       {
	       fputs(tsent,outfp) ;
	       fputc('\n',outfp) ;
	       }
	    num_extracted++ ;
	    }
//	 else
//	       cerr << "; eliminated ("<<MMRscore<<") "<<swords<<endl ;
	 }
      FrFree(ssent) ;
      FrFree(tsent) ;
      FrFree(tags) ;
      }
   if (verbose)
      cout << "; extracted " << num_extracted << " lines/pairs" << endl ;
   return num_extracted ;
}

//----------------------------------------------------------------------

bool extract_MMR_lines(const char *outfile, FILE *infp, size_t desired,
			 size_t max_allowed, size_t max_passes)
{
   if (!infp || !outfile || !*outfile)
      {
      FrWarning("missing input or output file") ;
      return false ;
      }
   FILE *outfp = fopen(outfile,"w") ;
   if (!outfp)
      {
      FrWarning("unable to create output file") ;
      return false ;
      }
   char *tokfile = FrForceFilenameExt(outfile,"MMR") ;
   FILE *tokfp = fopen(tokfile,"w+") ;
   if (!tokfp)
      {
      cerr << "; unable to create temporary file!" << endl ;
      return false ;
      }
   size_t num_sents = 0 ;
   FrTimer timer ;
   if (use_stdin)
      {
      cout << "; tokenizing standard input" << endl ;
      num_sents = tokenize_sentences(infp,tokfp) ;
      }
   else
      {
      while (!feof(infp))
	 {
	 char filename[PATH_MAX+1] ;
	 filename[0] = '\0' ;
	 fgets(filename,sizeof(filename),infp) ;
	 if (filename[strlen(filename)-1] == '\n')
	    filename[strlen(filename)-1] = '\0' ;
	 if (filename[0] && filename[0] != '#')
	    {
	    FILE *fp = fopen(filename,"r") ;
	    if (fp)
	       {
	       cout << "; tokenizing " << filename << endl ;
	       num_sents += tokenize_sentences(fp,tokfp) ;
	       fclose(fp) ;
	       }
	    else
	       FrWarningVA("unable to open '%s' -- skipped",filename) ;
	    }
	 }
      }
   if (verbose)
      cout << "; tokenizing took " << timer.readsec() << " seconds" << endl ;
   fseek(infp,0L,SEEK_SET) ;		// return to start of corpus or listing
   if (num_sents == 0)
      {
      fclose(tokfp) ;
      Fr_unlink(tokfile) ;
      FrFree(tokfile) ;
      return true ;
      }
   uint32_t *MMRs = 0 ;
   size_t passnumber = 1 ;
   size_t remaining ;
   if (max_allowed < desired)
      max_allowed = desired ;
   timer.start() ;
   FrSymbolTable *bigrams = new FrSymbolTable(INITIAL_SYMTAB_SIZE) ;
   if (!bigrams)
      {
      FrNoMemory("while initializing MMR extraction") ;
      return false ;
      }
   do {
      cout << "; Pass " << passnumber << endl ;
      if (verbose)
	 cout << ";\tcomputing scores... " << flush ;
      remaining = compute_MMRs(tokfp,bigrams,MMRs,num_sents,0) ;
      if (verbose)
	 cout << "collected MMR scores for " << remaining << " sentences"
	      << endl ;
      uint32_t threshold = find_MMR_threshold(MMRs,num_sents,desired) ;
      if (threshold > 0)
	 {
	 if (verbose)
	    cout << ";\tselecting sentences above threshold of " << threshold
		 << endl ;
	 remaining = compute_MMRs(tokfp,bigrams,MMRs,num_sents,threshold) ;
	 }
      else
	 {
	 if (passnumber == 1)
	    cout << ";\tnothing needs to be removed" << endl ;
	 remaining = num_sents ;
	 break ;
	 }
      if (verbose && remaining > max_allowed)
	 cout << ";\t" << remaining << " lines/pairs remain" << endl ;
      } while (remaining > max_allowed && passnumber++ < max_passes) ;
   if (verbose)
      cout << "; finding best sentences took "
	   << timer.readsec() << " seconds" << endl ;
// for some reason, the following causes a duplicate free in shutdown_FramepaC
//!!!   delete bigrams ;
   fclose(tokfp) ;
   Fr_unlink(tokfile) ;
   FrFree(tokfile) ;
   cout << "; extracting remaining " << remaining << " lines/pairs" << endl ;
   size_t sentcount = 0 ;
   if (use_stdin)
      remaining = extract_MMR(MMRs,num_sents,sentcount,infp,outfp) ;
   else
      {
      while (!feof(infp))
	 {
	 char filename[PATH_MAX+1] ;
	 filename[0] = '\0' ;
	 fgets(filename,sizeof(filename),infp) ;
	 if (filename[strlen(filename)-1] == '\n')
	    filename[strlen(filename)-1] = '\0' ;
	 if (filename[0] && filename[0] != '#')
	    {
	    FILE *fp = fopen(filename,"r") ;
	    if (fp)
	       {
	       cout << "; extracting from " << filename << endl ;
	       remaining += extract_MMR(MMRs,num_sents,sentcount,fp,outfp) ;
	       fclose(fp) ;
	       }
	    else
	       FrWarningVA("unable to open '%s' -- skipped",filename) ;
	    }
	 }
      }
   if (outfp)
      fclose(outfp) ;
   if (verbose && showmem)
      FrMemoryStats() ;
   return true ;
}

// end of file ebbigram.cpp //
