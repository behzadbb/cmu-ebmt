/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebtoken.h	word/phrase tokenizer				*/
/*  LastEdit: 08apr10							*/
/*									*/
/*  (c) Copyright 1996,1997,1998,1999,2001,2002,2003,2004,2005,2006,	*/
/*		2007,2008,2009,2010 Ralf Brown				*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __EBTOKEN_H_INCLUDED
#define __EBTOKEN_H_INCLUDED

#include "FramepaC.h"
#include "ebsetup.h"

#if defined(__GNUC__)
#  pragma interface
#endif

/************************************************************************/
/*	Manifest Constants						*/
/************************************************************************/

#define NUMBER_TOKEN "<number>"
#define WILDCARD_TOKEN "<*>"
#define CONCATENATION_MARKER "<->"

#define CONCATENATION_TOKEN1 " <-> "
#define CONCATENATION_TOKEN2 "<_ _>"
#define FAILED_CONCAT_TOKEN1 "<_ "
#define FAILED_CONCAT_TOKEN2 " _>"

#define TOKEN_FILE_SIGNATURE "EBMT Tokenizations"
#define TOKEN_COMMENT_CHAR ';'

#define EbTOKEN_START '<'
#define EbTOKEN_END   '>'

/************************************************************************/
/************************************************************************/

class BiTextMap ;
class Dictionary ;
class EbAlignConstraints ;
class EBMTCorpus ;
class EBMTIndex ;

/************************************************************************/
/************************************************************************/

class TokenInfo
   {
   private:
      static FrAllocator allocator ;
      TokenInfo* m_next ;
      FrList*    m_trg ;
      uint32_t*  m_wordIDs ;
      const FrTextSpan *m_span ;	// span in lattice to which this corrsp
      size_t     m_length ;
      size_t     m_sourcewords ;	// number of wordIDs
      size_t	 m_inputwords ;		// number of words matched in input
      uint32_t	 m_equivclass ;
      bool	 m_istok ;
      double	 m_prob ;
   private:
      void init(size_t len, uint32_t id, size_t srcwords = 1) ;
   public:
      void *operator new(size_t) { return allocator.allocate() ; }
      void operator delete(void *blk) { allocator.release(blk) ; }
      TokenInfo() { m_wordIDs = 0 ; m_sourcewords = 0 ; m_length = 0 ;
      		    m_inputwords = 0 ; m_trg = 0 ; m_next = 0 ;
		    m_span = 0 ; m_prob = 1.0 ; 
		    m_equivclass = FrVOCAB_WORD_NOT_FOUND ; m_istok = false; }
      TokenInfo(uint32_t id,size_t len,const FrList *trg,TokenInfo *nxt = 0) ;
      TokenInfo(uint32_t id,size_t len,FrString *trg,TokenInfo *nxt = 0,
		size_t srcwords = 1) ;
      TokenInfo(size_t words, const uint32_t *ids, size_t len, FrString *trg,
		TokenInfo *nxt = 0) ;
      ~TokenInfo() ;

      static int compare(const TokenInfo &, const TokenInfo &) ;

      // modifiers
      void setNext(TokenInfo *next) { m_next = next ; }
      void isToken(bool tok) { m_istok = tok ; }
      void inEquivClass(uint32_t tokenid) { m_equivclass = tokenid ; }
      void setProb(double prob) { m_prob = prob ; }
      void setSpan(const FrTextSpan *span) { m_span = span ; }
      void setInputWords(size_t words) { m_inputwords = words ; }
      void addTranslation(const FrString *trans)
	 { if (trans) pushlist(trans->deepcopy(),m_trg) ; }

      // accessors
      TokenInfo *next() const { return m_next ; }
      const FrString *translation() const
	 { return m_trg ? (FrString*)m_trg->first() : 0 ; }
      const FrList *translations() const { return m_trg ; }
      size_t length() const { return m_length ; }
      size_t sourceWords() const { return m_sourcewords ; }
      size_t inputWords() const { return m_inputwords ; }
      double probability() const { return m_prob ; }
      const FrTextSpan *span() const { return m_span ; }
      bool isToken() const { return m_istok ; }
      uint32_t wordID() const { return m_wordIDs[0] ; }
      uint32_t wordID(size_t N) const
         { return N < sourceWords() ? m_wordIDs[N] : FrVOCAB_WORD_NOT_FOUND ; }
      uint32_t equivalenceClass() const { return m_equivclass ; }
      
      // debugging
      void dump(ostream &out) const ;
   } ;

/************************************************************************/
/************************************************************************/

class Tokenizer
   {
   private:
      static FrAllocator allocator ;
      FrRegExp *m_regexlist ;
      EBMTCorpus *m_tempcorpus ;
      char *m_tempdir ;
      FrList *m_pending ;		// pending additions to tempcorpus
   private:
      void init() ;
   public:
      void *operator new(size_t) { return allocator.allocate() ; }
      void operator delete(void *blk) { allocator.release(blk) ; }
      Tokenizer() { init() ; }
      Tokenizer(const char *filename) ;
      ~Tokenizer() ;

      bool loadTokens(const char *filename) ;
      bool augmentDictionary(Dictionary *) const ;

      void setTemporaryCorpus(EBMTCorpus *corpus) { m_tempcorpus = corpus ; }
      bool setTemporaryCorpus(const char *dict_file, 
			      const char *parent_dir = 0) ;
      bool addTokenization(FrSymbol *equiv_class, const FrList *src,
			   const FrList *trg) ;
      bool addTokenizations(FrSymbol *equiv_class, const FrList *equivs,
			    bool reverse = false) ;
      bool setupComplete(bool force_quiet = false) ;

      FrSymbol *regexGeneralization(const char *word,
				    FrCasemapTable number_charmap,
				    FrString *&translation) const ;

      FrList *tokenize(FrTextSpans *stext,
		       const FrList *targetwords,
		       EBMTCorpus *corpus, BiTextMap *bitext = 0) const ;
      FrList *tokenize(FrTextSpans *stext, EBMTCorpus *corpus) const ;
   } ;

//----------------------------------------------------------------------

bool convert_token_file(const char *infile, EBMTIndex *index) ;

bool is_token(const char *word) ;
bool is_token(FrSymbol *obj) ;
bool is_token(const FrObject *obj) ;

bool contains_tokens(const FrList *words) ;

bool token_equal(FrSymbol *s1, FrSymbol *s2) ;
bool token_equal(FrSymbol *o1, const FrObject *o2) ;
inline bool token_equal(const FrObject *o1, FrSymbol *o2)
   { return token_equal(o2,o1) ; }
bool token_equal(const FrObject *o1, const FrObject *o2) ;

char *EbStripCoindex(const char *word, FrCharEncoding encoding) ;

#endif /* !__EBTOKEN_H_INCLUDED */

// end of file ebtoken.h //
