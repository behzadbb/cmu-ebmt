/************************************************************************/
/*									*/
/*  Pangloss -- Example-Based Machine Translation			*/
/*  Version 1.99							*/
/*	by Ralf Brown							*/
/*									*/
/*  File ebwrdloc.cpp		word-location map			*/
/*  LastEdit: 03jun04							*/
/*									*/
/*  (c) Copyright 2001,2004 Ralf Brown					*/
/*	This software may be used for educational and non-commercial	*/
/*	research purposes.  Any other use requires prior permission	*/
/*	from Ralf Brown or the Carnegie Mellon University Language	*/
/*	Technologies Institute.						*/
/*									*/
/************************************************************************/

#if defined(__GNUC__)
#  pragma implementation "ebwrdloc.h"
#endif

#include "ebwrdloc.h"

/************************************************************************/
/*	Methods for class EBMTWordLoc					*/
/************************************************************************/

void EBMTWordLoc::makeNew(const FrList *words, const FrList *analysis,
			  EBMTWordLoc *&locs, size_t &num_locs,
			  FrCharEncoding enc)
{
   size_t count = words->simplelistlength() ;
   for (const FrList *a = analysis ; a ; a = a->rest())
      {
      FrList *ana = (FrList*)a->first() ;
      if (ana)
	 {
	 if (ana->consp())
	    count += ana->simplelistlength() ;
	 else
	    count++ ;
	 }
      }
   EBMTWordLoc *locations = FrNewN(EBMTWordLoc,count+1) ;
   count = 0 ;
   size_t i ;
   for (i = 0 ; words ; words = words->rest(), i++)
      {
      FrObject *word = words->first() ;
      if (word)
	 new (&locations[count++]) EBMTWordLoc(FrCvt2Symbol(word,enc),i);
      }
   for (i = 0 ; analysis ; analysis = analysis->rest(), i++)
      {
      FrList *ana = (FrList*)analysis->first() ;
      if (!ana)
	 continue ;
      if (ana->consp())
	 {
	 for ( ; ana ; ana = ana->rest())
	    {
	    FrSymbol *w = FrCvt2Symbol(ana->first(),enc) ;
	    if (w)
	       new (&locations[count++]) EBMTWordLoc(w,i) ;
	    }
	 }
      else
	 new (&locations[count++]) EBMTWordLoc(FrCvt2Symbol((FrObject*)ana,
							    enc),i);
      }
   locations->sort(count) ;
   // strip out any duplicates
   size_t dest = 0 ;
   for (i = 1 ; i < count ; i++)
      {
      if (EBMTWordLoc::compare(locations[dest],locations[i]) != 0)
	 locations[++dest] = locations[i] ;
      }
   if (count > 0)
      dest++ ;
   // add the sentinel that will keep us from running off the end
   new (&locations[dest]) EBMTWordLoc(0,(size_t)~0) ;
   num_locs = dest ;
   locs = locations ;
   return ;
}

//----------------------------------------------------------------------

const EBMTWordLoc *EBMTWordLoc::find(FrSymbol *wanted, size_t num_locs) const
{
   if (num_locs > 0)
      {
      size_t lo = 0 ;
      size_t hi = num_locs ;
      // perform a binary search for the first occurrence of the word
      while (hi > lo)
	 {
	 size_t mid = (lo+hi) / 2 ;
	 const FrSymbol *midname = this[mid].getWord() ;
	 if (wanted > midname)
	    lo = mid + 1 ;
	 else
	    hi = mid ;
	 }
      if (lo < num_locs && this[lo].getWord() == wanted)
	 return &this[lo] ;
      }
   // if we get here, the desired word is not in our list
   return 0 ;
}

// end of file ebwrdloc.cpp //
