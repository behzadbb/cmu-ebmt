// quick-and-dirty test rig for class EbMatchStatisticsEngine
#include "ebstats.h"
#include "ebmt.h"

int main(int argc, char **argv)
{
   if (argc < 2)
      {
      fprintf(stderr,"Usage: %s ebmt-directory\n",argv[0]) ;
      return 1 ;
      }
   // some EBMT initialization before we can start the actual lookups:
   EbSetCharEncoding("Latin-1") ;
   EBMT_quiet_mode(true) ;
   // end of EBMT initialization
   EbMatchStatisticsEngine engine(argv[1]) ;
   if (engine.OK())
      {
      while (!feof(stdin))
	 {
	 char line[FrMAX_LINE] ;
	 if (!fgets(line,sizeof(line),stdin))
	    break ;
	 EbMatchStatistics *stats = engine.getStatistics(line) ;
	 if (stats)
	    {
	    fprintf(stdout,"for text: %s\n",stats->text()) ;
	    for (size_t start = 0 ; start < stats->length() ; start++)
	       {
	       fprintf(stdout,"%u:",(unsigned)start) ;
	       for (size_t end = start ; end < stats->length() ; end++)
		  {
		  size_t len = end - start + 1 ; 
		  unsigned count = stats->getCount(start,len) ;
		  if (count > 0)
		     fprintf(stdout," %u=%u",(unsigned)len,count) ;
		  }
	       fprintf(stdout,"\n") ;
	       }
	    }
	 }
      }
   return 0 ;
}
