/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebmorph.C	code to analyze morphologial variants	        */
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009 Ralf Brown and			*/
/*			 Aaron B. Phillips				*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "ebmorph.h"
#include "ebchunks.h"
#include "ebutil.h"
#include "ebglobal.h"
#include <list>
#include <map>
#include <string>
#include <sstream>

#ifdef USE_MORPH_LM
#include "lmodel.h"
#include "lmngram.h"
#include "math.h"
#endif

//----------------------------------------------------------------------

// #####################################################################
// Initial Declarations
// #####################################################################

typedef std::list<EbGeneralizationRule*> EbGeneralizationRules;
typedef std::map<EbGeneralizations*, double, compare_generalizations> EbGeneralizationWeights;

//----------------------------------------------------------------------

static FrList *feature_set_match(const FrList *feat1, const FrList *feat2);
static FrList *feature_set_nomatch(const FrList *feat1, const FrList *feat2);
static bool feature_set_diff(const FrList *feat1, const FrList *feat2);
static FrList *feature_set_update(const FrList *features, const FrList *feat1, const FrList *feat2);
static FrList *feature_set_dedupe(FrList *feat);

// #####################################################################
// Global variables
// #####################################################################

static FrList *generalization_types = new FrList(makeSymbol("MORPH_SURFACE"));
static size_t total_generalization_types = 1;
static size_t *generalization_counts = 0;

// #####################################################################
// MetaInfo
// #####################################################################

//----------------------------------------------------------------------

static FrSymbol *get_morph_key(const FrList *morph)
{
  if(morph->length() == 1 && ((FrList*)morph->first())->length() == 1)
    return FrCvt2Symbol(((FrList*) morph->first())->first(), FrChEnc_RawOctets);
  return 0;
}

//----------------------------------------------------------------------

static FrList *get_metainfo(FrSymbol *key)
{
  if(key)
    {
      FrSymHashEntry *item = metainfo_ht->lookup(key);
      if(item)
	return (FrList*) item->getValue();
    }
  cerr << "Warning: Unable to load metainfo for " << key << endl;
  return 0;
}

//----------------------------------------------------------------------

void load_metainfo() {
  if (!metainfo_file || !use_morph)
    return ;
  if(metainfo_ht) {
    cerr << "Warning: Metainfo already loaded once!" << endl;
    return ;
  }

  istream *in = new ifstream(metainfo_file) ;
  if (in && in->good())
    {
      metainfo_ht = new FrSymHashTable ;
      while (!in->eof() && !in->fail())
	{
	  FrObject *obj ;
	  (*in) >> obj ;
	  if (obj)
	    {
	      if(obj->consp())
		{
		  FrList *entry = (FrList*) obj;
		  FrSymbol *surface = FrCvt2Symbol(poplist(entry), FrChEnc_RawOctets);
		  if (surface)
		    {
		      if(entry)
			{
			  FrSymHashEntry *item = metainfo_ht->lookup(surface) ;
			  if (item)
			      cerr << "Warning: Multiple metainfo entries for " << surface
				   << " (ignoring all but first)" << endl;
			  else
			    metainfo_ht->add(surface, entry) ;
			}
		      else
			free_object(surface);
		    }
		  else
		    free_object(entry);
		}
	      else if (obj->numberp())
		{
		  metainfo_ht->expandTo(obj->intValue()) ;
		  obj->freeObject() ;
		}
	      else
		obj->freeObject();
	    }
	}
    }
  delete in;
  return;
}

//----------------------------------------------------------------------

static bool clear_entry(FrSymHashEntry *entry, va_list)
{
  if (entry) {
    free_object((FrObject*)entry->getName()) ;
    free_object((FrObject*)entry->getUserData()) ;
  }
  return true ;                        // continue iterating
}

//----------------------------------------------------------------------

void clear_metainfo()
{
  if(!use_morph)
    return;
  if (metainfo_ht)
    {
      metainfo_ht->doHashEntries(clear_entry,0) ;
      delete metainfo_ht ;
      metainfo_ht = 0 ;
    }
  return ;
}

//----------------------------------------------------------------------

// #####################################################################
// Generalization Weights
// #####################################################################

//----------------------------------------------------------------------

EbGeneralizationWeights *generalization_weights;

//----------------------------------------------------------------------

void load_generalization_weights() {
  if (!weights_file || !use_morph)
    return ;
  if(generalization_weights) {
    cerr << "Warning: Generalization weights already loaded once!" << endl;
    return ;
  }
  istream *in = new ifstream(weights_file) ;
  if (in && in->good())
    {
      generalization_weights = new EbGeneralizationWeights();
      while (!in->eof() && !in->fail())
	{
	  FrObject *obj ;
	  (*in) >> obj ;
	  if (obj)
	    {
	      if(obj->consp())
		{
		  FrList *generalizations = (FrList*) obj;
		  if (generalizations)
		    {
		      FrFloat *weight = (FrFloat*) poplist(generalizations);
		      if(weight)
			{
			  EbGeneralizations *g = EbGeneralizations::build(generalizations);
			  if(g)
			    {
			      double s = weight->floatValue();
			      generalization_weights->insert( make_pair(g, s) );
			    }
			  free_object(weight);
			}

		      free_object(generalizations);
		    }
		}
	      else
		obj->freeObject();
	    }
	}
    }
  delete in;
  return;
}

//----------------------------------------------------------------------

void clear_generalization_weights() {
  if(generalization_weights)
    {
      for(EbGeneralizationWeights::iterator iter = generalization_weights->begin();
	  iter != generalization_weights->end(); )
	{
	  delete iter->first;
	  generalization_weights->erase(iter++);
	}
      delete generalization_weights;
    }
  return;
}

//----------------------------------------------------------------------

// #####################################################################
// Generalization Rules
// #####################################################################

//----------------------------------------------------------------------

EbGeneralizationRules *generalization_rules;

//----------------------------------------------------------------------

const char* EbGeneralizationRule::ops = "{[<>]}";

//----------------------------------------------------------------------

void EbGeneralizationRule::setRule(size_t op, FrString *rule, size_t rule_begin, size_t rule_split, size_t rule_end)
{
  if(op > 6)
    {
      cerr << "Warning: Attempting to set non-existant rule" << endl;
      return;
    }

  if(rule_end == (size_t) ~0)
    rule_end = rule_split;

  FrString *match;
  FrString *repl;
  if(rule_begin == (size_t) ~0)
    {
      if(rule_end == (size_t) ~0)
	{
	  match = new FrString(".*");
	  repl = new FrString("");
	}
      else
	{
	  cerr << "Warning: Invalid rule, regular expression not delimited by / characters" << endl;
	  return;
	}
    }
  else
    {
      match = (FrString*) rule->subseq(rule_begin+1, rule_split-1);
      repl = (FrString*) rule->subseq(rule_split+1, rule_end-1);
    }
  
  if(repl->stringLength() == 0)
    {
      // Only Match
      if(rule_split == rule_end)
	{
	  rules[op] = (new FrString("("))->append(match)->append(")");
	  repl->append("%1");
	}
      // Deletion
      else
	{
	  rules[op] = match;
	}
      repls[op] = new FrList(repl);
    }
  // Replacement (with a list of alternatives)
  else
    {
      rules[op] = match;
      FrObject *obj;
      stringstream stream(repl->stringValue());
      stream >> obj;
      repls[op] = (FrList*) obj;
    }
}

//----------------------------------------------------------------------

EbGeneralizationRule::EbGeneralizationRule(FrSymbol *gen, FrList *src, FrList *tgt, FrString *rule)
{
  generalization = gen;
  src_match = src;
  tgt_match = tgt;

  memset(rules, 0, sizeof(FrString*) * 7);
  memset(repls, 0, sizeof(FrList*) * 7);

  bool escaped = false;
  int op = 0;
  size_t rule_split = ~0;
  size_t rule_begin = ~0;
  size_t rule_end = ~0;

  for(size_t i = 0; i < rule->stringLength(); i++)
    {
      char c = rule->nthChar(i);
      if(!escaped)
	{
	  if(c == '\\')
	    escaped = true;
	  else if (c == '/')
	    {
	      if(rule_begin == (size_t) ~0)
		rule_begin = i;
	      else if(rule_split == (size_t) ~0)
		rule_split = i;
	      else if(rule_end == (size_t) ~0)
		rule_end = i;
	      else
		cerr << "Warning: Invalid rule, too many / characters" << endl;
	    }
	  else
	    {
	      for(int j = 0; j < 6; j++)
		{
		  if(c == ops[j])
		    {
		      setRule(op, rule, rule_begin, rule_split, rule_end);
		      
		      op = j+1;
		      rule_begin = ~0;
		      rule_split = ~0;
		      rule_end = ~0;
		      
		      break;
		    }
		}
	    }
	}
      else
	escaped = false;
    }

  setRule(op, rule, rule_begin, rule_split, rule_end);
}

//----------------------------------------------------------------------

/* Each rule specifies a set of feature transformations. This function
   returns the set of features that would result from applying this rule
   to features such that the goal is to more closely resemble features2.
   feat_diff1 and feat_diff2 are passed along so they are not re-calculated
   for every rule. */

FrList *EbGeneralizationRule::match(const FrList *features1, const FrList *features2,
				    const FrList *feat_diff1, const FrList *feat_diff2)
{
  FrList *result = 0;

  //cerr << "Trying to match with rule " << generalization << src_match << tgt_match << endl;

  FrList *match1 = feature_set_match(src_match, features1);
  if(match1)
    {
      FrList *match2 = feature_set_match(tgt_match, features2);
      if(match2)
	{
	  // Check if this results in improvement
	  FrList *match_diff1 = feature_set_nomatch(match1, match2);
	  FrList *match_diff2 = feature_set_nomatch(match2, match1);

	  FrList *src_change = feature_set_match(match_diff1, feat_diff1);
	  FrList *tgt_change = feature_set_match(match_diff2, feat_diff2);

	  if((src_change && src_change->first()) || (tgt_change && tgt_change->first()))
	    result = feature_set_update(features1, match_diff1, match_diff2);

	  free_object(src_change);
	  free_object(tgt_change);
	  free_object(match_diff1);
	  free_object(match_diff2);
	  free_object(match1);
	  free_object(match2);
	}
      else
	{
	  free_object(match1);
	}
    }

  return result;
}

//----------------------------------------------------------------------

FrList *EbGeneralizationRule::getWordBoundaries(EBMTCandidate *cand, size_t word)
{
  FrList *result = 0;
  int tgt_pos = cand->bitext()->nextTargetCorrespondence(cand->sourceOffset()+word, cand->targetOffset()-1);
  while(tgt_pos != -1 && (size_t)tgt_pos <= cand->targetEnd())
    {
      int bound = tgt_pos-cand->targetOffset();
      pushlist(new FrList(new FrInteger(bound), new FrInteger(bound)), result);
      tgt_pos = cand->bitext()->nextTargetCorrespondence(cand->sourceOffset()+word, tgt_pos);
    }
  return result;
}

//----------------------------------------------------------------------

FrList *EbGeneralizationRule::getPhraseBoundaries(EBMTCandidate *cand, size_t word, FrList *boundaries)
{
  FrList *result = 0;

  size_t left_tgt_pos = boundaries->first()->intValue();
  size_t right_tgt_pos = boundaries->second()->intValue();
  
  size_t source_length = cand->sourceWords() ? cand->sourceWords()->simplelistlength() : 0;

  // Get the left end of the phrase due to word reordering
  size_t left_phrase_offset = 1;
  while(word+left_phrase_offset < source_length &&
	left_tgt_pos >= left_phrase_offset &&
	cand->bitext()->wordsCorrespond(cand->sourceOffset()+word+left_phrase_offset,
					cand->targetOffset()+left_tgt_pos-left_phrase_offset))
    left_phrase_offset++;
  left_phrase_offset--;
  
  // Get the right end of the phrase due to word reordering
  size_t right_phrase_offset = 1;
  while(word >= right_phrase_offset &&
	right_tgt_pos+right_phrase_offset < cand->targetLength() &&
	cand->bitext()->wordsCorrespond(cand->sourceOffset()+word-right_phrase_offset,
					cand->targetOffset()+right_tgt_pos+right_phrase_offset))
    right_phrase_offset++;
  right_phrase_offset--;
  
  size_t left_bound = left_tgt_pos-left_phrase_offset;
  size_t right_bound = right_tgt_pos+right_phrase_offset;
  
  pushlist(new FrList(new FrInteger(left_bound), new FrInteger(right_bound)), result);

  return result;
}

//----------------------------------------------------------------------

FrList *EbGeneralizationRule::getUnalignedBoundaries(EBMTCandidate *cand, FrList *boundaries)
{
  FrList *result = 0;
  
  size_t left_tgt_pos = boundaries->first()->intValue();
  size_t right_tgt_pos = boundaries->second()->intValue();

  size_t source_length = cand->sourceWords() ? cand->sourceWords()->simplelistlength() : 0;

  // Find unaligned words to the left of the phrase
  size_t left_tgt_offset = 0;
  size_t left_src_pos = 0;
  do
    {
      // Find unaligned words to the right of the phrase
      size_t right_tgt_offset = 0;
      size_t right_src_pos = 0;
      do
	{
	  FrList *entry = new FrList(new FrInteger(left_tgt_pos), new FrInteger(right_tgt_pos));
	  for(FrList* result_iter = result; result_iter; result_iter = result_iter->rest())
	    {
	      FrList *result_entry = (FrList*) result_iter->first();
	      if(entry->first()->equal(result_entry->first()) && 
		 entry->second()->equal(result_entry->second()))
		{
		  free_object(entry);
		  entry = 0;
		  break;
		}
	    }
	  if(entry)
	    pushlist(entry, result);

	  right_tgt_offset++;
	  right_src_pos = cand->bitext()->firstSourceCorrespondence(cand->targetOffset()+right_tgt_pos+right_tgt_offset,
								    cand->sourceOffset());
	}
      while(right_tgt_pos+right_tgt_offset < cand->targetLength() &&
	    right_src_pos >= cand->sourceOffset()+source_length)
	 ;
	
      left_tgt_offset++;
      left_src_pos = cand->bitext()->firstSourceCorrespondence(cand->targetOffset()+left_tgt_pos-left_tgt_offset,
							       cand->sourceOffset());
    }
  while(left_tgt_pos >= left_tgt_offset &&
	left_src_pos >= cand->sourceOffset()+source_length);

  return result;
}

//----------------------------------------------------------------------

/* Initiates a replacement by determining the covered bounds associated with the operand.
   Applies the regex rule specified by op to a bounded section of the target text of a
   list of candidates. However, the list of candidates all share the exact same text
   within the bounded window. This function will delete the incomming list of
   candidates and will return a new list of modified candidates. */

EBMTCandidate *EbGeneralizationRule::replace(EBMTCandidate *cand, size_t r, FrList *bounds[], size_t src_pos)
{
  FrString *rule = rules[r];
  FrList *repl = repls[r];

  if(!cand ||
     (!repl && (!rule || rule->stringLength() == 0)) ||
     (repl->simplelistlength() == 1 && *((FrString*) repl->first()) == "%1" && rule && *rule == "(.*)"))
    return cand;

  // end_rule is the next valid rule; this rule covers everything up end_rule
  size_t end_rule = r+1;
  while(end_rule < 7 && !rules[end_rule])
    end_rule++;

  size_t left_bound;
  if(r < 4)
    left_bound = bounds[r]->first()->intValue();
  else
    left_bound = bounds[7-r]->second()->intValue()+1;

  size_t right_bound;
  if(end_rule < 4)
    right_bound = bounds[end_rule]->first()->intValue();
  else
    right_bound = bounds[7-end_rule]->second()->intValue()+1;

  FrList *wordlist;
  if(cand->targetWords())
    wordlist = FrCvtSentence2Wordlist(cand->targetWords()->stringValue());
  else
    wordlist = new FrList(new FrString(""));
  
  if(right_bound > wordlist->length() || right_bound < left_bound)
    {
      //cerr << "Warning: replace given an invalid span [" << left_bound << " " << right_bound << "]";
      free_object(wordlist);
      cand->deleteList();
      return 0;
    }

  // This has been fixed... but it is a good thing to remember
  //
  // I'm not sure the right bound is being located properly for the phrase:
  // ORIG  "in a press" ((POS NOUN) (GEN F) (NUM P) (DEF +) (CASE GEN))
  // word = "a"; attempting to apply "(an?)" / ("%1") to span 0 - 1 : ("in" "a")
  // failed MORPH_DEF_REM1
  //
  //           { [ < > ] }
  // Bounds: 0 1 1 1 1 1 1 2
  //  Rule    0 1 2 3 4 5 6
  //                  |
  //                  new_rule
  // rule 0, end_rule 1: 0          (inclusive)
  // rule 0, end_rule 2: 0
  // rule 0, end_rule 3: 0
  // rule 0, end_rule 4: 0,1
  // rule 0, end_rule 5: 0,1
  // rule 0, end_rule 6: 0,1
  // rule 0, end_rule 7: 0,1,2
  // rule 2, end_rule 3: nil
  // rule 3, end_rule 4: 1
  // rule 3, end_rule 6: 1
  // rule 4, end_rule 6: nil
  // rule 4, end_rule 7: 2
  // left bound  when r <= 3 is bound[r]
  //             when r > 3  is bound[r]+1 
  // right bound when end_rule <= 3 is bound[end_rule]      (not inclusive)
  //             when end_rule > 3 is bound[end_rule]+1 

  EBMTCandidate *result = 0;

  for(int tgt_pos = right_bound; tgt_pos >= (int) left_bound; tgt_pos--)
    {
      FrString *orig_word = (FrString*) wordlist->getNth(tgt_pos);

      for(FrList *repl_iter = repl; repl_iter; repl_iter = repl_iter->rest())
	{
	  FrString *repl_word = (FrString*) repl_iter->first();

	  if(rule->length() == 0) 
	    {
	      // Insert
	      if(repl_word->stringLength())
		{
		  result = replace(cand, result, src_pos, ~0, tgt_pos, repl_word);
		}
	      // Allows us to have a rule like //("a" "an" "")/
	      else
		{
		  EBMTCandidate *newcand = EbCopyCandidates(cand);
		  newcand->setNext(result);
		  result = newcand;
		}
	    }
	  // We only use the right boundary for insertion
	  else if(tgt_pos < (int) right_bound) 
	    {
	      FrRegExp re(rule->stringValue(), repl_word->stringValue(), 0);
	      FrString *match_text = (FrString*) re.match(orig_word->stringValue());
	  
	      //cerr << "attempted to match " << orig_word << " with " << rule << " and repl " << repl_word << " = " << match_text << endl;

	      if(match_text)
		{
		  // Replace
		  if(repl_word->stringLength())
		    result = replace(cand, result, src_pos, tgt_pos, tgt_pos, match_text);
		  // Delete
		  else
		    result = replace(cand, result, src_pos, tgt_pos, ~0, 0);
		  
		  free_object(match_text);
		}
	    }
	}

      free_object(orig_word);
    }

  /*
    cerr << generalization
	 << " word = " << wordlist->getNth(bounds[3]->first()->intValue()) << "; attempting to apply "
	 << rule << " / " << repl << " to span "
	 << left_bound << " - " << right_bound << " : "
	 << wordlist->subseq(left_bound, right_bound) << endl;
    if(result)
      cerr << "Operation succeeded" << endl;
    else
      cerr << "Operation failed" << endl;
  */

  free_object(wordlist);
  cand->deleteList();

  return result;
}

//----------------------------------------------------------------------

EBMTCandidate* EbGeneralizationRule::replace(EBMTCandidate *cand, EBMTCandidate *result,
					     size_t src_pos, size_t elide_pos,
					     size_t insert_pos, FrString *insert_word)
{
  for(EBMTCandidate *cand_iter = cand; cand_iter; cand_iter = cand_iter->next())
    {
      EBMTCandidate *newcand = new EBMTCandidate(cand_iter);

      FrList *tmp_wordlist = FrCvtSentence2Wordlist(newcand->targetWords()->stringValue());

      bool substitute = (elide_pos != (size_t) ~0 && elide_pos == insert_pos) ? true : false;

      if(elide_pos != (size_t) ~0)
	{
	  tmp_wordlist = (FrList*) tmp_wordlist->elide(elide_pos, elide_pos);
	  if(!substitute)
	    newcand->bitext()->elideTargetWord(newcand->targetOffset()+elide_pos);
	}

      if(insert_pos != (size_t) ~0)
	{
	  // Elide returns null instead of an empty list -- is this a bug?
	  if(!tmp_wordlist && insert_pos == 0)
	    tmp_wordlist = new FrList(insert_word->deepcopy());
	  else
	    tmp_wordlist = (FrList*) tmp_wordlist->insert(insert_word, insert_pos, true);
	  if (!substitute)
	     {
	     size_t ip = newcand->targetOffset() + insert_pos ; 
	     newcand->bitext()->insertTargetWord(ip) ;
	     newcand->bitext()->setCorrespondence(newcand->sourceOffset() +
						  src_pos,
						  ip) ;
	     }
	}

      if (tmp_wordlist)
	 {
	 newcand->freeTargetWords();
	 newcand->setTargetWords(new FrString(tmp_wordlist),
				 newcand->targetOffset(),
				 newcand->targetOffset() +
				 tmp_wordlist->simplelistlength() - 1);
	 newcand->setNext(result);
	 result = newcand;
	 }

      free_object(tmp_wordlist);
    }

  return result;
}

//----------------------------------------------------------------------

/* Applies the rule to the source word in the candidate and returns a list
   of modified candidates. The incomming candidate is not a list, but the
   returned candidate is a list. */

EBMTCandidate *EbGeneralizationRule::apply(EBMTCandidate *cand, size_t word)
{
  if(!cand || !cand->bitext())
    return 0;

  EBMTCandidate *result = 0;
    
  FrList* bounds[4];
  memset(bounds, 0, sizeof(FrList*) * 4);
  bounds[0] = new FrList(new FrInteger(0), new FrInteger(cand->targetLength()-1));

  FrList *word_bounds = getWordBoundaries(cand, word);
  while(word_bounds)
    {
      bounds[3] = (FrList*) poplist(word_bounds);

      FrList *phrase_bounds = getPhraseBoundaries(cand, word, bounds[3]);
      while(phrase_bounds)
	{
	  bounds[2] = (FrList*) poplist(phrase_bounds);

	  FrList *unalign_bounds = getUnalignedBoundaries(cand, bounds[2]);
	  while(unalign_bounds)
	    {
	      bounds[1] = (FrList*) poplist(unalign_bounds);

	      /*
	      cerr << "Bounds: ";
	      for(int i = 0; i < 4; i++)
		cerr << bounds[i]->first() << " ";
	      for(int i = 3; i >= 0; i--)
		cerr << bounds[i]->second() << " ";
	      cerr << endl;
	      */

	      /*
	      if(generalization == makeSymbol("MORPH_NUM_DS5"))		  
		cerr << "----" << endl;
	      */

	      // Do the replacement from right to left so as not to mess up the bitext
	      EBMTCandidate *newcand = new EBMTCandidate(cand);
	      for(int r = 6; r >= 0 && newcand; r--)
		{
		  /*
		  if(generalization == makeSymbol("MORPH_NUM_DS5"))		  
		    cerr << "RULE " << r << " = " << rules[r] << " / " << repls[r] << endl;
		  */
		  newcand = replace(newcand, r, bounds, word);
		}

	      // Add newcands to result
	      if(newcand)
		{
		  //cerr << "GENERALIZATION TYPE " << generalization << endl;

		  size_t type = EbGeneralizations::getType(generalization->symbolName());

		  EBMTCandidate *iter = newcand;
		  while (iter)
		    {
		      iter->generalizations->set(word, type, true);
		      //cerr << "MORPH " << iter->targetWords() << endl;

		      EBMTCandidate *next = iter->next() ;
		      result = insert_unique(iter, result, false) ;
		      iter = next ;
		    }
		}

	      free_object(bounds[1]);
	    }

	  free_object(bounds[2]);
	}

      free_object(bounds[3]);
    }

  free_object(bounds[0]);

  return result;
}

//----------------------------------------------------------------------

void load_generalization_rules() {
  if(!use_morph)
    return;
  if(generalization_rules) {
    cerr << "Warning: Generalization rules already loaded once!" << endl;
    return ;
  }
  generalization_rules = new EbGeneralizationRules();
  if (!rules_file || !use_morph)
    return ;
  istream *in = new ifstream(rules_file) ;
  string buf;
  if (in && in->good())
    {
      while (!in->eof() && !in->fail())
	{
	  FrObject *obj ;
	  (*in) >> obj ;
	  if (obj)
	    {
	      if(obj->symbolp())
		{
		  FrSymbol *gen = (FrSymbol*) obj;
		  (*in) >> obj;
		  if(obj)
		    {
		      if(obj->consp())
			{
			  FrList *src_match = (FrList*) obj;
			  (*in) >> obj;
			  if(obj)
			    {
			      if(obj->consp())
				{
				  FrList *tgt_match = (FrList*) obj;
				  string rewrite_rule = "";
				  
				  // Clear buffer
				  (*in) >> ws;
				  while(in->peek() == '\n' || in->peek() == '\r') {
				    in->get();
				    (*in) >> ws;
				  }

				  if(!in->eof() && !in->fail())
				    {
				      getline(*in, rewrite_rule);
				      EbGeneralizationRule *rule = new EbGeneralizationRule(gen,
					      src_match, tgt_match, new FrString(rewrite_rule.c_str()));
				      generalization_rules->push_back(rule);

				      // This is where we load the generalization types -- from the rules
				      if(!generalization_types->member(gen))
					{
					  pushlist(gen, generalization_types);
					  total_generalization_types++;
					}
				    }
				  else
				    {
				      tgt_match->freeObject();
				      src_match->freeObject();
				      gen->freeObject();
				    }
				}
			      else {
				obj->freeObject();
				src_match->freeObject();
				gen->freeObject();
			      }
			    }
			  else {
			    src_match->freeObject();
			    gen->freeObject();
			  }
			}
		      else
			{
			  obj->freeObject();
			  gen->freeObject();
			}
		    }
		  else
		    gen->freeObject();
		}
	      else
		obj->freeObject();
	    }
	}
    }
  delete in;

  delete[] generalization_counts;
  generalization_counts = new size_t[total_generalization_types];
  memset(generalization_counts, 0, sizeof(size_t) * total_generalization_types);

  return;
}

//----------------------------------------------------------------------

void clear_generalization_rules() {
  if(generalization_rules)
    {
      for(EbGeneralizationRules::iterator iter = generalization_rules->begin();
	  iter != generalization_rules->end(); )
	{
	  delete (*iter);
	  generalization_rules->erase(iter++);
	}
      delete generalization_rules;
    }
  if(generalization_counts)
    {
      /*
      for(size_t i = 0; i < total_generalization_types; i++)
	cerr << generalization_types->getNth(i) << "\t" << generalization_counts[i] << endl;
      */
      free_object(generalization_types);
      delete[] generalization_counts;
      total_generalization_types = 0;
    }
  return;
}

//----------------------------------------------------------------------

// #####################################################################
// Generalizations
// #####################################################################

//----------------------------------------------------------------------

EbGeneralizations::EbGeneralizations(size_t w) {
  words = w;
  size_t size = words * total_generalization_types / 32 + 1;
  generalizations = FrNewN(uint32_t, size);
  memset(generalizations, 0, sizeof(uint32_t) * size);
}

//----------------------------------------------------------------------

EbGeneralizations* EbGeneralizations::build(FrList *word_list) {
  if(!word_list) {
    return 0;
  }

  EbGeneralizations *result = new EbGeneralizations(word_list->simplelistlength());

  FrList *word_list_iter = word_list;
  for(size_t w = 0; word_list_iter; w++) {
    FrList *gen_list_iter = (FrList*) word_list_iter->first();
    //if(gen_list_iter && gen_list_iter->length() > 0)
    //  set(w, getType("MORPH_SURFACE"), true); // hack to properly read rescore dumps
    while(gen_list_iter) {
      const FrSymbol *gen = (FrSymbol*) gen_list_iter->first();
      if(gen)
	{
	  size_t type = getType(gen->symbolName());
	  if(type == (size_t)-1)
	    {
	      delete result;
	      return 0;
	    }
	  result->set(w, type, true);
	}
      else
	cerr << "Warning: Invalid morphological generalization" << endl;
      gen_list_iter = gen_list_iter->rest();
    }
    word_list_iter = word_list_iter->rest();
  }

  return result;
}

//----------------------------------------------------------------------

EbGeneralizations::EbGeneralizations(EbGeneralizations *other)
{
   if (other)
      {
      words = other->words;
      size_t size = words * total_generalization_types / 32 + 1;
      generalizations = FrNewN(uint32_t, size);
      memcpy(generalizations, other->generalizations, sizeof(uint32_t) * size);
      }
   else
      {
      words = 0;
      generalizations = 0;
      }
   return ;
}

//----------------------------------------------------------------------

EbGeneralizations::~EbGeneralizations()
{
   FrFree(generalizations) ;
   return ;
}

//----------------------------------------------------------------------

size_t EbGeneralizations::getType(const char *name) {
  if(!generalization_types)
    return (size_t)-1;

  size_t i = 0;
  for(FrList *iter = generalization_types; iter; iter = iter->rest()) {
    FrSymbol *type = (FrSymbol*) iter->first();
    if(type)
      {
	if(strcmp(type->symbolName(),name) == 0)
	  return i;
	i++;
      }
    else
      cerr << "Warning: Encountered invalid generalization type" << endl;
  }
  
  //cerr << "Warning: Could not find generalization type " << name << endl;
  return (size_t)-1;
}

//----------------------------------------------------------------------

bool EbGeneralizations::get(size_t word, size_t type)
{
  if(word < words && type < total_generalization_types)
    {
      size_t index = word * total_generalization_types + type;
      size_t byte_index = index / 32;
      uint32_t bit_mask = 1 << (index % 32);
      return ( generalizations[byte_index] & bit_mask ) != 0;
    }
  return false;
}

//----------------------------------------------------------------------

void EbGeneralizations::set(size_t word, size_t type, bool value)
{
  if(word < words && type < total_generalization_types && type != (size_t)-1)
    {
      size_t index = word * total_generalization_types + type;
      size_t byte_index = index / 32;
      uint32_t bit_mask = 1 << (index % 32);
      if(value)
	generalizations[byte_index] |= bit_mask;
      else
	generalizations[byte_index] &= ~bit_mask;
    }
  else
    cerr << "Warning: Attempting to set invalid generalization value" << endl;
}

//----------------------------------------------------------------------

size_t EbGeneralizations::getWords() {
  return words;
}

//----------------------------------------------------------------------

bool EbGeneralizations::empty() {
  bool empty = true;
  for(size_t w = 0; empty && w < words; w++) {
    for(size_t t = 0; t < total_generalization_types; t++) {
      if(get(w, t)) {
        empty = false;
        break;
      }
    }
  }
  return empty;
}

//----------------------------------------------------------------------

bool EbGeneralizations::operator<(EbGeneralizations *other) {
  return (compare(other) < 0);
}

//----------------------------------------------------------------------

bool EbGeneralizations::equal(EbGeneralizations *other)
{
  return (compare(other) == 0);
}

//----------------------------------------------------------------------

int EbGeneralizations::compare(EbGeneralizations *other)
{
  if(this == other)
    return 0;

  if(!this) {
    if(other->empty())
      return 0;
    else
      return -1;
  }

  if(!other) {
    if(empty())
      return 0;
    else
      return +1;
  }

  if(words < other->words)
    return -1;

  if(words > other->words)
    return +1;

  for(size_t w = 0; w < words; w++) {
    for(size_t t = 0; t < total_generalization_types; t++) {
      bool v1 = get(w, t);
      bool v2 = other->get(w, t);
      if(v1 != v2) {
        if(!v1)
          return -1;
        else
          return +1;
      }
    }
  }

  return 0;
}

//----------------------------------------------------------------------

FrList *EbGeneralizations::display()
{
  FrList *result = 0;
  FrList **result_end = &result;

  for(size_t w = 0; w < words; w++)
    {
      FrList *word = 0;
      FrList **word_end = &word;

      for(size_t t = 0; t < total_generalization_types; t++) {
	if(get(w, t))
	  word->pushlistend(generalization_types->getNth(t), word_end);
      }

      *word_end = 0;
      result->pushlistend(word, result_end);
    }
  *result_end = 0;

  return result;
}

//----------------------------------------------------------------------

double EbGeneralizations::score() {
  if(debug_level >= 1)
    return 1.0;

  if(!generalization_weights) {
    if(empty())
      return 1.0;
    else
      return generalization_weight;
  }

  EbGeneralizationWeights::iterator weight_iter = generalization_weights->find(this);
  if(weight_iter != generalization_weights->end())
    return weight_iter->second;

  return 0.01;
}

//----------------------------------------------------------------------

// #####################################################################
// Utility Functions
// #####################################################################

//----------------------------------------------------------------------

static bool feature_names_diff(const FrList *feat1, const FrList *feat2)
{
  if (!feat1 && !feat2)			// both lists empty?
    return false;
  if (!feat1 || !feat2)			// one list empty?
    return true;

  if(feat1->first()->equal(feat2->first()))
    return false;

  return true;
}

//----------------------------------------------------------------------

/* Specifies whether the values of feat1 are exactly the same as those
   in feat2. The only difference allowed is reordering. */

static bool feature_values_diff(const FrList *feat1, const FrList *feat2)
{
   size_t len1 = feat1->simplelistlength() ;
   if (len1 < 2 && feat2->simplelistlength() < 2)
      return false;
   if (len1 != feat2->simplelistlength())
      return true;

   for (const FrList *feat1_iter = feat1->rest();
	feat1_iter ;
	feat1_iter = feat1_iter->rest())
      {
      FrObject *feat1_obj = feat1_iter->first();
      bool found = false;

      for(const FrList *feat2_iter = feat2->rest(); feat2_iter; feat2_iter = feat2_iter->rest())
	{
	  FrObject *feat2_obj = feat2_iter->first();
	  if(feat1_obj->equal(feat2_obj))
	    {
	      found = true;
	      break;
	    }
	}

      if(!found)
	return true;
    }

  return false;
}

//----------------------------------------------------------------------

static bool feature_is_neg(const FrList *feat) {
  return feat->simplelistlength() == 2 && feat->second()->equal(makeSymbol("-"));
}

//----------------------------------------------------------------------

/* Compares all features within a feature set. A feature whose only value
   is '-' is always considered to exist unless otherwise specified. */

static bool feature_set_diff(const FrList *feat1_set, const FrList *feat2_set)
{
  if(!feat1_set && !feat2_set)
    return false;

  // Cannot just compare size due to '-' features
  FrList *feat2_set_copy = feat2_set ? (FrList*) feat2_set->deepcopy() : 0;
  bool result = false;

  for(const FrList *feat1_set_iter = feat1_set; feat1_set_iter; feat1_set_iter = feat1_set_iter->rest())
    {
      FrList *feat1 = (FrList*) feat1_set_iter->first();
      bool found = false;

      FrList *feat2_set_prev = 0;
      for(FrList *feat2_set_iter = feat2_set_copy; feat2_set_iter; feat2_set_iter = feat2_set_iter->rest())
	{
	  FrList *feat2 = (FrList*) feat2_set_iter->first();
	  if(!feature_names_diff(feat1, feat2))
	    {
	      if(feature_values_diff(feat1, feat2))
		{
		  free_object(feat2_set_copy);
		  return true;
		}
	      else
		{
		  FrList *feat2_set_next = feat2_set_iter->rest();
		  if(!feat2_set_prev)
		    feat2_set_copy = feat2_set_next;
		  else
		    feat2_set_prev->replacd(feat2_set_next);
		  feat2_set_iter->replacd(0);
		  free_object(feat2_set_iter);

		  found = true;
		  break;
		}
	    }

	  feat2_set_prev = feat2_set_iter;
	}

      if(!found && !feature_is_neg(feat1))
	{
	  result = true;
	  break;
	}
    }

  // We look at everything left over in feat2_set_copy to make sure they are all negative
  for(const FrList *feat2_set_iter = feat2_set_copy; feat2_set_iter && !result; feat2_set_iter = feat2_set_iter->rest())
    {
      FrList *feat2 = (FrList*) feat2_set_iter->first();
      if(!feature_is_neg(feat2))
	result = true;
    }

  free_object(feat2_set_copy);
  return result;
}

//----------------------------------------------------------------------

static FrList *feature_set_dedupe(FrList *feat_set)
{
  if(!feat_set)
    return feat_set;

  for(FrList *feat_set_iter1 = feat_set; feat_set_iter1; feat_set_iter1 = feat_set_iter1->rest())
    {
      FrList *feat1 = (FrList*) feat_set_iter1->first();
      FrList *feat_set_iter2_prev = feat_set_iter1;
      for(FrList *feat_set_iter2 = feat_set_iter1->rest(); feat_set_iter2; feat_set_iter2 = feat_set_iter2->rest())
	{
	  FrList *feat2 = (FrList*) feat_set_iter2->first();
	  // Check if name of feature sets are equal
	  if(!feature_names_diff(feat1, feat2))
	    {
	      // Add features from set2 to set1
	      FrList *feat1_values = feat1->rest();
	      feat1_values = feat1_values->nconc(feat2->rest());
	      feat2->replacd(0);

	      // Remove duplicate features from set1
	      feat1->replacd(feat1_values->removeDuplicates()); // this makes a copy of feat1_values
	      free_object(feat1_values);

	      // Remove set2 from the list of feature sets
	      feat_set_iter2_prev->replacd(feat_set_iter2->rest());
	      feat_set_iter2->replacd(0);
              free_object(feat_set_iter2);
	      feat_set_iter2 = feat_set_iter2_prev;
	    }
	  else
	    {
	      feat_set_iter2_prev = feat_set_iter2;
	    }
	}
    }

  return feat_set;
}

//----------------------------------------------------------------------

/* Updates features that match feat1 with the corresponding values found
   in feat2 and returns the result. This also adds features from feat2
   to features if they do not exist in feat1. Basically we remove all
   elements from feat1 and then add all elements from feat2. */

static FrList *feature_set_update(const FrList *features, const FrList *feat1_set, const FrList *feat2_set)
{
  // First copy everything from features
  FrList *result = (features && features->first()) ? (FrList*) features->deepcopy() : 0;

  // Remove everything from feat1
  for(const FrList *result_iter = result; result_iter; result_iter = result_iter->rest())
    {
      FrList *result_feat = (FrList*) result_iter->first();
      FrList *result_values = result_feat->rest();

      for(const FrList *feat1_set_iter = feat1_set; feat1_set_iter; feat1_set_iter = feat1_set_iter->rest())
        {
          FrList *feat1 = (FrList*) feat1_set_iter->first();
          if(!feature_names_diff(result_feat, feat1))
            {
	      for(const FrList *feat1_iter = feat1->rest(); feat1_iter; feat1_iter = feat1_iter->rest())
		{
		  size_t pos = result_values->locate(feat1_iter->first());
		  result_values = (FrList*) result_values->elide(pos, pos);
		}
	    }
	}

      result_feat->replacd(result_values);
    }

  // Now add elements from feat2 if it is not empty
  if(feat2_set && feat2_set->first())
    result = result->nconc((FrList*) feat2_set->deepcopy());

  // Remove duplicates
  result = feature_set_dedupe(result);

  return result;
}

//----------------------------------------------------------------------

/* Returns the set of matching values if all values of feat1
   match values in feat2. Wildcards are allowed. */

static FrList *feature_values_match(const FrList *feat1, const FrList *feat2)
{
   if (!feat1)				// empty list?
      return 0;

  FrList *matches = 0;

  for(const FrList *feat1_iter = feat1->rest(); feat1_iter; feat1_iter = feat1_iter->rest())
    {
      FrObject *feat1_obj = feat1_iter->first();
      bool wild = feat1_obj->equal(makeSymbol("*"));
      bool found = false;

      for(const FrList *feat2_iter = feat2->rest(); feat2_iter; feat2_iter = feat2_iter->rest())
        {
	  FrObject *feat2_obj = feat2_iter->first();
          if(wild || feat1_obj->equal(feat2_obj))
            {
	      pushlist(feat2_obj->deepcopy(), matches);
              found = true;
	      if(!wild)
		break;
            }
        }

      if(!found)
	{
	  free_object(matches);
	  return 0;
	}
    }

  // Copy the feature name;
  pushlist(feat1->first()->deepcopy(), matches);

  return matches;
}

//----------------------------------------------------------------------

/* Returns the set of matching features if all elements of feat1_set
   match elements in feat2_set. Wildcards are allowed. */

static FrList *feature_set_match(const FrList *feat1_set, const FrList *feat2_set)
{
  /* This allows empty sets to match opposed to returning
     null which indicates a failure to match */

  if (!feat1_set || feat1_set->first() == 0)
    return new FrList(0);

  if (!feat2_set || feat2_set->first() == 0)
    return 0;

  FrList *matches = 0;

  for(const FrList *feat1_set_iter = feat1_set; feat1_set_iter; feat1_set_iter = feat1_set_iter->rest())
    {
      bool valid = false;
      bool found = false;

      FrList *feat1 = (FrList*) feat1_set_iter->first();
      for(const FrList *feat2_set_iter = feat2_set; feat2_set_iter; feat2_set_iter = feat2_set_iter->rest())
	{
	  FrList *feat2 = (FrList*) feat2_set_iter->first();
	  if(!feature_names_diff(feat1, feat2))
	    {
	      FrList *match = feature_values_match(feat1, feat2);
	      if(match)
		{
		  pushlist(match, matches);
		  valid = true;
		}

	      found = true;
	      break;
	    }
	}

      if(!found && feature_is_neg(feat1)) {
	pushlist(feat1->deepcopy(), matches);
	valid = true;
      }

      if(!valid)
	{
	  free_object(matches);
	  matches = 0;
	  break;
	}
    }

  return matches;
}

//----------------------------------------------------------------------

/* Returns the set of values from feat1 that do not match
   values in feat2. Wildcards are not allowed. */

static FrList *feature_values_nomatch(const FrList *feat1, const FrList *feat2)
{
   if (!feat1)				// empty feature list?
      return 0;

   if (!feat2)				// empty feature list?
      return (FrList*) feat1->deepcopy();

  FrList *matches = 0;

  for(const FrList *feat1_iter = feat1->rest(); feat1_iter; feat1_iter = feat1_iter->rest())
    {
      FrObject *feat1_obj = feat1_iter->first();
      bool found = false;

      for(const FrList *feat2_iter = feat2->rest(); feat2_iter; feat2_iter = feat2_iter->rest())
        {
	  FrObject *feat2_obj = feat2_iter->first();
          if(feat1_obj->equal(feat2_obj))
	    {
	      found = true;
	      break;
            }
        }

      if(!found)
	pushlist(feat1_obj->deepcopy(), matches);
    }

  // Copy the feature name;
  if(matches)
    pushlist(feat1->first()->deepcopy(), matches);

  return matches;
}

//----------------------------------------------------------------------

/* Returns the set of features from feat1_set that do not match features
   in feat2_set. Wildcards are not allowed. */

static FrList *feature_set_nomatch(const FrList *feat1_set, const FrList *feat2_set)
{
   if (!feat1_set)			// empty feature set?
      return 0;

   if (!feat2_set)			// empty feature set?
      return feat1_set ? (FrList*) feat1_set->deepcopy() : 0;

  FrList *matches = 0;

  for(const FrList *feat1_set_iter = feat1_set; feat1_set_iter; feat1_set_iter = feat1_set_iter->rest())
    {
      bool found = false;
      FrList *match = 0;

      FrList *feat1 = (FrList*) feat1_set_iter->first();
      for(const FrList *feat2_set_iter = feat2_set; feat2_set_iter; feat2_set_iter = feat2_set_iter->rest())
	{
	  FrList *feat2 = (FrList*) feat2_set_iter->first();
	  if(!feature_names_diff(feat1, feat2))
	    {
	      match = feature_values_nomatch(feat1, feat2);
	      found = true;
	      break;
	    }
	}

      if(!found && !feature_is_neg(feat1))
	match = feat1 ? (FrList*) feat1->deepcopy() : 0;

      if(match)
	pushlist(match, matches);
    }

  return matches;
}

//---------------------------------------------------------------------

// #####################################################################
// Morphology
// #####################################################################

//----------------------------------------------------------------------

#ifdef USE_MORPH_LM

static LanguageModeler *lm = 0;

static double lm_score(const FrString *text) 
{
   LmNGramModel **models;

   if(!lm) 
      {
      // Temporary fix
      FrConfiguration::beginningShutdown();
      // Load the language model
      lm = new LanguageModeler("EBMT-LM", config_file);
      if(!lm || !lm->good())
	 {
	 cerr << "Failed to load LM" << endl;
	 exit(1);
	 }
      lm->setScaleFactor(1.0);
      models = lm->models();
      for (size_t m = 0 ; models && models[m] ; m++)
	 models[m]->useLogSpace(false) ;
      }
   else
      {
      models = lm->models();
      }

   FrList *words = FrCvtString2Wordlist(text->stringValue(),word_delimiters,
					abbrevs_list,char_encoding) ;
   if (words) 
      {
      int words_size = words->simplelistlength();

      double total_weight = 0.0 ;
      double total_prob = 0.0 ;
      FrLocalAlloc(LmWordID_t,IDs,1024,words_size+1);
      for (size_t m = 0 ; models && models[m] ; m++)
	 {
	 LmNGramModel* model = models[m] ;
	 int i = 0;
	 for (FrList *iter = words; iter; iter = iter->rest()) 
	    {
	    FrString *word = (FrString*) iter->first() ;
	    IDs[i++] = model->findWordID(word ? word->stringValue() : " ") ;
	    }

	 double weight = model->weight() ;
	 total_weight += weight ;

	 double prob = 1;
	 for(i = 1; i <= words_size; i++)
	    prob *= model->probability(IDs, i);

	 if(prob < 0) 
	    {
	    cerr << "Bad LM probability -- likely underflow" << endl;
	    FrLocalFree(IDs);
	    free_object(words) ;
	    return 0;
	    }
	 total_prob += weight * prob ;
	 }
      FrLocalFree(IDs);
      free_object(words) ;
      
      if (total_weight > 0.0)
	 {
	 total_prob /= total_weight ;
	 if(words_size > 0.0)
	    return pow(total_prob, 1.0 / words_size);
	 }
      }
  return 0.0;
}

#endif

//----------------------------------------------------------------------

static EBMTCandidate* remove_ungrammatical(const EBMTCandidate *orig,
					   EBMTCandidate *variants)
{
   if (variants == 0)
      return 0;

#ifdef USE_MORPH_LM
   double best_score = lm_score(orig->targetWords());
   EBMTCandidate *prev_iter = 0;
   for (EBMTCandidate *cur_iter = variants; cur_iter; ) 
      {
      EBMTCandidate *next_iter = cur_iter->next();
      double score = lm_score(cur_iter->targetWords());
      if(10.0 * score >= best_score) 
	 {
	 prev_iter = cur_iter;
	 cur_iter = next_iter;
	 }
      else
	 {
	 //      cerr << "        ORIG " << orig->targetWords() << " " << best_score << endl;
	 //      cerr << "BAD " << cur_iter->targetWords() << " " << score << endl;
	 if (prev_iter) 
	    {
	    prev_iter->setNext(next_iter);
	    delete cur_iter;
	    cur_iter = next_iter;
	    }
	 else
	    {
	    variants = next_iter;
	    delete cur_iter;
	    cur_iter = next_iter;
	    }
	 }
      }
#else
  (void)orig ;
#endif /* USE_MORPH_LM */

  return variants;
}

//----------------------------------------------------------------------

/* This function accepts a list of candidates and returns a new list of
   candidates to which the generalization rules were applied. This
   function will NOT modify the incomming list of candidates */

static EBMTCandidate *apply_generalization_rules(const EBMTCandidate *cand, const size_t word,
						 const FrList *m_features, const FrList *cand_features)
{
  if(!cand)
    return 0;

  EBMTCandidate *newcand = EbCopyCandidates(cand);

  /*
  for(EBMTCandidate *newcand_iter = newcand; newcand_iter; newcand_iter = newcand_iter->next())
    cerr << "ORIG  " << newcand_iter->targetWords() << " " << cand_features << " " << m_features << endl;
  cerr << "-------------------------------------------" << endl;
  */

  if(feature_set_diff(cand_features, m_features))
    {
      // Make a new list of features
      FrList *newcand_features = 0;
      for(EBMTCandidate *newcand_iter = newcand; newcand_iter; newcand_iter = newcand_iter->next())
	pushlist(cand_features ? cand_features->deepcopy() : 0, newcand_features);
      
      EBMTCandidate *newcand_prev = 0;
      EBMTCandidate *newcand_iter = newcand;

      FrList *newcand_features_prev = 0;
      FrList *newcand_features_iter = newcand_features;
      
      // Apply rules to each item in list
      while(newcand_iter)
	{
	  const FrList *newcand_feature_set = (FrList*) newcand_features_iter->first();

	  /* These are not source and target as in Arabic and English, but
	     as in the original morphology of the example from the corpus
	     and the target morphology we need to convert it to (in the
	     same language) for translation */
	  FrList *src_diff = feature_set_nomatch(newcand_feature_set, m_features);
	  FrList *tgt_diff = feature_set_nomatch(m_features, newcand_feature_set);

	  //cerr << "FEATS " << newcand_feature_set << m_features << src_diff << tgt_diff << endl;

	  if (src_diff || tgt_diff)
	    {
	      for(EbGeneralizationRules::iterator rule = generalization_rules->begin();
		  rule != generalization_rules->end(); rule++)
		{
		  FrList *modified_features = (*rule)->match(newcand_feature_set, m_features, src_diff, tgt_diff);
		  if(modified_features)
		    {
		      EBMTCandidate *modified_cand = (*rule)->apply(newcand_iter, word);
		      modified_cand = remove_ungrammatical(newcand_iter, modified_cand);
		      if(modified_cand)
			{			  
			  /* Add all modified candidates to newcand_iter list,
			     but not in the first position because that will
			     be deleted once we have tried applying the
			     remaining to it */
			  
			  EBMTCandidate *end = modified_cand;
			  size_t modified_size = 1;
			  while(end->next())
			    {
			      end = end->next();
			      modified_size++;
			    }
			  end->setNext(newcand_iter->next());
			  newcand_iter->setNext(modified_cand);
			  
			  /* Add the modified features to the list of features
			     in the same position as the modified candidates */
			  
			  FrList *next = newcand_features_iter->rest();
			  while(modified_size > 0)
			    {
			      FrList *modified_features_list = new FrList(modified_features->deepcopy());
			      modified_features_list->replacd(next);
			      next = modified_features_list;
			      modified_size--;
			    }
			  newcand_features_iter->replacd(next);
			  
			  free_object(modified_features);
			      
			  /* After we have found one rule that matches
			     we do not evaluate the rest of the rules */
			  break;
			}
		      else
			free_object(modified_features);
		    }
		}
	      
	      /* Delete this element after all rules have been applied
		 to it (we already know the features don't match) */

	      //cerr << "Deleting newcand_iter " << newcand_iter->targetWords() << endl; 
	      
	      EBMTCandidate *newcand_next = newcand_iter->next();
	      if(!newcand_prev)
		newcand = newcand_next;
	      else
		newcand_prev->setNext(newcand_next);
	      delete newcand_iter;
	      newcand_iter = newcand_next;
	      
	      FrList *newcand_features_next = newcand_features_iter->rest();
	      if(!newcand_features_prev)
		newcand_features = newcand_features_next;
	      else
		newcand_features_prev->replacd(newcand_features_next);
	      newcand_features_iter->replacd(0);
	      free_object(newcand_features_iter);
	      newcand_features_iter = newcand_features_next;
	    }
	  else
	    {
	      //cerr << "Accepted newcand_iter " << newcand_iter->targetWords() << endl;

	      // Move to the next element
	      newcand_prev = newcand_iter;
	      newcand_iter = newcand_iter->next();
	      newcand_features_prev = newcand_features_iter;
	      newcand_features_iter = newcand_features_iter->rest();
	    }

	  free_object(src_diff);
	  free_object(tgt_diff);
	}

      free_object(newcand_features);
    }
  //cerr << "###########################################" << endl;

  /*
  if(newcand)
    cerr << "###########################################" << endl;
  for (EBMTCandidate *i = newcand; i; i = i->next())
    cerr << i->targetWords() << endl;
  */

  // Keep track of which generalizations were used
  if(generalization_counts) {
    for(EBMTCandidate *iter = newcand; iter; iter = iter->next()) {
      EbGeneralizations *generalizations = iter->generalizations;
      size_t words = generalizations->getWords();
      for(size_t i=0; i < words; i++) {
	for(size_t j=0; j < total_generalization_types; j++) {
	  if(generalizations->get(i,j))
	    generalization_counts[j]++;
	}
      }
    }
  }  
  
  return newcand;
}

//----------------------------------------------------------------------

/* This function returns all morphological variants (including the original)
   for a given candidate based on a the specified source word. Each
   morphological variant is identifyable through the EbGeneralizations class.
   The incomming cand can be a list of candidates that all share the same
   morph structure. This function will delete the cand that is passed in. */

static EBMTCandidate *get_morph_variants(EBMTCandidate *cand,
					 const FrList *cand_morph,
					 const FrList *m_morph,
					 const size_t word)
{
  /* Either both cand_morph and m_morph must be specified
     or they must both be NULL */

  if(!cand_morph || !m_morph)
    {
      if(!cand_morph && !m_morph) {
	return cand;
      } else {
	cand->deleteList();
	return 0;
      }
    }
 
  if(metainfo_ht)
    {
      FrSymbol *cand_key = get_morph_key(cand_morph);
      FrSymbol *m_key = get_morph_key(m_morph);

      if(cand_key && m_key)
	{
	  if(cand_key->equal(m_key))
	    return cand;
	  for(EBMTCandidate *iter = cand; iter; iter = iter->next())
	    iter->generalizations->set(word, EbGeneralizations::getType("MORPH_SURFACE"), true);
	}

      if(cand_key)
	cand_morph = get_metainfo(cand_key);

      if(m_key)
	m_morph = get_metainfo(m_key);
    }

  EBMTCandidate *variants = 0;

  // Parse Morphology Structures
  while(m_morph)
    {
      FrList *m_analysis = (FrList*) m_morph->first();
      if(!m_analysis)
	{
	  m_morph = m_morph->rest();
	  continue;
	}

      FrString *m_stem = (FrString*) m_analysis->first();
      if(!m_stem)
	{
	  m_morph = m_morph->rest();
	  continue;
	}

      const FrList *cand_morph_iter = cand_morph;
      while(cand_morph_iter)
	{
	  FrList *cand_analysis = (FrList*) cand_morph_iter->first();
	  if(!cand_analysis)
	    {
	      cand_morph_iter = cand_morph_iter->rest();
	      continue;
	    }

	  FrString *cand_stem = (FrString*) cand_analysis->first();
	  if(!cand_stem)
	    {
	      cand_morph_iter = cand_morph_iter->rest();
	      continue;
	    }

	  // Matching Stem (now lemmaID)
	  if(*m_stem == *cand_stem)
	    {
	      // List of Analyses
	      m_analysis = (FrList*) m_analysis->second();
	      cand_analysis = (FrList*) cand_analysis->second();
	      
	      while(m_analysis)
		{
		  FrList *m_features = feature_set_dedupe((FrList*) m_analysis->first());

		  const FrList *cand_analysis_iter = cand_analysis;
		  while(cand_analysis_iter)
		    {
		      FrList *cand_features = feature_set_dedupe((FrList*) cand_analysis_iter->first());

		      EBMTCandidate *variant = apply_generalization_rules(cand, word, m_features, cand_features);
		      while(variant) {
			EBMTCandidate *next = variant->next();
			/* FIX we should experiment with letting insert_unique update,
			   but this would have to be normalized in the end by adjust_score
			   or perhaps do a check to verify the same example is not counting
			   more than once */
			variants = insert_unique(variant, variants, false);
			variant = next;
		      }

		      cand_analysis_iter = cand_analysis_iter->rest();
		    }
		  
		  m_analysis = m_analysis->rest();
		}
	      // As long as we only have entry per stem we can safely stop looking
	      break;
	    }
	  cand_morph_iter = cand_morph_iter->rest();
	}
      m_morph = m_morph->rest();
    }
  
  cand->deleteList();
  
  return variants;
}			 

//----------------------------------------------------------------------

bool EbMayHaveVariants(const EBMTCandidate *candidate,
			 const EbCorpusMorphology* const *morph_info,
			 const size_t morph_spans)
{
   return (use_morph && candidate && morph_info && morph_spans) ;
}

//----------------------------------------------------------------------

/* This function will destroy the incomming candidate and return a candidate
   or collection of candidates (including the original) that are variants */

EBMTCandidate *get_variants(EBMTCandidate *candidate,
			    const EbCorpusMorphology* const *morph_info,
			    const size_t morph_spans)
{
   if (!EbMayHaveVariants(candidate,morph_info,morph_spans))
    return candidate;

  assert(candidate->next() == 0);
  assert(candidate->generalizations == 0);

  candidate->generalizations = new EbGeneralizations(morph_spans);
  EBMTCandidate *cand = new EBMTCandidate(candidate);

  // We look at each word and build the variants
  for (size_t i=0; cand && i < morph_spans; i++)
    {
      const FrList *cand_morph = candidate->otherMorphology(i+candidate->sourceOffset());
      const FrList *m_morph = morph_info[i] ? morph_info[i]->other(symMORPH) : 0;
      cand = get_morph_variants(cand, cand_morph, m_morph, i);

      // Prune if there are too many variants (speeds things up)
      size_t count = 0;
      for(EBMTCandidate *cand_iter = cand; cand_iter; cand_iter = cand_iter->next())
	count++;
      if(count > 500)
	{
	  EBMTCandidate *prev_cand = 0;
	  for(EBMTCandidate *cand_iter = cand; cand_iter; ) {
	    EBMTCandidate *next = cand_iter->next();
	    if(cand_iter->generalizations->empty()) {
	      cand_iter = next;
	    } else {
	      if(prev_cand) {
		prev_cand->setNext(next);
		delete cand_iter;
		cand_iter = next;
	      } else {
		cand = next;
		delete cand_iter;
		cand_iter = next;
	      }
	    }
	  }
	}
    }

  EbAdjustFrequency(cand);

  EBMTCandidate *variants = 0;  
  while(cand)
    {
      EBMTCandidate *next = cand->next();
      if(cand->generalizations->score() != 0)
	{
	  cand->setNext(variants);
	  variants = cand;
	}
      else
	delete cand;
      cand = next;
    }

  delete candidate;

  return variants;
}

//----------------------------------------------------------------------
