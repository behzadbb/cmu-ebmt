/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebmt.cpp	main program for EBMT engine			*/
/*  LastEdit: 08apr10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "FramepaC.h"
#include "ebalign.h"
#include "ebconfig.h"
#include "ebcorpus.h"
#include "dict.h"
#include "ebmkdict.h"
#include "ebsent.h"
#include "ebutil.h"
#include "ebmt.h"
#include "ebglobal.h"

#include <signal.h>

#ifdef unix
#include <unistd.h>
#endif

/************************************************************************/
/*	Manifest constants for this module				*/
/************************************************************************/

#define WINDOWS_TITLEBAR "EBMT"

/************************************************************************/
/*	Global variables for this module				*/
/************************************************************************/

static EBMTConfig *ebmt_config ;	// default configuration read from file

static bool output_unknown_words = false ;

static int port_number = -1 ;
static bool initiate_connection = false ;
static char *host_name = 0 ;

static bool compute_global_stats_requested = false ;
static bool create_dictionary_requested = false ;
static bool create_HF_dictionary_requested = false ;
static char *refine_dict_file = 0 ;
static const char *align_save_file = 0 ;

static bool create_index_requested = false ;
static bool pack_index_requested = false ;
static bool update_index_requested = false ;
static bool lengthmodel_requested = false ;
static bool autophrase_requested = false ;
static bool dump_index_requested = false ;
static const char *index_dump_filename = 0 ;
static const char *tokenize_to_filename = 0 ;
static const char *lengthmodel_filename = 0 ;
static bool show_doc_origin = false ;

static bool filter_MMR = false ;
static size_t filter_MMR_desired = 10000 ;
static size_t filter_MMR_max = 12000 ;
static size_t filter_MMR_passes = 1 ;
static char *filter_MMR_outfile = 0 ;

static char *index_directory_name = 0 ;

static const char *argv0 ;
static const char *config_filename = 0 ;

//----------------------------------------------------------------------
// signal handlers

static FrSignalHandler *sigint ;
static FrSignalHandler *sigill ;
static FrSignalHandler *sigfpe ;
#ifdef SIGPIPE
static FrSignalHandler *sigpipe ;
#endif /* SIGPIPE */
#ifdef SIGHUP
static FrSignalHandler *sighup ;
#endif /* SIGHUP */
#ifdef SIGBUS
static FrSignalHandler *sigbus ;
#endif /* SIGBUS */
#ifdef SIGSEGV
static FrSignalHandler *sigsegv ;
#endif /* SIGSEGV */

/************************************************************************/
/*    Global Data							*/
/************************************************************************/

#if defined(__WINDOWS__) || defined(__NT__)
extern "C" char __WinTitleBar[] = WINDOWS_TITLEBAR ;
#endif /* __WINDOWS__ || __NT__ */

static const char ready_bang[] = "Ready!" ;

/************************************************************************/
/*	Forward Declarations						*/
/************************************************************************/

static void untrap_signals() ;

/************************************************************************/
/************************************************************************/

static void usage(ostream &err, const char *argv0)
{
   err << "Usage: " << argv0 << " [options] config-file\n"
	   "\t(where config-file may be '.' for the default configuration)\n"
	   "\t-a\tprint near-perfect alignments to file\n"
	   "\t-A\textract high-frequency phrases according to AutoPhrase-...\n"
	   "\t-c\tcreate blank index (directory specifed in config-file)\n"
	   "\t-cDIR\tcreate blank index in directory DIR\n"
	   "\t-C\tcompute coverage statistics\n"
	   "\t-dN\tcreate dictionary from corpus, using threshold N\n"
           "\t-daN\tforce translations for all source words (N = how hard, 1..3)\n"
	   "\t-dbR,H,L\tbias words within R% of 'expected' pos by H, rest by L\n"
	   "\t-dcN\tdump intermediate dictionary data every N sentence pairs\n"
	   "\t-dCn,c,F  infer alignment constraints (min freq 'n', contra 'c', file F)\n"
	   "\t-diN\tcompute monolingual mutual information within window +/- N\n"
	   "\t-dIN\tcompute monolingual chi-square within window +/- N\n"
	   "\t-dl:file\tload co-occurrence counts from 'file'\n"
	   "\t-dmN\tset minimum number of co-occurrences before making defn.\n"
           "\t-dp\tfind phrases for -di/-dI (one-way window)\n"
           "\t-dP\tfind word-to-phrase mapping while building dict\n"
	   "\t-dr\trefine existing dictionary\n"
	   "\t-dsN:file\tstore co-occurrence counts >= N/total into 'file'\n"
	   "\t-dtM,N\tset asymmetric co-occurrence thresholds to M and N\n"
      	   "\t-dw\tset maximum length-based weight\n"
           "\t-F=...\tfind maximally-diverse sentences in corpus\n"
	   "\t-i\tindex documents, reading filenames from standard input\n"
	   "\t-i=FILE\tturn index back into text in FILE\n"
	   "\t-iDIR\tindex documents, place indexed corpus in directory DIR\n"
	   "\t-LFILE\tgenerate length model to FILE from input documents\n"
	   "\t-m\tshow memory usage\n"
	   "\t-M\tcompute global match statistics instead of translating\n"
	   "\t-nN\trun in network mode on port 'N'\n"
	   "\t-n=N\trun as network server on port 'N'\n"
	   "\t-Nhost:N initiate network connection to host on port 'N'\n"
	   "\t-p\tpack index after any other processing is complete\n"
	   "\t-Pfile\t(with -i) extract possible proper names to 'file' (NYI)\n"
	   "\t-q\trun quietly (suppress most warnings and info messages)\n"
	   "\t-r\treverse source/target languages while indexing\n"
	   "\t-s\t(with -d or -i) read document from standard input\n"
	   "\t-tN\tset threshold for returned arcs to N*chunk length\n"
	   "\t-Tfile\ttokenize source language documents into 'file'\n"
	   "\t-u\toutput untranslateable words (not implemented yet)\n"
	   "\t-U\tperform I/O using specified encoding (Unicode,UTF8,Latin-1,etc.)\n"
	   "\t-Ub\tperform byte-swapped I/O when using Unicode 16-bit characters\n"
	   "\t-v\tverbose operation\n"
	   "\t-xFILE\texport translation dictionary to FILE\n"
	   "\t-x=FILE\texport parallel corpus to FILE\n"
	   "\t-1\t(with -i) monolingual data file(s)\n"
	   "\t-@\tinput sentences are in canonical form\n"
	 << endl ;
   err << "This is free software; see the source for copying conditions.  There is NO\n"
      "warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE."
	<< endl ;
   return ;
}

/************************************************************************/
/************************************************************************/

static void set_flag_var(bool &flag, char option)
{
   if (option == '+')
      flag = true ;
   else if (option == '-')
      flag = false ;
   else if (flag)
      flag = false ;
   else
      flag = true ;
   return ;
}

//----------------------------------------------------------------------

static void extract_hostname_and_port(const char *parm, char *&host_name,
				      int &port_number)
{
   FrFree(host_name) ;
   host_name = FrDupString(parm) ;
   char *colon = strchr(host_name,':') ;
   if (colon)
      {
      *colon = '\0' ;			// strip off port number
      port_number = atoi(colon+1) ;	// get port number into variable
      initiate_connection = true ;	// yes, we want to initiate the conn.
      }
   else
      {
      port_number = -1 ;
      FrFree(host_name) ;
      host_name = 0 ;
      }
   return ;
}

//----------------------------------------------------------------------

static void extract_dict_thresholds(const char *arg)
{
   if (*arg == '=' || *arg == ':')
      {
      if (!load_dict_thresholds(arg+1))
	 FrWarning("unable to load dictionary thresholds -- will use defaults") ;
      return ;
      }
   char *end = 0 ;
   double thres = strtod(arg,&end) ;
   if (end && end != arg && *end == ',')
      {
      if (thres >= 0.0)
	 dict_correspondence_threshold_low = thres ;
      else
	 FrWarning("negative threshold ignored") ;
      arg = end+1 ;
      end = 0 ;
      thres = strtod(arg,&end) ;
      if (end && end != arg)
	 {
	 if (thres >= 0.0)
	    dict_correspondence_threshold_high = thres ;
	 else
	    FrWarning("negative threshold ignored") ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

static void extract_dict_forced_align(const char *arg)
{
   char *end = 0 ;
   makedict_force = 1 ;
   long argval = strtol(arg,&end,0) ;
   if (end && end != arg && argval >= 0 && argval <= 3)
      makedict_force = argval ;
   else if (end != arg)
      FrWarning("invalid value for -da (0-3 allowed), using default of 1") ;
   return ;
}

//----------------------------------------------------------------------

static void extract_dict_bias(const char *arg)
{
   char *end = 0 ;
   // first, extract the range over which to apply a bias
   double range = strtod(arg,&end) ;
   if (end && end != arg)
      {
      if (range >= 0.0 && range < 1.0)
	 dict_bias_range = range ;
      else
	 FrWarning("invalid range specified for -db, using default") ;
      }
   else
      end = (char*)arg ;
   // if a second parameter is present, extract the value to give inside
   // the bias range
   if (*end == ',')
      {
      arg = end+1 ;
      long int high = strtol(arg,&end,10) ;
      if (end && end != arg)
	 {
	 if (high >= 1)
	    dict_bias_high = (size_t)high ;
	 else
	    FrWarning("high bias value must be >= 1") ;
	 }
      else
	 end = (char*)arg ;
      }
   // if a third parameter is present, extract the value to give OUTSIDE
   // the bias range (default 1)
   if (*end == ',')
      {
      arg = end+1 ;
      long int low = strtol(arg,&end,10) ;
      if (end && end != arg)
	 {
	 if (low >= 0 && (size_t)low <= dict_bias_high)
	    dict_bias_low = (size_t)low ;
	 else
	    FrWarning("low bias must be between 0 and high-bias value") ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

static void extract_dict_HF_threshold(const char *arg)
{
   char *end = 0 ;
   double thres = strtod(arg,&end) ;
   if (end && end != arg)
      {
      dict_HF_threshold = thres ;
      arg = end ;
      }
   if (arg && (*arg == ':' || *arg == '='))
      {
      if (*arg == '=')
	 dict_extracting_HF = false ;
      if (arg[1])
	 dict_HF_filename = arg+1 ;
      }
   return ;
}

//----------------------------------------------------------------------

static void extract_dict_load_args(const char *arg)
{
   if (arg && (*arg == ':' || *arg == '='))
      {
      dict_loading_counts = true ;
      if (arg[1])
	 dict_load_filename = arg+1 ;
      }
   return ;
}

//----------------------------------------------------------------------

static void extract_dict_store_args(const char *arg)
{
   char *end = 0 ;
   double thres = strtod(arg,&end) ;
   if (end && end != arg)
      {
      dict_store_threshold = thres ;
      arg = end ;
      }
   if (arg && (*arg == ':' || *arg == '='))
      {
      dict_storing_counts = true ;
      if (arg[1])
	 dict_store_filename = arg+1 ;
      }
   return ;
}

//----------------------------------------------------------------------

static void extract_align_infer_params(const char *arg)
{
   char *end = 0 ;
   size_t min = strtol(arg,&end,0) ;
   if (end && end != arg)
      {
      infer_min_frequency = min ;
      arg = end ;
      if (*arg == ',')
	 arg++ ;
      }
   end = 0 ;
   double contra = strtod(arg,&end) ;
   if (end && end != arg)
      {
      if (contra >= 0.0 && contra < 0.5)
	 infer_max_contradictions = contra ;
      else
	 cout << "; second value on -dC (max contradictions) must be 0.0-0.5"
	      << endl ;
      arg = end ;
      if (*arg == ',')
	 arg++ ;
      }
   align_save_file = arg ;
   return ;
}

//----------------------------------------------------------------------

static void extract_MMR_thresholds(const char *arg)
{
   if (!*arg)
      {
      cerr << "Usage of -F= is:\t\t-F=des,max,passes,outfile\n"
	      "\twhere 'des' is the desired number of lines/pairs to retain,\n"
	      "\t'max' is the maximum number of retain, and 'passes' is the\n"
	      "\tlimit to the number of times to repeat the process in trying\n"
	      "\tto satisfy the requested 'max'\n" << endl ;
      return ;
      }
   char *end = 0 ;
   size_t value = (size_t)strtol(arg,&end,10) ;
   filter_MMR = true ;
   if (end && end != arg && *end == ',')
      {
      filter_MMR_desired = value ;
      arg = end+1 ;
      end = 0 ;
      value = (size_t)strtol(arg,&end,10) ;
      if (end && end != arg && *end == ',')
	 {
	 filter_MMR_max = value ;
	 arg = end+1 ;
	 end = 0 ;
	 value = (size_t)strtol(arg,&end,10) ;
	 if (end && end != arg && (*end == ',' || *end == ':'))
	    {
	    filter_MMR_passes = value ;
	    filter_MMR_outfile = end+1 ;
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

static char **skip_commandline_options(int &argc, char **argv)
{
   argv++ ;				// skip program name
   argc-- ;
   while (argc > 0 && argv[0][0] == '-')
      {
      // process the arguments we need before even loading the configuration
      // file (obviously, anything processed here can't easily be overridden
      // from the config file)
      char arg2 = argv[0][2] ;
      switch (argv[0][1])
	 {
	 case 'c':
	    create_index_requested = true ;
	    if (arg2)
	       index_directory_name = argv[0]+2 ;
	    break ;
	 case 'd':
	    if (arg2 != 'a')
	       create_dictionary_requested = true ;
	    if (arg2 == 'a')
	       extract_dict_forced_align(argv[0]+3) ;
	    else if (arg2 == 'b')
	       extract_dict_bias(argv[0]+3) ;
	    else if (arg2 == 'c')
	       lines_per_chunk = atoi(argv[0]+3) ;
	    else if (arg2 == 'C')
	       extract_align_infer_params(argv[0]+3) ;
	    else if (arg2 == 'h')
	       {
	       extract_dict_HF_threshold(argv[0]+3) ;
	       create_HF_dictionary_requested = true ;
	       }
	    else if (arg2 == 'i' || arg2 == 'I')
	       {
	       monolingual_data = true ;
	       mutual_info_via_chisquared = (arg2 == 'I') ;
	       compute_mutual_info = true ;
	       mutual_info_window = atoi(argv[0]+3) ;
	       if (mutual_info_window < 1)
		  mutual_info_window = DEFAULT_MUTUAL_INFO_WINDOW ;
	       }
	    else if (arg2 == 'l')
	       extract_dict_load_args(argv[0]+3) ;
	    else if (arg2 == 'm')
	       {
	       dict_min_occurrences = atoi(argv[0]+3) ;
	       if (dict_min_occurrences == 0)
		  dict_min_occurrences = 2 ;
	       }
	    else if (arg2 == 'p')
	       mutual_info_oneway = true ;
	    else if (arg2 == 'P')
	       learn_dict_phrases = true ;
	    else if (arg2 == 'r')
	       refine_dict_file = argv[0]+3 ;
	    else if (arg2 == 's')
	       extract_dict_store_args(argv[0]+3) ;
	    else if (arg2 == 't')
	       extract_dict_thresholds(argv[0]+3) ;
	    else if (arg2 == 'w')
	       {
	       dict_max_weight = atoi(argv[0]+3) ;
	       if (dict_max_weight <= 0)
		  dict_max_weight = 1 ;
	       }
	    else if (Fr_isdigit(arg2))
	       dict_correspondence_threshold = atof(argv[0]+2) ;
	    else
	       FrWarningVA("unrecognized parameter '%s' to -d option",
			   argv[0]+2) ;
	    break ;
	 case 'i':
	    if (arg2 == '=')
	       {
	       dump_index_requested = true ;
	       index_dump_filename = argv[0]+3 ;
	       }
	    else
	       {
	       update_index_requested = true ;
	       if (arg2)
		  index_directory_name = argv[0]+2 ;
	       }
	    break ;
	 case 'L':
	    lengthmodel_requested = true ;
	    lengthmodel_filename = argv[0]+2 ;
	    break ;
	 case 'M':
	    set_flag_var(compute_global_stats_requested,argv[0][2]) ;
	    break ;
	 case 'n':
	    if (arg2 == '=' && argv[0][3])
	       {
	       port_number = atoi(argv[0]+3) ;
	       if (port_number > 0)
		  EbNetworkServerMode(true) ;
	       }
	    else if (arg2)
	       port_number = atoi(argv[0]+2) ;
	    else
	       port_number = -1 ;
	    break ;
	 case 'N':
	    if (arg2)
	       extract_hostname_and_port(argv[0]+2,host_name,port_number) ;
	    else
	       port_number = -1 ;
	    break ;
	 case 'p':
	    set_flag_var(pack_index_requested,arg2) ;
	    break ;
	 default:
	    break ;
	 }
      argc-- ;
      argv++ ;
      }
   return argv ;
}

//----------------------------------------------------------------------

static void select_EBMT_char_encoding(const char *enc_name)
{
   EbSetCharEncoding(enc_name) ;
   return ;
}

//----------------------------------------------------------------------

static void process_commandline_options(int &argc, char **&argv,
					ostream &err)
{
   if (index_directory_name)
      {
      EBMTConfig *config = (EBMTConfig*)get_EBMT_config() ;
      if (config)
	 {
	 free_object(config->corpus_directory) ;
	 config->corpus_directory =
	    new FrList(new FrString(index_directory_name)) ;
	 }
      }
   bool bad_options = false ;
   char *argv0 = argv[0] ;
   while (argc > 1 && argv[1][0] == '-')
      {
      char option = argv[1][2] ;
      switch (argv[1][1])
	 {
	 case '1':
	    set_flag_var(monolingual_data,option) ;
	    break ;
	 case 'a':
	    set_flag_var(print_EBMT_alignments,option) ;
	    break ;
	 case 'A':
	    set_flag_var(autophrase_requested,option) ;
	    break ;
	 case 'C':
	    compute_coverage = true ;
	    break ;
	 case 'F':
	    if (option == '=')
	       extract_MMR_thresholds(argv[1]+3) ;
	    break ;
	 case 'm':
	    set_flag_var(showmem,option) ;
	    break ;
	 case 'P':
	    //FIXME: proper_names_file
	    break ;
	 case 'Q':
	 case 'q':
	    set_flag_var(quiet_mode,option) ;
	    break ;
	 case 'r':
	    set_flag_var(reverse_languages,option) ;
	    break ;
	 case 's':
	    set_flag_var(use_stdin,option) ;
	    break ;
	 case 't':
	    align_threshold = atof(argv[1]+2) ;
	    break ;
	 case 'T':
	    if (option == '+')
	       {
	       show_doc_origin = true ;
	       tokenize_to_filename = argv[1]+3 ;
	       }
	    else
	       tokenize_to_filename = argv[1]+2 ;
	    break ;
	 case 'u':
	    set_flag_var(output_unknown_words,option) ;
	    break ;
	 case 'U':
	    if (option == 'b')
	       {
	       Unicode_bswap = true ;
	       select_EBMT_char_encoding(argv[1]+3) ;
	       }
	    else
	       select_EBMT_char_encoding(argv[1]+2) ;
	    break ;
	 case 'v':
	    set_flag_var(verbose,option) ;
	    break ;
	 case 'x':
	    if (option == '=')
	       {
	       export_corpus_requested = true ;
	       export_dict_requested = false ;
	       dict_export_file = argv[1]+3 ;
	       }
	    else if (option)
	       {
	       export_dict_requested = true ;
	       export_corpus_requested = false ;
	       dict_export_file = argv[1]+2 ;
	       }
	    break ;
	 case '@':
	    EbInputAlreadyCanonical(true) ;
	    break ;
	 case 'c':
	    // do nothing -- already handled in skip_commandline_options
	    break ;
	 case 'd':
	    if (option == 'a')
	       extract_dict_forced_align(argv[1]+3) ;
	    else if (option == 'w')
	       {
	       dict_max_weight = atoi(argv[1]+3) ;
	       if (dict_max_weight <= 0)
		  dict_max_weight = 1 ;
	       }
	    // everything else already handled in skip_commandline_options
	    break ;
	 case 'i':
	 case 'L':
	 case 'M':
	 case 'n':
	 case 'N':
	 case 'p':
	    // do nothing -- already handled in skip_commandline_options
	    break ;
	 default:
	    err << "Unknown option '" << argv[1] << "'" << endl ;
	    bad_options = true ;
	    break ;
	 }
      argc-- ;				// advance to next argument
      argv++ ;
      }
   if (bad_options)
      {
      usage(err,argv0) ;
      exit(EXIT_FAILURE) ;
      }
   if (!word_delimiters)
      EBMT_set_word_delimiters(char_encoding) ;
   EBMTConfig::startupComplete() ;	// switch from STARTUP to RUNTIME vars
   return ;
}

//----------------------------------------------------------------------

static void set_index_config(EBMTIndex *index, EBMTConfig *ebmt_config)
{
   if (ebmt_config->source_charmap || ebmt_config->number_charmap)
      index->setCharMapping(ebmt_config->source_charmap,
			    ebmt_config->number_charmap) ;
   return ;
}

//----------------------------------------------------------------------

static void make_autophrase(EBMT *ebmt, ostream &err)
{
   EBMTCorpus *corpus = ebmt->getCorpus() ;
   if (!corpus)
      return ;
   EBMTIndex *index = corpus->getIndex() ;
   if (!index)
      return ;
   EbBWTIndex *idx = index->selectIndex(EbIndex_Main) ;
   size_t idx_size = idx ? idx->numItems() : 0 ;
   if (autophrase_freq_thresh >= 10 && autophrase_freq_thresh < idx_size)
      {
      if (!autophrase_filename || !*autophrase_filename)
	 autophrase_filename = FrDupString("./autophrase.ebmt") ;
      err << "Extracting high-frequency phrases to " << autophrase_filename
	  << endl ;
      generate_auto_phrases(index) ;
      }
   else
      err << "AutoPhrase disabled, will not extract phrases\n" ;
   ebmt->save() ;
   return ;
}

//----------------------------------------------------------------------

static void tokenize_to_file(EBMT *ebmt, const char *output_name,
			     bool show_doc_origin)
{
   EBMTCorpus *corpus = ebmt->getCorpus() ;
   if (!corpus)
      return ;
   EBMTIndex *index = corpus->getIndex() ;
   if (!index)
      return ;
   ostream *out ;
   if (!output_name || !*output_name)
      out = &cout ;
   else
      {
      out = new ofstream(output_name) ;
      if (!out || out->bad() || out->fail())
	 {
	 cerr << "; error opening \"" << output_name << "\" for writing."
	      << endl ;
	 return ;
	 }
      }
   if (use_stdin)
      index->tokenizeDocument("stdin",stdin,*out,show_doc_origin) ;
   else
      {
      while (!cin.eof())
	 {
	 char line[FrMAX_LINE] ;
	 cin.getline(line,sizeof(line)) ;
	 char *filename = FrTrimWhitespace(line) ;
	 cout << "; tokenizing " << filename << endl ;
	 index->tokenizeDocument(filename,*out,show_doc_origin) ;
	 }
      }
   if (out != &cout)
      {
      delete out ;
      }
   return ;
}

//----------------------------------------------------------------------

static void build_length_model(const char *model_file, const char *argv0,
			       ostream &out, istream &filelist, ostream &err)
{
   out << "; Building length model" << endl ;
   FrTimer timer ;
   EbLengthModelInit() ;
   if (use_stdin)
      {
      err << argv0 << ": sorry, input can not be read from stdin because "
	  << "\n\ttwo passes are required." << endl ;
      }
   else
      {
      // collect the filenames from standard input
      FrList *files = 0 ;
      FrList **files_end = &files ;
      while (!filelist.eof() && !filelist.fail())
	 {
	 char line[FrMAX_LINE] ;
	 filelist.getline(line,sizeof(line)) ;
	 char *filename = FrTrimWhitespace(line) ;
	 if (*filename && *filename != ';' && *filename != '#')
	    files->pushlistend(new FrString(filename),files_end) ;
	 }
      out << "; gathering word statistics" << endl ;
      for (FrList *file = files ; file ; file = file->rest())
	 {
	 EbLengthModelUpdate(FrPrintableName(file->first()),true) ;
	 }
      EbLengthModelFinishMeans() ;
      out << "; gathering byte statistics" << endl ;
      for (FrList *file = files ; file ; file = file->rest())
	 {
	 EbLengthModelUpdate(FrPrintableName(file->first()),false) ;
	 }
      }
   EbLengthModelFinalize(model_file,verbose) ;
   out << "; Length model built in " << timer.readsec() << " seconds" << endl ;
   return ;
}

//----------------------------------------------------------------------

static void update_index(EBMT *ebmt,const char *argv0, ostream &out,
			 istream &filelist,ostream &err, bool pack_requested)
{
   EBMTCorpus *corpus = ebmt->getCorpus() ;
   if (!corpus)
      return ;
   EBMTIndex *index = corpus->getIndex() ;
   if (!index)
      return ;
   if (check_index_status(index,err) == EXIT_FAILURE)
      usage(err,argv0) ;
   else
      {
      if (index->isReadOnly())
	 {
	 out << "Sorry, can't update the corpus because it is read-only"
	     << endl ;
	 return ;
	 }
      bool incr_update
	    = (index->numSentencePairs() > index->tokenFileEntries()) ;
      if (incr_update)
	 out << "; Performing incremental update of EBMT corpus" << endl ;
      else if (index->numSentencePairs() < index->tokenFileEntries())
	 {
	 out << "ERROR: corpus says it has more generalization entries than total entries!"
	     << endl ;
	 return ;
	 }
      else
	 out << "; Performing initial indexing of EBMT corpus" << endl ;
      FrSymbolTable *symtab = ebmt->symbolTable()->select() ;
      set_index_config(index,ebmt_config) ;
      out << ready_bang << endl ;
      index->beginIndexing() ;
      if (use_stdin)
	 index->addDocument("stdin",stdin,incr_update) ;
      else
	 {
	 while (!filelist.eof())
	    {
	    char line[FrMAX_LINE] ;
	    filelist.getline(line,sizeof(line)) ;
	    char *filename = FrTrimWhitespace(line) ;
	    index->addDocument(filename,incr_update) ;
	    }
	 }
      index->finishIndexing() ;
      if (showmem)
	 FrMemoryStats() ;
      EbBWTIndex *idx = index->selectIndex(EbIndex_Main) ;
      size_t idx_size = idx ? idx->numItems() : 0 ;
      if (autophrase_freq_thresh >= 10 && autophrase_freq_thresh < idx_size)
	 generate_auto_phrases(index) ;
      if (pack_requested)
	 index->pack(&out) ;
      ebmt->save() ;
      symtab->select() ;
      }
   return ;
}

//----------------------------------------------------------------------

static void pack_index(EBMTConfig *ebmt_config, ostream &out,ostream &err)
{
   bool newindex ;
   EBMTIndex *index ;
   if (active_EBMT() && active_EBMT()->getCorpus())
      {
      index = active_EBMT()->getCorpus()->getIndex() ;
      newindex = false ;
      }
   else
      {
      index = new EBMTIndex(first_corpus_dir(ebmt_config->corpus_directory)) ;
      newindex = true ;
      }
   if (check_index_status(index,err) != EXIT_FAILURE)
      {
      index->pack(&out) ;
      }
   if (newindex)
      delete index ;
   return ;
}

//----------------------------------------------------------------------

static istream *in = &cin ;
static ostream *out = &cout ;
static ostream *err = &cerr ;

void terminate_program(int exitcode)
{
   shutdown__EBMT() ;
   untrap_signals() ;
   unload_EBMT_config() ;
   FrCloseConnection(in,out,err) ;
   FrDestroyWindow() ;
   FrCloseListener() ;
   if (showmem)
      {
      FrMemoryStats(cerr) ;
      if (verbose)
	 {
	 cerr << "Unfreed strings:" << endl ;
	 FrString::dumpUnfreed(cerr) ;
	 FramepaC_gc() ;
	 FrMemoryStats(cerr) ;
	 }
      }
   exit(exitcode) ;
}

//----------------------------------------------------------------------

#ifdef SIGPIPE
static void sigpipe_handler(int)
{
   FrWarning("Lost connection to another process.  Shutting down....") ;
   terminate_program(1) ;
}
#endif /* SIGPIPE */

//----------------------------------------------------------------------

static void sigint_handler(int)
{
   static bool first_interrupt = true ;

   if (!first_interrupt)
      {
      // attempt a graceful shutdown
      cout << "Shutting down (signal)...." << endl ;
      terminate_program(1) ;
      }
   else
      // ignore the first interrupt (i.e. require two Ctrl-C's to kill)
      first_interrupt = false ;
}

//----------------------------------------------------------------------

static void sigill_handler(int)
{
   static bool first = true ;
   // first time, attempt a graceful shutdown
   if (first)
      {
      first = false ;
      FrWarning("illegal instruction or bus error; attempting to shut down") ;
      terminate_program(1) ;
      }
   else
      FrProgError("repeated illegal instruction or bus error!") ;
}

//----------------------------------------------------------------------

static void sigfpe_handler(int)
{
   static bool first = true ;
   // first time, attempt a graceful shutdown
   if (first)
      {
      first = false ;
      FrWarning("unhandled floating-point error; attempting to shut down") ;
      terminate_program(1) ;
      }
   else
      FrProgError("repeated floating-point error!  Goodbye...") ;
}

//----------------------------------------------------------------------

#ifdef SIGSEGV
static void sigsegv_handler(int)
{
   static bool first = true ;
   // first time, attempt a graceful shutdown of the child processes
   if (first)
      {
      first = false ;
      FrWarning("segmentation violation; attempting to shut down") ;
      terminate_program(1) ;
      }
   else
      FrProgError("repeated segmentation violation!") ;
}
#endif /* SIGSEGV */

//----------------------------------------------------------------------

static void trap_signals()
{
   sigint = new FrSignalHandler(SIGINT,sigint_handler) ;
   sigill = new FrSignalHandler(SIGILL,sigill_handler) ;
   sigfpe = new FrSignalHandler(SIGFPE,sigfpe_handler) ;
#ifdef SIGPIPE
   sigpipe = new FrSignalHandler(SIGPIPE,sigpipe_handler) ;
#endif /* SIGPIPE */
#ifdef SIGHUP
   sighup = new FrSignalHandler(SIGHUP,sigint_handler) ;
#endif /* SIGHUP */
#ifdef SIGBUS
   sigbus = new FrSignalHandler(SIGBUS,sigill_handler) ;
#endif /* SIGBUS */
#ifdef SIGSEGV
   sigsegv = new FrSignalHandler(SIGSEGV,sigsegv_handler) ;
#endif /* SIGSEGV */
   return ;
}

//----------------------------------------------------------------------

static void untrap_signals()
{
   delete sigint ;
   delete sigill ;
   delete sigfpe ;
#ifdef SIGPIPE
   delete sigpipe ;
#endif /* SIGPIPE */
#ifdef SIGHUP
   delete sighup ;
#endif /* SIGHUP */
#ifdef SIGBUS
   delete sigbus ;
#endif /* SIGBUS */
#ifdef SIGSEGV
   delete sigsegv ;
#endif /* SIGSEGV */
   return ;
}

/************************************************************************/
/************************************************************************/

int perform_EBMT_operation(FrObject *object, ostream &out, istream &in);

int perform_EBMT(EBMT *ebmt, ostream &out, istream &in)
{
   if (ebmt && ebmt->OK())
      {
      EbSetActiveCorpus(ebmt->getCorpus()) ;
      out << ready_bang << endl ;
      while (!in.eof())
	 {
	 if (!perform_EBMT_operation(0,out,in))
	    break ;
	 }
      if (EbActiveCorpus()->addedTranslations())
	 {
	 out << "; Updating dictionary on disk." << endl ;
	 EbActiveCorpus()->storeTranslations() ;
	 }
      if (export_dict_requested)
	 ebmt->exportDictionary(dict_export_file) ;
      else if (export_corpus_requested)
	 ebmt->exportCorpus(dict_export_file) ;
      EbSetActiveCorpus(0) ;
      shutdown__EBMT() ;
      out << "Done!" ;
      if (verbose)
	 out << "; " << EbSentencesProcessed() << " sentences processed" ;
      out << endl ;
      return EXIT_SUCCESS ;
      }
   else
      {
      out << "Error opening corpus!" << endl ;
      shutdown__EBMT() ;
      EbNetworkServerMode(false) ;
      return EXIT_FAILURE ;
      }
}

//----------------------------------------------------------------------

int
#ifndef __WATCOMC__
   __FrCDECL
#endif
   main(int argc, char **argv)
{
   if (argc < 2)
      {
      usage(*err,argv[0]) ;
      return EXIT_FAILURE ;
      }
   initialize_FramepaC() ;
   argv0 = argv[0] ;			// remember program name
   EbSetArgv0(argv0) ;
   int argc1 = argc ;
   char **argv1 = skip_commandline_options(argc1,argv) ;
   config_filename = *argv1 ;
   EbSetConfigFilename(*argv1) ;
   trap_signals() ;
   if (argc1 < 1)
      usage(*err,argv0) ;
   if (port_number > 0 && !EbNetworkServerMode())
      {
      FrHideWindow() ;
      if (initiate_connection)
	 {
	 if (FrInitiateConnection(host_name,port_number,in,out,err))
	    {
	    EbDisplayBanner(*out) ;
	    }
	 else
	    {
	    (*err) << "Unable to initiate network connection!" << endl ;
	    shutdown__EBMT() ;
	    return EXIT_FAILURE ;
	    }
	 }
      else
	 {
	 if (!FrAwaitConnection(port_number,in,out,err))
	    {
	    (*err) << "Unable to listen on port " << port_number << "!"
		   << endl ;
	    return EXIT_FAILURE ;
	    }
	 }
      }
   else // port_number <= 0 || EbNetworkServerMode()
      EbDisplayBanner(*out) ;
   int status = EXIT_SUCCESS ;
   FrTimer *timer = 0 ;
   if (lengthmodel_requested)
      {
      process_commandline_options(argc,argv,cerr) ;
      if (get_EBMT_setup_file(config_filename,argv0,cerr))
	 apply_EBMT_configuration((EBMTConfig*)get_EBMT_config()) ;
      build_length_model(lengthmodel_filename,argv0,*out,*in,*err) ;
      }
   else if (create_dictionary_requested)
      {
      if (get_EBMT_setup_file(config_filename,argv0,cerr))
	 {
	 apply_EBMT_configuration((EBMTConfig*)get_EBMT_config()) ;
	 process_commandline_options(argc,argv,cerr) ;
	 timer = new FrTimer ;
	 status = create_dictionary(get_EBMT_config(),
				    create_HF_dictionary_requested,
				    refine_dict_file,align_save_file,
				    use_stdin,*in,*out) ;
	 }
      else
	 status = EXIT_FAILURE ;
      }
   else if (pack_index_requested && !update_index_requested)
      {
      if (get_EBMT_setup_file(config_filename,argv0,cerr))
	 {
	 EBMTConfig *config = (EBMTConfig*)get_EBMT_config() ;
	 apply_EBMT_configuration(config) ;
	 process_commandline_options(argc,argv,cerr) ;
	 pack_index((EBMTConfig*)get_EBMT_config(),*out,*err) ;
	 }
      else
	 status = EXIT_FAILURE ;
      }
   else
      {
      timer = new FrTimer ;
      if (initialize_EBMT(argv0,config_filename,*err, create_index_requested,
			  update_index_requested, index_directory_name))
	 {
	 process_commandline_options(argc,argv,cerr) ;
	 ebmt_config = (EBMTConfig*)get_EBMT_config() ;
	 EBMT *ebmt = active_EBMT() ;
	 if (showmem)
	    FrMemoryStats(cerr) ;
	 EBfeature_map.finalize(EbFeatureVector::featureSize()) ;
	 if (compute_global_stats_requested)
	    {
	    cout << "Compute global match statistics" << endl ;
	    status = compute_global_match_stats(active_EBMT(),*in,*out) ;
	    }
	 else if (tokenize_to_filename)
	    tokenize_to_file(ebmt,tokenize_to_filename,show_doc_origin) ;
	 else if (update_index_requested)
	    update_index(ebmt,argv0,*out,*in,*err,pack_index_requested) ;
	 else if (autophrase_requested)
	    make_autophrase(ebmt,*err) ;
	 else if (filter_MMR)
	    {
	    FrSymbolTable *sym_t = ebmt->symbolTable()->select() ;
	    extract_MMR_lines(filter_MMR_outfile,stdin,filter_MMR_desired,
			      filter_MMR_max,filter_MMR_passes) ;
	    sym_t->select() ;
	    }
	 else // ebmt_mode
	    {
	    if (EbNetworkServerMode() && port_number > 0)
	       EbRunNetworkServer(ebmt,port_number) ;
	    else
	       status = perform_EBMT(ebmt,*out,*in) ;
	    }
	 if (pack_index_requested && !update_index_requested)
	    {
	    cerr << ";;  pack-index requested, doing so" << endl ;
	    pack_index(ebmt_config,*out,*err) ;
	    cerr << ";;   (pack-index done)" << endl ;
	    }
	 if (dump_index_requested)
	    {
	    cerr << ";;  dump-index requested, to file "
		  << index_dump_filename << endl ;
	    ebmt->dumpIndex(index_dump_filename) ;
	    cerr << ";;    (dump-index done)" << endl ;
	    }
	 save_EBMT_updates() ;
	 shutdown_EBMT() ;
	 }
      }
   if (timer)
      {
      printf("; total time = %.2f seconds\n",timer->readsec()) ;
      delete timer ;
      }
   terminate_program(status) ;
   return status ;
}

// end of file ebmt.cpp //
