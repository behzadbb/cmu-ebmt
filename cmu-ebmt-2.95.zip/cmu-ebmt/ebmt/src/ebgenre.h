/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebgenre.h		genre-specific global variables		*/
/*  LastEdit: 30mar10							*/
/*									*/
/*  (c) Copyright 2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __EBGENRE_H_INCLUDED
#define __EBGENRE_H_INCLUDED

class EbGenreSettings
   {
   private:
      class EBMTGlobalVariables *m_vars ;
      EbGenreSettings *m_next ;
      EbGenreSettings *m_prev ;
   protected:
      char *m_genre ;
   public: // data
      size_t _max_duplicates ;		// max instance of a phrase to use
      size_t _max_duplicates1 ;		// max instances of a unigram to use
      size_t _max_alternatives ;	// max. proposals for a single chunk
      size_t _max_alternatives1 ;	// max. proposals for a single unigram
      size_t _max_match ;		// max. size of source match to use

      bool _use_SPA ;			// use SPA instead of heur. aligner?
      size_t _max_align_ambig ;		// max number of aligns for a srcphrase
      double _align_ambig_cutoff ;	// ratio between best/worst aligns
      double _align_threshold ;		// min align score to allow on output
      double _phrase_threshold ;	// min phrase score to use for alignmnt

      size_t _example_limit_lo ;	// first training instance to use
      size_t _example_limit_hi ;	// last training instance to use

      double _example_weight_start ;
      double _example_weight_end ;
      double _example_weight_range ;
      FrList *_example_origin_weights ;

   protected:
      void link(class EBMTGlobalVariables *vars) ;
   public: // methods
      EbGenreSettings(class EBMTGlobalVariables * = 0, const char *genre = 0) ;
      EbGenreSettings(const EbGenreSettings &,
		      class EBMTGlobalVariables *, const char *newgenre = 0) ;
      ~EbGenreSettings() ;

      // accessors
      EbGenreSettings *next() const { return m_next ; }
      const char *name() const { return m_genre ; }
      static EbGenreSettings *find(const char *genre) ;
      const EBMTGlobalVariables *belongsTo() const { return m_vars ; }
   } ;

#endif /* !__EBGENRE_H_INCLUDED */

// end of file ebgenre.h //
