//----------------------------------------------------------------------

#if 0
static size_t count_words(const FrTextSpans *lattice)
{
   const char *string = lattice->originalString() ;
   if (!string || !*string)
      return 0 ;
   size_t count = 1 ;
   for ( ; *string ; string++)
      {
      if (Fr_isspace(*string))
	 {
	 while (*string && Fr_isspace(*string))
	    string++ ;
	 count++ ;
	 }
      }
   return count ;
}
#endif /* 0 */

