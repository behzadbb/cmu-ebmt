/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.93							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebstruct.cpp	structural-matching support			*/
/*  LastEdit: 19mar10							*/
/*									*/
/*  (c) Copyright 2007,2008,2009,2010 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "ebchunks.h"
#include "ebcmatch.h"
#include "ebcorpus.h"
#include "ebfreq.h"
#include "ebtoken.h"
#include "ebutil.h"
#include "ebglobal.h"

//----------------------------------------------------------------------

static FrTextSpans *build_struct_lattice(FrTextSpans *input_lattice)
{
   FrTextSpans *struct_lattice = new FrTextSpans(input_lattice) ;
   if (!struct_lattice)
      return 0 ;
   // parse structural info in the lattice metadata into spans
   const FrList *source_tags = (FrList*)struct_lattice->metaData("SOURCE") ;
   FrSymbol *sym_POS = struct_lattice->makeSymbol("POS") ;
   const FrList *source_PoS
      = source_tags ? (FrList*)source_tags->assoc(sym_POS,EBMT_equal) : 0;
   if (source_PoS)
      {
      source_PoS = source_PoS->rest() ;	// skip the "POS" at start of list
      size_t textlen = input_lattice->textLength() ;
      FrLocalAllocC(bool,wordbound,1024,textlen+1) ;
      if (wordbound)
	 {
	 for (size_t i = 0 ; i < input_lattice->spanCount() ; i++)
	    {
	    const FrTextSpan *span = input_lattice->getSpan(i) ;
	    if (span)
	       wordbound[span->start()] = true ;
	    }
	 size_t start = 0 ;
	 size_t end = 0 ;
	 for (const FrList *sp = source_PoS ;
	      sp && start < textlen ;
	      sp = sp->rest())
	    {
	    FrObject *pos_value = sp->first() ;
	    if (pos_value && pos_value->consp())
	       pos_value = ((FrList*)pos_value)->first() ;
	    char *pos_text = FrDupString(FrPrintableName(pos_value)) ;
	    if (ignore_source_case)
	       Fr_strlwr(pos_text,char_encoding) ;
	    // scan for next word boundary
	    while (end < textlen && !wordbound[end+1])
	       end++ ;
	    if (pos_text)
	       {
	       // insert a new span covering start to end, inclusive
	       FrList *span_spec = new FrList(new FrInteger(start),
					      new FrInteger(end),
					      new FrString(pos_text)) ;
	       struct_lattice->newSpan(span_spec) ;
	       free_object(span_spec) ;
	       }
	    FrFree(pos_text) ;
	    start = ++end ;
	    }
	 FrLocalFree(wordbound) ;
	 }
      }
   else
      {
      // try to get source_PoS from each individual span in input_lattice
      for (size_t i = 0 ; i < input_lattice->spanCount() ; i++)
	 {
	 const FrTextSpan *span = input_lattice->getSpan(i) ;
	 if (!span)
	    continue ;
	 const FrObject *pos = span->getMetaData("POS") ;
	 if (pos)
	    {
	    if (pos->consp())
	       pos = ((FrList*)pos)->first() ;
	    char *pos_text = FrDupString(FrPrintableName(pos)) ;
	    FrTextSpan *pos_span = new FrTextSpan(span) ;
	    if (pos_text && *pos_text)
	       {
	       if (ignore_source_case)
		  Fr_strlwr(pos_text,char_encoding) ;
	       pos_span->updateText(pos_text) ;
	       }
	    FrFree(pos_text) ;
	    struct_lattice->addSpan(pos_span) ;
	    delete pos_span ;
	    }
	 }
      }
   return struct_lattice ;
}

//----------------------------------------------------------------------

EBMTCandidate *find_structural_matches(FrTextSpans *input_lattice,
				       EBMTCorpus *corpus,
				       const EBMTCandidate *lexical_matches,
				       int transmem_mode,
				       FrCasemapTable number_charmap)
{
   EBMTIndex *index = corpus->getIndex() ;
   EbBWTIndex *idx = index->selectIndex(EbIndex_Struct) ;
   if (!idx || idx->numItems() == 0)	// no structural index means nothing
      return 0 ;			//   to do
   size_t full_len = input_lattice->textLength() ;
   EbClearMatchCover() ;
   FrLocalAllocC(TokenInfo*,tokens,1024,full_len+1) ;
   if (!tokens)
      {
      FrNoMemory("building token information array") ;
      return 0 ;
      }
   // active chunks will be split into N lists in an array, indexed by the
   //    END of the chunk in the original untokenized input
   FrLocalAlloc(EbCorpusMatches*,active,1024,full_len+1) ;
   if (!active)
      {
      FrLocalFree(tokens) ;
      FrNoMemory("while setting up to find structural corpus matches") ;
      return 0 ;
      }
   FrTextSpans *struct_lattice = EbGetStructuralLattice(input_lattice) ;
   if (!struct_lattice && 
       (struct_lattice = build_struct_lattice(input_lattice)) == 0)
      {
      FrLocalFree(tokens) ;
      FrLocalFree(active) ;
      FrNoMemory("while creating a structural-info lattice") ;
      return 0 ;
      }
   EBMTCandidate *generalizations = build_token_info(struct_lattice,corpus,
						     0,tokens,number_charmap) ;
   generalizations->deleteList() ;
   EbMatchFrequency match_freqs(lexical_matches,full_len,
				max_duplicates,max_duplicates1) ;
   EbCorpusMatches *matches = 0 ;
   EbCorpusMatches *prev_matches = 0 ;
   // find all matches in the structural index
   if (transmem_mode != EbTRANSMEM_OFF)
      {
      matches = find_matches(index,EbIndex_Struct,struct_lattice,tokens,
			     active,matches,true,&match_freqs) ;
      match_freqs.updateFrequencies(matches,0) ;
      prev_matches = matches ;
      }
   if (!matches && transmem_mode != EbTRANSMEM_ON)
      {
      matches = find_matches(index,EbIndex_Struct,struct_lattice,tokens,
			     active,matches,false,&match_freqs) ;
      match_freqs.updateFrequencies(matches,prev_matches) ;
      prev_matches = matches ;
      }
   // add the matches extending to the end of the input to the list of
   //   all finished matches
   matches = finished_matches(active[full_len],matches,index,
			      false,&match_freqs) ;
   FrLocalFree(active) ;
   // ignore matches that are too short
   matches = EbFilterMatches(matches,min_struct_match,max_duplicates) ;
   // convert remaining matches into candidate chunks
   EBMTCandidate *candidates = 0 ;
   if (preparing_for_doc)
      {
      size_t max = EbPrepDocMaxDups(index) ;
      matches = EbFilterMatches(matches,prepare_doc_minlen,max) ;
      while (matches)
	 {
	 matches->incrDocWeights(index) ;
	 EbCorpusMatches *m = matches ; 
	 matches = matches->next() ;
	 delete m ;
	 }
      }
   else if (matches)
      {
      candidates = candidates->nconc(EbMakeCandidates(matches,input_lattice,
						      corpus,false,0)) ;
      }
   for (size_t location = 0 ; location < full_len ; location++)
      {
      delete tokens[location] ;
      tokens[location] = 0 ;
      }
   // we can't delete struct_lattice, since the returned candidates have
   //   pointers to its spans, so stuff it into the caller's input_lattice
   //   and let EbFreeLattice() delete it once the caller is done with
   //   all the candidates
   EbStoreStructuralLattice(input_lattice,struct_lattice) ;
   FrLocalFree(tokens) ;
   return candidates ;
}

// end of file ebstruct.cpp //
