/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebsource.h		EBMT data source records		*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2006,	*/
/*		2007,2008,2009 Ralf Brown				*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __EBSOURCE_H_INCLUDED
#define __EBSOURCE_H_INCLUDED

//----------------------------------------------------------------------

/*
Format of corpus source-file index (binary file):
        24 BYTEs  signature "Glossary Source Files\n",26,0
 	   BYTE	  source-file file format version number
         3 BYTEs  reserved (0) for future enhancements
	 4 BYTEs  number of source-file entries (big-endian)
        32 BYTEs  reserved (0) for future enhancements
	   var	  N source-file entries, each consisting of
	             4 BYTEs offset of first line from indicated source file
		     4 BYTEs offset past last line from indicated source file
		     N BYTEs ASCIZ filename from which entries came

*/

//----------------------------------------------------------------------

typedef unsigned char LONGbuffer[4] ;

class EbDataSource
   {
   private:
      off_t m_start, m_end ;		// location in corpus file
      char *m_sourcename ;		// name of original training file
      double m_weight ;			// overall weight of this source
      size_t m_rank ;			// ranking by source weight
   public:
      void *operator new(size_t, void *where) { return where ; }
      EbDataSource()
	 { m_start = m_end = 0; m_sourcename = 0; m_weight = 0.0; m_rank = 0; }
      EbDataSource(const char *file, off_t s, off_t e) ;
      ~EbDataSource() ;
      bool save(const char *filename, size_t num_sources) const ;
      void expandSource(off_t new_end) { m_end = new_end ; }
      void clear()
	    {
	    FrFree(m_sourcename) ; m_sourcename = 0 ;
	    m_start = m_end = 0 ;
	    m_weight = 0.0 ;
	    }
      void incrWeight(double incr = 1.0) { m_weight += incr ; }
      void setWeight(double new_wt) { m_weight = new_wt ; }
      void setRank(size_t rnk) { m_rank = rnk ; }

      // access to internal state
      const char *getName() const { return m_sourcename ; }
      off_t startLoc() const { return m_start ; }
      off_t endLoc() const { return m_end ; }
      off_t sourceLength() const { return m_end - m_start + 1 ; }
      double weight() const { return m_weight ; }
      size_t rank() const { return m_rank ; }
      bool sameSource(const char *file, off_t strt) ;
      bool sameSource(const char *file) ;
   } ;

//----------------------------------------------------------------------

class EbDataSourceList
   {
   private:
      EbDataSource *sources ;
      size_t num_sources ;
      bool m_loaded ;
      bool m_changed ;
      bool m_have_weights ;
   public:
      EbDataSourceList() ;
      ~EbDataSourceList() ;

      bool load(const char *filename, bool force_creation = false) ;
      bool save(const char *filename) ;

      // manipulators
      bool addSource(const char *filename, FILE *fp) ;
      bool addSource(const char *filename, off_t start, off_t end) ;
      void resetWeights() ;
      void incrWeight(size_t example_number) ;
      void normalizeWeights() ;
      void rankSources() ;

      // accessors
      EbDataSource *source(size_t N) const
	 { return sources ? &sources[N] : 0 ; }
      EbDataSource *find(off_t location) ;
      const EbDataSource *find(off_t location) const ;
      size_t numSources() const { return num_sources ; }
      bool changed() const { return m_changed ; }
      bool haveWeights() const { return m_have_weights ; }
      const char *getName(size_t N) const
	 { return sources ? sources[N].getName() : 0 ; }
      bool OK() const ;
   } ;

//----------------------------------------------------------------------

size_t EbLoadDataSources(const char *filename,
			 EbDataSource *&sources,
			 bool force_creation) ;

#endif /* !__EBSOURCE_H_INCLUDED */

// end of file ebsource.h //
