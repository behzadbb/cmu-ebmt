/************************************************************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebconstr.cpp		class EbAlignConstraints		*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 2003,2004,2006,2007,2008,2009 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#if defined(__GNUC__)
#  pragma implementation "ebbitext.h"
#endif

#include "FramepaC.h"
#include "ebalign.h"
#include "ebbitext.h"
#include "ebglobal.h"

/************************************************************************/
/*    Types for this module						*/
/************************************************************************/

class EbAlignStats
   {
   private:
      size_t m_total ;			// total number of word occurrences
      size_t m_unambig ;		// number of unambig alignments
      size_t m_left ;			// number of left-hand relations
      size_t m_right ;			// number of right-hand relations
      size_t m_boundleft ;
      size_t m_boundright ;
      size_t m_revleft ;
      size_t m_revright ;
   public:
      EbAlignStats()
	 { m_total = 0 ; m_unambig = 0 ;
	   m_left = m_right = 0 ;
	   m_boundleft = m_boundright = 0 ;
	   m_revleft = m_revright = 0 ; }
      ~EbAlignStats() {}

      // manipulators
      void incrTotals(bool unambig) ;
      void incrCounts(bool on_left,int type) ;

      // accessors
      size_t totalOccurrences() const { return m_total ; }
      size_t unambigOccurrences() const { return m_unambig ; }
      size_t totalLeft() const { return m_left ; }
      size_t boundLeft() const { return m_boundleft ; }
      size_t reversedLeft() const { return m_revleft ; }
      size_t totalRight() const { return m_right ; }
      size_t boundRight() const { return m_boundright ; }
      size_t reversedRight() const { return m_revright ; }
   } ;

/************************************************************************/
/*    Helper Functions							*/
/************************************************************************/

//----------------------------------------------------------------------

static bool clear_stats(FrSymHashEntry *entry, va_list)
{
   EbAlignStats *stats = (EbAlignStats*)entry->getUserData() ;
   if (stats)
      {
      delete stats ;
      entry->setUserData(0) ;
      }
   return true ;			// continue iterating
}

/************************************************************************/
/*    Methods for class EbAlignStats					*/
/************************************************************************/

void EbAlignStats::incrTotals(bool unambig)
{
   m_total++ ;
   if (unambig) m_unambig++ ;
   return ;
}

//----------------------------------------------------------------------

void EbAlignStats::incrCounts(bool on_left,int type)
{
   if (on_left)
      m_left++ ;
   else
      m_right++ ;
   if ((type & EbAlignConstraints::ct_boundleft) != 0) m_boundleft++ ;
   if ((type & EbAlignConstraints::ct_reverseleft) != 0) m_revleft++ ;
   if ((type & EbAlignConstraints::ct_boundright) != 0) m_boundright++ ;
   if ((type & EbAlignConstraints::ct_reverseright) != 0) m_revright++ ;
   return ;
}

/************************************************************************/
/*    Methods for class EbAlignConstraints				*/
/************************************************************************/

EbAlignConstraints::EbAlignConstraints(const Dictionary *dict,
				       const char *filename)
{
   m_dict = dict ;
   m_source_types = ct_none ;
   m_target_types = ct_none ;
   m_source = new FrSymHashTable ;
   m_target = new FrSymHashTable ;
   m_source_stats = 0 ;
   m_target_stats = 0 ;
   if (m_source)
      m_source->expand(100) ;
   if (m_target)
      m_target->expand(100) ;
   if (filename && *filename)
      {
      FILE *fp = fopen(filename,"r") ;
      if (fp)
	 {
	 if (!load(fp) && !quiet_mode)
	    FrWarningVA("error loading alignment constraints from file\n"
			"\t%s",filename) ;
	 fclose(fp) ;
	 }
      else if (!quiet_mode)
	 FrWarningVA("unable to access alignment constraints in file\n"
		     "\t%s",filename) ;
      }
   return ;
}

//----------------------------------------------------------------------

EbAlignConstraints::EbAlignConstraints(const Dictionary *dict,
				       const FrList *s_left,
				       const FrList *s_right,
				       const FrList *t_left,
				       const FrList *t_right)
{
   m_dict = dict ;
   m_source_types = ct_none ;
   m_target_types = ct_none ;
   m_source = new FrSymHashTable ;
   m_target = new FrSymHashTable ;
   m_source_stats = 0 ;
   m_target_stats = 0 ;
   if (m_source)
      {
      size_t size = 100 ;
      size_t count = listlength(s_left) ;
      if (count > size) size = count ;
      count = listlength(s_right) ;
      if (count > size) size = count ;
      m_source->expand(size+10) ;
      }
   if (m_target)
      {
      size_t size = 100 ;
      size_t count = listlength(s_left) ;
      if (count > size) size = count ;
      count = listlength(s_right) ;
      if (count > size) size = count ;
      m_target->expand(size+10) ;
      }
   addBoundWords(s_left,true,false,true) ;
   addBoundWords(s_right,true,false,false) ;
   addBoundWords(t_left,false,false,true) ;
   addBoundWords(t_right,false,false,false) ;
   return ;
}

//----------------------------------------------------------------------

EbAlignConstraints::~EbAlignConstraints()
{
   clear() ;
   if (m_source_stats)
      {
      m_source_stats->doHashEntries(clear_stats) ;
      delete m_source_stats ;
      m_source_stats = 0 ;
      }
   if (m_target_stats)
      {
      m_target_stats->doHashEntries(clear_stats) ;
      delete m_target_stats ;
      m_target_stats = 0 ;
      }
   return ;
}

//----------------------------------------------------------------------

void EbAlignConstraints::clear()
{
   delete m_source ;		m_source = 0 ;
   delete m_target ;		m_target = 0 ;
   m_source_types = ct_none ;
   m_target_types = ct_none ;
   return ;
}

//----------------------------------------------------------------------

bool EbAlignConstraints::load(FILE *fp)
{
   if (fp)
      {
      char buf[FrMAX_LINE] ;
      bool source = true ;
      bool reverse = false ;
      bool left = true ;
      while (!feof(fp) && fgets(buf,sizeof(buf),fp) != 0)
	 {
	 char *line = buf ;
	 FrSkipWhitespace(line) ;
	 char *end = strchr(line,'\0') ;
	 while (end > line && Fr_isspace(end[-1]))
	    *--end = '\0' ;
	 if (line[0] == ';' && line[1] == ';')
	    continue ;			// it's a comment
	 else if (*line == '[' && line[1] != '\0')
	    {
	    // parse the section header
	    source = (Fr_stristr(line,"target") == 0) ;
	    reverse = (Fr_stristr(line,"rev") != 0) ;
	    left = (Fr_stristr(line,"right") == 0) ;
	    }
	 else
	    {
	    // accumulate the words for the current section
	    addBoundWord(line,source,reverse,left) ;
	    }
	 }
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

bool EbAlignConstraints::load(const char *filename)
{
   if (filename && *filename)
      {
      FILE *fp = fopen(filename,"r") ;
      if (fp)
	 {
	 clear() ;
	 load(fp) ;
	 fclose(fp) ;
	 }
      else if (!quiet_mode)
	 {
	 FrWarningVA("unable to open '%s' for reading",filename) ;
	 return false ;
	 }
      }
   return true ;
}

//----------------------------------------------------------------------

static bool write_constraint(FrSymHashEntry *entry, va_list args)
{
   FrVarArg(FILE*,fp) ;
   FrVarArg(int,type) ;
   if ((((uintptr_t)entry->getUserData()) & type) != 0)
      {
      fprintf(fp,"%s\n",entry->getName()->symbolName()) ;
      }
   return true ;			// continue iterating
}

//----------------------------------------------------------------------

static bool write_constraints(FILE *fp, const FrSymHashTable *ht,
			      int type)
{
   if (ht)
      return ((FrSymHashTable*)ht)->doHashEntries(write_constraint,fp,type) ;
   return true ;
}

//----------------------------------------------------------------------

bool EbAlignConstraints::save(FILE *fp) const
{
   if (fp)
      {
      bool success = true ;
      fprintf(fp,";;; Alignment Constraints\n") ;
      if (sourceLeftBindings())
	 {
	 fprintf(fp,"[source-left-bound]\n") ;
	 if (!write_constraints(fp,m_source,ct_boundleft))
	    success = false ;
	 }
      if (sourceRightBindings())
	 {
	 fprintf(fp,"[source-right-bound]\n") ;
	 if (!write_constraints(fp,m_source,ct_boundright))
	    success = false ;
	 }
      if (sourceLeftReversals())
	 {
	 fprintf(fp,"[source-left-reversed]\n") ;
	 if (!write_constraints(fp,m_source,ct_reverseleft))
	    success = false ;
	 }
      if (sourceRightReversals())
	 {
	 fprintf(fp,"[source-right-reversed]\n") ;
	 if (!write_constraints(fp,m_source,ct_reverseright))
	    success = false ;
	 }
      if (targetLeftBindings())
	 {
	 fprintf(fp,"[target-left-bound]\n") ;
	 if (!write_constraints(fp,m_target,ct_boundleft))
	    success = false ;
	 }
      if (targetRightBindings())
	 {
	 fprintf(fp,"[target-right-bound]\n") ;
	 if (!write_constraints(fp,m_target,ct_boundright))
	    success = false ;
	 }
      if (targetLeftReversals())
	 {
	 fprintf(fp,"[target-left-reversed]\n") ;
	 if (!write_constraints(fp,m_target,ct_reverseleft))
	    success = false ;
	 }
      if (targetRightReversals())
	 {
	 fprintf(fp,"[target-right-reversed]\n") ;
	 if (!write_constraints(fp,m_target,ct_reverseright))
	    success = false ;
	 }
      fprintf(fp,";;; end of file\n") ;
      return success ;
      }
   return false ;
}

//----------------------------------------------------------------------

bool EbAlignConstraints::save(const char *filename) const
{
   if (filename && *filename)
      {
      FILE *fp = fopen(filename,"w") ;
      if (fp)
	 {
	 save(fp) ;
	 fclose(fp) ;
	 }
      else
	 {
	 FrWarningVA("unable to open '%s' for writing",filename) ;
	 return false ;
	 }
      }
   return true ;
}

//----------------------------------------------------------------------

static bool infer_constraints(FrSymHashEntry *entry, va_list args)
{
   EbAlignStats *stats = (EbAlignStats*)entry->getUserData() ;
   if (stats)
      {
      FrVarArg(size_t,min_freq) ;
      FrVarArg(double,max_contra) ;
      uintptr_t type = EbAlignConstraints::ct_none ;
      size_t total = stats->totalLeft() ;
      bool have_data = false ;
      if (total >= min_freq)
	 {
	 size_t contra_limit = (size_t)(total * max_contra) ;
	 size_t contra = /*total - stats->boundLeft() +*/ stats->reversedLeft() ;
//cout<<"  check left " <<entry->getName()<<", contra = "<<contra<<", limit = "<<contra_limit<<endl ;
	 if (contra <= contra_limit)
	    type |= EbAlignConstraints::ct_boundleft ;
	 contra = /*total - stats->reversedLeft() +*/ stats->boundLeft() ;
	 if (contra <= contra_limit)
	    type |= EbAlignConstraints::ct_reverseleft ;
	 have_data = true ;
	 }
      total = stats->totalRight() ;
      if (total >= min_freq)
	 {
	 size_t contra_limit = (size_t)(total * max_contra) ;
	 size_t contra = /*total - stats->boundRight() +*/ stats->reversedRight() ;
//cout<<"  check right " <<entry->getName()<<", contra = "<<contra<<", limit = "<<contra_limit<<endl ;
	 if (stats->boundRight() > total/2 && contra <= contra_limit)
	    type |= EbAlignConstraints::ct_boundright ;
	 contra = /*total - stats->reversedRight() +*/ stats->boundRight() ;
	 if (stats->reversedRight() > total/2 && contra <= contra_limit)
	    type |= EbAlignConstraints::ct_reverseright ;
	 have_data = true ;
	 }
      if (have_data)
	 {
//if(type!=EbAlignConstraints::ct_none)cout <<"    adding "<<entry->getName()<<" "<<type<<endl ;
	 FrVarArg(FrSymHashTable*,ht) ;
	 ht->add(entry->getName(),(void*)type) ;
	 }
      }
   return true ;			// continue iterating
}

//----------------------------------------------------------------------

bool EbAlignConstraints::inferConstraints(size_t min_freq,
					    double max_contra)
{
//cout<<"inferConstraints("<<min_freq<<","<<max_contra<<")"<<endl ;
   bool inferred = false ;
   if (m_source_stats)
      {
      delete m_source ;
      m_source = new FrSymHashTable ;
      if (m_source)
	 {
	 m_source_stats->doHashEntries(infer_constraints,min_freq,max_contra,
				       m_source) ;
	 m_source_types = (ct_boundleft | ct_boundright |
			   ct_reverseleft | ct_reverseright) ;
	 inferred = true ;
	 }
      }
   if (m_target_stats)
      {
      delete m_target ;
      m_target = new FrSymHashTable ;
      if (m_target)
	 {
	 m_target_stats->doHashEntries(infer_constraints,min_freq,max_contra,
				       m_target) ;
	 m_target_types = (ct_boundleft | ct_boundright |
			   ct_reverseleft | ct_reverseright) ;
	 inferred = true ;
	 }
      }
   return inferred ;
}

//----------------------------------------------------------------------

void EbAlignConstraints::addBoundWord(const char *word, bool source_lang,
				      bool reverse_order, bool on_left)
{
   FrString *wordstr = new FrString(word) ;
   if (wordstr)
      {
      wordstr->uppercaseString(char_encoding) ;
      FrSymbol *wordsym = FrSymbolTable::add(wordstr->stringValue()) ;
      free_object(wordstr) ;
      FrSymHashTable *ht = source_lang ? m_source : m_target ;
      uintptr_t type ;
      if (on_left)
	 type = (reverse_order ? ct_reverseleft : ct_boundleft) ;
      else
	 type = (reverse_order ? ct_reverseright : ct_boundright) ;
      if (ht)
	 {
	 FrSymHashEntry *entry = ht->lookup(wordsym) ;
	 if (entry)
	    entry->setUserData((void*)(type |
				       (uintptr_t)entry->getUserData())) ;
	 else
	    ht->add(wordsym,(void*)type) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void EbAlignConstraints::addBoundWords(const FrList *words, bool source_lang,
				       bool reverse_order, bool on_left)
{
   for ( ; words ; words = words->rest())
      {
      const char *word = FrPrintableName(words->first()) ;
      if (word)
	 addBoundWord(word,source_lang,reverse_order,on_left) ;
      }
   return ;
}

//----------------------------------------------------------------------

void EbAlignConstraints::addStats(FrSymbol *word, bool source_lang,
				  bool unambig)
{
   FrSymHashTable *ht ;
   if (source_lang)
      {
      if (!m_source_stats)
	 {
	 m_source_stats = new FrSymHashTable ;
	 if (!m_source_stats)
	    return ;
	 m_source_stats->expand(100) ;
	 }
      ht = m_source_stats ;
      }
   else
      {
      if (!m_target_stats)
	 {
	 m_target_stats = new FrSymHashTable ;
	 if (!m_target_stats)
	    return ;
	 m_target_stats->expand(100) ;
	 }
      ht = m_target_stats ;
      }
   FrSymHashEntry *entry = ht->lookup(word) ;
   EbAlignStats *stats ;
   if (entry)
      stats = (EbAlignStats*)entry->getUserData() ;
   else
      {
      stats = new EbAlignStats() ;
      if (!stats)
	 {
	 static bool warned(false) ;
	 if (!warned)
	    FrNoMemory("accumulating alignment statistics") ;
	 warned = true ;
	 return ;
	 }
      ht->add(word,stats) ;
      }
   stats->incrTotals(unambig) ;
   return ;
}

//----------------------------------------------------------------------

static void add_stats(FrSymbol *word, FrSymHashTable *ht, int &types,
		      bool on_left, bool bound, bool reversed)
{
   int type = EbAlignConstraints::ct_none ;
   if (on_left)
      {
      if (bound)
	 type = EbAlignConstraints::ct_boundleft ;
      else if (reversed)
	 type = EbAlignConstraints::ct_reverseleft ;
      }
   else
      {
      if (bound)
	 type = EbAlignConstraints::ct_boundright ;
      else if (reversed)
	 type = EbAlignConstraints::ct_reverseright ;
      }
   FrSymHashEntry *entry = ht->lookup(word) ;
   EbAlignStats *stats ;
   if (entry)
      stats = (EbAlignStats*)entry->getUserData() ;
   else
      {
      stats = new EbAlignStats() ;
      if (!stats)
	 {
	 FrNoMemory("accumulating alignment statistics") ;
	 return ;
	 }
      ht->add(word,stats) ;
      }
   types |= type ;
   stats->incrCounts(on_left,type) ;
   return ;
}

//----------------------------------------------------------------------

void EbAlignConstraints::addSourceStats(FrSymbol *word, bool on_left,
					bool bound, bool reversed)
{
   if (!m_source_stats)
      {
      m_source_stats = new FrSymHashTable ;
      if (!m_source_stats)
	 return ;
      m_source_stats->expand(100) ;
      }
   add_stats(word,m_source_stats,m_source_types,on_left,bound,reversed) ;
   return ;
}

//----------------------------------------------------------------------

void EbAlignConstraints::addTargetStats(FrSymbol *word, bool on_left,
					bool bound, bool reversed)
{
   if (!m_target_stats)
      {
      m_target_stats = new FrSymHashTable ;
      if (!m_target_stats)
	 return ;
      m_target_stats->expand(100) ;
      }
   add_stats(word,m_target_stats,m_target_types,on_left,bound,reversed) ;
   return ;
}

//----------------------------------------------------------------------

static bool is_of_type(FrSymbol *word, const FrSymHashTable *ht, int type)
{
   if (!ht)
      return false ;
   FrSymHashEntry *entry = ht->lookup(word) ;
   if (entry)
      return (((uintptr_t)entry->getUserData()) & type) != 0 ;
   return false ;
}

//----------------------------------------------------------------------

bool EbAlignConstraints::isSourceBoundLeft(FrSymbol *word) const
{
   return is_of_type(word,m_source,ct_boundleft) ;
}

//----------------------------------------------------------------------

bool EbAlignConstraints::isSourceBoundRight(FrSymbol *word) const
{
   return is_of_type(word,m_source,ct_boundright) ;
}

//----------------------------------------------------------------------

bool EbAlignConstraints::isTargetBoundLeft(FrSymbol *word) const
{
   return is_of_type(word,m_target,ct_boundleft) ;
}

//----------------------------------------------------------------------

bool EbAlignConstraints::isTargetBoundRight(FrSymbol *word) const
{
   return is_of_type(word,m_target,ct_boundright) ;
}

//----------------------------------------------------------------------

bool EbAlignConstraints::isSourceReversedLeft(FrSymbol *word) const
{
   return is_of_type(word,m_source,ct_reverseleft) ;
}

//----------------------------------------------------------------------

bool EbAlignConstraints::isSourceReversedRight(FrSymbol *word) const
{
   return is_of_type(word,m_source,ct_reverseright) ;
}

//----------------------------------------------------------------------

bool EbAlignConstraints::isTargetReversedLeft(FrSymbol *word) const
{
   return is_of_type(word,m_target,ct_reverseleft) ;
}

//----------------------------------------------------------------------

bool EbAlignConstraints::isTargetReversedRight(FrSymbol *word) const
{
   return is_of_type(word,m_target,ct_reverseright) ;
}

// end of file ebconstr.cpp //
