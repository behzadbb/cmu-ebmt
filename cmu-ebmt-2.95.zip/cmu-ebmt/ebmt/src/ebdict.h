/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss -- Example-Based Machine Translation			*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebdict.h	EBMT translation dictionary - private types	*/
/*  LastEdit: 04nov09	28jan08							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2006,2007,2008 Ralf Brown				*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __EBDICT_H_INCLUDED
#define __EBDICT_H_INCLUDED

/************************************************************************/
/*	Manifest constants						*/
/************************************************************************/

#define DICTIONARY_SLACK 5000
#define DEFINITION_SLACK 5000
#define HEADNAMES_INCR 4096

// keep SHORT_WORDINFO defined at all times -- commenting it out will change
//   the file format
#ifndef DICT_V3
#define SHORT_WORDINFO
#endif

/************************************************************************/
/************************************************************************/

class DictWordInfo
   {
   private:
      static const char *names ;
#ifdef SHORT_WORDINFO
      char m_name[3] ;
      char m_index[3] ;
      char m_freq[3] ;
#else
      LONGbuffer m_name ;
      LONGbuffer m_index ;
      LONGbuffer m_freq ;
#endif /* SHORT_WORDINFO */
   public:
      void *operator new(size_t,void *where) { return where ; }
      DictWordInfo() {} ;
      DictWordInfo(size_t name_offset, uint32_t index, uint32_t freq = 0) ;

      // accessors
#ifdef SHORT_WORDINFO
      size_t nameOffset() const { return (size_t)FrLoadThreebyte(m_name) ; }
      size_t index() const { return (size_t)FrLoadThreebyte(m_index) ; }
      uint32_t frequency() const { return FrLoadThreebyte(m_freq) ; }
#else
      size_t nameOffset() const { return (size_t)FrLoadLong(m_name) ; }
      size_t index() const { return (size_t)FrLoadLong(m_index) ; }
      uint32_t frequency() const { return FrLoadLong(m_freq) ; }
#endif  /* SHORT_WORDINFO */

      // support for FrQuickSort
      static int compare(DictWordInfo &x, DictWordInfo &y)
	 { return strcmp(names+x.nameOffset(), names+y.nameOffset()) ; }
      static void swap(DictWordInfo &x, DictWordInfo &y)
         { DictWordInfo tmp = x ; x = y ; y = tmp ; }

      // modifiers
#ifdef SHORT_WORDINFO
      void setNameOffset(size_t offset) { FrStoreThreebyte(offset,m_name) ; }
      void setIndex(size_t newindex) { FrStoreThreebyte(newindex,m_index) ; }
      void setFrequency(uint32_t frequency) { FrStoreThreebyte(frequency,m_freq) ; }
#else
      void setNameOffset(size_t offset) { FrStoreLong(offset,m_name) ; }
      void setIndex(size_t newindex) { FrStoreLong(newindex,m_index) ; }
      void setFrequency(uint32_t frequency) { FrStoreLong(frequency,m_freq) ; }
#endif /* SHORT_WORDINFO */
      void incrFreq(uint32_t incr) ;
      static void setNamesBase(const char *base) { names = base ; }
   } ;

/************************************************************************/
/************************************************************************/

#endif /* !__EBDICT_H_INCLUDED */

// end of file ebdict.h //
