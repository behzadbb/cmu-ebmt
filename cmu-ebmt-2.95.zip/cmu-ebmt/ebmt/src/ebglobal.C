/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebglobal.cpp		global variables for PanEBMT		*/
/*  LastEdit: 05apr10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*  with contributions by Aaron B. Phillips				*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "ebconfig.h"
#include "ebindex.h"	// for EbEx_LENGTHMASK, AUTO_MAXLEN
#include "ebmkdict.h"	// for DEFAULT_MUTUAL_INFO_WINDOW, etc.
#include "ebglobal.h"

#ifdef FrSTRICT_CPLUSPLUS
# include <string>
#else
# include <string.h>
#endif /* FrSTRICT_CPLUSPLUS */

/************************************************************************/
/*	Manifest constants for this module				*/
/************************************************************************/

/************************************************************************/
/*	Global variables shared with other modules			*/
/************************************************************************/

EBMTGlobalVariables ebmt_vars ;
FrFeatureVectorMap  EBfeature_map ;

/************************************************************************/
/*	Global variables for this module				*/
/************************************************************************/

static EBMTGlobalVariables *active_vars = 0 ;
static EBMTGlobalVariables *default_vars = 0 ;

/************************************************************************/
/*	Helper Functions						*/
/************************************************************************/

void clear_regex_list(FrRegExp *re_list)
{
   while (re_list)
      {
      FrRegExp *tmp = re_list ;
      re_list = re_list->next() ;
      delete tmp ;
      }
   return ;
}

/************************************************************************/
/*	Methods for class EBMTGlobalVariables				*/
/************************************************************************/

EBMTGlobalVariables::EBMTGlobalVariables()
{
   _abbrevs_list = 0 ;
   genre_list = 0 ;
   _pending_metadata = 0 ;
   _thread_pool = 0 ;
   applyDefaultConfig() ;
   applyConfiguration(0) ;
   return ;
}

//----------------------------------------------------------------------

EBMTGlobalVariables::EBMTGlobalVariables(const EBMTGlobalVariables &vars)
{
   memcpy(this,&vars,sizeof(EBMTGlobalVariables)) ;
   // fix up the items which are allocated on the heap
   _thread_pool = 0 ;
   if (_word_delimiters)
      {
      char *delimiters = FrNewN(char,256) ;
      if (delimiters)
	 memcpy(delimiters,_word_delimiters,256) ;
      _word_delimiters = delimiters ;
      }
   if (_pending_metadata)
      _pending_metadata = (FrStruct*)_pending_metadata->deepcopy() ;
   EbGenreSettings *g = genre_list ;
   genre_list = 0 ;
   EbGenreSettings *curr_g = genre ;
   genre = 0 ;
   for ( ; g ; g = g->next())
      {
      EbGenreSettings *new_g = new EbGenreSettings(*g,this,0) ;
      if (g == curr_g)
	 genre = new_g ;
      }
   return ;
}

//----------------------------------------------------------------------

EBMTGlobalVariables::~EBMTGlobalVariables()
{
   if ((this == active_vars || this == &ebmt_vars) && default_vars)
      default_vars->select() ;
   if (this == &ebmt_vars)
      return ;
   free() ;
   return ;
}

//----------------------------------------------------------------------

void EBMTGlobalVariables::free()
{
   // free any variable allocated on the heap
   clear_regex_list(_source_regex_list) ; _source_regex_list = 0 ;
   clear_regex_list(_target_regex_list) ; _target_regex_list = 0 ;
   FrFree(_word_delimiters) ;		_word_delimiters = 0 ;
   FrFreeAbbreviationList(_abbrevs_list) ; _abbrevs_list = 0 ;
   genre = 0 ;
   while (genre_list && genre_list->belongsTo() == this)
      {
      EbGenreSettings *g = genre_list->next() ;
      delete genre_list ;
      genre_list = g ;
      }
   free_object(_pending_metadata) ;
   return ;
}

//----------------------------------------------------------------------

void EBMTGlobalVariables::applyDefaultConfig()
{
   genre_list = genre = new EbGenreSettings(this) ;
   // bool
   _add_alignments = false ;
   _print_alignments = false ;
   _Unicode_bswap = false ;
   _verbose = false ;
   _trace_matching = false ;
   _showmem = false ;
   _underscore_hack = false ;
   _match_accented = false ;
   _ignore_accents = false ;
   _compute_coverage = false ;
   _export_corpus_requested = false ;
   _export_dict_requested = false ;
   _allow_gapped_matches = false ;
   _ignore_source_case = false ;
   _canonicalized_input_data = false ;
   _allow_memory_mapping = true ;
   _touch_all_memory = false ;
   _map_corpus_subfiles = false ;
   _infer_min_frequency = 100 ;
   _infer_max_contradictions = 0.01 ;	// must be 99% confident to infer it
   _compute_mutual_info = false ;
   _mutual_info_via_chisquared = false ;
   _mutual_info_oneway = false ;
   _dict_extracting_HF = true ;
   _dict_loading_counts = false ;
   _dict_storing_counts = false ;
   _reverse_languages = false ;
   _monolingual_data = false ;
   _quiet_mode = false ;
   _EBMT_fill_gaps = true ;
   _allow_token_recursion = false ;
   _use_compressed_index = false ;
   _use_stdin = false ;
   _index_original = false ;
   _strip_punct = false ;
   _double_count_phrases = false ;
   _learn_dict_phrases = false ;
   _dict_keep_case = true ;
   _show_source_text = false ;
   _load_dict_readonly = false ;
   _load_corpus_readonly = false ;
   _reconstrain_bitext = true ;
   _preparing_for_doc = false ;

   // char *
   _dict_export_file = 0 ;
   _dict_HF_filename = 0 ;
   _dict_load_filename = 0 ;
   _dict_store_filename = 0 ;
   _word_delimiters = 0 ;
   _metainfo_ht = 0 ;

   // int or size_t
   _max_word_ratio = 3 ;   // target may not be more than triple src len
   _min_word_ratio = 2 ;   // target must be >= half as long as source
   _max_dict_translations = ~0 ;
   _max_sentence_length = EbEx_LENGTHMASK ;
   _mutual_info_window = DEFAULT_MUTUAL_INFO_WINDOW ;
   _dict_min_occurrences = 2 ;
   _lines_per_chunk = 0 ;
   _dict_bias_low = 1 ;
   _dict_bias_high = 1 ;
   _min_phrase_length = 2 ;
   _EBMT_word_order_similarity = 0 ;
   _autophrase_freq_thresh = INT_MAX ;
   _autophrase_max_length = AUTO_MAXLEN ;
   _total_input_len = 0 ;
   _total_match_count = 0 ;
   _gapped_match_count = 0 ;
   _ungapped_match_count = 0 ;
   _skipped_training_instances = 0 ;
   _covered_words = 0 ;
   _covered_bytes = 0 ;
   _total_words = 0 ;
   _total_bytes = 0 ;
   _total_arcs = 0 ;
   _total_words_in_arcs = 0 ;

   // double
   _dict_HF_threshold = 0.20 ;
   _dict_correspondence_threshold = 0.5 ;
   _dict_correspondence_threshold_low = 0.4 ;
   _dict_correspondence_threshold_high = 0.9 ;
   _dict_store_threshold = 0.05 ;
   _dict_bias_range = 0.10 ;

   // other types
   _genre_names = 0 ;
   _source_regex_list = 0 ;
   _target_regex_list = 0 ;
   _char_encoding = FrChEnc_Latin1 ;
   _stemword_ht = 0 ;
   _named_entity_spec = 0 ;

   // feature vector entries
   _featureID_score = EBfeature_map.addFeature("Score") ;
   _featureID_weight = EBfeature_map.addFeature("ArcWeight") ;
   _featureID_confidence = EBfeature_map.addFeature("Confidence") ;
   _featureID_probability = EBfeature_map.addFeature("Probability") ;
   _featureID_frequency = EBfeature_map.addFeature("Frequency") ;
#if 0
   _featureID_frequency1 = EBfeature_map.addFeature("Frequency1") ;
   _featureID_frequency2 = EBfeature_map.addFeature("Frequency2") ;
   _featureID_frequency3 = EBfeature_map.addFeature("Frequency3") ;
   _featureID_frequency4 = EBfeature_map.addFeature("Frequency4") ;
   _featureID_frequency5 = EBfeature_map.addFeature("Frequency5") ;
   _featureID_frequencylong = EBfeature_map.addFeature("FrequencyLong") ;
#endif
   _featureID_mass = EBfeature_map.addFeature("Mass") ;
   _featureID_quality = EBfeature_map.addFeature("Quality") ;
   _featureID_alignment = EBfeature_map.addFeature("Alignment") ;
   _featureID_complete = EBfeature_map.addFeature("Complete") ;
   _featureID_chunking = EBfeature_map.addFeature("Chunking",true) ;
   _featureID_doccontext = EBfeature_map.addFeature("DocContext",true) ;
   _featureID_sntcontext = EBfeature_map.addFeature("SntContext") ;
   _featureID_phrcontext = EBfeature_map.addFeature("PhrContext") ;
   _featureID_phrcontext1 = EBfeature_map.addFeature("PhrContext1",true) ;
   _featureID_phrcontext2 = EBfeature_map.addFeature("PhrContext2",true) ;
   _featureID_phrcontext3 = EBfeature_map.addFeature("PhrContext3",true) ;
   _featureID_phrcontext4 = EBfeature_map.addFeature("PhrContext4",true) ;
   _featureID_phrcontext5 = EBfeature_map.addFeature("PhrContext5",true) ;
   _featureID_phrcontext6 = EBfeature_map.addFeature("PhrContext6",true) ;
   _featureID_phrcontextplus = EBfeature_map.addFeature("PhrContextPlus",true);
   _featureID_originwt = EBfeature_map.addFeature("Origin-Weight") ;
   _featureID_multiref = EBfeature_map.addFeature("MultiRef") ;
   _featureID_srcfeat = EBfeature_map.addFeature("Source-Features") ;
   _featureID_al_srccover = FrFeatureVectorMap::unknown ;
   _featureID_al_inside = FrFeatureVectorMap::unknown ;
   _featureID_al_outside = FrFeatureVectorMap::unknown ;
   _featureID_al_matchgap = FrFeatureVectorMap::unknown ;
   _featureID_al_length = FrFeatureVectorMap::unknown ;
   _featureID_al_sentbound = FrFeatureVectorMap::unknown ;
   _featureID_al_surfmatch = FrFeatureVectorMap::unknown ;
   _featureID_al_excised = FrFeatureVectorMap::unknown ;
   _featureID_spa_source = FrFeatureVectorMap::unknown ;
   _featureID_spa_target = FrFeatureVectorMap::unknown ;
   _featureID_spa_s2t = FrFeatureVectorMap::unknown ;
   _featureID_spa_t2s = FrFeatureVectorMap::unknown ;
   _num_align_features = 0 ;
   return ;
}

//----------------------------------------------------------------------

void EBMTGlobalVariables::applyConfiguration(const EBMTConfig *config)
{
   (void)config ;
   _symPERIOD = makeSymbol(".") ;
   _symMORPH = makeSymbol("MORPH") ;
   _symPOS = makeSymbol("POS") ;
   _symNUMBER = makeSymbol("NUMBER") ;
   _symPERSON = makeSymbol("PERSON") ;
   _symGENDER = makeSymbol("GENDER") ;
   _symASPECT = makeSymbol("ASPECT") ;
   _symNIL = makeSymbol("NIL") ;
   _symROOT = makeSymbol("ROOT") ;
   _symSTRING = makeSymbol("STRING") ;
   _symTOKEN = makeSymbol("TOKEN") ;
   _symALIGN = makeSymbol("ALIGN") ;
   return ;
}

//----------------------------------------------------------------------

EBMTGlobalVariables *EBMTGlobalVariables::select()
{
   if (!active_vars && !default_vars)
      default_vars = active_vars = new EBMTGlobalVariables(ebmt_vars) ;
   if (active_vars)
      {
      // deselect the current active variables by copying them back into the
      // structure
      memcpy(active_vars,&ebmt_vars,sizeof(EBMTGlobalVariables)) ;
      }
   if (this)
      {
      memcpy(&ebmt_vars,this,sizeof(EBMTGlobalVariables)) ;
      }
   EBMTGlobalVariables *prev = active_vars ;
   active_vars = this ;
   return prev ;
}

//----------------------------------------------------------------------

void EbSetCharEncoding(const char *enc_name)
{
   char_encoding = FrParseCharEncoding(enc_name) ;
   uppercase_table = FrUppercaseTable(char_encoding) ;
   lowercase_table = FrLowercaseTable(char_encoding) ;
   return ;
}

//----------------------------------------------------------------------

void EbAddAlignmentFeatures()
{
   if (!EBfeature_map.finalized())
      {
      if (use_SPA)
	 {
	 align_featureIDs[0] = featureID_spa_source =
	    EBfeature_map.addFeature("SPA-Source") ;
	 align_featureIDs[1] = featureID_spa_target =
	    EBfeature_map.addFeature("SPA-Target") ;
	 align_featureIDs[2] = featureID_spa_s2t =
	    EBfeature_map.addFeature("SPA-S2T") ;
	 align_featureIDs[3] = featureID_spa_t2s =
	    EBfeature_map.addFeature("SPA-T2S") ;
	 num_align_features = 4 ;
	 }
      else
	 {
	 align_featureIDs[0] = featureID_al_srccover =
	    EBfeature_map.addFeature("AlignSc-SrcCover") ;
	 align_featureIDs[1] = featureID_al_inside =
	    EBfeature_map.addFeature("AlignSc-Inside") ;
	 align_featureIDs[2] = featureID_al_outside =
	    EBfeature_map.addFeature("AlignSc-Outside") ;
	 align_featureIDs[3] = featureID_al_matchgap =
	    EBfeature_map.addFeature("AlignSc-MatchGap") ;
	 align_featureIDs[4] = featureID_al_length =
	    EBfeature_map.addFeature("AlignSc-LengthRatio") ;
	 align_featureIDs[5] = featureID_al_sentbound =
	    EBfeature_map.addFeature("AlignSc-SentBounds") ;
	 align_featureIDs[6] = featureID_al_surfmatch =
	    EBfeature_map.addFeature("AlignSc-SurfaceMatch") ;
	 align_featureIDs[7] = featureID_al_excised =
	    EBfeature_map.addFeature("AlignSc-Excised") ;
	 num_align_features = 8 ;
	 }
      // note: NUM_ALIGN_SCORES in ebchunks.h must be at least as big as the
      //   maximum value of num_align_features; making it larger will only
      //   waste memory, however.
      }
   return ;
}

//----------------------------------------------------------------------

bool EBMT_quiet_mode(bool newmode)
{
   bool quiet = quiet_mode ;
   quiet_mode = newmode ;
   return quiet ;
}

// end of file ebglobal.cpp //
