/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.92							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebcrpinf.h	class EbCorpusMetaInfo				*/
/*  LastEdit: 18mar10							*/
/*									*/
/*  (c) Copyright 2003,2004,2005,2006,2007,2008,2009,2010 Ralf Brown	*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __EBCRPINF_H_INCLUDED
#define __EBCRPINF_H_INCLUDED

#ifndef __FRAMEPAC_H_INCLUDED
#include "FramepaC.h"
#endif

#if defined(__GNUC__)
#  pragma interface
#endif

/************************************************************************/
/*	Manifest Constants						*/
/************************************************************************/

// define the ranges of extra data types
#define EbCORPUS_EXTRA_BITEXT 0x00      // first type of bitext data
#define EbCORPUS_EXTRA_TAGS   0x10	// first type of extra tag data
#define EbCORPUS_EXTRA_RSVD   0x80	// reserved for future use
#define EbCORPUS_EXTRA_FILLER 0xFF

// now, the exact types
#define EbCORPUS_EXTRA_BITEXT_UNCOMP 	0	// matrix of binary links
#define EbCORPUS_EXTRA_BITEXT_RLE2 	1	// binary links, run-length enc
#define EbCORPUS_EXTRA_BITEXT_FLOAT1	2	// real-valued links, byte ofs
#define EbCORPUS_EXTRA_BITEXT_FLOAT2	3	// real-valued links, word ofs
#define EbCORPUS_EXTRA_TAGS_RECURSE    0x10	// followed by ASCIZ string
#define EbCORPUS_EXTRA_SCORE	       0x11	// followed by LONG
#define EbCORPUS_EXTRA_FREQ	       0x12	// followed by two LONGs
#define EbCORPUS_EXTRA_PHRASES	       0x13	// followed by SHORT + 6N byte
#define EbCORPUS_EXTRA_PHRASES2	       0x14	// followed by SHORT + 8?N byte
#define EbCORPUS_EXTRA_ORIGIN	       0x15	// followed by ASCIZ string
#define EbCORPUS_EXTRA_LCONTEXT	       0x16	// followed by ASCIZ string
#define EbCORPUS_EXTRA_RCONTEXT	       0x17	// followed by ASCIZ string
#define EbCORPUS_EXTRA_SOURCE	       0x18	// followed by ASCIZ string
#define EbCORPUS_EXTRA_TARGET	       0x19	// followed by ASCIZ string
#define EbCORPUS_EXTRA_TARGETPOS       0x1A	// followed by N BYTEs
#define EbCORPUS_EXTRA_BOUNDS1	       0x1B	// followed by SHORT + N BYTEs
#define EbCORPUS_EXTRA_BOUNDS2	       0x1C	// followed by SHORT + N SHORTs
#define EbCORPUS_EXTRA_EXACT	       0x1D	// no extra data
#define EbCORPUS_EXTRA_USERSCORE       0x1E	// followed by BYTE + N LONGs
#define EbCORPUS_EXTRA_LABELS	       0x1F     // followed by SHORT + N ASCIZ

#define EbCORPUS_EXTRA_MORPH	       0x20	// followed by ASCIZ string
#define EbCORPUS_EXTRA_POS	       0x21	// followed by N BYTEs
#define EbCORPUS_EXTRA_PERS_NUM	       0x22	// followed by N BYTEs
#define EbCORPUS_EXTRA_GENDER_ASPECT   0x23	// followed by N BYTEs

#define EbCORPUS_EXTRA_TRGSPANS	       0x24	// followed by ASCIZ

#define EbCORPUS_SCORE_SCALE		1000000000L  // allows 0.0-4.2

//----------------------------------------------------------------------

// the bitfields for the morphology data

// Part of Speech
#define EbCORPUS_POS			0xFF	// the mask for the field
#define EbCORPUS_POS_NOUN		0x01
#define EbCORPUS_POS_VERB		0x02
#define EbCORPUS_POS_ADJ		0x04
#define EbCORPUS_POS_ADV		0x08
#define EbCORPUS_POS_PREP		0x10
#define EbCORPUS_POS_POST		0x20
#define EbCORPUS_POS_DET		0x40
#define EbCORPUS_POS_CONJ		0x80

// Person
#define EbCORPUS_PERS			0x0F	// the mask for the field
#define EbCORPUS_PERS_FIRST		0x01
#define EbCORPUS_PERS_SECOND		0x02
#define EbCORPUS_PERS_THIRD		0x04
#define EbCORPUS_PERS_FOURTH		0x08

// Number
#define EbCORPUS_NUM			0xF0	// the mask for the field
#define EbCORPUS_NUM_SINGULAR		0x10
#define EbCORPUS_NUM_DUAL		0x20
#define EbCORPUS_NUM_PLURAL   		0x40
#define EbCORPUS_NUM_PAUCAL		0x80

// Gender
#define EbCORPUS_GENDER			0x07	// the mask for the field
#define EbCORPUS_GENDER_FEM		0x01
#define EbCORPUS_GENDER_MASC		0x02
#define EbCORPUS_GENDER_NEUT		0x04

// Aspect
#define EbCORPUS_ASPECT			0xF8
#define EbCORPUS_ASPECT_BEGIN		0x08	// action starting
#define EbCORPUS_ASPECT_PROG		0x10	// action progressing
#define EbCORPUS_ASPECT_END		0x20	// action completing
#define EbCORPUS_ASPECT_CONT		0x40	// continuous action
#define EbCORPUS_ASPECT_RECUR		0x80	// recurrent action

// quick tests
#define EbCORPUS_UNSPECIFIED(value,mask)	(0==((value)&(mask)))
#define EbCORPUS_SPECIFIED(value,mask)		(0!=((value)&(mask)))
#define EbCORPUS_UNKNOWN(value,mask)		((mask)==((value)&(mask)))

/************************************************************************/
/************************************************************************/

class BiTextMap ;

class EbCorpusMorphology
   {
   private:
      FrBYTE  m_pos ;			// part of speech
      FrBYTE  m_pers_num ;		// person and number
      FrBYTE  m_gend_asp ;		// gender and aspect
      FrList *m_other ;			// general tags not explicitly handled
   public:
      EbCorpusMorphology() ;
      EbCorpusMorphology(const FrList *tags) ;
      EbCorpusMorphology(const FrStruct *tagstruct) ;
      ~EbCorpusMorphology() { free_object(m_other) ; m_other = 0 ; }

      // accessors
      FrBYTE partOfSpeech() const { return m_pos ; }
      FrBYTE person() const { return (FrBYTE)(m_pers_num & EbCORPUS_PERS) ; }
      FrBYTE number() const { return (FrBYTE)(m_pers_num & EbCORPUS_NUM) ; }
      FrBYTE gender() const { return (FrBYTE)(m_gend_asp & EbCORPUS_GENDER) ; }
      FrBYTE aspect() const { return (FrBYTE)(m_gend_asp & EbCORPUS_ASPECT) ; }

      // retrieve morph info by tag: other() returns only those values not
      //   covered by the above special-purpose access functions, get()
      //   handles any tag and returns a copy that must be freed
      const FrList *other(FrSymbol *tag) const ;
      FrList *get(FrSymbol *tag) const ;

      // return an association list of all morphology information; must free
      //   with free_object() when done
      FrList *morphology() const ;

      // for use by EbCorpusMetaInfo::write
      FrBYTE personAndNumber() const { return m_pers_num ; }
      FrBYTE genderAndAspect() const { return m_gend_asp ; }
      const FrList *other() const { return m_other ; }

      // manipulators
      void init(const FrList *tags) ;
      void init(const FrStruct *tagstruct) ;
      EbCorpusMorphology &operator = (const EbCorpusMorphology &) ;
      void partOfSpeech(FrBYTE pos) { m_pos = pos ; }
      void personAndNumber(FrBYTE p_n) { m_pers_num = p_n ; }
      void genderAndAspect(FrBYTE g_a) { m_gend_asp = g_a ; }
      void setOther(const FrList *other) ;
   } ;

//----------------------------------------------------------------------

class EbCorpusMetaInfo
   {
   public:
      enum tagfields
         {
	 token_tag =     0x0000001,
	 score_tag =     0x0000002,
	 freq_tag =      0x0000004,
	 origin_tag =    0x0000008,
	 align_tag =     0x0000010,
	 comment_tag =   0x0000020,
	 exact_tag =     0x0000040,
	 pos_tag =       0x0000080,
	 num_tag =       0x0000100,
	 person_tag =    0x0000200,
	 gender_tag =    0x0000400,
	 aspect_tag =    0x0000800,
	 morph_tag =     0x0001000,
	 phrase_tag =    0x0002000,
	 lcontext_tag =  0x0004000,
	 rcontext_tag =  0x0008000,
	 source_tag =    0x0010000,
	 target_tag =    0x0020000,
	 bounds_tag =    0x0040000,
	 literal_tag =   0x0080000,
	 userscore_tag = 0x0100000,
	 labels_tag =    0x0200000,
	 trgspans_tag =  0x0400000
	 } ;

   private:
      double m_alignscore ;		// alignment score for whole example
      double m_score ;			// overall score for example
      double *m_userscores ;
      FrSymbol *m_token ;		// equivalence class for this pair
      BiTextMap *m_bitext ;
      FrList *m_wordalign ;		// target->source word alignments
      FrList *m_phrases ;		// phrasal alignments (user input)
      FrList *m_lcontext ;		// left context
      FrList *m_rcontext ;		// right context
      FrList *m_sourceinfo ;		// PoS and other tags for source words
      FrList *m_targetinfo ;		// PoS and other tags for target words
      char *m_targetpos ;		// PoS for target words
      EbCorpusMorphology *m_morph ;	// (one structure per source word)
      char *m_phrasemap ;		// phrasal alignments (from corpus)
      char *m_phrasemap2 ;		// noncont. phrasal alignments
      char *m_origin ;			// name of file from which indexed
      const char *m_unparsed_morph ;	// raw morph data waiting to be parsed
      uint16_t *m_chunkbounds ;		// positions of chunk boundaries
      FrSymbol **m_chunklabels ;	// optional labels/names for chunks
      FrList *m_trgspans ;		// optional list of target span labels
      size_t m_frequency ;		// number of times source text seen
      size_t m_sourcewords ;		// number of structs in m_morph
      size_t m_phrasecount ;		// size of m_phrasemap
      unsigned fields ;			// bitmask of explicitly-present tags
      unsigned m_numuserscores ;	// number of items in m_userscores
   private:
      void init(size_t src_words = 0) ;
   protected:
      FrList *phrase2TargetWords(const char *map) const ;
   public:
      EbCorpusMetaInfo(size_t src_words = 0) { init(src_words) ; }
      EbCorpusMetaInfo(const EbCorpusMetaInfo *original) ;
      EbCorpusMetaInfo(const char *tagslist, size_t src_words = 0,
		       bool report_errors = true) ;
      ~EbCorpusMetaInfo() ;
      EbCorpusMetaInfo &operator = (const EbCorpusMetaInfo &original) ;

      // manipulators
      void parse(const char *info, const char *end, int slen, int tlen,
		 const FrList *sentence = 0, bool ignore_bitext = false,
		 bool ignore_morphology = false) ;
      bool parse(const char *tags, bool report_errors = true) ;
      bool parse(const FrList *tags) ;
      void parseChunkBounds(FrList *bounds) ;
      bool parseMorph(const char *morph) ;
      bool setMorphology(size_t N, const FrStruct *morph) ;
      bool write(FILE *fp) const ;
      char *store(size_t &length) const ;

      void addField(enum tagfields field) { fields |= field ; }
      void clearField(enum tagfields field) { fields &= ~(field) ; }
      void score(double new_score) { m_score = new_score ; }
      void alignmentScore(double new_score) { m_alignscore = new_score ; }
      void token(FrSymbol *new_token) { m_token = new_token ; }
      void bitext(BiTextMap *new_map) { freeBitext() ; m_bitext = new_map ; }
      void origin(const char *new_origin) ;
      void wordAlignments(const FrList *align)
	 { m_wordalign = align ? (FrList*)align->deepcopy() : 0 ; }
      void frequency(size_t new_total) { m_frequency = new_total ; }
      void freeBitext() { delete m_bitext ; m_bitext = 0 ; }
      void setSourceWords(size_t N) ;
      void finishParsingMorphology() ;

      // accessors
      bool goodParse() const { return fields != 0 ; }
      double score() const { return m_score ; }
      double alignmentScore() const { return m_alignscore ; }
      size_t numUserScores() const { return m_numuserscores ; }
      const double *userScores() const { return m_userscores ; }
      double userScore(size_t N) const
	 { return (N<numUserScores() && m_userscores) ? m_userscores[N] : 0 ; }
      FrSymbol *token() const { return m_token ; }
      BiTextMap *bitext() const { return m_bitext ; }
      const FrList *wordAlignments() const { return m_wordalign ; }
      const FrList *phrases() const { return m_phrases ; }
      const char *phraseMap() const { return m_phrasemap ; }
      static size_t phraseMapEntrySize() { return 6 ; }
      const char *phraseMap(size_t N) const
	 { return N < m_phrasecount 
	      ? m_phrasemap + phraseMapEntrySize()*N : 0 ; }
      const char *phraseMap2() const { return m_phrasemap2 ; }
      static size_t phraseMap2EntrySize() { return 8 ; }
      const char *phraseMap2(size_t N) const
	 { return N < m_phrasecount 
	      ? m_phrasemap2 + phraseMap2EntrySize()*N : 0 ; }
      double phraseAlign(size_t start, size_t end,
			 size_t &trg_start, size_t &trg_end,
			 size_t &trg_mask, size_t alt_num = 0) const ;
      bool phraseAlignIncludes(size_t start, size_t end) const ;
      FrList *phrasalAlignments() const ;
      const FrList *leftContext() const { return m_lcontext ; }
      const FrList *rightContext() const { return m_rcontext ; }
      const FrList *sourceTags() const { return m_sourceinfo ; }
      FrList *sourceStructure() const ;
      const uint16_t *chunkBounds() const { return m_chunkbounds ; }
      size_t numChunkBounds() const { return m_chunkbounds ? m_chunkbounds[0] : 0 ; }
      FrSymbol const * const *chunkLabels() const { return m_chunklabels ; }
      size_t chunkBound(size_t N, size_t sentlen = ~0) const ;
      FrSymbol *chunkLabel(size_t N) const ;
      FrList *chunkBoundaries() const ;
      bool chunksCovered(size_t start, size_t end, size_t sentlen,
			   size_t &fully_covered, size_t &partly_covered,
			   double &weighted_coverage,
			   bool weight_cover = false) const ;
      const FrList *targetSpans() const { return m_trgspans ; }
      FrList *targetSpans(size_t start, size_t end) const ;
      const FrList *targetTags() const { return m_targetinfo ; }
      const char *targetPoS() const { return m_targetpos ; }
      FrList *targetRestrictions(size_t target_start = 0,
				 size_t target_end = (size_t)~0) const ;
      const char *origin() const { return m_origin ; }
      size_t frequency() const { return m_frequency ; }
      size_t numSourceWords() const { return m_sourcewords ; }
      FrList *morphology(size_t N) const
	 { return (N < numSourceWords()) ? m_morph[N].morphology() : 0 ; }
      size_t partOfSpeech(size_t N) const
	 { return (N < numSourceWords()) ? m_morph[N].partOfSpeech() : 0 ; }
      size_t person(size_t N) const
	 { return (N < numSourceWords()) ? m_morph[N].person() : 0 ; }
      size_t number(size_t N) const
	 { return (N < numSourceWords()) ? m_morph[N].number() : 0 ; }
      size_t personAndNumber(size_t N) const
	 { return (N < numSourceWords()) ? m_morph[N].personAndNumber() : 0 ; }
      size_t gender(size_t N) const
	 { return (N < numSourceWords()) ? m_morph[N].gender() : 0 ; }
      size_t aspect(size_t N) const
	 { return (N < numSourceWords()) ? m_morph[N].aspect() : 0 ; }
      size_t genderAndAspect(size_t N) const
	 { return (N < numSourceWords()) ? m_morph[N].genderAndAspect() : 0 ; }
      const FrList *otherMorphology(size_t N) const
	 { return (N < numSourceWords()) ? m_morph[N].other() : 0 ; }
      FrList *getMorphology(size_t N, FrSymbol *tag) const
	 { return (N < numSourceWords()) ? m_morph[N].get(tag) : 0 ; }
      bool hasPartOfSpeech(size_t N, size_t pos) const
	 { return (partOfSpeech(N) & pos) != 0 ; }
      bool hasPerson(size_t N, size_t pers) const
	 { return (person(N) & pers) != 0 ; }
      bool hasNumber(size_t N, size_t num) const
	 { return (number(N) & num) != 0 ; }
      bool hasGender(size_t N, size_t gend) const
	 { return (gender(N) & gend) != 0 ; }
      bool hasAspect(size_t N, size_t asp) const
	 { return (aspect(N) & asp) != 0 ; }
      bool hasScore() const
	 { return (fields & score_tag) != 0 ; }
      bool haveField(enum tagfields field) const
	 { return (fields & field) != 0 ; }
      bool requireExactMatch() const
	 { return (fields & exact_tag) != 0 ; }
      bool skipGeneralization() const
	 { return (fields & literal_tag) != 0 ; }
      bool haveMorphology() const
	 { return (fields & (pos_tag | person_tag | num_tag | gender_tag |
			     aspect_tag | morph_tag)) != 0 ; }

      // utility accessors
      static size_t phraseSrcStart(const char *map) 
	 { return ((const unsigned char *)map)[0] ; }
      static size_t phraseSrcEnd(const char *map) 
	 { return ((const unsigned char *)map)[1] ; }
      static size_t phraseTrgStart(const char *map) 
	 { return ((const unsigned char *)map)[2] ; }
      static size_t phraseTrgEnd(const char *map) 
	 { return ((const unsigned char *)map)[3] ; }
      static size_t phraseScore(const char *map) { return FrLoadShort(map+4); }
      static size_t phrase2TrgStart(const char *map) 
	 { return FrLoadShort(map+2) ; }
      static size_t phrase2TargetMask(const char *map) 
	 { return FrLoadShort(map+6) ; } // bit N says word start+N+1 is xlatn
   } ;

//----------------------------------------------------------------------

FrSymbol *EbExtractTokenTag(const char *tags) ;
FrList *EbExtractAlignTag(const char *tags) ;
FrList *EbExtractUserScoreTag(const char *tags) ;
FrString *EbExtractOriginTag(const char *tags) ;
double EbExtractScoreTag(const char *tags, bool *present = 0) ;
bool EbExtractFreqTag(const char *tags, uint32_t &xlat, uint32_t &total) ;
bool EbExtractLiteralTag(const char *tags) ;

#endif /* __EBCRPINF_H_INCLUDED */

// end of file ebcrpinf.h //
