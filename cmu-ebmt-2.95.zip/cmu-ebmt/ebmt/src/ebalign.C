/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebalign.cpp	chunk-alignment code				*/
/*  LastEdit: 30mar10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#if defined(__GNUC__)
#  pragma implementation "ebalign.h"
#endif

#include "frassert.h"
#include <limits.h>
#include "ebmt.h"
#include "ebalign.h"
#include "ebcorpus.h"
#include "ebsent.h"
#include "ebtoken.h"
#include "ebutil.h"
#include "ebglobal.h"

#ifdef FrSTRICT_CPLUSPLUS
#  include <cmath>
#else
#  include <math.h>
#endif

//#define LOGLIN

// avoid spurious data-race reports on statistics gathering
#ifdef HELGRIND
#  define KEEP_STATS(x)
#else
#  define KEEP_STATS(x) (x)
#endif

/************************************************************************/
/*	Manifest Constants						*/
/************************************************************************/

#ifdef LOGLIN
#  define NO_LINK (-703.0)	// when using log-scores -- log(DBL_MIN)
#else
#  define NO_LINK (0.0)		// when using linear scores
#endif /* LOGLIN */

//----------------------------------------------------------------------
// control of SPA alignment code by Jaedy

//#define BASIC_SPA
#define USE_LINKS
//#define PRINT_MOSES

#define SPA_MAX_SENT		512
#define SPA_EPSILON          	1e-7
#ifdef BASIC_SPA
#  define SPA_WINDOW_SIZE      	0
#else
#  define SPA_WINDOW_SIZE      	3
#endif /* BASIC_SPA */

/************************************************************************/
/*	Types local to this module					*/
/************************************************************************/

enum TranslationState
   {
      Trans_Unknown,
      Trans_NotTrans,
      Trans_Possible,
      Trans_IsTrans
   } ;

struct WordStatus
   {
   public:
      TranslationState state ;
      bool matched ;
      bool insertable ;
      short int excised ;
      short int boundary_start ;
      short int boundary_end ;
   public:
      WordStatus()
	 { state = Trans_Unknown ; matched = false ; insertable = false ;
	   excised = 0 ; boundary_start = 0 ; boundary_end = 0 ; }
   } ;

//----------------------------------------------------------------------

class LinkScores
   {
   private:
      double *m_scores ;
      double *m_sourcescores ;
      double *m_targetscores ;
      size_t m_rows ;
      size_t m_cols ;
      size_t m_inside ;
      size_t m_outside ;
      size_t m_srcstart ;
      size_t m_srcend ;
      size_t m_trgstart ;
      size_t m_trgend ;
   protected: // methods
      void init(size_t rows, size_t cols) ;
   public:
      LinkScores(const BiTextMap *bitext, size_t s_start, size_t s_end) ;
      ~LinkScores() ;

      // modifiers
      void setScores(const BiTextMap *bitext) ;
      void setScore(size_t row, size_t col, double score) ;
      void setSourceScores(size_t s_start, size_t s_end,
			   size_t t_start, size_t t_end) ;
      void setTargetScores(size_t s_start, size_t s_end) ;
      
      // accessors
      bool empty() const { return m_rows == 0 ; }
      bool nonEmpty() const { return m_rows > 0 ; }
      double score(size_t row, size_t col) const ;
      double sourceScoreInside(size_t row) const ;
      double sourceScoreOutside(size_t row) const ;
      double sourceScoreNet(size_t row) const ;
      double targetScoreInside(size_t col) const ;
      double targetScoreOutside(size_t col) const ;
      double targetScoreNet(size_t col) const ;
      size_t countInside() const { return m_inside ; }
      size_t countOutside() const { return m_outside ; }
   } ;

//----------------------------------------------------------------------

enum EbIntRangeType
   {
      IR_Heuristic,
      IR_SPA
   } ;

//----------------------------------------------------------------------

class EbIntRangeList
   {
   private:
      static FrAllocator allocator ;
      EbIntRangeList *m_next ;
      double m_score ;
      double m_userscores[NUM_ALIGN_SCORES] ;
      size_t m_start ;
      size_t m_end ;
      size_t m_mask ;
      EbIntRangeType m_type ;
   public:
      void *operator new(size_t) { return allocator.allocate() ; }
      void *operator new(size_t, void *where) { return where ; }
      void operator delete(void *blk) { allocator.release(blk) ; }
      EbIntRangeList() ;
      EbIntRangeList(const EbIntRangeList *old) ;
      EbIntRangeList(size_t start, size_t end, double sc,
		     EbIntRangeType type,
		     EbIntRangeList *next = 0) ;
      EbIntRangeList(size_t start, size_t end, size_t mask, double sc,
		     EbIntRangeType type,
		     EbIntRangeList *next = 0) ;
      ~EbIntRangeList() { if (m_next) delete m_next ; }

      size_t listlength() const ;

      // modifiers
      void clearUserScores() ;
      void setNext(EbIntRangeList *next) { m_next = next ; }
      void setUserScore(size_t N, double val) { m_userscores[N] = val ; }
      void setMask(size_t m) { m_mask = m ; }

      // accessors
      EbIntRangeList *next() const { return m_next ; }
      size_t start() const { return m_start ; }
      size_t end() const { return m_end ; }
      size_t mask() const { return m_mask ; }
      double score() const { return m_score ; }
      EbIntRangeType aligner() const { return m_type ; }
      double userScore(size_t N) const { return m_userscores[N] ; }
      const double *userScores() const { return m_userscores ; }
   } ;

//----------------------------------------------------------------------

class EbIntRangeLists
   {
   private:
      EbIntRangeList *m_ranges ;
      size_t m_numranges ;
      size_t m_curranges ;
      size_t m_overflow ;
      double m_threshold ;
   public:
      EbIntRangeLists(size_t N, double cutoff) ;
      ~EbIntRangeLists()
	 { delete [] m_ranges ; m_ranges = 0 ; m_numranges = 0 ; }

      // manipulators
      bool insert(size_t start, size_t end, size_t mask, double score,
		  EbIntRangeType type, double *test_scores = 0) ;
      bool insert(size_t start, size_t end, double score, EbIntRangeType type,
		  double *test_scores = 0)
	 { return insert(start,end,~0,score,type,test_scores) ; }

      // accessors
      EbIntRangeList *ranges() const ;
   } ;

//----------------------------------------------------------------------

class EbAlignCacheEntry
   {
   private:
      static FrAllocator allocator ;
      EbAlignCacheEntry *m_next ;
      size_t m_recnum ;
      uint16_t m_start ;
      uint16_t m_end ;
      EbIndexSpec m_index ;

   public:
      void *operator new(size_t) { return allocator.allocate() ; }
      void operator delete(void *blk) { allocator.release(blk) ; }
      EbAlignCacheEntry(EbIndexSpec which, size_t recnum,
			size_t startpos, size_t endpos) ;
      ~EbAlignCacheEntry() ;

      // accessors
      bool OK() const { return true ; }
      EbAlignCacheEntry *next() const { return m_next ; }
      EbIndexSpec whichIndex() const { return m_index ; }
      size_t recordNumber() const { return m_recnum ; }
      size_t startPosition() const { return m_start ; }
      size_t endPosition() const { return m_end ; }

      // manipulators
      void setNext(EbAlignCacheEntry *nxt) { m_next = nxt ; }
   } ;

//----------------------------------------------------------------------

class EbAlignCache
   {
   private:
      EbAlignCacheEntry **m_entries ;
      size_t m_size ;
      size_t m_used ;
      size_t m_insertions ;
      mutable size_t m_lookups ;
      mutable size_t m_hits ;
   public:
      EbAlignCache() ;
      ~EbAlignCache() ;

      // accessors
      bool OK() const { return m_size && m_entries ; }
      int context(EbIndexSpec which, size_t recnum,
		  size_t startpos, size_t endpos) const ;
      size_t cacheSize() const { return m_size ; }
      size_t cacheUsage() const { return m_used ; }
      size_t numInsertions() const { return m_insertions ; }
      size_t numLookups() const { return m_lookups ; }
      size_t numHits() const { return m_hits ; }

      // manipulators
      bool add(EbAlignCacheEntry *new_entry) ;
      bool grow() ;
      bool clear() ;
   } ;

/************************************************************************/
/*	Utility Macros							*/
/************************************************************************/

#ifdef NDEBUG
#  define MTRACE(x)
#  define MVTRACE(x)
#else
#  define MTRACE(x) if (trace_matching) x ;
#  define MVTRACE(x) if (trace_matching && verbose) x ;
#endif

/************************************************************************/
/*	Global data local to this module				*/
/************************************************************************/

#define IDX_SOURCE_FRAC 	0	// fraction of source half matched
#define IDX_LINK_MASS	 	1	// frac. of chunk words linked
#define IDX_OUTSIDE_LINKS	2	// frac. of non-chunk words linked
// additional, less-critical factors
#define IDX_MATCHED_UNTRANS 	3	// frac. paired untranslated words
#define IDX_LENGTH_RATIO	4	// ratio between source & target len
#define IDX_SENT_BOUND		5	// same sentence boundaries?
#define IDX_SURFACE_MATCH	6	// frac. of words matched at surface
#define IDX_EXCISED_WORDS	7	// inv.frac. of target words excised
#define NUM_TEST_FUNCS 8

static const double factory_weights[NUM_TEST_FUNCS] =
   {
#ifdef LOGLIN
   1.0,   30.0,   50.0,   4.0,   0.6, 0.07, 0.50, 0.75
#else
   1.0,   20.0,   10.0,   1.0,   1.5, 0.12, 0.20, 0.05
#endif
   } ;

// current values for alignment-score weights
static double align_weights[NUM_TEST_FUNCS] =
   {
#ifdef LOGLIN
   1.0,   30.0,   50.0,   4.0,   0.6, 0.07, 0.50, 0.75
#else
   1.0,   20.0,   10.0,   1.0,   1.5, 0.12, 0.20, 0.05
#endif
   } ;

double *EBMT_align_weights = align_weights ;

FrAllocator EbIntRangeList::allocator("EbIntRangeList",sizeof(EbIntRangeList));
FrAllocator EbAlignCacheEntry::allocator("AlignCacheEntry",
					 sizeof(EbAlignCacheEntry)) ;

static EbAlignCache *alignment_cache = 0 ;

size_t total_alignments_scored = 0 ;
size_t total_alignments_good = 0 ;

#ifdef BASIC_SPA
static bool use_basic_SPA = true ;
#else
static bool use_basic_SPA = false ;
#endif /* BASIC_SPA */
static size_t SPA_window_size = SPA_WINDOW_SIZE ;

static FrMutex mutex(true) ;

/************************************************************************/
/*	Helper functions						*/
/************************************************************************/

inline double minimum(double x, double y)
{
   return x < y ? x : y ;
}

inline int minimum(int x, int y)
{
   return x < y ? x : y ;
}

inline size_t minimum(size_t x, size_t y)
{
   return x < y ? x : y ;
}

inline double maximum(double x, double y)
{
   return x > y ? x : y ;
}

inline int maximum(int x, int y)
{
   return x > y ? x : y ;
}

inline size_t maximum(size_t x, size_t y)
{
   return x > y ? x : y ;
}

//----------------------------------------------------------------------

static int is_punctuation(const char *word)
{
   if (word && !word[1])
      return Fr_ispunct(word[0]) ;
   return 0 ;
}

/************************************************************************/
/*	Utility functions						*/
/************************************************************************/

static void display_match(const EBMTCandidate *candidate)
{
   EBMTIndex *index = candidate->getIndex() ;
   EbBWTIndex *idx = 0 ;
   if (index) idx = index->selectIndex(candidate->sourceIndex()) ;
   FrString *ssent = 0 ;
   bool complete_source = false ;
   if (idx && (idx->haveIndexLocations() || index->setIndexLocations()))
      {
      size_t loc = idx->indexLocation(candidate->exampleNumber()) ;
      FrList *s = idx->retrieveSource(loc,index->vocabulary()) ;
      if (s)
	 {
	 ssent = new FrString(s) ;
	 s->freeObject() ;
	 complete_source = true ;
	 }
      }
   if (!ssent)
      ssent = new FrString(candidate->sourceWords()) ;
   FrList *trgsent = 0 ;
   if (candidate->targetSentence())
      trgsent = candidate->targetSentence()->wordList() ;
   FrString *tsent = new FrString(trgsent) ;
   free_object(trgsent) ;
   cout << "finding match for " << candidate->sourceWords()
	<< " [" << candidate->inputStart() << ".."
	<< candidate->inputStart() + candidate->inputLength() - 1
	<< " @ " << candidate->sourceOffset() ;
   if (candidate->token())
      cout << " ==" << candidate->token();
   cout << "] in sentence pair"
	<< "\n\t" ;
   if (!complete_source)
      cout << "..."  ;
   cout << ssent->stringValue() ;
   if (!complete_source)
      cout << "..." ;
   cout << "\n\t" << tsent->stringValue() << endl ;
   free_object(ssent) ;
   free_object(tsent) ;
   const FrString *targetwords = candidate->targetWords() ;
   if (targetwords)
      {
      cout << " ==> " << targetwords << " (align="
	   << candidate->alignmentScore() << ", score="
	   << candidate->score() << ")" << endl ;
      }
   else
      cout << " --> failed!" << endl ;
   return ;
}

/************************************************************************/
/*	Weight-assignment functions					*/
/************************************************************************/

void EbClearAlignmentWeights()
{
   // restore alignment-score weights to factory defaults
   memcpy(align_weights,factory_weights,sizeof(align_weights)) ;
   return ;
}

/************************************************************************/
/*	Methods for class LinkScores					*/
/************************************************************************/

LinkScores::LinkScores(const BiTextMap *bitext,
		       size_t s_start, size_t s_end)
{
   if (bitext)
      {
      init(bitext->sourceLength(),bitext->targetLength()) ;
      setScores(bitext) ;
      setTargetScores(s_start,s_end) ;
      }
   else
      init(0,0) ;
   return ;
}

//----------------------------------------------------------------------

LinkScores::~LinkScores()
{
   FrFree(m_scores) ;		m_scores = 0 ;
   m_sourcescores = 0 ;
   m_targetscores = 0 ;
   return ;
}

//----------------------------------------------------------------------

void LinkScores::init(size_t rows, size_t cols)
{
   m_rows = rows ;
   m_cols = cols ;
   m_inside = 0 ;
   m_outside = cols ;
   m_srcstart = m_srcend = rows ;
   m_trgstart = m_trgend = cols ;
   m_scores = FrNewN(double,m_rows*m_cols + 3*m_rows + 2*m_cols) ;
   if (m_scores)
      {
      m_sourcescores = &m_scores[m_rows*m_cols] ;
      m_targetscores = &m_sourcescores[3*m_rows] ;
      }
   else
      {
      m_rows = 0 ;
      m_cols = 0 ;
      m_sourcescores = 0 ;
      m_targetscores = 0 ;
      }
   return ;
}

//----------------------------------------------------------------------

void LinkScores::setScores(const BiTextMap *bitext)
{
   for (size_t i = 0 ; i < bitext->sourceLength() ; i++)
      {
#if NEW
      size_t mintrg = ~0 ;
      size_t maxtrg = 0 ;
#endif
      for (size_t j = 0 ; j < bitext->targetLength() ; j++)
	 {
	 double sc = bitext->correspondenceScore(i,j) ;
	 setScore(i,j,sc) ;
#if NEW
	 if (sc > 0.0)
	    {
	    if (j < mintrg)
	       mintrg = j ;
	    if (j > maxtrg)
	       maxtrg = j ;
	    }
#endif
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void LinkScores::setScore(size_t row, size_t col, double score)
{
   if (row < m_rows && col < m_cols)
      m_scores[row * m_cols + col] = score ;
   return ;
}

//----------------------------------------------------------------------

void LinkScores::setSourceScores(size_t s_start, size_t s_end,
				 size_t t_start, size_t t_end)
{
   if (s_end >= m_rows)
      s_end = m_rows - 1 ;
   if (m_sourcescores)
      {
      if (t_start == m_trgstart && t_end == m_trgend + 1)
	 {
	 // incrementally adjust the inside/outside values
	 for (size_t i = s_start ; i <= s_end ; i++)
	    {
	    double change = score(i,t_end) ;
	    m_sourcescores[3*i] += change ;
	    m_sourcescores[3*i+1] -= change ;
	    }
	 m_trgend = t_end ;
	 }
      else if (t_start == m_trgstart + 1 && m_trgstart < m_cols)
	 {
	 for (size_t i = s_start ; i <= s_end ; i++)
	    {
	    double plus = 0.0 ;
	    for (size_t j = t_start ; j <= t_end ; j++)
	       {
	       plus += score(i,j) ;
	       }
	    m_sourcescores[3*i] = plus ;
	    double minus = m_sourcescores[3*i+2] + score(i,m_trgstart) ;
	    m_sourcescores[3*i+2] = minus ;
	    for (size_t j = t_end + 1 ; j < m_cols ; j++)
	       {
	       minus += score(i,j) ;
	       }
	    m_sourcescores[3*i+1] = minus ;
	    }
	 m_trgstart = t_start ;
	 m_trgend = t_end ;
	 }
      else
	 {
	 for (size_t i = s_start ; i <= s_end ; i++)
	    {
	    double minus = 0.0 ;
	    for (size_t j = 0 ; j < t_start ; j++)
	       {
	       minus += score(i,j) ;
	       }
	    m_sourcescores[3*i+2] = minus ;
	    double plus = 0.0 ;
	    for (size_t j = t_start ; j <= t_end ; j++)
	       {
	       plus += score(i,j) ;
	       }
	    m_sourcescores[3*i] = plus ;
	    for (size_t j = t_end + 1 ; j < m_cols ; j++)
	       {
	       minus += score(i,j) ;
	       }
	    m_sourcescores[3*i+1] = minus ;
	    }
	 m_trgstart = t_start ;
	 m_trgend = t_end ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void LinkScores::setTargetScores(size_t s_start, size_t s_end)
{
   m_srcstart = s_start ;
   m_srcend = s_end ;
   if (m_targetscores)
      {
      m_inside = s_end - s_start ;
      m_outside = m_rows - m_inside ;	
      for (size_t j = 0 ; j < m_cols ; j++)
	 {
	 double plus = 0.0 ;
	 double minus = 0.0 ;
	 for (size_t i = 0 ; i < s_start ; i++)
	    {
	    minus += score(i,j) ;
	    }
	 for (size_t i = s_start ; i <= s_end ; i++)
	    {
	    plus += score(i,j) ;
	    }
	 for (size_t i = s_end + 1 ; i < m_rows ; i++)
	    {
	    minus += score(i,j) ;
	    }
	 m_targetscores[2*j] = plus ;
	 m_targetscores[2*j+1] = minus ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

double LinkScores::score(size_t row, size_t col) const
{
   if (row < m_rows && col < m_cols)
      return m_scores[row * m_cols + col] ;
   return NO_LINK ;
}

//----------------------------------------------------------------------

double LinkScores::sourceScoreInside(size_t row) const
{
   return (row < m_rows) ? m_sourcescores[3*row] : 0.0 ;
}

//----------------------------------------------------------------------

double LinkScores::sourceScoreOutside(size_t row) const
{
   return (row < m_rows) ? m_sourcescores[3*row+1] : 0.0 ;
}

//----------------------------------------------------------------------

double LinkScores::sourceScoreNet(size_t row) const
{
   return (row < m_rows) ? m_sourcescores[3*row]-m_sourcescores[3*row+1] : 0.0;
}

//----------------------------------------------------------------------

double LinkScores::targetScoreInside(size_t col) const
{
   return (col < m_cols) ? m_targetscores[2*col] : 0.0 ;
}

//----------------------------------------------------------------------

double LinkScores::targetScoreOutside(size_t col) const
{
   return (col < m_cols) ? m_targetscores[2*col+1] : 0.0 ;
}

//----------------------------------------------------------------------

double LinkScores::targetScoreNet(size_t col) const
{
   return (col < m_cols) ? m_targetscores[2*col]-m_targetscores[2*col+1] : 0.0;
}

/************************************************************************/
/*	Methods for class EbIntRangeList				*/
/************************************************************************/

EbIntRangeList::EbIntRangeList()
{
   m_start = m_end = 0 ;
   m_mask = (size_t)~0 ;
   m_score = 0.0 ; 
   m_type = IR_Heuristic ;
   clearUserScores() ;
   m_next = 0 ;
   return ;
}

//----------------------------------------------------------------------

EbIntRangeList::EbIntRangeList(const EbIntRangeList *old)
{
   m_start = old->m_start ;
   m_end = old->m_end ;
   m_mask = old->m_mask ;
   m_score = old->m_score ;
   m_type = old->m_type ;
   clearUserScores() ;
   m_next = 0 ;
   return ;
}

//----------------------------------------------------------------------

EbIntRangeList::EbIntRangeList(size_t start, size_t end,
			       double sc, EbIntRangeType type,
			       EbIntRangeList *next)
{
   m_start = start ;
   m_end = end ;
   m_mask = (size_t)~0 ;
   m_score = sc ;
   m_type = type ;
   clearUserScores() ;
   m_next = next ;
   return ;
}

//----------------------------------------------------------------------

EbIntRangeList::EbIntRangeList(size_t start, size_t end, size_t mask,
			       double sc, EbIntRangeType type,
			       EbIntRangeList *next)
{
   m_start = start ;
   m_end = end ;
   m_mask = mask ;
   m_score = sc ;
   m_type = type ;
   clearUserScores() ;
   m_next = next ;
   return ;
}

//----------------------------------------------------------------------

void EbIntRangeList::clearUserScores()
{
   for (size_t i = 0 ; i < lengthof(m_userscores) ; i++)
      m_userscores[i] = 0.0 ;
   return ;
}

//----------------------------------------------------------------------

size_t EbIntRangeList::listlength() const
{
   size_t count = 0 ;
   const EbIntRangeList *l = this ;
   while (l)
      {
      count++ ;
      l = l->next() ;
      }
   return count ;
}

/************************************************************************/
/*	Methods for class EbIntRangeList				*/
/************************************************************************/

EbIntRangeLists::EbIntRangeLists(size_t N, double cutoff)
{
   m_ranges = new EbIntRangeList[N] ;
   m_threshold = cutoff ;
   if (m_ranges)
      m_numranges = N ;
   else
      {
      FrNoMemory("allocating ranges") ;
      m_numranges = 0 ;
      }
   m_curranges = 0 ;
   m_overflow = 0 ;
   return ;
}

//----------------------------------------------------------------------

bool EbIntRangeLists::insert(size_t start, size_t end, size_t /*mask*/,
			     double score, EbIntRangeType type,
			     double *test_scores)
{
   double best_score = (m_curranges > 0) ? m_ranges[0].score() : 0.0 ;
   // first, check whether the new score is high enough to be included
   if (score < m_threshold * best_score)
      return false ;
   // next, check whether the new range will have to be placed in the overflow
   if (m_curranges >= m_numranges &&
       m_ranges[m_curranges-1].score() == best_score &&
       score == best_score)
      {
      m_overflow++ ;
      return true ;
      }
   // finally, figure out where to insert the new range
   // use a simple linear scan since the number of ranges won't be more than
   //   three to five
   size_t where ;
   for (where = 0 ; where < m_curranges ; where++)
      {
      if (score > m_ranges[where].score())
	 break ;
      }
   if (where >= m_numranges)
      return false ;			// it's not one of the N best ranges
   else if (where == 0)
      {
      // new best score, so clear the overflow list and drop any ranges
      //   with scores below the new cutoff
      m_overflow = 0 ;
      for (size_t i = 0 ; i < m_curranges ; i++)
	 {
	 if (m_ranges[i].score() < m_threshold * score)
	    {
	    m_curranges = i ;
	    break ;
	    }
	 }
      }
   if (m_curranges == m_numranges)
      m_curranges-- ;		      	// drop the lowest-scoring range
   // make room for the new entry
   for (size_t i = m_curranges ; i > where ; i--)
      {
      m_ranges[i] = m_ranges[i-1] ;
      }
   new (&m_ranges[where]) EbIntRangeList(start,end,score,type) ;
   if (test_scores)
      {
      for (size_t i = 0 ; i < num_align_features ; i++)
	 {
	 m_ranges[where].setUserScore(i,test_scores[i]) ;
	 }
      }
   m_curranges++ ;
   return true ;
}

//----------------------------------------------------------------------

EbIntRangeList *EbIntRangeLists::ranges() const
{
   EbIntRangeList *result = 0 ;
//!!!   if (m_overflow == 0)
      {
      // only return a set of ranges if we weren't too ambiguous about which
      //   was the best
      for (size_t i = m_curranges ; i > 0 ; i--)
	 {
	 EbIntRangeList *range = new EbIntRangeList(m_ranges[i-1]) ;
	 range->setNext(result) ;
	 result = range ;
	 }
      }
   return result ;
}

/************************************************************************/
/*	Methods for class EbAlignCacheEntry				*/
/************************************************************************/

EbAlignCacheEntry::EbAlignCacheEntry(EbIndexSpec which, size_t recnum,
				     size_t startpos, size_t endpos)
{
   m_next = 0 ;
   m_index = which ;
   m_recnum = recnum ;
   m_start = (uint16_t)startpos ;
   m_end = (uint16_t)endpos ;
   return ;
}

//----------------------------------------------------------------------

EbAlignCacheEntry::~EbAlignCacheEntry()
{
   return ;
}

/************************************************************************/
/*	Methods for class EbAlignCache					*/
/************************************************************************/

EbAlignCache::EbAlignCache()
{
   m_insertions = m_lookups = m_hits = 0 ;
   m_used = 0 ;
   m_size = 32000 ;
   m_entries = FrNewC(EbAlignCacheEntry*,m_size) ;
   if (!m_entries)
      m_size = 0 ;
   return ;
}

//----------------------------------------------------------------------

EbAlignCache::~EbAlignCache()
{
   clear() ;
   FrFree(m_entries) ;
   m_size = 0 ;
   m_used = 0 ;
   return ;
}

//----------------------------------------------------------------------

bool EbAlignCache::grow()
{
   if (cacheUsage() >= cacheSize())
      {
      // grow the cache by doubling the size of the hash table
      size_t new_size = 2 * cacheSize() ;
      EbAlignCacheEntry **new_entries = FrNewC(EbAlignCacheEntry*,new_size) ;
      if (new_entries)
	 {
	 // insert all the existing cache entries into the new table
	 for (size_t i = 0 ; i < cacheSize() ; i++)
	    {
	    EbAlignCacheEntry *ent = m_entries[i] ;
	    while (ent)
	       {
	       size_t key = ent->recordNumber() % new_size ;
	       EbAlignCacheEntry *next = ent->next() ;
	       ent->setNext(new_entries[key]) ;
	       new_entries[key] = ent ;
	       ent = next ;
	       }
	    }
	 FrFree(m_entries) ;
	 m_size = new_size ;
	 m_entries = new_entries; 
	 return true ;
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

bool EbAlignCache::clear()
{
   if (cacheUsage() > 0)
      {
      for (size_t i = 0 ; i < cacheSize() ; i++)
	 {
	 EbAlignCacheEntry *ent = m_entries[i] ;
	 m_entries[i] = 0 ;
	 while (ent)
	    {
	    EbAlignCacheEntry *tmp = ent ;
	    ent = ent->next() ;
	    delete tmp ;
	    }
	 }
      m_used = 0 ;
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

int EbAlignCache::context(EbIndexSpec which, size_t recnum,
			  size_t startpos, size_t endpos) const
{
   size_t key = recnum % cacheSize() ;
   m_lookups++ ;
   for (EbAlignCacheEntry *ent = m_entries[key] ; ent ; ent = ent->next())
      {
      if (ent->whichIndex() == which && ent->recordNumber() == recnum &&
	  startpos >= ent->startPosition() && endpos <= ent->endPosition())
	 {
	 size_t ent_len = ent->endPosition() - ent->startPosition() ;
	 m_hits++ ;
	 return ent_len - (endpos - startpos) ;
	 }
      }
   return -1 ; 				// not found
}

//----------------------------------------------------------------------

bool EbAlignCache::add(EbAlignCacheEntry *new_entry)
{
   FrCRITSECT_ENTER(mutex) ;
   size_t key = new_entry->recordNumber() % cacheSize() ;
   for (EbAlignCacheEntry *ent = m_entries[key] ; ent ; ent = ent->next())
      {
      if (ent->recordNumber() == new_entry->recordNumber() &&
	  new_entry->startPosition() == ent->startPosition() &&
	  new_entry->endPosition() == ent->endPosition())
	 {
	 FrCRITSECT_LEAVE(mutex) ;
	 return false ;
	 }
      }
   m_insertions++ ;
   new_entry->setNext(m_entries[key]) ;
   m_entries[key] = new_entry ;
   m_used++ ;
   grow() ;
   FrCRITSECT_LEAVE(mutex) ;
   return true ;
}

/************************************************************************/
/*	Procedural interface to EbAlignCache				*/
/************************************************************************/

bool EbAlignCacheInit()
{
   if (!alignment_cache)
      alignment_cache = new EbAlignCache ;
   return (alignment_cache != 0) ;
}

//----------------------------------------------------------------------

bool EbAlignCacheClear()
{
   if (alignment_cache)
      {
      alignment_cache->clear() ;
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

bool EbAlignCacheActive()
{
   return alignment_cache != 0 ;
}

//----------------------------------------------------------------------

int EbAlignCacheContext(EbIndexSpec which, size_t recnum, size_t startpos,
			size_t endpos)
{
   if (alignment_cache)
      return alignment_cache->context(which,recnum,startpos,endpos) ;
   return -1 ;				// not found
}

//----------------------------------------------------------------------

const EBMTCandidate *EbAlignCacheCandidate(EbIndexSpec which, size_t recnum,
					   size_t startpos, size_t endpos)
{
   (void)which; (void)recnum; (void)startpos ; (void)endpos ;
   // not found:
   return 0 ;
}

//----------------------------------------------------------------------

void EbAlignCacheStats(size_t &lookups, size_t &hits, size_t &inserts)
{
   if (alignment_cache)
      {
      lookups = alignment_cache->numLookups() ;
      hits = alignment_cache->numHits() ;
      inserts = alignment_cache->numInsertions() ;
      }
   else
      {
      lookups = hits = inserts = 0 ;
      }
   return ;
}

//----------------------------------------------------------------------

bool EbAlignCacheFree()
{
   delete alignment_cache ;
   alignment_cache = 0 ;
   return true ;
}

/************************************************************************/
/*	The alignment scoring functions					*/
/************************************************************************/

static bool excisable_corr(const BiTextMap *bitext, size_t word,
			     size_t start, size_t end, size_t src_start,
			     size_t src_end, int &offset)
{
   register int ofs = 0 ;
   for (size_t i = start ; i <= end ; i++)
      {
      // scan for a word that matches our target word, and see whether it
      //   has any other possible correspondences besides the given target word
      if (bitext->wordsCorrespond(i,word) && 
	  bitext->numTargetCorrespondences(i) == 1)
	 {
	 // if there are multiple words which align to the given target, take
	 //   the one closest to the source match
	 int prev_ofs = ofs ;
	 if (i < src_start)
	    ofs = -(int)(src_start - i) ;
	 else if (i > src_end)
	    ofs = (int)(i - src_end) ;
	 if (prev_ofs && abs(prev_ofs) < abs(ofs))
	    ofs = prev_ofs ;
	 }
      }
   offset = ofs ;
   return ofs != 0 ;
}

//----------------------------------------------------------------------

static void find_excisable_words(const BiTextMap *bitext,
				 size_t src_start, size_t src_end,
				 WordStatus *status)
{
   size_t src_len = bitext->sourceLength() ;
   size_t trg_len = bitext->targetLength() ;
   if (src_start > src_len)		//!!!!
      src_start = src_len - 1 ;
   // compute the limits of the range in which a word can have a
   // correspondence making it excisable
   size_t sim = EbMaxGapOffset() ;
   size_t first = (src_start < sim) ? 0 : (src_start - sim) ;
   size_t last = (src_end + sim >= src_len) ? src_len - 1 : (src_end + sim) ;
   for (size_t i = 0 ; i < trg_len ; i++)
      {
      if (!status[i].matched)
	 {
	 // check whether the unmatched word actually matches a word very
	 // near to the matched source chunk; if this is the case, the word
	 // can be excised from the target side in order to get a better
	 // alignment
	 bool corr = false ;
	 int offset = 0 ;
	 int ofs ;
	 if (src_start > 0 && !status[i].insertable &&
	     excisable_corr(bitext,i,first,src_start-1,src_start,src_end,ofs))
	    {
	    corr = true ;
	    offset = ofs ;
	    }
	 if (src_end < trg_len && !status[i].insertable &&
	     excisable_corr(bitext,i,src_end+1,last,src_start,src_end,ofs))
	    {
	    corr = !corr ;
	    offset = (corr && ofs != 0) ? ofs : 0 ;
	    }
	 status[i].excised = offset ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

static void classify_words(const BiTextMap *bitext, bool complete,
			   const LinkScores &link_scores,
			   size_t src_start, size_t src_end,
			   const FrList *source, const EbSentence *target,
			   WordStatus *status, size_t &min_required,
			   size_t &max_required)
{
   //
   // check which words in the target sentence correspond to a word in the
   //  candidate chunk, and which may be excised because they must correspond
   //  to a word outside the source chunk
   //
   size_t sourcelen = bitext->sourceLength() ;
   size_t targetlen = bitext->targetLength() ;
   const char *src_punct_start ;
   const char *src_punct_end ;
   size_t punct_start ;
   size_t punct_end ;
   if (source)
      {
      src_punct_start = FrPrintableName(source->first()) ;
      src_punct_end = FrPrintableName(source->last()->first()) ;
      punct_start = is_punctuation(src_punct_start) ;
      punct_end = is_punctuation(src_punct_end) ;
      }
   else
      {
      punct_start = false ;
      punct_end = false ;
      src_punct_start = "" ;
      src_punct_end = "" ;
      }
   min_required = targetlen ;
   max_required = 0 ;
   for (size_t i = 0 ; i < targetlen ; i++)
      {
      status[i].boundary_start = 0 ;
      status[i].boundary_end = 0 ;
      status[i].insertable = (char)false ;
      int total_links = bitext->numSourceCorrespondences(i) ;
      if (total_links == 0)
	 {
	 status[i].state = Trans_Unknown ;
	 status[i].matched = false ;
	 }
      else if (link_scores.targetScoreInside(i) == 0.0)
	 {
	 status[i].state = Trans_NotTrans ;
	 status[i].matched = false ;
	 }
      else if (link_scores.targetScoreOutside(i) == 0.0)
	 {
	 status[i].state = Trans_IsTrans ;
	 status[i].matched = true ;
	 max_required = i ;
	 if (i < min_required)
	    min_required = i ;
	 }
      else
	 {
	 bool match = true ;
	 // check whether this is the only possible translation for a
	 //   word which is NOT part of the chunk; if so, and it's a 
	 //   sufficiently probable link, we have to say that the word
	 //   isn't a translation for anything in the chunk
	 size_t k ;
	 unsigned char weakest_link
	    = (unsigned char)bitext->maxSourceCorrespondence(i,src_start,
							     src_end) / 8 ;
	 if (weakest_link == 0)
	    weakest_link = 1 ;
	 for (k = 0 ; k < src_start ; k++)
	    {
	    if (bitext->numTargetCorrespondences(k) == 1 &&
		bitext->wordsCorrespond(k,i) >= weakest_link)
	       {
	       match = false ;
	       break ;
	       }
	    }
	 for (k = src_end+1 ; match && k < sourcelen ; k++)
	    {
	    if (bitext->numTargetCorrespondences(k) == 1 &&
		bitext->wordsCorrespond(k,i) >= weakest_link)
	       {
	       match = false ;
	       break ;
	       }
	    }
	 status[i].state = match ? Trans_Possible : Trans_NotTrans ;
	 status[i].matched = match ;
	 }
      if (complete && bitext->numSourceCorrespondences(i) == 0)
	 status[i].insertable = (char)true ;
      if (target)
	 {
	 const char *word = target->word(i) ;
	 if (word)
	    {
	    // while we're at it, compute bonus/penalty for placing the target
	    //   chunk's boundaries at each location based on common punct
	    size_t punct = is_punctuation(word) ;
	    if (punct != punct_start)
	       status[i].boundary_start -= 4  ;	// penalize the mismatch
	    else if (punct + punct_start == 2)
	       {
	       status[i].boundary_start++ ;
	       if (strcmp(src_punct_start,word) == 0)
		  status[i].boundary_start++ ;
	       }
	    if (punct != punct_end)
	       status[i].boundary_end -= 4 ;	// penalize the mismatch
	    else if (punct + punct_end == 2)
	       {
	       status[i].boundary_end++ ;
	       if (strcmp(src_punct_end,word) == 0)
		  status[i].boundary_end++ ;
	       }
	    }
	 }
      }
   if (src_start == 0)
      status[0].boundary_start++ ;    	// bonus for both abutting start
   if (src_end == sourcelen - 1)
      status[targetlen-1].boundary_end++ ; // bonus for both abutting end
   find_excisable_words(bitext,src_start,src_end,status) ;
   return ;
}

//----------------------------------------------------------------------

inline double limit_prob(double val)
{ 
   return val < 0.0 ? 0.0 : (val > 1.0 ? 1.0 : val) ; 
}

//----------------------------------------------------------------------

static double score_match(const BiTextMap *bitext,
			  LinkScores &link_scores,
			  size_t src_begin, size_t src_end,
			  size_t target_start, size_t target_end,
			  size_t gaplocs, size_t numtokens,
			  const WordStatus *status, bool relaxed,
			  double *test_scores)
{
   if (link_scores.empty())
      return SCORE_UNALIGNABLE ;	// no bitext, so can't align

   size_t matchlen = (src_end - src_begin) + 1 ;
   if (gaplocs != NO_GAP)
      {
      for (size_t gaploc = 0 ; gaploc < matchlen ; gaploc++)
	 {
	 if ((gaplocs & (1UL << gaploc)) == 0)
	    continue ;
	 // if we had a gap in the corpus match, we MUST include the
	 //    translation of that gap in the translation; further, if the
	 //    gap is at beginning or end of the match, require that none of
	 //    the words outside the candidate translation could be a
	 //    translation of the gap
	 if ((gaploc == 0 || gaploc == matchlen - 1) &&
	     bitext->numTargetCorrespondences(src_begin+gaploc) != 1)
	    return SCORE_UNALIGNABLE ;
	 size_t xlat = bitext->numTargetCorrespondences(src_begin+gaploc,
							target_start,
							target_end) ;
	 if (xlat != 1)
	    return SCORE_UNALIGNABLE ;
	 }
      }

   double score[NUM_TEST_FUNCS+1] ;
   double max_score[NUM_TEST_FUNCS+1] ;
   // heuristic 1: percentage of example's source that was matched by chunk
   score[IDX_SOURCE_FRAC] = matchlen ;
   max_score[IDX_SOURCE_FRAC] = bitext->sourceLength() ;

   size_t tsent_length = bitext->targetLength() ; 
   size_t target_length = (target_end - target_start + 1) ;
   int excised = 0 ;

   // heuristic 2: proportion of source words having more alignment mass
   //    within candidate target chunk plus proportion of target words
   //    having more alignment within source chunk
   max_score[IDX_LINK_MASS] = ((src_end - src_begin + 1) + target_length) ;
   score[IDX_LINK_MASS] = 0 ;
   link_scores.setSourceScores(0,~0,target_start,target_end) ;
   size_t link_count = 0 ;
   for (size_t i = src_begin ; i <= src_end ; i++)
      {
      double net = link_scores.sourceScoreNet(i) ;
      if (net > 0.0)
	 {
	 if (net > 1.0)
	    net = 1.0 ;
	 score[IDX_LINK_MASS] += net ;
	 link_count++ ;
	 }
      }
   if (!relaxed && link_count < (src_end - src_begin + 1)/2)
      return SCORE_UNALIGNABLE ;
   if (link_count == 0)
      return SCORE_UNALIGNABLE ;
   link_count = 0 ;
   size_t core_start = target_start ;
   size_t core_end = (size_t)~0 ;
   for (size_t i = target_start ; i <= target_end ; i++)
      {
      if (status[i].excised)
	 {
	 if (core_end == (size_t)~0)
	    core_start = i + 1 ;
	 }
      else
	 core_end = i ;
      }
   for (size_t i = target_start ; i <= target_end ; i++)
      {
      double inside = link_scores.targetScoreInside(i) ;
      double outside = link_scores.targetScoreOutside(i) ;
      double net = inside - outside ;
      if (inside <= matchlen * NO_LINK)
	 {
	 if (status[i].excised)
	    {
	    excised++ ;
	    // only allow the excised word to count as a positive if it
	    //   is in the middle of the target chunk rather than at either
	    //   end, to avoid excessively extending the translation with
	    //   gap markers.
	    if (i > core_start && i < core_end)
	       net = -net ;
	    }
	 }
      if (net > 0.0)
	 {
	 if (net > 1.0)
	    net = 1.0 ;
	 score[IDX_LINK_MASS] += net ;
	 link_count++ ;
	 }
      }
   if (!relaxed && link_count < (target_end - target_start + 1)/2)
      return SCORE_UNALIGNABLE ;

   max_score[IDX_OUTSIDE_LINKS] = (bitext->sourceLength() + 
				   bitext->targetLength() -
				   max_score[IDX_LINK_MASS]) ;
   score[IDX_OUTSIDE_LINKS] = 0 ;
bool use_outside_probs = false ;
//bool use_outside_probs = true ;
   if (use_outside_probs)
      {
      // heuristic 3: probability mass of words in neither source nor target
      //   chunks with more alignment mass outside the chunks than within
      for (size_t i = 0 ; i < src_begin ; i++)
	 {
	 double net = link_scores.sourceScoreNet(i) ;
	 score[IDX_OUTSIDE_LINKS] += limit_prob(-net) ;
	 }
      for (size_t i = src_end + 1 ; i < bitext->sourceLength() ; i++)
	 {
	 double net = link_scores.sourceScoreNet(i) ;
	 score[IDX_OUTSIDE_LINKS] += limit_prob(-net) ;
	 }
      for (size_t i = 0 ; i < target_start ; i++)
	 {
	 double net = link_scores.targetScoreNet(i) ;
	 score[IDX_OUTSIDE_LINKS] += limit_prob(-net) ;
	 }
      for (size_t i = target_end + 1 ; i < bitext->targetLength() ; i++)
	 {
	 double net = link_scores.targetScoreNet(i) ;
	 score[IDX_OUTSIDE_LINKS] += limit_prob(-net) ;
	 }
      }
   else
      {
      // OLD VERSION
      // heuristic 3: proportion of words in neither source nor target chunks
      //   which have more alignment mass outside the chunks than within
      for (size_t i = 0 ; i < src_begin ; i++)
	 {
	 if (link_scores.sourceScoreNet(i) < 0.0)
	    score[IDX_OUTSIDE_LINKS]++ ;
	 }
      for (size_t i = src_end + 1 ; i < bitext->sourceLength() ; i++)
	 {
	 if (link_scores.sourceScoreNet(i) < 0.0)
	    score[IDX_OUTSIDE_LINKS]++ ;
	 }
      for (size_t i = 0 ; i < target_start ; i++)
	 {
	 if (link_scores.targetScoreNet(i) < 0.0)
	    score[IDX_OUTSIDE_LINKS]++ ;
	 }
      for (size_t i = target_end + 1 ; i < bitext->targetLength() ; i++)
	 {
	 if (link_scores.targetScoreNet(i) < 0.0)
	    score[IDX_OUTSIDE_LINKS]++ ;
	 }
      // stretch the scaling on the linkage by only counting the part above
      //   half the total possible
      score[IDX_OUTSIDE_LINKS] *= 2 ;
      score[IDX_OUTSIDE_LINKS] -= max_score[IDX_OUTSIDE_LINKS] ;
      if (score[IDX_OUTSIDE_LINKS] < 0)
	 return SCORE_UNALIGNABLE ;
      }

   // heuristic 4: percentage of words without known translations that are
   //   pairable between source and target (assumes that dictionary was
   //   incomplete); value is min(source/target,target/source)
   // note that in contrast to old scoring metrics, we don't include
   //   words that have correspondences outside the chunks being scored
   int src_untrans = 0 ;
   for (size_t i = src_begin ; i <= src_end ; i++)
      {
      if (bitext->numTargetCorrespondences(i) == 0)
	 src_untrans++ ;
      }
   int trg_untrans = 0 ;
   for (size_t i = target_start ; i <= target_end ; i++)
      {
      if (bitext->numSourceCorrespondences(i) == 0)
	 trg_untrans++ ;
      }
   score[IDX_MATCHED_UNTRANS] = minimum(src_untrans,trg_untrans) ;
   max_score[IDX_MATCHED_UNTRANS] = maximum(src_untrans,trg_untrans) ;

   // heuristic 5: length ratio -- min(source/target,target/source)
   double sent_length_ratio = tsent_length / (double)bitext->sourceLength() ;
   double desired_target = (matchlen * sent_length_ratio) ;
   score[IDX_LENGTH_RATIO] = minimum(desired_target,(double)target_length) ;
   max_score[IDX_LENGTH_RATIO] = maximum(desired_target,(double)target_length);

   // heuristic 6: same sentence boundaries
   score[IDX_SENT_BOUND] = (status[target_start].boundary_start + 
			    status[target_end].boundary_end) ;
   max_score[IDX_SENT_BOUND] = 5 ; // up to 3 for start, 2 for end

   // heuristic 7: percentage of source chunk matched at surface level
   score[IDX_SURFACE_MATCH] = matchlen - numtokens ;
   max_score[IDX_SURFACE_MATCH] = matchlen ;

   // heuristic 8: inverse percentage of words excised from target for outside
   //   correspondences
//FIXME: check why setting max to 0 got a better BLEU score!
   max_score[IDX_EXCISED_WORDS] = tsent_length - target_length ;
   score[IDX_EXCISED_WORDS] = max_score[IDX_EXCISED_WORDS] - excised ;

   MVTRACE(cout << "scores(" << target_start << "," << target_end << "):") ;
   double sum(0) ;
   double total_sum(0) ;
   // add up all the scores
   for (size_t i = 0 ; i < NUM_TEST_FUNCS ; i++)
      {
      MVTRACE(cout << ' ' << score[i] << '/' << max_score[i]) ;
      if (max_score[i] == 0 &&
	  (i == IDX_MATCHED_UNTRANS || i >= IDX_EXCISED_WORDS))
	 {
	 // heuristics which might not have any words they apply to should get
	 //   full credit when they have no opportunity, since that's a good
	 //   thing
	 score[i] = max_score[i] = 1 ;
	 }
      if (max_score[i] == 0 || align_weights[i] == 0.0)
	 {
	 if (i <= num_align_features)
	    {
	    test_scores[i] = 1.0 ;
	    }
	 continue ;
	 }
      double proportion = score[i] / max_score[i] ;
      if (i == IDX_LINK_MASS || i == IDX_OUTSIDE_LINKS)
	 proportion *= proportion ;
#ifdef LOGLIN
      sum += align_weights[i] * EBMTCandidate::log(proportion) ;
#else
      sum += align_weights[i] * proportion ;
#endif /* LOGLIN */
      total_sum += fabs(align_weights[i]) ;
      if (i <= num_align_features)
	 test_scores[i] = proportion ;
      }
#ifdef LOGLIN
   double align_score = total_sum ? ::exp(sum / total_sum) : 0.0 ;
#else
   double align_score = total_sum ? sum / total_sum : 0.0 ; 
#endif /* LOGLIN */
   MVTRACE(cout << " => " << align_score << endl) ;
   return align_score ;
}

/************************************************************************/
/************************************************************************/

static bool biggest_possible_match(const LinkScores &link_scores,
				     size_t matchlen, size_t targetlen,
				     size_t &minword, size_t &maxword,
				     size_t &min_poss, size_t &max_poss,
				     const WordStatus *status)
{
   size_t leftmost = minword ;
   size_t rightmost = maxword ;
   // try to expand the match by adding boundary words and words previously
   //   skipped because they had multiple corresponding target words
   int numexcised = 0 ;
   if (rightmost >= leftmost)		// any matches at all?
      {
      int i ;
      for (i = leftmost-1 ; i >= 0 ; i--)
	 {
	 // stop as soon as we encounter too many consecutive words that we
	 //   know couldn't translate anything in the source chunk
	 if (status[i].state == Trans_NotTrans)
	    {
	    // look back at following words
	    bool can_match = false ;
	    size_t last = targetlen ; 
	    if ((size_t)(i + 2) < targetlen)
	       last = i + 3 ;
	    for (size_t j = i + 1 ; j < last ; j++)
	       {
	       if (link_scores.targetScoreInside(j) > 0.0)
		  {
		  can_match = true ;
		  break ;
		  }
	       }
	    if (!can_match)
	       break ;
	    }
	 if (status[i].excised != 0)
	    numexcised++ ;
	 }
      leftmost = i+1 ;
      for (i = rightmost+1 ; i < (int)targetlen ; i++)
	 {
	 // stop as soon as we encounter too many consecutive words that we
	 //   know couldn't translate anything in the source chunk
	 if (status[i].state == Trans_NotTrans)
	    {
	    bool can_match = false ;
	    for (int j = (i >= 3) ? i-3 : 0 ; j < i ; j++)
	       {
	       if (link_scores.targetScoreInside(j) > 0.0)
		  {
		  can_match = true ;
		  break ;
		  }
	       }
	    if (!can_match)
	       break ;
	    }
	 if (status[i].excised != 0)
	    numexcised++ ;
	 }
      rightmost = i-1 ;
      }
   if (rightmost >= leftmost &&
       ((rightmost-leftmost+1-numexcised)*min_word_ratio >= matchlen))
      {
      min_poss = leftmost ;
      max_poss = rightmost+1 ;
      if (max_poss > targetlen)
	 max_poss = targetlen ;
      return true ;
      }
   else
      {
      min_poss = targetlen ; 
      max_poss = 0 ;
      return false ;
      }
}

//----------------------------------------------------------------------

static bool remove_excised(FrList *words, size_t start,
			     const WordStatus *status)
{
   bool have_nonexcised = false ;
   for ( ; words ; words = words->rest(), start++)
      {
      if (!status[start].matched && status[start].excised != 0)
	 {
	 free_object(words->first()) ;
	 words->replaca(EbMakeGapMarker(status[start].excised)) ;
	 }
      else
	 have_nonexcised = true ;
      }
   return have_nonexcised ;
}

//----------------------------------------------------------------------

static FrList *backfill_gaps(FrList *translation, EBMTCandidate *candidate,
			     size_t trg_start,
			     const WordStatus *word_status = 0,
			     const FrSymHashTable *targetvocab = 0)
{
   bool success = true ;
   if (translation && candidate->haveGap())
      {
      for (size_t ofs = 0 ; ofs < candidate->matchLength() ; ofs++)
	 {
	 if (!candidate->gapAt(ofs))
	    continue ;
	 size_t src_start = candidate->sourceOffset() ;
	 int trg_gap =
	    candidate->nextTargetCorrespondence(src_start+ofs,trg_start-1) ;
	 FrList *trg ;
	 if (trg_gap != -1 &&
	     (trg = translation->nthcdr(trg_gap - trg_start)) != 0)
	    {
	    free_object(trg->first()) ;
	    trg->replaca(EbMakeGapMarker(ofs,false,true)) ;
	    }
	 else
	    {
	    success = false ;
	    break ;
	    }
	 }
      }
   FrList *results ;
   FrList **res_end = &results ;
   if (success && translation)
      {
      FrList *translations ;
      if (contains_tokens(translation))
	 {
	 translations = candidate->backsubstitute(translation,targetvocab,trg_start) ;
	 free_object(translation) ;
	 }
      else
	 translations = new FrList(translation) ;
      while (translations)
	 {
	 FrList *trans = (FrList*)poplist(translations) ;
	 if (!word_status ||
	     remove_excised(trans,trg_start,word_status))
	    {
	    if (trans)
	       {
	       results->pushlistend(new FrString(trans,char_encoding),res_end);
	       free_object(trans) ;
	       }
	    else
	       results->pushlistend(new FrString(""),res_end) ;
	    }
	 else
	    {
	    free_object(trans) ;
	    }
	 }
      }
   else
      free_object(translation) ;
   *res_end = 0 ; 			// terminate the results list
   return results ;
}

//----------------------------------------------------------------------

static EbIntRangeList *align(const EBMTCandidate *candidate,
			     size_t src_start, size_t src_end,
			     LinkScores &link_scores,
			     const WordStatus *word_status, bool relaxed,
			     size_t min_required, size_t max_required,
			     size_t min_poss, size_t max_poss,
			     size_t min_target, size_t max_target)
{
   total_alignments_scored++ ;
//cout<<"aligning "<<candidate->exampleNumber()<<"/"<<src_start<<"-"<<src_end<<endl;
   EbIntRangeLists alignments(max_align_ambig,align_ambig_cutoff) ;
   size_t gaplocs = candidate->gapPositions() ;
   size_t numtokens = candidate->numTokens() ;
   size_t targetlen = candidate->targetLength() ;
   const BiTextMap *bitext = candidate->bitext() ;
   for (size_t i = min_poss ; i <= min_required ; i++)
      {
      size_t end_target = i + max_target ;
      if (end_target > targetlen)
	 end_target = targetlen ;
      if (end_target > max_poss)
	 end_target = max_poss ;
      else if (end_target < max_required)
	 end_target = max_required ;
      size_t start_target = i + min_target ;
      if (start_target < max_required)
	 start_target = max_required ;
      for (size_t j = start_target ; j <= end_target ; j++)
	 {
	 double test_scores[NUM_ALIGN_SCORES] ;
	 double curr_score = score_match(bitext, link_scores,
					 src_start, src_end, i, j,
					 gaplocs, numtokens, word_status,
					 relaxed, test_scores) ;
	 alignments.insert(i,j,curr_score,IR_Heuristic,
			   show_all_align_scores ? test_scores : 0) ;
	 }
      }
   return alignments.ranges() ;
}

//----------------------------------------------------------------------

static EbIntRangeList *align(const EBMTCandidate *candidate,
			     WordStatus *word_status, bool relaxed,
			     size_t t_start, size_t t_end,
			     size_t t_limit_low = 0, size_t t_limit_high = ~0,
			     bool precompute_subphrases = context_biases_sampling)
{
   const BiTextMap *bitext = candidate->bitext() ;
   if (!bitext)
      return 0 ;			// can't align without a bitext map
   bool complete = candidate->completeMapping() ;
   size_t min_required, max_required ;
   size_t src_start = candidate->sourceOffset() ;
   size_t src_end = src_start + candidate->matchLength() - 1 ;
   const FrList *source_sent = candidate->sourceWords() ;
   const EbSentence *target_sent = candidate->targetSentence() ;
   LinkScores link_scores(bitext,src_start,src_end) ;
   classify_words(bitext,complete,link_scores,src_start,src_end,
		  source_sent,target_sent,word_status,
		  min_required,max_required) ;
   size_t matchlen = candidate->matchLength() ;
   size_t targetlen = candidate->targetLength() ;
   size_t min_poss = t_limit_low ;
   size_t max_poss = t_limit_high ;
   // do we have an enforced target segment?
   bool have_anchor ;
   if (t_start <= t_end)
      {
      have_anchor = true ;
      min_required = t_start ;
      max_required = t_end ;
      if (t_limit_high == (size_t)~0)
	 {
	 min_poss = t_start ;
	 max_poss = t_end ;
	 }
      }
   else
      have_anchor
	 = biggest_possible_match(link_scores,matchlen,targetlen,
				  min_required,max_required,
				  min_poss,max_poss,word_status) ;
   // some prestidigitation to minimize the work we do; we don't want to
   //   bother with any matches that are too much shorter or longer than the
   //   source chunk
   size_t min_target = matchlen / min_word_ratio ;
   if (min_target > 0)
      min_target-- ;
   size_t max_target = matchlen * max_word_ratio + 1 ;
   if (!have_anchor)
      {
      // we're brute-forcing this one....
      if (t_limit_high == (size_t)~0)
	 {
	 min_poss = 0 ;
	 max_poss = targetlen ;
	 }
      min_required = targetlen - min_target ;
      max_required = min_target ;
      }
   if (min_required > targetlen)
      min_required = targetlen ;
   if (max_required > targetlen)
      max_required = targetlen ;
   // the commented-out first part of the expression below is needed
   //    to correctly decide whether the target is viable, but initial
   //    tests indicate that performance is actually better if we just
   //    skip brute-forced alignments...
   if ((max_required >= min_required || !brute_force_align) &&
       (max_required - min_required + 1) > max_target)
      {
      skipped_training_instances++ ;
      return 0 ;			// can't get a good alignment
      }
   EbAlignCacheEntry *entry = 0 ;
   if (precompute_subphrases && alignment_cache && matchlen > 1)
      entry = new EbAlignCacheEntry(candidate->sourceIndex(),
				    candidate->exampleNumber(),
				    src_start,src_end) ;
   EbIntRangeList *ranges = align(candidate,src_start,src_end,
				  link_scores,word_status,relaxed,
				  min_required,max_required,min_poss,max_poss,
				  min_target,max_target) ;
   if (entry && !alignment_cache->add(entry))
      delete entry ;
   return ranges ;
}

/************************************************************************/
/************************************************************************/
// This is SPA alignment added by Jaedy for experiments

static EbIntRangeList *SPA_align(const EBMTCandidate *candidate,
				 WordStatus * /*word_status*/,
				 size_t t_start, size_t t_end,
				 size_t /*t_mask*/)
{
   total_alignments_scored++ ;
   const BiTextMap *bitext = candidate->bitext() ;
   assertq(bitext != 0) ;
   size_t targetlen = bitext->targetLength()-1;
   size_t src_start = candidate->sourceOffset() ;
   size_t src_end = src_start + candidate->matchLength() - 1 ;
   size_t srclen = src_end - src_start + 1;
   size_t tgtlen;
   size_t tmax = 0;
   size_t tmin = targetlen;
   if (use_basic_SPA)
      tmin++ ;
#ifdef USE_LINKS
//   size_t avg = 0, avg_cnt = 0;
   for (size_t i=src_start; i<=src_end; i++ ) 
      {
      size_t tgt = bitext->lastTargetCorrespondence(i) ;
      if (tgt > tmax)
	 tmax = tgt ;
      tgt = bitext->firstTargetCorrespondence(i) ;
      if (tgt < tmin)
	 tmin = tgt ;
//      const unsigned char *corr = bitext->sourceCorrespondences(i);
//      for( size_t j=0; j<bitext->targetLength(); j++ )
//	 {
//	 if (corr[i] != (char)0)
//	    {
//	    avg += j;
//	    avg_cnt++;
//	    }
//	 }
      }
#else
   size_t avg = 0, avg_cnt = 0;
   avg = (size_t)((src_start+src_end)*
		  ((double)bitext->targetLength()/bitext->sourceLength())/2);
   avg_cnt = 1;
   if( avg_cnt ) 
      {
      avg /= avg_cnt;
      tmin = avg - srclen/2;
      tmax = avg + srclen/2;
      if ((int)tmin < 0 )
	 tmin = 0;
      if (tmax > bitext->targetLength() )
	 tmax = bitext->targetLength();
      }
#endif /* USE_LINKS */

   size_t tmin_start = (tmin < SPA_window_size) ? 0 : tmin - SPA_window_size ;
   size_t tmin_end = tmin + SPA_window_size ;
   if (tmin_end > targetlen)
      tmin_end = targetlen ;
   size_t tmax_start = (tmax < SPA_window_size) ? 0 : tmax - SPA_window_size ;
   size_t tmax_end = tmax + SPA_window_size ;
   if (tmax_end > targetlen)
      tmax_end = targetlen ;

   MTRACE(fprintf(stderr, "TGTLEN [%ld] sourceLength[%ld] targetLength[%ld]\n", \
		  (long)targetlen, (long)bitext->sourceLength(), \
		  (long)bitext->targetLength())) ;
/*
   for( size_t j=0; j<=targetlen; j++ )
      fprintf(stderr, "[%d]%s ", j, bitext->targetWord(j));
   fprintf(stderr, "\n");
*/

   MTRACE(fprintf(stderr, "SS:%ld, SE:%ld, TMIN:%ld, TMAX:%ld, TMIN_S:%ld, TMIN_E:%ld, TMAX_S:%ld, TMAX_E:%ld\n", \
		  (long)src_start, (long)src_end, (long)tmin, (long)tmax, \
		  (long)tmin_start, (long)tmin_end, (long)tmax_start, \
		  (long)tmax_end )) ;

   if (t_start <= t_end ) 
      {
      tmin_start = tmin_end = t_start;
      tmax_start = tmax_end = t_end;
      }

   double biarr[SPA_MAX_SENT][SPA_MAX_SENT];
   double tgt_inside[SPA_MAX_SENT] ;
   double tgt_outside[SPA_MAX_SENT] ;

   size_t src_first, src_last ;
   size_t trg_start, trg_end ;
   if (use_basic_SPA)
      {
      src_first = src_start ;
      src_last = src_end + 1 ;
      trg_start = tmin_start ;
      trg_end = tmax_end + 1 ;
      }
   else
      {
      src_first = 0 ;
      src_last = bitext->sourceLength() ;
      trg_start = 0 ;
      trg_end = bitext->targetLength() ;
      }
   for( size_t j=trg_start; j < trg_end; j++ ) 
      {
      double inside = SPA_EPSILON ;
      size_t incount = 0 ;
      double outside = SPA_EPSILON ;
      size_t outcount = 0 ;
      for( size_t i = src_first; i < src_last; i++ ) 
	 {
	 if (bitext->wordsCorrespond(i,j))
	    {
	    double sc = bitext->correspondenceScore(i,j);
	    biarr[i][j] = sc ;
	    if (i >= src_start && i <= src_end)
	       {
	       inside += sc ;
	       incount++ ;
	       }
	    else
	       {
	       outside += sc ;
	       outcount++ ;
	       }
	    }
	 else
	    biarr[i][j] = 0.0;
	 }
      // since the tgtscore for any given target word is constant (due to the
      //   fixed source phrase), we can precompute it so that we need only
      //   sum up the individual word scores while scoring a candidate align
      if (incount)
	 tgt_inside[j] = log(inside / incount) ;
      else
	 tgt_inside[j] = log(SPA_EPSILON) ;
      if (outcount)
	 tgt_outside[j] = log(outside / outcount) ;
      else
	 tgt_outside[j] = log(SPA_EPSILON) ;
      }

   EbIntRangeLists alignments(max_align_ambig,align_ambig_cutoff) ;

   size_t min_tgtlen = srclen / min_word_ratio ;
   if (min_tgtlen > 0)
      min_tgtlen-- ;
   if (use_basic_SPA)
      {
      tmin_end = tmax_end ;
      tmax_start = min_tgtlen ;
      }
   else
      {
//      tmax_start = minimum(tmin_end,tmax_start) ; 
      tmax_start = min_tgtlen ; //FIXME?
      }
   for( size_t ts=tmin_start; ts<=tmin_end; ts++ )
      { 
      for( size_t te=maximum(ts+min_tgtlen,tmax_start); te<=tmax_end; te++ ) 
	 {
	 tgtlen = te - ts + 1;
	 // reduce the amount of work we do by ignoring candidate alignments
	 //   which differ too much in length between source and target
	 if ((srclen==1 && tgtlen>3) ||
	     (srclen > 1 && tgtlen > srclen*max_word_ratio))
	    break ;			// won't get any more short enough
	 if ((tgtlen==1 && srclen>3) ||
	     (tgtlen > 1 && srclen > tgtlen*min_word_ratio))
	    continue ;
	 MTRACE(fprintf( stdout, "SRC: %ld-%ld    TGT: %ld-%ld\n", \
			 (long)src_start, (long)src_end, (long)ts, (long)te)) ;
	 double score ;
	 double srcscore = 0.0 ;
	 double tgtscore = 0.0;

	 if (use_basic_SPA)
	    {
	    // src | tgt 
	    for( size_t i=src_start; i<=src_end; i++ ) 
	       {
	       size_t cnt = 0; 
	       double tmpscore = 0;
	       for( size_t j=ts; j<=te; j++ ) 
		  {
		  if( biarr[i][j] != 0.0 ) 
		     {
		     tmpscore += biarr[i][j];
		     cnt++;
		     }
		  }   
	       if( cnt ) 
		  {
		  tmpscore /= cnt;
		  srcscore += log(tmpscore);
		  }
	       else
		  { srcscore += log(SPA_EPSILON); }
	       MVTRACE(fprintf(stdout, "\tSRC SCORE[%e]\n", srcscore )) ;
	       }
	    srcscore /= srclen;
	    MTRACE(fprintf(stdout, "FINAL SRC SCORE[%e]\n", srcscore )) ;

	    // tgt | src
	    for( size_t i = ts ; i <= te; i++ ) 
	       {
	       tgtscore += tgt_inside[i] ;
	       }
	    tgtscore /= tgtlen;
	    MTRACE(fprintf(stdout, "FINAL TGT SCORE[%e]\n", tgtscore ));

	    score = (srcscore+tgtscore)/2;
	    score += log((1.0 - abs((int)(srclen-tgtlen))/(double)(srclen*tgtlen)));
	    score = exp(score);
	    }
	 else // !use_basic_SPA
	    {

/*				Positive: p1, p3, p5, p7, p9
				Negative: p2, p4, p6, p8
				----------------------
				|      |      |      |
				|  p1  |  p2  |  p3  |
				|      |      |      |
				----------------------
				|      |      |      |
				|  p4  |  p5  |  p6  |
				|      |      |      |
				----------------------
				|      |      |      |
				|  p7  |  p8  |  p9  |
				|      |      |      |
				----------------------
				srcscore/tgtscore are p5
*/
	    // src 2 tgt 
	    double src_p1379 = 0.0;
	    double src_p2468 = 0.0;
	    for( size_t i=0; i<bitext->sourceLength(); i++ )
	       {
	       double inscore = SPA_EPSILON;
	       size_t incnt = 0;
	       double outscore = SPA_EPSILON;
	       size_t outcnt = 0;
	       for( size_t j=0; j<bitext->targetLength(); j++ ) 
		  {
		  if( biarr[i][j] == 0.0 )
		     continue;
		  if( ((i>=src_start && i<=src_end) && (j>=ts && j<=te )) ||
		      (!(i>=src_start && i<=src_end) && !(j>=ts && j<=te )))
		     {
		     inscore += biarr[i][j];
		     incnt++;
		     }
		  else
		     {
		     outscore += biarr[i][j];
		     outcnt++;
		     }
		  }
	       if( incnt ) inscore /= incnt;
	       if( outcnt ) outscore /= outcnt;
	    
	       if( i>=src_start && i<=src_end )
		  srcscore += log(inscore);
	       else
		  src_p1379 += log(inscore);
	       src_p2468 += log(outscore);
	       }
	    srcscore /= srclen;
	    src_p1379 /= bitext->sourceLength()-srclen;
	    src_p2468 /= bitext->sourceLength();
			 
	    // tgt 2 src
	    double tgt_p1379 = 0.0;
	    double tgt_p2468 = 0.0;
	    size_t i ;
	    for (i = 0; i < ts ; i++)
	       {
	       tgt_p1379 += tgt_outside[i] ;  // p1 and p7
	       tgt_p2468 += tgt_inside[i] ;   // p4
	       }
	    for ( ; i <= te ; i++)
	       {
	       tgtscore += tgt_inside[i] ;    // p5
	       tgt_p2468 += tgt_outside[i] ;  // p2 and p8
	       }
	    for ( ; i < bitext->targetLength() ; i++ )
	       {
	       tgt_p1379 += tgt_outside[i] ;  // p3 and p9
	       tgt_p2468 += tgt_inside[i] ;   // p6
	       }
	    tgtscore /= tgtlen;
	    tgt_p1379 /= bitext->targetLength()-tgtlen;
	    tgt_p2468 /= bitext->targetLength();

	    score = (exp((srcscore+tgtscore)/2)
		     +0.1*exp((src_p1379+tgt_p1379)/2)
		     -0.1*exp((src_p2468+tgt_p2468)/2)) ;
	    if( score < 0 ) score = 0;
	    score *= (1.0 - abs((int)(srclen-tgtlen))/(double)(srclen*tgtlen));
	    }
	 MTRACE(fprintf(stderr, "CANDIDATE: SCORE[%e] SRCSCORE[%e] TGTSCORE[%e]\n", score, srcscore, tgtscore ));
	 double s2tratio = tgtlen/(double)srclen ;
	 double t2sratio = srclen/(double)tgtlen ;
#ifdef PRINT_MOSES
	 if (trace_matching)
	    {
	    if (use_basic_SPA)
	       {
	       fprintf( stderr, "%e %d %d", score, srclen, tgtlen );
	       fprintf( stderr, "%e ", exp((srcscore+tgtscore)/2));
	       }
	    for( size_t j=0; j<candidate->sourceWords()->simplelistlength(); j++ )
	       fprintf(stderr, "%s ",
		       candidate->sourceWords()->getNth(j)->printableName());
	    fprintf( stderr, "||| " );
	    for (size_t j = ts ; j <= te ; j++)
	       fprintf(stderr, "%s ", candidate->targetSentence()->word(j));
	    fprintf(stderr, "||| %e %e %e %f %f\n", score, srcscore,
		    tgtscore, s2tratio, t2sratio );
	    }
#endif /* PRINT_MOSES */
	 double test_scores[NUM_ALIGN_SCORES] ;
	 test_scores[0] = srcscore;
	 test_scores[1] = tgtscore;
	 test_scores[2] = log(s2tratio) ;
	 test_scores[3] = log(t2sratio) ;
	 alignments.insert(ts, te, score, IR_SPA,
			   show_all_align_scores ? test_scores : 0) ;
	 }
      }
   
   return alignments.ranges() ;
}

//----------------------------------------------------------------------

static void make_target_phrase(EBMTCandidate *candidate, FrList *matchlist,
			       size_t start, size_t stop, size_t mask,
			       double phrase_score, double wt, double conf,
			       const double *user_scores, bool &first)
{
   while (matchlist)
      {
      EBMTCandidate *cand ;
      if (first)
	 {
	 cand = candidate ;
	 first = false ;
	 }
      else
	 {
	 // clone the translation candidate
	 cand = new EBMTCandidate(candidate) ;
	 cand->setNext(candidate->next()) ;
	 candidate->setNext(cand) ;
	 }
      cand->freeTargetWords() ;
      cand->setAlignScore(phrase_score) ;
      cand->setAlignQuality(phrase_score) ;
      cand->setConfidence(conf) ;
      cand->setWeight(wt) ;
      FrString *match = (FrString*)poplist(matchlist) ;
      if (stop == (size_t)~0)
	 stop = start + EbWordCount(match) - 1 ;
      cand->setTargetWords(match,start,stop,mask) ;
      if (show_all_align_scores || user_scores)
	 cand->setAlignScores(user_scores,num_align_features) ;
      }
   return ;
}

//----------------------------------------------------------------------

static void make_target_phrases(EBMTCandidate *candidate,
				EbIntRangeList *alignments,
				const WordStatus *word_status,
				const FrSymHashTable *targetvocab)
{
   if (alignments)
      {
      KEEP_STATS(total_alignments_good++) ;
      EbSentence *tsent = candidate->targetSentence() ;
      bool first = true ;
      double wt = candidate->weight() ;
      double conf = candidate->confidence() ;
      for (const EbIntRangeList *al = alignments ; al ; al = al->next())
	 {
	 size_t start = al->start() ;
	 size_t stop = al->end() ;
	 FrList *matchlist = backfill_gaps(tsent->wordList(start,stop),
					   candidate,start,word_status,
					   targetvocab) ;
	 if (matchlist)
	    {
	    make_target_phrase(candidate,matchlist,start,stop,al->mask(),
			       al->score(), wt,conf,al->userScores(),first) ;
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

static EbIntRangeList *align_chunk(EBMTCandidate *candidate,
				   WordStatus *word_status, bool relaxed,
				   size_t t_start, size_t t_end,
				   size_t t_limit_low = 0,
				   size_t t_limit_high = ~0,
				   size_t t_mask = ~0)
{
   BiTextMap *bitext = candidate->bitext() ;
   EbIntRangeList *alignments ;
   if (use_SPA && bitext && bitext->sourceLength() < SPA_MAX_SENT &&
       bitext->targetLength() < SPA_MAX_SENT)
      alignments = SPA_align(candidate, word_status, t_start, t_end, t_mask );
   else
      alignments = align(candidate, word_status, relaxed, t_start, t_end,
			 t_limit_low, t_limit_high) ;
   return alignments ;
}

//----------------------------------------------------------------------

static void align_chunk_main(EBMTCandidate *candidate, bool relaxed,
			     const FrSymHashTable *targetvocab,
			     size_t t_start = ~0, size_t t_end = 0,
			     size_t t_limit_low = 0, size_t t_limit_high = ~0,
			     size_t t_mask = ~0)
{
   WordStatus word_status[EbEx_LENGTHMASK+1] ;
   FrCRITSECT_ENTER(mutex) ;
   EbIntRangeList *alignments = align_chunk(candidate,word_status,relaxed,
					    t_start,t_end,
					    t_limit_low,t_limit_high,t_mask) ;
   FrCRITSECT_LEAVE(mutex) ;
   candidate->markUnalignable() ;
   candidate->clearTargetWords() ;
   make_target_phrases(candidate,alignments,word_status,targetvocab) ;
   delete alignments ;
   return ;
}

//----------------------------------------------------------------------

static void elide_noncorresponding(FrList *&submatch, EBMTCandidate *candidate,
				   size_t start, size_t end, size_t mask)
{
   size_t additional_words = end - start ;
   if (additional_words > CHAR_BIT * sizeof(mask))
      additional_words = CHAR_BIT * sizeof(mask) ;
   FrList *sub = submatch ; 
   for (size_t i = 0 ; i < additional_words && sub ; i++, sub = sub->rest())
      {
      if ((mask & (1L << i)) == 0)
	 {
	 free_object(sub->first()) ;
	 if (candidate->numSourceCorrespondences(start+i+1) == 1)
	    {
	    // check whether the unique correspondence is just outside the
	    //   source chunk; if so, instead of completely eliding the target
	    //   word, we'll insert a marker for the decoder to try to fill
	    //   in an appropriate translation from another candidate
	    size_t src = candidate->firstSourceCorrespondence(start+i+1) ;
	    size_t sim = EbMaxGapOffset() ;
	    if (src < start && start - src <= sim)
	       sub->replaca(EbMakeGapMarker((int)(src-start))) ;
	    else if (src > end && src - end <= sim)
	       sub->replaca(EbMakeGapMarker((int)(src-end))) ;
	    else
	       sub->replaca(EbMakeGapMarker(0)) ;
	    }
	 else
	    sub->replaca(EbMakeGapMarker(0)) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void align_chunk(EBMTCandidate *candidate, bool keep_sentpair,
		 bool relaxed, const FrSymHashTable *targetvocab)
{
   double phrase_score ;
   size_t trg_start, trg_end, trg_mask ;
   if (candidate->completeMatch())
      {
      if (!candidate->targetWords())
	 {
	 // this chunk is an exact match for the source sentence, and does not
	 //   yet have an aligned translation listed, so the alignment is the
	 //   complete target sentence
	 const EbSentence *targsent = candidate->targetSentence() ;
	 if (targsent && targsent->length() > 0)
	    {
	    double orig_align_score = 1.0 ;
	    if (candidate->haveMetaScore())
	       {
	       orig_align_score = candidate->alignmentScore() ;
	       candidate->setScore(orig_align_score * candidate->score()) ;
	       }
	    candidate->markUnalignable() ;
	    FrList *matchlist = backfill_gaps(targsent->wordList(),
					      candidate,0,0,targetvocab) ;
	    if (matchlist)
	       {
	       double tokpen = ((candidate->numTokens() /
				(double)candidate->matchLength()) *
				align_weights[IDX_SURFACE_MATCH]) ;	
	       double sumwt = (align_weights[IDX_SURFACE_MATCH] +
			       align_weights[IDX_LINK_MASS]) ;
	       double discounted = (sumwt-tokpen) / sumwt * orig_align_score ;
	       const double *user_scores = 0 ;
	       EbIntRangeList *a = 0 ;
	       if (show_all_align_scores)
		  {
		  WordStatus word_status[EbEx_LENGTHMASK+1] ;
		  a = align_chunk(candidate, word_status, relaxed, 0,
				  targsent->length() - 1) ;
		  user_scores = (a ? a->userScores() : 0) ;
		  }
	       bool first = true ;
	       make_target_phrase(candidate,matchlist,0,~0,~0,discounted,
				  candidate->weight(),candidate->confidence(),
				  user_scores,first) ;
	       delete a ;
	       }
	    }
	 }
      }
   else if (candidate->matchLength() >= min_phrase_length &&
            (phrase_score = candidate->phraseAlign(trg_start,trg_end,trg_mask))
	    >= phrase_threshold)
      {
      size_t alt_num = 0 ;
      EbSentence *tsent = candidate->targetSentence() ;
      bool first = true ;
      double conf = candidate->confidence() ;
      double wt = candidate->weight() ;
      do {
         // we have an explicit phrasal alignment stored in the corpus, so use
         //   that directly
         MVTRACE(cout <<"phrase align = " << trg_start << "," << trg_end \
		      << "," << phrase_score << endl) ;
	 FrList *submatch = tsent->wordList(trg_start,trg_end) ;
	 elide_noncorresponding(submatch,candidate,trg_start,trg_end,trg_mask);
	 FrList *matchlist = backfill_gaps(submatch,candidate,trg_start,0,
					   targetvocab) ;
	 if (matchlist)
	    {
	    if (show_all_align_scores || rescore_external_phrases)
	       {
	       WordStatus word_status[EbEx_LENGTHMASK+1] ;
	       EbIntRangeList *a ;
	       BiTextMap *bitext = candidate->bitext() ;
	       if (use_SPA && bitext &&
		   bitext->sourceLength() < SPA_MAX_SENT &&
		   bitext->targetLength() < SPA_MAX_SENT)
		  a = SPA_align(candidate, word_status, trg_start, trg_end,
				trg_mask);
	       else
		  a = align(candidate, word_status, relaxed,
			    trg_start, trg_end) ;
	       if (show_all_align_scores || (a && a->userScores()))
		  candidate->setAlignScores(a ? a->userScores() : 0,
					    num_align_features) ;
	       if (rescore_external_phrases && a)
		  phrase_score = a->score() ;
	       delete a ;
	       }
	    make_target_phrase(candidate,matchlist,trg_start,~0,trg_mask,
			       phrase_score,wt,conf,0,first) ;
	    }
      } while ((phrase_score = candidate->phraseAlign(trg_start,trg_end,
						      trg_mask,++alt_num))
	       >= phrase_threshold) ;
      }
   else // no exact match, so find best alignment
      {
      bool may_use = true ;
      trg_start = 0 ;
      trg_end = (size_t)~0 ;
      trg_mask = (size_t)~0 ;
      if (candidate->matchLength() >= min_phrase_length &&
	  !may_cross_phrase_boundaries)
	 {
	 if (candidate->phraseAlignSuperset(trg_start,trg_end,
					    trg_mask) >= phrase_threshold)
	    {
	    // do nothing, we'll use trg_start and trg_end to restrict aligner
//	      // prune the bitext map according to the phrasal alignment
//	      candidate->pruneBitextTarget(trg_start,trg_end) ;
	    }
	 else if (candidate->crossesPhrases())
	    {
	    // we didn't have a superset phrase, but we've been asked not to 
	    //   cross phrase boundaries as defined in the corpus metadata
	    may_use = false ;
	    candidate->markUnalignable() ;
	    }
	 }
      if (may_use)
	 align_chunk_main(candidate,relaxed,targetvocab,
			  ~0,0,trg_start,trg_end,trg_mask) ;
      }
   if (trace_matching)
      display_match(candidate) ;
   // reduce memory requirements by freeing the full target sentence, which
   // is no longer required
   if (!keep_sentpair)
      candidate->freeTargetSentence() ;
   return ;
}

// end of file ebalign.cpp //
