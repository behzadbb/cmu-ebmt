/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebmkdict.cpp	generate translation dictionary	from corpus	*/
/*  LastEdit: 08apr10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "ebconfig.h"
#include "ebcorpus.h"
#include "dict.h"
#include "ebmkdict.h"
#include "ebtoken.h"
#include "ebutil.h"
#include "ebmt.h"
#include "ebglobal.h"

#ifndef NDEBUG
# undef _FrCURRENT_FILE
static const char _FrCURRENT_FILE[] = __FILE__ ; // save memory
#endif /* NDEBUG */

/************************************************************************/
/*	Manifest constants for this module				*/
/************************************************************************/

#define DOC_SEPARATOR "<<EOD>>"
#define BATCHSIZE	4	// how many times actual window to accumulate
				// before actually adding co-occurrences
				// (reduces array resizing)

// DOS/Windows have a lower limit on open files than Unix...
#if defined(__MSDOS__) || defined(MSDOS)
# define MAX_SWAP_FPS 8
# define SWAP_FP_MASK 0x0007
# define DEFAULT_LINES_PER_CHUNK 10000

#elif defined(__WINDOWS__) || defined(__NT__)
# define MAX_SWAP_FPS 16
# define SWAP_FP_MASK 0x000F
# define DEFAULT_LINES_PER_CHUNK 32000

#elif defined(__WATCOMC__) || defined(_MSC_VER)
# define MAX_SWAP_FPS 8
# define SWAP_FP_MASK 0x0007
# define DEFAULT_LINES_PER_CHUNK 10000

#elif defined(__linux__)
# define MAX_SWAP_FPS 64
# define SWAP_FP_MASK 0x003F
#  if defined(__886__)
#     define DEFAULT_LINES_PER_CHUNK 1000000L
#  else
#     define DEFAULT_LINES_PER_CHUNK 500000L
#  endif /* __886__ */

#else
# define MAX_SWAP_FPS 32
# define SWAP_FP_MASK 0x001F
# define DEFAULT_LINES_PER_CHUNK 125000L

#endif /* __MSDOS__ || __WINDOWS__ || __NT__ */

#define DEFAULT_LINES_PER_MI_CHUNK (10*DEFAULT_LINES_PER_CHUNK)

#define NUM_THRESHOLDS	20	 // separate thresholds for first N counts

#define DICT_SYMTAB_SIZE 64000
#define DICT_HASHTAB_SIZE 64000

#define MIN_MAX_SIZE (sizeof(FrArrayFrag)/sizeof(FrArrayFrag*))

#define array_frags(n) (((n)+FrARRAY_FRAG_SIZE-1)/FrARRAY_FRAG_SIZE)

/************************************************************************/
/*	Global variables for this module				*/
/************************************************************************/

static size_t total_wordcount = 0 ;
static double total_weight = 0.0 ;

static size_t num_dict_thresholds = 0 ;
static double *dict_thresholds_low ;
static double *dict_thresholds ;
static double *dict_thresholds_high ;

static bool Initialized = false ;
static FrSymbolTable *dict_symtab ;
static FrSymHashTable *dict_target ;
static FrList *dict_sstoplist = 0 ;
static FrList *dict_tstoplist = 0 ;
static FrCasemapTable dict_charmap = 0 ;
static const char *dict_tempdir = "." ;
static size_t dict_lines_per_chunk = DEFAULT_LINES_PER_CHUNK ;
static bool swapped_out_data = false ;
static FILE *swap_fp[MAX_SWAP_FPS] ;
static char *swap_file[MAX_SWAP_FPS] ;

static size_t sentences_processed = 0 ;

//static bool count_once_only = false ;
static bool count_once_only = true ;

//----------------------------------------------------------------------

static const char error_bang[] = "Error!" ;
static const char ready_bang[] = "Ready!" ;
static const char done_bang[] = "Done!" ;

static const char str_Ok[] = "Ok" ;

//----------------------------------------------------------------------

static size_t num_definitions = 0 ;

/************************************************************************/
/*    forward and external declarations					*/
/************************************************************************/

bool EbExtractFreqTag(const char *tags, uint32_t &xlat, uint32_t &total) ;
FrList *EbExtractAlignTag(const char *tags) ;

/************************************************************************/
/************************************************************************/

class DictList : public FrSparseArray
{
   private:
      static FrAllocator allocator ;
   private:
      size_t   count ;			// how many times did we see source wrd
      size_t   weight ;			// total weight for source word
   public:
      void *operator new(size_t) { return allocator.allocate() ; }
      void operator delete(void *blk,size_t) { allocator.release(blk) ; }
      DictList()
	  { count = 1 ; weight = 1 ; memset(items,'\0',sizeof(items)) ; }
      DictList(size_t n, size_t max, size_t wt = 1) ;
      DictList(FrSymbol *word, size_t weight = 1) ;
      DictList(const FrList *words, size_t max = 0, size_t weight = 1) ;
      //virtual ~DictList() ;

      void incrCount() { count++ ; }
      void setCount(size_t cnt) { count = cnt ; }
      void addWeight(size_t w) { weight += w ; }
      void setWeight(size_t w) { weight = w ; }

      double highestMCP(FrSymbol *word,FrSymHashTable *ht,size_t &corr) const ;

      void removeUncorrelated(FrSymbol *word,
			      FrSymHashTable *target_words,
			      Dictionary *dict,
			      bool refining = false) const ;
      bool filterChiSquared(FrSymbol *word, FrSymHashTable *target_words,
			      size_t total_wordcount) ;
      bool filterTriggers(FrSymbol *word,size_t totalcount,size_t step_size,
			    double max_expected) ;

      bool add(const FrList *counts) ;
      bool defineWord(FrSymbol *word, Dictionary *dict) const ;
      bool merge(const DictList *other) ;
      bool write(FrSymbol *word,FILE *fp) const ;
      static DictList *read(FILE *fp, FrSymbol *&word) ;
      static void reserve(size_t N) ;

      // access to internal state
      size_t numItems() const { return m_length ; }
      size_t wordCount() const { return count ; }
      size_t wordWeight() const { return weight ; }
} ;

//----------------------------------------------------------------------

FrAllocator DictList::allocator("DictList",sizeof(DictList)) ;

/************************************************************************/
/*	Helper functions						*/
/************************************************************************/

static DictList *get_dictlist(FrSymbol *sym)
{
   // gross hack to save lots of space: stuff DictList into symbol's
   // frame field instead of using a separate hash table
   return (DictList*)sym->symbolFrame() ;
}

//----------------------------------------------------------------------

static void set_dictlist(FrSymbol *sym, DictList *dlist)
{
   // gross hack to save lots of space: stuff DictList into symbol's
   // frame field instead of using a separate hash table
   DictList *dl = get_dictlist(sym) ;
   delete dl ;
   sym->setFrame((FrFrame*)dlist) ;
   return ;
}

//----------------------------------------------------------------------

inline void incr_dict_count(FrSymHashTable *dict_target, FrSymbol *word,
			    size_t amount = 1)
{
   // update the frequency of the given word
   FrSymHashEntry *entry = dict_target->lookup(word) ;
   if (!entry)
      dict_target->add(word,amount) ;
   else
      entry->setCount(((size_t)entry->getValue())+amount) ;
   return ;
}

//----------------------------------------------------------------------

static void add_cooccur_count(FrSymbol *sword, FrSymbol *tword,
			      size_t weight)
{
   DictList *dictlist = get_dictlist(sword) ;
   if (dictlist)
      {
      if (tword)
	 dictlist->addItem((uintptr_t)tword,(FrObject*)weight,
			   FrArrAdd_INCREMENT) ;
      else
	 {
	 dictlist->incrCount() ;
	 dictlist->addWeight(weight) ;
	 }
      }
   else
      {
      if (tword)
	 dictlist = new DictList(tword,weight) ;
      else
	 dictlist = new DictList((FrList*)0,0,weight) ;
      set_dictlist(sword,dictlist) ;
      }
   return ;
}

//----------------------------------------------------------------------

static bool add_new_cooccur_count(FrSymbol *sword, FrSymbol *tword,
				  size_t weight, FrHashTable &already_seen)
{
   FrList *pair = new FrList(sword,tword) ;
   FrHashEntryObject entry(pair) ;
   pair->eraseList(false) ;
   if (!already_seen.lookup(&entry))
      {
      add_cooccur_count(sword,tword,weight) ;
      already_seen.add(&entry) ;
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

static void add_cooccur_counts(FrSymbol *sword, const FrList *twords,
			       size_t weight)
{
   DictList *dictlist = get_dictlist(sword) ;
   if (dictlist)
      {
      dictlist->incrCount() ;
      dictlist->addWeight(weight) ;
      }
   else
      {
      dictlist = new DictList((FrList*)0,0,weight) ;
      set_dictlist(sword,dictlist) ;
      }
   for (const FrList *tw = twords ; tw ; tw = tw->rest())
      {
      FrSymbol *tword = (FrSymbol*)tw->first() ;
      if (tword)
	 dictlist->addItem((uintptr_t)tword,(FrObject*)weight,
			   FrArrAdd_INCREMENT) ;
      }
   return ;
}

//----------------------------------------------------------------------

static bool by_chance(size_t weight1, size_t weight2, size_t cooccur,
			bool refining)
{
   if (total_weight >= 100 && weight1 > cooccur && weight2 > cooccur)
      {
      double expected = ((double)weight1 * weight2) / total_weight ;
      double discount ;
      size_t maxweight = max(weight1,weight2) ;
      if (refining)
	 {
	 // while refining, we'll often get instances that don't align when
	 //   they actually should, so set the discount to account for that
	 discount = 0.75 - (maxweight/(double)total_weight)/10.0 ;
	 }
      else
	 {
	 // for low-frequency terms, we can use the expected value as-is, but
	 //   if the two terms are very frequent, we need to relax the
	 //   by-chance check a little or we risk throwing out good
	 //   translations
	 discount = 1.05 - (maxweight/(double)total_weight)/5.0 ;
	 }
      return (cooccur < discount * expected) ;
      }
   return false ;
}

//----------------------------------------------------------------------

static bool same_value(FrSymbol *word1, FrSymbol *word2)
{
   char *end ;
   double val1 = strtod(word1->symbolName(),&end) ;
   double val2 = strtod(word2->symbolName(),&end) ;
   return (val1 == val2) ;
}

//----------------------------------------------------------------------

static int compare_symbols(const FrObject *o1, const FrObject *o2)
{
   if ((size_t)o1 < (size_t)o2)
      return -1 ;
   else if ((size_t)o1 > (size_t)o2)
      return +1 ;
   else
      return 0 ;
}

//----------------------------------------------------------------------

static FrSymbol *make_word_pair(FrSymbol *sym1, FrSymbol *sym2)
{
   const char *word1 = sym1 ? sym1->symbolName() : "" ;
   const char *word2 = sym2 ? sym2->symbolName() : "" ;
   char pair[2*FrMAX_SYMBOLNAME_LEN+3] ;
   size_t len1 = strlen(word1) ;
   size_t len2 = strlen(word2) ;
   if (len1 + len2 + 1 <= FrMAX_SYMBOLNAME_LEN)
      {
      memcpy(pair,word1,len1) ;
      pair[len1] = ' ' ;
      memcpy(pair+len1+1,word2,len2) ;
      pair[len1+len2+1] = '\0' ;
      return FrSymbolTable::add(pair) ;
      }
   else
      return 0 ;
}

//----------------------------------------------------------------------

static size_t target_count(FrSymbol *word, FrSymHashTable *ht)
{
   const char *space = strchr(word->symbolName(),' ') ;
   size_t othercnt = 0 ;
   FrSymHashEntry *entry = ht->lookup(word) ;
   if (space)
      {
      othercnt = entry ? entry->getCount() : 0 ;
      entry = ht->lookup(FrSymbolTable::add(space+1)) ;
      if (entry)
	 othercnt = entry->getCount() ;
      char name[FrMAX_SYMBOLNAME_LEN+3] ;
      size_t len = space-word->symbolName() ;
      memcpy(name,word->symbolName(),len) ;
      name[len] = '\0' ;
      entry = ht->lookup(FrSymbolTable::add(name)) ;
      if (entry)
	 {
	 size_t cnt2 = entry->getCount() ;
	 if (cnt2 > othercnt)
	    othercnt = cnt2 ;
	 }
      }
   else if (entry)
      othercnt = entry->getCount() ;
   return othercnt ;
}

/************************************************************************/
/************************************************************************/

//----------------------------------------------------------------------
// input: 'words'  list of FrSymbol, which MUST be sorted by increasing
//		   address

DictList::DictList(const FrList *words, size_t max, size_t wt)
{
   m_length = words->listlength() ;
   if (max == 0)
      max = MIN_MAX_SIZE*FrARRAY_FRAG_SIZE ;
   if (max <= numItems())
      max_items = array_frags(numItems()) ;
   else
      max_items = array_frags(max) ;
   count = 1 ;
   weight = wt ;
   allocFragmentList() ;
   size_t frags = arrayLength() / FrARRAY_FRAG_SIZE ;
   for (size_t i = 0 ; i < frags ; i++)
      {
      FrArrayFrag *fragment = new FrArrayFrag ;
      for (size_t j = 0 ; j < FrARRAY_FRAG_SIZE ; j++)
	 {
	 new (&fragment->items[j]) FrArrayItem((uintptr_t)words->first(),
					       (FrObject*)wt) ;
	 words = words->rest() ;
	 }
      items[i] = fragment ;
      }
   size_t leftover = arrayLength() % FrARRAY_FRAG_SIZE ;
   if (leftover)
      {
      FrArrayFrag *fragment = new FrArrayFrag ;
      for (size_t j = 0 ; j < leftover ; j++)
	 {
	 new (&fragment->items[j]) FrArrayItem((uintptr_t)words->first(),
					       (FrObject*)wt) ;
	 words = words->rest() ;
	 }
      items[frags] = fragment ;
      }
   max_items *= FrARRAY_FRAG_SIZE ;
   return ;
}

//----------------------------------------------------------------------

DictList::DictList(size_t n, size_t max, size_t wt)
   : FrSparseArray(max)
{
   m_length = n ;
   count = 1 ;
   weight = wt ;
   return ;
}

//----------------------------------------------------------------------
// input: 'word'   FrSymbol

DictList::DictList(FrSymbol *word, size_t wt)
   : FrSparseArray(2)
{
   count = 1 ;
   weight = wt ;
   FrArrayFrag *fragment = new FrArrayFrag ;
   items[0] = fragment ;
   new (&fragment->items[0]) FrArrayItem((uintptr_t)word,(FrObject*)wt) ;
   m_length = 1 ;
   return ;
}

//----------------------------------------------------------------------

//DictList::~DictList()
//{
//   return ;
//}

//----------------------------------------------------------------------

void DictList::reserve(size_t N)
{
   size_t objs_per_block = FrBLOCKING_SIZE / allocator.objectSize() ;
   for (size_t i = allocator.objects_allocated() ;
	i < N ;
	i += objs_per_block)
      {
      allocator.preAllocate() ;
      }
   return ;
}

//----------------------------------------------------------------------

bool DictList::add(const FrList *counts)
{
   while (counts)
      {
      FrSymbol *word ;
      FrNumber *num ;
      if (counts->consp())
	 {
	 word = (FrSymbol*)counts->first() ;
	 counts = counts->rest() ;
	 if (!counts)
	   return false ;
	 num = (FrNumber*)counts->first() ;
	 counts = counts->rest() ;
	 }
      else
	 {
	 // we've hit the end of a dotted list...
	 word = makeSymbol(".") ;
	 num = (FrNumber*)counts ;
	 counts = 0 ;
	 }
      if (word && num)
	 newItem((uintptr_t)word,(FrObject*)num->intValue()) ;
      }
   return true ;			// successfully added
}

//----------------------------------------------------------------------

static void filter_fragment(FrArrayFrag *fragment, size_t fragsize,
			    DictList *result, FrSymHashTable *ht,
			    bool isnum, size_t weight,
			    FrSymbol *word, bool check_chance = true,
			    bool refining = false)
{
   double threshold, threslow, threshigh ;
   for (size_t i = 0 ; i < fragsize ; i++)
      {
      FrArrayItem *itm = &fragment->items[i] ;
      size_t co_occur = (size_t)itm->getValue() ;
      if (co_occur < dict_min_occurrences)
	 continue ;
      FrSymbol *otherword = (FrSymbol*)itm->getIndex() ;
      size_t cnt = ((co_occur > num_dict_thresholds)
		    ? num_dict_thresholds : co_occur) ;
      size_t othercnt = target_count(otherword,ht) ;
      if (!othercnt)
	 continue ;
      threshold = dict_thresholds[cnt] ;
      threslow = dict_thresholds_low[cnt] ;
      threshigh = dict_thresholds_high[cnt] ;
      if ((co_occur >= (size_t)(weight*threshold) &&
	   co_occur >= (size_t)(othercnt*threshold)) ||
	  (co_occur >= weight*threslow && co_occur >= othercnt*threshigh) ||
	  (co_occur >= weight*threshigh && co_occur >= othercnt*threslow) ||
	  (cognate_threshold < 1.0 &&
	   FrCognateScore(word,otherword,true) >= cognate_threshold))
	 {
	 // OK, user thresholds pass (or the words are sufficiently similar
	 //   lexically to be considered cognates), so add the definition
	 //   unless the co-occurrence rate is close to random chance or the
	 //   words are both numbers and their values differ
	 if ((!check_chance ||
	      !by_chance(weight,othercnt,co_occur,refining)) &&
	     (!isnum || !is_number(otherword) || same_value(word,otherword)))
	    {
	    result->addItem((uintptr_t)otherword,(FrObject*)co_occur,
			    FrArrAdd_INCREMENT) ;
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

double DictList::highestMCP(FrSymbol */*word*/, FrSymHashTable *ht,
			    size_t &corr_count) const
{
   size_t numfrags = numItems() / FrARRAY_FRAG_SIZE ;
   size_t leftover = numItems() % FrARRAY_FRAG_SIZE ;
   double max_mcp = 0.0 ;
   size_t corr = 0 ;
   for (size_t frag = 0 ; frag < numfrags ; frag++)
      {
      FrArrayFrag *fragment = items[frag] ;
      for (size_t i = 0 ; i < FrARRAY_FRAG_SIZE ; i++)
	 {
	 FrArrayItem *itm = &fragment->items[i] ;
	 FrSymbol *otherword = (FrSymbol*)itm->getIndex() ;
	 size_t co_occur = (size_t)itm->getValue() ;
	 double othercnt = target_count(otherword,ht) ;
	 double mcp = co_occur / (double)weight ;
	 double mcp2 = co_occur / othercnt ;
	 if (mcp2 < mcp)
	    mcp = mcp2 ;
	 if (mcp > max_mcp)
	    {
	    max_mcp = mcp ;
	    corr = co_occur ;
	    }
	 else if (mcp == max_mcp && co_occur > corr)
	    corr = co_occur ;
	 }
      }
   FrArrayFrag *fragment = items[numfrags] ;
   for (size_t i = 0 ; i < leftover ; i++)
      {
      FrArrayItem *itm = &fragment->items[i] ;
      FrSymbol *otherword = (FrSymbol*)itm->getIndex() ;
      size_t co_occur = (size_t)itm->getValue() ;
      double othercnt = target_count(otherword,ht) ;
      double mcp = co_occur / weight ;
      double mcp2 = co_occur / othercnt ;
      if (mcp2 < mcp)
	 mcp = mcp2 ;
      if (mcp > max_mcp)
	 {
	 max_mcp = mcp ;
	 corr = co_occur ;
	 }
      else if (mcp == max_mcp && co_occur > corr)
	 corr = co_occur ;
      }
   corr_count = corr ;
   return max_mcp ;
}

//----------------------------------------------------------------------

static void filter_by_mcp(FrArrayFrag *fragment, size_t fragsize, double mcp,
			  size_t min_corr, DictList *result,
			  FrSymHashTable *ht, double weight, bool verb=false)
{
   for (size_t i = 0 ; i < fragsize ; i++)
      {
      FrArrayItem *itm = &fragment->items[i] ;
      size_t co_occur = (size_t)itm->getValue() ;
      if (co_occur >= min_corr)
	 {
	 FrSymbol *otherword = (FrSymbol*)itm->getIndex() ;
	 double othercnt = target_count(otherword,ht) ;
	 double mcp1 = co_occur / weight ;
	 double mcp2 = co_occur / othercnt ;
	 // there is apparently an optimization error in GCC 3.x with -O9; the
	 //   following "if" is here exclusively to work around that bug
	 if (verb) cout << "mcp=" << mcp1 << endl ;
	 // now back to the real code...
	 if (mcp1 >= mcp && mcp2 >= mcp)
	    {
	    result->addItem((uintptr_t)otherword,(FrObject*)co_occur,
			    FrArrAdd_INCREMENT) ;
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void DictList::removeUncorrelated(FrSymbol *word, FrSymHashTable *ht,
				  Dictionary *dict, bool refining) const
{
   if (!ht)
      return ;
   // zero out the counts for any candidate translations which do not have
   // at least some 'threshold' level of correlation with the source word
   // also pack all the remaining words so there are no intervening gaps
   if (numItems() == 0 || (count < dict_min_occurrences && !makedict_force))
      return ;
   // we'll perform the packing by copying only the nonzero values into a
   //   temporary new DictList, to permit a second pass if needed
   DictList *result = new DictList ;
   if (!result)
      {
      FrNoMemory("while filtering collocations") ;
      return ;
      }
   result->setCount(wordCount()) ;
   result->setWeight(wordWeight()) ;
   size_t numfrags = arrayLength() / FrARRAY_FRAG_SIZE ;
   size_t leftover = arrayLength() % FrARRAY_FRAG_SIZE ;
   bool isnum = is_number(word) ;
   if (count <= 20 && (size_t)lookup((uintptr_t)word) >= weight)
      {
      // if the word has itself as a possible translation in every single
      // instance where it appears, remove all other correspondences
      // (this removes lots of spurious candidates)
      result->addItem((uintptr_t)word,(FrObject*)weight,FrArrAdd_INCREMENT) ;
      }
   else
      {
      for (size_t frag = 0 ; frag < numfrags ; frag++)
	 {
	 filter_fragment(items[frag],FrARRAY_FRAG_SIZE,result,ht,isnum,
			 weight,word,true,refining) ;
	 }
      filter_fragment(items[numfrags],leftover,result,ht,isnum,weight,
		      word,true,refining) ;
      if (result->arrayLength() == 0 && makedict_force != 0)
	 {
	 // we didn't find any acceptable correlations, but have been told to
	 //   produce something -- anything -- anyway
	 // first try, we just drop the check whether the correlation is merely
	 //   by chance
	 if ((makedict_force & 1) != 0)
	    {
	    for (size_t frag = 0 ; frag < numfrags ; frag++)
	       {
	       filter_fragment(items[frag],FrARRAY_FRAG_SIZE,result,ht,isnum,
			       weight,word,false) ;
	       }
	    filter_fragment(items[numfrags],leftover,result,ht,isnum,weight,
			    word,false) ;
	    }
	 // if still nothing, we then pick out the terms with highest mutual
	 //  conditional probability
	 if (result->arrayLength() == 0 && (makedict_force & 2) != 0)
	    {
	    size_t min_corr ;
	    double mcp = highestMCP(word,ht,min_corr) ;
	    for (size_t frag = 0 ; frag < numfrags ; frag++)
	       filter_by_mcp(items[frag],FrARRAY_FRAG_SIZE,mcp,min_corr,result,
			     ht,weight) ;
	    filter_by_mcp(items[numfrags],leftover,mcp,min_corr,result,ht,
			  weight) ;
	    }
	 }
      }
   if (result->arrayLength() > 0)
      {
      num_definitions++ ;
      result->defineWord(word,dict) ;
      }
   delete result ;
   return ;
}

//----------------------------------------------------------------------

static double norm_chisquare(size_t total, size_t freq1, size_t freq2,
			     size_t cooccur)
{
   //  N=total, |X|=freq1, |Y|=freq2, C[X,Y]=cooccur
   //
   //         N( (N-C[X,Y])C[X,Y] - |X||Y| )^2
   //      -----------------------------------
   //       |Y| * (N - |Y|) * |X| * (N - |X|)
   //
   // we normalize the above into the range 0..1 by omitting the N in the
   //   numerator
   double chi = ((double)(total-cooccur)*(double)cooccur -
		 (double)freq1*(double)freq2) ;
   double denom = (double)freq1 * (double)(total-freq1) *
                  (double)freq2 * (double)(total-freq2) ;
   // return a value between 0 and 1, rather than between 0 and N as for the
   // true chi^2 definition
   return chi * chi / denom ;
}

//----------------------------------------------------------------------

#if 0
static double G_score(size_t total, size_t freq1, size_t freq2,
		      size_t cooccur)
{
   double observed = ((double)cooccur) / (double)total ;
   double expected = ((double)freq1 * freq2) / ((double)total * total) ;
   return 2 * observed * ::log(observed / expected) ;
}
#endif

//----------------------------------------------------------------------

bool DictList::filterChiSquared(FrSymbol *word,FrSymHashTable *ht,
				  size_t total_wordcount)
{
   if (!ht)
      return false ;
   // zero out the counts for any candidate translations which do not have
   // at least some 'threshold' level of correlation with the source word
   // also pack all the remaining words so there are no intervening gaps
   if (count < dict_min_occurrences)
      return false ;
   size_t numitems = 0 ;
   size_t numfrags = numItems() / FrARRAY_FRAG_SIZE ;
   size_t leftover = numItems() % FrARRAY_FRAG_SIZE ;
   bool isnum = is_number(word) ;
   double threshold ;
   for (size_t frag = 0 ; frag < numfrags ; frag++)
      {
      FrArrayFrag *fragment = items[frag] ;
      for (size_t i = 0 ; i < FrARRAY_FRAG_SIZE ; i++)
	 {
	 FrArrayItem *itm = &fragment->items[i] ;
	 size_t co_occur = (size_t)itm->getValue() ;
	 if (co_occur < dict_min_occurrences)
	    continue ;
	 size_t cnt = co_occur ;
	 FrSymHashEntry *entry = ht->lookup((FrSymbol*)itm->getIndex()) ;
	 if (co_occur > num_dict_thresholds)
	    cnt = num_dict_thresholds ;
	 if (!entry)
	    continue ;
	 threshold = dict_thresholds[cnt] ;
	 size_t othercnt = entry->getCount() ;
	 double chi2 = norm_chisquare(total_wordcount,count,othercnt,co_occur);
	 if (chi2 >= threshold)
	    {
	    // OK, thresholds pass, so add the definition unless both source
	    // and target are numbers
	    if (!isnum || !is_number((FrSymbol*)itm->getIndex()))
	       {
	       // scale the score such that 10^6 == 1.0 (can't go higher since
	       // dict only stores 20 bits for count)
	       itm->setValue((FrObject*)((size_t)(1.0E6*chi2 + 0.5))) ;
	       item(numitems++) = *itm ;
	       }
	    }
	 }
      }
   FrArrayFrag *fragment = items[numfrags] ;
   for (size_t i = 0 ; i < leftover ; i++)
      {
      FrArrayItem *itm = &fragment->items[i] ;
      size_t co_occur = (size_t)itm->getValue() ;
      if (co_occur < dict_min_occurrences)
	 continue ;
      size_t cnt = co_occur ;
      FrSymHashEntry *entry = ht->lookup((FrSymbol*)itm->getIndex()) ;
      if (co_occur > num_dict_thresholds)
	 cnt = num_dict_thresholds ;
      if (!entry)
	 continue ;
      threshold = dict_thresholds[cnt] ;
      size_t othercnt = entry->getCount() ;
      double chi2 = norm_chisquare(total_wordcount,count,othercnt,co_occur) ;
      if (chi2 >= threshold)
	 {
	 // OK, thresholds pass, so add the definition unless both source
	 // and target are numbers
	 if (!isnum || !is_number((FrSymbol*)itm->getIndex()))
	    {
	    // scale the score such that 10^6 == 1.0 (can't go higher
	    // because dict only stores 20 bits for count)
	    itm->setValue((FrObject*)((size_t)(1.0E6*chi2 + 0.5))) ;
	    item(numitems++) = *itm ;
	    }
	 }
      }
   // remove any list fragments which are no longer needed
   size_t num_alloc = array_frags(numItems()) ;
   for (size_t j = array_frags(numitems) ; j < num_alloc ; j++)
      {
      delete items[j] ;
      }
   // update the count of definitions
   m_length = numitems ;
   return (numitems > 0) ;
}

//----------------------------------------------------------------------
// compare two items of our dictionary list, ordering them by decreasing
// count value, using alphabetical order as tie-breaker

static int compare_count(const FrObject *o1, const FrObject *o2)
{
   size_t count1 = ((FrNumber*)((FrList*)o1)->second())->intValue() ;
   size_t count2 = ((FrNumber*)((FrList*)o2)->second())->intValue() ;
   if (count1 > count2)
      return -1 ;
   else if (count1 < count2)
      return +1 ;
   else
      {
      const char *word1 = ((FrSymbol*)((FrList*)o1)->first())->symbolName() ;
      const char *word2 = ((FrSymbol*)((FrList*)o2)->first())->symbolName() ;
      return strcmp(word1,word2) ;
      }
}

//----------------------------------------------------------------------

bool DictList::defineWord(FrSymbol *word, Dictionary *dict) const
{
   if (!dict || numItems() == 0 || !items)
      return false ;
   FrList *wordlist = 0 ;
   for (size_t i = 0 ; i < arrayLength() ; i++)
      {
      FrArrayItem &itm = item(i) ;
      FrSymbol *xlatsym = (FrSymbol*)itm.getIndex() ;
      if (!xlatsym)
	 continue ;
      const char *xlatstr = xlatsym->symbolName() ;
      const char *space = strchr(xlatstr,' ') ;
      FrObject *xlat = xlatsym ;
      if (space)
	 {
	 char name[FrMAX_SYMBOLNAME_LEN+3] ;
	 size_t len = space - xlatstr ;
	 memcpy(name,xlatstr,len) ;
	 name[len] = '\0' ;
	 FrSymbol *word1 = FrSymbolTable::add(name) ;
	 FrSymbol *word2 = FrSymbolTable::add(space+1) ;
	 xlat = new FrList(word1,word2) ;
	 }
      pushlist(new FrList(xlat,new FrInteger((size_t)itm.getValue())),
	       wordlist) ;
      }
   wordlist = wordlist->sort(compare_count) ;
   dict->addDefinitionsCounted(word,wordlist,
			       weight > count ? weight : count) ;
   wordlist->freeObject() ;
   return true ;
}

//----------------------------------------------------------------------

bool DictList::write(FrSymbol *word, FILE *fp) const
{
   if (!fp)
      return false ;
   if (!Fr_fwrite_v(word, fp) || !Fr_fwrite_v(m_length, fp) ||
       !Fr_fwrite_v(count, fp) || !Fr_fwrite_v(weight, fp))
      return false ;
   size_t last_full = arrayLength() / FrARRAY_FRAG_SIZE ;
   for (size_t i = 0 ; i < last_full ; i++)
      {
      if (!Fr_fwrite(items[i], sizeof(FrArrayFrag), fp))
	 return false ;
      }
   size_t leftover = arrayLength() % FrARRAY_FRAG_SIZE ;
   if (leftover)
      {
      if (!Fr_fwrite(items[last_full], sizeof(FrArrayItem), leftover, fp))
	 return false ;
      }
   return true ;
}

//----------------------------------------------------------------------

DictList *DictList::read(FILE *fp, FrSymbol *&word)
{
   if (!fp)
      return 0 ;
   size_t nitems, dcount, dweight ;
   if (!Fr_fread_v(word, fp) || !Fr_fread_v(nitems, fp) ||
       !Fr_fread_v(dcount, fp) || !Fr_fread_v(dweight, fp))
      {
      return 0 ;
      }
   DictList *dlist = new DictList(nitems,nitems+50,dweight) ;
   if (!dlist)
      return 0 ;
   dlist->count = dcount ;
   dlist->weight = dweight ;
   bool failed = false ;
   size_t last_full = nitems / FrARRAY_FRAG_SIZE ;
   size_t leftover = nitems % FrARRAY_FRAG_SIZE ;
   FrArrayFrag *frag ;
   for (size_t i = 0 ; i < last_full ; i++)
      {
      frag = new FrArrayFrag ;
      if (frag && fread(frag, sizeof(FrArrayFrag), 1, fp) == 1)
	 dlist->items[i] = frag ;
      else
	 {
	 delete frag ;
	 for (size_t j = 0 ; j < i ; j++)
	    delete dlist->items[j] ;
	 dlist->m_length = 0 ;
	 failed = true ;
	 break ;
	 }
      }
   if (!failed && leftover)
      {
      frag = dlist->items[last_full] = new FrArrayFrag ;
      if (!frag || fread(frag, sizeof(FrArrayItem), leftover, fp) < leftover)
	 failed = true ;
      }
   if (failed)
      {
      delete dlist ;
      return 0 ;
      }
   return dlist ;
}

//----------------------------------------------------------------------

bool DictList::merge(const DictList *other)
{
   if (other && other->numItems() > 0)
      {
      size_t theseitems = numItems() ;
      size_t otheritems = other->numItems() ;
      FrArrayFrag **our_items = items ;
      size_t our_max = max_items ;
      m_length = 0 ;
      max_items = array_frags(theseitems+otheritems) ;
      allocFragmentList() ;
      max_items *= FrARRAY_FRAG_SIZE ;
      if (!items)
	 {
	 items = our_items ;
	 m_length = theseitems ;
	 max_items = our_max ;
	 return false ;
	 }
      count += other->count ;
      weight += other->weight ;
      register size_t j = 0 ;
      if (theseitems > 0)
	 {
	 FrArrayItem *our_item = &our_items[0]->items[0] ;
	 register size_t i = 0 ;
         register uintptr_t idx1 = our_item->getIndex() ;
	 register uintptr_t idx2 = other->item(0).getIndex() ;
         for ( ; ; )
	    {
   	    if (idx1 == idx2)
	       {
	       newItem(idx1,(FrObject*)((size_t)our_item->getValue() +
					(size_t)other->item(j).getValue())) ;
	       i++ ;
	       j++ ;
	       if (i >= theseitems || j >= otheritems)
		  break ;
	       our_item = &our_items[i/FrARRAY_FRAG_SIZE]
		 		->items[i%FrARRAY_FRAG_SIZE] ;
	       idx2 = other->item(j).getIndex() ;
	       idx1 = our_item->getIndex() ;
	       }
	    else if (idx1 < idx2)
	       {
	       newItem(our_item) ;
	       if (++i >= theseitems)
	          break ;
	       our_item = &our_items[i/FrARRAY_FRAG_SIZE]
		 		->items[i%FrARRAY_FRAG_SIZE] ;
	       idx1 = our_item->getIndex() ;
	       }
	    else // if (idx1 > idx2)
	       {
	       newItem(&other->item(j)) ;
	       if (++j >= otheritems)
		  break ;
	       idx2 = other->item(j).getIndex() ;
	       }
	    }
	 while (i < theseitems)
	    {
	    size_t fragnum = i/FrARRAY_FRAG_SIZE ;
 	    newItem(&our_items[fragnum]->items[i%FrARRAY_FRAG_SIZE]) ;
	    i++ ;
	    }
 	 }
      while (j < otheritems)
	 newItem(&other->item(j++)) ;
      for (size_t k = 0 ; k < array_frags(theseitems) ; k++)
	 delete our_items[k] ;
      if (our_max <= MIN_MAX_SIZE*FrARRAY_FRAG_SIZE)
	 delete (FrArrayFrag*)our_items ;
      else
	 FrFree(our_items) ;
      }
   return true ;
}

/************************************************************************/
/************************************************************************/

static bool erase_dictlist(const FrObject *s, va_list)
{
   set_dictlist((FrSymbol*)s,0); 
   return true ;
}

//----------------------------------------------------------------------

static void erase_dictlists(FrSymbolTable *symtab)
{
   if (symtab)
      symtab->iterate(erase_dictlist) ;
   return ;
}

//----------------------------------------------------------------------

void EbFreeDictionarySymbolTable()
{
   delete dict_symtab ;
   dict_symtab = 0 ;
   return ;
}

//----------------------------------------------------------------------

void EbInitDictionarySymbolTable()
{
   EbFreeDictionarySymbolTable() ;
   dict_symtab = new FrSymbolTable ;
   dict_symtab->expandTo(DICT_SYMTAB_SIZE) ;
   dict_symtab->setDeleteHook(erase_dictlists) ;
   return ;
}

//----------------------------------------------------------------------

FrSymbolTable *EbSelectDictionarySymbolTable()
{
   if (dict_symtab)
      return dict_symtab->select() ;
   else
      return FrSymbolTable::current() ;
}

//----------------------------------------------------------------------

FrSymbolTable *EbDictionarySymbolTable()
{
   return dict_symtab ;
}

/************************************************************************/
/************************************************************************/

//----------------------------------------------------------------------

static void reserve_memory()
{
   FramepaC_gc() ;
   // reduce future memory fragmentation by pre-allocating a bunch of
   //   object instances
   FrSymHashChain::reserve(1200000) ;
   DictList::reserve(250000) ;
   FrArrayFrag::reserve(500000) ;
   FrHashEntryObject::reserve(750000) ;
   FrList::reserve(250000) ;
   return ;
}

//----------------------------------------------------------------------

static void save_counts(FILE *fp, double threshold, FrSymbol *word,
			DictList *dictlist)
{
   size_t i ;
   bool found = false ;
   size_t mincount = (size_t)(threshold * dictlist->wordWeight()) ;
   for (i = 0 ; i < dictlist->numItems() ; i++)
      {
      if ((size_t)dictlist->item(i).getValue() >= mincount)
	 {
	 found = true ;
	 break ;
	 }
      }
   if (!found)
      return ;
   char name[FrMAX_SYMBOLNAME_LEN+3] ;
   word->print(name) ;
   fprintf(fp,"(%s %ld %ld",
	   name,(long)dictlist->wordCount(),(long)dictlist->wordWeight()) ;
   for (i = 0 ; i < dictlist->numItems() ; i++)
      {
      FrArrayItem *item = &dictlist->item(i) ;
      size_t count = (size_t)item->getValue() ;
      if (count >= mincount)
	 {
	 FrSymbol *w = (FrSymbol*)item->getIndex() ;
	 if (w)
	    {
	    w->print(name) ;
	    fprintf(fp," %s %ld",name,(long)count) ;
	    }
	 }
      }
   fputs(")\n",fp) ;
   return ;
}

//----------------------------------------------------------------------

static bool make_chisquared(const FrObject *w, va_list args)
{
   FrSymbol *word = (FrSymbol*)w ;
   DictList *dictlist = get_dictlist(word) ;
   if (dictlist)
      {
      FrVarArg(FILE *,fp) ;
      FrVarArg(double,save_threshold) ;
      if (fp)
	 save_counts(fp,save_threshold,word,dictlist) ;
      FrVarArg(FrSymHashTable *,targetwords) ;
      FrVarArg(Dictionary *,dict) ;
      FrVarArg(size_t,totalcount) ;
      if (dictlist->filterChiSquared(word,targetwords,totalcount))
	 {
	 num_definitions++ ;
	 dictlist->defineWord(word,dict) ;
	 }
      set_dictlist(word,0) ;
      }
   return true ;			// continue iterating
}

//----------------------------------------------------------------------

static bool make_dictionary_word(const FrObject *w, va_list args)
{
   FrSymbol *word = (FrSymbol*)w ;
   if (!word)
      return true ;
   DictList *dictlist = get_dictlist(word) ;
   if (dictlist)
      {
      FrVarArg(size_t*,tot_words) ;
      FrVarArg(FILE *,fp) ;
      FrVarArg(double,save_threshold) ;
      if (tot_words)
	 (*tot_words)++ ;
      if (fp)
	 save_counts(fp,save_threshold,word,dictlist) ;
      FrVarArg(FrSymHashTable *,targetwords) ;
      FrVarArg(Dictionary *,dict) ;
      FrVarArg2(bool,int,refining) ;
      dictlist->removeUncorrelated(word,targetwords,dict,refining) ;
      FrVarArg(ostream *,termfile) ;
      FrVarArg(size_t,HF_threshold) ;
      if (termfile)
	 {
	 if (dictlist->wordCount() >= HF_threshold)
	    *termfile << word << endl ;
	 }
      set_dictlist(word,0) ;
      }
   return true ;
}

//----------------------------------------------------------------------

static bool swap_out_word(const FrObject *w, va_list)
{
   FrSymbol *word = (FrSymbol*)w ;
   DictList *dictlist = get_dictlist(word) ;
   if (dictlist)
      {
      const char *name = word->symbolName() ;
      size_t which = name[0] ;
      if (which)
	 which = which ^ name[1] ;
      which = which ^ ((size_t)word >> 6) ;
      FILE *fp = swap_fp[which & SWAP_FP_MASK] ;
      if (!dictlist->write(word,fp))
	 return false ;
      set_dictlist(word,0) ;
      }
   return true ;
}

//----------------------------------------------------------------------

static bool swap_out_partial_dict(FrSymbolTable *symtab)
{
   if (!swapped_out_data)
      {
      for (size_t i = 0 ; i < MAX_SWAP_FPS ; i++)
	 {
	 char *end = strchr(dict_tempdir,'\0') ;
	 const char *slash = "" ;
	 if (end > dict_tempdir && end[-1] != '/'
#ifdef FrMSDOS_PATHNAMES
	     && end[-1] != '\\'
#endif /* FrMSDOS_PATHNAMES */
	    )
	    slash = "/" ;
	 char *filename = Fr_aprintf("%s%sdicttmp.%03lu",
				     dict_tempdir,slash,(unsigned long)i) ;
	 // create the temporary file
	 swap_fp[i] = fopen(filename,FrFOPEN_WRITE_MODE) ;
	 if (swap_fp[i])
	    fclose(swap_fp[i]) ;
	 // now re-open the temp file in read/write mode
	 swap_fp[i] = fopen(filename,FrFOPEN_UPDATE_MODE) ;
	 if (swap_fp[i])
	    {
	    fseek(swap_fp[i],0L,SEEK_SET) ;
	    swap_file[i] = filename ;
	    }
	 else
	    {
	    FrFree(filename) ;
	    return false ;
	    }
	 }
      }
   if (showmem)
      {
      cout << "\n#|\n" ;
      FrMemoryStats(cout) ;
      cout << "#|" << endl ;
      }
   if (symtab)
      if (!symtab->iterate(swap_out_word))
	 return false ;
   for (size_t j = 0 ; j < MAX_SWAP_FPS ; j++)
      if (swap_fp[j])
	 fflush(swap_fp[j]) ;
   reserve_memory() ;		 // reduce future memory fragmentation
   swapped_out_data = true ;
   return true ;
}

//----------------------------------------------------------------------

static bool combine_swap_files(FrSymbolTable *symtab,
			       FrSymHashTable *targetwords,
			       Dictionary *dict, ostream *termfile,
			       size_t HF_threshold, FILE *savefp = 0,
			       double save_threshold = 0.0,
			       size_t *tot_words = 0,
			       bool refining = false)
{
   if (showmem)
      FrMemoryStats(cerr) ;
   cout << "; combining spill files " << flush ;
   if (!symtab || !targetwords || !dict)
      return false ;
   size_t prev_meg = 0 ;
   for (size_t i = 0 ; i < MAX_SWAP_FPS ; i++)
      {
      FILE *fp = swap_fp[i] ;
      if (!fp)
	 continue ;
      reserve_memory() ;	 // reduce future memory fragmentation
      fseek(fp,0L,SEEK_SET) ;
      while (!feof(fp))
	 {
	 FrSymbol *word = 0 ;
	 DictList *dl = DictList::read(fp,word) ;
	 if (dl && word)
	    {
	    DictList *dictlist = get_dictlist(word) ;
	    if (dictlist)
	       {
	       if (!dictlist->merge(dl))
		  cout << "merge error!" << endl ;
	       delete dl ;
	       }
	    else
	       set_dictlist(word,dl) ;
	    }
	 else
	    delete dl ;
	 size_t meg = (ftell(fp) / (1024*1024)) ;
	 if (meg != prev_meg)
	    {
	    cout << '-' << flush ;
	    prev_meg = meg ;
	    }
	 }
      if (compute_mutual_info && mutual_info_via_chisquared)
	 {
	 if (!symtab->iterate(make_chisquared,savefp,save_threshold,
			      targetwords,dict,total_wordcount))
	    {
	    cout << " error!" << endl ;
	    return false ;
	    }

	 }
      else if (!symtab->iterate(make_dictionary_word,&tot_words,savefp,
				save_threshold,targetwords,dict,refining,
				termfile,HF_threshold))
	 {
	 cout << " error!" << endl ;
	 return false ;
	 }
      if (showmem)
	 {
	 cout << "\n#|" ;
	 FrMemoryStats(cout) ;
	 cout << "#|" << flush ;
	 }
      else
	 cout << "*" << flush ;
      fclose(fp) ;
      swap_fp[i] = 0 ;
      Fr_unlink(swap_file[i]) ;
      FramepaC_gc() ;
      }
   cout << " done" << endl ;
   symtab->setDeleteHook(0) ;
   return true ;
}

//----------------------------------------------------------------------

static bool make_dictionary(FrSymbolTable *symtab,
			    FrSymHashTable *targetwords,
			    Dictionary *dict, ostream *termfile = 0,
			    FILE *savefp = 0, double save_threshold = 0.0,
			    bool refining = false,
			    bool run_quietly = false)
{
   if (!symtab || !dict)
      return false ;
   num_definitions = 0 ;
   bool success = true ;
   FrSymbolTable *old_symtab = symtab->select() ;
   size_t HF_threshold = (size_t)(dict_HF_threshold * sentences_processed) ;
   if (termfile)
      {
      *termfile << "; high-frequency source-language terms in the corpus\n"
	           "(" << endl ;
      }
   size_t tot_words = 0 ;
   if (swapped_out_data)
      {
      // swap out any partial chunk, then read back each of the individual
      // swap files and compute definitions
      swap_out_partial_dict(symtab) ;
      FramepaC_gc() ;
      success = combine_swap_files(symtab,targetwords, dict,termfile,
				   HF_threshold,savefp,save_threshold,
				   &tot_words,refining) ;
      if (success)
	 {
	 symtab->setDeleteHook(0) ;
	 if (dict->dictFileName() != 0 && !dict->save())
	    success = false ;
	 }
      }
   else if (compute_mutual_info && mutual_info_via_chisquared)
      {
      if (symtab->iterate(make_chisquared,savefp,save_threshold,
			  targetwords,dict,total_wordcount))
	 {
	 symtab->setDeleteHook(0) ;
	 if (dict->dictFileName() != 0 && !dict->save())
	    success = false ;
	 }
      }
   else if (symtab->iterate(make_dictionary_word,&tot_words,savefp,
			    save_threshold,targetwords,dict,refining,termfile,
			    HF_threshold))
      {
      symtab->setDeleteHook(0) ;
      if (dict->dictFileName() != 0 && !dict->save())
	 success = false ;
      }
   else
      success = false ;
   if (termfile)
      *termfile << ")" << endl ;
   if (success)
      {
      if (!run_quietly)
	 {
	 if (tot_words)
	    cout << "; new definitions added for " << num_definitions << " of "
		 << tot_words << " words" << endl ;
	 else
	    cout << "; new definitions added for " << num_definitions
		 << " words" << endl ;
	 }
      }
   else
      cout << "; error updating dictionary from correlation lists!" << endl ;
   old_symtab->select() ;
   return success ;
}

//----------------------------------------------------------------------

static void adjust_thresholds()
{
   if (num_dict_thresholds == 0)
      {
      if (dict_correspondence_threshold_high < dict_correspondence_threshold)
	 dict_correspondence_threshold_high = dict_correspondence_threshold ;
      if (dict_correspondence_threshold_low > dict_correspondence_threshold)
	 dict_correspondence_threshold_low = dict_correspondence_threshold ;
      dict_thresholds_low = &dict_correspondence_threshold_low ;
      dict_thresholds = &dict_correspondence_threshold ;
      dict_thresholds_high = &dict_correspondence_threshold_high ;
      return ;
      }
   dict_min_occurrences = num_dict_thresholds ;
   size_t j = 0 ;
   for (size_t i = 1 ; i <= num_dict_thresholds ; i++)
      {
      if (dict_thresholds_high[i] > 0.0)
	 j = i ;
      else
	 {
	 // copy the most recent nonzero thresholds into current position
	 dict_thresholds_low[i] = dict_thresholds_low[j] ;
	 dict_thresholds[i] = dict_thresholds[j] ;
	 dict_thresholds_high[i] = dict_thresholds_high[j] ;
	 }
      if (i < dict_min_occurrences && dict_thresholds_low[i] <= 1.0)
	 dict_min_occurrences = i ;
      }
   if (dict_thresholds[num_dict_thresholds] <= 1.0)
      dict_correspondence_threshold = dict_thresholds[num_dict_thresholds] ;
   dict_correspondence_threshold_low=dict_thresholds_low[num_dict_thresholds] ;
   dict_correspondence_threshold_high =
      dict_thresholds_high[num_dict_thresholds] ;
   return ;
}

//----------------------------------------------------------------------

static bool start_building_dictionary(const char *tempdir,
					size_t lines_each_chunk,
					const FrList *charmapping,
					const FrList *sstopwords,
					const FrList *tstopwords)
{
   if (Initialized)
      return false ;
   delete dict_target ;
   free_object(dict_sstoplist) ;
   free_object(dict_tstoplist) ;
   EbInitDictionarySymbolTable() ;
   dict_target = new FrSymHashTable(DICT_HASHTAB_SIZE) ;
   if (tempdir)
      dict_tempdir = tempdir ;
   else
      dict_tempdir = "." ;
   if (sstopwords)
      dict_sstoplist = FrCvtWordlist2Symbollist(sstopwords,char_encoding) ;
   else
      dict_sstoplist = 0 ;
   if (tstopwords)
      dict_tstoplist = FrCvtWordlist2Symbollist(tstopwords,char_encoding) ;
   else
      dict_tstoplist = 0 ;
   if (charmapping)
      dict_charmap = FrMakeCharacterMap(charmapping) ;
   else
      dict_charmap = 0 ;
   if (lines_each_chunk > 1000)
      dict_lines_per_chunk = lines_per_chunk ;
   else if (compute_mutual_info)
      dict_lines_per_chunk = DEFAULT_LINES_PER_MI_CHUNK ;
   else
      dict_lines_per_chunk = DEFAULT_LINES_PER_CHUNK ;
   adjust_thresholds() ;
   total_wordcount = 0 ;
   total_weight = 0.0 ;
   Initialized = true ;
   return true ;
}

//----------------------------------------------------------------------

static FrList *remove_unprintable(FrList *words)
{
   FrSymbol *null = makeSymbol("") ;
   FrList *result = 0 ;
   FrList **end = &result ;
   while (words)
      {
      FrSymbol *word = (FrSymbol*)poplist(words) ;
      if (word != null)
	 result->pushlistend(word,end) ;
      }
   *end = 0 ;				// terminate result list
   return result ;
}

//----------------------------------------------------------------------

static FrList *remove_duplicates(FrList *words, const FrList *stoplist)
{
   if (!stoplist && !count_once_only)
      return words ;
   FrList *result = 0 ;
   FrList **end = &result ;
   while (words)
      {
      FrSymbol *word = (FrSymbol*)poplist(words) ;
      if (!(count_once_only && result->member(word) != 0) &&
	  stoplist->member(word) == 0)
	 {
	 result->pushlistend(word,end) ;
	 *end = 0 ;
	 }
      }
   *end = 0 ;				// terminate result list
   return result ;
}

//----------------------------------------------------------------------

static void compute_biased_range(size_t pos, size_t len, size_t otherlen,
				 size_t &range_start, size_t &range_end)
{

   double otherpos = (double)otherlen * (double)pos / (double)len ;
   size_t midpoint = (size_t)(otherpos + 0.5) ;
   size_t range_size = (size_t)((otherlen * dict_bias_range) + 0.5) ;
   if (range_size < 1)
      range_size = 1 ;
   if (range_size < EBMT_word_order_similarity)
      range_size = EBMT_word_order_similarity ;
   if (midpoint < range_size)
      range_start = 0 ;
   else
      range_start = midpoint - range_size ;
   if (midpoint + range_size >= otherlen)
      range_end = otherlen - 1 ;
   else
      range_end = midpoint + range_size ;
   return ;
}

//----------------------------------------------------------------------

static bool build_biased_dictionary(const FrList *swords,
				      size_t sourcelen,
				      const FrList *twords,
				      size_t targetlen,
				      FrSymHashTable *dict_target,
				      size_t extra_weight)
{
   size_t range_start ;
   size_t range_end ;
   size_t total_weight = extra_weight + dict_bias_high ;
   for (size_t spos = 0 ; swords ; swords = swords->rest(), spos++)
      {
      FrSymbol *sword = (FrSymbol*)swords->first() ;
      if (!sword)
	 continue ;
      compute_biased_range(spos,sourcelen,targetlen,range_start,range_end) ;
      add_cooccur_counts(sword,0,total_weight) ;
      DictList *dictlist = get_dictlist(sword) ;
      size_t tpos = 0 ;
      for (const FrList *tw = twords ; tw ; tw = tw->rest(), tpos++)
	 {
	 FrSymbol *tword = (FrSymbol*)tw->first() ;
	 if (tword)
	    {
	    size_t weight ;
	    if (tpos >= range_start && tpos <= range_end)
	       weight = extra_weight + dict_bias_high ;
	    else
	       weight = extra_weight + dict_bias_low ;
	    if (weight > 0)
	       dictlist->addItem((uintptr_t)tword,(FrObject*)weight,
				 FrArrAdd_INCREMENT) ;
	    }
	 }
      }
   for (size_t tpos = 0 ; twords ; twords = twords->rest(), tpos++)
      {
      FrSymbol *tword = (FrSymbol*)twords->first() ;
      if (tword)
	 incr_dict_count(dict_target,tword,total_weight) ;
      }
   return true ;
}

//----------------------------------------------------------------------

static BiTextMap *make_bitext(const FrList *swords, const FrList *twords,
			      const FrList *alignment,
			      FrCasemapTable number_charmap = 0,
			      const EbAlignConstraints *constraints = 0)
{
   if (alignment)
      {
      // override the internal correspondence table construction
      return new BiTextMap(swords,twords,alignment,1,1.0,0,reverse_languages) ;
      }
   return EbMakeBitext(swords,twords,0,number_charmap,constraints) ;
}

//----------------------------------------------------------------------

static void update_mi_table(const FrArray &words, size_t wordnum,size_t window,
			    const FrList *stoplist)
{
   if (words.arrayLength() == 0)
      return ;
   FrSymbol *word = (FrSymbol*)words[wordnum] ;
   if (stoplist->member(word))
      return ;
   size_t start ;
   if (mutual_info_oneway)
      start = wordnum+1 ;
   else if (wordnum > window)
      start = wordnum - window ;
   else
      start = 0 ;
   size_t end = wordnum + window ;
   if (end >= words.arrayLength())
      end = words.arrayLength()-1 ;
   FrList *neighbors = 0 ;
   for (size_t i = start ; i <= end ; i++)
      {
      FrSymbol *neighbor = (FrSymbol*)words[i] ;
      // if the context word hasn't been seen yet, and is not a self-trigger,
      // add it to the list of co-occurring words
      if (neighbor && neighbor != word && !neighbors->member(neighbor) &&
	  !stoplist->member(neighbor))
	 pushlist(neighbor,neighbors) ;
      }
   neighbors = neighbors->sort(compare_symbols) ;
   add_cooccur_counts(word,neighbors,1) ;
   free_object(neighbors) ;
   incr_dict_count(dict_target,word) ;
   return ;
}

//----------------------------------------------------------------------

static FrList *copy_stoplist(const FrList *stoplist)
{
   FrList *copy = 0 ;
   FrList **end = &copy ;
   for ( ; stoplist ; stoplist = stoplist->rest())
      {
      FrObject *stop = stoplist->first() ;
      if (stop)
	 {
	 if (stop->symbolp())
	    copy->pushlistend(makeSymbol(((FrSymbol*)stop)->symbolName()),end);
	 else
	    copy->pushlistend(stop->deepcopy(),end) ;
	 }
      }
   *end = 0 ;				// terminate copied list
   return copy ;
}

//----------------------------------------------------------------------

static bool save_word_count(FrSymHashEntry *entry, va_list args)
{
   FrVarArg(FILE *,fp) ;
   if (fp && entry->getName())
      {
      char word[FrMAX_SYMBOLNAME_LEN+3] ;
      entry->getName()->print(word) ;
      fprintf(fp,"%s %ld\n",word,(long)entry->getUserData()) ;
      }
   return true ;			// continue iterating
}

//----------------------------------------------------------------------

static bool filter_correspondences(FrSymbolTable *symtab,
				   FrSymHashTable *target, Dictionary *dict,
				   const char *HF_filename,
				   const char *save_filename,
				   double threshold, bool refining,
				   bool run_quietly = false)
{
   ostream *termfile = 0 ;
   if (HF_filename)
      {
      termfile = new ofstream(HF_filename) ;
      if (!termfile || !termfile->good())
	 {
	 FrWarning("unable to open high-frequency terms file for writing!") ;
	 delete termfile ;
	 termfile = 0 ;
	 }
      }
   FILE *savefp = 0 ;
   if (save_filename && *save_filename)
      {
      savefp = fopen(save_filename,"w") ;
      if (savefp)
	 {
	 if (dict_target)
	    {
	    fprintf(savefp,"%ld\n",(long)dict_target->currentSize()) ;
	    dict_target->doHashEntries(save_word_count,savefp) ;
	    fprintf(savefp,"\n") ;
	    }
	 }
      else
	 FrWarning("unable to open counts save file!  Counts will not be saved.") ;
      }
   if (dict_correspondence_threshold_low > dict_correspondence_threshold_high)
      {
      double tmp = dict_correspondence_threshold_low ;
      dict_correspondence_threshold_low = dict_correspondence_threshold_high ;
      dict_correspondence_threshold_high = tmp ;
      }
   if (dict_correspondence_threshold_low > dict_correspondence_threshold)
      dict_correspondence_threshold_low = dict_correspondence_threshold ;
   if (dict_correspondence_threshold_high < dict_correspondence_threshold)
      dict_correspondence_threshold_high = dict_correspondence_threshold ;
   bool success = make_dictionary(symtab,target,dict,termfile,savefp,
				  threshold,refining,run_quietly) ;
   delete termfile ;
   if (savefp)
      {
      fprintf(savefp,"; *EOF*\n") ;
      fflush(savefp) ;
      fclose(savefp) ;
      }
   return success ;
}

//----------------------------------------------------------------------

static bool build_mi_table(FILE *fp, ostream *out)
{
   FrSymbolTable *sym_t = EbSelectDictionarySymbolTable() ;
   size_t first_word = 0 ;
   FrArray words(0) ;
   FrList *stoplist = copy_stoplist(dict_sstoplist) ;
   FrSymbol *separator = makeSymbol(DOC_SEPARATOR) ;
   bool end_window = false ;
   do {
      char *line, *line2, *tags ;
      bool status = read_EBMT_entry(fp,dict_charmap,line,line2,tags,
				    dict_keep_case,source_regex_list,
				    target_regex_list,abbrevs_list) ;
      FrFree(tags) ;
      FrList *currwords = 0 ;
      FrFree(line2) ;
      if (status)
	 {
	 line2 = FrStripNamedEntityData(line,named_entity_spec) ;
	 FrFree(line) ;
	 line = line2 ;
	 currwords = EbStripMorph(FrCvtSentence2Wordlist(line),char_encoding) ;
	 currwords = remove_unprintable(currwords) ;
	 }
      FrFree(line) ;
      if (currwords && !currwords->rest() && currwords->first() == separator)
	 {
	 end_window = true ;
	 currwords->eraseList(false) ;
	 }
      else if (currwords)
	 {
	 sentences_processed++ ;
	 words.insert(currwords,words.arrayLength(),false) ;
	 currwords->eraseList(false) ;
	 }
      else
	 end_window = true ;
      size_t length = words.arrayLength() ;
      if (length > BATCHSIZE*2*mutual_info_window ||
	  (end_window && length > 0))
	 {
	 size_t last_word ;
	 if (end_window)
	    last_word = length-1 ;
	 else // if (length > 2*mutual_info_window)
	    last_word = length-1-mutual_info_window ;
	 for (size_t i = first_word ; i <= last_word ; i++)
	    {
	    update_mi_table(words,i,mutual_info_window,stoplist) ;
	    if (++total_wordcount % 10000 == 0 && out)
	       *out << '.' << flush ;
	    if ((total_wordcount % (10*dict_lines_per_chunk)) == 0)
	       {
	       swap_out_partial_dict(EbDictionarySymbolTable()) ;
	       if (out) *out << ':' << flush ;
	       }
	    }
	 if (end_window)
	    {
	    words.elide(0,length-1) ;
	    end_window = false ;
	    first_word = 0 ;
	    }
	 else
	    {
	    words.elide(0,last_word-mutual_info_window) ;
	    first_word = mutual_info_window ;
	    }
	 }
      } while (!feof(fp)) ;
   free_object(stoplist) ;
   sym_t->select() ;
   return true ;
}

//----------------------------------------------------------------------

bool EbBuildMutualInfoTable(FILE *fp, ostream *out, bool finish,
			    double threshold, size_t minfreq,
			    bool chi_squared)
{
   if (!Initialized)
      {
      EbInitDictionarySymbolTable() ;
      dict_target = new FrSymHashTable(DICT_HASHTAB_SIZE) ;
      if (!DcActiveDictionary())
	 DcSetActiveDictionary(new Dictionary) ;
      Initialized = true ;
      }
   bool old_compute_MI = compute_mutual_info ;
   bool old_window = mutual_info_window ;
   bool old_oneway = mutual_info_oneway ;
   bool old_minfreq = dict_min_occurrences ;
   bool old_chisquared = mutual_info_via_chisquared ;
   compute_mutual_info = true ;
   mutual_info_window = 1 ;
   mutual_info_oneway = true ;
   mutual_info_via_chisquared = chi_squared ;
   dict_min_occurrences = (size_t)(minfreq * threshold) ;
   dict_lines_per_chunk = DEFAULT_LINES_PER_MI_CHUNK ;
   bool success = build_mi_table(fp,out) ;
   if (success && finish)
      {
      double old_thresh_low = dict_correspondence_threshold_low ;
      double old_thresh_mid = dict_correspondence_threshold ;
      double old_thresh_hi = dict_correspondence_threshold_high ;
      dict_correspondence_threshold_low = threshold ;
      dict_correspondence_threshold = threshold ;
      dict_correspondence_threshold_high = threshold ;
      dict_thresholds_low = &dict_correspondence_threshold_low ;
      dict_thresholds = &dict_correspondence_threshold ;
      dict_thresholds_high = &dict_correspondence_threshold_high ;
      num_dict_thresholds = 0 ;
      Dictionary *dict = DcActiveDictionary() ;
      success = filter_correspondences(EbDictionarySymbolTable(),
				       dict_target,dict,0,0,
				       threshold,false,true) ;
      EbFreeDictionarySymbolTable() ;
      DcSetActiveDictionary(0) ;
      delete dict ;
      delete dict_target ;
      dict_correspondence_threshold_low = old_thresh_low ;
      dict_correspondence_threshold = old_thresh_mid ;
      dict_correspondence_threshold_high = old_thresh_hi ;
      Initialized = false ;
      }
   dict_min_occurrences = old_minfreq ;
   mutual_info_window = old_window ;
   mutual_info_oneway = old_oneway ;
   mutual_info_via_chisquared = old_chisquared ;
   compute_mutual_info = old_compute_MI ;
   return success ;
}

//----------------------------------------------------------------------

Dictionary *EbGetMutualInfoTable()
{
   Dictionary *dict = DcActiveDictionary() ;
   DcSetActiveDictionary(0) ;
   return dict ;
}

//----------------------------------------------------------------------

static void accumulate_align_stats(const BiTextMap *bitext,
				   EbAlignConstraints *constraints)
{
   assertq(bitext != 0) ;
   size_t i ;
   // check the source->target direction
   for (i = 0 ; i < bitext->sourceLength() ; i++)
      {
      size_t numcorr = bitext->numTargetCorrespondences(i) ;
      if (numcorr == 0)
	 continue ;
      bool unambig(numcorr == 1) ;
      FrSymbol *word(bitext->sourceWord(i)) ;
      // check relationship with left neighbor
      if (i > 0 && bitext->numTargetCorrespondences(i-1) > 0)
	 {
	 bool rightbound(false), rightreverse(false) ;
	 size_t neighbor_unambig = bitext->numTargetCorrespondences(i-1) == 1 ;
	 if (unambig)
	    {
	    size_t corr = bitext->firstTargetCorrespondence(i) ;
	    if (corr > 1 && bitext->wordsCorrespond(i-1,corr-1))
	       rightbound = true ;
	    }
	 else if (neighbor_unambig)
	    {
	    // check whether one of the possible translations of the current
	    //   word is immediately to the right of the sole translation of
	    //   its left neighbor
	    size_t corr = bitext->firstTargetCorrespondence(i-1) ;
	    if (corr+1 < bitext->targetLength() &&
		bitext->wordsCorrespond(i,corr+1))
	       rightbound = true ;
	    }
	 if ((size_t)bitext->firstTargetCorrespondence(i-1) >
	     bitext->lastTargetCorrespondence(i))
	    {
	    rightreverse = true ;
	    }
	 if (unambig || neighbor_unambig || rightbound || rightreverse)
	    constraints->addSourceStats(word,true,rightbound,rightreverse) ;
	 }
      // check relationship with right neighbor
      if (i+1 < bitext->sourceLength() &&
	  bitext->numTargetCorrespondences(i+1) > 0)
	 {
	 bool leftbound(false), leftreverse(false) ;
	 size_t neighbor_unambig = bitext->numTargetCorrespondences(i+1) == 1 ;
	 if (unambig)
	    {
	    size_t corr = bitext->firstTargetCorrespondence(i) ;
	    if (corr+1 < bitext->targetLength() &&
		bitext->wordsCorrespond(i+1,corr+1))
	       leftbound = true ;
	    }
	 else if (neighbor_unambig)
	    {
	    // check whether one of the possible translations of the current
	    //   word is immediately to the left of the sole translation of
	    //   its right neighbor
	    size_t corr = bitext->firstTargetCorrespondence(i+1) ;
	    if (corr > 1 && bitext->wordsCorrespond(i,corr-1))
	       leftbound = true ;
	    }
	 if ((size_t)bitext->firstTargetCorrespondence(i) >
	     bitext->lastTargetCorrespondence(i+1))
	    {
	    leftreverse = true ;
	    }
	 if (unambig || neighbor_unambig || leftbound || leftreverse)
	    constraints->addSourceStats(word,false,leftbound,leftreverse) ;
	 }
      constraints->addStats(word,true,unambig) ;
      }
   // now, check the target->source direction
#if 0
   for (i = 0 ; i < bitext->targetLength() ; i++)
      {
      size_t numcorr = bitext->numSourceCorrespondences(i) ;
      if (numcorr == 0)
	 continue ;
      bool unambig(numcorr == 1) ;
      FrSymbol *word(bitext->targetWord(i)) ;
      if (i > 0 && bitext->numSourceCorrespondences(i-1) > 0)
	 {
	 bool rightbound(false), rightreverse(false) ;
	 size_t neighbor_unambig = bitext->numSourceCorrespondences(i-1) == 1 ;
	 if (unambig || neighbor_unambig)
	    constraints->addTargetStats(word,true,rightbound,rightreverse) ;
	 }
      if (i+1 < bitext->targetLength() &&
	  bitext->numSourceCorrespondences(i+1) > 0)
	 {
	 bool leftbound(false), leftreverse(false) ;
	 size_t neighbor_unambig = bitext->numSourceCorrespondences(i+1) == 1 ;

	 if (unambig || neighbor_unambig)
	    constraints->addTargetStats(word,false,leftbound,leftreverse) ;
	 }
      constraints->addStats(word,false,unambig) ;
      }
#endif /* 0 */
   return ;
}

//----------------------------------------------------------------------

static void build_unbiased_dict(const FrList *swords, FrList *&twords,
				size_t weight)
{
   if (!swords || !twords)
      return ;
   for (const FrList *sw = swords ; sw ; sw = sw->rest())
      {
      FrSymbol *sword = (FrSymbol*)sw->first() ;
      add_cooccur_counts(sword,twords,weight) ;
      }
   while (twords)
      {
      FrSymbol *tword = (FrSymbol*)poplist(twords) ;
      incr_dict_count(dict_target,tword,(size_t)weight) ;
      }
   return ;
}

//----------------------------------------------------------------------

static void build_refined_dict(const FrList *swords, size_t slength,
			       FrList *&twords, size_t tlength,
			       const char *sline, const char *tline,
			       size_t weight, const FrList *alignment,
			       EbAlignConstraints *constraints,
			       bool infer_align_constraints,
			       FrCasemapTable number_charmap)
{
   if (swords && twords)
      {
      BiTextMap *ctable = make_bitext(swords,twords,alignment,number_charmap,
				      constraints) ;
      if (infer_align_constraints && ctable)
	 accumulate_align_stats(ctable,constraints) ;
      const FrList *sw = swords ;
      FrHashTable already_seen ;
      already_seen.expandTo(10*slength) ;
      for (size_t i = 0 ; i < slength ; i++, sw = sw->rest())
	 {
	 FrSymbol *sword = (FrSymbol*)sw->first() ;
	 const FrList *tw = twords ;
	 bool have_corr = false ;
	 for (size_t j = 0 ; j < tlength ; j++, tw = tw->rest())
	    {
	    if (!ctable->wordsCorrespond(i,j))
	       continue ;
	    have_corr = true ;
	    FrSymbol *tword = (FrSymbol*)tw->first() ;
	    if (learn_dict_phrases && j+1 < tlength &&
		ctable->wordsCorrespond(i,j+1))
	       {
	       bool corr_1 = ctable->numSourceCorrespondences(j) == 1 ;
	       bool corr_2 = ctable->numSourceCorrespondences(j+1) == 1 ;
	       bool is_phrase = (corr_1 && corr_2) ;
	       if (!is_phrase || double_count_phrases)
		  add_new_cooccur_count(sword,tword,weight,already_seen) ;
	       if (is_phrase)
		  {
		  // translate one word into two
		  FrSymbol *tword2 = (FrSymbol*)tw->second() ;
		  if (tword2)
		     {
		     FrSymbol *pair = make_word_pair(tword,tword2) ;
		     if (pair)
			{
			if (add_new_cooccur_count(sword,pair,weight,
						  already_seen))
			   incr_dict_count(dict_target,pair,weight) ;
			}
		     }
		  if (!double_count_phrases)
		     {
		     j++ ;		// skip next target word, and
		     tw = tw->rest() ;	//   don't count individual words
		     continue ;
		     }
		  }
	       }
	    else
	       add_new_cooccur_count(sword,tword,weight,already_seen) ;
	    }
	 add_new_cooccur_count(sword,0,have_corr ? weight : weight/2,
			       already_seen) ;
	 }
      delete ctable ;
      while (twords)
	 {
	 FrSymbol *tword = (FrSymbol*)poplist(twords) ;
	 // only count one instance of each distinct word in this sentence
	 if (!twords->member(tword,::equal))
	    incr_dict_count(dict_target,tword,weight) ;
	 }
      }
   else
      {
      FrWarningVA("both source and target lines must be non-empty!\n"
		  "\tsource = %70.70s\n"
		  "\ttarget = %70.70s",sline,tline) ;
      }
   return ;
}

//----------------------------------------------------------------------

static bool build_dictionary(FILE *fp,
			       ostream *out, const FrList *HF_terms,
			       FrCasemapTable number_charmap = 0,
			       EbAlignConstraints *constraints = 0,
			       bool infer_align_constraints = false)
{
   if (!fp)
      return false ;
   if (compute_mutual_info)
      return build_mi_table(fp, out) ;
   FrSymbolTable *sym_t = EbSelectDictionarySymbolTable() ;
   static size_t count = 0 ;
   const Dictionary *refine_dict = constraints ? constraints->dictionary() : 0;
   FrList *sstoplist = 0 ;
   FrList *tstoplist = 0 ;
   if (!refine_dict && dict_bias_high == 1 && dict_bias_low == 1)
      {
      tstoplist = copy_stoplist(dict_tstoplist) ;
      sstoplist = copy_stoplist(dict_sstoplist) ;
      }
   FrCharEncoding enc = (dict_keep_case ? FrChEnc_RawOctets : char_encoding) ;
   do {
      char *sline, *tline, *tags ;
      bool status = read_EBMT_entry(fp,dict_charmap,sline,tline,tags,true,
				      source_regex_list,target_regex_list,
				      abbrevs_list) ;
      if (!status)
	 {
	 FrFree(sline) ;
	 FrFree(tline) ;
	 FrFree(tags) ;
	 break ;
	 }
      char *tmpline = FrStripNamedEntityData(sline,named_entity_spec) ;
      FrFree(sline) ;
      sline = tmpline ;
      FrList *swords = EbStripMorph(FrCvtSentence2Wordlist(sline),
				    char_encoding) ;
      tmpline = FrStripNamedEntityData(tline,named_entity_spec) ;
      FrFree(tline) ;
      tline = tmpline ;
      FrList *twords = EbStripMorph(FrCvtSentence2Wordlist(tline),enc) ;
      FrList *alignment = EbExtractAlignTag(tags) ;
      if (!alignment)
	 {
	 swords = remove_unprintable(swords) ;
	 twords = remove_unprintable(twords) ;
	 swords = remove_duplicates(swords,sstoplist) ;
	 }
      if (HF_terms)
	 {
	 // if we are processing the high-frequency terms only, skip the line
	 // unless it contains either one or two of the high-frequency terms
	 FrList *terms = swords->intersection(HF_terms) ;
	 free_object(swords) ;
	 if (!terms || terms->listlength() > 2)
	    {
	    free_object(terms) ;
	    free_object(twords) ;
	    continue ;
	    }
	 // OK, good high-frequency sentence, but we only want to process
	 // the high-frequency source words....
	 swords = terms ;
	 }
      if (!refine_dict)
	 {
	 twords = remove_duplicates(twords,tstoplist) ;
	 if (twords)
	    twords = twords->sort(compare_symbols) ;
	 }
      size_t slength = swords->simplelistlength() ;
      size_t tlength = twords->simplelistlength() ;
      size_t weight = swords && twords
		        ? (2*dict_max_weight) / (slength * tlength)
			: dict_max_weight ;
      if (weight == 0)
	 weight = 1 ;
      uint32_t freq, total_freq ;
      if (EbExtractFreqTag(tags,freq,total_freq))
	 {
	 if (total_freq > freq)
	    freq = total_freq ;
	 weight *= freq ;
	 }
      FrFree(tags) ;
      total_weight += weight ;
      if (refine_dict)
	 build_refined_dict(swords,slength,twords,tlength,sline,tline,weight,
			    alignment,constraints,infer_align_constraints,
			    number_charmap) ;
      else if (dict_bias_high == dict_bias_low)
	 build_unbiased_dict(swords,twords,weight) ;
      else
	 build_biased_dictionary(swords,slength,twords,tlength,dict_target,
				 weight-1) ;
      free_object(alignment) ;
      FrFree(sline) ;
      FrFree(tline) ;
      free_object(swords) ;
      free_object(twords) ;
      sentences_processed++ ;
      if (++count % 1000 == 0 && out)
	 *out << '.' << flush ;
      if ((count % dict_lines_per_chunk) == 0)
	 {
	 swap_out_partial_dict(EbDictionarySymbolTable()) ;
	 if (out) *out << ':' << flush ;
	 }
      } while (!feof(fp)) ;
   free_object(sstoplist) ;
   free_object(tstoplist) ;
   sym_t->select() ;
   return true ;
}


//----------------------------------------------------------------------

static bool build_dictionary(const char *filename, ostream *out,
			       const FrList *HF_terms,
			       FrCasemapTable number_charmap = 0,
			       EbAlignConstraints *constraints = 0,
			       bool infer_align_constraints = false)
{
   if (!filename || !*filename)
      return false ;
   FILE *fp = fopen(filename,"r") ;
   if (!fp)
      {
      (*out) << " (unable to open file " << filename << ")" << flush ;
      return false ;
      }
   bool result = build_dictionary(fp,out,HF_terms,number_charmap,
				    constraints,infer_align_constraints) ;
   fclose(fp) ;
   return result ;
}

//----------------------------------------------------------------------

static bool finish_building_dictionary(Dictionary *dict,
				       const char *HF_filename,
				       const char *save_filename,
				       bool refining)
{
   if (!Initialized || !dict)
      return false ;
   if (!filter_correspondences(EbDictionarySymbolTable(),dict_target,dict,
			       HF_filename,save_filename,dict_store_threshold,
			       refining))
      return false ;
   if (export_dict_requested)
      dict->exportDict(dict_export_file) ;
   EbFreeDictionarySymbolTable() ;
   delete dict_target ;
   dict_target = 0 ;
   free_object(dict_sstoplist) ;
   dict_sstoplist = 0 ;
   free_object(dict_tstoplist) ;
   dict_tstoplist = 0 ;
   FrDestroyCharacterMap(dict_charmap) ;
   dict_charmap = 0 ;
   EbFreeDictionarySymbolTable() ;
   Initialized = false ;
   return true ;
}

//----------------------------------------------------------------------

static bool load_target_counts(istream &counts)
{
   FrObject *obj ;
   counts >> obj ;
   counts.ignore() ;		// skip rest of line, including NL
   size_t num_targets ;
   if (obj && obj->numberp())
      num_targets = (size_t)obj->intValue() ;
   else
      return false ;
   for (size_t i = 0 ; i < num_targets ; i++)
      {
      char line[FrMAX_SYMBOLNAME_LEN+50] ;
      line[0] = '\0' ;
      counts.getline(line,sizeof(line)) ;
      if (counts.eof() || line[0] == '\0')
	 return false ;
      char *l = line ;
      FrObject *word = string_to_FrObject(l) ;
      FrObject *num = string_to_FrObject(l) ;
      if (word && word->symbolp() && num && num->numberp())
	 {
	 size_t count = (size_t)num->intValue() ;
	 dict_target->add((FrSymbol*)word,count) ;
	 total_wordcount += count ;
	 }
      }
   return true ;
}

//----------------------------------------------------------------------

void init_dict_thresholds(size_t max = 0)
{
   if (num_dict_thresholds > 0)
      return ;				// already initialized....
   num_dict_thresholds = max > NUM_THRESHOLDS ? max : NUM_THRESHOLDS ;
   dict_thresholds_low = FrNewN(double,num_dict_thresholds+1) ;
   dict_thresholds = FrNewN(double,num_dict_thresholds+1) ;
   dict_thresholds_high = FrNewN(double,num_dict_thresholds+1) ;
   if (dict_thresholds_low && dict_thresholds && dict_thresholds_high)
      {
      dict_thresholds[0] = dict_thresholds_low[0] =
	 dict_thresholds_high[0] = 2.0 ;
      for (size_t i = 1 ; i < num_dict_thresholds ; i++)
	 {
	 double t = (2.0 / i) ;
	 if (max == 0 && t < dict_correspondence_threshold)
	    t = dict_correspondence_threshold ;
	 dict_thresholds[i] = t ;
	 dict_thresholds_low[i] = t ;
	 dict_thresholds_high[i] = t ;
	 }
      }
   else
      {
      FrFree(dict_thresholds_low) ; dict_thresholds_low = 0 ;
      FrFree(dict_thresholds) ; dict_thresholds = 0 ;
      FrFree(dict_thresholds_high) ; dict_thresholds_high = 0 ;
      num_dict_thresholds = 0 ;
      }
}

//----------------------------------------------------------------------

#undef swap
#define swap(type,x,y) { type tmp = x ; x = y ; y = tmp ; }

bool load_dict_thresholds(const char *filename)
{
   if (!filename || !*filename)
      {
      init_dict_thresholds() ;
      return false ;
      }
   istream *in = new ifstream(filename) ;
   if (!in || !in->good())
      {
      init_dict_thresholds() ;
      return false ;
      }
   bool cleared = false ;
   FrObject *obj ;
   *in >> obj ;
   size_t limit = obj ? obj->intValue() : NUM_THRESHOLDS ;
   init_dict_thresholds(limit) ;
   while (!in->eof())
      {
      *in >> obj ;
      if (obj == makeSymbol("*EOF*"))
	 break ;
      if (obj->consp())
	 {
	 FrList *spec = (FrList*)obj ;
	 obj = poplist(spec) ;
	 size_t count = obj ? obj->intValue() : 0 ;
	 free_object(obj) ;
	 size_t len = spec->listlength() ;
	 if (count > num_dict_thresholds)
	    count = num_dict_thresholds ;
	 double thresh, threshlo, threshhi ;
	 if (len == 1)
	    {
	    obj = spec->first() ;
	    thresh = obj ? obj->floatValue() : 0.0 ;
	    threshlo = threshhi = thresh ;
	    }
	 else if (len == 3)
	    {
	    obj = spec->first() ;
	    thresh = obj ? obj->floatValue() : 0.0 ;
	    obj = spec->second() ;
	    threshlo = obj ? obj->floatValue() : 0.0 ;
	    obj = spec->third() ;
	    threshhi = obj ? obj->floatValue() : 0.0 ;
	    if (thresh < threshlo)
	       swap(double,thresh,threshlo) ;
	    if (threshlo < threshhi)
	       swap(double,threshlo,threshhi) ;
	    if (threshhi < thresh)
	       swap(double,threshhi,thresh) ;
	    }
	 else
	    {
	    free_object(spec) ;
	    continue ;
	    }
	 if (threshlo > 0.0 && count > 0)
	    {
	    if (!cleared)
	       {
	       for (size_t i = 1 ; i <= num_dict_thresholds ; i++)
		  {
		  dict_thresholds_low[i] = 0.0 ;
		  dict_thresholds[i] = 0.0 ;
		  dict_thresholds_high[i] = 0.0 ;
		  }
	       cout << "; using thresholds in " << filename << endl ;
	       cleared = true ;
	       }
	    dict_thresholds_low[count] = threshlo ;
	    dict_thresholds[count] = thresh ;
	    dict_thresholds_high[count] = threshhi ;
	    }
	 free_object(spec) ;
	 }
      }
   delete in ;
   return true ;
}

//----------------------------------------------------------------------

static bool filter_counts(istream &counts, Dictionary *dict = 0,
			    bool refining = false)
{
   FrSymbol *symEOF = makeSymbol("*EOF*") ;
   if (!dict)
      dict = DcActiveDictionary() ;
   while (!counts.eof())
      {
      FrObject *obj ;
      counts >> obj ;
      if (obj && obj->consp())
	 {
	 FrList *count_list = (FrList*)obj ;
	 size_t listlen = count_list->listlength() ;
	 if (listlen % 2 == 1)
	    {
	    FrSymbol *word = (FrSymbol*)poplist(count_list) ;
	    FrNumber *count = (FrNumber*)poplist(count_list) ;
	    FrNumber *weight = (FrNumber*)poplist(count_list) ;
	    DictList *dictlist = new DictList((size_t)0,listlen/2,
					      weight->intValue()) ;
	    dictlist->setCount(count->intValue()) ;
	    dictlist->add(count_list) ;
	    if (mutual_info_via_chisquared)
	       {
	       if (dictlist->filterChiSquared(word,dict_target,
					      total_wordcount))
		  {
		  dictlist->defineWord(word,dict) ;
		  num_definitions++ ;
		  }
	       }
	    else
	       {
	       dictlist->removeUncorrelated(word,dict_target,dict,refining) ;
	       }
	    delete dictlist ;
	    }
	 free_object(count_list) ;
	 }
      else if (obj == symEOF)
	 break ;
      else
	 {
	 free_object(obj) ;
	 return false ;
	 }
      }
   return true ;
}

//----------------------------------------------------------------------

static bool filter_dictionary_counts(const char *count_filename,
				     Dictionary *dict, bool refining)
{
   if (!count_filename || !*count_filename)
      return false ;			// can't filter if no filename given
   istream *counts = new ifstream(count_filename) ;
   if (!counts || !counts->good())
      return false ;
   EbInitDictionarySymbolTable() ;
   dict_target = new FrSymHashTable(DICT_HASHTAB_SIZE) ;
   bool success = false ;
   FrSymbolTable *sym_t = EbSelectDictionarySymbolTable() ;
   adjust_thresholds() ;
   if (load_target_counts(*counts))
      success = filter_counts(*counts,0,refining) ;
   if (success)
      {
      cout << "; new definitions added for " << num_definitions << " words"
	    << endl ;
      if (!dict)
	 dict = DcActiveDictionary() ;
      if (!dict || (dict->dictFileName() != 0 && !dict->save()))
	 success = false ;
      }
   sym_t->select() ;
   EbFreeDictionarySymbolTable() ;
   delete dict_target ;
   dict_target = 0 ;
   delete counts ;
   return success ;			// successful
}

//----------------------------------------------------------------------

int create_dictionary(const EBMTConfig *ebmt_config,
		      bool create_HF_dictionary_requested,
		      const char *refine_to_dict,
		      const char *align_save_filename,
		      bool usestdin, istream &filelist, ostream &out)
{
   reserve_memory() ;		 // reduce future memory fragmentation
   const char *dir = first_corpus_dir(ebmt_config->corpus_directory) ;
   if (!start_building_dictionary(dir,lines_per_chunk,
				  ebmt_config->source_charmap,
				  ebmt_config->dict_sstoplist,
				  ebmt_config->dict_tstoplist))
      return EXIT_FAILURE ;
   FrSymbolTable *symtab = EbSelectDictionarySymbolTable() ;
   if (!DcInitializeDictionary(ebmt_config->dictionary_file))
      {
      symtab->select() ;
      return EXIT_FAILURE ;
      }
   if (align_save_filename && !*align_save_filename)
      align_save_filename = 0 ;
   bool infer_align_constraints = (align_save_filename != 0) ;
   Dictionary *dict = DcActiveDictionary() ;
   Dictionary *orig_dict = 0 ;
   if (refine_to_dict && !dict_loading_counts)
      {
      orig_dict = DcActiveDictionary() ;
      if (!*refine_to_dict)
	 refine_to_dict = DEFAULT_DICT_NAME ;
      dict = Dictionary::open(refine_to_dict) ;
      }
   FrList *HF_terms = 0 ;
   if (create_HF_dictionary_requested && !dict_extracting_HF &&
       dict_HF_filename && *dict_HF_filename)
      {
      // load the list of high-frequency terms to be targeted
      istream *termfile = new ifstream(dict_HF_filename) ;
      if (!termfile || !termfile->good())
	 {
	 out << "Error opening high-frequency terms file!" << endl ;
	 return EXIT_FAILURE ;
	 }
      FrObject *terms ;
      *termfile >> terms ;
      if (terms && terms->consp())
	 HF_terms = (FrList*)terms ;
      else if (terms)
	 {
	 FrWarning("invalid data in high-frequency terms file!") ;
	 terms->freeObject() ;
	 }
      delete termfile ;
      }
   EbAlignConstraints *constraints ;
   if (ebmt_config->constraints_filename)
      constraints = new EbAlignConstraints(orig_dict,
					   ebmt_config->constraints_filename) ;
   else
      constraints = new EbAlignConstraints(orig_dict,
					   ebmt_config->tight_bound_left,
					   ebmt_config->tight_bound_right) ;
   out << ready_bang << endl ;
   FrCasemapTable number_charmap = 0 ;
   if (ebmt_config->number_charmap)
      number_charmap = FrMakeCharacterMap(ebmt_config->number_charmap) ;
   if (dict_loading_counts)
      {
      if (!dict_load_filename || !*dict_load_filename)
	 {
	 out << "Error: did not specify file from which to load counts!"
	     << endl ;
	 return EXIT_FAILURE ;
	 }
      out << "; loading co-occurrence counts from " << dict_load_filename
	  << endl ;
      if (filter_dictionary_counts(dict_load_filename,dict,
				   refine_to_dict != 0))
	 {
	 if (export_dict_requested)
	    DcExportDictionary(dict_export_file,dict) ;
	 DcShutdownDictionary() ;
	 return EXIT_SUCCESS ;
	 }
      else
	 {
	 out << "Error processing co-occurrence counts!" << endl ;
	 return EXIT_FAILURE ;
	 }
      }
   else if (usestdin)
      {
      out << "; processing stdin " << flush ;
      if (build_dictionary(stdin,&out,HF_terms,number_charmap,constraints,
			   infer_align_constraints))
	 out << str_Ok << endl ;
      else
	 out << error_bang << endl ;
      }
   else
      while (!filelist.eof())
	 {
	 char line[MAX_CORPUS_LINE] ;
	 line[0] = '\0' ;
	 filelist.getline(line,sizeof(line)) ;
	 char *lineptr = FrTrimWhitespace(line) ;
	 if (*lineptr == ';' || *lineptr == '#')
	    {
	    // it's a comment line, so skip it
	    }
	 else if (*lineptr)
	    {
	    out << "; processing " << lineptr << ' ' << flush ;
	    if (build_dictionary(lineptr,&out,HF_terms,number_charmap,
				 constraints,infer_align_constraints))
	       out << "\n; " << str_Ok << endl ;
	    else
	       out << "\n; " << error_bang << endl ;
	    }
	 if (verbose && showmem)
	    {
	    out << "#|\n" ;
	    FrMemoryStats(out) ;
	    out << "|#" << endl ;
	    }
	 }
   FrDestroyCharacterMap(number_charmap) ;
   if (align_save_filename)
      {
      constraints->inferConstraints(infer_min_frequency,
				    infer_max_contradictions) ;
      constraints->save(align_save_filename) ;
      }
   delete constraints ;
   const char *HF_name = 0 ;
   if (create_HF_dictionary_requested && dict_extracting_HF)
      HF_name = dict_HF_filename ;
   const char *count_file = 0 ;
   if (dict_storing_counts && dict_store_filename && *dict_store_filename)
      count_file = dict_store_filename ;
   if (!finish_building_dictionary(dict,HF_name,count_file,
				   constraints && constraints->dictionary()))
      {
      out << error_bang << endl ;
      symtab->select() ;
      if (refine_to_dict)
	 dict->close() ;
      return EXIT_FAILURE ;
      }
   if (refine_to_dict)
      dict->close() ;
   dict = 0 ;
   if (!DcShutdownDictionary())
      {
      out << error_bang << endl ;
      symtab->select();
      return EXIT_FAILURE ;
      }
   symtab->select();
   out << done_bang << endl ;
   return EXIT_SUCCESS ;
}


// end of file ebmkdict.cpp //
