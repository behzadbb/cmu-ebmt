/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.95							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebindex.h	EBMT corpus index				*/
/*  LastEdit: 09apr10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __EBINDEX_H_INCLUDED
#define __EBINDEX_H_INCLUDED

#include "FramepaC.h"
#include "ebsetup.h"
#include "ebsource.h"

#ifdef FrSTRICT_CPLUSPLUS
# include <cstdio>
#else
# include <stdio.h>
#endif /* FrSTRICT_CPLUSPLUS */

#if defined(__GNUC__)
#  pragma interface
#endif

//#define EbINDEX_INCLUDES_LOCATION

/************************************************************************/
/*	Manifest Constants						*/
/************************************************************************/

// split index entry values to allow 3 billion words in 1 billion lines
#define INDEX_EOR_VALUE  (3UL*1073741824UL)

#define ORIGIN_WEIGHT_SCALE 1000000000.0

// don't bother checking N-grams longer than this for AutoPhrase
#define AUTO_MAXLEN	8

#define EbINDEX_NO_SUCH_RECORD ((size_t)~0)

// specify how many distinct document ranks to use for subsampling matches
#define NUM_DOC_RANK_BITS	7
#define NUM_DOC_RANKS 		(1<<NUM_DOC_RANK_BITS)

#define NUM_CONTEXT_RANK_BITS	3
#define NUM_CONTEXT_RANKS	(1<<NUM_CONTEXT_RANK_BITS)

//#define NUM_LOCAL_RANK_BITS	2
#define NUM_LOCAL_RANK_BITS	0
#define NUM_LOCAL_RANKS		(1<<NUM_LOCAL_RANK_BITS)

/************************************************************************/
/************************************************************************/

#define INDEX_SIGNATURE "EBMT Index File"
#define INDEX_INFO_SIGNATURE "EBMT Example Information"

#define INDEX_FILE_NAME "corpus.idx"
#define INDEX_TAGGED_NAME "corpus.tag"
#define INDEX_UPDATES_NAME "corpus.upd"
#define INDEX_STRUCT_NAME "corpus.str"
#define INDEX_PHRASES_NAME "corpus.phr"
#define INDEX_SVOCAB_NAME "corpus.voc"
#define INDEX_TVOCAB_NAME "corpus.trg"
#define INDEX_INFO_NAME "corpus.inf"
#define INDEX_LOCATIONS_NAME "corpus.loc"
#define TOKEN_FILE_NAME "corpus.tok"
#define ORIGINS_FILE_NAME "corpus.src"
#define OVERRIDES_FILE_NAME "corpus.met"

#define MAX_WORD_LENGTH 255

#define INDEX_FILE_VERSION 1

/*
   Corpus File Format:
	(binary) Target Sentence 0
	(binary) metadata 0
	(binary) Target Sentence 1
	(binary) metadata 1
	...
	(binary) Target Sentence 262143
	(binary) metadata 262143
	(*EOF*)

   Metadata record:
        BYTE   data type
	       00h uncompressed
	       01h RLE2
	       02h (X,Y) pairs with 8 bit scores, Y stored in 8 bits
	       03h (X,Y) pairs with 8 bit scores, Y stored in 16 bits [NYI]
	       10h tags
	       11h score
	       12h frequency
	       13h phrasal alignments (v1)
	       14h phrasal alignments (v2)
	       15h origin file
	       16h left context
	       17h right context
	       20h general morphological data
	       21h part-of-speech data
	       22h person and number
	       23h gender and aspect
      N BYTEs  meta data body

   Meta Data (Type 2):
	BYTE	00h (data type)
      N BYTEs	SL*TL bytes of uncompressed table entries
	BYTE	FFh (end-of-data marker)
   Meta Data (Type 1):
        BYTE	01h (data type)
      N BYTEs	run-length encoded possible-correspondences table
		00h-EFh represent N bytes of 00h followed by a byte with
		 the current nonzero value, F0h indicates 240 bytes of 00h,
		 F1h plus the following byte set the nonzero value (reset
		 after the next run), and F2h-FEh set the value to
		 N-F0h (also reset after next run)
        BYTE	FFh (end-of-data marker)
      After decompression, data represents an MxN array of bytes, where each
        byte is interpreted as a bitset of possible correspondences beginning
	at that position and extending for <bitnumber> additional target words.
	M = number of source words, N = number of target words,
	array[i][j] = correspondence from source[i] to target[j]
   Meta Data (Type 2):
	BYTE	03h (data type)
     2N BYTEs	(X,Y) pairs: one byte for SL word offset followed by a
     		  second byte for TL word offset; neither may be FFh
	BYTE	FFh (end-of-data marker)
   Meta Data (Type 10h):
        BYTE	10h (data type)
	...

*/

/* format of metadata-overrides file
	LONG	offset of index
	LONG	number of entries in index (K)
	...	metadata records, each
		LONG	number of bytes following
		N BYTEs	metadata
	K LONGs	offsets of metadata records or 0 if not present (no override)
	EOF
*/

#define LINES_PER_SUBFILE (512*1024UL)

#define SUBFILE_NUMBER(x)    	((x)/LINES_PER_SUBFILE)
#define LINE_IN_SUBFILE(x) 	((x)%LINES_PER_SUBFILE)

/************************************************************************/
/*	Forward Declarations						*/
/************************************************************************/

class EBMTCandidate ;
class EBMTCorpus ;
class EBMTIndex ;
class EbAlignConstraints ;
class EbCorpusMetaInfo ;
class EbDataSource ;
class BiTextMap ;
class Dictionary ;
class Tokenizer ;

/************************************************************************/
/************************************************************************/

enum EbIndexSpec
   { EbIndex_None, EbIndex_Struct, EbIndex_Main, EbIndex_Tagged,
     EbIndex_Updates } ;
   // the order of indices above is used to rank them by priority, with the
   //   last-listed having highest priority when comparing candidate
   //   translations

/************************************************************************/
/************************************************************************/

class EbBWTIndex : public FrBWTIndex
   {
   private:
      uint32_t *wordIDs ;		// the actual index contents
      uint32_t *m_startloc ;		// index location for start of recs
      FrWordIDList *idlist ;		// temp storage for updates
      size_t m_idcount ;		// number of word IDs in index
      uint32_t m_numrecs ;		// number of entries in m_startloc
      uint32_t m_SOR_id ;		// wordID of start-of-record marker
      bool m_changed ;
   private: // methods
      void init() ;
   public:
      EbBWTIndex() { init() ; }
      EbBWTIndex(const char *filename, bool memory_mapped = true,
		 bool touch_memory = false) ;
      EbBWTIndex(uint32_t *items, size_t num_items,
		 FrBWTEORHandling hnd = FrBWT_MergeEOR, uint32_t eor = ~0,
		 ostream *progress = 0) ;
      virtual ~EbBWTIndex() ;
      virtual const char *signatureString() const ;

      // accessors
      bool changed() const { return m_changed ; }
      bool haveIndexLocations() const { return m_numrecs > 0 ; }
      uint32_t indexLocation(size_t line_num) const ;
      uint32_t recordStartID() const { return m_SOR_id ; }
      FrBWTLocation recordStarts() const ;
      FrList *retrieveSource(size_t location, FrVocabulary *vocab,
			     size_t maxlen = ~0) const ;

      // manipulators
      bool loadIDs() ;
      bool freeIndexLocations() ;
      bool setIndexLocations(size_t numrecs) ;  // crawl thru index
      bool setIndexLocations(size_t numrecs, const LONGbuffer *locations) ;
      void setRecordStartID(uint32_t id) { m_SOR_id = id ; }
      bool addWord(FrObject *) ;
      bool finishLine(size_t line_num, size_t eor_value = ~0) ;
      bool write(const char *filename, bool keep_IDs = false,
		   EBMTIndex *index = 0, bool compress = false) ;
      bool writeIDs(FILE *fp) const ;
      bool dump(FILE *fp, const FrVocabulary *vocab,
		  bool print_recnum = false, EBMTIndex * = 0) const ;
   } ;

/************************************************************************/
/************************************************************************/

#define EbEx_LENGTHMASK		0x03FF
#define EbEx_FLAGSMASK		0xFC00
#define EbEx_HAVETOKEN		0x8000
#define EbEx_HAVEFREQ		0x4000
#define EbEx_HAVESCORE		0x2000
//				0x1000
#define EbEx_EXACTMATCH		0x0800
#define EbEx_HAVESTRUCT		0x0400  // note: currently not actually used

typedef unsigned char SHORTbuffer[2] ;

class EbExampleInfo
   {
   private:
      LONGbuffer m_corpusoffset ;
#ifdef EbINDEX_INCLUDES_LOCATION
      LONGbuffer m_indexloc ;
#endif /* EbINDEX_INCLUDES_LOCATION */
      SHORTbuffer m_length_flags ;
   public:
      void *operator new(size_t, void *where) { return where ; }
      EbExampleInfo() {}
      EbExampleInfo(uint32_t corpoffset, size_t length, size_t flags) ;
      EbExampleInfo(uint32_t corpoffset, uint32_t indexloc,
		    size_t length, size_t flags) ;
      ~EbExampleInfo() {}

      // manipulators
      bool write(FILE *fp) const ;
      void setCorpusOffset(uint32_t off) ;
      void setIndexLoc(uint32_t loc) ;
      void setLength(size_t len) ;
      void setFlags(size_t enable, size_t disable = 0) ;

      // accessors
      uint32_t corpusOffset() const { return FrLoadLong(m_corpusoffset) ; }
#ifdef EbINDEX_INCLUDES_LOCATION
      uint32_t indexLocation() const { return FrLoadLong(m_indexloc) ; }
#endif /* EbINDEX_INCLUDES_LOCATION */
      size_t length() const
	 { return FrLoadShort(m_length_flags) & EbEx_LENGTHMASK ; }
      size_t flags() const
	 { return FrLoadShort(m_length_flags) & EbEx_FLAGSMASK ; }
      bool haveFreq() const
	 { return (FrLoadShort(m_length_flags) & EbEx_HAVEFREQ) != 0 ; }
      bool haveScore() const
	 { return (FrLoadShort(m_length_flags) & EbEx_HAVESCORE) != 0 ; }
      bool isTaggedPhrase() const
	    { return (FrLoadShort(m_length_flags) & EbEx_HAVETOKEN) != 0 ; }
      bool haveStructure() const
	 { return (FrLoadShort(m_length_flags) & EbEx_HAVESTRUCT) != 0 ; }
      bool requireExactMatch() const
	    { return (FrLoadShort(m_length_flags)&EbEx_EXACTMATCH) != 0 ; }
   } ;

/************************************************************************/
/************************************************************************/

#if NUM_DOC_RANKS < 256
   typedef uint8_t EbDocRank ;
#else
   typedef uint16_t EbDocRank ;
#endif

class EBMTIndex
   {
   private:
      EbDataSourceList m_origins ;	// where did examples come from?
      EbBWTIndex *m_index ;		// the main index of the source half
      EbBWTIndex *m_tagged ;		// the index of tagged examples
      EbBWTIndex *m_updates ;		// the index of online updates
      EbBWTIndex *m_struct ;		// structural-match (mostly PoS) index
      FrVocabulary *m_svocab ;		// mapping from SL word to word ID
      FrVocabulary *m_tvocab ;		// mapping from TL word to word ID
      EbExampleInfo *m_info ;		// per-example information
      char *m_locations ;		// per-word location information
      EBMTCorpus *corpus ;		// the corpus for which this is index
      Tokenizer *tokenizer ;
      EbDocRank *m_exampleranks ;	// per-sentencepair document ranks
      double m_deforiginweight ;
      FILE *last_fp ;			// cached subfile handle
      FILE *override_fp ;		// handle for file w/ extra metadata
      char *base_dir ;			// root of corpus db's directory tree
      char *svocab_file ;		// file mapping words to word IDs
      char *tvocab_file ;		// file mapping words to word IDs
      char *info_file ;			// filename for per-example info file
      char *locations_file ;		// filename for per-word locations file
      char *index_file ;		// filename for main index file
      char *tagged_file ;		// filename for index of tagged entries
      char *updates_file ;		// filename for updates index
      char *struct_file ;		// filename for structural index
      char *token_file ;		// filename for token list
      char *origins_file ;		// filename for example-origins file
      char *overrides_file ;		// filename for metadata overrides
      char *source_language ;
      char *target_language ;
      char *current_origin ;		// where are the examples from?
      char *m_metadata_overrides ;	// offsets of extra metadata records
      char *m_override_data ;		// buffer holding extra metadata recs
      FrCasemapTable character_map ;	// for source character massaging
      FrCasemapTable number_charmap ;	// for translating numeric strings
      size_t m_num_overrides ;		// how many overrides available?
      uint32_t m_override_index ;	// ofs of m_metadata_overrides in file
      FrSymbolTable *symtab ;		// contains mapping from word to index
      FrHashTable *origin_ht ;		// mapping from FrString to weight
      FrFileMapping *m_infomap ;	// for memory-mapped example-info file
      FrFileMapping *m_locmap ;		// for memory-mapped per-word loc file
      FrFileMapping **subfile_maps ;	// for memory-mapped corpus subfiles
      FrFileMapping *m_overridemap ;	// for memory-mapped metadata file
      FrString *m_SOR_token ;		// start-of-record token
      uint32_t num_pairs ;		// # of sentence pairs in corpus
      uint32_t token_file_entries ;	// # of pairs from tokens file
      size_t info_alloc ;		// # of entries allocated for m_info
      size_t highest_file ;		// last corpus file indexed
      size_t last_filenumber ;		// file# corresp. to 'last_fp'
      bool m_modified ;
      bool m_readonly ;
      bool m_good ;
      bool m_indexing ;
   private: // methods
      EbBWTIndex *openIndex(EbBWTIndex *&idx, const char *filename,
			    bool force_create) ;
      EbBWTIndex *openIndex(EbIndexSpec which, bool force_create = false) ;
      void indexSentence(const FrList *wordlist, size_t linenum,
			 EbIndexSpec which_index = EbIndex_Main,
			 bool force_create = false) ;
      void storeLineInfo(size_t linenum, size_t corpus_offset,
			 size_t line_length) ;
      void unmemmap() ;
      void overrideOffset(size_t linenum, uint32_t newoffset) ;
   public: // methods
      EBMTIndex(const char *corpusdir, bool force_creation = false,
                const char *sourcelang = 0, const char *targetlang = 0,
		bool *was_created = 0) ;

      ~EBMTIndex() ;
      void setCorpus(EBMTCorpus *corp) { corpus = corp ; }
      void setCharMapping(const FrList *map, const FrList *numeric_map) ;
      void setSourceLanguage(const char *language) ;
      void setTargetLanguage(const char *language) ;
      void setOrigin(const char *orig) ;
      void setOriginWeights(const FrList *weights) ;
      void clearOriginWeights() ;
      void setExampleRanks(size_t num_ranks) ;
      void setTokenFileEntries(uint32_t tok) { token_file_entries = tok ; }
      void incrTokenFileEntries() { token_file_entries++ ; }

      bool loadTokens(const char *filename) ;
      bool loadLocations(bool memory_mapped = true, bool create = true) ;
      bool writeLocations(const char *filename) ;
      void freeLocations() ;
      bool loadExampleInfo(bool memory_mapped = true) ;
      bool unmapExampleInfo() ;
      void freeExampleInfo() ;
      bool augmentDictionary(Dictionary *dict) const ;

      bool mapCorpus(bool interim_map = false) ;
      void unmapCorpus() ;

      bool loadOverrides(const char *filename, bool allow_memmap = true,
			   bool force_creation = false) ;
      bool addOverride(uint32_t linenum, const EbCorpusMetaInfo *metainfo) ;
      bool saveOverrides(FILE *fp) ;
      bool saveOverrides() ;
      void freeOverrides() ;

      FrBWTLocation getInstanceRange(const FrSymbol *word, EbIndexSpec) const ;
      FrBWTLocation getInstanceRange(size_t wordID, EbIndexSpec) const ;
      size_t recordNumber(EbBWTIndex *idx, size_t location) const ;
      void getWordLocation(EbIndexSpec which, size_t location,
			   size_t &record_number, size_t &offset,
			   bool exact = true) const ;
      void getWordLocation(const EbBWTIndex *idx, size_t location,
			   size_t &record_number, size_t &offset,
			   bool exact = true) const ;
      void refineWordLocation(EbIndexSpec which, size_t location,
			      size_t &record_number, size_t &offset) const ;

      bool setSourceText(EBMTCandidate *, EbIndexSpec) const ;

      FrList *tokenize(FrTextSpans *source,const FrList *target,
		       BiTextMap *bitext = 0) const ;
      FrString *correspondingWord(const FrSymbol *sourceword) const ;

      char *getFileName(uint32_t filenumber) ;
      FILE *openFile(uint32_t filenumber, bool write = false) ;
      bool readFile(char *&buffer, size_t filenumber, uint32_t start,
		      int length, bool &must_free) ;
      uint32_t overridingMetaInfo(uint32_t linenumber) const ;
      const char *overridingMetaInfo(uint32_t linenumber,
				     size_t &meta_len,
				     bool &must_free) const ;

      bool saveExampleInfo() ;
      bool load(const char *filename) ;
      bool create(const char *filename) ;
      bool eraseFiles() ;

      bool beginIndexing() ;
      bool finishIndexing(bool completely_done = true) ;
      bool indexSentencePair(char *source, const char *target,
			       const char *tags,
			       FILE *corpusfp, EbIndexSpec = EbIndex_Main,
			       bool report_failures = true,
			       bool recursive_match = false,
			       bool *skip_tokenizer = 0) ;
      bool addPairs(const FrList *pairs, bool must_canonicalize = false,
		      bool recursive_match = false,
		      bool skip_tokenization = true,
		      bool force_quiet = false) ;
      bool addDocument(const char *document,
			 bool incremental_update = false) ;
      bool addDocument(const char *document, FILE *docfp,
			 bool incremental_update = false) ;
      bool tokenizeSentence(ostream &out, char *line) ;
      bool tokenizeDocument(const char *document, FILE *docfp,
			    ostream &out, bool show_origin = false) ;
      bool tokenizeDocument(const char *document, ostream &out,
			    bool show_origin = false) ;
      bool overrideMetaInfo(uint32_t linenumber,
			      const EbCorpusMetaInfo *override) ;

      bool enumerateNGrams(EbIndexSpec which, size_t N, size_t minfreq,
			     bool include_EOR,
			     FrBWTNGramIterFunc fn, va_list) const ;
      bool enumerateNGrams(EbIndexSpec which, size_t N, size_t minfreq,
			     bool include_EOR,
			     FrBWTNGramIterFunc fn, ...) const ;

      bool newSubFile() ;
      bool pack(ostream *out = 0) ;
      bool dumpIndex(const char *exportfile, bool lexical_sort = false) ;

      void resetDocWeights() ;
      void incrDocWeight(size_t example_number) ;
      void normalizeDocWeights() ;

      void setIndexLocation(size_t linenum, uint32_t entrynum) ;
      bool setIndexLocations() ;
      void freeIndexLocations() ;

      // accessors
      EBMTCorpus *getCorpus() const { return corpus ; }
      const char *corpusDirectory() const { return base_dir ; }
      Tokenizer *getTokenizer() const { return tokenizer ; }
      bool exampleInfoLoaded() const ;
      FrVocabulary *vocabulary() const { return m_svocab ; }
      FrVocabulary *sourceVocabulary() const { return m_svocab ; }
      FrVocabulary *targetVocabulary() const { return m_tvocab ; }
      bool indexGood() const { return m_good ; }
      EbBWTIndex *selectIndex(EbIndexSpec) const ;
      uint32_t numSentencePairs() const { return num_pairs ; }
      uint32_t numOccurrences(FrSymbol *word) const ;
      uint32_t tokenFileEntries() const { return token_file_entries ; }
      size_t numSubFiles() const { return highest_file+1 ; }
      bool getLinePosition(uint32_t location, uint32_t &start,
			     int &length) const ;
      const EbExampleInfo *info(size_t linenum) const
	    { return m_info ? &m_info[linenum] : 0 ; }
      EbExampleInfo *info(size_t linenum)
	    { return m_info ? &m_info[linenum] : 0 ; }
      bool isTaggedPhrase(size_t linenum) const
	    { return m_info ? m_info[linenum].isTaggedPhrase() : false ; }
      bool requireExactMatch(size_t linenum) const
	    { return m_info ? m_info[linenum].requireExactMatch() : false ; }
      size_t sourceLength(size_t linenum) const
	    { return m_info ? m_info[linenum].length() : 0 ; }
      uint32_t indexLocation(EbIndexSpec which, size_t linenum) const ;
      FrList *getContext(uint32_t exampleNumber, uint32_t lines) ;
      const char *currentOrigin() const { return current_origin ; }
      const char *getOrigin(uint32_t examplenum) const ;
      const EbDataSource *originOf(size_t example_number) const
	 { return m_origins.find(example_number) ; }
      double documentWeight(size_t example_number) const ;
      double originWeight(const EbDataSource *source) const ;
      double originWeight(size_t example_number,
			  const EbDataSource *source = 0) const ;
      size_t originRank(size_t example_number, size_t num_ranks = 0) const ;
      size_t numOrigins() const { return m_origins.numSources() ; }
      bool haveSourceWeights() const { return m_origins.haveWeights() ; }
      bool isReadOnly() const { return m_readonly ; }
      const char *sourceLanguage() const { return source_language ; }
      const char *targetLanguage() const { return target_language ; }
      const char *tokenFileName() const { return token_file ; }
      FrCasemapTable numberCharMap() const { return number_charmap ; }

      size_t wordID(FrSymbol *word) const ;

      // modifiers
      void setInfoFlags(size_t linenum, size_t flags)
	    { if (m_info) m_info[linenum].setFlags(flags) ; }
      void clearInfoFlags(size_t linenum, size_t flags)
	    { if (m_info) m_info[linenum].setFlags(0,flags) ; }
   } ;

//----------------------------------------------------------------------

void generate_auto_phrases(EBMTIndex *index) ;

size_t EbCvtWord2WordID(const char *word, bool target_lang = false) ;
size_t EbCvtSrcWord2WordID(const char *word) ;

#endif /* !__EBINDEX_H_INCLUDED */

// end of file ebindex.h //
