/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.93							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebcmatch.cpp	EBMT corpus matches				*/
/*  LastEdit: 19mar10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#if defined(__GNUC__)
#  pragma implementation "ebcmatch.h"
#endif

#include "ebcmatch.h"
#include "ebtoken.h"

/************************************************************************/
/*    Global variables for this module					*/
/************************************************************************/

FrAllocator EbCorpusMatches::allocator("EbCorpusMatches",
				       sizeof(EbCorpusMatches)) ;

/************************************************************************/
/*	Methods for class EbCorpusMatches				*/
/************************************************************************/

EbCorpusMatches::EbCorpusMatches(FrBWTLocationList *matched, EbIndexSpec which,
				 const EbCorpusMatches *oldmatch,
				 const TokenInfo *extension,
				 size_t matchlen, EbCorpusMatches *next)
{
   m_matches = matched ;
   extensionOf((EbCorpusMatches*)oldmatch) ;
   setMatchLength(matchlen) ;
   m_which = which ;
   m_next = next ;
   m_extendsr = 0 ;
   m_context = 0 ;
   m_subsumed = false ;
   m_spans = FrNewN(const FrTextSpan *,matchlen) ;
   m_backsubs = FrNewC(FrList*,matchlen) ;
   if (!m_spans || !m_backsubs)
      {
      FrNoMemory("while allocating corpus-match information") ;
      FrFree(m_spans) ;		m_spans = 0 ;
      FrFree(m_backsubs) ;      m_backsubs = 0 ;
      m_matchlen = 0 ;
      return ;
      }
   size_t oldlen ;
   if (oldmatch)
      {
      setProbability(oldmatch->probability()) ;
      m_numtokens = (EbUSHORT)oldmatch->numTokens() ;
      setInputMatch(oldmatch->inputMatch()) ;
      m_gap = oldmatch->gapPositions() ;
      m_numspans = (EbUSHORT)(oldmatch->numSpans() + 1) ;
      oldlen = oldmatch->matchLength() ;
      }
   else
      {
      setProbability(1.0) ;
      m_numtokens = 0 ;
      setInputMatch(0) ;
      clearGaps() ;
      m_numspans = 1 ;
      oldlen = 0 ;
      }
   if (extension)
      setProbability(probability() * extension->probability()) ;
   size_t i ;
   for (i = 0 ; i < oldlen ; i++)
      {
      m_spans[i] = oldmatch->span(i) ;
      const FrList *bs = oldmatch->backSubstitutions(i) ;
      m_backsubs[i] = bs ? (FrList*)bs->deepcopy() : 0 ;
      }
   for (i = oldlen ; i < matchlen ; i++)
      {
      if (extension)
	 {
	 m_spans[i] = extension->span() ;
	 const FrList *bs = extension->translations() ;
	 if (bs)
	    {
	    m_backsubs[i] = (FrList*)bs->deepcopy() ;
	    moreTokens() ;
	    }
	 else
	    m_backsubs[i] = 0 ;
	 extendInputMatch(extension->inputWords()) ;
	 }
      else
	 {
	 m_spans[i] = 0 ;
	 m_backsubs[i] = 0 ;
	 extendInputMatch(1) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

EbCorpusMatches::~EbCorpusMatches()
{
   if (m_backsubs)
      {
      for (size_t i = 0 ; i < m_matchlen ; i++)
	 free_object(m_backsubs[i]) ;
      FrFree(m_backsubs) ; 	m_backsubs = 0 ;
      }
   delete m_matches ; 		m_matches = 0 ;
   delete m_context ;		m_context = 0 ;
   FrFree(m_spans) ;		m_spans = 0 ;
   m_gap = 0xdeaddead ;
   return ;
}

//----------------------------------------------------------------------

void EbCorpusMatches::deleteList()
{
   FrLinkListDelete(this) ;
   return ;
}

//----------------------------------------------------------------------

EbCorpusMatches *EbCorpusMatches::reverseList()
{
   return FrLinkListReverse(this) ;
}

//----------------------------------------------------------------------

size_t EbCorpusMatches::listlength() const
{
   return FrLinkListLength(this) ;
}

//----------------------------------------------------------------------

void EbCorpusMatches::insert(FrBWTLocation loc)
{
   if (!m_matches)
      m_matches = new FrBWTLocationList(loc) ;
   else
      m_matches->insert(loc) ;
   return ;
}

//----------------------------------------------------------------------

void EbCorpusMatches::append(FrBWTLocation loc)
{
   if (!m_matches)
      m_matches = new FrBWTLocationList(loc) ;
   else
      m_matches->append(loc) ;
   return ;
}

//----------------------------------------------------------------------

size_t EbCorpusMatches::numGaps() const
{
   return FrPopulationCount(m_gap) ;
}

//----------------------------------------------------------------------

void EbCorpusMatches::incrDocWeights(EBMTIndex *index) const
{
   EbIndexSpec which = whichIndex() ;
   EbBWTIndex *idx = index->selectIndex(which) ;
   for (size_t r = 0 ; r < matches()->numRanges() ; r++)
      {
      FrBWTLocation range = matches()->range(r) ;
      size_t first = range.first() ;
      size_t last = range.pastEnd() ;
      if (last > idx->numItems())
	 last = idx->numItems() ;
      for (size_t loc = first ; loc < last ; loc++)
	 {
	 size_t recnum = index->recordNumber(idx,loc) ;
	 index->incrDocWeight(recnum) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

bool EbCorpusMatches::isExtensionOf(const EbCorpusMatches *other) const
{
   if (other && numSpans() == other->numSpans() + 1 &&
       m_spans && other->m_spans)
      {
      size_t i ;
      // skip all words corresponding to the first span
      for (i = 1 ; m_spans[i] && m_spans[i] == m_spans[i-1] ; i++)
	 ;
      size_t sp ;
      // then check whether the rest of the words came from the same
      //   spans
      for (sp = 0 ; (sp+i) < numSpans() ; sp++)
	 {
	 if (m_spans[sp+i] != other->m_spans[sp])
	    return false ;
	 }
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

void EbCorpusMatches::addContext(const EbCorpusMatches *ctxt, EBMTIndex *index)
{
   if (!ctxt)
      return ;
   const FrBWTLocationList *context = ctxt->context() ;
   if (context)
      {
      for (size_t r = 0 ; r < context->numRanges() ; r++)
	 {
	 FrBWTLocation range = context->range(r) ;
	 addContext(range,index) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void EbCorpusMatches::addContext(FrBWTLocation loc, EBMTIndex *index)
{
   if (loc.isEmpty())
      return ;
   if (!context())
      {
      m_context = new FrBWTLocationList ;
      if (!context())
	 return ;
      }
   size_t first = loc.first() ;
   size_t past_end = loc.pastEnd() ;
   FrBWTIndex *idx = index->selectIndex(whichIndex()); 
   if (first + 1 == past_end)
      {
      m_context->insert(FrBWTLocation(idx->getSuccessor(first))) ;
      }
   else if (past_end > first)
      {
      size_t last = past_end - 1 ;
      size_t first_succ = idx->getSuccessor(first) ;
      size_t last_succ = idx->getSuccessor(last) ;
      if (last_succ - first_succ == last - first)
	 m_context->insert(FrBWTLocation(first,last+1)) ;
      else
	 {
	 for (size_t i = first ; i < past_end ; i++)
	    {
	    m_context->insert(FrBWTLocation(idx->getSuccessor(i))) ;
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void EbCorpusMatches::addContextRev(const EbCorpusMatches *ctxt)
{
   if (!ctxt)
      return ;
   const FrBWTLocationList *context = ctxt->context() ;
   if (!context)
      return ;
   if (!m_context)
      {
      m_context = new FrBWTLocationList(*context) ;
      }
   else
      {
      for (size_t r = 0 ; r < context->numRanges() ; r++)
	 {
	 m_context->insert(context->range(r)) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void EbCorpusMatches::addContextRev(FrBWTLocation loc)
{
   if (loc.isEmpty())
      return ;
   if (!context())
      m_context = new FrBWTLocationList(loc) ;
   else
      m_context->insert(loc) ;
   return ;
}

//----------------------------------------------------------------------

int EbCorpusMatches::compare(const EbCorpusMatches &m1,
			     const EbCorpusMatches &m2)
{
   // sort by decreasing match length, then increasing position in sentence
//   size_t len1 = m1.matchLength() ;
//   size_t len2 = m2.matchLength() ;
   size_t len1 = m1.inputMatch() ;
   size_t len2 = m2.inputMatch() ;
   if (len1 > len2)
      return -1 ;
   else if (len1 < len2)
      return +1 ;
   size_t pos1 = m1.startPosition() ;
   size_t pos2 = m2.startPosition() ;
   if (pos1 < pos2)
      return -1 ;
   else if (pos1 > pos2)
      return +1 ;
   // sort by which index the match comes from, giving priority to
   //   EbIndex_Updates over EbIndex_Tagged over EbIndex_Main over
   //   EbIndex_Struct
   if (m1.whichIndex() > m2.whichIndex())
      return -1 ;
   else if (m1.whichIndex() < m2.whichIndex())
      return +1 ;
   // for chunks covering the same phrase, sort by increasing amount
   //   of generalization/fuzzy-match
   size_t tok1 = m1.numTokens() ;
   size_t tok2 = m2.numTokens() ;
   if (tok1 < tok2)
      return -1 ;
   else if (tok1 > tok2)
     return +1 ;
   tok1 = m1.numGaps() ;
   tok2 = m2.numGaps() ;
   if (tok1 < tok2)
      return -1 ;
   else if (tok1 > tok2)
     return +1 ;
   // if we get here, the two match records are equivalent
   return 0 ;
}

//----------------------------------------------------------------------

//----------------------------------------------------------------------

void EbCorpusMatches::dump(ostream &out) const
{
   out << "EbCorpusMatches(" << matchLength() << "/" << inputMatch()
       << ", gapmask=" << hex << gapPositions() << dec
       << ", numtok=" << numTokens() ;
   if (matchLength() > 0)
      {
      out << " = " ;
      for (size_t i = 0 ; i < matchLength() ; i++)
	 {
	 const FrTextSpan *sp = span(i) ;
	 if (sp)
	    {
	    FrList *text = sp->printable() ;
	    out << text ;
	    free_object(text) ;
	    }
	 }
      }
   out << ") has "
       << matches()->totalMatches() << " matches" << endl ;
   return ;
}

// end of file ebcmatch.cpp //
