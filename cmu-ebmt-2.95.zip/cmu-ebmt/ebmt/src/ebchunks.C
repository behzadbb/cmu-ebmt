/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.93							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebchunks.cpp	code to find candidate chunks			*/
/*  LastEdit: 19mar10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#if defined(__GNUC__)
#  pragma implementation "ebchunks.h"
#endif

#include <limits.h>
#define IMPLEMENT_EBCHUNKS
#include "ebchunks.h"
#include "ebcmatch.h"
#include "ebcorpus.h"
#include "ebfreq.h"
#include "ebsent.h"
#include "ebtoken.h"
#include "ebutil.h"
#include "ebmt.h"
#include "ebglobal.h"

FrList *EbMakeGeneralizationSeq(FrObject *token, size_t offset, size_t len) ;

/************************************************************************/
/*	Manifest constants for this module				*/
/************************************************************************/

/************************************************************************/
/*	Types for this module						*/
/************************************************************************/

/************************************************************************/
/*	Global Variables						*/
/************************************************************************/

/************************************************************************/
/************************************************************************/

static EbCorpusMatches *make_match(FrBWTLocationList *occur,
				   EbIndexSpec which,
				   const EbCorpusMatches *act,
				   const TokenInfo *inf,
				   size_t matchlen, EbCorpusMatches *matches)
{
   EbCorpusMatches *newmatch = new EbCorpusMatches(occur,which,act,
						   inf,matchlen,matches) ;
   if (newmatch)
      return newmatch ;
   else
      return matches ;
}

//----------------------------------------------------------------------

static bool is_function_word(const char *text, const FrList *func_words)
{
   FrList *words = FrCvtString2Wordlist(text,word_delimiters,abbrevs_list,
					char_encoding) ;
   bool func = words->intersect(func_words,EBMT_equal) ;
   free_object(words) ;
   return func ;
}

//----------------------------------------------------------------------

static bool contains_content_word(const EbCorpusMatches *match)
{
   if (match && function_words)
      {
      for (size_t i = 0 ; i < match->matchLength() ; i++)
	 {
	 const FrTextSpan *span = match->span(i) ;
	 if (!span)
	    continue ;
	 char *text = span->getText() ;
	 bool content = !is_function_word(text,function_words) ;
	 FrFree(text) ;
	 if (content)
	    return true ;
	 }
      return false ;
      }
   return true ;
}

//----------------------------------------------------------------------

static void show_token_info(ostream &out, const TokenInfo *ti, size_t loc,
			    FrVocabulary *svocab,
			    const FrTextSpans *input_lattice)
{
   if (ti->equivalenceClass())
      {
      if (svocab)
	 out << svocab->nameForID(ti->equivalenceClass()) ;
      else
	 out << ti->equivalenceClass() ;
      }
   else
      out << "-surf-" ;
   out << "/" << ti->inputWords() << "/" << ti->length() ;
   if (input_lattice)
      {
      char *text = input_lattice->getText(loc,loc+ti->length()-1) ;
      if (text)
	 {
	 out << "[" << text << "]" ;
	 FrFree(text) ;
	 }
      }
   if (ti->translations())
      out << " " << ti->translations() ;
   return ;
}

//----------------------------------------------------------------------

EbCorpusMatches *EbFilterMatches(EbCorpusMatches *matches,
				 size_t min_length,
				 size_t max_freq,
				 const EbMatchFrequency *freqs)
{
   EbCorpusMatches *filtered = 0 ;
   EbCorpusMatches *prev = 0 ;
   EbCorpusMatches *next = 0 ;

   for ( ; matches ; matches = next)
      {
      next = matches->next() ;
      matches->setNext(0) ;
      if (matches->matchLength() < min_length ||
	  (freqs && !freqs->wantMore(matches)) ||
	  matches->totalMatches() > max_freq)
	 delete matches ;
      else if (!contains_content_word(matches))
	 delete matches ;
      else
	 {
	 if (prev)
	    prev->setNext(matches) ;
	 else
	    filtered = matches ;
	 prev = matches ;
	 }
      }
   return filtered ;
}

//----------------------------------------------------------------------

size_t EbPrepDocMaxDups(const EBMTIndex *index)
{
#if 0
   size_t max = index->numOrigins()  ;
   if (2 * max_duplicates < max)
      max = 2 * max_duplicates ;
#else
   (void)index ;
   size_t max = max_duplicates ;
#endif /* 0 */
   return max ;
}

//----------------------------------------------------------------------

EBMTCandidate *find_full_chunks(const uint32_t *IDs, size_t N,
				const FrTextSpans *original_input,
				EBMTCorpus *corpus,
				EbIndexSpec which)
{
   FrMessageLoop() ;			// handle any pending events
   if (N < 2 || !IDs)
      return 0 ;
   EBMTIndex *index = corpus->getIndex() ;
   EbBWTIndex *idx = index->selectIndex(which) ;
   FrBWTLocation occurs(idx->unigram(IDs[0])) ;
   for (size_t i = 1 ; i < N && occurs.nonEmpty() ; i++)
      {
      occurs = idx->extendMatch(occurs,idx->unigram(IDs[i])) ;
      }
   // at this point, anything left in 'occurs' covers the entire input phrase
   EBMTCandidate *candidates = 0 ;
   if (occurs.nonEmpty())
      {
      FrBWTLocationList *match = new FrBWTLocationList(occurs) ;
      TokenInfo info(IDs[0],original_input->textLength(),(FrString*)0,0) ;
      info.setSpan(original_input->getSpan(0)) ;
      EbCorpusMatches *matches = make_match(match,which,0,&info,N,0) ;
      candidates = candidates->nconc(EbMakeCandidates(matches,original_input,
						      corpus,false,0)) ;
      }
   if (verbose)
      cerr << "; candidates found = " << candidates->listlength() << endl ;
   return candidates ;
}

/************************************************************************/
/************************************************************************/

static uint32_t get_ID(const FrObject *obj, const FrVocabulary *vocab)
{
   if (obj)
      {
      const char *w = obj->printableName() ;
      if (w)
	 {
	 FrCharEncoding enc = (ignore_source_case
			       ? char_encoding : FrChEnc_RawOctets) ;
	 char *word = EbStripCoindex(w,enc) ;
	 if (word)
	    {
	    uint32_t id = vocab->findID(word) ;
	    FrFree(word) ;
	    return id ;
	    }
	 }
      }
   return FrVOCAB_WORD_NOT_FOUND ;
}

//----------------------------------------------------------------------

static uint32_t get_ID(const char *origword, const FrVocabulary *vocab)
{
   if (origword)
      {
      FrCharEncoding enc = (ignore_source_case
			    ? char_encoding : FrChEnc_RawOctets) ;
      char *word = EbStripCoindex(origword,enc) ;
      if (word)
	 {
	 uint32_t id = vocab->findID(word) ;
	 FrFree(word) ;
	 return id ;
	 }
      }
   return FrVOCAB_WORD_NOT_FOUND ;
}

//----------------------------------------------------------------------

static EbCorpusMatches *extend_speculatively(const EbCorpusMatches *previous,
					     FrBWTLocation next,
					     EbIndexSpec which,
					     EbBWTIndex *idx,
					     EbCorpusMatches *matches,
					     size_t gaplen,
					     const TokenInfo *inf)
{
   FrBWTLocation recstarts = idx->recordStarts() ;
   for ( ; previous ; previous = previous->next())
      {
      if (previous->numGaps() > 1)	// avoid pathological cases that blow
	 continue ;			//   up memory requirements
      FrBWTLocationList *prevmatch = previous->matches() ;
      // check for a cached copy of 'occur' if the combination of prev and
      //   next is cacheable
      bool cacheable = (gaplen == 1 && previous->matchLength() == 1 &&
			  prevmatch->numRanges() == 1) ;
      FrBWTLocationList *occur ;
      occur = cacheable ? EbCachedGappedMatch(prevmatch->range(0),next) : 0 ;
      bool prev_gap = false ;
      if (occur)
	 prev_gap = true ;
      else
	 {
	 if (prevmatch->numRanges() == 1 && prevmatch->range(0) == recstarts)
	    occur = 0 ;
	 else
	    occur = idx->extendMatchGap(prevmatch,next,gaplen) ;
	 if (cacheable)
	    (void)EbCacheGappedMatch(prevmatch->range(0),next,occur) ;
	 }
      if (occur && occur->totalMatches() > 0)
	 {
	 size_t matchlen = previous->matchLength() + inf->sourceWords() + 1 ;
	 matches = make_match(occur,which,previous,inf,matchlen,matches) ;
	 if (prev_gap)
	    matches->addGap(1) ;
	 matches->addGap(previous->matchLength()) ;
	 }
      else
	 delete occur ;
      }
   return matches ;
}

//----------------------------------------------------------------------

EbCorpusMatches *finished_matches(EbCorpusMatches *&active,
				  EbCorpusMatches *matches,
				  EBMTIndex *index,
				  bool complete_only,
				  const EbMatchFrequency *freqs)
{
   if (active && index)
      {
      bool delete_single = (!keep_unigram_matches && !complete_only) ;
      while (active)
	 {
	 EbCorpusMatches *m = active ;
	 active = m->next() ;
	 if (freqs && !freqs->wantMore(m))
	    delete m ;
	 else if (m->matchLength() > 1 || (!delete_single && !m->haveGap()))
	    {
	    if (complete_only)
	       {
	       EbBWTIndex *idx = index->selectIndex(m->whichIndex()) ;
	       FrBWTLocation recstarts = idx->recordStarts() ;
	       if (recstarts.nonEmpty())
		  {
		  m->setMatches(idx->restrictMatch(m->matches(),recstarts)) ;
		  }
	       else
		  {
		  FrBWTLocationList *complete = new FrBWTLocationList ;
		  FrBWTLocationList *mtch = m->matches() ;
		  size_t mlen = m->matchLength() ;
		  for (size_t i = 0 ; i < mtch->numRanges() ; i++)
		     {
		     FrBWTLocation ext(mtch->range(i)) ;
		     for (size_t j = ext.first() ; j < ext.pastEnd() ; j++)
			{
			size_t recnum = index->recordNumber(idx,j) ;
			if (index->sourceLength(recnum) == mlen)
			   {
			   complete->append(j) ;
			   }
			}
		     }
		  m->setMatches(complete) ;
		  }
	       }
	    if (m->totalMatches() > 0)
	       {
	       m->setNext(matches) ;
	       matches = m ;
	       }
	    else
	       delete m ;
	    }
	 else
	    {
	    // filter the unigram matches to get only those which are complete
	    //   training instances
	    FrBWTLocationList *extlist = m->matches() ;
	    if (extlist->totalMatches() > 0)
	       {
	       EbBWTIndex *idx = index->selectIndex(m->whichIndex()) ;
	       FrBWTLocation recstarts = idx->recordStarts() ;
	       FrBWTLocationList *singletons ;
	       if (recstarts.nonEmpty())
		  {
		  singletons = idx->restrictMatch(extlist,recstarts) ;
		  }
	       else
		  {
		  singletons = new FrBWTLocationList ;
		  for (size_t i = 0 ; i < extlist->numRanges() ; i++)
		     {
		     FrBWTLocation ext(extlist->range(i)) ;
		     for (size_t j = ext.first() ; j < ext.pastEnd() ; j++)
			{
			size_t recnum = index->recordNumber(idx,j) ;
			if (index->sourceLength(recnum) == 1)
			   {
			   singletons->append(j) ;
			   }
			}
		     }
		  }
	       if (singletons->totalMatches() > 0)
		  {
		  m->setMatches(singletons) ;
		  m->setNext(matches) ;
		  matches = m ;
		  }
	       else
		  {
		  delete singletons ;
		  delete m ;
		  }
	       }
	    else
	       delete m ;
	    }
	 }
      }
   return matches ;
}

//----------------------------------------------------------------------

static void extend_active_match(EbCorpusMatches **active,
				size_t loc, const TokenInfo *inf,
				EbBWTIndex *idx, EbIndexSpec which, 
				const TokenInfo * const *tokinf,
				size_t prev_loc, bool complete_only,
				const FrBWTLocation &endofline)
{
   FrBWTLocation ext ;
   if (inf->sourceWords() > 0)
      {
      uint32_t id = inf->wordID(0) ;
      ext = idx->unigram(id) ;
      for (size_t i = 1 ; i < inf->sourceWords() && ext.nonEmpty() ; i++)
	 {
	 id = inf->wordID(i) ;
	 ext = idx->extendMatch(ext,idx->unigram(id)) ;
	 }
      if (ext.isEmpty())
	 return ;
      }
   else
      ext = FrBWTLocation(0,~0) ;
   size_t len = inf->length() ;
   size_t end = loc + len ;
   if (loc > 0)
      {
      for (const EbCorpusMatches *act = active[loc] ; act ; act=act->next())
	 {
	 FrBWTLocationList *occur = idx->extendMatch(act->matches(),ext,
						     inf->sourceWords()) ;
	 if (occur && occur->totalMatches() > 0)
	    {
	    size_t matchlen = act->matchLength() + inf->sourceWords() ;
	    active[end] = make_match(occur,which,act,inf,matchlen,active[end]);
	    }
	 else
	    delete occur ;
	 }
      if (prev_loc != (size_t)~0)
	 {
	 const TokenInfo *prev_inf = tokinf[prev_loc] ;
	 if (!prev_inf)
	    prev_inf = inf ;
	 active[end] = extend_speculatively(active[prev_loc],ext,which,
					    idx,active[end],
					    prev_inf->sourceWords(),inf) ;
	 }
      }
   // add a newly-started chunk into the appropriate bin
   if (complete_only)
      ext = idx->extendMatch(endofline,ext,inf->sourceWords()) ;
   if (ext.nonEmpty())
      active[end] = make_match(new FrBWTLocationList(ext),which,
			       0,inf,inf->sourceWords(),active[end]) ;
   return ;
}

//----------------------------------------------------------------------

static void show_lattice(EBMTIndex *index, size_t full_len,
			 const TokenInfo * const *tokens,
			 const FrTextSpans *input_lattice)
{
   FrVocabulary *svocab = index->sourceVocabulary() ;
   for (size_t i = 0 ; i < full_len ; i++)
      {
      if (tokens[i])
	 {
	 const TokenInfo *ti = tokens[i] ;
	 for ( ; ti ; ti = ti->next())
	    {
	    if (ti == tokens[i])
	       cout << setw(3) << i << ": " ;
	    else
	       cout << setw(5) << " " ;
	    show_token_info(cout,ti,i,svocab,input_lattice) ;
	    cout << endl ;
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

EbCorpusMatches *find_matches(EBMTIndex *index, EbIndexSpec which,
			      const FrTextSpans *input_lattice,
			      TokenInfo **tokens,
			      EbCorpusMatches **active,
			      EbCorpusMatches *matches,
			      bool complete_only,
			      EbMatchFrequency *freqs)
{
   size_t full_len = input_lattice->textLength() ;
   EbBWTIndex *idx = index->selectIndex(which) ;
   if (!idx || idx->numItems() == 0)
      return matches ;
   if (trace_matching)
      show_lattice(index,full_len,tokens,input_lattice) ;
   // work through original input from left to right, using the active
   //   chunks ending at the current position and the tokens starting at
   //   the following position
   FrBWTLocation endofline(idx->unigram(idx->EORvalue())) ;
   bool may_speculate = (allow_gapped_matches && !complete_only) ;
   size_t prev_loc = ~0 ;
   for (size_t loc = 0 ; loc < full_len ; loc++)
      {
      size_t active_loc = prev_loc ;
      for (const TokenInfo *inf = tokens[loc] ; inf ; inf = inf->next())
	 {
	 extend_active_match(active,loc,inf,idx,which,tokens,prev_loc,
			     complete_only,endofline) ;
	 active_loc = loc ;
	 }
      // put all matches which have now been passed by onto the list of
      //   completed matches
      if (may_speculate)
	 {
	 if (active_loc > prev_loc)
	    {
	    for ( ; prev_loc < active_loc ; prev_loc++)
	       matches = finished_matches(active[prev_loc],matches,index,
					  complete_only,freqs) ;
	    }
	 prev_loc = active_loc ;
	 }
      else
	 matches = finished_matches(active[loc],matches,index,
				    complete_only,freqs) ;
      }
   if (may_speculate && prev_loc != (size_t)~0)
      matches = finished_matches(active[prev_loc],matches,index,
				 complete_only,freqs) ;
   return finished_matches(active[full_len],matches,index,
			   complete_only,freqs) ;
}

//----------------------------------------------------------------------

static void sort_by_id(TokenInfo **tokens, size_t full_len)
{
   // to make subsequent processing more efficient, sort each sublist
   //   of TokenInfo structures by their wordIDs
   for (size_t location = 0 ; (size_t)location < full_len ; location++)
      {
      tokens[location] = FrMergeSort(tokens[location]) ;
      }
   return ;
}

//----------------------------------------------------------------------

static bool in_list(TokenInfo *inf, uint32_t id, size_t length,
		      const FrString *translation, TokenInfo *&same_src)
{
   for ( ; inf ; inf = inf->next())
      {
      if (inf->length() == length)
	 {
	 bool matched = true ;
	 for (size_t i = 0 ; i < inf->sourceWords() ; i++)
	    {
	    if (inf->wordID(i) != id)
	       {
	       matched = false ;
	       break ;
	       }
	    }
	 if (matched)
	    {
	    same_src = inf ;
	    return (inf->translations()->member(translation,EBMT_equal) != 0) ;
	    }
	 }
      }
   same_src = 0 ;
   return false ;
}

//----------------------------------------------------------------------

static bool single_word(const char *text)
{
   if (!text)
      return false ;
   while (*text)
      {
      if (Fr_isspace(*text))
	 return false ;
      text++ ;
      }
   return true ;
}

//----------------------------------------------------------------------

#if 0
static void dump_info(const TokenInfo * const *tokens, size_t inputlen,
		      ostream &out)
{
   for (size_t i = 0 ; i < inputlen ; i++)
      {
      if (tokens[i])
	 out << i ;
      for (const TokenInfo *info = tokens[i] ; info ; info = info->next())
	 {
	 out << "\t" << info->length() << "/" << info->inputWords() ;
	 out << " ID0=" << info->wordID() ;
	 if (info->isToken())
	    out << " equivclass=" << info->equivalenceClass() ;
	 out << endl ;
	 }
      }
   return ;
}
#endif /* 0 */

//----------------------------------------------------------------------

static TokenInfo *make_info(const FrTextSpan *span, uint32_t id,
			    size_t length, FrString *trans,
			    TokenInfo *previnfo, bool is_tok = false,
			    uint32_t equiv = FrVOCAB_WORD_NOT_FOUND,
			    size_t inputwords = 1, size_t sourcewords = 1,
			    double prob = 1.0)
{
   TokenInfo *info = new TokenInfo(id,length,trans,previnfo,sourcewords) ;
   if (info)
      {
      info->isToken(is_tok) ;
      info->setSpan(span) ;
      if (equiv != FrVOCAB_WORD_NOT_FOUND)
	 info->inEquivClass(equiv) ;
      info->setInputWords(inputwords) ;
      info->setProb(prob) ;
      return info ;
      }
   else
      return previnfo ;
}

//----------------------------------------------------------------------

static TokenInfo *make_info(const FrTextSpan *span, size_t numIDs,
			    uint32_t* ids, size_t length,
			    FrString *trans, TokenInfo *previnfo,
			    bool is_tok = false,
			    uint32_t equiv = FrVOCAB_WORD_NOT_FOUND)
{
   TokenInfo *info = new TokenInfo(numIDs,ids,length,trans,previnfo) ;
   if (info)
      {
      info->isToken(is_tok) ;
      info->setSpan(span) ;
      if (equiv != FrVOCAB_WORD_NOT_FOUND)
	 info->inEquivClass(equiv) ;
      return info ;
      }
   else
      {
      delete span ;
      return previnfo ;
      }
}

//----------------------------------------------------------------------

static EBMTCandidate *make_generalization(int location, const char *word,
					  const FrString *trans,
					  const FrTextSpan *span,
					  FrSymbol *token, size_t length,
					  EBMTCandidate *generalizations)
{
   FrString *wordstr = new FrString(word) ;
   generalizations = new EBMTCandidate(location,wordstr,trans,generalizations);
   free_object(wordstr) ;
   generalizations->setInputLength(length) ;
   generalizations->equivClass(token) ;
   generalizations->setCoveredSpans(1,&span) ;
   generalizations->setAlignScore(span->score()) ;
   generalizations->setAlignQuality(span->score()) ;
   FrList *genseq
      = new FrList(EbMakeGeneralizationSeq(token,0,EbWordCount(trans))) ;
   generalizations->setGeneralizationSequence(genseq) ;
   return generalizations ;
}

//----------------------------------------------------------------------

static void insert_null_arc(const FrTextSpan *span, TokenInfo **tokens)
{
   int location = span->start() ;
   size_t length = span->spanLength() ; 
   tokens[location] = make_info(span,0,(uint32_t*)0,length,0,tokens[location]);
   return ;
}

//----------------------------------------------------------------------

static void insert_single_word_arc(const FrTextSpan *span, TokenInfo **tokens,
				   EBMTCorpus *corpus, FrVocabulary *vocab,
				   const Tokenizer *tokenizer,
				   FrCasemapTable number_charmap,
				   EBMTCandidate *&generalizations)
{
   const char *word = span->text() ;
   bool is_tok = is_token(word) ;
   int location = span->start() ;
   size_t length = span->spanLength() ; 
   uint32_t id = get_ID(word,vocab) ;
   if (id != FrVOCAB_WORD_NOT_FOUND)
      {
      tokens[location] = make_info(span,id,length,0,tokens[location],is_tok) ;
      }
   const FrList *synonyms = corpus->sourceSynonyms(word) ;
   for ( ; synonyms ; synonyms = synonyms->rest())
      {
      FrObject *syn = synonyms->first() ;
      uint32_t id = get_ID(syn,vocab) ;
      is_tok = is_token(syn) ;
      if (id != FrVOCAB_WORD_NOT_FOUND)
	 {
	 tokens[location] = make_info(span,id,length,0,tokens[location],
				      is_tok) ;
	 }
      }
   FrString *trans = 0 ;
   FrSymbol *token = 0 ;
   if (tokenizer)
      token = tokenizer->regexGeneralization(word,number_charmap,trans) ;
   if (token)
      {
      // add this translation to the list of all candidates
      generalizations = make_generalization(location,word,trans,span,
					    token,length,generalizations) ;
      corpus->setExampleWeight(generalizations) ;
      // add this tokenization to the lattice, but only if the token
      //  itself occurs in the corpus
      uint32_t tok_id = get_ID(token,vocab) ;
      if (tok_id != FrVOCAB_WORD_NOT_FOUND)
	 {
	 id = tok_id ; //!!! was trying to match untok against tok. in index
	 tokens[location] = make_info(span,id,length,trans,tokens[location],
				      true,tok_id) ;
	 } 
      else
	 free_object(trans) ;
      }
   else
      free_object(trans) ;
   return ;
}

//----------------------------------------------------------------------

static void insert_multi_word_arc(const FrTextSpan *span, TokenInfo **tokens,
				  FrVocabulary *vocab)
{
   FrList *words = FrCvtString2Wordlist(span->text(),word_delimiters,
					abbrevs_list,char_encoding) ;
   size_t srclen = words->simplelistlength() ;
   if (srclen > 0)
      {
      FrLocalAlloc(uint32_t,ids,64,srclen) ;
      if (!ids)
	 {
	 FrNoMemory("converting words to IDs") ;
	 return ;
	 }
      bool untranslatable = false ;
      for (size_t i = 0 ; i < srclen ; i++)
	 {
	 ids[i] = get_ID(words->nth(i),vocab) ; 
	 if (ids[i] == FrVOCAB_WORD_NOT_FOUND)
	    {
	    untranslatable = true ;
	    break ;
	    }
	 } 
      if (!untranslatable)
	 {
	 size_t location = span->start() ;
	 tokens[location] = make_info(span,srclen,ids,span->spanLength(),0,
				      tokens[location]) ;
	 }
      FrLocalFree(ids) ;
      }
   free_object(words) ;
   return ;
}

//----------------------------------------------------------------------

EBMTCandidate *build_token_info(FrTextSpans *input_lattice,
				EBMTCorpus *corpus,
				const Tokenizer *tokenizer,
				TokenInfo **tokens,
				FrCasemapTable number_charmap)
{
   EBMTIndex *index = corpus->getIndex() ;
   FrVocabulary *vocab = index->vocabulary() ;
   //  make TokenInfo entries for the original source words as well as any
   //    synonyms and any regex matches against the generalization file
   EBMTCandidate *generalizations = 0 ;
   for (size_t i = 0 ; i < input_lattice->spanCount() ; i++)
      {
      const FrTextSpan *span = input_lattice->getSpan(i) ;
      if (!span)
	 continue ;
      const char *word = span->text() ;
      // check whether the span is an externally-tagged entity; if so, we want
      //   to treat it like a token
      const FrObject *category = span->getMetaDataSingle("CAT") ;
      const FrObject *xlat = span->getMetaDataSingle("XLAT") ;
      if (category && xlat)
	 {
	 const char *cat = FrPrintableName(category) ;
	 char *token = Fr_aprintf("%s%s%s",(cat[0]=='<')?"":"<",cat,
				  (cat[strlen(cat)-1]=='>')?"":">") ;
	 // add the translation to the list of all candidates
	 FrString *trans = (FrString*)xlat->deepcopy() ;
	 int location = span->start() ;
	 size_t length = span->spanLength() ; 
	 generalizations = make_generalization(location,word,trans,span,
					       FrSymbolTable::add(token),
					       length,generalizations) ;
	 corpus->setExampleWeight(generalizations) ;
	 // add the tokenization to the lattice, but only if the token itself
	 //   occurs in the corpus
	 uint32_t id = get_ID(token,vocab) ;
	 FrFree(token) ;
	 if (id != FrVOCAB_WORD_NOT_FOUND)
	    {
	    tokens[location] = make_info(span,id,length,trans,
					 tokens[location],true) ;
	    }
	 else
	    free_object(trans) ;
	 }
      // now check whether the source is empty, a single word, or a phrase
      //   and insert an arc accordingly
      if (!word || !*word)
	 insert_null_arc(span,tokens) ;
      else if (single_word(word))
	 insert_single_word_arc(span,tokens,corpus,vocab,tokenizer,
				number_charmap,generalizations) ;
      else
	 insert_multi_word_arc(span,tokens,vocab) ;
      }
   size_t full_len =  input_lattice->textLength() ;
   sort_by_id(tokens,full_len) ;
   return generalizations ;
}

//----------------------------------------------------------------------

static FrSymHashTable *make_target_vocab(const FrList *targetwords)
{
   if (!targetwords)
      return 0;
   FrSymHashTable *vocab = new FrSymHashTable ;
   if (vocab)
      {
      vocab->expandTo(targetwords->simplelistlength()) ;
      for ( ; targetwords ; targetwords = targetwords->rest())
	 {
	 const char *tword = FrPrintableName(targetwords->first()) ;
	 if (tword)
	    {
	    char buf[FrMAX_SYMBOLNAME_LEN+1] ;
	    strncpy(buf,tword,sizeof(buf)) ;
	    buf[sizeof(buf)-1] = '\0' ;
	    Fr_strlwr(buf,char_encoding) ;
	    vocab->add(FrSymbolTable::add(buf)) ;
	    }
	 }
      }
   return vocab ;
}

//----------------------------------------------------------------------

EBMTCandidate *find_generalized_chunks(FrTextSpans *input_lattice,
				       EBMTCorpus *corpus,
				       const Tokenizer *tokenizer,
				       TokenInfo **tokens,
				       FrCasemapTable number_charmap,
				       const FrList *targetwords)
{
   size_t full_len =  input_lattice->textLength() ;
   FrLocalAllocC(EbCorpusMatches*,active,1024,full_len+1) ;
   if (!active)
      return 0 ;
   FrSymHashTable *targetvocab = make_target_vocab(targetwords) ;
   EBMTCandidate *generalizations = build_token_info(input_lattice,corpus,
						     tokenizer,tokens,
						     number_charmap) ;
   int match_count = 0 ;
   EBMTIndex *index = corpus->getIndex() ;
   FrVocabulary *vocab = index->vocabulary() ;
   EBMTCandidate *candidates ;
   bool old_apply_backsubs = apply_backsubs ;
   apply_backsubs = true ;
   for (size_t iteration = 1 ; iteration <= 20 ; iteration++)
      {
      int num_matches = match_count ;
      EbCorpusMatches *matches = find_matches(index,EbIndex_Tagged,
					      input_lattice,tokens,
					      active,0,true) ;
      candidates = EbMakeCandidates(matches,input_lattice,corpus,
				    true,0,0,targetvocab) ;
      match_count = candidates->listlength() ;
      if (match_count <= num_matches)
	 break ;
      // add the matches to the proper positions in the tokens[] array
      bool added = false ;
      while (candidates)
	 {
	 EBMTCandidate *cand = candidates ;
	 candidates = candidates->next() ;
	 int location = cand->inputStart() ;
	 size_t length = cand->inputLength() ;
	 const FrString *translation = cand->targetWords() ;
	 FrSymbol *eq_class = cand->equivClass() ;
	 uint32_t tok_id = eq_class ? vocab->findID(eq_class->symbolName())
	    			    : FrVOCAB_WORD_NOT_FOUND ;
	 if (tok_id != FrVOCAB_WORD_NOT_FOUND)
	    {
	    TokenInfo *same_source = 0 ;
	    if (translation &&
		!in_list(tokens[location],tok_id,length,translation,
			 same_source))
	       {
	       if (same_source)
		  {
		  same_source->addTranslation(translation) ;
		  }
	       else if (cand->spansCovered() == 1)
		  {
		  FrString *trans = (FrString*)translation->deepcopy() ;
		  tokens[location] = make_info(cand->span(0),tok_id,length,
					       trans,tokens[location],true,
					       tok_id,cand->inputWords(),1,
					       cand->score()) ;
		  added = true ;
		  }
	       else
		  {
		  FrString *trans = (FrString*)translation->deepcopy() ;
		  size_t lastloc = location + length - 1 ;
		  char *srctext = input_lattice->getText(location,
							 lastloc) ;
		  FrTextSpan *new_span = new FrTextSpan(location,lastloc,
							0.0,srctext,
							input_lattice);
		  FrFree(srctext) ;
		  size_t numwords = cand->spansCovered() ; //FIXME?
		  tokens[location] = make_info(new_span,tok_id,length,trans,
					       tokens[location],true,tok_id,
					       cand->inputWords(),numwords,
					       cand->score()) ;
		  // we need to remember 'new_span' until all EBMTCandidates
		  //   built using it have been deleted.  Since the given
		  //   input lattice also has to remain intact until then,
		  //   stuff the span into a metadata field
		  if (EbInsertExtraSpan(input_lattice,new_span))
		     added = true ;
		  }
	       }
	    }
	 delete cand ;
	 }
      if (added)
	 sort_by_id(tokens,full_len) ;
      else
	 break ;
      }
   FrLocalFree(active) ;
   apply_backsubs = old_apply_backsubs ;
   delete targetvocab ;
   return candidates->nconc(generalizations) ;
}

//----------------------------------------------------------------------

static EbCorpusMatches *locate_matches(FrTextSpans *input_lattice,
				       size_t full_len, EBMTIndex *index,
				       TokenInfo **tokens,
				       int transmem_mode,
				       EbMatchFrequency *freqs)
{
   // active chunks will be split into N lists in an array, indexed by the
   //    END of the chunk in the original untokenized input
   FrLocalAllocC(EbCorpusMatches*,active,1024,full_len+1) ;
   if (!active)
      {
      FrNoMemory("while setting up to find corpus matches") ;
      return 0 ;
      }
   if (trace_matching)
      show_lattice(index,full_len,tokens,input_lattice) ;
   EbCorpusMatches *matches = 0 ;
   EbCorpusMatches *prev_matches = 0 ;
   // find all matches in each of the two non-tagged indices
   if (transmem_mode != EbTRANSMEM_OFF)
      {
      matches = find_matches(index,EbIndex_Updates,input_lattice,tokens,
			     active,matches,true,freqs) ;
      if (freqs)
	 freqs->updateFrequencies(matches) ;
      prev_matches = matches ;
      matches = find_matches(index,EbIndex_Main,input_lattice,tokens,
			     active,matches,true,freqs) ;
      if (freqs)
	 freqs->updateFrequencies(matches,prev_matches) ;
      prev_matches = matches ;
      }
   if (!matches && transmem_mode != EbTRANSMEM_ON)
      {
      matches = find_matches(index,EbIndex_Updates,input_lattice,tokens,
			     active,matches,false,freqs) ;
      if (freqs)
	 freqs->updateFrequencies(matches,prev_matches) ;
      prev_matches = matches ;
      matches = find_matches(index,EbIndex_Main,input_lattice,tokens,
			     active,matches,false,freqs) ;
      if (freqs)
	 freqs->updateFrequencies(matches,prev_matches) ;
      prev_matches = matches ;
      }
   // add the matches extending to the end of the input to the list of
   //   all finished matches
   matches = finished_matches(active[full_len],matches,index,
			      false,freqs) ;
   FrLocalFree(active) ;   
   return matches ;
}

//----------------------------------------------------------------------

static void free_token_info(TokenInfo **tokens, size_t full_len)
{   
   for (size_t location = 0 ; location < full_len ; location++)
      {
      delete tokens[location] ;
      tokens[location] = 0 ;
      }
   FrFree(tokens) ;
   return ;
}

//----------------------------------------------------------------------

EBMTCandidate *find_recursive_chunks(Tokenizer *tokenizer,
				     FrTextSpans *input_lattice,
				     EBMTCorpus *corpus, int transmem_mode)
{
   size_t full_len = input_lattice->textLength() ;
   EbClearMatchCover() ;
   EbAlignCacheInit() ; //FIXME: maybe move this call elsewhere?
   TokenInfo **tokens = FrNewC(TokenInfo*,full_len+1) ;
   if (!tokens)
      {
      FrNoMemory("building token information array") ;
      return 0 ;
      }
   EBMTIndex *index = corpus->getIndex() ;
   EBMTCandidate *candidates ;
   candidates = find_generalized_chunks(input_lattice,corpus,tokenizer,
					tokens,index->numberCharMap()) ;
   if (!quiet_mode && !preparing_for_doc && (tokenizer || candidates))
      cerr << "; compositional matches = " << candidates->listlength() << endl;
   if (transmem_mode != EbTRANSMEM_OFF)
      {
      candidates->deleteList() ;
      candidates = 0 ;
      }
   EbMatchFrequency freqs(candidates,full_len,max_duplicates,max_duplicates1) ;
   EbCorpusMatches *matches = locate_matches(input_lattice,full_len,index,
					     tokens,transmem_mode,&freqs) ;
   if (preparing_for_doc)
      {
      candidates->deleteList() ;	// eliminate generalizations that
      candidates = 0 ;			//   got converted into translations
      size_t max = EbPrepDocMaxDups(corpus->getIndex()) ;
      matches = EbFilterMatches(matches,prepare_doc_minlen,max) ;
      while (matches)
	 {
	 matches->incrDocWeights(index) ;
	 EbCorpusMatches *m = matches ; 
	 matches = matches->next() ;
	 delete m ;
	 }
      }
   else
      {
      candidates = candidates->nconc(EbMakeCandidates(matches,input_lattice,
						      corpus,false,full_len)) ;
      }
   free_token_info(tokens,full_len) ;
   EbAlignCacheClear() ;
   return candidates ;
}

//----------------------------------------------------------------------

EbCorpusMatches *find_recursive_matches(Tokenizer *tokenizer,
					FrTextSpans *input_lattice,
					EBMTCorpus *corpus, int transmem_mode)
{
   size_t full_len = input_lattice->textLength() ;
   EbClearMatchCover() ;
   TokenInfo **tokens = FrNewC(TokenInfo*,full_len+1) ;
   if (!tokens)
      {
      FrNoMemory("building token information array") ;
      return 0 ;
      }
   EBMTIndex *index = corpus->getIndex() ;
   EBMTCandidate *candidates ;
   candidates = find_generalized_chunks(input_lattice,corpus,tokenizer,
					tokens,index->numberCharMap()) ;
   if (!quiet_mode && !preparing_for_doc && (tokenizer || candidates))
      cerr << "; compositional matches = " << candidates->listlength() << endl;
   candidates->deleteList() ;
   candidates = 0 ;
   EbCorpusMatches *matches = locate_matches(input_lattice,full_len,index,
					     tokens,transmem_mode,0) ;
   // since this function is called only to compute match statistics, and
   //   the returned EbCorpusMatches structures are never converted into
   //   EBMTCandidates, it is OK to free the TokenInfo structures even
   //   though the matches still have a pointer to the FrTextSpan in the
   //   TokenInfo
   free_token_info(tokens,full_len) ;
   EbAlignCacheClear() ;
   return matches ;
}

//----------------------------------------------------------------------

void find_source_cover(const FrTextSpan * const *spans, size_t numspans,
		       size_t index, size_t &start, size_t &end)
{
   if (spans)
      {
      size_t endword = spans[0]->wordCount() ;
      size_t i ;
      for (i = 0 ; endword <= index && i+1 < numspans ; i++)
	 {
	 endword += spans[i+1]->wordCount() ;
	 }
      start = spans[i]->start() ;
      end = spans[i]->end() ;
      }
   else
      {
      start = (size_t)~0 ;
      end = (size_t)~0 ;
      }
   return ;
}

//----------------------------------------------------------------------

FrList *EbWordAlignments(const EBMTCandidate *cand)
{
   if (cand && cand->wordAlignments())
      return (FrList*)cand->wordAlignments()->deepcopy() ;
   FrList *align ;
   FrList **end = &align ;
   if (cand && cand->bitext() && cand->targetWords())
      {
      BiTextMap *bitext = cand->bitext() ;
      size_t sstart = cand->sourceOffset() ;
      size_t tstart = cand->targetOffset() ;
      size_t tlen = EbWordCount(cand->targetWords()) ;
      size_t send = sstart + cand->matchLength() ;
      size_t tend = tstart + tlen ;
      for (size_t i = tstart ; i < tend ; i++)
	 {
	 FrList *corr = 0 ;
	 for (size_t j = sstart ; j < send ; j++)
	    {
	    if (bitext->wordsCorrespond(j,i))
	       {
	       size_t wordnum = j - sstart ;
	       size_t loc1, loc2 ;
	       find_source_cover(cand->spans(),cand->spansCovered(),
				 wordnum,loc1,loc2) ;
	       if (loc2 != loc1)
		  pushlist(new FrList(new FrInteger(loc1),makeSymbol("-"),
				      new FrInteger(loc2)),corr) ;
	       else if (loc1 != (size_t)~0)
		  pushlist(new FrInteger(loc1),corr) ;
	       else
		  pushlist(0,corr) ;
	       }
	    }
	 if (corr && !corr->rest())
	    align->pushlistend(poplist(corr),end) ;
	 else
	    align->pushlistend(listreverse(corr),end) ;
	 }
      }
   *end = 0 ;				// ensure proper termination
   return align ;
}

//----------------------------------------------------------------------

static FrSymbol *extra_spans = 0 ;

bool EbInsertExtraSpan(FrTextSpans *input_lattice, FrTextSpan *new_span)
{
   if (!extra_spans)
      extra_spans = makeSymbol("_EXTRA_SPANS_") ;
   if (input_lattice && new_span)
      {
      input_lattice->insertMetaData(extra_spans,new_span,false) ;
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

bool EbRemoveExtraSpans(FrTextSpans *input_lattice)
{
   if (input_lattice && extra_spans)
      return input_lattice->clearMetaData(extra_spans,false) ;
   return false ;
}

// end of file ebchunks.cpp //
