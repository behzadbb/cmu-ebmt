/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.94							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebcorpus.h	EBMT corpus manipulation			*/
/*  LastEdit: 25mar10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2001,2002,2003,2004,2005,	*/
/*		2006,2007,2008,2009,2010 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __EBCORPUS_H_INCLUDED
#define __EBCORPUS_H_INCLUDED

#include <stdio.h>
#include "FramepaC.h"
#include "ebindex.h"
#include "ebmt.h"

#if defined(__GNUC__)
#  pragma interface
#endif

/************************************************************************/
/************************************************************************/

#define MAX_CORPUS_LINE 8192		// longest line we can read from corpus

/************************************************************************/
/************************************************************************/

class BiTextMap ;
class Dictionary ;
class EbCorpusMetaInfo ;
class EbDataSource ;
class EbGenreSettings ;
class EBMTCandidate ;
class EBMTIndex ;
class EbAlignConstraints ;
class EbSentence ;

enum EbIndexSpec ;

//----------------------------------------------------------------------

class EbRefCounts
   {
   private:
      size_t m_examples ;
      unsigned char *m_counts ;
   public:
      EbRefCounts(size_t num_examples) ;
      ~EbRefCounts() ;

      // accessors
      size_t numExamples() const { return m_examples ; }
      size_t refCount(size_t N) const
	 { return (N < m_examples) ? m_counts[N] : 0 ; }

      // manipulators
      void clearCounts() ;
      void addReference(size_t N)
	 { if (N < numExamples() && m_counts[N] < UCHAR_MAX) m_counts[N]++ ; }
      void addReferences(size_t N, size_t refs)
	 { if (N < numExamples()) {
	    if ((m_counts[N] + refs) < UCHAR_MAX)
	       m_counts[N] += (unsigned char)refs ;
	    else
	       m_counts[N] = (unsigned char)UCHAR_MAX ; }
	 }
   } ;

//----------------------------------------------------------------------

class EBMTCorpus
   {
   private:
      Dictionary *dictionary ;		// bilingual dictionary
      EBMTIndex *index ;
      FrSymHashTable *sourcehash ;	// source language synonym lists
      FrSymHashTable *targethash ;	// target language synonym lists
      char *corpus_name ;
      char *tsyn_filename ;		// file containing TL synonym lists
      const char *cache_filename ;
      EBMTCorpus *next ;
      EbAlignConstraints *constraints ;
      EbRefCounts *m_refcounts ;
      FrMutex	m_mutex ;
      bool 	new_translations ;
      bool 	m_haverecstarts ;
      bool 	_enabled ;
      bool	m_temporary ;		// corpus is temp, may be erased
   public:
      EBMTCorpus(const char *corpusdir, const char *targetindex,
		 const char *cachefile, bool force_creation = false,
		 EBMTCorpus *nxt = 0, bool is_temporary = false) ;
      ~EBMTCorpus() ;

      bool exportCorpus(FILE *fp, EbIndexSpec which) ;
      bool exportCorpus(const char *exportfile) ;

      void setName(const char *name) ;
      void setAlignConstraints(const char *filename) ;
      void setTightlyBoundWords(const FrList *left, const FrList *right) ;
      bool addSourceSynonym(const char *word, const char *synonym) ;
      bool setSourceSynonymsUnaccented() ;
      bool loadSourceSynSets(const char *filename) ;
      void addTranslations(FrObject *sword, FrList *twords,
			   bool override_existing = false) ;
      void addTranslationsCounted(FrObject *sword, FrList *twords,
				  bool override_existing = false) ;
      FrList *getTranslations(FrSymbol *sword, size_t max = ~0) const ;
      bool storeTranslations() ;

      void disableCorpus() { _enabled = false ; }
      void enableCorpus() { _enabled = true ; }

      bool selectGenre(const char *genre_name, bool remember_prev = true) ;
      bool selectGenre(EbGenreSettings *genre) ;
      bool revertGenre() ;

      bool getExample(uint32_t position, EbSentence *&target,
		      EbCorpusMetaInfo &metainfo, size_t srclen,
		      bool ignore_bitext = false,
		      bool ignore_morphology = false) const ;
      const FrList *sourceSynonyms(const char *word) const ;
      FrList *getTargetRoots(const FrList *target_sentence) ;

      void setExampleWeight(EBMTCandidate *cand) const ;
      const EbDataSource *originOf(size_t example_number) const
	 { return index ? index->originOf(example_number) : 0 ; }
      double originWeight(size_t example_number,
			  const EbDataSource *source = 0) const
	 { return index ? index->originWeight(example_number,source) : 1.0 ; }

      bool initRefCounts() ;
      bool resetRefCounts() ;
      void addReference(size_t examplenum, size_t matchlen) ;
      void addReference(const EBMTCandidate *cand) ;
      size_t referenceCount(size_t examplenum) const ;
      double localContextBonus(size_t examplenum) const ;

      bool locateRecordStarts(EbBWTIndex *idx) ;
      bool locateRecordStarts() ; // run over all subindexes
      void freeRecordStarts() ;
      uint32_t recordStart(size_t N, EbIndexSpec which = EbIndex_Main) const 
	 { return index ? index->indexLocation(which,N) : (uint32_t)~0 ; }
      bool haveRecordStarts() const { return m_haverecstarts ; }

      bool eraseCorpusFiles() ;

      // access to internal state
      EBMTCorpus *nextCorpus() const { return next ; }
      EBMTIndex *getIndex() const { return index ; }
      FrVocabulary *getVocabulary() const { return index->vocabulary() ; }
      FrVocabulary *targetVocabulary() const
	    { return index->targetVocabulary() ; }
      bool targetGood() const { return tsyn_filename != 0 ; }
      bool addedTranslations() const { return new_translations ; }
      bool temporary() const { return m_temporary ; }
      Dictionary *getDictionary() const { return dictionary ; }
      const FrSymHashTable *sourceSynonyms() const { return sourcehash ; }
      const FrSymHashTable *targetSynonyms() const { return targethash ; }
      const EbAlignConstraints *alignConstraints() const { return constraints ; }
      bool enabled() const { return _enabled ; }
      const char *corpusName() const { return corpus_name ; }
   } ;

/************************************************************************/

FrList *preprocess_word_translations(const FrList *translations,
				     EBMTCorpus *corpus = 0) ;

#endif /* !__EBCORPUS_H_INCLUDED */

// end of file ebcorpus.h //
