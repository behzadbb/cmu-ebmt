/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.93							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebcmatch.h	EBMT corpus matches				*/
/*  LastEdit: 19mar10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __EBCMATCH_H_INCLUDED
#define __EBCMATCH_H_INCLUDED

#if defined(__GNUC__)
#  pragma interface
#endif

#include "FramepaC.h"

#ifndef __EBCHUNKS_H_INCLUDED
#include "ebchunks.h"
#endif

/************************************************************************/
/************************************************************************/

class EbCorpusMatches
   {
   private:
      static FrAllocator allocator ;
      EbCorpusMatches *m_next ;
      EbCorpusMatches *m_extends;	// the match record which this extends
      EbCorpusMatches *m_extendsr ; 	// the match extended in the other dir
      FrBWTLocationList *m_matches ;
      FrBWTLocationList *m_context ;
      FrList **m_backsubs ;
      const FrTextSpan **m_spans ; 	// which source spans were matched?
      double m_prob ;
      size_t m_gap ;
      EbUSHORT m_numspans ;		// how many source spans were matched?
      EbUSHORT m_matchlen ;		// number of words in corpus matches
      EbUSHORT m_inputmatch ;		// number of words in original input
      EbUSHORT m_numtokens ;
      EbIndexSpec m_which ;
      bool m_subsumed ;
   public:
      void *operator new(size_t) { return allocator.allocate() ; }
      void operator delete(void *blk) { allocator.release(blk) ; }
      EbCorpusMatches()
	 { m_matches = 0 ; m_matchlen = 0 ; clearGaps() ; m_prob = 1.0 ;
	   m_which = EbIndex_Main ; m_numtokens = 0 ; setInputMatch(0) ;
	   m_spans = 0 ; m_numspans = 0 ; m_backsubs = 0 ; m_next = 0 ;
	   m_subsumed = false ; }
      EbCorpusMatches(FrBWTLocationList *matched, EbIndexSpec which,
		      const EbCorpusMatches *oldmatch,
		      const class TokenInfo *extension,
		      size_t matchlen = 1,
		      EbCorpusMatches *next = 0) ;
      ~EbCorpusMatches() ;
      void deleteList() ;

      // accessors
      EbCorpusMatches *next() const { return m_next ; }
      EbCorpusMatches *extensionOf() const { return m_extends ; }
      EbCorpusMatches *extensionOfRev() const { return m_extendsr ; }
      const FrBWTLocationList *context() const { return m_context ; }
      bool subsumed() const { return m_subsumed ; }
      size_t numSpans() const { return m_numspans ; }
      size_t matchLength() const { return m_matchlen ; }
      size_t inputMatch() const { return m_inputmatch ; }
      size_t startPosition() const { return m_spans[0]->start() ; }
      size_t endPosition() const { return m_spans[matchLength()-1]->end() ; }
      size_t sourceOffset(size_t N) const
	 { return (N < matchLength()) ? m_spans[N]->start() : 0 ; }
      double probability() const { return m_prob ; }
      bool haveGap() const { return m_gap != 0 ; }
      size_t numGaps() const ;
      size_t gapPositions() const { return m_gap ; }
      bool gapAtOffset(size_t off) const
	 { return (m_gap & (1UL << off)) != 0 ; }
      FrBWTLocationList *matches() const { return m_matches ; }
      size_t totalMatches() const
	 { return m_matches ? m_matches->totalMatches() : 0 ; }
      const FrTextSpan **spans() const { return m_spans ; }
      const FrTextSpan *span(size_t N) const
	 { return (N < matchLength()) ? m_spans[N] : 0 ; }
      const FrList *backSubstitutions(size_t N) const
	 { return (N < matchLength()) ? m_backsubs[N] : 0 ; }
      EbIndexSpec whichIndex() const { return m_which ; }
      size_t numTokens() const { return m_numtokens ; }
      size_t listlength() const ;
      bool isExtensionOf(const EbCorpusMatches *) const ;

      // sorting support
      static int compare(const EbCorpusMatches &m1,
			 const EbCorpusMatches &m2) ;

      // manipulators
      void setNext(EbCorpusMatches *nxt) { m_next = nxt ; }
      void extensionOf(EbCorpusMatches *ext) { m_extends = ext ; }
      void extensionOfRev(EbCorpusMatches *ext) { m_extendsr = ext ; }
      void clearContext() ;
      void addContext(const EbCorpusMatches *, EBMTIndex *) ;
      void addContext(FrBWTLocation, EBMTIndex *) ;
      void addContextRev(const EbCorpusMatches *) ;
      void addContextRev(FrBWTLocation) ;
      void markSubsumed() { m_subsumed = true ; }
      void clearGaps() { m_gap = 0 ; }
      void addGap(size_t offset) { m_gap |= (1UL << offset) ; }
      void setIndex(EbIndexSpec which) { m_which = which ; }
      void setMatchLength(size_t len) { m_matchlen = (EbUSHORT)len ; }
      void setInputMatch(size_t len) { m_inputmatch = (EbUSHORT)len ; }
      void extendInputMatch(size_t len) { m_inputmatch += (EbUSHORT)len ; }
      void setProbability(double p) { m_prob = p ; }
      void moreTokens(size_t extra = 1) { m_numtokens += (EbUSHORT)extra ; }
      void backsubstitution(size_t N, const FrObject *bs)
	 { if (N < matchLength()) {
	    if (bs) pushlist(bs->deepcopy(),m_backsubs[N]) ;
	    else { free_object(m_backsubs[N]) ; m_backsubs[N] = 0 ; } }
	 }
      void insert(FrBWTLocation loc) ;
      void append(FrBWTLocation loc) ;
      EbCorpusMatches *reverseList() ;
      void clearMatches() { m_matches = 0 ; }
      void deleteMatches() { delete m_matches ; m_matches = 0 ; }
      void setMatches(FrBWTLocation loc) 
	 { delete m_matches ; m_matches = new FrBWTLocationList(loc) ; }
      void setMatches(FrBWTLocationList *loclist) 
	 { delete m_matches ; m_matches = loclist ; }
      void incrDocWeights(EBMTIndex *index) const ;

      // debugging support
      void dump(ostream &out) const ;
      void dump() const { dump(cerr) ; }
   } ;

#endif /* !__EBCMATCH_H_INCLUDED */

// end of file ebcmatch.h //
