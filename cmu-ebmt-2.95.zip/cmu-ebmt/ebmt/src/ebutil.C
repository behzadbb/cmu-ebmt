/************************************************************************/
/*									*/
/*  Example-Based Machine Translation					*/
/*  Version 2.91							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File ebutil.cpp	general utility functions			*/
/*  LastEdit: 15feb10							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2006,2007,2008,2009,2010 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "ebutil.h"
#include "ebglobal.h"

/************************************************************************/
/*    Manifest constants for this module				*/
/************************************************************************/

#define STRUCT_LATTICE_TAG "STRUCT_LATTICE"

/************************************************************************/
/*    Global data for this module					*/
/************************************************************************/

static const char spaces_only[] =
   {
      1, 0, 0, 0, 0, 0, 0, 0,	1, 1, 1, 1, 1, 1, 0, 0,	   // ^@ to ^O
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   // ^P to ^_
      1, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   // SP to /
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   //  0 to ?
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   //  @ to O
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   //  P to _
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   //  ` to o
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   //  p to DEL
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   // 0x80 to 0x8F
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   // 0x90 to 0x9F
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   // 0xA0 to 0xAF
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   // 0xB0 to 0xBF
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   // 0xC0 to 0xCF
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   // 0xD0 to 0xDF
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   // 0xE0 to 0xEF
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   // 0xF0 to 0xFF
   } ;

extern bool FramepaC_PnP_mode ;

/************************************************************************/
/************************************************************************/

//----------------------------------------------------------------------
// perform a case-insensitive equality comparison between a FrSymbol and
// a FrString or FrSymbol

bool EBMT_equal(FrSymbol *s1, const FrObject *s2)
{
   if (s1 == s2)
      return true ;
   else if (s1 && s2)
      {
      const char *str = s2->printableName() ;
      if (str)
	 return Fr_stricmp(s1->symbolName(),str,uppercase_table) == 0 ;
      }
   return false ;
}

//----------------------------------------------------------------------
// perform a case-insensitive equality comparison between two FrStrings
// or between a FrString and a Symbol (for other type combinations, fall
// back to default FramepaC comparison)

bool EBMT_equal(const FrObject *s1, const FrObject *s2)
{
   return equal_casefold(s1,s2,uppercase_table) ;
}

//----------------------------------------------------------------------
// compare two lists, performing case-insensitive equality comparison
// between any FrStrings they contain

bool EBMT_list_equiv(const FrList *l1, const FrList *l2)
{
   if (l1 == l2)			// must be equivalent if the same list
      return true ;
   else if (!l1 || !l2)			// can't be equiv if only one is NULL
      return false ;
   size_t len1 = l1->simplelistlength() ;
   size_t len2 = l2->simplelistlength() ;
   if (len1 != len2)
      return false ;			// ditto if lengths differ
   if (1 == len1)
      return equal_casefold(l1->first(),l2->first(),uppercase_table) ;
   const FrList *list1 = l1 ;
   for ( ; l1 ; l1 = l1->rest())
      {
      if (!l2->member(l1->first(),EBMT_equal))
	 return false ;
      }
   // at this point, we know that every item in 'l1' is contained in 'l2'
   // now check in the other direction
   for ( ; l2 ; l2 = l2->rest())
      {
      if (!list1->member(l2->first(),EBMT_equal))
	 return false ;
      }
   // At long last!  The lists are equivalent.
   return true ;
}

//----------------------------------------------------------------------

FrList *coerce_string_to_wordlist(const FrString *sent)
{
   bool force_uppercase = false ;
   char *input_sent 
      = FrCanonicalizeSentence(sent->stringValue(),char_encoding,
			       force_uppercase,word_delimiters,abbrevs_list) ;
   if (source_regex_list && input_sent)
      {
      FrString *tmp = EBMT_apply_regex(input_sent,source_regex_list) ;
      if (strcmp(tmp->stringValue(),input_sent) != 0)
	 {
	 FrFree(input_sent) ;
	 input_sent = FrCanonicalizeSentence(tmp->stringValue(),
					     char_encoding,force_uppercase,
					     word_delimiters,abbrevs_list) ;
	 }
      free_object(tmp) ;
      }
   FrList *wordlist = FrCvtSentence2Wordlist(input_sent) ;
   FrFree(input_sent) ;
   return wordlist ;
}

//----------------------------------------------------------------------

char *unaccent(const char *accented)
{
   static char unaccented[FrMAX_SYMBOLNAME_LEN+3] ;
   char *result = unaccented ;
   if (accented)
     {
     const unsigned char *un = ((char_encoding == FrChEnc_Latin2)
				? FramepaC_unaccent_table_Latin2
				: FramepaC_unaccent_table_Latin1) ;
     while (*accented)
	{
	*result++ = un[(unsigned char)(*accented)] ;
	accented++ ;
	}
     }
   *result = '\0' ;
   return unaccented ;
}

//----------------------------------------------------------------------

char *unaccent(const FrObject *word)
{
   if (word)
      {
      const char *accented = FrPrintableName(word) ;
      if (accented)
	 return unaccent(accented) ;
      else
	 {
//	 FrObjectType objtype = word->objType() ;
//	 switch (objtype)
	    {
	    // add any future expansion to other types here
//	    default:
	       return 0 ;
	    }
	 }
      }
   // if we get here, we were unable to do anything with 'word'
   return 0 ;
}

//----------------------------------------------------------------------

FrSymbol *cvt2unaccented_symbol(const FrObject *word)
{
   const char *unaccented = unaccent(word) ;
   if (unaccented)
      {
      if (*unaccented != '|')
	 {
	 char upcased[FrMAX_SYMBOLNAME_LEN+1] ;
	 strncpy(upcased,unaccented,FrMAX_SYMBOLNAME_LEN+1) ;
	 upcased[FrMAX_SYMBOLNAME_LEN] = '\0' ;
	 Fr_strupr(upcased,char_encoding) ;
	 return FrSymbolTable::add(upcased) ;
	 }
      else
	 return FrSymbolTable::add(unaccented) ;
      }
   else
      return 0 ;
}

//----------------------------------------------------------------------

const FrSymbol *map_number(const FrSymbol *number,
			   FrCasemapTable number_charmap)
{
   if (number && number_charmap)
      {
      char newnum[FrMAX_SYMBOLNAME_LEN+2] ;
      strcpy(newnum,number->symbolName()) ;
      FrMapString(newnum,number_charmap) ;
      return FrSymbolTable::add(newnum) ;
      }
   else
      return number ;
}

//----------------------------------------------------------------------

const FrSymbol *map_number(const char *number,
			   FrCasemapTable number_charmap)
{
   if (number && number_charmap)
      {
      char newnum[FrMAX_SYMBOLNAME_LEN+2] ;
      strcpy(newnum,number) ;
      FrMapString(newnum,number_charmap) ;
      return FrSymbolTable::add(newnum) ;
      }
   else if (number)
      return FrSymbolTable::add(number) ;
   else
      return 0 ;
}

//----------------------------------------------------------------------

static bool is_punct(const FrObject *obj)
{
   if (!obj)
      return false ;
   const char *word ;
   if (obj->stringp())
      word = ((FrString*)obj)->stringValue() ;
   else if (obj->symbolp())
      word = (char*)((FrSymbol*)obj)->symbolName() ;
   else
      return false ;
   if (word && *word)
      {
      while (*word)
	 {
	 if (!Fr_ispunct(*word))
	    return false ;
	 word++ ;
	 }
      return true ;
      }
   else
      return false ;
}

//----------------------------------------------------------------------

FrList *remove_punctuation(FrList *words)
{
   if (!words)
      return words ;
   // start by removing any leading punctuation
   while (words && is_punct(words->first()))
      {
      FrObject *word = poplist(words) ;
      free_object(word) ;
      }
   if (!words)
      return words ;
   // now remove any embedded punctuation
   FrList *wordlist = words ;
   FrList *prev = words ;
   words = words->rest() ;
   while (words)
      {
      if (is_punct(words->first()))
	 {
	 FrObject *word = poplist(words) ;
	 free_object(word) ;
	 prev->replacd(words) ;
	 }
      else
	 {
	 prev = words ;
	 words = words->rest() ;
	 }
      }
   return wordlist ;
}

//----------------------------------------------------------------------

FrList *EbFixDottedList(const FrList *original)
{
   FrList *fixed = 0 ;
   FrList **end = &fixed ;
   while (original)
      {
      if (original->consp())
	 {
	 const FrObject *head = original->first() ;
	 fixed->pushlistend(head ? head->deepcopy() : 0,end) ;
	 original = original->rest() ;
	 }
      else
	 {
	 fixed->pushlistend(makeSymbol("."),end) ;
	 fixed->pushlistend(original->deepcopy(),end) ;
	 break ;
	 }
      }
   *end = 0 ;				// terminate result list
   return fixed ;
}

//----------------------------------------------------------------------

FrList *EbStripMorph(FrList *words, FrCharEncoding enc)
{
   if (!morph_intro_str || !*morph_intro_str)
      {
      FrList *syms = FrCvtWordlist2Symbollist(words,enc) ;
      free_object(words) ;
      return syms ;
      }
   for (FrList *w = words ; w ; w = w->rest())
      {
      FrString *word = (FrString*)w->first() ;
      if (word && word->stringp())
	 {
	 const char *s = word->stringValue() ;
	 if (s)
	    {
	    const char *morph = strstr(s,morph_intro_str) ;
	    FrSymbol *sym ;
	    if (morph && morph != s && morph[strlen(morph_intro_str)])
	       {
	       char symname[FrMAX_SYMBOLNAME_LEN+1] ;
	       size_t len = morph - s ;
	       if (len >= sizeof(symname)) len = sizeof(symname) - 1 ;
	       memcpy(symname,s,len) ;
	       symname[len] = '\0' ;
	       sym = FrCvtString2Symbol(symname,enc) ;
	       }
	    else
	       sym = FrCvtString2Symbol(s,enc) ;
	    free_object(word) ;
	    w->replaca(sym) ;
	    }
	 }
      }
   return words ;
}

//----------------------------------------------------------------------

static bool is_tags_line(const char *line)
{
   // check whether the line contains any tags, which are indicated by the
   // first three non-whitespace characters being ";;;"
   if (FrSkipWhitespace(line) != ';')
      return false ;
   line++ ;
   if (FrSkipWhitespace(line) != ';')
      return false ;
   line++ ;
   if (FrSkipWhitespace(line) != ';')
      return false ;
   return true ;
}

//----------------------------------------------------------------------

FrString *EBMT_apply_regex(const char *line, FrRegExp *regex_list,
			   size_t charwidth, size_t stringlen)
{
   FrString *result = 0 ;
   if (regex_list && line && *line)
      {
      FrList *wordlist ;
      if (charwidth == 1)
	 wordlist = FrCvtString2Wordlist(line,word_delimiters,
					 abbrevs_list,char_encoding) ;
      else
	 {
	 if (stringlen == (size_t)-1)
	    stringlen = Fr_wcslen((FrChar16*)line) ;
	 wordlist = FrCvtUString2Wordlist((FrChar16*)line,stringlen,
					  word_delimiters,abbrevs_list) ;
	 }
      if (wordlist)
	 {
	 bool replacement = false ;
	 for (FrList *wl = wordlist ; wl ; wl = wl->rest())
	    {
	    FrString *word = (FrString*)wl->first() ;
	    if (!word)
	       continue ;
	    for (FrRegExp *re = regex_list ; re ; re = re->next())
	       {
	       FrObject *translation = re->match(word->stringValue()) ;
	       if (translation)
		  {
		  replacement = true ;
		  // remove the current word from the line
		  wl->replaca(0) ;
		  word->freeObject() ;
		  // now plug in the new one (may include embedded blanks,
		  // which will cause it to be treated as multiple words after
		  // we reassemble the line to return the updates)
		  wl->replaca(translation) ;
		  word = (FrString*)translation ;
		  }
	       }
	    }
	 if (replacement)
	    result = new FrString(wordlist,char_encoding) ;
	 else
	    result = new FrString(line) ;
	 wordlist->freeObject() ;
	 }
      else
	 result = new FrString(line) ;
      }
   else
      result = new FrString(line) ;
   return result ;
}

//----------------------------------------------------------------------

FrString *EBMT_apply_regex(FrString *line, FrRegExp *regex_list)
{
   if (line)
      return EBMT_apply_regex(line->stringValue(),regex_list,
			      line->charWidth(),line->stringLength()) ;
   else
      return 0 ;
}

//----------------------------------------------------------------------

FrTextSpans *EbMakeLattice(const FrObject *input, const FrList *classes,
			   bool keep_global_info)
{
   if (!input)
      return 0 ;
   FrTextSpans *lattice ;
   if (input->stringp())
      {
      FrList *wordlist = coerce_string_to_wordlist((FrString*)input) ;
      lattice = new FrTextSpans(wordlist) ;
      free_object(wordlist) ;
      }
   else
      lattice = new FrTextSpans(input,char_encoding,word_delimiters) ;
   (void)FrParseNamedEntityData(lattice,named_entity_spec,true) ;
   (void)FrParseMorphologyData(lattice,classes,morph_replace_text,
			       keep_global_info) ;
   lattice->sort() ;
   return lattice ;
}

//----------------------------------------------------------------------

void EbClearLattice(FrTextSpans *lattice)
{
   FrList *str_lat = (FrList*)lattice->metaData(STRUCT_LATTICE_TAG) ;
   if (str_lat && str_lat->consp())
      {
      FrTextSpans *slattice = (FrTextSpans*)str_lat->first() ;
      str_lat->replaca(0) ;
      delete slattice ;
      }
   return ;
}

//----------------------------------------------------------------------

FrTextSpans *EbGetStructuralLattice(FrTextSpans *lattice)
{
   FrList *str_lat = (FrList*)lattice->metaData(STRUCT_LATTICE_TAG) ;
   if (str_lat && str_lat->consp())
      return (FrTextSpans*)str_lat->first() ;
   return 0 ;
}

//----------------------------------------------------------------------

void EbStoreStructuralLattice(FrTextSpans *lattice,
			      FrTextSpans *struct_lattice)
{
   if (!lattice->metaData(STRUCT_LATTICE_TAG))
      lattice->setMetaData(makeSymbol(STRUCT_LATTICE_TAG),
			   new FrList((FrObject*)struct_lattice),false) ;
   return ;
}

//----------------------------------------------------------------------

void EbFreeLattice(FrTextSpans *lattice)
{
   if (lattice)
      {
      EbClearLattice(lattice) ;
      delete lattice ;
      }
   return ;
}

//----------------------------------------------------------------------

char *read_canon_line(FILE *fp, FrCharEncoding enc, bool *unicode_bswap,
		      FrCasemapTable charmap, const char *delim,
		      char const * const *abbrevs)
{
   if (!fp)
      return 0 ;
   char line[FrMAX_LINE] ;
   char *result = 0 ;
   memset(line,'\0',sizeof(line)) ;	// keep Purify and ValGrind happy
   do {
      if (result)
	 FrFree(result) ;
      line[0] = '\0' ;
      // read lines until we get a non-blank one.  This allows us to
      // read files with extraneous blank lines
      if (enc == FrChEnc_Unicode)
	 {
	 bool bswap = false ;
	 if (!unicode_bswap)
	    unicode_bswap = &bswap ;
	 bool oldcheck = FramepaC_check_Unicode_corruption ;
	 FramepaC_check_Unicode_corruption = true ;
	 bool success = Fr_utf8gets(fp,line,sizeof(line),*unicode_bswap)!=0 ;
	 FramepaC_check_Unicode_corruption = oldcheck ;
	 if (!success)
	    return 0 ;
	 }
      else if (!fgets(line,sizeof(line),fp))
	 return 0 ;
      // check whether the input line was longer than our buffer; if so,
      //   issue a warning and dump the rest of the line
      size_t len = strlen(line) ;
      if (len == sizeof(line)-1 && line[len-1] != '\n')
	 {
	 FrWarningVA("input line longer than %lu chars; remainder skipped",
		     (unsigned long)(sizeof(line)-1)) ;
	 if (enc == FrChEnc_Unicode)
	    {
	    while (!feof(fp) && Fr_ugets(fp,(FrChar16*)line,2,
					 *unicode_bswap) &&
		   *((FrChar16*)line) != '\n')
	       ;
	    }
	 else
	    {
	    while (!feof(fp) && fgetc(fp) != '\n')
	       ;
	    }
	 }
      // strip trailing whitespace, giving us an empty line if the line
      // consists entirely of whitespace
      char *lineptr = FrTrimWhitespace(line) ;
      if (charmap)
	 FrMapString(line,charmap) ;
      if (lineptr[0] != '\0')
	 {
	 if (is_tags_line(line))
	    result = FrDupString(line) ;
	 else
	    result = FrCanonicalizeSentence(line,enc,false,delim,abbrevs) ;
	 }
      } while (!result || !*result) ;
   return result ;			// successfully read a non-empty line
}

//----------------------------------------------------------------------

bool read_EBMT_entry(FILE *fp, FrCharEncoding encoding,
		     FrCasemapTable charmap,
		     char *&ssent, char *&tsent, char *&tags,
		     bool preserve_case, FrRegExp *source_re_list,
		     FrRegExp *target_re_list,
		     char const * const *abbrevs)
{
   if (!word_delimiters)
      EBMT_set_word_delimiters(encoding) ;
   ssent = read_canon_line(fp,encoding, &Unicode_bswap, charmap,
			   canonicalized_input_data ? spaces_only
			   			    : word_delimiters,
			   abbrevs) ;
   tags = 0 ;
   tsent = 0 ;
   size_t tags_len = 0 ;
   if (ssent && is_tags_line(ssent))
      {
      tags = ssent ;
      tags_len = strlen(tags) ;
      bool more_tags ;
      do {
         more_tags = false ;
         ssent = read_canon_line(fp,encoding, &Unicode_bswap, charmap,
				 canonicalized_input_data ? spaces_only
				 			  : word_delimiters,
				 abbrevs) ;
	 if (ssent && is_tags_line(ssent))
	    {
	    more_tags = true ;
	    char *add = strchr(ssent,'(') ;
	    if (add)
	       {
	       size_t add_len = strlen(add) ;
	       size_t new_len = tags_len + add_len + 1 ;
	       char *new_tags = FrNewR(char,tags,new_len) ;
	       if (new_tags)
		  {
		  tags = new_tags ;
		  memcpy(tags+tags_len,add,add_len+1) ;
		  tags_len += add_len ;
		  }
	       else
		  FrNoMemory("while accumulating meta-data for training example") ;
	       FrFree(ssent) ;
	       ssent = 0 ;
	       }
	    }
         } while (more_tags) ;
      }
   if (feof(fp))
      {
      FrFree(tags) ;
      tags = 0 ;
      FrFree(ssent) ;
      ssent = 0 ;
      return false ;
      }
   if (!ssent)
      {
      if (ferror(fp))
	 return false ;
      ssent = FrNew(char) ;
      *ssent = '\0' ;
      }
   if (monolingual_data)
      tsent = FrDupString(ssent) ;
   else
      tsent = FrReadCanonLine(fp,true,encoding,&Unicode_bswap,0,false,charmap,
			      canonicalized_input_data ? spaces_only
			      			       : word_delimiters,
			      abbrevs) ;
   if (!tsent)
      {
      if (ferror(fp))
	 {
	 FrFree(ssent) ;
	 ssent = 0 ;
	 return false ;
	 }
      tsent = FrNew(char) ;
      *tsent = '\0' ;
      }
   else if (verbose && is_tags_line(tsent))
      FrWarningVA("EBMT corpus out of sync -- got tags line ('%.20s')\n"
		"\tinstead of target language line; assumed source line was\n"
		"\t%.70s\n",tsent,ssent) ;
   if (reverse_languages)
      {
      char *tmp = ssent ;
      ssent = tsent ;
      tsent = tmp ;
      }
   if (!preserve_case)
      Fr_strlwr(ssent,encoding) ;
   if (source_re_list)
      {
      FrString *tmp = EBMT_apply_regex(ssent,source_re_list) ;
      if (strcmp(tmp->stringValue(),ssent) != 0)
	 {
	 FrFree(ssent) ;
	 ssent = FrCanonicalizeSentence(tmp->stringValue(),
					FrChEnc_RawOctets,false,
					word_delimiters,abbrevs) ;
	 }
      free_object(tmp) ;
      }
   if (target_re_list)
      {
      FrString *tmp = EBMT_apply_regex(tsent,target_re_list) ;
      if (strcmp(tmp->stringValue(),tsent) != 0)
	 {
	 FrFree(tsent) ;
	 tsent = FrCanonicalizeSentence(tmp->stringValue(),
					FrChEnc_RawOctets,false,
					word_delimiters,abbrevs) ;
	 }
      free_object(tmp) ;
      }
   return true ;
}

//----------------------------------------------------------------------

bool read_EBMT_entry(FILE *fp, FrCasemapTable charmap,
		       char *&ssent, char *&tsent, char *&tags,
		       bool preserve_case, FrRegExp *source_re_list,
		       FrRegExp *target_re_list,
		       char const * const *abbrevs)
{
   return read_EBMT_entry(fp,char_encoding,charmap,ssent,tsent,tags,
			  preserve_case,source_re_list,target_re_list,
			  abbrevs) ;
}

//----------------------------------------------------------------------

FrList *EbCvtString2Symbollist(const FrObject *str)
{
   const char *s = FrPrintableName(str) ;
   if (s)
      {
      char *dupstr = FrDupString(s) ;
      if (dupstr)
	 {
	 Fr_strlwr(dupstr,char_encoding) ;
	 char *canon = FrCanonicalizeSentence(dupstr,char_encoding,false,
					      spaces_only,0) ;
	 FrFree(dupstr) ;
	 FrList *symlist = 0 ;
	 if (canon)
	    {
	    symlist = FrCvtSentence2Symbollist(canon,FrChEnc_RawOctets) ;
	    FrFree(canon) ;
	    }
	 return symlist ;
	 }
      }
   return 0 ;
}


//----------------------------------------------------------------------

bool EbInputAlreadyCanonical(bool canon)
{
   bool old_canon = canonicalized_input_data ;
   canonicalized_input_data = canon ;
   return old_canon ;
}

/************************************************************************/
/************************************************************************/

enum LineType { LT_Source, LT_Target } ;

static const char *gen_name = "<GENERATE>" ;
static const char *nogen_name = "<NOGENERATE>" ;
static const char *recog_name = "<RECOGNIZE>" ;
static const char *norecog_name = "<NORECOGNIZE>" ;

//----------------------------------------------------------------------

static char *get_next_line(FILE *fp, int type, bool strict = false,
			   FrCasemapTable charmap = 0,
			   char const * const * abbrevs = 0)
{
   static char line[MAX_EBMT_LINE+1] ;
   static bool prefetched_line = false ;
   static LineType prefetched_type = LT_Source ;
   static FILE *prev_fp = 0 ;

   if (prev_fp != fp)			// can't use prefetched line if it's
      {
      prefetched_line = false ;		//  from another file!
      prev_fp = fp ;
      }
   if (prefetched_line)
      {
      // check if the request was for the same type of line as we already
      // prefetched on the last call
      if (prefetched_type == type)
	 {
	 prefetched_line = false ;
	 return line ;
	 }
      else
	 return 0 ;			// no more lines of requested type
      }
   else
      {
      // OK, we have to go read a line from the file
      do {
	 if (feof(fp))
	    return 0 ;
	 char *comment ;
	 bool leading_whitespace ;
	 bool old_pnp_mode = FramepaC_PnP_mode ;
	 FramepaC_PnP_mode = true ;
	 char *inputline = FrReadCanonLine(fp,!strict,char_encoding,
					   &Unicode_bswap,
					   &leading_whitespace,false,
					   charmap,word_delimiters,abbrevs) ;
	 line[0] = '\0' ;
	 if (!inputline)
	    break ;
	 if (strict && *inputline == '\0')
	    {
	    FrFree(inputline) ;
	    break ;
	    }
	 if (target_regex_list && (leading_whitespace == !reverse_languages))
	    {
	    FrString *tmp = EBMT_apply_regex(inputline,target_regex_list) ;
	    if (strcmp(tmp->stringValue(),inputline) != 0)
	       {
	       FrFree(inputline) ;
	       inputline = FrCanonicalizeSentence(tmp->stringValue(),
						  FrChEnc_RawOctets,false,
						  word_delimiters,abbrevs) ;
	       }
	    free_object(tmp) ;
	    }
	 else if (source_regex_list &&
		  (leading_whitespace == reverse_languages))
	    {
	    FrString *tmp = EBMT_apply_regex(inputline,source_regex_list) ;
	    if (strcmp(tmp->stringValue(),inputline) != 0)
	       {
	       FrFree(inputline) ;
	       inputline = FrCanonicalizeSentence(tmp->stringValue(),
						  FrChEnc_RawOctets,false,
						  word_delimiters,abbrevs) ;
	       }
	    free_object(tmp) ;
	    }
	 FramepaC_PnP_mode = old_pnp_mode ;
	 if (!inputline)
	    return 0 ;
	 int len ;
	 // can ignore all after semicolon, unless that semicolon is
	 // inside a string
	 bool in_string = false ;
	 comment = 0 ;
	 for (char *lp = inputline ; *lp ; lp++)
	    {
	    if (*lp == '"' && (lp == inputline || lp[-1] != '\\'))
		in_string = !in_string ;
	    else if (*lp == ';')
	       {
	       comment = lp ;
	       break ;
	       }
	    }
	 if (!comment)
	    {
	    // strip trailing newline, if present
	    len = strlen(inputline) ;
	    if (inputline[len-1] == '\n')
	       inputline[--len] = '\0' ;
	    }
	 else
	    {
	    *comment = '\0' ;
	    len = (comment - inputline) ;
	    }
	 // remove trailing whitespace
	 while (len > 0 && Fr_isspace(inputline[len-1]))
	    inputline[--len] = '\0' ;
	 if (leading_whitespace)
	    {
	    prefetched_type = LT_Target ;
	    char *tmp = inputline ;
	    while (Fr_isspace(*tmp))	// strip leading whitespace
	       tmp++ ;
	    strcpy(line,tmp) ;
	    }
	 else
	    {
	    prefetched_type = LT_Source ;
	    strcpy(line,inputline) ;
	    }
	 FrFree(inputline) ;
	 } while (line[0] == '\0') ;
      if (prefetched_type != type)
	 {
	 prefetched_line = true ;
	 return 0 ;			// reached end of section
	 }
      }
   return line ;
}

//----------------------------------------------------------------------

static void remove_marker(char *marker)
{
   char *start = marker ;
   marker = strchr(marker,'>') ;
   if (marker)
      {
      // zap the marker by copying the remainder of the string down
      marker++ ;
      if (*marker == ' ')
	 marker++ ;
      strcpy(start,marker) ;
      }
}

//----------------------------------------------------------------------

static bool remove_markers(char *line, const char *name)
{
   char *marker ;
   bool have_marker = false ;
   while ((marker = Fr_stristr(line,name)) != 0)
      {
      line = marker ;
      remove_marker(marker) ;
      have_marker = true ;
      }
   return have_marker ;
}

//----------------------------------------------------------------------

static FrList *get_line_group(FILE *fp,LineType type, bool strict = false,
			      bool reverse = false, FrCasemapTable charmap = 0,
			      bool *terminated = 0,
			      char const * const * abbrevs = 0)
{
   FrList *group = 0 ;
   int len = 0 ;
   char *line ;
   bool have_gen_marker = false ;
   bool have_recog_marker = false ;
   do {
      line = get_next_line(fp,type,strict,charmap,abbrevs) ;
      if (line)
	 {
	 if (strict)
	    {
	    // remove trailing whitespace, and then check for empty line
	    line = FrTrimWhitespace(line) ;
	    if (!*line && group)	// if blank line and we've already seen
	       {
	       if (terminated) *terminated = true ;
	       return listreverse(group) ;// non-blank line, end the group
	       }
	    }
	 else if (!*line)
	    continue ;
	 // strip out all the different markers, remembering which were present
	 bool nogen = have_gen_marker ;
	 bool norecog = have_recog_marker ;
	 if (remove_markers(line,nogen_name))
	    nogen = true ;
	 if (remove_markers(line,norecog_name))
	    norecog = true ;
	 bool gen = remove_markers(line,gen_name) ;
	 bool recog = remove_markers(line,recog_name) ;
	 if (gen)
	    {
	    have_gen_marker = true ;
	    if (type == LT_Target)
	       nogen = false ;
	    }
	 if (recog)
	    {
	    have_recog_marker = true ;
	    if (type == LT_Source)
	       norecog = false ;
	    }
	 // if we didn't have an appropriate no... marker, add the line
	 if ((reverse && !(type == LT_Target && norecog) &&
	      !(type == LT_Source && nogen)) ||
	     (!reverse && !(type == LT_Target && nogen) &&
	      !(type == LT_Source && norecog)))
	    {
	    line = FrTrimWhitespace(line) ;
	    pushlist(new FrString(line),group) ;
	    len += strlen(line) + 1 ;
	    }
	 }
      } while (line && len < MAX_EBMT_LINE-50) ;
   if (len >= MAX_EBMT_LINE-50)
      {
      FrWarning("Glossary entry too large (truncated).\n"
		"Split the entry into multiple entries next time.") ;
      poplist(group) ;
      while (get_next_line(fp,type,strict,0,abbrevs))
	 ;				// skip rest of section
      }
   return listreverse(group) ;
}

//----------------------------------------------------------------------

bool get_glossary_entry(FILE *fp, FrList *&source, FrList *&target,
			bool reverse_langs, bool strict,
			FrCasemapTable charmap, char const * const *abbrevs)
{
   if (!word_delimiters)
      EBMT_set_word_delimiters(char_encoding) ;
   // get the source line(s)
   bool terminated = false ;
   source = get_line_group(fp,LT_Source,strict,reverse_langs,charmap,
			   &terminated,abbrevs) ;
   // get the target line(s)
   if (!terminated)
      target = get_line_group(fp,LT_Target,false,reverse_langs,charmap,
			      0,abbrevs) ;
   else
      target = 0 ;
   if (reverse_langs)
      {
      FrList *tmp = source ;
      source = target ;
      target = tmp ;
      }
   return true ;
}

//----------------------------------------------------------------------

const char *first_corpus_dir(const FrList *corpus_dir_list)
{
   FrString *dir = 0 ;
   if (corpus_dir_list)
      dir = (FrString*)corpus_dir_list->first() ;
   return dir ? dir->stringValue() : "." ;
}

//----------------------------------------------------------------------

void EBMT_set_word_delimiters(FrCharEncoding enc)
{
   EBMT_set_word_delimiters(FrStdWordDelimiters(enc)) ;
   return ;
}

//----------------------------------------------------------------------

void EBMT_set_word_delimiters(const char *delimiters)
{
   char *delim = FrNewN(char,256) ;
   if (delim)
      {
      memcpy(delim,delimiters,256) ;
      FrFree(word_delimiters) ;
      word_delimiters = delim ;
      }
   return ;
}

//----------------------------------------------------------------------

void EbOutputSentenceCoverage(const char *cover, size_t cover_size,
			      size_t length)
{
   if ((verbose || compute_coverage) && length > 0)
      {
      int match_count = 0 ;
      for (size_t i = 0 ; i < length && i < cover_size ; i++)
	 {
	 if (cover[i])
	    match_count++ ;
	 }
      total_match_count += match_count ;
      if (verbose)
	 cerr << "; matched " << match_count << " of " << length
	      << " bytes (total " << total_match_count << " of "
	      << total_input_len << ")" << endl ;
      }
   return ;
}

//----------------------------------------------------------------------

size_t EbWordCount(const char *string)
{
   if (!string || !*string)
      return 0 ;
   size_t count = 1 ;
   for ( ; *string ; string++)
      {
      if (Fr_isspace(*string))
	 {
	 while (*string && Fr_isspace(*string))
	    string++ ;
	 count++ ;
	 }
      }
   return count ;
}

//----------------------------------------------------------------------

size_t EbWordCount(const FrString *words)
{
   return words ? EbWordCount(words->stringValue()) : 0 ;
}

//----------------------------------------------------------------------

size_t EbWordCount(const FrObject *words)
{
   if (!words)
      return 0 ;
   if (words->consp())
      return ((FrList*)words)->simplelistlength() ;
   return EbWordCount(words->printableName()) ;
}

// end of file ebutil.cpp //
