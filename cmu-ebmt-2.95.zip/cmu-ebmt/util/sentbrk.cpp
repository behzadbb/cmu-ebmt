/************************************************************************/
/*	SentBrk -- sentence breaker					*/
/*	v1.03								*/
/*	(c) 2001,2002,2006,2010 Ralf Brown				*/
/*	LastEdit: 01feb10						*/
/************************************************************************/

#ifdef unix
#include <unistd.h>   // for isatty()
#endif /* unix */
#include "FramepaC.h"

/************************************************************************/
/*	Global variables						*/
/************************************************************************/

static int linewrap_width = 0 ;
static int curr_column = 0 ;
static FrCharEncoding char_encoding = FrChEnc_Latin1 ;

// reduce code bloat a little
//FrReader _FrString::reader(0,0,0,'\0') ;
//FrReader _FrCons::reader(0,0,0,'\0') ;
//FrReader _FrNumber::reader(0,0,0,'\0') ;

/************************************************************************/
/************************************************************************/

static void ResetLineWrap(ostream &out)
{
   if (curr_column > 0)
      out << endl ;
   else
      out << flush ;
   curr_column = 0 ;
   return ;
}

//----------------------------------------------------------------------

static void LineWrap(ostream &out, const char *line, FrBool recursive = False)
{
   if (linewrap_width <= 0)
      {
      if (line && *line)
	 out << line ;
      else
	 out << ' ' ;
      curr_column++ ;		// we have output, so will need newline later
      return ;
      }
   int len = strlen(line) ;
   int remaining = linewrap_width - curr_column ;
   if (len <= remaining)
      {
      if (len > 0)
	 {
	 out << line ;
	 curr_column += len ;
	 }
      }
   else
      {
      const char *end = line + remaining ;
      while (end > line && !Fr_isspace(*end))
	 end-- ;
      if (end <= line)
	 {
	 for (end = line + remaining ; *end && !Fr_isspace(*end) ; end++)
	    ;
	 if (end - line >= 2*remaining && curr_column > 0)
	    end = line ;
	 }
      if (end != line)
	 out.write(line,end-line) ;
      out << endl ;
      curr_column = 0 ;
      if (*end)
	 LineWrap(out,(end==line)?line:end+1,True) ;
      }
   if (!recursive && curr_column < linewrap_width && len > 0)
      {
      out << ' ' ;
      curr_column++ ;
      }
   return ;
}

//----------------------------------------------------------------------

static FrList *split_off_sentence(char *&linebuf, const char *sentbreak,
				  size_t &buflen, FrList *sentences,
				  size_t &numlines)
{
   // split the combined line into two pieces; put the first
   // piece on the list of sentences and move the second piece
   // up to the beginning of the accumulation buffer
   const char *sent = linebuf ;
   while (Fr_isspace(*sent))
      sent++ ;
   size_t sentlen = sentbreak - sent ;
   const char *end = sentbreak - 1 ;
   while (end > sent && sentlen > 0 && Fr_isspace(*end))
      {
      end-- ;
      sentlen-- ;
      }
//   if (Unicode)
//      pushlist(new FrString(sent,sentlen/sizeof(FrChar16),sizeof(FrChar16)),
//	       sentences) ;
//   else
      pushlist(new FrString(sent,sentlen),sentences) ;
   sentlen = sentbreak - linebuf ;
   numlines++ ;
   memcpy(linebuf,sentbreak,buflen-sentlen+1) ;
   buflen -= sentlen ;
   linebuf = FrNewR(char,linebuf,buflen+1) ;
   return sentences ;
}

//----------------------------------------------------------------------

static FrList *split_off_sentences(char *&linebuf, FrList *lines,
				   size_t &buflen, size_t &numlines)
{
   const char *sentbreak = FrSentenceBreak(linebuf,char_encoding) ;
   if (sentbreak)
      {
      while (sentbreak)
	 {
	 lines = split_off_sentence(linebuf,sentbreak,buflen,lines,numlines) ;
	 sentbreak = FrSentenceBreak(linebuf,char_encoding) ;
	 }
      }
   return lines ;
}

//----------------------------------------------------------------------

FrList *SplitIntoSentences(char *&partial, char *line)
{
   FrList *sentences = 0 ;
   // if the new input line is empty or a command, the prior partial
   //   sentence is now complete
   if (!line || !*line)
      {
      pushlist(new FrString(partial ? partial : ""),sentences) ;
      partial = 0 ;
      }
   else
      {
      // append the new input to the prior partial sentence and check
      //   whether the result contains a sentence break
      size_t len1 = partial ? strlen(partial) : 0 ;
      size_t len2 = strlen(line) ;
      char *newline = FrNewR(char,partial,len1+len2+2) ;
      if (newline)
	 {
	 if (len1 > 0)
	    newline[len1++] = ' ' ; // ensure word break on line boundary
	 memcpy(newline+len1,line,len2+1) ;
	 size_t buflen = len1+len2 ;
	 size_t numlines = 0 ;
	 sentences = split_off_sentences(newline,sentences,buflen,numlines) ;
	 partial = newline ;
	 }
      else
	 FrNoMemory("while accumulating free-form sentence") ;
      }
   return listreverse(sentences) ;
}

//----------------------------------------------------------------------

static void get_line(istream &in, char *line, size_t maxline)
{
   if (!line || maxline == 0)
      return ;
//   if (Unicode)
//      {
//      if (!Fr_ugets(in,(FrChar16*)line,maxline/sizeof(FrChar16),Unicode_bswap))
//	 *((FrChar16*)line) = '\0' ;
//      }
//   else
      {
      line[maxline-1] = '\0' ;
      in.clear() ;			// clear any exceptional conditions
      in.getline(line,maxline) ;
      // remove any trailing newline and whitespace
      char *end = strchr(line,'\0') ;
      while (end > line && (end[-1] == '\n' || Fr_isspace(end[-1])))
	 *--end = '\0' ;
      }
   return ;
}

//----------------------------------------------------------------------

inline FrBool blank_line(const char *line)
{
//   if (Unicode)
//      return ((FrChar16*)line)[0] == 0 ;
//   else
      return line[0] == '\0' ;
}

//----------------------------------------------------------------------

static FrList *accumulate_sentences(istream &in, char *&linebuf,
				    size_t &buflen)
{
   FrList *lines = 0 ;
   size_t numlines = 0 ;
   FrBool done = False ;
   do {
      char line[FrMAX_LINE+1] ;
      ((FrChar16*)line)[0] = 0 ;
      get_line(in,line,FrMAX_LINE) ;
      // flush all buffered data on paragraph break or EOF
      if (blank_line(line) || in.eof())
	 {
	 if (buflen > 0)
	    {
//  	    if (Unicode)
//	       pushlist(new FrString(linebuf,Fr_ustrlen((FrChar16*)line),
//				     sizeof(FrChar16)),
//		        lines) ;
//	    else
	       pushlist(new FrString(linebuf),lines) ;
	    }
	 if (!in.eof())
	    numlines++ ;
	 FrFree(linebuf) ;
	 linebuf = 0 ;
	 buflen = 0 ;
	 done = True ;
	 break ;
	 }
      if (*line)
	 {
	 // combine the new input line with any previously-buffered data
	 size_t linelen = strlen(line) ;
	 size_t newlen = buflen + linelen + 1 ;
	 char *newbuf = FrNewR(char,linebuf,newlen+1) ;
	 if (!newbuf)
	    {
	    FrNoMemory("while accumulating multi-line sentence") ;
	    break ;
	    }
	 linebuf = newbuf ;
	 if (buflen > 0)
	    linebuf[buflen++] = ' ' ;	// ensure word break on line boundary
	 strcpy(linebuf+buflen,line) ;
	 buflen += linelen ;
	 lines = split_off_sentences(linebuf,lines,buflen,numlines) ;
	 }
      else
	 {
//	 if (Unicode)
//	    pushlist(new FrString(line,Fr_ustrlen((FrChar16*)line),
//				  sizeof(FrChar16)),
//		     lines) ;
//	 else
	    pushlist(new FrString(line),lines) ;
	 numlines++ ;
	 }
      } while (!done) ;
   return listreverse(lines) ;
}

//----------------------------------------------------------------------

static void usage(const char *argv0)
{
   cerr << "Usage: " << argv0 << " [options] <input [>output]\n"
	<< "Options:\n"
	<< "\t-aFILE\tread non-breaking abbreviations from FILE\n"
	<< "\t-bTXT\tset begin-sentence marker to TXT\n"
	<< "\t-eTXT\tset end-sentence marker to TXT\n"
	<< "\t-m\tshow memory usage\n"
	<< "\t-p\tinsert blank lines between sentences\n"
	<< "\t-wN\tword-wrap to N columns (0 = no wrapping)\n"
	<< endl ;
}

//----------------------------------------------------------------------

int main(int argc, char **argv)
{
   const char *argv0 = argv[0] ;
   if (isatty(fileno(stdin)) && argc == 1)
      {
      usage(argv0) ;
      return 1 ;
      }
   FrBool insert_blank_lines = False ;
   FrBool showmem = False ;
   const char *begin_marker = "" ;
   const char *end_marker = "" ;
   const char *abbrev_file = 0 ;
   while (argc > 1 && argv[1][0] == '-')
      {
      switch (argv[1][1])
	 {
	 case 'a':
	    abbrev_file = argv[1]+2 ;
	    break ;
	 case 'b':
	    begin_marker = argv[1]+2 ;
	    break ;
	 case 'e':
	    end_marker = argv[1]+2 ;
	    break ;
	 case 'm':
	    showmem = True ;
 	    break ;
	 case 'p':
	    insert_blank_lines = True ;
	    break ;
	 case 'w':
	    linewrap_width = atoi(argv[1]+2) ;
	    break ;
	 default:
	    cerr << "Unrecognized option " << argv[1] << endl ;
	    usage(argv0) ;
	    return 2 ;
	 }
      argv++ ;
      argc-- ;
      }
   FrList *abbrevs = 0 ;
   if (abbrev_file && *abbrev_file)
      {
      FILE *fp = fopen(abbrev_file,"r") ;
      if (fp)
	 {
	 while (!feof(fp) && !ferror(fp))
	    {
	    char line[FrMAX_LINE];
	    if (!fgets(line,sizeof(line),fp))
	       break ;
	    char *lineptr = line ;
	    FrSkipWhitespace(lineptr) ;
	    char *end = lineptr ;
	    while (*end && !Fr_isspace(*end))
	       end++ ;
	    *end = '\0' ;
	    pushlist(new FrString(lineptr),abbrevs) ;
	    }
	 fclose(fp) ;
	 }
      }
   else
      {
      const char *abbr = "(\"Mr\" \"Mrs\" \"Ms\" \"Dr\" \"Rev\" \"Fr\" \"Rep\""
	 "\"Hon\" \"Sr\" \"Jr\" \"St\" \"Ave\" \"Blvd\" \"a.m\" \"p.m\""
	 "\"m\" \"Gen\")" ;
      abbrevs = (FrList*)string_to_FrObject(abbr) ;
      }
   FrSetNonbreakingAbbreviations(abbrevs) ;
   if (!*begin_marker)
      begin_marker = 0 ;
   if (!*end_marker)
      end_marker = 0 ;
   char *linebuf = 0 ;
   size_t buflen = 0 ;
   while (!cin.eof() && !feof(stdin))
      {
      FrList *sentences = accumulate_sentences(cin,linebuf,buflen) ;
      if (!sentences)
	 cout << endl ;
      while (sentences)
	 {
	 FrString *sent = (FrString*)poplist(sentences) ;
	 if (begin_marker)
	    {
	    LineWrap(cout,begin_marker) ;
	    LineWrap(cout,"") ;
	    }
	 else
	    ResetLineWrap(cout) ;
	 LineWrap(cout,(char*)sent->stringValue()) ;
	 free_object(sent) ;
	 if (end_marker)
	    {
	    LineWrap(cout,"") ;
	    LineWrap(cout,end_marker) ;
	    }
	 if (insert_blank_lines)
	    ResetLineWrap(cout) ;
	 else
	    LineWrap(cout,"") ;
	 }
      ResetLineWrap(cout) ;
      cout << endl ;
      }
   cout << flush ;
   if (showmem)
      FrMemoryStats(cerr) ;
   return 0 ;
}
