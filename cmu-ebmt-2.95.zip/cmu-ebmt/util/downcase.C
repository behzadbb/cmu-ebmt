/****************************** -*- C++ -*- *****************************/
/*  DownCase -- remove sentence-initial capitalization			*/
/*  Version 0.90							*/
/*  LastEdit: 11may10							*/
/*									*/
/*  (c) Copyright 2006,2007,2008,2010 Ralf Brown			*/
/*	This software may be used for educational and non-commercial	*/
/*	research purposes.  Any other use requires prior permission	*/
/*	from Ralf Brown or the Carnegie Mellon University Language	*/
/*	Technologies Institute.						*/
/*									*/
/************************************************************************/

#include "FramepaC.h"
#include "ebutil.h"

/************************************************************************/
/*	Manifest constants						*/
/************************************************************************/

#define VERSION_STR "0.90"

// filename extension for downcased output files
#define CONV_EXT "uncap"

// relative weight of words that DON'T start a sentence
#define NON_INITIAL_WEIGHT	3

#define CONCAT_MARKER		'\t'

/************************************************************************/
/*	Global variables						*/
/************************************************************************/

static FrCharEncoding char_encoding = FrChEnc_Latin1 ;
static bool reverse_languages = false ;
static bool canon_input = false ;

static const char spaces_only[] =
   {
      1, 0, 0, 0, 0, 0, 0, 0,	1, 1, 1, 1, 1, 1, 0, 0,	   // ^@ to ^O
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   // ^P to ^_
      1, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   // SP to /
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   //  0 to ?
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   //  @ to O
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   //  P to _
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   //  ` to o
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   //  p to DEL
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   // 0x80 to 0x8F
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   // 0x90 to 0x9F
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   // 0xA0 to 0xAF
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   // 0xB0 to 0xBF
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   // 0xC0 to 0xCF
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   // 0xD0 to 0xDF
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   // 0xE0 to 0xEF
      0, 0, 0, 0, 0, 0, 0, 0,	0, 0, 0, 0, 0, 0, 0, 0,	   // 0xF0 to 0xFF
   } ;

/************************************************************************/
/************************************************************************/

static FrBool clear_frame(const FrObject *obj, va_list)
{
   FrSymbol *sym = reinterpret_cast<FrSymbol*>(const_cast<FrObject*>(obj)) ;
   if (sym)
      sym->setFrame(0) ;
   return True ;
}

//----------------------------------------------------------------------

static void clear_frames(FrSymbolTable *symtab)
{
   if (symtab)
      symtab->iterate(clear_frame) ;
   return ;
}

//----------------------------------------------------------------------

static FrBool valid_filename(const char *filename)
{
   if (!filename || !*filename)
      return False ;
   char first = FrSkipWhitespace(filename) ;
   if (first == '#' || first == ';')
      return False ;
   return (*filename != '\0') ;
}

//----------------------------------------------------------------------

static FrBool is_punctuation(const char *word)
{
   if (word && *word && Fr_ispunct(word[0]))
      return True ;
   return False ;
}

//----------------------------------------------------------------------

static FrSymbol *concat_words(const char *w1, const char *w2,
			      FrBool create = False)
{
   if (!w1 || !w2)
      return 0 ;
   char wordpair[2*FrMAX_SYMBOLNAME_LEN+1] ;
   size_t len1 = strlen(w1) ;
   size_t len2 = strlen(w2) ;
   if (len1 >= lengthof(wordpair)-1)
      len1 = lengthof(wordpair) - 2 ;
   if (len1 + len2 >= lengthof(wordpair)-1)
      len2 = lengthof(wordpair) - len1 - 2 ;
   memcpy(wordpair,w1,len1) ;
   wordpair[len1] = CONCAT_MARKER ;
   memcpy(wordpair+len1+1,w2,len2) ;
   wordpair[len1+len2+1] = '\0' ;
   if (create)
      return FrSymbolTable::add(wordpair) ;
   else
      return findSymbol(wordpair) ;
}

//----------------------------------------------------------------------

static FrBool all_caps(const char *text)
{
   if (!text)
      return False ;
   for ( ; *text ; text++)
      {
      if (Fr_islower(*text))
	 return False ;
      }
   return True ;
}

//----------------------------------------------------------------------

static FrList *collect_files(const char *listfile, int argc, char **argv)
{
   FrList *files = 0 ;
   if (listfile)
      {
      FILE *fp = fopen(listfile,"r") ;
      if (fp)
	 {
	 while (!feof(fp))
	    {
	    char line[FrMAX_LINE] ;
	    if (!fgets(line,sizeof(line),fp))
	       break ;
	    char *lineptr = line ;
	    lineptr = FrTrimWhitespace(lineptr) ;
	    if (valid_filename(lineptr))
	       pushlist(new FrString(lineptr),files) ;
	    }
	 }
      else
	 cout << "! unable to open " << listfile << " to get list of files"
	      << endl ;
      }
   while (argc > 1)
      {
      if (valid_filename(argv[1]))
	 pushlist(new FrString(argv[1]),files) ;
      argc-- ;
      argv++ ;
      }
   return listreverse(files) ;
}

//----------------------------------------------------------------------

static void swap_halves(char *&src, char *&tgt)
{
   if (reverse_languages)
      {
      char *tmp = src ;
      src = tgt ;
      tgt = tmp ;
      }
   return ;
}

//----------------------------------------------------------------------

static void collect_external_statistics(const char *file, size_t N)
{
   if (!file || !*file)
      return ;				// no external statistics file
   if (N > 1)
      return ;				// only do unigrams right now
   FILE *fp = fopen(file,"r") ;
   if (!fp)
      {
      FrWarningVA("unable to open '%s' for reading",file) ;
      return ;
      }
   cout << "  reading " << file << endl ;
   while (!feof(fp))
      {
      char buf[FrMAX_LINE] ;
      if (!fgets(buf,sizeof(buf),fp))
	 break ;
      char *word = FrTrimWhitespace(buf) ;
      char *last_blank = strrchr(word,' ') ;
      char *last_tab = strrchr(word,'\t') ;
      char *end = last_blank ;
      if (!end || (last_tab && last_blank && last_tab < last_blank))
	 end = last_tab ;
      if (!end || end == buf)
	 continue ;			// malformed line
      *end++ = '\0' ;			// split off frequency count
      size_t count = strtoul(end,0,0) ;
      if (count > 0)
	 {
	 FrSymbol *wordsym = makeSymbol(word) ;
	 // stuff the count into the otherwise unused frame pointer
	 if (wordsym)
	    {
	    size_t oldcount = (size_t)wordsym->symbolFrame() ;
	    wordsym->setFrame((FrFrame*)(oldcount + count)) ;
	    }
	 }
      }
   fclose(fp) ;
   return ;
}

//----------------------------------------------------------------------

static void collect_statistics(const char *file, FrBool monolingual)
{
   FILE *fp = fopen(file,"r") ;
   if (fp)
      {
      cout << "  processing " << file << endl ;
      while (!feof(fp))
	 {
	 char *ssent ;
	 char *tsent ;
	 char *tags ;
	 FrBool success ;
	 if (monolingual)
	    {
	    ssent = 0 ;
	    tsent = FrReadCanonLine(fp,True,char_encoding,0,0,False,0,0,0) ;
	    tags = 0 ;
	    success = (tsent != 0) ;
	    }
	 else
	    {
	    success = read_EBMT_entry(fp,char_encoding,0,ssent,tsent,
				      tags,True) ;
	    swap_halves(ssent,tsent) ;
	    }
	 FrBool caps = all_caps(tsent) ;
	 if (success)
	    {
	    FrList *words = FrCvtString2Wordlist(tsent) ;
	    size_t weight = 1 ;
	    for (FrList *w = words ; w ; w = w->rest())
	       {
	       const char *str = FrPrintableName(w->first()) ;
	       if (!str)
		  continue ;
	       if (is_punctuation(str))
		  {
		  if (*str == '.')
		     weight = 1 ;	// may be a multi-sentence line
		  continue ;
		  }
	       FrSymbol *word = makeSymbol(str) ;
	       // stuff the count into the otherwise unused frame pointer
	       if (word)
		  {
		  size_t count = (size_t)word->symbolFrame() ;
		  word->setFrame((FrFrame*)(count+weight)) ;
		  // give more weight to words that don't start a sentence,
		  //   since the initial word will almost always be
		  //   capitalized, unless the sentence is all-caps
		  if (!caps)
		     weight = NON_INITIAL_WEIGHT ;
		  }
	       if (w->rest() && weight == NON_INITIAL_WEIGHT)
		  {
		  // collect counts for capitalized bigrams
		  const char *str2 = FrPrintableName(w->rest()->first()) ;
		  if (str2 && Fr_isupper(str2[0]))
		     {
		     FrSymbol *wordpair = concat_words(str,str2,True) ;
		     if (wordpair)
			{
			size_t count = (size_t)wordpair->symbolFrame() ;
			wordpair->setFrame((FrFrame*)(count+weight)) ;
			}
		     }
		  }
	       }
	    free_object(words) ;
	    }
	 FrFree(tags) ;
	 FrFree(ssent) ;
	 FrFree(tsent) ;
	 }
      fclose(fp) ;
      }
   else
      cout << "! unable to open " << file << " !" << endl ;
   return ;
}

//----------------------------------------------------------------------

static FrBool make_conversion(const FrObject *obj, va_list args)
{
   FrVarArg(FrSymbolTable*,symtab) ;
   FrVarArg(FrSymHashTable*,conv_ht) ;
   FrSymbol *sym = reinterpret_cast<FrSymbol*>(const_cast<FrObject*>(obj)) ;
   const char *symname = sym->symbolName() ;
   char *lowercase = FrDupString(symname) ;
   char *marker ;
   if ((marker = strchr(lowercase,CONCAT_MARKER)) != 0)
      {
      // only lowercase the first word, since we know that the second is always
      //   capitalized
      *marker = '\0' ;
      Fr_strlwr(lowercase,char_encoding) ;
      *marker = CONCAT_MARKER ;
      }
   else
      Fr_strlwr(lowercase,char_encoding) ;
   if (strcmp(symname,lowercase) != 0)
      {
      FrSymbol *lsym = symtab->lookup(lowercase) ;
      size_t count = reinterpret_cast<size_t>(sym->symbolFrame()) ;
      if (lsym)
	 {
	 size_t lcount = reinterpret_cast<size_t>(lsym->symbolFrame()) ;
         if (lcount > count)
	    conv_ht->add(sym,lsym) ;
	 }
      }
   FrFree(lowercase) ;
   return True ;
}

//----------------------------------------------------------------------

static void make_conversion_table(FrSymHashTable &conv_ht)
{
   FrSymbolTable *symtab = FrSymbolTable::current() ;
   symtab->iterate(make_conversion,symtab,&conv_ht) ;
   return ;
}

//----------------------------------------------------------------------

static void downcase(char *line, const FrSymHashTable &conv_ht)
{
   // skip over leading whitespace and punctuation marks
   while (Fr_ispunct(FrSkipWhitespace(line)))
      line++ ;
   // convert the rest of the text line into a list of words
   FrList *words = FrCvtString2Wordlist(line,0,False) ;
   if (!words)
      return ;
   FrBool caps = all_caps(line) ;
   FrBool first = True ;
   do {
      // now lowercase the first word if appropriate
      FrObject *word = poplist(words) ;
      const char *firstword = FrPrintableName(word) ;
      const char *secondword = FrPrintableName(words ? words->first() : 0) ;
      if (secondword && !Fr_isupper(secondword[0]))
	 secondword = 0 ;		// only bother if second word is uc
      line = strstr(line,firstword) ;
      if (firstword && line)
	 {
	 FrSymHashEntry *ent ;
	 FrSymbol *pair = concat_words(firstword,secondword) ;
	 FrSymbol *first = makeSymbol(firstword) ;
	 if (pair)
	    ent = conv_ht.lookup(pair) ;
	 else
	    ent = conv_ht.lookup(first) ;
	 if (!ent && caps)
	    {
	    char *capword = FrDupString(firstword) ;
	    const char *downcased = 0 ;
	    if (capword)
	       {
	       Fr_strlwr(capword+1,char_encoding) ;
	       first = findSymbol(capword) ;
	       if (first)
		  {
		  downcased = first->symbolName() ;
		  ent = conv_ht.lookup(first) ;
		  }
	       if (!ent)
		  {
		  Fr_strlwr(capword,char_encoding) ;
		  first = findSymbol(capword) ;
		  if (first)
		     {
		     downcased = first->symbolName() ;
		     ent = conv_ht.lookup(first) ;
		     }
		  }
	       FrFree(capword) ;
	       if (!ent && downcased)
		  memcpy(line,downcased,strlen(downcased)) ;
	       }
	    }
	 if (ent)
	    {
	    const char *downcased = FrPrintableName(ent->getValue()) ;
	    if (downcased && strlen(downcased) == strlen(firstword))
	       {
	       char *term = strchr(downcased,CONCAT_MARKER) ;
	       if (!term)
		  term = strchr(downcased,'\0') ;
	       memcpy(line,downcased,term-downcased) ;
	       }
	    }
	 line += strlen(firstword) ;
	 }
      else
	 break ;
      first = False ;
      // if all-caps text, downcase all of the words in the line
      } while (words && caps) ;
   free_object(words) ;
   return ;
}

//----------------------------------------------------------------------

static void convert_case(const char *src, const char *dest,
			 const FrSymHashTable &conv_ht, FrBool monolingual)
{
   FILE *srcfp = fopen(src,"r") ;
   FILE *outfp = fopen(dest,"w") ;
   if (srcfp && outfp)
      {
      cout << "  processing " << src << endl ;
      while (!feof(srcfp))
	 {
	 char *ssent ;
	 char *tsent ;
	 char *tags ;
	 FrBool success ;
	 if (monolingual)
	    {
	    ssent = FrReadCanonLine(srcfp,True,char_encoding,0,0,False,0,
				    canon_input?spaces_only:0,0) ;
	    tsent = 0 ;
	    tags = 0 ;
	    success = (ssent != 0) ;
	    }
	 else
	    {
	    success = read_EBMT_entry(srcfp,char_encoding,0,ssent,tsent,
				      tags,True) ;
	    }
	 if (success)
	    {
	    if (tags)
	       {
	       fputs(tags,outfp) ;
	       fputc('\n',outfp) ;
	       }
	    if (monolingual || reverse_languages)
	       downcase(ssent,conv_ht) ;
	    else
	       downcase(tsent,conv_ht) ;
	    fputs(ssent,outfp) ;
	    fputc('\n',outfp) ;
	    if (!monolingual)
	       {
	       fputs(tsent,outfp) ;
	       fputc('\n',outfp) ;
	       fputc('\n',outfp) ;
	       }
	    }
	 FrFree(tags) ;
	 FrFree(ssent) ;
	 FrFree(tsent) ;
	 }
      }
   if (srcfp)
      fclose(srcfp) ;
   else
      cout << "! Unable to open " << src << " for reading !" << endl ;
   if (outfp)
      fclose(outfp) ;
   else
      cout << "! Unable to open " << dest << " for writing !" << endl ;
   return ;
}

//----------------------------------------------------------------------

static FrBool show_conversion(FrSymHashEntry *entry, va_list)
{
   if (entry)
      cout << ' ' << entry->getName() << " ==> " << entry->getValue() << endl ;
   return True ;
}

//----------------------------------------------------------------------

static void convert(const FrList *filelist, const char *new_ext,
		    const char *wordfreq_file,
		    FrBool dump_conversions, FrBool monolingual,
		    const char *out_dir)
{
   cout << "Collecting capitalization statistics" << endl ;
   FrSymbolTable *symtab = new FrSymbolTable ;
   symtab->setDeleteHook(clear_frames) ;
   symtab->expandTo(1000000) ;
   symtab->select() ;
   collect_external_statistics(wordfreq_file,1) ;
   for (const FrList *fl = filelist ; fl ; fl = fl->rest())
      {
      const char *file = FrPrintableName(fl->first()) ;
      if (!file)
	 continue ;
      collect_statistics(file,monolingual) ;
      }
   cout << "Generating case-conversion table" << endl ;
   FrSymHashTable conv_ht(100000) ;
   make_conversion_table(conv_ht) ;
   cout << "Converting case" << endl ;
   for (const FrList *fl = filelist ; fl ; fl = fl->rest())
      {
      const char *file = FrPrintableName(fl->first()) ;
      if (!file)
	 continue ;
      char *dest ;
      if (out_dir)
	 {
	 if (new_ext && *new_ext)
	    dest = Fr_aprintf("%s/%s.%s",out_dir,FrFileBasename(file),new_ext);
	 else
	    dest = Fr_aprintf("%s/%s",out_dir,FrFileBasename(file)) ;
	 }
      else if (new_ext && *new_ext)
	 dest = Fr_aprintf("%s.%s",file,new_ext) ;
      else
	 dest = FrDupString(file) ;
      if (strcmp(file,dest) == 0)
	 cout << "Destination is same as input!  Won't overwrite file."
	      << endl ;
      else
	 convert_case(file,dest,conv_ht,monolingual) ;
      FrFree(dest) ;
      }
   delete symtab ;
   if (dump_conversions)
      {
      cout << "======= conversion table =======" << endl ;
      conv_ht.doHashEntries(show_conversion) ;
      cout << "======= end of table =======" << endl ;
      }
   return ;
}

//----------------------------------------------------------------------

static void usage(const char *argv0)
{
   cout << "DownCase v" VERSION_STR " -- true-case first words of sentences\n";
   cout << "Usage:\t" << argv0 << " [options] file1 [file2 ...]\n"
	<< "  or  \t" << argv0 << " [options] -fLISTFILE\n"
	<< "Options:\n"
	<< "\t-1\ttext is monolingual\n"
	<< "\t-c\twrite output files to current directory instead of original dir\n"
	<< "\t-cDIR\twrite output files to DIR instead of original directory\n"
	<< "\t-d\tdisplay generated conversion table\n"
	<< "\t-eX\tadd extension X to converted files (default " CONV_EXT ")\n"
	<< "\t-fF\tread list of files to convert from file F (one per line)\n"
	<< "\t-m\tshow memory usage\n"
	<< "\t-r\treverse languages, downcase first half of bitext\n"
	<< "\t-Uenc\tuse character encoding 'enc'\n"
	<< "\t-w F\tadd word frequencies from unigram list in 'F' to stats\n"
	<< "\t-@\tdon't tokenize input, split only on whitespace\n"
	<< endl ;
   return ;
}

//----------------------------------------------------------------------

int main(int argc, char **argv)
{
   FrBool showmem = False ;
   FrBool dump_conversions = False ;
   FrBool monolingual = False ;
   const char *out_dir = 0 ;
   char *listfile = 0 ;
   char *argv0 = argv[0] ;
   const char *new_ext = CONV_EXT ;
   const char *wordfreq_file = 0 ;
   while (argc > 1 && argv[1][0] == '-')
      {
      switch (argv[1][1])
	 {
	 case '1':
	    monolingual = True ;
	    break ;
	 case 'c':
	    if (argv[1][2])
	       out_dir = argv[1]+2 ;
	    else
	       out_dir = "." ;
	    break ;
	 case 'd':
	    dump_conversions = True ;
	    break ;
	 case 'e':
	    new_ext = argv[1]+2 ;
	    break ;
	 case 'f':
	    listfile = argv[1]+2 ;
	    break ;
	 case 'm':
	    showmem = True ;
	    break ;
	 case 'r':
	    reverse_languages = true ;
	    break ;
	 case 'U':
	    char_encoding = FrParseCharEncoding(argv[1]+2) ;
	    break ;
	 case 'w':
	    wordfreq_file = argv[1]+2 ;
	    break ;
	 case '@':
	    EbInputAlreadyCanonical(True) ;
	    canon_input = true ;
	    break ;
	 default:
	    usage(argv0) ;
	    return 1 ;
	 }
      argc-- ;
      argv++ ;
      }
   if (argc < 2 && !listfile)
      {
      usage(argv0) ;
      return 1 ;
      }
   FrList *filelist = collect_files(listfile,argc,argv) ;
   convert(filelist,new_ext,wordfreq_file,dump_conversions,monolingual,
	   out_dir) ;
   free_object(filelist) ;
   if (showmem)
      FrMemoryStats() ;
   return 0 ;
}
