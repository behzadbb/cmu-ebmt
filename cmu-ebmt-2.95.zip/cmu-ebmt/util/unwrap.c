#include <stdio.h>

int main(int argc, char **argv)
{
  int prevch = EOF ;
  (void)argc ; (void)argv ;
  while (!feof(stdin))
     {
     int c = getchar() ;
     if (prevch == '\n' && c != '\n')
        putchar(' ') ;
     else if (prevch != EOF)
        putchar(prevch) ;
     prevch = c ;
     }
  if (prevch != EOF)
     putchar(prevch) ;
  return 0 ;
}
