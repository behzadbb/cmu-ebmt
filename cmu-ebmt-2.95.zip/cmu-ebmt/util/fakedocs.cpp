/************************************************************************/
/*									*/
/*  FakeDocs -- insert fake document boundaries in text for EBMT	*/
/*  Version 0.20							*/
/*	by Ralf Brown							*/
/*									*/
/*  LastEdit: 23may08							*/
/*									*/
/*  (c) Copyright 2007,2008 Ralf Brown					*/
/*	This software may be used for educational and non-commercial	*/
/*	research purposes.  Any other use requires prior permission	*/
/*	from Ralf Brown or the Carnegie Mellon University Language	*/
/*	Technologies Institute.						*/
/*									*/
/************************************************************************/

#include "ebmt.h"
#include "ebutil.h"

/************************************************************************/
/*	Manifest constants						*/
/************************************************************************/

#define VERSION "0.20"

/************************************************************************/
/************************************************************************/

static bool extract_origin_tag(const char *tags, char **docname)
{
   if (tags && docname)
      {
      char *origin = Fr_stristr(tags,"(origin") ;
      if (origin)
	 {
	 char *org_start = strchr(origin,'"') ;
	 if (org_start)
	    {
	    org_start++ ;
	    char *org_end = strchr(org_start,'"') ;
	    if (org_end)
	       {
	       char *newdoc = FrNewN(char,org_end-org_start+1) ;
	       if (newdoc)
		  {
		  memcpy(newdoc,org_start,org_end-org_start) ;
		  newdoc[org_end-org_start] = '\0' ;
		  FrFree(*docname) ;
		  *docname = newdoc ;
		  return true ;
		  }
	       }
	    }
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

static void remove_origin_tag(char *tags)
{
   if (tags)
      {
      char *origin ;
      do {
         origin = Fr_stristr(tags,"(origin") ;
	 if (origin)
	    {
	    char *tag_end = strchr(origin,')') ;
	    if (tag_end)
	       {
	       strcpy(origin,tag_end+1) ;
	       }
	    }
         } while (origin) ;
      if (strcmp(tags,";;;") == 0)
	 *tags = '\0' ;
      }
   return ;
}

//----------------------------------------------------------------------

static void insert_docbounds_monolingual(FILE *fp, const char *docname,
					 size_t lines_per_doc,
					 FrCharEncoding /* encoding */)
{
   size_t count = 0 ;
   size_t docnum = 0 ;
   while (!feof(stdin))
      {
      char line[FrMAX_LINE] ;
      if (!fgets(line,sizeof(line),fp))
	 break ;
      if (count % lines_per_doc == 0)
	 {
	 if (count > 0)
	    printf(":ENDDOC\n") ;
	 printf(":DOC %s.%04d\n",docname,docnum) ;
	 docnum++ ;
	 }
      fputs(line,stdout) ;
      count++ ;
      }
   if (docnum > 0)
      printf(":ENDDOC\n") ;
   return ;
}

//----------------------------------------------------------------------

static void insert_docbounds_bilingual(FILE *fp, const char *doc_name,
				       size_t lines_per_doc,
				       bool subdivide,
				       FrCharEncoding encoding)
{
   size_t count = 0 ;
   size_t docnum = 0 ;
   char *docname = FrDupString(doc_name) ;
   while (!feof(fp))
      {
      char *ssent, *tsent, *tags ;

      if (!read_EBMT_entry(fp,encoding,0,ssent,tsent,tags,True))
	 break ;
      if (subdivide)
	 {
	 // look for an existing ORIGIN tag; if found, update docname nad
	 //   reset line count
	 if (extract_origin_tag(tags,&docname))
	    {
	    count = 0 ;
	    docnum = 0 ;
	    }
	 }
      remove_origin_tag(tags) ;
      if (tags && *tags)
	 {
	 fputs(tags,stdout) ;
	 fputc('\n',stdout) ;
	 }
      if (count % lines_per_doc == 0)
	 {
	 printf(";;;(ORIGIN \"%s.%04d\")\n",docname,docnum) ;
	 docnum++ ;
	 }
      fputs(ssent,stdout) ;
      fputc('\n',stdout) ;
      fputs(tsent,stdout) ;
      fputc('\n',stdout) ;
      fputc('\n',stdout) ;
      count++ ;
      }
   FrFree(docname) ;
   return ;
}

//----------------------------------------------------------------------

int main(int argc, char **argv)
{
   bool monolingual = false ;
   bool subdivide = false ;
   FrCharEncoding encoding = FrChEnc_UTF8 ;
   while (argc > 1 && argv[1][0] == '-')
      {
      switch (argv[1][1])
	 {
	 case '1':
	    monolingual = true ;
	    break ;
	 case 's':
	    subdivide = true ;
	    break ;
	 case 'U':
	    encoding = FrParseCharEncoding(argv[1]+2) ;
	    break ;
	 default:
	    cerr << "Unknown flag " << argv[1] << endl ;
	    break ;
	 }
      argc-- ;
      argv++ ;
      }
   if (argc < 3)
      {
      cerr << "FakeDocs v" VERSION << endl ;
      cerr << "   insert fake document boundaries into corpus" << endl ;
      cerr << endl ;
      cerr << "Usage: " << argv[0] << " [-1] [-Uenc] sent_per_doc infile >out" << endl ;
      cerr << "  -1\tinput is monolingual (i.e. test data)" << endl ;
      cerr << "  -s\tsubdivide existing documents into chunks of given size" << endl ;
      cerr << "  -Uenc\tuse character encoding 'enc'" << endl ;
      return 1 ;
      }
   char *end ;
   size_t lines_per_doc = strtoul(argv[1],&end,0) ;
   char *infile = argv[2] ;
   if (lines_per_doc < 1)
      lines_per_doc = 100 ;
   FILE *infp = fopen(infile,"r") ;
   if (!infp)
      {
      cerr << "Unable to open file " << infile << endl ;
      return 1 ;
      }
   char *docname = FrForceFilenameExt(infile,0) ;
   if (monolingual)
      insert_docbounds_monolingual(infp,docname,lines_per_doc,encoding) ;
   else
      insert_docbounds_bilingual(infp,docname,lines_per_doc,subdivide,
				 encoding) ;
   FrFree(docname) ;
   fclose(infp) ;
   return 0 ;
}

// end of file fakedocs.cpp //
