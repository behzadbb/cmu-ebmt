// version 0.1
// LastEdit: 04dec07

#include "FramepaC.h"

static FrChar16 charmap[65536];

#define VERSION "0.1"

//----------------------------------------------------------------------

static void usage(const char *argv0)
{
   fprintf(stderr,"NormUTF8 v" VERSION "\t\tCopyright 2007 Ralf Brown\n"
		  "Usage: %s <in >out\n"
	          "  normalize UTF8 characters, replacing multiple variants of\n"
		  "  a character with the canonical version\n",
	   argv0) ;
   exit(1) ;
}

//----------------------------------------------------------------------

static void initialize()
{
   // start with the identity mapping
   for (size_t i = 0 ; i < lengthof(charmap) ; i++)
      charmap[i] = i ;

   // then put in all the exceptions
   // map Latin-1 high-bit characters down to ASCII
   charmap[160] = ' ' ;			// hard space -> regular blank
   charmap[0x00AB] = '"' ;		// left double angle quote
   charmap[0x00AD] = '-' ;		// n-dash / soft hyphen
   charmap[0x00BB] = '"' ;		// right double angle quote
   charmap[0x00D7] = '*' ;		// multiplication sign

   // map Windows characters down to ASCII
   charmap[0x0091] = '\'' ;		// left single quote
   charmap[0x0092] = '\'' ;		// right single quote
   charmap[0x0093] = '"' ;		// left double quote
   charmap[0x0094] = '"' ;		// right double quote

   // map Arabic punctuation marks to standard ASCII
   charmap[0x060C] = ',' ;
   charmap[0x060D] = '/' ;		// date separator
   charmap[0x061B] = ';' ;
   charmap[0x061F] = '?' ;
   charmap[0x066A] = '%' ;
   charmap[0x066B] = '.' ;		// Arabic decimal separator
   charmap[0x066C] = ',' ;		// Arabic thousands separator
   charmap[0x066D] = '*' ;		// Arabic five-pointed star
   charmap[0x06D4] = '.' ;		// Arabic full stop
   charmap[0x06FD] = '&' ;		// Sindhi ampersand

   // map Arabic-Indic and Easter Arabic-Indic digits to ASCII
   charmap[0x0660] = charmap[0x06F0] = '0' ;
   charmap[0x0661] = charmap[0x06F1] = '1' ;
   charmap[0x0662] = charmap[0x06F2] = '2' ;
   charmap[0x0663] = charmap[0x06F3] = '3' ;
   charmap[0x0664] = charmap[0x06F4] = '4' ;
   charmap[0x0665] = charmap[0x06F5] = '5' ;
   charmap[0x0666] = charmap[0x06F6] = '6' ;
   charmap[0x0667] = charmap[0x06F7] = '7' ;
   charmap[0x0668] = charmap[0x06F8] = '8' ;
   charmap[0x0669] = charmap[0x06F9] = '9' ;

   // map Devanagari digits to ASCII
   charmap[0x0966] = '0' ;
   charmap[0x0967] = '1' ;
   charmap[0x0968] = '2' ;
   charmap[0x0969] = '3' ;
   charmap[0x096A] = '4' ;
   charmap[0x096B] = '5' ;
   charmap[0x096C] = '6' ;
   charmap[0x096D] = '7' ;
   charmap[0x096E] = '8' ;
   charmap[0x096F] = '9' ;

   // map general punctuation symbols down to ASCII
   charmap[0x2000] = ' ' ;		// en quad
   charmap[0x2001] = ' ' ;		// em quad
   charmap[0x2002] = ' ' ;		// en space
   charmap[0x2003] = ' ' ;		// em space
   charmap[0x2004] = ' ' ;		// thick space
   charmap[0x2005] = ' ' ;		// mid space
   charmap[0x2006] = ' ' ;		// thin space
   charmap[0x2007] = ' ' ;		// figure space
   charmap[0x2008] = ' ' ;		// punctuation space
   charmap[0x2009] = ' ' ;		// thin space
   charmap[0x200A] = ' ' ;		// hair space
   charmap[0x200B] = ' ' ;		// zero-width space
   charmap[0x2010] = '-' ;		// hyphen
   charmap[0x2011] = '-' ;		// non-breaking hyphen
   charmap[0x2012] = '-' ;		// figure dash
   charmap[0x2013] = '-' ;		// n-dash
   charmap[0x2014] = '-' ;		// m-dash
   charmap[0x2015] = '-' ;		// horizontal bar / quotation dash
   charmap[0x2017] = '_' ;		// double low line
   charmap[0x2018] = '\'' ;		// left single quote
   charmap[0x2019] = '\'' ;		// right single quote
   charmap[0x201C] = '"' ;		// left double quote
   charmap[0x201D] = '"' ;		// right double quote
   charmap[0x201E] = '"' ;		// double low rev-9 quotation mark
   charmap[0x201F] = '"' ;		// double high rev-9 quotation mark
   charmap[0x2022] = '*' ;		// bullet
   charmap[0x2027] = '-' ;		// hyphenation point
   charmap[0x202F] = ' ' ;		// narrow no-break space
   charmap[0x2032] = '\'' ;		// prime
   charmap[0x2033] = '"' ;		// double prime
   charmap[0x2035] = '`'; 		// reversed prime
   charmap[0x2038] = '^' ;		// caret
   charmap[0x2039] = '<' ;		// single left angle quotation mark
   charmap[0x203A] = '>' ;		// single right angle quotation mark
   charmap[0x203C] = '!' ;		// double exclamation mark
   charmap[0x2044] = '/' ;		// fraction slash
   charmap[0x2045] = '[' ;		// left sq. bracket with quill
   charmap[0x2046] = ']' ;		// right sq. bracket with quill
   charmap[0x2047] = '?' ;		// double question mark
   charmap[0x204E] = '*' ;		// low asterisk
   charmap[0x204F] = ';' ;		// reversed semicolon
   charmap[0x2052] = '%' ;		// commercial minus sign
   charmap[0x2053] = '~' ;		// swung dash
   charmap[0x20AC] = 0x0080 ;		// Euro symbol
   charmap[0x223C] = '~' ;		// approximately
   charmap[0x2500] = '-' ;		// box drawings light horizontal
   charmap[0x2501] = '-' ;		// box drawings heavy horizontal
   charmap[0xFD3E] = '(' ;		// ornate left parenthesis
   charmap[0xFD3F] = ')' ;		// ornate right parenthesis
   charmap[0xFE30] = ':' ;		// vertical two dot leader
   charmap[0xFE6A] = '%' ;		// small percent sign

   // map CJK punctuation down to ASCII
   charmap[0x3000] = ' ' ;
   charmap[0x3001] = ',' ;
   charmap[0x3002] = '.' ;		// ideographic full stop
   charmap[0x3003] = '"' ;		// ditto mark
   charmap[0x3007] = '0' ;		// ideographic number zero
   charmap[0x3008] = '<' ;		// left angle bracket
   charmap[0x3009] = '>' ;		// right angle bracket
   charmap[0x300A] = 0x00AB ;		// left double angle bracket
   charmap[0x300B] = 0x00BB ;		// right double angle bracket
   charmap[0x300C] = '"' ;		// upper-left corner bracket
   charmap[0x300D] = '"' ;		// lower-right corner bracket
   charmap[0x300E] = '"' ;		// upper-left white corner bracket
   charmap[0x300F] = '"' ;		// lower-right white corner bracket
   charmap[0x3010] = '[' ;		// left lenticular bracket
   charmap[0x3011] = ']' ;		// right lenticular bracket
   charmap[0x301D] = '"' ;		// reversed double prime quot mark
   charmap[0x301E] = '"' ;		// double prime quotation mark
   charmap[0x3030] = '~' ;		// wavy dash

   // Suzhou numerals
   charmap[0x3021] = '1' ;
   charmap[0x3022] = '2' ;
   charmap[0x3023] = '3' ;
   charmap[0x3024] = '4' ;
   charmap[0x3025] = '5' ;
   charmap[0x3026] = '6' ;
   charmap[0x3027] = '7' ;
   charmap[0x3028] = '8' ;
   charmap[0x3029] = '9' ;

   // other symbols
   charmap[0x30FB] = 0x00B7 ;		// Katakana middle dot

   // map Fullwidth ASCII variants to regular ASCII
   for (size_t i = 0xFF01 ; i <= 0xFF5E ; i++)
      charmap[i] = (i - 0xFF00 + ' ') ;

   // map Fullwidth symbol variants
   charmap[0xFFE0] = 0x00A2 ;		// fullwidth cent sign
   charmap[0xFFE1] = 0x00A3 ;		// fullwidth pound sign
   charmap[0xFFE2] = 0x00AC ;		// fullwidth not sign
   charmap[0xFFE3] = 0x00AF ;		// fullwidth macron
   charmap[0xFFE4] = 0x00A6 ;		// fullwidth broken bar
   charmap[0xFFE5] = 0x00A5 ;		// fullwidth Yen sign
   charmap[0xFFE6] = 0x20A9 ;		// fullwidth Won sign

   // halfwidth CJK
   charmap[0xFF61] = '.' ;		// halfwidth ideographic full stop
   charmap[0xFF64] = ',' ;		// halfwidth ideographic comma

   return ;
}

//----------------------------------------------------------------------

static void normalize(const char *line, FILE *out)
{
   FrChar16 *unicode = Fr_UTF8_to_Unicode(line) ;
   FrBool byteswap = False ;
   for (FrChar16 *unichar = unicode ; unichar && *unichar ; unichar++)
      {
      char UTF8buffer[8] ;
      FrChar16 codepoint = charmap[FrLoadShort(unichar)] ;
      // handle a few special cases that map to multiple characters first
      if (codepoint == 0x2014)		// em-dash
	 fwrite("--",sizeof(char),2,out) ;
      else if (codepoint == 0x2026)	// ellipsis
	 fwrite("...",sizeof(char),3,out) ;
      else if (codepoint == 0x2047)	// ??
	 fwrite("??",sizeof(char),2,out) ;
      else if (codepoint == 0x2048)	// ?! character
	 fwrite("?!",sizeof(char),2,out) ;
      else if (codepoint == 0x2048)	// !? character
	 fwrite("!?",sizeof(char),2,out) ;
      else
	 {
	 int len = Fr_Unicode_to_UTF8(codepoint,UTF8buffer,byteswap) ;
	 UTF8buffer[len] = '\0' ;
	 if (fwrite(UTF8buffer,sizeof(char),len,out) < len)
	    break ;
	 }
      }
   FrFree(unicode) ;
   return ;
}

//----------------------------------------------------------------------

int main(int argc, char **argv)
{
   if (argc > 1)
      usage(argv[0]) ;
   initialize() ;
   while (!feof(stdin))
      {
      char line[32768] ;
      line[0] = '\0' ;
      if (!fgets(line,sizeof(line),stdin))
	 break ;
      line[sizeof(line)-1] = '\0' ;
      normalize(line,stdout) ;
      }
   return 0 ;
}

// end of file normUTF8.cpp //
