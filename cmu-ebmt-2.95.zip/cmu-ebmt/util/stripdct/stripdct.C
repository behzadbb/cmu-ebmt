//**************************************************************************
//  stripdct.C  -- postprocessing for exported dictionary file: remove all
//		  other definitions for words which have themselves as one
//		  of their possible translations, or remove all words with
//		  cognate similarity scores below a given threshold if the
//		  most-similar translation is above another, higher threshold
//  by Ralf Brown
//  Version 1.31
//  LastEdit: 11may10
//**************************************************************************

#include "FramepaC.h"
#ifdef FrSTRICT_CPLUSPLUS
#  include <cstdlib>
#  include <fstream>
#else
#  include <stdlib.h>
#  include <fstream.h>
#endif

#define VERSION "1.31"

/**************************************************************************/
/**************************************************************************/

static size_t cog_weight = 0 ;
static size_t dup_weight = ~0 ;
static FrBool verbose = False ;

/**************************************************************************/
/**************************************************************************/

static void extract_cognate_parms(const char *arg)
{
   char *end = 0 ;
   size_t c_weight = (size_t)strtol(arg,&end,0) ;
   if (end && end != arg)
      {
      cog_weight = c_weight ;
      if (*end == ',')
	 {
	 arg = end+1 ;
	 size_t d_weight = (size_t)strtol(arg,&end,0) ;
	 if (end && end != arg)
	    dup_weight = d_weight ;
	 }
      FrSetCognateScoring(cog_weight,dup_weight) ;
      }
   return ;
}

//----------------------------------------------------------------------

static const FrObject *translation_word(const FrList *translation)
{
   if (!translation->rest() || translation->rest()->consp())
      return translation->first() ;
   else
      return makeSymbol(".") ;
}

//----------------------------------------------------------------------

static size_t translation_frequency(const FrList *translation)
{
   FrObject *cnt = translation->rest() ;
   if (cnt && cnt->consp())
      cnt = ((FrList*)cnt)->first() ;
   return (cnt && cnt->numberp()) ? cnt->intValue() : 0 ;
}

//----------------------------------------------------------------------

static FrBool compatible_stopwords(const FrObject *word, const FrObject *trans,
				   const FrHashTable *src_stop,
				   const FrHashTable *trg_stop)
{
   if (!src_stop || !trg_stop)
      return True ;			// no stopwords that might conflict
   FrHashEntryObject src_key(word) ;
   FrHashEntryObject trg_key(trans) ;
   FrBool src_is_stop = src_stop->lookup(&src_key) != 0 ;
   FrBool trg_is_stop = trg_stop->lookup(&trg_key) != 0 ;
   return (src_is_stop && trg_is_stop) || (!src_is_stop && !trg_is_stop) ;
}

//----------------------------------------------------------------------

static void load_stoplist(FILE *fp, FrHashTable *&ht)
{
   ht = new FrHashTable ;
   if (ht)
      {
      ht->expandTo(1000) ;
      while (!feof(fp))
	 {
	 char line[FrMAX_LINE] ;
	 if (!fgets(line,sizeof(line),fp))
	    break ;
	 char *lineptr = line ;
	 if (FrSkipWhitespace(lineptr) == ';')
	    continue ;
	 FrObject *obj = string_to_FrObject(lineptr) ;
	 if (obj && obj != makeSymbol("*EOF*"))
	    {
	    FrHashEntryObject key(obj) ;
	    ht->add(&key) ;
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

static void load_stoplists(const char *stopfiles,FrHashTable *&src_ht,
			   FrHashTable *&trg_ht)
{
   const char *comma = strchr(stopfiles,',') ;
   if (!comma)
      {
      cerr << "You must specify two filenames separated by a comma for -s"
	   << endl ;
      cerr << "No stopword processing will be done." << endl ;
      }
   else
      {
      char *srcfile = FrDupString(stopfiles) ;
      char *trgfile = strchr(srcfile,',') ;
      *trgfile++ = '\0' ;
      FILE *srcfp = fopen(srcfile,"r") ;
      if (srcfp)
	 {
	 load_stoplist(srcfp,src_ht) ;
	 fclose(srcfp) ;
	 }
      else
	 {
	 cerr << "Unable to read '" << srcfile << "'" << endl ;
	 }
      FILE *trgfp = fopen(trgfile,"r") ;
      if (trgfp)
	 {
	 load_stoplist(trgfp,trg_ht) ;
	 fclose(trgfp) ;
	 }
      else
	 {
	 cerr << "Unable to read '" << trgfile << "'" << endl ;
	 }
      FrFree(srcfile) ;
      }
   return ;
}

//----------------------------------------------------------------------

static void strip_entry(const FrList *entry, ostream &out, size_t max_freq,
			size_t min_length, size_t max_defs, double threshold,
			double minkeep,	const FrHashTable *src_stop,
			const FrHashTable *trg_stop, FrBool strip_highfreq)
{
   FrObject *word = entry->first() ;
   FrObject *count = entry->second() ;
   const char *wordstr = FrPrintableName(word) ;
   size_t wordlen = wordstr ? strlen(wordstr) : 0 ;
   size_t num_defs = 0 ;
   const FrList *definitions = entry->rest() ;
   if (count && count->numberp())
      definitions = definitions->rest() ;
   if (definitions->rest() && wordlen >= min_length && count &&
       (!count->numberp() || (size_t)count->intValue() <= max_freq))
      {
      size_t highest_freq = 0 ;
      double best_cognate = 0.0 ;
      for (const FrList *l = definitions ; l ; l = l->rest())
	 {
	 const FrList *def = (FrList*)l->first() ;
	 if (def)
	    {
	    double score = FrCognateScore(word,translation_word(def)) ;
	    if (verbose)
	       cout << "cog(" << def->first() << ',' << word << ") = " << score
		    << endl ;
	    size_t count = translation_frequency(def) ;
	    if (score > best_cognate)
	       {
	       best_cognate = score ;
	       highest_freq = count ;
	       }
	    else if (score == best_cognate && count > highest_freq)
	       highest_freq = count ;
	    }
	 }
      if (best_cognate >= threshold)
	 {
	 if (strip_highfreq)
	    highest_freq = (size_t)~0 ;
	 out << '(' << word ;
	 if (count && count->numberp())
	    out << ' ' << count ;
	 for ( ;
	       definitions && num_defs < max_defs ;
	       definitions = definitions->rest())
	    {
	    const FrList *def = (FrList*)definitions->first() ;
	    if (!def)
	       continue ;
	    size_t count = translation_frequency(def) ;
	    const FrObject *translation = translation_word(def) ;
            if ((count > highest_freq ||
		FrCognateScore(word,translation) >= minkeep) &&
		compatible_stopwords(word,translation,src_stop,trg_stop))
	       {
	       out << '(' << translation << ' ' << count << ')' ;
	       num_defs++ ;
	       }
	    }
	 out << ')' << endl ;
	 return ;
	 }
      }
   out << '(' << word ;
   if (count && count->numberp())
      out << ' ' << count ;
   for (size_t def_count = 0 ;
	def_count < max_defs && definitions ;
	definitions = definitions->rest())
      {
      const FrList *def = (FrList*)definitions->first() ;
      if (compatible_stopwords(word,translation_word(def),src_stop,trg_stop))
	 {
	 out << def ;
	 def_count++ ;
	 }
      }
   out << ')' << endl ;
   return ;
}

//----------------------------------------------------------------------

int main(int argc, char **argv)
{
   const char *argv0 = argv[0] ;
   const char *stopfiles = 0 ;
   size_t min_length = 4 ;
   size_t max_freq = 2 ;
   size_t max_defs = 500 ;
   double cognate_threshold = 1.00 ;
   double cognate_minimum = 1.00 ;
   FrBool strip_highfreq = False ;
   FrSetDefaultCognateLetters() ;
   while (argc > 1 && argv[1][0] == '-')
      {
      switch (argv[1][1])
	 {
	 case 'c':   extract_cognate_parms(argv[1]+2) ;		break ;
	 case 'd':   max_defs = atoi(argv[1]+2) ;		break ;
	 case 'f':   max_freq = atoi(argv[1]+2) ;		break ;
	 case 'h':   strip_highfreq = True ;			break ;
	 case 'l':   min_length = atoi(argv[1]+2) ;		break ;
	 case 'm':   cognate_minimum = atof(argv[1]+2) ;	break ;
	 case 's':   stopfiles = argv[1]+2 ;			break ;
	 case 't':   cognate_threshold = atof(argv[1]+2) ;	break ;
	 case 'v':   verbose = True ;				break ;
	 default:
	    cerr << "Unknown option " << argv[1] << endl ;
	 }
      argc-- ;
      argv++ ;
      }
   if (min_length < 1)
      min_length = 1 ;
   if (max_freq < 1)
      max_freq = 1 ;
   if (cognate_threshold > 1.0)
      cognate_threshold = 1.0 ;
   else if (cognate_threshold < 0.0)
      cognate_threshold = 0.0 ;
   if (cognate_minimum > cognate_threshold)
      cognate_minimum = cognate_threshold ;
   else if (cognate_minimum < 0.0)
      cognate_minimum = 0.0 ;
   if (argc < 2)
      {
      cerr << "Dictionary Stripper v"VERSION"\t(c) 1997,2001,2008 Ralf Brown"
	   << endl ;
      cerr << "Usage: " <<argv0<< " [options] dictionary-file [>stripped-dict]\n"
	   << "Options:\n"
	   << "\t-cX,Y\tset cognate fuzzy-match weight to X, dup weight to Y\n"
	   << "\t-dN\tkeep at most N definitions per head word (500)\n"
	   << "\t-fN\tmaximum word frequency to strip (2)\n"
	   << "\t-h\tstrip low-scoring words even if higher-freq than best\n"
	   << "\t-lN\tdon't modify definitions for words with < N letters\n"
	   << "\t-mX\tset mimimum cognate score to keep (0.0-1.0)\n"
	   << "\t-sS,T\tuse stopword files S (source) and T (target lang)\n"
	   << "\t-tX\tset threshold cognate score at which to strip entry\n"
	   << "\t-v\trun verbosely\n"
           << endl ;
      cerr << "If -s is specified, dictionary entries will be further filtered\n"
	   << "such that no source stopword translates to a target non-stopword\n"
	   << "and no source non-stopword translates to a target stopword.\n"
	   << "Stopwords in this context are intended to be function words and\n"
	   << "similar items such as punctuation or numbers.\n"
	   << endl ;
      return 1 ;
      }
   ifstream *in = new ifstream(argv[1]) ;
   if (!in || !in->good())
      {
      cerr << "unable to open input file " << argv[1] << endl ;
      return 2 ;
      }
   FrHashTable *src_ht = 0 ;
   FrHashTable *trg_ht = 0 ;
   if (stopfiles)
      {
      load_stoplists(stopfiles,src_ht,trg_ht) ;
      }
   FrSymbol *symEOF = FrSymbolTable::add("*EOF*") ;
   while (!in->eof())
      {
      FrObject *entry ;
      *in >> entry ;
      if (entry && entry->consp())
	 strip_entry((FrList*)entry,cout,max_freq,min_length,max_defs,
		     cognate_threshold,cognate_minimum,src_ht,trg_ht,
		     strip_highfreq) ;
      else if (entry == symEOF)
	 break ;
      else if (entry)
	 cout << "; invalid item: " << entry << endl ;
      }
   in->close() ;
   delete in ;
   return 0 ;
}

// end of file stripdct.C //
