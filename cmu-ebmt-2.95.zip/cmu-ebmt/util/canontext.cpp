// g++ -O9 -o canontext -I../include -L../lib canontext.cpp -lframepac

#include <stdio.h>
#include <unistd.h>
#include "FramepaC.h"

static FrCharEncoding char_encoding = FrChEnc_Latin1 ;

//----------------------------------------------------------------------

static void usage(const char *argv0)
{
   fprintf(stderr,"CanonText v0.91\n") ;
   fprintf(stderr,"Usage: %s [flags] <text >result\n",argv0) ;
   fprintf(stderr,"Flags:\n") ;
   fprintf(stderr,"\t-aFILE\tload list of abbreviations from FILE\n") ;
   fprintf(stderr,"\t-h\tdisplay this usage summary\n") ;
   fprintf(stderr,"\t-s\tkeep single quotes attached to end of words\n") ;
   fprintf(stderr,"\t-Uenc\tuse character encoding 'enc'\n") ;
   exit(1) ;
}

//----------------------------------------------------------------------

static char *allow_single_quotes(FrCharEncoding enc)
{
   const char *delimiters = FrStdWordDelimiters(enc) ;
   char *with_quote = FrNewN(char,256) ;
   if (with_quote)
      {
      if (delimiters)
	 memcpy(with_quote,delimiters,256) ;
      else
	 memset(with_quote,'\0',256) ;
      with_quote['\''] = (char)0 ;
      }
   return with_quote ;
}

//----------------------------------------------------------------------

int main(int argc, char **argv)
{
   const char *argv0 = argv[0] ;
   char **abbrevs = 0 ;
   char *delim = 0 ;
   FrBool single_quotes = False ;
   while (argc > 1 && argv[1][0] == '-')
      {
      switch (argv[1][1])
	 {
	 case 'a':
	    abbrevs = FrLoadAbbreviationList(argv[1]+2) ;
	    break ;
	 case 'h':
	 default:
	    usage(argv0) ;
	    break ;
	 case 's':
	    single_quotes = True ;
	    break ;
	 case 'U':
	    char_encoding = FrParseCharEncoding(argv[1]+2) ;
	    break ;
	 }
      argv++ ;
      argc-- ;
      }
   if (single_quotes)
      delim = allow_single_quotes(char_encoding) ;
   else
      delim = (char*)FrStdWordDelimiters(char_encoding) ;
   while (!feof(stdin))
      {
      char line[32767] ;
      if (!fgets(line,sizeof(line),stdin))
	 break ;
      if (strncmp(line,";;;",3) == 0)
	 fputs(line,stdout) ;
      else
	 {
	 char *result = FrCanonicalizeSentence(line,char_encoding,False,delim,
					       abbrevs) ;
	 fputs(result,stdout) ;
	 fputc('\n',stdout) ;
	 FrFree(result) ;
	 }
      }
   FrFreeAbbreviationList(abbrevs) ;
   if (single_quotes)
      FrFree(delim) ;
   fflush(stdout) ;
   return 0 ;
}
