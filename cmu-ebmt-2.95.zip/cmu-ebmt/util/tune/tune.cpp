/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Parameter Tuner							*/
/*  Version 2.90							*/
/*	 by Ralf Brown							*/
/*									*/
/*  File tune.cpp							*/
/*  LastEdit: 07apr10							*/
/*									*/
/*  (c) Copyright 2005,2006,2007,2008,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#define VERSION "2.90"

#include <errno.h>
#include <math.h>
#include <limits.h>	// for INT_MAX 
#include <signal.h>
#include <sys/wait.h>
#include "FramepaC.h"

/************************************************************************/
/*	Manifest Constants						*/
/************************************************************************/

// when randomizing starting conditions, try up to N values per parameter
//   being varied, and use the set of parameter values resulting in the best
//   score
#define INIT_TRIES 2

// how many steps can we try taking when performing a local perturbation?
#define MAX_LOCAL_STEPS 20

#define WORST_SCORE (-99999999.9)

#define UNKNOWN_VALUE ((size_t)(~0-2))

// we don't really care what the eval program prints after the first few words
#define TUNE_MAX_LINE 80

/************************************************************************/
/*	Types								*/
/************************************************************************/

enum ArgBias
   {
      Bias_None,
      Bias_Low,
      Bias_High,
      Bias_Required
   } ;

class ArgSpec
   {
   private:
      ArgSpec *m_next ; 
      char   *m_section ;
      char   *m_param ;
      double  m_min ;
      double  m_max ;
      double *m_values ;
      double  m_current ;
      double  m_best ;
      double  m_marker ;
      size_t  num_values ;
      ArgBias m_bias ;
      bool    use_integers ;
      bool    set_externally ;
   protected:
      void setNext(ArgSpec *nxt) { m_next = nxt ; }
   public:
      ArgSpec(const ArgSpec *) ;  // copy constructor
      ArgSpec(const char *parm, const char *spec, ArgSpec *nxt = 0) ;
      ~ArgSpec() ;

      // manipulators
      void biasLow() { m_bias = Bias_Low ; }
      void biasHigh() { m_bias = Bias_High ; }
      void biasRequired() { m_bias = Bias_Required ; }
      void randomizeCurr() ;
      void setCurr(double curr) { m_current = curr ; }
      void setBest(double best) { m_best = best ; }
      void setMarker(double val) { m_marker = val ; }
      ArgSpec *reverseList() ;
      bool insertValue(double newvalue, bool require_floats = false,
		       bool make_current = false, bool force = false) ;
      double perturbStep() const ;
      double randomPerturbation() const ;
      void perturbRandomly() ;
      ArgSpec *copyList() const ;

      // accessors
      ArgSpec *next() { return m_next ; }
      const ArgSpec *next() const { return m_next ; }
      const char *paramSection() const { return m_section ; }
      const char *paramName() const { return m_param ; }
      size_t getIndex(double value, bool must_exist = true) const ;
      size_t numValues() const { return num_values ; }
      double value(size_t N) const
	 { return (N < num_values) ? m_values[N] : 0.0 ; }
      double value() const { return m_current ; }
      double lowestValue() const { return value(0) ; }
      double highestValue() const { return value(numValues()-1) ; }
      size_t currIndex() const { return getIndex(value()) ; }
      double bestValue() const { return m_best ; }
      double marker() const { return m_marker ; }
      bool useIntegers() const { return use_integers ; }
      double minAllowable() const { return m_min ; }
      double maxAllowable() const { return m_max ; }
      size_t tuningArgs() const ;
      size_t listlength() const ;
      ArgBias bias() const { return m_bias ; }
      bool external() const { return set_externally ; }
      bool OK() const { return m_param != 0 && m_values != 0 ; }

      bool betterValue(double curr_score, double best_score,
		       double curr_value) const ;
   } ;

//----------------------------------------------------------------------

class ParamVector
   {
   private:
      ArgSpec *m_args ;			// the list of all parameter descripts
      ArgSpec *m_activearg ;		// the parameter being twiddled
      double  *m_values ;
      bool    *m_integral ;
      char    *m_testprog ;		// name of program to invoke
      char    *m_configfile ;		// name of edited config file to pass
      char    *m_inputfile ;		// name of file with test data
      char     m_resultline[TUNE_MAX_LINE] ;
      double   m_score ;
      unsigned m_numargs ;
      unsigned m_activeargnum ;
      bool     m_scoreknown ;
      bool     m_finalrun ;
      bool     m_externals ;		// any parameters set externally?
   public:
      ParamVector(ArgSpec *args, ArgSpec *activearg, double newvalue,
		  const char *testprog, const char *cfgfile,
		  const char *inputfile) ;
      ~ParamVector() ;

      // access to internal state
      const ArgSpec *args() const { return m_args ; }
      ArgSpec *args() { return m_args ; }
      const ArgSpec *activeArg() const { return m_activearg ; }
      double *values() const { return m_values ; }
      double value(size_t N) const { return m_values[N] ; }
      double value() const { return m_values[m_activeargnum] ; }
      bool integralValue() const { return m_integral[m_activeargnum] ; }
      const char *testProgram() const { return m_testprog ; }
      const char *configFile() const { return m_configfile ; }
      const char *testInput() const { return m_inputfile ; }
      const char *resultLine() const { return m_resultline ; }
      double score() const { return m_score ; }
      bool scoreKnown() const { return m_scoreknown ; }
      size_t numArgs() const { return m_numargs ; }
      size_t activeIndex() const { return m_activeargnum ; }
      bool finalRun() const { return m_finalrun ; }
      bool externalValues() const { return m_externals ; }

      const char *activeParamName() const ;
      double activeValue() const { return m_values[m_activeargnum] ; }

      // tests
      static bool canParallelize(const char *testprog, const char *cfgfile,
				 ArgSpec *args, ArgSpec *activearg)  ;

      // manipulators
      void replaceArgSpecs(ArgSpec *new_args) ;
      void setActiveValue(double value) ;
      void setFinalRun() { m_finalrun = true ; }
      bool editConfig(const char *cfgfile) ;
      bool editConfig(const char *cfgfile, const char *newconfig) ;
      static bool editConfig(const char *cfgfile, const char *newconfig,
			     const ArgSpec *arglist, const double *values,
			     bool final = false) ;
      bool evaluate() ;
      static bool optimizer(const char *testprog, const char *configfile,
			    const char *testinput, ArgSpec *argspecs) ;
      bool updateValues(double &best_score, const char *new_config,
			bool all_args = false) ;

      static double *collectValues(const ArgSpec *argspecs) ;
      static bool readValues(const char *cfg, ArgSpec *argspecs,
			     bool read_all = false) ;
      static bool cleanup(const char *testprog) ;
      static void checkResults(ParamVector **vectors, size_t count,
			       double &best_score, const char *new_config,
			       bool all_params = false) ;

      // I/O
      void dumpValues(FILE *fp, bool echo = false) const ;
   } ;

/************************************************************************/
/*	Global Variables						*/
/************************************************************************/

static bool verbose = false ;
static bool minimize = false ;
static bool randomize = false ;
static bool randomize_all = false ;
static bool allow_subdivision = true ;
static unsigned int use_external_optimizer = false ;
static unsigned int time_offset = 0 ;
static size_t max_concurrency = 1 ;

static volatile bool aborted = false ;
static FrSignalHandler *sigint = 0 ;

static FrMutex global_mutex(true) ;
static FrThreadPool *thread_pool ;

/************************************************************************/
/*	Helper Functions						*/
/************************************************************************/

static bool abort_requested()
{
   FrCRITSECT_ENTER(global_mutex) ;
   bool ab = aborted ;
   FrCRITSECT_LEAVE(global_mutex) ;
   return ab ;
}

//----------------------------------------------------------------------

static void request_abort()
{
   FrCRITSECT_ENTER(global_mutex) ;
   aborted = true ;
   FrCRITSECT_LEAVE(global_mutex) ;
   return ;
}

//----------------------------------------------------------------------

static double worst_score()
{
   return  minimize ? -WORST_SCORE : WORST_SCORE ;
}

//----------------------------------------------------------------------

inline size_t minimum(size_t x, size_t y)
{
   return (x < y) ? x : y ;
}

//----------------------------------------------------------------------

static int compare_double(const void *val1, const void *val2)
{
   double d1 = *(double*)val1 ;
   double d2 = *(double*)val2 ;
   if (d1 > d2)
      return +1 ;
   else if (d1 < d2)
      return -1 ;
   else
      return 0 ;
}

//----------------------------------------------------------------------

static bool same_sign(double val1, double val2)
{
   if (val1 < 0.0 && val2 < 0.0)
      return true ;
   else if (val1 > 0.0 && val2 > 0.0)
      return true ;
   else if (val1 == 0.0 && val2 == 0.0)
      return true ;
   return false ;
}

//----------------------------------------------------------------------

static void show_parameter_value(const ArgSpec *specs, double value,
				 FILE *outfp, bool leading_blank = false,
				 bool starred = false, bool bracketed = false)
{
   if (leading_blank)
      fputc(' ',outfp) ;
   if (bracketed)
      fputc(specs->external()?'{':'[',outfp) ;
   if (specs->useIntegers())
      fprintf(outfp,"%d",(int)(value+0.01)) ;
   else
      fprintf(outfp,"%.10g",value) ;
   if (bracketed)
      fputc(specs->external()?'}':']',outfp) ;
   if (starred)
      fputc('*',outfp) ;
   if (!leading_blank)
      fputc('\n',outfp) ;
   return ;
}

//----------------------------------------------------------------------

static void show_parameter_values(const ArgSpec *argspecs, bool all_values)
{
   size_t maxname = 0 ;
   const ArgSpec *currspec ;
   for (currspec = argspecs ; currspec ; currspec = currspec->next())
      {
      const char *section = currspec->paramSection() ;
      if (!section)
	 section = "" ;
      const char *colon = *section ? ":" : "" ;
      size_t len = (strlen(section) + strlen(colon) + 
		    strlen(currspec->paramName())) ;
      if (len > maxname)
	 maxname = len ;
      }
   for (currspec = argspecs ; currspec ; currspec = currspec->next())
      {
      const char *section = currspec->paramSection() ;
      if (!section)
	 section = "" ;
      const char *colon = *section ? ":" : "" ;
      const char *param_name = currspec->paramName() ;
      size_t padding
	 = maxname - (strlen(section) + strlen(colon) + strlen(param_name)) ;
      printf("#  %s%s%s%*s",section,colon,param_name,(int)(padding+1)," ") ;
      size_t numval = currspec->numValues() ;
      size_t min = 0 ; 
      size_t max = numval ;
      bool starred = false ;
      if (!all_values)
	 {
	 min = currspec->currIndex() ;
	 max = min+1 ;
	 starred = (numval > 1) && (min == 0 || max == numval) ;
	 }
      for (size_t i = min ; i < max ; i++)
	 {
	 bool bracketed = ((all_values && (i==currspec->currIndex() || numval == 1)) ||
			   (!all_values && currspec->external())) ;
	 show_parameter_value(currspec,currspec->value(i),stdout,true,
			      starred,bracketed) ;
	 }
      printf("\n") ;
      }
   fflush(stdout) ;
   return ;
}

/************************************************************************/
/*	Methods for class ArgSpec					*/
/************************************************************************/

ArgSpec::ArgSpec(const ArgSpec *orig)
{
   m_next = 0 ;
   m_values = 0 ;
   num_values = 0 ;
   if (orig)
      {
      m_section = FrDupString(orig->m_section) ;
      m_param = FrDupString(orig->m_param) ;
      m_min = orig->m_min ;
      m_max = orig->m_max ;
      m_values = FrNewN(double,orig->num_values) ;
      if (m_values)
	 {
	 num_values = orig->num_values ;
	 memcpy(m_values,orig->m_values,num_values * sizeof(m_values[0])) ;
	 }
      m_current = orig->value() ;
      m_best = orig->bestValue() ;
      m_marker = orig->marker() ;
      m_bias = orig->m_bias ;
      use_integers = orig->use_integers ;
      set_externally = orig->set_externally ;
      }
   else
      {
      m_param = 0 ;
      m_current = 0.0 ;
      m_best = 0.0 ;
      m_marker = 0.0 ;
      m_section = 0 ;
      m_min = -DBL_MAX ;
      m_max = DBL_MAX ;
      m_bias = Bias_None ;
      use_integers = true ;
      set_externally = false ;
      }
   return ;
}

//----------------------------------------------------------------------

ArgSpec::ArgSpec(const char *parm, const char *spec, ArgSpec *nxt)
   : m_next(nxt), m_min(-DBL_MAX), m_max(DBL_MAX), m_values(0),
     m_current(0), m_marker(0), num_values(0), m_bias(Bias_None), 
     use_integers(true), set_externally(false)
{
   m_section = 0 ;
   if (parm)
      {
      if (*parm == '+')
	 {
	 biasHigh() ;
	 parm++ ;
	 }
      else if (*parm == '-')
	 {
	 biasLow() ;
	 parm++ ;
	 }
      else if (*parm == '=')
	 {
	 biasRequired() ;
	 parm++ ;
	 }
      }
   const char *colon = strchr(parm,':') ;
   if (colon)
      {
      if (colon > parm)
	 m_section = Fr_aprintf("%.*s",(int)(colon-parm),parm) ;
      parm = colon + 1 ;
      }
   m_param = FrDupString(parm) ;
   if (!m_param)
      return ;
   // check whether we have any restrictions on the valid range for the
   //   parameter
   char *greater = strchr(m_param,'>') ;
   char *less = strchr(m_param,'<') ;
   if (greater)
      {
      *greater++ = '\0' ;		// chop off the restriction
      char *end ;
      double val = strtod(greater,&end) ;
      if (end != greater)
	 m_min = val ;
      }
   if (less)
      {
      *less++ = '\0' ;			// chop off the restriction
      char *end ;
      double val = strtod(less,&end) ;
      if (end != less)
	 m_max = val ;
      }
   // parse the spec to determine which format was used and whether we
   //   have all integral values
   bool subdivided = false ;
   if (FrSkipWhitespace(spec) == '@')
      {
      num_values = 1 ;
      m_values = FrNewN(double,num_values) ;
      if (!m_values)
	 {
	 num_values = 0 ;
	 return ;
	 }
      set_externally = true ;
      m_values[0] = 0.0 ;
      }
   else
      {
      subdivided = (strchr(spec,'/') != 0) ;
      char *next ;
      size_t count = 0 ;
      size_t divisions = 1 ;
      double minvalue = LONG_MAX ;
      double maxvalue = LONG_MIN ;
      for (const char *sp = spec ; sp && *sp ; sp = next)
	 {
	 double value = strtod(sp,&next) ;
	 if (next == sp)
	    break ;
	 count++ ;
	 long intvalue = (int)value ;
	 if ((double)intvalue != value || memchr(sp,'.',next-sp) != 0)
	    use_integers = false ;
	 if (value > maxvalue)
	    maxvalue = value ;
	 if (value < minvalue)
	    minvalue = value ;
	 if (FrSkipWhitespace(next) == '/')
	    {
	    char *end ;
	    divisions = (size_t)strtol(next+1,&end,0) ;
	    if (end == next+1 || divisions < 2)
	       divisions = 2 ;
	    break ;
	    }
	 }
      if (subdivided)
	 {
	 if (useIntegers() && (int)maxvalue - (int)minvalue < (int)divisions)
	    divisions = (int)maxvalue - (int)minvalue + 1 ;
	 else if (!useIntegers() && minvalue == maxvalue)
	    divisions = 1 ;
	 num_values = divisions ;
	 }
      else
	 num_values = count ;
      if (num_values == 0)
	 return ;
      // allocate space for the values to be tested
      m_values = FrNewN(double,num_values) ;
      if (!m_values)
	 {
	 num_values = 0 ;
	 return ;
	 }
      // and store the values
      if (subdivided)
	 {
	 double range = maxvalue - minvalue ;
	 m_values[0] = minvalue ;
	 for (size_t i = 1 ; i < numValues() ; i++)
	    {
	    m_values[i] = minvalue + (i * range / (num_values-1)) ;
	    }
	 // start in the middle of the range unless we've been told to randomize
	 if (randomize || randomize_all)
	    m_current = value(FrRandomNumber(numValues())) ;
	 else
	    m_current = value(numValues() / 2) ;
	 }
      else
	 {
	 // we have explicit values, so just store them
	 for (size_t i = 0 ; i < numValues() ; i++, spec = next)
	    {
	    double value = strtod(spec,&next) ;
	    if (next == spec)
	       break ;
	    m_values[i] = value ;
	    (void)FrSkipWhitespace(next) ;
	    }
	 // sort the values, remembering which one was first before the sort
	 double first_value = value(0) ;
	 qsort(m_values,num_values,sizeof(m_values[0]),compare_double) ;
	 // unless we've been asked to randomize, go find the original 
	 //   first value
	 if (randomize_all)
	    m_current = value(FrRandomNumber(num_values)) ;
	 else
	    m_current = first_value ;
	 }
      }
   m_best = m_current ;
   return ;
}

//----------------------------------------------------------------------

ArgSpec::~ArgSpec()
{
   FrFree(m_section) ; 	m_section = 0 ;
   FrFree(m_param) ;	m_param = 0 ;
   FrFree(m_values) ;	m_values = 0 ;
   num_values = 0 ;
   if (m_next)
      delete m_next ;
   return ;
}

//----------------------------------------------------------------------

size_t ArgSpec::getIndex(double val, bool must_exist) const
{
   // binary search to find the insertion point
   size_t lo(0) ;
   size_t hi(num_values) ;
   while (lo < hi)
      {
      size_t mid = (lo + hi) / 2 ;
      double midval = value(mid) ;
      if (val < midval)
	 hi = mid ;
      else if (val > midval)
	 lo = mid+1 ;
      else // if (newval == midval)
	 lo = hi = mid ;		// terminate the search right away
      }
   if (must_exist && value(lo) != val)
      return UNKNOWN_VALUE ;
   return lo ;
}

//----------------------------------------------------------------------

bool ArgSpec::insertValue(double newval, bool require_floats,
			  bool make_current, bool force)
{
   if (require_floats)
      use_integers = false ;
   if (numValues() == 1 &&
       (external() ||
	(bias() == Bias_Required && force)))
      {
      // replace the current value
      m_values[0] = newval ;
      if (make_current)
	 m_current = newval ;
      return false ;			// we haven't made a new entry in list
      }
   size_t inspoint = getIndex(newval,false) ;
   if (newval == value(inspoint))
      {
      if (make_current)
	 m_current = newval ;
      return false ;			// not inserted, already present
      }
   double *newvalues = FrNewR(double,m_values,num_values+1) ;
   if (newvalues)
      {
      // make space for the new value, then insert it
      m_values = newvalues ;
      for (size_t i = numValues() ; i > inspoint ; i--)
	 m_values[i] = value(i-1) ;
      m_values[inspoint] = newval ;
      num_values++ ;
      if (make_current)
	 {
	 m_current = newval ;
	 }
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

bool ArgSpec::betterValue(double curr_score, double best_score,
			  double curr_value) const
{
   if (minimize)
      {
      curr_score = -curr_score ;
      best_score = -best_score ;
      }
   if (curr_score > best_score)
      return true ;
   if (curr_score < best_score)
      return false ;
   if (bias() == Bias_Low)
      return curr_value < bestValue() ;
   else if (bias() == Bias_High)
      return curr_value > bestValue() ;
   return false ;
}

//----------------------------------------------------------------------

size_t ArgSpec::listlength() const
{
   const ArgSpec *s = this ;
   size_t count = 0 ;
   while (s)
      {
      count++ ;
      s = s->next() ;
      }
   return count ;
}

//----------------------------------------------------------------------

size_t ArgSpec::tuningArgs() const
{
   const ArgSpec *s = this ;
   size_t count = 0 ;
   while (s)
      {
      if (!s->external())
	 count++ ;
      s = s->next() ;
      }
   return count ;
}

//----------------------------------------------------------------------

ArgSpec *ArgSpec::reverseList()
{
   ArgSpec *curr = this ;
   ArgSpec *prev = 0 ;

   ArgSpec *next ;
   while (curr)
      {
      next = curr->next() ;
      curr->m_next = prev ;
      prev = curr ;
      curr = next ;
      }
   return prev ;
}

//----------------------------------------------------------------------

void ArgSpec::randomizeCurr()
{
   m_current = value(FrRandomNumber(num_values)) ;
   return ;
}

//----------------------------------------------------------------------

double ArgSpec::perturbStep() const
{
   double step ;
   if (useIntegers())
      {
      step = 1.0 + floor(value() / 50) ;
      }
   else
      {
      step = value() * 0.005 ;	    // half a percent of current value
      }
   return step ;
}

//----------------------------------------------------------------------

double ArgSpec::randomPerturbation() const
{
   if (numValues() == 1 && bias() == Bias_Required)
      return value() ;	       		// this is a fixed value, don't perturb
   double adj = perturbStep() ;
   double new_value = value() ;
   if (useIntegers())
      new_value += FrRandomNumber(1+2*(int)adj) - adj ; // -adj .. +adj
   else
      new_value += adj * ((signed)FrRandomNumber(17) - 8) / 2 ;  // -4 .. +4
   // round to nearest thousandth
   new_value = floor(1000.0*new_value + 0.5) / 1000.0 ;
   if (new_value < minAllowable() || new_value > maxAllowable())
      return value() ;
   if ((value() > 0.0 && new_value < 0.0 && minAllowable() == -DBL_MAX) ||
       (value() < 0.0 && new_value > 0.0 && maxAllowable() == DBL_MAX))
      return value() ;			// don't cross zero if no explicit lim
   return new_value ;
}

//----------------------------------------------------------------------

void ArgSpec::perturbRandomly()
{
   double new_value = randomPerturbation() ;
   // insert the new value into the list of values if it doesn't yet exist,
   //   and make it the current value
   insertValue(new_value,false,true,true) ;
   setBest(value()) ;
   return ;
}

//----------------------------------------------------------------------

ArgSpec *ArgSpec::copyList() const
{
   ArgSpec *copy = new ArgSpec(this) ;
   if (copy && next())
      copy->setNext(next()->copyList()) ;
   return copy ;
}

/************************************************************************/
/*	Configuration File editor					*/
/************************************************************************/

static bool param_matches(const char *line, const ArgSpec *spec,
			  const char *active_section,
			  const char **value = 0)
{
   const char *sec = spec->paramSection() ;
   if (sec && *sec && active_section && *active_section &&
       Fr_stricmp(sec,active_section) != 0)
      return false ;
   const char *parm = spec->paramName() ;
   if (!parm)
      return false ;
   size_t namelen = strlen(parm) ;
   if (Fr_strnicmp(line,parm,namelen) != 0)
      return false ;
   line += namelen ;
   char punct = FrSkipWhitespace(line) ;
   if (value)
      {
      if (punct)
	 {
	 line++ ;
	 (void)FrSkipWhitespace(line) ;
	 }
      *value = line ;
      }
   return (punct == ':' || punct == '=') ;
}

//----------------------------------------------------------------------

static bool parse_line(const char *line, ArgSpec *specs,
		       const char *active_section, bool read_all_values)
{
   for ( ; specs ; specs = specs->next())
      {
      const char *value ;
      if (!read_all_values && !specs->external())
	 continue ;			// only get the external parms, not all
      if (param_matches(line,specs,active_section,&value))
	 {
	 if (specs->bias() == Bias_Required && specs->numValues() == 1)
	    return false ;		// found, but not allowed to add value
	 // get current parameter value
	 char *end_i ;
	 char *end_f ;
	 long value_i = strtol(value,&end_i,0) ;
	 double value_f = strtod(value,&end_f) ;
	 if (end_i == value)
	    continue ;			// no value on same line....
	 // and add it to the list of values for the argument spec (making it
	 //   the default)
	 bool floating = value_i < 0 ? (value_f<value_i) : (value_f>value_i) ;
	 specs->insertValue(value_f,floating,true) ;
	 specs->setBest(specs->value()) ;
	 specs->setMarker(specs->value()) ;
	 return true ;
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

static void copy_comment(const char *line, FILE *outfp)
{
   // skip parameter name
   while (*line && *line != ':' && *line != '=')
      line++ ;
   // skip colon/equals after name
   line++ ;
   // skip whitespace before value
   while (*line && Fr_isspace(*line))
      line++ ;
   // skip the value
   while (*line && *line != ';' && *line != '#')
      line++ ;
   if (*line == ';' || *line == '#')
      fprintf(outfp,"\t%s",line) ;
   else
      fputc('\n',outfp) ;
   return ;
}

//----------------------------------------------------------------------

static bool edit_line(const char *line, const ArgSpec *specs,
		      const double *values, bool *written,
		      FILE *outfp, const char *active_section, bool final_run)
{
   for (size_t i = 0 ; specs ; i++, specs = specs->next())
      {
      if (param_matches(line,specs,active_section))
	 {
	 fprintf(outfp,"%s=",specs->paramName()) ;
	 if (final_run)
	    show_parameter_value(specs,specs->bestValue(),outfp,true) ;
	 else
	    show_parameter_value(specs,values[i],outfp,true) ;
	 copy_comment(line,outfp) ;
	 fflush(outfp) ;
	 if (written)
	    written[i] = true ;
	 return true ;
	 }
      }
   fputs(line,outfp) ;
   return false ;
}

/************************************************************************/
/*	Methods for class ParamVector					*/
/************************************************************************/

ParamVector::ParamVector(ArgSpec *args, ArgSpec *activearg, double newvalue,
			 const char *testprog, const char *cfgfile,
			 const char *inputfile)
{
   m_args = args ;
   m_activearg = activearg ;
   m_numargs = args->listlength() ;
   m_values = FrNewC(double,m_numargs+1) ;
   m_integral = FrNewC(bool,m_numargs+1) ;
   if (!m_values || !m_integral)
      m_numargs = 0 ;
   m_configfile = 0 ;
   m_testprog = FrDupString(testprog) ;
   m_inputfile = FrDupString(inputfile) ;
   m_score = worst_score() ;
   m_activeargnum = m_numargs ;
   m_resultline[0] = '\0' ;
   m_externals = false ;
   ArgSpec *a = args ;
   for (size_t i = 0 ; a && i < numArgs() ; a = a->next(), i++)
      {
      m_values[i] = a->value() ;
      m_integral[i] = a->useIntegers() ;
      if (a->external())
	 m_externals = true ;
      if (a == activearg)
	 m_activeargnum = i ;
      }
   m_scoreknown = false ;
   m_finalrun = false ;
   setActiveValue(newvalue) ;
   if (cfgfile)
      editConfig(cfgfile) ;
   return ;
}

//----------------------------------------------------------------------

double *ParamVector::collectValues(const ArgSpec *argspecs)
{
   size_t numargs = argspecs->listlength() ;
   double *values = FrNewN(double,numargs+1) ;
   if (values)
      {
      for (size_t i = 0 ; i < numargs && argspecs ; i++)
	 {
	 values[i] = argspecs->value() ;
	 argspecs = argspecs->next() ;
	 }
      }
   return values ;
}

//----------------------------------------------------------------------

ParamVector::~ParamVector()
{
   FrFree(m_values) ;		m_values = 0 ;
   FrFree(m_integral) ;		m_integral = 0 ;
   if (m_configfile)
      Fr_unlink(m_configfile) ;
   FrFree(m_configfile) ;	m_configfile = 0 ;
   FrFree(m_testprog) ;		m_testprog = 0 ;
   FrFree(m_inputfile) ;	m_inputfile = 0 ;
   m_numargs = 0 ;
   return ;
}

//----------------------------------------------------------------------

const char *ParamVector::activeParamName() const
{
   return m_activearg ? m_activearg->paramName() : "<unk>" ;
}

//----------------------------------------------------------------------

void ParamVector::setActiveValue(double value)
{
   if (integralValue())
      {
      // turn value into integer by truncating toward zero
      value = (value < 0 ? ceil(value) : floor(value)) ;
      }
   m_values[m_activeargnum] = value ;
   return ;
}

//----------------------------------------------------------------------

void ParamVector::replaceArgSpecs(ArgSpec *new_args)
{
   delete args() ;
   m_args = new_args ;
   return ;
}

//----------------------------------------------------------------------

bool ParamVector::editConfig(const char *cfgfile, const char *newconfig)
{
   return editConfig(cfgfile,newconfig,args(),values(),finalRun()) ;
}

//----------------------------------------------------------------------

bool ParamVector::editConfig(const char *cfgfile, const char *newconfig,
			     const ArgSpec *args, const double *values,
			     bool final)
{
   if (!cfgfile || !*cfgfile || !newconfig || !*newconfig)
      return false ;
   FILE *infp = fopen(cfgfile,"r") ;
   FILE *outfp = fopen(newconfig,"w") ;
   if (!infp || !outfp)
      {
      if (infp) fclose(infp) ;
      if (outfp) fclose(outfp) ;
      return false ;
      }
   bool changes = false ;
   char *active_section = 0 ;
   size_t numspecs = args ? args->listlength() : 0 ;
   FrLocalAllocC(bool,written,1024,numspecs) ;
   while (!feof(infp))
      {
      char line[FrMAX_LINE] ;
      if (!fgets(line,sizeof(line),infp))
	 break ;
      if (line[0] == '[')
	 {
	 // we're in a new section of the config file, so get the section name
	 FrFree(active_section) ;
	 active_section = FrDupString(line+1) ;
	 char *end = strchr(active_section,']') ;
	 if (end)
	    *end = '\0' ;
	 }
      if (edit_line(line,args,values,written,outfp,active_section,final))
	 changes = true ;
      }
   FrFree(active_section) ;
   const ArgSpec *specs = args ;
   for (size_t i = 0 ; i < numspecs ; i++, specs = specs->next())
      {
      if (!written[i])
	 cout << "#!! Parameter " << specs->paramName()
	      << " not in config file" << endl ;
      }
   FrLocalFree(written) ;
   fflush(outfp) ;
   (void)fclose(infp) ;
   (void)fclose(outfp) ;
   return changes ;
}

//----------------------------------------------------------------------

bool ParamVector::editConfig(const char *cfgfile)
{
   char *dir = FrFileDirectory(cfgfile) ;
   char *edited_cfg = FrTempFile(FrFileBasename(cfgfile),dir) ;
   FrFree(dir) ;
   if (editConfig(cfgfile,edited_cfg))
      {
      m_configfile = edited_cfg ;
      //FIXME
      return true ;
      }
   else
      {
      FrFree(edited_cfg) ;
      return false ;
      }
}

//----------------------------------------------------------------------

bool ParamVector::canParallelize(const char *testprog, const char *cfgfile,
				 ArgSpec *args, ArgSpec *activearg)
{
   ParamVector *params = new ParamVector(args,activearg,activearg->value(),
					 testprog,cfgfile,
					 activearg->paramName()) ;
   int pipe_in, pipe_out ;
   istream *stream_in ;
   ostream *stream_out ;
   bool multi = false ;
   if (FrExecProgram(0,0,0,0,pipe_in,pipe_out,stream_in,stream_out,cerr,
		     testprog,params->configFile(),activearg->paramName(),
		     "--test",(void*)0))
      {
      char resultline[TUNE_MAX_LINE] ;
      resultline[0] = '\0' ;
      stream_in->getline(resultline,sizeof(resultline)) ;
      FrShutdownPipe(stream_in,stream_out,pipe_in,pipe_out) ;
      if (verbose)
	 fprintf(stdout,"# parallelizability check for %s reported: %s\n",
		 activearg->paramName(),resultline) ;
      multi = Fr_stricmp(resultline,"MULTI") == 0 ;
      }
   delete params ;
   return multi ;
}

//----------------------------------------------------------------------

bool ParamVector::evaluate()
{
   int pipe_in, pipe_out ;
   istream *stream_in ;
   ostream *stream_out ;
   const char *final = (finalRun() ? "--final" : 0) ;
   bool success = false ;
   if (FrExecProgram(0,0,0,0,pipe_in,pipe_out,stream_in,stream_out,cerr,
		     testProgram(),configFile(),testInput(),final,(void*)0))
      {
      m_resultline[0] = '\0' ;
      stream_in->getline(m_resultline,sizeof(m_resultline)) ;
      FrShutdownPipe(stream_in,stream_out,pipe_in,pipe_out) ;
      const char *resultptr = m_resultline ;
      (void)FrSkipWhitespace(resultptr) ;
      char *end ;
      double result = strtod(resultptr,&end) ;
      if (end != resultptr)
	 {
	 m_score = result ;
	 m_scoreknown = true ;
	 success = true ;
	 }
      dumpValues(stdout,true) ;
      }
   else
      {
      fflush(stdout) ;
      fprintf(stderr,"# error executing test program on");
      dumpValues(stderr) ;
      }
   // reap any child processes that are still hanging around as zombies
   while (waitpid(-1,0,WNOHANG) > 0)
      ;
   return success ;
}

//----------------------------------------------------------------------

bool ParamVector::optimizer(const char *testprog,
			    const char *configfile, const char *testinput,
			    ArgSpec *argspecs)
{
   if (verbose)
      printf("# telling eval script to run its optimizer\n") ;
   char *dir = FrFileDirectory(configfile) ;
   char *edited_cfg = FrTempFile(FrFileBasename(configfile),dir) ;
   FrFree(dir) ;
   double *argvalues = ParamVector::collectValues(argspecs) ;
   ParamVector::editConfig(configfile,edited_cfg,argspecs,argvalues,false) ;
   FrFree(argvalues) ;
   int pipe_in, pipe_out ;
   istream *stream_in ;
   ostream *stream_out ;
   bool success = false ;
   if (FrExecProgram(0,0,0,0,pipe_in,pipe_out,stream_in,stream_out,cerr,
		     testprog,edited_cfg,testinput,"--opt",(void*)0))
      {
      char resultline[TUNE_MAX_LINE] ;
      resultline[0] = '\0' ;
      stream_in->getline(resultline,sizeof(resultline)) ;
      FrShutdownPipe(stream_in,stream_out,pipe_in,pipe_out) ;
      printf("# optimize call reported: %s\n",resultline) ;
      success = true ;
      ParamVector::readValues(edited_cfg,argspecs) ;
//      ParamVector::editConfig(edited_cfg,configfile,0,0,false) ;
      }
   Fr_unlink(edited_cfg) ;
   FrFree(edited_cfg) ;
   // reap any child processes that are still hanging around as zombies
   while (waitpid(-1,0,WNOHANG) > 0)
      ;
   return success ;
}

//----------------------------------------------------------------------

bool ParamVector::cleanup(const char *testprog)
{
   if (verbose)
      printf("# telling eval script to clean up\n") ;
   int pipe_in, pipe_out ;
   istream *stream_in ;
   ostream *stream_out ;
   bool success = false ;
   if (FrExecProgram(0,0,0,0,pipe_in,pipe_out,stream_in,stream_out,cerr,
		     testprog,"--cleanup",(void*)0))
      {
      char resultline[TUNE_MAX_LINE] ;
      resultline[0] = '\0' ;
      stream_in->getline(resultline,sizeof(resultline)) ;
      FrShutdownPipe(stream_in,stream_out,pipe_in,pipe_out) ;
      printf("# cleanup call reported: %s\n",resultline) ;
      success = true ;
      }
   // reap any child processes that are still hanging around as zombies
   while (waitpid(-1,0,WNOHANG) > 0)
      ;
   return success ;
}

//----------------------------------------------------------------------

bool ParamVector::readValues(const char *configfile, ArgSpec *specs,
			     bool read_all_values)
{
   FILE *infp = fopen(configfile,"r") ;
   if (!infp)
      return false ;
   FrBool changes = false ;
   char *active_section = 0 ;
   while (!feof(infp))
      {
      char line[FrMAX_LINE] ;
      if (!fgets(line,sizeof(line),infp))
	 break ;
      if (line[0] == '[')
	 {
	 // we're in a new section of the config file, so get the section name
	 FrFree(active_section) ;
	 active_section = FrDupString(line+1) ;
	 char *end = strchr(active_section,']') ;
	 if (end)
	    *end = '\0' ;
	 }
      if (parse_line(line,specs,active_section,read_all_values))
	 changes = true ;
      }
   FrFree(active_section) ;
   (void)fclose(infp) ;
   return changes ;
}

//----------------------------------------------------------------------

bool ParamVector::updateValues(double &best_score, const char *new_config,
			       bool all_args)
{
   if (scoreKnown() && all_args)
      {
      if ((minimize && score() >= best_score) ||
	  (!minimize && score() <= best_score))
	 return false ;
      best_score = score() ;
      ArgSpec *arg = args() ;
      for (size_t i = 0 ; arg && i < m_numargs ; arg = arg->next(), i++)
	 {
	 arg->insertValue(value(i)) ;
	 arg->setCurr(value(i)) ;
	 arg->setBest(value(i)) ;
	 }
      }
   else if (scoreKnown() && activeArg()->betterValue(score(),best_score,
						     value()))
      {
      best_score = score() ;
      ArgSpec *arg = m_activearg ;
      double val = activeValue() ;
      arg->insertValue(val) ;
      arg->setCurr(val) ;
      arg->setBest(val) ;
      }
   else
      return false ;
   if (m_externals)
      {
      // read back any updated values for the external params
      readValues(configFile(),m_args) ;
      }
   editConfig(configFile(),new_config) ;
   return true ;
}

//----------------------------------------------------------------------

void ParamVector::checkResults(ParamVector **vectors, size_t count,
			       double &best_score, const char *new_config,
			       bool all_params)
{
   thread_pool->waitUntilIdle() ;
   // check the results
   if (!all_params && count > 2 && vectors[0] && vectors[0]->scoreKnown() &&
       (1 || vectors[0]->activeArg()->bias() == Bias_None))
      {
      // see whether there are multiple values tied for best, and if so, pick
      //   a median value
      double best = best_score ;
      size_t first = (size_t)~0 ;
      size_t last = 0 ;
      for (size_t i = 0 ; i < count ; i++)
	 {
	 if (!vectors[i] || !vectors[i]->scoreKnown())
	    continue ;
	 if ((minimize && vectors[i]->score() < best) ||
	     (!minimize && vectors[i]->score() > best))
	    {
	    best = vectors[i]->score() ;
	    first = i ;
	    for (last = first + 1 ; last < count ; last++)
	       {
	       if (vectors[last]->score() != vectors[first]->score())
		  {
		  last-- ;
		  break ;
		  }
	       }
	    if (last >= count)
	       last = count-1 ;
	    }
	 }
      if (last >= first)
	 {
         size_t mid = (first + last) / 2 ;
	 if (vectors[mid] && vectors[mid]->scoreKnown())
	    {
	    vectors[mid]->updateValues(best_score,new_config,all_params) ;
	    for (size_t i = 0 ; i < count ; i++)
	       {
	       delete vectors[i] ;
	       vectors[i] = 0 ;
	       }
	    return ;
	    }
	 }
      }
   for (size_t i = 0 ; i < count ; i++)
      {
      if (vectors[i])
	 vectors[i]->updateValues(best_score,new_config,all_params) ;
      delete vectors[i] ;
      vectors[i] = 0 ;
      }
   return ;
}

//----------------------------------------------------------------------

static FrMutex output_mutex ;

void ParamVector::dumpValues(FILE *fp, bool echo) const
{
   FrCRITSECT_ENTER(output_mutex) ;
   if (echo)
      {
      if (m_resultline[0])
	 {
	 const char *resultptr = m_resultline ;
	 (void)FrSkipWhitespace(resultptr) ;
	 fprintf(fp,"%.60s", resultptr) ;
	 }
      else
	 {
	 fprintf(fp,"# no result") ;
	 }
      }
   if (values())
      {
      const ArgSpec *as = args() ;
      for (size_t i = 0 ; as ; as = as->next(), i++)
	 {
	 if (as->bias() != Bias_Required || as->numValues() != 1)
	    show_parameter_value(as,value(i),fp,true,false,as->external()) ;
	 }
      }
   if (values() || echo)
      {
      fprintf(fp,"\n") ;
      fflush(fp) ;
      }
   FrCRITSECT_LEAVE(output_mutex) ;
   return ;
}

/************************************************************************/
/************************************************************************/

static void evaluate_paramvector(const void *, void *paramptr)
{
   ParamVector *params = reinterpret_cast<ParamVector*>(paramptr) ;
   if (!abort_requested())
      (void)params->evaluate() ;
   return ;
}

//----------------------------------------------------------------------

static double next_value(const ArgSpec *spec, size_t val, size_t prev_val)
{
   double curr = spec->value(val) ;
   double diff = curr - spec->value(prev_val) ;
   if (val == 0 && !spec->useIntegers() && curr > 0 && diff > curr / 2)
      diff = curr / 2 ;
   double next = curr + diff ;
   if (!same_sign(next,curr))
      {
      if (spec->useIntegers())
	 {
	 next = curr + (val < prev_val ? -1 : +1) ;
	 if (next == 0)
	    next = curr ;
	 }
      else
	 {
	 next = curr / 2 ;
	 // round to 6 decimal places
	 next = floor(100000.0*next + 0.5) / 100000.0 ;
	 }
      }
   return next ;
}

//----------------------------------------------------------------------

#define fabs(x) (((x)>=0)?x:-x)

static bool subdividable(const ArgSpec *spec, size_t set1, size_t set2,
			 double &midpoint)
{
   if (!spec)
      return false ;
   double val1 = spec->value(set1) ;
   double val2 = spec->value(set2) ;
   bool divisible ;
   if (spec->useIntegers())
      {
      divisible = fabs(val2-val1) >= 2.0 ;
      midpoint = val1 + (int)((val2 - val1) / 2.0 + 0.01) ;
      }
   else
      {
      divisible = fabs(val2-val1) >= 0.02 ;
      midpoint = val1 + ((val2 - val1) / 2.0) ;
      }
   return divisible ;
}

//----------------------------------------------------------------------

static void wait_on_eval(bool &wait)
{
   if (wait)
      {
      thread_pool->waitUntilIdle() ;
      wait = false ;
      }
   return ;
}

//----------------------------------------------------------------------

static void eval_local_performance(ArgSpec *argspecs, ArgSpec *currspec,
				   size_t iterations, double &best_score,
				   const char *testprog, const char *cfgfile,
				   const char *testinput,
				   size_t &maxtries, size_t &maxiter,
				   const char *new_config, bool wait_for_first)
{
   double argstep = currspec->perturbStep() ;
   double start_val = currspec->value() ;
   double lo_limit = currspec->minAllowable() ;
   double hi_limit = currspec->maxAllowable() ;
   // perturb both up and down in parallel, moving outward from the initial
   //   value until there is no longer improvement in that direction
   ParamVector *vectors[2] ;
   size_t first = 1 ;
   // on the very first iteration, we need to evaluate the performance
   //   without perturbation to get the baseline score
   if (iterations == 0 && start_val == currspec->marker())
      first = 0 ;
   for (size_t i = first ; i <= MAX_LOCAL_STEPS ; i++)
      {
      double lo = start_val - i * argstep ;
      vectors[0] = vectors[1] = 0 ;
      if (lo >= lo_limit)
	 {
	 vectors[0] = new ParamVector(argspecs,currspec,lo,testprog,
				      cfgfile,testinput) ;
	 thread_pool->dispatch(evaluate_paramvector,vectors[0],vectors[0]) ;
	 wait_on_eval(wait_for_first) ;
	 }
      double hi = start_val + i * argstep ;
      if (hi <= hi_limit && hi != lo)
	 {
	 vectors[1] = new ParamVector(argspecs,currspec,hi,testprog,
				      cfgfile,testinput) ;
	 thread_pool->dispatch(evaluate_paramvector,vectors[1],vectors[1]) ;
	 wait_on_eval(wait_for_first) ;
	 }
      if (vectors[0] == 0 && vectors[1] == 0)
	 break ;
      thread_pool->waitUntilIdle() ;
      if (vectors[0])
	 {
	 if (vectors[0]->activeArg()->betterValue(best_score,
						  vectors[0]->score(),
						  vectors[0]->value()))
	    lo_limit = start_val ;
	 else
	    vectors[0]->updateValues(best_score,new_config) ;
	 delete vectors[0] ;
	 }
      if (vectors[1])
	 {
	 if (vectors[1]->activeArg()->betterValue(best_score,
						  vectors[1]->score(),
						  vectors[1]->value()))
	    hi_limit = start_val ;
	 else
	    vectors[1]->updateValues(best_score,new_config) ;
	 delete vectors[1] ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

static bool eval_performance(ArgSpec *argspecs, ArgSpec *currspec,
			     size_t iterations, double &best_score,
			     const char *testprog, const char *cfgfile,
			     const char *testinput,
			     size_t &maxtries, size_t &maxiter,
			     const char *new_config, bool wait_for_first)
{
   size_t start_val = 0 ;
   if (iterations == 0 && maxtries == 1)
      start_val = currspec->currIndex() ;
   size_t num_values = currspec->numValues() ;
   ParamVector **vectors = FrNewC(ParamVector*,num_values + 2) ;
   if (!vectors)
      {
      FrNoMemory("setting up parameter vectors") ;
      return false ;
      }
   size_t pending = 0 ;
   bool evaluated = false ;
   for (size_t val = start_val ; val < num_values ; val++)
      {
      // after optimizing the first parameter, we don't need to
      //   check the current setting of the active parameter because
      //   its score has already been generated and checked
      if (iterations > 0 && 
	  (currspec->external() ||
	   (currspec->value(val) == currspec->marker() &&
	    !use_external_optimizer)
	   ))
	 {
	 if (verbose)
	    cout << "# skipping value " << currspec->value(val) << endl ;
	 continue ;
	 }
      if (pending >= maxtries)
	 break ;
      ParamVector *params = new ParamVector(argspecs,currspec,
					    currspec->value(val),
					    testprog,cfgfile,testinput) ;
      vectors[pending++] = params ;
      (void)thread_pool->dispatch(evaluate_paramvector,params,params) ;
      evaluated = true ;
      wait_on_eval(wait_for_first) ;
      }
   maxtries -= pending ;
   if (maxtries <= 0 || abort_requested())
      maxiter = 0 ;
   ParamVector::checkResults(vectors,pending,best_score,new_config) ;

   size_t extensions = 0 ; 
   while (currspec->bestValue() <= currspec->lowestValue() &&
	  currspec->numValues() > 1 &&
	  extensions++ < 10 && maxtries > 0)
      {
      // try expanding the range downward
      double nextvalue = next_value(currspec,0,1) ;
      // don't go below the stated minimum for the parameter
      // also don't cross zero, in case that's a limit on the parameter,
      //   unless we have an explicitly stated minimum
      if ((nextvalue < currspec->minAllowable() ||
	   nextvalue == currspec->value(0) ||
	   (currspec->minAllowable() == -DBL_MAX &&
	    !same_sign(nextvalue,currspec->value(0)))))
	 break ;
      if (verbose)
	 cout << "# extending range down to " << nextvalue << endl ;
      ParamVector *params = new ParamVector(argspecs,currspec,nextvalue,
					    testprog,cfgfile,testinput) ;
      bool better = false ;
      if (params->evaluate())
	 {
	 better = params->updateValues(best_score,new_config) ;
	 }
      delete params ;
      if (!better)
	 break ;
      if (--maxtries <= 0 || abort_requested())
	 {
	 maxiter = 0 ;
	 break ;
	 }
      }
   extensions = 0 ;
   while (currspec->bestValue() >= currspec->highestValue() &&
	  currspec->numValues() > 1 && extensions++ < 10 && maxtries > 0)
      {
      // try expanding the range upward
      double nextvalue = next_value(currspec,currspec->numValues()-1,
				    currspec->numValues()-2) ;
      // don't go above the stated maximum for the parameter
      // also don't cross zero, in case that's a limit on the parameter,
      //   unless we have an explicitly stated maximum
      if ((nextvalue > currspec->maxAllowable() ||
	   nextvalue == currspec->value(currspec->numValues()-1) ||
	   (currspec->maxAllowable() == DBL_MAX &&
	    !same_sign(nextvalue,currspec->bestValue()))))
	 break ;
      if (verbose)
	 cout << "# extending range up to " << nextvalue << endl ;
      ParamVector *params = new ParamVector(argspecs,currspec,nextvalue,
					    testprog,cfgfile,testinput) ;
      bool better = false ;
      if (params->evaluate())
	 {
	 better = params->updateValues(best_score,new_config) ;
	 }
      delete params ;
      if (!better)
	 break ;
      if (--maxtries <= 0 || abort_requested())
	 {
	 maxiter = 0 ;
	 break ;
	 }
      }
   // try subdividing the space between the best value and its neighbors
   double best = currspec->bestValue() ;
   pending = 0 ;
   if (allow_subdivision && maxtries > 0 &&
       best > currspec->lowestValue() && best < currspec->highestValue())
      {
      double midpoint ;
      size_t best_idx = currspec->getIndex(best) ;
      if (!abort_requested() &&
	  subdividable(currspec,best_idx,best_idx+1,midpoint))
	 {
	 // add right neighbor
	 ParamVector *params = new ParamVector(argspecs,currspec,midpoint,
					       testprog,cfgfile,testinput) ;
	 vectors[pending++] = params ;
	 (void)thread_pool->dispatch(evaluate_paramvector,params,params) ;
	 maxtries-- ;
	 }
      if (!abort_requested() &&
	  subdividable(currspec,best_idx-1,best_idx,midpoint))
	 {
	 // add left neighbor
	 ParamVector *params = new ParamVector(argspecs,currspec,midpoint,
					       testprog,cfgfile,testinput) ;
	 vectors[pending++] = params ;
	 (void)thread_pool->dispatch(evaluate_paramvector,params,params) ;
	 maxtries-- ;
	 }
      }
   ParamVector::checkResults(vectors,pending,best_score,new_config) ;
   FrFree(vectors) ;
   return evaluated ;
}

//----------------------------------------------------------------------

static double tune_parameters(const char *testprog, const char *cfgfile,
			      const char *testinput, ArgSpec *argspecs,
			      size_t maxiter, size_t maxtries,
			      double best_score,
			      const char *new_config = 0,
			      bool perturb_locally = false)
{
   if (!argspecs || abort_requested())
      return best_score ;
   ArgSpec *currspec = argspecs ;
   size_t num_specs = argspecs->listlength() ;
   // loop until convergence
   size_t iterations = 0 ;
   size_t total_params = 0 ;
   size_t tested_params = 0 ;
   size_t unchanged_parms = 0 ;
   bool just_optimized = false ;
   do {
      // try each value of the current parameter and pick the maximum
      currspec->setMarker(currspec->bestValue()) ;
      double origscore = best_score ;
      if (use_external_optimizer &&
	  tested_params % use_external_optimizer == 0 &&
	  !just_optimized)
	 {
	 ParamVector::optimizer(testprog,cfgfile,testinput,argspecs) ;
	 ParamVector *vectors[2] ;
	 vectors[0] = new ParamVector(argspecs,argspecs,argspecs->value(),
				      testprog,cfgfile,testinput) ;
	 vectors[1] = 0 ;
	 thread_pool->dispatch(evaluate_paramvector,vectors[0],vectors[0]) ;
	 double new_best_score = best_score * 0.9 ;
	 ParamVector::checkResults(vectors,1,new_best_score,new_config,true) ;
	 // reset the best score, because it's possible for the external
	 //   optimizer to result in a lower score on the official eval
	 // (but if it's too much lower, we want to bail out)
	 if (new_best_score == best_score * 0.9)
	    break ;
	 best_score = new_best_score ;
	 just_optimized = true ;
	 }
      total_params++ ;
      if (currspec->bias() != Bias_Required || currspec->numValues() != 1)
	 {
	 if (!currspec->external())
	    tested_params++ ;
	 if (maxiter > 1 || maxtries > 1)
	    {
	    // (don't say anything about which parameter is being adjusted
	    //   when evaluating a random point)
	    const char *sect = currspec->paramSection() ;
	    printf("# adjusting %s%s%s, trying to improve on %g\n",
		   sect?sect:"",sect?":":"",currspec->paramName(),best_score) ;
	    fflush(stdout) ;
	    }
	 bool wait_for_first =
	    (iterations != 0 &&
	     currspec->numValues() != 1 &&
	     !ParamVector::canParallelize(testprog,cfgfile,
					  argspecs,currspec)) ;
	 if (perturb_locally)
	    {
	    for (ArgSpec *a = argspecs ; a ; a = a->next())
	       {
	       a->setBest(a->value()) ;
	       }
	    eval_local_performance(argspecs,currspec,iterations,best_score,
				   testprog,cfgfile,testinput,
				   maxtries,maxiter,new_config,wait_for_first);
	    just_optimized = false ;
	    }
	 else if (eval_performance(argspecs,currspec,iterations,best_score,
				   testprog,cfgfile,testinput,maxtries,
				   maxiter,new_config,wait_for_first))
	    {
	    just_optimized = false ;
	    }
	 // set the parameter to the best value found
	 currspec->setCurr(currspec->bestValue()) ;
	 iterations++ ;
	 }
      // keep track of how long we've gone without an improvement
      if (currspec->bestValue() == currspec->marker() ||
	  best_score == origscore)
	 unchanged_parms++ ;
      else
	 unchanged_parms = 0 ;
      // advance to the next parameter
      currspec = currspec->next() ;
      if (!currspec)
	 currspec = argspecs ;
      } while (unchanged_parms < num_specs && iterations < maxiter &&
	       !abort_requested()) ;
   return best_score ;
}

//----------------------------------------------------------------------

static void randomize_parameters(ArgSpec *argspecs, bool seed)
{
   if (seed)
      {
      unsigned int t = (unsigned int)time(0) - time_offset ;
      FrSeedRandom(t) ;
      }
   for ( ; argspecs ; argspecs = argspecs->next())
      argspecs->randomizeCurr() ;
   return ;
}

//----------------------------------------------------------------------

static double init_parameters(const char *testprog, const char *cfgfile,
			      const char *testinput, ArgSpec *argspecs,
			      size_t tries, double best_score,
			      const char *new_config)
{
   if (randomize_all)
      {
      size_t num_args = (3*argspecs->tuningArgs() + argspecs->listlength()) / 4;
      size_t init_points = tries * num_args ;
      if (init_points > 200)
	 init_points = init_points / 2 ;
      else if (init_points > 75)
	 init_points = (2 * init_points / 3) ;
      else if (init_points > 40)
	 init_points = (3 * init_points / 4) ;
      ParamVector **vectors = FrNewC(ParamVector*,init_points) ;
      if (!vectors)
	 {
	 FrNoMemory("while setting up randomized points") ;
	 return best_score ;
	 }
      cout << "# checking " << init_points << " starting points" << endl ;
      for (size_t i = 0 ; i < init_points ; i++)
	 {
	 randomize_parameters(argspecs,i == 0) ;
	 vectors[i] = new ParamVector(argspecs,argspecs,argspecs->value(),
				      testprog,cfgfile,testinput) ;
	 thread_pool->dispatch(evaluate_paramvector,vectors[i],vectors[i]) ;
	 }
      ParamVector::checkResults(vectors,init_points,best_score,new_config,
				true) ;
      FrFree(vectors) ;
      cout << "# best initial score: " << best_score << endl ;
      }
   return best_score ;
}

//----------------------------------------------------------------------

static ArgSpec *try_random_perturbations(ArgSpec *argspecs, double &best_score,
					 const char *testprog,
					 const char*cfgfile,
					 const char *testinput,
					 const char *new_config)
{
   FrSeedRandom() ;
   size_t max_init = minimum(argspecs->listlength(),20) ;
   cout << "# trying " << max_init << " initial perturbations" << endl ;
   ParamVector **vectors = FrNewC(ParamVector*,max_init) ;
   for (size_t i = 0 ; i < max_init && !abort_requested() ; i++)
      {
      ArgSpec *argspecs2 = argspecs->copyList() ;
      for (ArgSpec *spec = argspecs2 ; spec ; spec = spec->next())
	 {
	 if (!spec->external())
	    spec->perturbRandomly() ;
	 }
      vectors[i] = new ParamVector(argspecs2,argspecs2,argspecs2->value(),
				   testprog,cfgfile,testinput) ;
      thread_pool->dispatch(evaluate_paramvector,vectors[i],vectors[i]) ;
      }
   thread_pool->waitUntilIdle() ;
   for (size_t i = 0 ; i < max_init ; i++)
      {
      vectors[i]->replaceArgSpecs(argspecs) ;
      }
   ParamVector::checkResults(vectors,max_init,best_score,new_config,true) ;
   FrFree(vectors) ;
   return argspecs ; 
}

//----------------------------------------------------------------------

static void sigint_handler(int)
{
   request_abort() ;
   printf("*** user interrupt, will stop after current runs ***\n") ;
   fflush(stdout) ;
   // next time, allow ourselves to be killed
   delete sigint ;
   sigint = 0 ;
   return ;
}

//----------------------------------------------------------------------

static int usage(const char *argv0)
{
   argv0 = FrFileBasename(argv0) ;
   fprintf(stderr,
	   "Hill-Climbing Parameter Tuner v" VERSION " (c) 2005-2010 Ralf Brown\n"
	   "Usage: %s [flags] testprog cfgfile input parm1 values [parm2 values ...]\n"
	   "\t'parmN' may be of the form 'section:name' or just 'name'\n"
	   "\t'values' may be a space/underscore-separated list in quotes or in\n"
	   "\tthe form 'A_B/N', where A and B are minimum and maximum values and\n"
	   "\tN is the number of points within that range to test.  If neither A\n"
	   "\tnor B contains a decimal point, only integral values will be used.\n"
	   "Flags:\n"
	   "\t-cF\tcreate new config file F edited with the tuned parameters\n"
	   "\t-C#\trun up to # evaluations concurrently (default 1)\n"
	   "\t-iN\tlimit total iterations to N parameters\n"
	   "\t-l\tattempt to find parameters yielding lowest score, not highest\n"
	   "\t-m\tshow memory usage\n"
	   "\t-oN\toffset randomization seed by N days from current time\n"
	   "\t-On\ttell testprog to run its own optimizer after every 'n' params\n"
	   "\t-p\tpreserve current parameters from configuration file\n"
	   "\t-r\trandomize starting values for range parameters\n"
	   "\t-r -r\trandomize starting values for all parameters\n"
	   "\t-s\tdisallow search of parameter values between those given\n"
	   "\t-tN\tlimit total parameter combinations tried to N\n"
	   "\t-V[F]\tvalidate score with a final run of the testprog (allows it\n"
	   "\t\t to provide updated parameters, e.g. for MER training).  If\n"
	   "\t\t 'F' is specified, use that file instead of the regular input\n"
	   "\t\t file for the validation run.\n",
	   argv0) ;
   exit(1) ;
}

//----------------------------------------------------------------------

int main(int argc, char **argv)
{
   const char *argv0 = argv[0] ;
   size_t maxiter = INT_MAX ;
   size_t maxtries = INT_MAX ;
   bool showmem = false ;
   bool preserve_current_values = false ;
   bool validate_score = false ;
   bool perturb_randomly = false ;
   bool perturb_locally = false ;
   const char *new_config = 0 ;
   const char *validate_input = 0 ;
   while (argc > 1 && argv[1][0] == '-')
      {
      switch (argv[1][1])
	 {
	 case 'C':
	    max_concurrency = atoi(argv[1]+2) ;
	    break ;
	 case 'c':
	    new_config = argv[1]+2 ;
	    break ;
	 case 'i':
	    maxiter = strtoul(argv[1]+2,0,0) ;
	    break ;
	 case 'l':
	    minimize = true ;
	    break ;
	 case 'm':
	    showmem = true ;
	    break ;
	 case 'o':
	    time_offset = atoi(argv[1]+2) * 86400L ; // convert days to seconds
	    break ;
	 case 'O':
	    use_external_optimizer = 1 ;
	    if (argv[1][2] && Fr_isdigit(argv[1][2]))
	       use_external_optimizer = (unsigned)atol(argv[1]+2) ;
	    break ;
	 case 'p':
	    preserve_current_values = true ;
	    if (argv[1][2] == 'r')
	       {
	       perturb_randomly = true ;
	       perturb_locally = false ;
	       randomize_all = false ;
	       }
	    else if (argv[1][2] == 'l')
	       {
	       perturb_locally = true ;
	       perturb_randomly = false ;
	       randomize_all = false ;
	       }
	    break ;
	 case 'r':
	    if (randomize)
	       randomize_all = true ;
	    randomize = true ;
	    FrSeedRandom() ;
	    break ;
	 case 's':
	    allow_subdivision = false ;
	    break ;
	 case 't':
	    maxtries = strtoul(argv[1]+2,0,0) ;
	    break ;
	 case 'v':
	    verbose = true ;
	    break ;
	 case 'V':
	    validate_score = true ;
	    if (argv[1][2])
	       validate_input = argv[1]+2 ;
	    break ;
	 default:
	    usage(argv0) ;
	    return 1 ;
	 }
      argv++ ;
      argc-- ;
      }
   if (argc < 6)
      usage(argv0) ;
   const char *testprog = argv[1] ;
   const char *cfgfile = argv[2] ;
   const char *testinput = argv[3] ;
   argv += 3 ;
   argc -= 3 ;
   if (!validate_input)
      validate_input = testinput ;
   if (max_concurrency < 1)
      max_concurrency = 1 ;
   ArgSpec *argspecs = 0 ;
   bool have_external_parms = false ;
   while (argc > 2)
      {
      // convert any underscores in the parameter-values spec into blanks
      for (char *sp = argv[2] ; *sp ; sp++)
	 if (*sp == '_') *sp = ' ' ;
      argspecs = new ArgSpec(argv[1],argv[2],argspecs) ;
      if (!argspecs->OK())
	 {
	 fprintf(stderr,"Error parsing parameter specification '%s' '%s'\n",
		 argv[1],argv[2]) ;
	 return 2 ; 
	 }
      if (argspecs->external())
	 have_external_parms = true ;
      argv += 2 ;
      argc -= 2 ;
      }
   if (!argspecs)
      {
      fprintf(stderr,"No tunable parameters specified\n") ;
      return 2 ;
      }
   ParamVector::readValues(cfgfile,argspecs,preserve_current_values) ;
   argspecs = argspecs->reverseList() ;
   thread_pool = FrCreateGlobalThreadPool(max_concurrency) ;
   if (!thread_pool)
      {
      fprintf(stderr,"Unable to initialize thread pool\n") ;
      return 3 ;
      }
   sigint = new FrSignalHandler(SIGINT,sigint_handler) ;
   double best_score = worst_score() ;
   if (perturb_randomly)
      {
      argspecs = try_random_perturbations(argspecs,best_score,testprog,cfgfile,
					  testinput,new_config) ;
      }
   //
   // output the parameter values to be tested
   //
   printf("# Tuning \"%s %s %s\" over\n",testprog,cfgfile,testinput) ;
   show_parameter_values(argspecs,true) ;
   best_score = init_parameters(testprog,cfgfile,testinput,argspecs,
				INIT_TRIES,best_score,new_config) ;
   best_score = tune_parameters(testprog,cfgfile,testinput,argspecs,
				maxiter,maxtries,best_score,
				new_config,perturb_locally) ;
   fflush(stdout) ;
   if (validate_score && have_external_parms)
      {
      printf("# Validating score of %g\n",best_score) ;
      fflush(stdout) ;
      best_score = worst_score() ;
      for (ArgSpec *as = argspecs ; as ; as = as->next())
	 as->setCurr(as->bestValue()) ;
      ParamVector *params = new ParamVector(argspecs,argspecs,
					    argspecs->value(),
					    testprog,cfgfile,validate_input) ;
      params->setFinalRun() ;
      if (params->evaluate())
	 {
	 params->updateValues(best_score,new_config) ;
	 }
      delete params ;
      }
   // tell evaluation program to clear any cached data
   ParamVector::cleanup(testprog) ;
   printf("### Best Result: %g\n",best_score) ;
   show_parameter_values(argspecs,false) ;
   // final cleanup
   delete argspecs ;
   FrDestroyGlobalThreadPool(thread_pool) ;
   if (showmem)
      FrMemoryStats() ;
   delete sigint ;
   sigint = 0 ;
   return 0 ;
}

// end of file tune.cpp //
