#!/bin/csh -f
## Last Edit: 10apr10
##	by Ralf Brown <ralf@cs.cmu.edu>					##
##									##
##  (c) Copyright 2005,2006,2007,2008,2009,2010 Ralf Brown		##
##	This program is free software; you can redistribute it and/or	##
##	modify it under the terms of the GNU General Public License as	##
##	published by the Free Software Foundation, version 3.		##
##									##
##	This program is distributed in the hope that it will be		##
##	useful, but WITHOUT ANY WARRANTY; without even the implied	##
##	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		##
##	PURPOSE.  See the GNU General Public License for more details.	##
##									##
##	You should have received a copy of the GNU General Public	##
##	License (file COPYING) along with this program.  If not, see	##
##	http://www.gnu.org/licenses/					##

set verb=""
set rand=""
set use_existing=""
set offset=""
set run_opt=""
set tries=""
set min=""
set newcfg=""
set mer_training=""
set concur="1"
set cd="."
set extraparms=""
unset lmonly

# default parameter values to try, may be modified by cmdline flags
set lmscale="1.0_0.6_0.7_0.8_0.9_1.1_1.2_1.4_1.6_2.0_2.2"
set verbositypen="-Brevity-Byte 0.2_3.0/15 -Brevity-Word 0.0_1.5/16 -Verbosity-Byte 0.2_5.0/25 -Verbosity-Word 0.0_3.0/16 =LMWeights:WordCount 0.0"
set arcweight="LMWeights:ArcWeight 0.50_1.75/6"
set lenbonus="LMWeights:Length2Bonus 0.3_1.5/13 LMWeights:Length3Bonus 0.3_1.5/13 LMWeights:Length4Bonus 0.3_1.5/13 LMWeights:Length5Bonus 0.3_1.5/13 LMWeights:Length6Bonus 0.3_1.5/13 LMWeights:LengthPlusBonus 0.3_1.5/13"
set ovrbonus="LMWeights:Overlap 0.5_3.5/13"
set untrans="LMWeights:Untranslated 0.25_1.75/7"
set reorderpen="LMWeights:Reordering 0.05_-0.05_-0.03_-0.01_0.02_0.07_0.10_0.15_0.20_0.30_0.40_0.50_0.60 LMWeights:Reordering2 0.05_0.70/14"
set lengths="0.9_1.05/16"
set beamwidth="70_80_100_120_150_200_250_300_350_400_500"
set beamwidth_fast="80"
set punct="-LMWeights:Reorder-Punct>0 0.0_3.0/13 LMWeights:Reorder-Punct-EOS>0 0.5_4.0/15"
set ngrams="-LanguageModeler:Longest-Ngram>2 6_3_4_5"
set ngramlen=""
set unidup0=""
set unidup0v=""
set unidup=""
set unimax=""
set chunking=""
set docwt=""
set srcfeat=""
set userweights=""
set alignweights=""
set future=""
set multipath=""
set multiengine=""
set nulltrans=""
set interleave="LMWeights:Interleave -1.5_-1.0_-0.5_0.0_0.5_1.0_1.5_2.0_3.0_4.0"
set confidence="LMWeights:Confidence @"
set other="LMWeights:Gaps-Discarded @ =LMWeights:Engine-LM 0"
set oovpenalty="LMWeights:OOV 0.0_1.0/6"
set arccount="LMWeights:ArcCount 0.0_0.4/9"
set reinforcement="LMWeights:Reinforcement 0.0_1.0/6"
set beamratio="-Beam-Ratio>1.1			1.2_1.3_1.4_1.5_1.6_1.8_2.0_2.5_3"
set quality="LMWeights:Quality			0.5_0.6_0.7_0.8_0.9_1.0_1.1_1.2_1.5_2.0_2.5_3.0"
set score="LMWeights:Score 0.5_1.5/21 =LMWeights:Probability 1.0"
set frequency="LMWeights:Frequency 0.0_0.5/21"
set mass="LMWeights:Mass 0.0_0.2/21"
set alignment="LMWeights:Alignment 0.0_0.5/21"
set origweight="LMWeights:Origin-Weight 0.0_0.24/13"
set multiref="LMWeights:MultiRef 0.02_0.34/17"
set complete="LMWeights:Complete 0.0_1.0/11"
set sourcefeat="LMWeights:Source-Features 0.0_0.5/21"
set maxdup0="=EBMT:Max-Duplicates		80"
set maxdup="-EBMT:Max-Duplicates		75_80_90_100_110_120_130_150_175_200_225_250"
set maxalt="=EBMT:Max-Alternatives		50	-LMEngine-EBMT:Max-Alts>1 2_10/9"
set alignthresh="-EBMT:Align-Threshold		0.02_0.00_0.04_0.06_0.10_0.15_0.20_0.25"
set doccontext=""
set context="LMWeights:PhrContext 0.5_2.0/16 LMWeights:PhrContext1 0.5_2.0/16 LMWeights:PhrContext2 0.5_2.0/16 LMWeights:PhrContext3 0.5_2.0/16 LMWeights:PhrContext4 0.5_2.0/16 LMWeights:PhrContext5 0.5_2.0/16 LMWeights:PhrContext6 0.5_2.0/16 LMWeights:PhrContextPlus 0.5_2.0/16 LMWeights:SntContext 0.1_1.0/10"
set dictxlat="=EBMT:Max-Dict-Xlat 		40 	-LMEngine-Dict:Max-Alts>1 1_6/6"
set ebmtweight="LMWeights:Engine-EBMT		-1.5_2.5/17"
set dictweight="LMWeights:Engine-DICT 		-0.5_0.5/11"
set window="3_2_4_5"
set nbest=200

# if we were invoked via the cluster scheduler, get the caller's working directory
#  rather than the temporary directory in which we were invoked
if ($?PBS_O_WORKDIR) then
   if ("x$PBS_O_WORKDIR" != "x") set cd="$PBS_O_WORKDIR"
   chdir $cd
endif

while ( "x$1" =~ x-* )
   switch ("$1")
    case "-alignonly":
       set alignonly
       # fall through
    case "-align":
       set alignweights=(AlignSc-Inside   	12_48.0/10 \
			 AlignSc-Outside  	12_56.0/12 \
			 AlignSc-MatchGap 	1_6.0/6 \
			 AlignSc-LengthRatio 	0.4_1.6/7 \
			 AlignSc-SentBounds 	0.025_0.175/7 \
			 AlignSc-SurfaceMatch 	0.0_0.8/9 \
			 AlignSc-Excised 	0.0_0.12/13)
#		      	 "=AlignSc-SrcCover" 	1.0)
       breaksw
    case "-b":
       set lengths="1.8_2.1/16"
       breaksw
    case "-B":
       set lengths="0.45_0.525/16"
       breaksw
    case "-c":
       shift
       set newcfg="-c$1"
       breaksw
    case "-C":
       shift
       set concur="$1"
       breaksw
    case "-cunei":
       set run_opt="-O10"
       if ( ! $?TUNE_PANLITE_CUNEI ) setenv TUNE_PANLITE_CUNEI
       breaksw
    case "-dict":
    case "-dictonly":
       set dictonly
       breaksw
    case "-ebmt":
    case "-ebmtonly":
       set ebmtonly
       set dictweight=""
       set dictxlat=""
       breaksw
    case "-f":
    case "-fast":
       set fasttune
       breaksw
    case "-faster":
       set fasttune
       set omitsubsumed
       breaksw
    case -fast2:
       set fasttune
       set fasttune2			# only run phase 2 of fast tuning
       breaksw
    case -imp:
    case -important:
       set important_only		# skip parms with little effect
       breaksw
    case -keep:
       setenv TUNE_PANLITE_KEEPTMP
       breaksw
    case -lmonly:
       set lmonly
       breaksw
    case -lr:
       shift
       set force_lenratio="$1"
       breaksw
    case -l:
    case -m:
       set min="-l"
       breaksw
    case -loglin:
       # no-op now
       breaksw
    case -merfile:
       shift
       set mer_file="$1"
       breaksw
    case -mer:
       setenv TUNE_MER_FINAL
    case -MER:
       set mer_training="-V"
       shift
       set nbest="$1"
       breaksw
    case -moses:
       set force_lenratio="0.001"
       set verbositypen="LMWeights:WordCount 0.002_0.024/12 =LMWeights:Brevity-Word 0 =LMWeights:Brevity-Byte 0 =LMWeights:Verbosity-Word 0 =LMWeights:Verbosity-Byte 0"
       breaksw
    case -me:
       set multiengine="LMWeights:MultiEngine 0.0_5.0/11"
       breaksw
    case -mp:
       set multipath="LMWeights:MultiPath -2.0_30.0/17"
       breaksw
    case -n:
       set ngrams="-LanguageModeler:Longest-Ngram>2 6_3_4_5_7_8"
       breaksw
    case "-ng":
       set ngramlen="LMWeights:NgramLength 0.0_-1.5_-1.0_-0.5_0.1_0.25_0.5_1.0_1.5_2.0_3.0 LMWeights:NGrams1 0.0_1.0/11 LMWeights:NGrams2 0.0_1.0/11 LMWeights:NGrams3 0.0_1.5/16 LMWeights:NGrams4 0.0_1.5/16 LMWeights:NGrams5 0.0_2.0/11 LMWeights:NGrams6 0.0_2.0/11 LMWeights:NGramsLong 0.0_2.0/11"
       breaksw
    case "-nl":
       set ngrams="-LanguageModeler:Longest-Ngram>2 16_5_6_7_8_10_12_14_18_20_22_24"
       set window="3_2_4_5_6_7"
       breaksw
    case "-nn":
       set ngrams=""
       breaksw
    case "-np":
       set punct=""
       breaksw
    case "-o":
       shift
       set offset="-o$1"
       breaksw
    case "-opt":
       unsetenv TUNE_PANLITE_CUNEI
       set run_opt="-O4"
       breaksw
    case "-p":
       set use_existing=-p
       breaksw
    case -pr:
       set use_existing=-pr
       breaksw
    case -pl:
       set use_existing=-pl
       breaksw
    case -r:
       set rand="-r $rand"
       breaksw
    case -t:
       shift
       set tries="-t$1"
       breaksw
    case -u:
       set unimax="=EBMT:Max-Alternatives1	50	-LMEngine-EBMT:Max-Alts1>1 2_9/8"
       set unidup0="=EBMT:Max-Duplicates1 80"
       set unidup="-EBMT:Max-Duplicates1 75_80_90_100_110_120_130_150_175_200_225_250"
       breaksw
    case -v:
       set verb="-v"
       breaksw
    case -x:
       shift
       set extraparms="$1"
       breaksw
    default:
       echo "Unknown option $1"
       breaksw
   endsw
   shift
end

if ($#argv < 3) then
   echo "Usage: $0:t [options] evalscript cfgfile testinput"
   echo "  perform a tuning of major Panlite configuration parameters"
   echo "  (this will execute several hundred runs on the test input)"
   echo "Options:"
   echo "  -b/-B    for translating between multi- and single-byte chars,"
   echo "           double/halve the length ratios"
   echo "  -c F     create new configuration file F edited with tuned values"
   echo "  -C N     run up to N evaluations concurrently (default 1)"
   echo "  -align   also tune EBMT aligner's scoring parameters"
   echo "  -alignonly  _only_ tune EBMT aligner's scoring parameters"
   echo "  -cunei   run Cunei's optimizer"
   echo "  -dict    tune only parameters affecting DICT engine"
   echo "  -ebmt    don't tune DICT engine parameters"
   echo "  -fast    run a fast tune with smaller beam, then tune beam separately"
   echo "  -imp     tune important parms only, skip those with little effect"
   echo "  -keep    keep temporary files created by evalscript"
   echo "  -lmonly  tune only decoder parameters"
   echo "  -lr X    force length ratio to X"
   echo "  -m	    minimize the score (required when tuning TER)"
   echo "  -me      tune MultiEngine parameter"
   echo "  -MER N   run MER training with N-best list size N (every iteration)"
   echo "  -mer N   run MER training with N-best list (only on LM param changes)"
   echo "  -moses   decoder is using MOSES-style scoring"
   echo "  -merfile F  use file F for the MER training instead of 'testinput'"
   echo "  -mp      tune MultiPath parameter"
   echo "  -n	    try ngrams up to length 8 instead of length 6"
   echo "  -nl	    try very long ngrams (use with .bwt models)"
   echo "  -nn	    don't tune ngram length (useful for multi-LM runs)"
   echo "  -ng	    also tune NgramLength/NGrams# (implied by -mer)"
   echo "  -np	    no punctuation in corpus (skip Reorder-Punct/Reorder-Punct-EOS)"
   echo "  -o N	    offset randomization seed by N days"
   echo "  -opt     run Panlite's internal optimizer"
   echo "  -p	    start from (perturb) existing parameter values"
   echo "  -pl	    start from (perturb) existing values, only explore locally"
   echo "  -pr	    start from (perturb) existing values after applying random offsets"
   echo "  -r	    randomize the initial settings (double to randomize all)"
   echo "  -t N	    limit the total number of parameter combinations checked to N"
   echo "  -u  	    tune parameters for UNIGRAMS as well"
   echo "  -x P     tune additional parameters specified by 'P'"
   exit 1
endif

if ( ( $?alignonly && $?lmonly ) || ( $?dictonly && $?ebmtonly )) then
   echo "It does not make sense to specify both -alignonly and -lmonly or"
   echo "  both -dict and -ebmt"
   exit 2
endif

set evalscript="$1"
set cfgfile="$2"
set testinput="$3"

if ( "x$evalscript" == "x." ) then
   set evalscript=`where eval-panlite.sh|head -1`
   if ( "x$evalscript" == "x" ) set evalscript=~ralf/pnp/bin/eval-panlite.sh
endif
if ( ! -e $evalscript ) then
   echo Evaluation script $evalscript does not exist\!
   exit 1
endif
if ( ! -e $cfgfile ) then
   echo Configuration file $cfgfile does not exist\!
   exit 1
endif
if ( ! -e $testinput ) then
   echo Test input file $testinput does not exist\!
   exit 1
endif

if ( $?mer_file  && "$mer_training" != "" ) then
   if ( ! -e $mer_file ) then
      echo MER input file $mer_file does not exist\!
      exit 1
   endif
   set mer_training="$mer_training$mer_file"
endif

if ( $?force_lenratio ) then
   set lengthratio="=Length-Bias-Byte $force_lenratio =Length-Bias-Word $force_lenratio"
else
   set lengthratio="Length-Bias-Byte $lengths Length-Bias-Word $lengths"
endif

# if MULTISTACK is enabled in the config file, adjust the reordering penalty
#   and beam width accordingly
if { grep -i -q -s '^[ 	][ 	]*[+]*MULTISTACK' $cfgfile } then
   set reorderpen="LMWeights:Reordering 0.20_-0.10_-0.05_-0.01_0.05_0.10_0.15_0.25_0.35_0.40_0.45_0.50_0.60 LMWeights:Reordering2 0.15_0.70/12"
   set beamwidth="15_20_25_30_35_40_50_60_80"
   set beamwidth_fast="20"
endif

# check whether future utility estimates are in play, and if so tune their wt
if { grep -i -q -s '^Future[ 	]*[:=]' $cfgfile } then
   set future="-LMWeights:Future>0 0.2_2.2/11"
endif

# adjust things for MER training if requested
if ( "x$run_opt" != "x" ) then
   set use_external_opt
endif
if ( "x$mer_training" != "x" ) then
   set mer_prog=`where OptimizeNBest|head -1`
   if ( "x$mer_prog" == "x" && -e ${evalscript:h}/OptimizeNBest ) then
      set mer_prog=${evalscript:h}/OptimizeNBest
   endif
   set lmout2hyp=`where lmout2hyp|head -1`
   if ("x$lmout2hyp" == "x" && -e ${evalscript:h}/lmout2hyp ) then
      set lmout2hyp=${evalscript:h}/lmout2hyp
   endif
   if ( "x$mer_prog" == "x" || "x$lmout2hyp" == "x" ) then
      echo MER program is not available, will tune without MER training
      unset mer_training
   else
      setenv TUNE_MER $nbest
      set use_external_opt
   endif
endif

if ( $?use_external_opt) then
   # the following parameters get optimized by the external optimizer, so read
   #   them back from the modified configuration file
   set lmscale="@"
   set quality="LMWeights:Quality @"
   set score="LMWeights:Score @ =LMWeights:Probability @"
   set frequency="LMWeights:Frequency @"
   set mass="LMWeights:Mass @"
   set alignment="LMWeights:Alignment @"
   set origweight="LMWeights:Origin-Weight @"
   set multiref="LMWeights:MultiRef @"
   set complete="LMWeights:Complete @"
   set arcweight="LMWeights:ArcWeight @"
   set lenbonus="LMWeights:Length2Bonus @ LMWeights:Length3Bonus @ LMWeights:Length4Bonus @ LMWeights:Length5Bonus @ LMWeights:Length6Bonus @ LMWeights:LengthPlusBonus @"
   set chunking="LMWeights:Chunking @"
   set reorderpen="LMWeights:Reordering @ LMWeights:Reordering2 @"
   set punct="LMWeights:Reorder-Punct @ LMWeights:Reorder-Punct-EOS @"
   set interleave="LMWeights:Interleave @"
   set sourcefeat="LMWeights:Source-Features @"
   set ebmtweight="LMWeights:Engine-EBMT @"
   set dictweight="LMWeights:Engine-DICT @"
   set context="LMWeights:SntContext @ LMWeights:PhrContext @ LMWeights:PhrContext1 @ LMWeights:PhrContext2 @ LMWeights:PhrContext3 @ LMWeights:PhrContext4 @ LMWeights:PhrContext5 @ LMWeights:PhrContext6 @ LMWeights:PhrContextPlus @"
   set ngramlen="LMWeights:NGramLength @ LMWeights:NGrams1 @ LMWeights:NGrams2 @ LMWeights:NGrams3 @ LMWeights:NGrams4 @ LMWeights:NGrams5 @ LMWeights:NGrams6 @ LMWeights:NGramsLong @"
   set verbositypen="LMWeights:Brevity-Byte @ LMWeights:Brevity-Word @ LMWeights:Verbosity-Byte @ LMWeights:Verbosity-Word @ LMWeights:WordCount @"
   set multipath="LMWeights:MultiPath @"
   set multiengine="LMWeights:MultiEngine @"
   set arccount="LMWeights:ArcCount @"
   set reinforcement="LMWeights:Reinforcement @"
   set ovrbonus="LMWeights:Overlap @"
   set oovpenalty="LMWeights:OOV @"
   set untrans="LMWeights:Untranslated @"
   set nulltrans="LMWeights:Null-Translation @"
endif

# if the user specified -u, check whether UNIGRAMS is enabled in the
#   configuration file
if ( "x$unimax" != "x") then
   if { grep -i -q -s '^[ 	]*[-\!]UNIGRAMS' $cfgfile } then
      echo You requested tuning of UNIGRAMS parameters, but UNIGRAMS is disabled
      exit 2
   endif
   # check whether we have the needed LMEngine-EBMT:Max-Alts1 parameter in the
   #   configuration file
   if ( ! $?lmonly && ! $?dictonly ) then
      if { grep -i -q -s '^Max-Alts1 *[:=]' $cfgfile } then
      else
         echo "The specified configuration file does not contain the Max-Alts1: parameter,"
         echo "which is needed to tune the number of single-word EBMT alternatives"
         echo  "(formerly tuned via Max-Alternatives1).  Please add it to the"
         echo "[LMEngine-EBMT] section."
         exit 2
      endif
   endif
endif

# check whether we have the needed LMEngine-Dict:Max-Alts parameter in the
#   configuration file
if ( "x$dictxlat" != "x" ) then
   if { grep -i -q -s '^Max-Alts *[:=]' $cfgfile } then
   else
      echo "The specified configuration file does not contain any Max-Alts: parameters,"
      echo "which are needed to tune the number of dictionary alternatives (formerly"
      echo "tuned via Max-Dict-Xlat) and number of EBMT alternatives (formerly"
      echo "tuned via Max-Alternatives).  Please add them to the [LMEngine-DICT] and"
      echo "[LMEngine-EBMT] sections."
      exit 2
   endif
endif

# if the test file contains :DOC/:ENDDOC, also tune the similarity weighting
#
if { grep -iq '^ *: *DOC' $testinput } then
   if ( ! $?lmonly || $?dictonly ) then
      set docwt="Doc-Sim-Weight 0.65_0.85/11"
      set doccontext="DocContext 0.2_1.0/5"
   endif
endif

if { grep -iq '^SrcFeat' $cfgfile } then
   if ( ! $?lmonly || $?dictonly ) set srcfeat="EBMT:SrcFeat-Position 0.6_1.6/11"
endif

# skip the parameters that have little effect if so requested
if ( $?important_only ) then
   set interleave="LMWeights:Interleave @"
   set ovrbonus="LMWeights:Overlap @"
   set oovpenalty=""
   set punct=""
   set srcfeat=""
   set arcweight=""
endif

setenv TUNE_PANLITE_DIR ${cd}/tune_$$
if ( $?fasttune ) then
   if ( ! $?newcfg ) then
      echo Must specify new configuration file when using -fast
      exit 1
   endif
   set tmpcfg=${cfgfile:r}-$$.cfg
   if ( $?fasttune2 ) then
      cp $cfgfile $tmpcfg
   else
      set cfgfile2=${cfgfile:r}-$$b.cfg
      if ($?omitsubsumed) then
         sed -e 's/^[ 	]*[-+\!]OMITSUBSUMED/	OMITSUBSUMED/' $cfgfile >$cfgfile2
      else
         cat $cfgfile >$cfgfile2
      endif
      set parms="$lengthratio \
	-Reorder-Window>1	2_3 \
	=Beam-Width		$beamwidth_fast \
	=Beam-Ratio		1.5 \
	$verbositypen \
	LMWeights:LM-Scale-Factor 	$lmscale \
	$ngrams \
	$alignweights \
	$score \
	$quality \
        $ngramlen \
	$arcweight \
	$lenbonus \
	$untrans \
	$ovrbonus \
	$interleave \
	$oovpenalty \
	$frequency \
	$mass \
	$alignment \
	$origweight \
	$multiref \
	$sourcefeat \
	$doccontext \
	$context \
	$punct \
	$multipath \
	$multiengine \
	$complete \
	$arccount \
	$reinforcement \
	$future \
	$unimax \
	$maxalt \
	$ebmtweight \
	$dictweight \
	$srcfeat \
	$dictxlat \
	$alignthresh \
	$docwt \
	$chunking \
	$userweights \
	$unidup0 \
	$maxdup0 \
	$confidence \
	$other \
	"
      if ($verb != "") then
         echo tune -C$concur $use_existing $rand $offset $min $tries -c$tmpcfg \
	      $run_opt $verb $mer_training $evalscript $cfgfile2 $testinput \
	      `echo $parms $extraparms`
      endif
      tune -C$concur $use_existing $rand $offset $min $tries -c$tmpcfg \
	   $run_opt $verb $mer_training $evalscript $cfgfile2 $testinput \
	   `echo $parms $extraparms`
      rm $cfgfile2
   endif

   unsetenv TUNE_MER
   echo Running second phase of fast tuning -- beam size, reordering and max dups
   set parms="$maxdup \
	$unidup \
	-Beam-Width>10		$beamwidth \
	$beamratio \
	-Reorder-Window>1 	$window \
	$reorderpen"
   tune -C$concur -p+ $min $newcfg $run_opt $evalscript $tmpcfg $testinput \
	`echo $parms $extraparms`
   rm $tmpcfg
   exit

else if ( $?alignonly ) then
   echo Tuning Alignment parameters
   set parms="$alignweights $quality"

else if ( $?lmonly ) then
   echo Tuning LM parameters
   set parms="$lengthratio \
	-Beam-Width>10		$beamwidth \
	$beamratio \
	Reorder-Window>1	$window \
	$verbositypen \
	LMWeights:LM-Scale-Factor 	$lmscale \
	$ngrams \
	$reorderpen \
	$alignweights \
	$score \
	$quality \
	$ngramlen \
	$arcweight \
	$lenbonus \
	$untrans \
	$ovrbonus \
	$interleave \
	$oovpenalty \
	$frequency \
	$mass \
	$alignment \
	$origweight \
	$multiref \
	$sourcefeat \
	$punct	\
	$multipath \
	$multiengine \
	$complete \
	$arccount \
	$reinforcement \
	$future \
	$nulltrans \
	$unimax \
	$maxalt \
	$ebmtweight \
	$dictweight \
	$dictxlat \
	$chunking \
	$userweights \
	$confidence \
	$other \
	"
	
else if ( $?dictonly ) then
   echo Tuning Dictionary parameters
   set parms="$lengthratio \
	Reorder-Window>1	$window \
	$verbositypen \
	LMWeights:LM-Scale-Factor 	$lmscale \
	$ngrams \
	$punct	\
	$multipath \
	$multiengine \
	$arccount \
	$reinforcement \
	$future \
	$dictweight \
	$dictxlat \
	$score \
	$quality \
	$ngramlen \
	$arcweight \
	$lenbonus \
	$untrans \
	$ovrbonus \
	$interleave \
	$oovpenalty \
	$confidence \
	$other \
	"

else
   set parms="$lengthratio \
	$ngrams \
	-Beam-Width>10		$beamwidth \
	$beamratio \
	-Reorder-Window>1 	$window \
	$verbositypen \
	LMWeights:LM-Scale-Factor 	$lmscale \
	$reorderpen \
	$alignweights \
	$score \
        $ngramlen \
	$arcweight \
	$quality \
	$lenbonus \
	$untrans \
	$ovrbonus \
	$interleave \
	$oovpenalty \
	$frequency \
	$mass \
	$alignment \
	$origweight \
	$multiref \
	$sourcefeat \
	$doccontext \
	$context \
	$punct \
	$multipath \
	$multiengine \
	$complete \
	$arccount \
	$reinforcement \
	$future \
	$nulltrans \
	$unimax \
	$maxalt \
	$ebmtweight \
	$srcfeat \
	$dictweight \
	$dictxlat \
	$maxdup \
	$unidup \
	$alignthresh \
	$docwt \
	$chunking \
	$userweights \
	$confidence \
	$other \
	"
endif

if ($verb != "") then
   echo tune -C$concur $use_existing $rand $offset $min $tries $newcfg $run_opt \
  	$verb $mer_training $evalscript $cfgfile $testinput `echo $parms $extraparms`
endif
tune -C$concur $use_existing $rand $offset $min $tries $newcfg $run_opt \
     $verb $mer_training $evalscript $cfgfile $testinput `echo $parms $extraparms`

if ( ! $?TUNE_PANLITE_KEEPTMP && $?TUNE_PANLITE_DIR) rm -rf $TUNE_PANLITE_DIR

# we want to use the lowest possible values for Max-Alternatives, Beam-Width,
#   Beam-Ratio, Reorder-Window, and Longest-Ngram to minimize runtime;
#   minimizing Align-Threshold will maximize EBMT coverage
