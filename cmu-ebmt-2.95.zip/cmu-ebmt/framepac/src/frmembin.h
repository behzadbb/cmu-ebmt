/****************************** -*- C++ -*- *****************************/
/*									*/
/*  FramepaC  -- frame manipulation in C++				*/
/*  Version 1.99							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File frmembin.h		template FrMemoryBinnedFreelist		*/
/*  LastEdit: 04mar10							*/
/*									*/
/*  (c) Copyright 2009,2010 Ralf Brown					*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __FRMEMBIN_H_INCLUDED
#define __FRMEMBIN_H_INCLUDED

/************************************************************************/
/*	Methods for template class FrMemoryBinnedFreelist		*/
/************************************************************************/

template <class T_hdr, unsigned N_factor>
FrMemoryBinnedFreelist<T_hdr,N_factor>::FrMemoryBinnedFreelist(
   size_t minbinsize,
   size_t maxbinsize,
   size_t gran)
   : m_mutex(true,true)
{
   // the default memory pool might get forcibly initialized before its
   //   constructor has a chance to run, so don't run the initialization
   //   again if that happens
   if (((void*)this != (void*)&FramepaC_default_mempool
#if defined(FrREPLACE_MALLOC) && !defined(PURIFY)
	&& (void*)this != (void*)&FramepaC_bigalloc_pool
#endif
	  )
       || !initialized())
      {
      m_self = 0 ;
      init(minbinsize,maxbinsize,gran) ;
      }
   return ;
}

//----------------------------------------------------------------------

template <class T_hdr, unsigned N_factor>
FrMemoryBinnedFreelist<T_hdr,N_factor>::~FrMemoryBinnedFreelist()
{ 
   m_self = 0 ; 
   if (0
#if defined(FrREPLACE_MALLOC) && !defined(PURIFY)
       || (void*)this == (void*)&FramepaC_bigalloc_pool
#endif
//       || (void*)this == (void*)&FramepaC_default_mempool
      )
      {
      VALGRIND_DESTROY_MEMPOOL(this) ;
      }
   return ;
}

//----------------------------------------------------------------------

template <class T_hdr, unsigned N_factor>
void FrMemoryBinnedFreelist<T_hdr,N_factor>::init(size_t minbin, size_t maxbin,
						  size_t gran)
{
   if (m_self != this)
      m_mutex.init(true) ;
   initBinSizes(minbin,maxbin,gran) ;
   // the free list is a circular doubly-linked list with special header node,
   //   so the empty free list is the header pointing at itself in both dirs
   m_freelist.initEmpty() ;
   for (size_t i = 0 ; i <= maximumBin() ; i++)
      {
      m_freelist_ptrs[i] = &m_freelist ;
      m_index[i] = maximumBin() ;
      }
   for (size_t i = maximumBin() + 1 ; i < lengthof(m_freelist_ptrs) ; i++)
      m_freelist_ptrs[i] = 0 ;
   m_self = this ;
#if defined(FrREPLACE_MALLOC) && !defined(PURIFY)
   if ((void*)this == (void*)&FramepaC_bigalloc_pool)
      {
      VALGRIND_CREATE_MEMPOOL(this,0,0) ;
      }
   else
#endif
   if ((void*)this == (void*)&FramepaC_default_mempool)
      {
      // small mallocs have four bytes of admin info between them, so
      //   split them into a pair of two-byte redzones
//      VALGRIND_CREATE_MEMPOOL(&FramepaC_default_mempool,2,0) ;
//!      VALGRIND_CREATE_MEMPOOL(&FramepaC_default_mempool,0,0) ;
      }
   return ;
}

//----------------------------------------------------------------------

template <class T_hdr, unsigned N_factor>
void FrMemoryBinnedFreelist<T_hdr,N_factor>::initBinSizes(size_t minbin,
							  size_t maxbin,
							  size_t gran)
{
   if (maximumBin() == 0)
      {
      setGranularity(gran) ;
      setBinSize(0,minbin) ;
      setMaximumBin(lengthof(m_freelist_ptrs)-1) ;
      size_t max = bin(maxbin) ;
      if (max >= numBins())
	 max = numBins()-1 ;
      setMaximumBin(max) ;
      size_t incr = gran ;
      size_t size = minbin ;
      unsigned count = 0 ;
      for (size_t i = 0 ; i <= maximumBin() ; i++)
	 {
	 if (count >= N_factor)
	    {
	    incr <<= 1 ;
	    count >>= 1 ;
	    }
	 count++ ;
	 setBinSize(i,size) ;
	 size += incr ;
	 if (binsize(i) > maxbin)
	    setBinSize(i,maxbin) ;
	 }
      setBinSize(maximumBin()+1,
		 (maxbin>MAX_SMALL_BLOCK) ? ULONG_MAX : MAX_SMALL_BLOCK) ;
      }
   return ;
}

//----------------------------------------------------------------------

template <class T_hdr, unsigned N_factor>
size_t FrMemoryBinnedFreelist<T_hdr,N_factor>::bin(size_t size)
{
   if (size <= binsize(0))
      return 0 ;
   size -= binsize(0) ;
   size /= granularity() ;		// all blocks are multiple of this size
   size_t b = 0 ;
   // allow for 16 distinct block sizes per power of two (may waste a
   //   little memory, but considerably speeds up the maintenance of the
   //   freelist pointers)
   for ( ; size >= N_factor ; size >>= 1)
      {
      b += (N_factor >> 1) ;
      }
   b += size ;
   return (b > maximumBin()) ? maximumBin() : b ;
}

//----------------------------------------------------------------------

template <class T_hdr, unsigned N_factor>
void FrMemoryBinnedFreelist<T_hdr,N_factor>::splitblock(size_t totalsize,
							size_t &desired)
{
   // round up the desired size to the proper bin size
   size_t b = bin(desired) ;
   size_t size = binsize(b) ;
   if (size < desired)
      size = binsize(b+1) ;
   if (totalsize >= size && totalsize - size >= binsize(0))
      {
      desired = size ;
      }
   else
      {
      // not enough to split off a fragment, so use the whole block
      desired = totalsize ;
      }
   return ;
}

//----------------------------------------------------------------------

template <class T_hdr, unsigned N_factor>
T_hdr *FrMemoryBinnedFreelist<T_hdr,N_factor>::pop(size_t size)
{
   size_t b = bin(size) ;
   if (binsize(b) < size)
      {
      if (b >= maximumBin())
	 {
	 // we'll have to scan for a sufficiently large block, as we can't
	 //   guarantee that the first one on the list is big enough
	 FrCRITSECT_ENTER(mutex()) ;
	 T_hdr *block = m_freelist_ptrs[m_index[b]] ;
	 while (block != &m_freelist)
	    {
	    if (blockSize(block) >= size)
	       {
	       remove(block,b) ;
	       FrCRITSECT_LEAVE(mutex()) ;
	       return block ;
	       }
	    block = block->nextFree() ;
	    }
	 FrCRITSECT_LEAVE(mutex()) ;
	 return 0 ;			// no sufficiently large block availabl
	 }
      else
	 b++ ;
      }
   FrCRITSECT_ENTER(mutex()) ;
   size_t idx = m_index[b] ;
   T_hdr *block = m_freelist_ptrs[idx] ;
   if (block == &m_freelist)
      block = 0 ;
   else
      remove(block,b) ;
   FrCRITSECT_LEAVE(mutex()) ;
   return block ;
}

//----------------------------------------------------------------------

template <class T_hdr, unsigned N_factor>
void FrMemoryBinnedFreelist<T_hdr,N_factor>::add(T_hdr *block)
{
   size_t size = blockSize(block) ;
   size_t b = bin(size) ;
   FrCRITSECT_ENTER(mutex()) ;
   size_t idx = m_index[b] ;
   T_hdr *next = m_freelist_ptrs[idx] ;
   T_hdr *prev = next->prevFree() ;
   // insert block into doubly-linked freelist
   block->setNextFree(next) ;
   block->setPrevFree(prev) ;
   next->setPrevFree(block) ;
   prev->setNextFree(block) ;
   // fix up the freelist pointers
   size_t first_bin = (prev == &m_freelist) ? 0 : bin(blockSize(prev)) + 1 ;
   m_freelist_ptrs[b] = block ;
   for (size_t i = first_bin ; i <= b ; i++)
      m_index[i] = b ;
   markAsFree(block) ;
   FrCRITSECT_LEAVE(mutex()) ;
   return ;
}

//----------------------------------------------------------------------
// Prerequisite: caller must have acquired mutex(); block is free or belongs to caller

template <class T_hdr, unsigned N_factor>
void FrMemoryBinnedFreelist<T_hdr,N_factor>::remove(T_hdr *block,
						    size_t bin_num)
{
   // cut the block out of the freelist
   markAsUsed(block) ;
   T_hdr *next = block->nextFree() ;
   T_hdr *prev = block->prevFree() ;
   size_t idx = m_index[bin_num] ;
   prev->setNextFree(next) ;
   next->setPrevFree(prev) ;
   if (m_freelist_ptrs[idx] == block)
      {
      // fix up the freelist pointers
      size_t next_bin =
	 (next == &m_freelist) ? maximumBin() : bin(blockSize(next)) ;
      idx = (prev == &m_freelist) ? 0 : bin(blockSize(prev))+1 ;
      m_freelist_ptrs[next_bin] = next ;
      for (size_t i = idx ; i <= next_bin ; i++)
	 m_index[i] = next_bin ;
      }
   return ;
}

//----------------------------------------------------------------------
// Prerequisite: block belongs to caller

template <class T_hdr, unsigned N_factor>
void FrMemoryBinnedFreelist<T_hdr,N_factor>::remove(T_hdr *block)
{
   size_t size = blockSize(block) ;
   size_t bin_number = bin(size) ;
   FrCRITSECT_ENTER(mutex()) ;
   remove((T_hdr*)block,bin_number) ;
   FrCRITSECT_LEAVE(mutex()) ;
   return ;
}

//----------------------------------------------------------------------

template <class T_hdr, unsigned N_factor>
size_t FrMemoryBinnedFreelist<T_hdr,N_factor>::removeIfFree(T_hdr *block)
{
   size_t block_size = 0 ;
   FrCRITSECT_ENTER(mutex()) ;
   if (!blockInUse(block))
      {
      block_size = blockSize(block) ;
      size_t bin_number = bin(block_size) ;
      remove((T_hdr*)block,bin_number) ;
      }
   FrCRITSECT_LEAVE(mutex()) ;
   return block_size ;
}

//----------------------------------------------------------------------

#endif /* !__FRMEMBIN_H_INCLUDED */

// end of file frmembin.h //
