/****************************** -*- C++ -*- *****************************/
/*									*/
/*  FramepaC  -- frame manipulation in C++				*/
/*  Version 1.99							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File frmem.h		memory allocation routines		*/
/*  LastEdit: 02mar10							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,1999,2000,2003,2004,2005,	*/
/*		2006,2007,2008,2009,2010 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __FRMEM_H_INCLUDED
#define __FRMEM_H_INCLUDED

#ifndef __FRCOMMON_H_INCLUDED
#include "frcommon.h"
#endif

#ifndef __FRTHREAD_H_INCLUDED
#include "frthread.h"
#endif

#ifdef FrMEMWRITE_CHECKS
#include "framerr.h"
#endif

#include <stdlib.h>


//FIXME: until all the client calls to Valgrind can be straightened out,
//   disable memory checks within FrMalloc/FrAllocator
#define VALGRIND_BROKEN

#include "memcheck.h"

/************************************************************************/
/*    Manifest constants						*/
/************************************************************************/

// we allocate a bunch of FrCons, FrFrame, FrSlot, FrFacet, etc. objects at
// a time in order to reduce the overhead (in both memory and time)
// of making individual requests to the system memory allocation routines
// for each object.  Up to a point, bigger blocks save time and memory
// overhead, but excessive values can waste both time and memory preallocating
// objects which are never used.
//
// The blocks are smaller for MS-DOS than other OSs because of the restricted
// amount of memory available in MS-DOS's sub-megabyte address space.
//
// (with the current implementation, 4080 is an exact multiple of the
//  size of the object types FrCons/FrSlot/FrFacet/FrString/FrFloat
//  under MS-DOS)
//
// Note: various code requires that the alignment sizes be powers of two, and
// that the block size be a multiple of FrALIGN_SIZE.
//
#if defined(_MSC_VER)   // Visual C++
#  define FrALIGN_SIZE	   4		// strictest alignment of any type
#  define FrALIGN_SIZE_PTR 4		// alignment size for pointers
#  define FrALIGN_SIZE_SBRK 131072UL	// allocation granularity for sbrk()
#  define FrALLOC_GRANULARITY 16384	// allocation granularity of big_malloc
#  define FrBLOCKING_SIZE  16356	// exactly 16K with our overhead
#elif defined(__386__)    // x86, primarily Watcom C++32
#  if defined(__WINDOWS__) || defined(__NT__)
#    define FrALIGN_SIZE_SBRK 131072UL	// allocation granularity for sbrk()
#  else
#    define FrALIGN_SIZE_SBRK 4096	// allocation granularity for sbrk()
#  endif
#  if defined(__linux__)
#    define FrMMAP_GRANULARITY (4*1024*1024UL)
#  endif /* __linux__ */
#  if defined(__886__)
#    define FrALIGN_SIZE	8	// strictest alignment of any type
#    define FrALIGN_SIZE_PTR	8	// alignment size for pointers
#    define FrALLOC_GRANULARITY 65536	// allocation granularity of big_malloc
#    define FrALLOC_BIGMAX  (1UL << 31) // biggest block we ordinarily allocate
#    define FrBLOCKING_SIZE  	65480	// exactly 64K with 64-bit overhead
//#    define FrMAX_AUTO_SUBALLOC (64*FrALIGN_SIZE)
#  else
#    define FrALIGN_SIZE	4	// strictest alignment of any type
#    define FrALIGN_SIZE_PTR 	4	// alignment size for pointers
#    define FrALLOC_GRANULARITY 16384	// allocation granularity of big_malloc
#    define FrBLOCKING_SIZE  	16356	// exactly 16K with overhead since
					// Watcom's protected-mode sbrk()
					// insists on alloc in multiples of 4K
#  endif /* __886__ */
#elif defined(__MSDOS__)  // 16-bit DOS compiler
#  define FrALIGN_SIZE	   4		// strictest alignment of any type
#  define FrALIGN_SIZE_PTR 4		// alignment size for pointers
#  define FrBLOCKING_SIZE  4084
#elif defined(__linux__)  // Linux on x86
#  define FrALIGN_SIZE	   4		// strictest alignment of any type
#  define FrALIGN_SIZE_PTR 4		// alignment size for pointers
//#  define FrALIGN_SIZE_SBRK 4096	// allocation granularity for sbrk()
#  define FrALLOC_GRANULARITY 16384	// allocation granularity for big_malloc
#  define FrBLOCKING_SIZE  16356	// exactly 16K with our overhead
#elif defined(__alpha__)
#  define FrALIGN_SIZE	   8		// strictest alignment of any type
#  define FrALIGN_SIZE_PTR 8		// alignment size for pointers
//#  define FrALIGN_SIZE_SBRK 4096	// allocation granularity for sbrk()
#  define FrALLOC_GRANULARITY 16384	// allocation granularity for big_malloc
#  define FrBLOCKING_SIZE  16340	// exactly 16K with our overhead
#else			  // conservative, for generic platform
#  define FrALIGN_SIZE	   8		// SPARC needs doubles on 8-byte bound
#  define FrALIGN_SIZE_PTR 4		// pointers are OK on 4-byte boundaries
#  define FrPOINTERS_MUST_ALIGN		// data accesses must be aligned
#  define FrALLOC_GRANULARITY 16384	// allocation granularity for big_malloc
# if defined(FrREPLACE_MALLOC)
#  define FrBLOCKING_SIZE  16356	// exactly 16K with FrMalloc overhead
# else
#  define FrBLOCKING_SIZE  16340	// just under 16K, to allow overhead
# endif /* FrREPLACE_MALLOC */
#endif

#ifndef FrMAX_AUTO_SUBALLOC
#  define FrMAX_AUTO_SUBALLOC (16*FrALIGN_SIZE)
#endif

#define FrMAX_MEMPOOL_NAME 32

// ensure that we can address everything in a block
//
#if FrBLOCKING_SIZE >= USHRT_MAX
#  error FrBLOCKING_SIZE must fit in an unsigned short
#endif

// if the sbrk() granularity has not been explicitly set above, use the
// default value, which is the strictest type-alignment size
//
#ifndef FrALIGN_SIZE_SBRK
#  if FrALIGN_SIZE >= 512
#    define FrALIGN_SIZE_SBRK FrALIGN_SIZE
#  else
#    define FrALIGN_SIZE_SBRK 512
#  endif
#endif

#ifndef FrALLOC_GRANULARITY
#  define FrALLOC_GRANULARITY 1024	// granularity of big_malloc() for sbrk
#endif

// Set the size of the biggest block we expect to allocate with big_malloc
//   (we won't fail if this is too small, but we will have to search more
//   blocks in the highest bin).  Smaller values mean less freelist
//   maintenance overhead.
#ifndef FrALLOC_BIGMAX
#  define FrALLOC_BIGMAX   (1UL << 27)	   // 128MB
#endif

#ifndef FrMMAP_GRANULARITY
#  define FrMMAP_GRANULARITY (16*1048576L) // gran of big_malloc() for mmap()
#endif

#if FrALLOC_GRANULARITY % FrALIGN_SIZE != 0
#  error FrALLOC_GRANULARITY must be a multiple of the alignment size
#endif

#if FrMMAP_GRANULARITY % 32768 != 0
#  error FrMMAP_GRANULARITY must be a multiple of 32K
#endif

#ifdef __GNUC__
//#define FrTHREE_ARG_NEW	// this version of G++ supports three-arg new[]
#endif

/************************************************************************/
/************************************************************************/

class FrAllocator ;
class FrFreeHdr ;
class FrMemoryPoolInfo ;

class FrObjArray
   {
   public: // members
      char objs[FrBLOCKING_SIZE] ;
      FrObjArray *next ;
   public: // methods
      // the following are use by FrSymbolTable's palloc()
      static unsigned maxFreeCount()
	 { return FrBLOCKING_SIZE - sizeof(unsigned) ; }
      unsigned &freecount() { return *(unsigned*)(objs + maxFreeCount()) ; }
   } ;

class FrFreeList
   {
   public:
      void *marker ;	// points at free_cell or freed_cell if free/reclaimed
      FrFreeList *next ;
   } ;

class FrFreeHdr
   {
   public:
      FrFreeHdr *next ;			// this MUST be the first field!
      FrFreeHdr *prev ;
   public:
      void initEmpty() { next = this ; prev = this ; }
      FrFreeHdr *nextFree() const { return next ; }
      FrFreeHdr *prevFree() const { return prev ; }
      void setNextFree(FrFreeHdr *n) { next = n ; }
      void setPrevFree(FrFreeHdr *p) { prev = p ; }
   } ;
// code in frmem.C uses the fact that "next" is at offset 0 in the structure
// to allow the freelist "prev" pointer to point at the simple FrFreeHdr*
// that points at the freelist, thus avoiding a null check when unlinking
// blocks from the freelist

typedef void FrCompactFunc(FrMemoryPoolInfo *mpi, FrFreeList **freelist,
			   FrObjArray **freed) ;
typedef int FrGCFunc(FrAllocator *allocator) ;
typedef bool FrMemIterFunc(void *object, va_list args) ;

/************************************************************************/
/*	Global Variables						*/
/************************************************************************/

extern class FrMemoryPool FramepaC_default_mempool ;

extern bool memory_errors_are_fatal ;
extern unsigned long FrMalloc_requests ;	// only valid if FrMEMUSE_STATS

/************************************************************************/
/*    Procedural interface to memory allocation				*/
/************************************************************************/

extern void *FrMalloc(size_t numbytes)
     _fnattr_malloc _fnattr_alloc_size1(1) _fnattr_warn_unused_result ;
extern void *FrCalloc(size_t nitems, size_t size)
      _fnattr_malloc _fnattr_alloc_size2(1,2) _fnattr_warn_unused_result ;
extern void *FrCalloc(size_t nitems, size_t size,
		      FrMemoryPool *mp)
      _fnattr_malloc _fnattr_alloc_size2(1,2) _fnattr_warn_unused_result ;
void *FrRealloc(void *block, size_t newsize, bool copy_contents = true)
      _fnattr_alloc_size1(2) _fnattr_warn_unused_result ;
void FrFree(void *block) ;
void *realloc3(void *block, size_t newsize, bool copy_contents = true)
      _fnattr_alloc_size1(2) _fnattr_warn_unused_result ;

void *_FrMallocDebug(size_t numbytes, const char *file, size_t line)
     _fnattr_malloc _fnattr_alloc_size1(1) _fnattr_warn_unused_result ;
void *_FrCallocDebug(size_t nitems,size_t size, const char *file,size_t line)
     _fnattr_malloc _fnattr_alloc_size2(1,2) _fnattr_warn_unused_result ;
void *_FrReallocDebug(void *blk, size_t newsize, bool copy_contents,
		      const char *file,size_t line) ;
void _FrFreeDebug(void *block, const char *file, size_t line) ;

#ifdef FrMEMLEAK_CHECKS
#define FrMalloc(size) _FrMallocDebug(size,__FILE__,__LINE__)
#define FrCalloc(n,size) _FrCallocDebug(n,size,__FILE__,__LINE__)
inline FrRealloc(void *blk,size_t newsize,bool copy=true)
  { return _FrReallocDebug(blk,newsize,copy,__FILE__,__LINE__) ; }
#define FrFree(blk) _FrFreeDebug(blk,__FILE__,__LINE__)
#endif /* FrMEMLEAK_CHECKS */


void FrMalloc_gc() ;		// reclaim unused FrMalloc blocks
void FramepaC_gc() ;		// reclaim unused FrMalloc/FrAllocator blocks

size_t FrMaxSmallAlloc() 	// largest request allocated in a small block
     _fnattr_const ;

// integrity checks
bool FramepaC_memory_chain_OK() ;
bool FramepaC_memory_freelist_OK() ;
bool check_FrMalloc(FrMemoryPoolInfo *mpi) ;

// informational displays
void FrMemoryStats(ostream &out) ;
void FrMemoryStats() ; // use cerr
void FrMemoryAllocReport(ostream &out) ;
void FrMemoryAllocReport() ; // use cerr
void FrShowMemory(ostream &out) ;
void FrShowMemory() ;

/************************************************************************/
/*	Debugging Support						*/
/************************************************************************/

#if defined(PURIFY) || (defined(VALGRIND_BROKEN) && defined(VALGRIND))
#undef FrMalloc
#define FrMalloc ::malloc
#undef FrCalloc
#define FrCalloc ::calloc
#undef FrRealloc
#define FrRealloc ::realloc3
#undef FrFree
#define FrFree ::free
#endif /* PURIFY */

/************************************************************************/
/*    Convenience Macros						*/
/************************************************************************/

#define FrNew(type) ((type*)FrMalloc(sizeof(type)))
#define FrNewN(type,n) ((type*)FrMalloc((n)*sizeof(type)))
#define FrNewC(type,n) ((type*)FrCalloc((n),sizeof(type)))
#define FrNewR(type,ptr,n) ((type*)FrRealloc(ptr,(n)*sizeof(type),true))

// round up to the next multiple of some power of two
#define round_up(val,align) ((val+align-1)&(~(align-1)))

/************************************************************************/
/*	local stack allocation similar to alloca, but allowing		*/
/*	arbitrary sizes by falling back on regular memory allocator	*/
/************************************************************************/

#define FrLocalAlloc(type,name,stackcount,count) \
   type name##buffer[stackcount] ; \
   type *name ; \
   if ((count) <= stackcount) \
      name = name##buffer ; \
   else \
      name = FrNewN(type,count) ;

#define FrLocalAllocC(type,name,stackcount,count) \
   type name##buffer[stackcount] ; \
   type *name ; \
   if ((count) <= stackcount) \
      { \
      name = name##buffer ; \
      memset(name,'\0',(count)*sizeof(type)) ; \
      } \
   else \
      name = FrNewC(type,count) ;

#define FrLocalFree(name) \
   if (name != name##buffer) FrFree(name) ;

/************************************************************************/
/*	declarations for class FrMemoryPoolInfo			  	*/
/************************************************************************/

// originally 4 and 2 instead of 3 and 3
#define FrMEMPOOLINFO_FACTORBITS 3
#define FrBIGPOOLINFO_FACTORBITS 3

#define FrMEMPOOLINFO_FACTOR (1<<FrMEMPOOLINFO_FACTORBITS)
#define FrBIGPOOLINFO_FACTOR (1<<FrBIGPOOLINFO_FACTORBITS)

#if FrALIGN_SIZE >= 16
#define FrMEMPOOLINFO_SCALE 4
#elif FrALIGN_SIZE >= 8
#define FrMEMPOOLINFO_SCALE 3
#elif FrALIGN_SIZE >= 4
#define FrMEMPOOLINFO_SCALE 2
#else
#define FrMEMPOOLINFO_SCALE 1
#endif
//NOTE: FrMEMPOOLINFO_BINS must be big enough to hold all the bins needed by
//  *any* instantiation of FrMemoryBinnedFreelist
#define FrMEMPOOLINFO_BINS \
     (FrMEMPOOLINFO_FACTOR*(sizeof(unsigned short)*CHAR_BIT \
			    - FrMEMPOOLINFO_SCALE \
			    - 2*FrMEMPOOLINFO_FACTORBITS + 1))

template <class T_hdr, unsigned N_factor> class FrMemoryBinnedFreelist
   {
   private:
      static size_t  m_maxbin ;		// maximum bin number in use
      static size_t  m_granularity ;
      static size_t  m_binsizes[FrMEMPOOLINFO_BINS+1] ;
   protected:
      T_hdr	     m_freelist ;
      FrMutex 	     m_mutex ;
      FrMemoryBinnedFreelist *m_self ;	// verifies initialization by pointing
					//   to containing instance
      T_hdr	    *m_freelist_ptrs[FrMEMPOOLINFO_BINS] ;
      uint16_t	     m_index[FrMEMPOOLINFO_BINS] ;
   protected:
      void setMaximumBin(size_t max) { m_maxbin = max ; }
      void setGranularity(size_t gr) { m_granularity = gr ; }
      void setBinSize(size_t N, size_t sz) { m_binsizes[N] = sz ; }
      static void markAsFree(T_hdr *block) ;
      static void markAsUsed(T_hdr *block) ;
      static bool blockInUse(const T_hdr *block) ;
   public:
      FrMemoryBinnedFreelist(size_t minbinsize, size_t maxbinsize,
			     size_t gran) ;
      ~FrMemoryBinnedFreelist() ;
      void init(size_t minbinsize, size_t maxbinsize,
		size_t gran) ;
      void initBinSizes(size_t minbinsize, size_t maxbinsize,
			size_t gran) ;

      // accessors
      bool initialized() const { return m_self == this ; }
      FrMutex &mutex() { return m_mutex ; }
      T_hdr *freelistHead() { return &m_freelist ; }
      static size_t numBins() { return FrMEMPOOLINFO_BINS ; }
      static size_t granularity() { return m_granularity ; }
      static size_t maximumBin() { return m_maxbin ; }
      static size_t bin(size_t size) ;
      static size_t binsize(size_t bin_num) { return m_binsizes[bin_num] ; }
      static size_t blockSize(const T_hdr *block) ;
      static void splitblock(size_t totalsize, size_t &desired) ;

      // manipulators
      T_hdr *pop(size_t size) ;
      void add(T_hdr *block) ;
      void remove(T_hdr *block,size_t bin_num) ;
      void remove(T_hdr *block) ;
      size_t removeIfFree(T_hdr *block) ;
   } ;

//----------------------------------------------------------------------

class FrMemoryPoolInfo
   : public FrMemoryBinnedFreelist<FrFreeHdr,FrMEMPOOLINFO_FACTOR>
   {
   protected:
      FrObjArray       *m_blocklist ;	// list of blocks in use
      FrObjArray       *m_freeblocks ;	// list of freed blocks
      size_t	        m_blocks ;	// number of blocks in use
      FrCriticalSection m_critsect ;
   public:
      FrMemoryPoolInfo() ;
      ~FrMemoryPoolInfo() ;
      void init() ;

      // synchronization
      void enterCritical() { m_critsect.acquire() ; }
      void leaveCritical() { m_critsect.release() ; }
      template <typename T> T atomicSwap(T &var, const T value)
	 { return m_critsect.swap(var,value) ; }

      // accessors
      size_t numBlocks() const { return m_blocks ; }
      bool haveFreeBlocks() const { return m_freeblocks != 0 ; }
      size_t numFreeBlocks() const ;
      const FrObjArray *blocklist() const { return m_blocklist ; }
      const FrFreeHdr *freelist() const { return &m_freelist ; }

      // manipulators
      void addBlock(FrObjArray *newblock) ;
      void removeBlock(FrObjArray *oldblock, FrObjArray *pred) ;
      void removeAllBlocks() ;
      void addFreeBlock(FrObjArray *freeblock) ;
      FrObjArray *popFreeBlock() ;
      bool reclaimFreeBlocks() ;
      bool checkFreelist() ;

      // debugging
      void check() ;
   } ;

/************************************************************************/
/*	declarations for class FrMemoryPool			  	*/
/************************************************************************/

class FrMemoryPool : public FrMemoryPoolInfo
   {
   protected:
      FrMemoryPool *m_next, *m_prev ;
      char m_typename[FrMAX_MEMPOOL_NAME] ;
      bool mempool_subclass ;		// subclass on a different chain?
   public:
      void *operator new(size_t size) { return FrMalloc(size) ; }
      void operator delete(void *blk) { FrFree(blk) ; }
      FrMemoryPool(const char *name = 0, bool subclass = false) ;
      ~FrMemoryPool() ;
      void init(const char *name) ;

      void *allocate(size_t size) ;
      void release(void *item) ;
      void *reallocate(void *item,size_t size, bool copydata = true) ;

      // manipulation functions
      void setName(const char *name) ;

      // access to state
      bool initialized() const { return m_self == this ; }
      long bytes_allocated() const ;
      const char *typeName() const { return m_typename ; }
      FrMemoryPool *nextPool() const { return m_next ; }
      FrMemoryPool *prevPool() const { return m_prev ; }
   } ;

/************************************************************************/
/*	declarations for class FrAllocator				*/
/************************************************************************/

#ifdef FrMEMUSE_STATS
#  define INC_REQUESTS total_requests++
#else
#  define INC_REQUESTS
#endif /* FrMEMUSE_STATS */

#ifdef FrMEMWRITE_CHECKS
#  define MEMWRITE_CHECK \
	if (freelist->marker != 0) FrProgError("memory overwrite!") ;
#  define MEMWRITE_CLEAR(item) ((FrFreeList*)item)->marker = 0
#else
#  define MEMWRITE_CHECK
#  define MEMWRITE_CLEAR(item)
#endif /* FrMEMWRITE_CHECKS */

class FrAllocator : public FrMemoryPool
   {
   protected:
      unsigned long total_requests ;
      unsigned int objsize ;
      unsigned int offset ;
      FrCriticalSection m_critsect ;
      FrFreeList *freelist ;
      FrFreeList *(*allocate_objblock)(FrObjArray *block, FrFreeList *fl,
				       size_t sz) ;
      FrCompactFunc *compact_func ;
      FrGCFunc *gc_func, *async_gc_func ;
      bool compacting ;
   protected: // methods
      void *allocate_more() ;
      void reinit()
	 { FrMemoryPool::init(m_typename) ;
	   offset = 0 ; compacting = false ; total_requests = 0 ; }
      void initFreelist() { freelist = 0 ; }
   public:
      FrAllocator(const char *name, int size, FrCompactFunc *func = 0) ;
      ~FrAllocator() ;
#if defined(PURIFY)
      // override the suballocator and use standard allocations instead
      void *allocate() { return malloc(objsize) ; }
      void release(void *item) { free(item) ; }
#else /* !PURIFY */
      void *allocate() _fnattr_hot
	 {
	 m_critsect.acquire() ;
	 void *item = freelist ;
	 if (__builtin_expect(!item,0))
	    item = allocate_more() ;
	 MEMWRITE_CHECK ;
	 INC_REQUESTS ;
	 VALGRIND_MAKE_MEM_DEFINED(&((FrFreeList*)item)->next,
				   sizeof(((FrFreeList*)item)->next)) ;
	 freelist = ((FrFreeList*)item)->next ;
	 VALGRIND_MEMPOOL_ALLOC(this,item,objsize) ;
	 m_critsect.release() ;
	 return item ;
	 }
      void release(void *item) _fnattr_hot
	 {
	 MEMWRITE_CLEAR(item) ;
	 m_critsect.acquire() ;
	 ((FrFreeList*)item)->next = freelist ;
	 freelist = (FrFreeList*)item ;
	 m_critsect.release() ;
	 VALGRIND_MEMPOOL_FREE(this,item) ;
	 }
#endif /* PURIFY */
      void *allocate(size_t size)
	 {
	 if (size > objsize)
	    return FrMalloc(size) ;
	 else
	    return allocate() ;
	 }
      void release(void *item,size_t size)
	 {
	 if (size > objsize)
	    FrFree(item) ;
	 else
	    release(item) ;
	 }

      // manipulation functions
      void set_gc_funcs(FrGCFunc *gc, FrGCFunc *async_gc) ;
      int async_gc() ;
      int gc() ;
      int compact(bool force = false) ;
      size_t reclaimFreeBlocks() ;
      int zapAll() ; // use with EXTREME CARE -- only when no more ptrs to objs
		     // much faster than compact() when no objs in use
      void preAllocate() ;
      bool iterateVA(FrMemIterFunc *fn, va_list args) ;
      bool iterate(FrMemIterFunc *fn, ...) ;

      // access to state
      size_t objects_allocated() const ;
      size_t freelist_length() const ;
      unsigned long requests_made() const { return total_requests ; }
      int objectSize() const { return objsize ; }
      FrAllocator *nextAllocator() const { return (FrAllocator*)m_next ; }
   } ;

#undef INC_REQUESTS
#undef MEMWRITE_CHECK

/************************************************************************/

#endif /* !__FRMEM_H_INCLUDED */

// end of file frmem.h //
