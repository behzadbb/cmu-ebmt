/****************************** -*- C++ -*- *****************************/
/*									*/
/*  FramepaC  -- frame manipulation in C++				*/
/*  Version 1.99							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File frmemp.cpp		memory-pool allocation routines		*/
/*  LastEdit: 02mar10							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,1999,2000,2002,2003,2004,	*/
/*		2006,2007,2008,2009,2010 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#if __GNUC__ >= 3
namespace std {
#include <sys/types.h>		    	// needed by new.h
}
using namespace std ;
#endif /* __GNUC__ >= 3 */

#if !defined(__GNUC__) || __GNUC__ < 4
#include <new.h>
#endif

#include <errno.h>
#include <string.h>			/* needed on SunOS */
#include "fr_mem.h"
#include "frmembin.h"
#ifndef NDEBUG
#  define NDEBUG			// comment out to enable assertions
#endif /* !NDEBUG */
#include "frassert.h"
#include "frprintf.h"
#include "frthread.h"
#include "frpcglbl.h"
#include "memcheck.h"			// for VALGRIND_MAKE_*

#ifndef NDEBUG
# undef _FrCURRENT_FILE
static const char _FrCURRENT_FILE[] = __FILE__ ; // save memory
#endif /* NDEBUG */

/************************************************************************/
/*	Manifest constants for this module				*/
/************************************************************************/

#define SUBALLOC_GRAN (2*FrALIGN_SIZE)
#define AUTO_SUBALLOC_BINS (FrMAX_AUTO_SUBALLOC/SUBALLOC_GRAN)

/************************************************************************/
/*	Readability macros						*/
/************************************************************************/

#if defined(FrMEMUSE_STATS) && !defined(HELGRIND)
#  define if_MEMUSE_STATS(x) x
#else
#  define if_MEMUSE_STATS(x)
#endif /* FrMEMUSE_STATS */

/************************************************************************/
/*	Types local to this module					*/
/************************************************************************/

static FrFreeList *alloc_subobj_block(FrObjArray *newfr,
				      FrFreeList *freelist, size_t size) ;

class FrSubAllocator : public FrAllocator
   {
   public:
      FrSubAllocator(int size, const char *name = 0,
		     FrCompactFunc *func = 0) ;
      ~FrSubAllocator() {}

      void initFreelist() { freelist = 0 ; }
      void setAllocFunc() { allocate_objblock = &alloc_subobj_block ; }
      void setObjectSize(size_t s) { objsize = s ; }
   } ;

/************************************************************************/
/*	External and forward declarations				*/
/************************************************************************/

// external
void *big_malloc(size_t) ;
void *big_realloc(FrBigAllocHdr *block,size_t newsize) ;
void big_free(FrBigAllocHdr *) ;
bool big_reclaim() ;

extern void FramepaC_bad_pointer(void *ptr, const char *comment,
				 const char *where);
extern void (*FramepaC_memory_corrupted)(const void *blk, bool,
					 const char *) ;
extern void (*FramepaC_mem_err)(const char *msg) ;

// forward
void FramepaC_auto_gc() ;
static bool FramepaC_reclaim_free_blocks() ;

/************************************************************************/
/*	 Global Variables for this module				*/
/************************************************************************/

FrAllocator *FramepaC_allocators = 0 ;

static char free_cell ;		// magic value for recognizing unused cells
static char freed_cell ;	// magic value for use during memory compaction

static FrSubAllocator *auto_suballocators[AUTO_SUBALLOC_BINS+1] = { 0, 0 } ;
static bool auto_suballocators_alloc = false ;

unsigned long FrMalloc_requests = 0 ;
#ifdef FrMEMUSE_STATS
unsigned long FrMalloc_bytes = 0 ;
unsigned long FrRealloc_requests = 0 ;
#endif /* FrMEMUSE_STATS */

static bool gc_in_progress = false ;
void (*FramepaC_gc_handler)() = 0 ;
void (*FramepaC_auto_gc_handler)() = 0 ;

// the default memory pool "owns" the global variables, so use its mutex
#define Malloc_mutex FramepaC_default_mempool.mutex()

#if defined(FrREPLACE_MALLOC)
static const char outside_heap_str[] = " (outside heap)" ;
#endif /* FrREPLACE_MALLOC */
static const char FrRealloc_str[] = "FrRealloc" ;
static const char FrFree_str[] = "FrFree" ;

/************************************************************************/
/*	Helper functions						*/
/************************************************************************/

static void FramepaC_auto_gc_handler_func()
{
   FrAllocator *alloc = FramepaC_allocators ;
   while (alloc)
      {
      alloc->async_gc() ;
      alloc->compact(false) ;
      alloc = alloc->nextAllocator() ;
      }
   return ;
}

//----------------------------------------------------------------------

static void FramepaC_gc_handler_func()
{
   FrAllocator *alloc = FramepaC_allocators ;
   while (alloc)
      {
      alloc->gc() ;
      alloc->compact(true) ;
      alloc->reclaimFreeBlocks() ;
      alloc = alloc->nextAllocator() ;
      }
   return ;
}

//----------------------------------------------------------------------

inline size_t suballoc_bin(size_t size)
{
   if (size < sizeof(FrFreeList))
      size = sizeof(FrFreeList) ;
   return ((size+sizeof(unsigned short))+(SUBALLOC_GRAN-1)) / SUBALLOC_GRAN ;
}

static FrSubAllocator suballoc_alloc(suballoc_bin(sizeof(FrSubAllocator))
				     *SUBALLOC_GRAN,"small FrMalloc") ;

//----------------------------------------------------------------------

static bool new_suballoc()
{
   size_t alloc_bin = ~0 ;
   if (sizeof(FrSubAllocator) <= FrMAX_AUTO_SUBALLOC)
      {
      alloc_bin = suballoc_bin(sizeof(FrSubAllocator)) ;
      if (suballoc_alloc.objectSize() == 0)
	 {
	 suballoc_alloc.setAllocFunc() ;
	 suballoc_alloc.setObjectSize(alloc_bin * SUBALLOC_GRAN) ;
	 }
      suballoc_alloc.initFreelist() ;
      auto_suballocators[alloc_bin] = &suballoc_alloc ;
      }
   for (size_t i = suballoc_bin(1); i <= suballoc_bin(MAX_AUTO_SUBALLOC) ; i++)
      {
      if (i != alloc_bin)
	 {
	 auto_suballocators[i] = new FrSubAllocator(i * SUBALLOC_GRAN) ;
	 auto_suballocators[i]->initFreelist() ;
	 }
      }
   auto_suballocators_alloc = true ;
   bool success = true ;
   for (size_t i = suballoc_bin(1); i <= suballoc_bin(MAX_AUTO_SUBALLOC) ; i++)
      {
      if (auto_suballocators[i])
	 {
	 size_t datasize = (auto_suballocators[i]->objectSize() -
			    sizeof(unsigned short)) ;
	 char name[40] ;
	 Fr_sprintf(name,sizeof(name),"FrMalloc <= %d",(int)datasize) ;
	 auto_suballocators[i]->setName(name) ;
	 }
      else
	 success = false ;
      }
   auto_suballocators_alloc = success ;
   return success ;
}

//----------------------------------------------------------------------
// thread-safety note: caller must ensure serialized access to
//   'freelist'

static FrFreeList *alloc_subobj_block(FrObjArray *newfr,
				      FrFreeList *freelist, size_t size)
{
   // build a new free list inside the array we just allocated, adding it to
   //   the front of the existing free list
   FrFreeList *last = (FrFreeList*)&newfr->objs[FrBLOCKING_SIZE-2*size] ;
   FrFreeList *fr ;
   for (fr = (FrFreeList*)(newfr->objs + FrALIGN_SIZE) ;
	fr <= last ;
	fr = fr->next)
      {
      fr->next = (FrFreeList*)(((char*)fr)+size) ;
      MEMWRITE_CLEAR(fr) ;		// ensure proper memory init for
      					// running with FrMEMWRITE_CHECK or
      					// under Purify
      HDRSETSIZE(fr,size - sizeof(unsigned short)) ;
      }
   fr->next = freelist ;
   MEMWRITE_CLEAR(fr) ;			// ensure proper memory init
   HDRSETSIZEUSED(fr,size - sizeof(unsigned short)) ;
   VALGRIND_MAKE_MEM_NOACCESS(newfr->objs,sizeof(newfr->objs)) ;
   return (FrFreeList*)(newfr->objs + FrALIGN_SIZE) ;
}

//----------------------------------------------------------------------
// thread-safety note: caller must ensure serialized access to 'blocks'
//   and 'freelist'

static FrFreeList *alloc_obj_block(FrObjArray *newfr,
				   FrFreeList *freelist, size_t size)
{
   // build a new free list inside the array we just allocated, adding it to
   //   the front of the existing free list
   FrFreeList *last = (FrFreeList*)&newfr->objs[FrBLOCKING_SIZE-2*size] ;
   FrFreeList *fr ;
   for (fr = (FrFreeList*)newfr->objs ; fr <= last ; fr = fr->next)
      {
      fr->next = (FrFreeList*)(((char*)fr)+size) ;
      MEMWRITE_CLEAR(fr) ;		// ensure proper memory init for
      					// running with FrMEMWRITE_CHECK or
      					// under Purify
      }
   fr->next = freelist ;
   MEMWRITE_CLEAR(fr) ;			// ensure proper memory init
   VALGRIND_MAKE_MEM_NOACCESS(newfr->objs,sizeof(newfr->objs)) ;
   return (FrFreeList*)newfr->objs ;
}

//----------------------------------------------------------------------

inline void make_fragment(void *block, size_t oldsize, size_t newsize,
			  FrMemoryPoolInfo *mpi)
{
   size_t leftover = oldsize - newsize ;
   char *frag = (((char *)block) + newsize) ;
   char *next = (((char *)block) + oldsize) ;
   // make a valid block out of the leftover fragment and add it
   //   to the freelist
   HDR(frag).prevsize = (unsigned short)newsize ;
   HDRSETSIZEUSED(frag,leftover) ;
   HDR(next).prevsize = (unsigned short)leftover ;
   mpi->add((FrFreeHdr*)frag) ;
   return ;
}

/************************************************************************/
/*	Consistency Checks						*/
/************************************************************************/

#if defined(FrMEMORY_CHECKS) && defined(FrREPLACE_MALLOC)
#define check_in_heap(block,msg,retval)					\
   FrCRITSECT_ENTER(FramepaC_bigalloc_pool.mutex()) ;			\
   bool bad = (block < memory_start || block >= FramepaC_memory_end) ;	\
   FrCRITSECT_LEAVE(FramepaC_bigalloc_pool.mutex()) ;			\
   if (bad)								\
      {									\
      FramepaC_bad_pointer(block,outside_heap_str,msg) ;		\
      return retval ;							\
      }
#else
#define check_in_heap(block,msg,retval)
#endif /* FrMEMORY_CHECKS && FrREPLACE_MALLOC */

#if defined(FrMEMORY_CHECKS) && defined(FrPOINTERS_MUST_ALIGN)
#define check_alignment(block,msg,retval)	  \
   if (((long int)block & (FrALIGN_SIZE-1)) != 0)	\
      {							\
      FramepaC_bad_pointer(block,misaligned_str,msg) ;	\
      errno = EFAULT ;					\
      return retval ;					\
      }
#else
#define check_alignment(block,msg,retval)
#endif /* FrMEMORY_CHECKS && FrPOINTERS_MUST_ALIGN */

//----------------------------------------------------------------------

static bool check_FrMalloc_block(const FrObjArray *block, void *userptr = 0,
				 bool *found = 0)
{
   const char *frag = (((char*)block)+FrALIGN_SIZE) ;
   const char *prev = frag ;
   const char *last = frag + ((sizeof(block->objs)/FrALIGN_SIZE)-1)*FrALIGN_SIZE ;
   const char *next ;
   if (found)
      *found = false ;
   int size ;
   do {
      if (userptr && userptr == frag && found)
	 *found = true ;
      if (HDR(frag).prevsize != (frag-prev))
	 {
	 FrMessage("bad prev-subblock size") ;
	 return false ;	   // corrupted: bad previous-subblock size
	 }
      size = HDRBLKSIZE(frag) ;
      if (size > (last-frag) || (size & (FrALIGN_SIZE-1)) != 0)
	 {
	 FrMessage("bad subblock size") ;
	 return false ;	   // corrupted: bad subblock size
	 }
      next = frag + size ;
      if (size)
	 {
	 if (HDR(next).prevsize != size)
	    {
	    FrMessage("link mismatch (next)") ;
	    return false ; // corrupted: link mismatch with following subblock
	    }
	 }
      else if (frag != last)
	 {
	 FrMessage("last block in wrong place") ;
	 return false ;	   // corrupted: last block doesn't end in right place
	 }
      prev = frag ;
      frag = next ;
      } while (size && frag <= last) ;
   return true ;  // block checks out OK
}

//----------------------------------------------------------------------

bool check_FrMalloc(FrMemoryPoolInfo *mpi)
{
   // check FrMalloc memory chain, and then report either that the pointer
   // is bad or that it has already been freed
   FrCRITSECT_ENTER(mpi->mutex()) ;
   for (const FrObjArray *block = mpi->blocklist() ;
	block ;
	block = block->next)
      {
      if (!check_FrMalloc_block(block))
	 return false ;	   // block bad, so FrMalloc chain is corrupt!
      }
   FrCRITSECT_LEAVE(mpi->mutex()) ;
   return mpi->checkFreelist() ;
}

/************************************************************************/
/*	General allocation functions					*/
/************************************************************************/

static void *_malloc_reclaimed_block(size_t size)
{
   void *blk = 0 ;
   if (!FramepaC_reclaim_free_blocks() ||
       (blk = big_malloc(size)) == 0)
      {
      FramepaC_auto_gc() ;	  // if no blocks free, try to free some
      if (!FramepaC_reclaim_free_blocks() ||
	  (blk = big_malloc(size)) == 0)
	 {
#ifdef FrLRU_DISCARD
	 while (discard_LRU_frames())
	    {
	    FramepaC_auto_gc() ;
	    if (FramepaC_reclaim_free_blocks() &&
		(blk = big_malloc(size)) != 0)
	       break ;
	    }
#endif /* FrLRU_DISCARD */
	 }
      }
   return blk ;
}

// to prevent automatic inlining by Watcom C++ or Visual C++ and to permit
// possible extensions with other handlers, we indirect
// malloc_reclaimed_block() through a pointer
static void *(*malloc_reclaimed_block)(size_t size) = _malloc_reclaimed_block ;

//----------------------------------------------------------------------

static FrObjArray *_allocate_reclaimed_block(const char *errloc)
{
   FramepaC_auto_gc() ;		 // try to free some blocks
   // throw out frames if we haven't freed any blocks yet
#ifdef FrLRU_DISCARD
   while (!FramepaC_default_mempool.haveFreeBlocks() && discard_LRU_frames())
      {
      FramepaC_auto_gc() ;
      }
#endif /* FrLRU_DISCARD */
   FrObjArray *newobj = FramepaC_default_mempool.popFreeBlock() ;
   if (!newobj && errloc)
      FrNoMemory(errloc) ;
   return newobj ;
}

// to prevent automatic inlining by the compiler and to permit possible
// extensions with other handlers, we indirect through a pointer
static FrObjArray* (*allocate_reclaimed_block)(const char *msg)
	= _allocate_reclaimed_block ;

//----------------------------------------------------------------------

FrObjArray *FramepaC_allocate_block(const char *errloc)
{
   FrObjArray *newobj = FramepaC_default_mempool.popFreeBlock() ;
   if (!newobj)
      {
#ifdef FrMEMWRITE_CHECKS
      if (!FramepaC_memory_chain_OK() ||
	  !check_FrMalloc(&FramepaC_default_mempool))
	 FrProgError("memory corruption detected while allocating block!") ;
#endif /* FrMEMWRITE_CHECKS */
      newobj = (FrObjArray*)big_malloc(sizeof(FrObjArray)) ;
      if (!newobj)			// out of memory?
	 {
	 newobj = allocate_reclaimed_block(errloc) ;
	 if (!newobj)			// REALLY out of memory?
	    return 0 ;
	 }
      }
#ifdef FrREPLACE_MALLOC
   ((FrBigAllocHdr*)newobj)[-1].suballocated = (unsigned char)1 ;
#endif /* FrREPLACE_MALLOC */
   return newobj ;
}

//----------------------------------------------------------------------

static bool in_free_subblock(const FrObjArray *block, void *userptr)
{
   // assume that the block is OK, so we just follow the subblock chain and
   // see whether the user pointer is inside a free subblock
   const char *frag = (((char*)block)+FrALIGN_SIZE) ;
   const char *last = frag + ((sizeof(block->objs)/FrALIGN_SIZE)-1)*FrALIGN_SIZE ;
   int size ;

   do {
      size = HDR(frag).size ;
      if ((size & FRFREEHDR_USED_BIT) != 0)
	 size &= FRFREEHDR_SIZE_MASK ;
      else if (userptr >= (void*)frag && userptr <= (void*)(frag+size))
	 return true ;	 // yes, we're inside a free block!
      frag += size ;
      } while (size && frag <= last) ;
   return false ;  // not inside free memory
}

//----------------------------------------------------------------------

static bool _check_free_or_bad(const FrMemoryPoolInfo *mpi,
			       const char *where, void *blk)
{
#ifdef FrREPLACE_MALLOC
   if ((char*)blk < (char*)memory_start ||
       (char*)blk >= (char*)FramepaC_memory_end)
      {
      FramepaC_bad_pointer(blk,outside_heap_str, where) ;
      return true ;
      }
#endif /* FrREPLACE_MALLOC */
   // check FrMalloc memory chain, and then report either that the pointer
   // is bad or that it has already been freed
   for (const FrObjArray *block=mpi->blocklist() ; block ; block = block->next)
      {
      bool found ;
      if (blk >= (void*)block &&
	  blk <= (void*)(((char*)block)+sizeof(FrObjArray)))
	 {
	 if (!check_FrMalloc_block(block,blk,&found))
	    FramepaC_memory_corrupted(block,true,where) ;
	 else if (!found)
	    {
	    const char *comment = (in_free_subblock(block,blk)
				   ? " (possibly re-freed)" : "") ;
	    FramepaC_bad_pointer(blk, comment, where) ;
	    }
	 else
	    {
	    char buf[200] ;
	    Fr_sprintf(buf,sizeof(buf),"gave already-free block 0x%lX to %s",
		       (long int)blk,where) ;
	    FramepaC_mem_err(buf) ;
	    }
	 return false ;
	 }
      }
   // memory checks out OK, so pointer must be bad
   FramepaC_bad_pointer(blk,"",where) ;
   return true ;
}

// to prevent automatic inlining by Watcom C++ or Visual C++ and to permit
// possible extensions with other handlers, we indirect check_free_or_bad()
// through a pointer
static bool (*check_free_or_bad)(const FrMemoryPoolInfo *,const char *,void *blk) = _check_free_or_bad ;

/************************************************************************/
/*	"Garbage Collection"  (memory compaction)			*/
/************************************************************************/

static void compact_Malloc(FrMemoryPoolInfo *mpi)
{
#ifdef FrMEMWRITE_CHECKS
   if (!gc_in_progress && (!FramepaC_memory_chain_OK() ||
			   !check_FrMalloc(mpi)))
      FrProgError("memory corruption detected while compacting FrMalloc memory!") ;
#endif /* FrMEMWRITE_CHECKS */
   FrObjArray *prev = 0 ;
   mpi->enterCritical() ;
   FrObjArray *block = (FrObjArray*)mpi->blocklist() ;
   while (block)
      {
      void *hdr = block->objs + FrALIGN_SIZE ;
      // is there only a single unallocated block in the FrObjArray?
      unsigned short size = HDRBLKSIZE(hdr) ;
      if (size > 0 && HDRBLKSIZE(block->objs + FrALIGN_SIZE + size) == 0 &&
	  HDRBLKUSED(hdr) == 0)
	 {
	 FrObjArray *curr = block ;
	 block = block->next ;
	 mpi->remove((FrFreeHdr*)hdr) ;		// pass the body of the block
	 mpi->removeBlock(curr,prev) ;
	 }
      else
	 {
	 prev = block ;
	 block = block->next ;
	 }
      }
   mpi->leaveCritical() ;
   return ;
}

//----------------------------------------------------------------------

void FramepaC_auto_gc()
{
   if (gc_in_progress)
      return ;
   gc_in_progress = true ;
#ifdef FrMEMWRITE_CHECKS
   if (!FramepaC_memory_chain_OK() ||
       !check_FrMalloc(&FramepaC_default_mempool))
      FrProgError("memory corruption detected while starting GC!") ;
#endif /* FrMEMWRITE_CHECKS */
   if (FramepaC_auto_gc_handler)
      FramepaC_auto_gc_handler() ;
   compact_Malloc(&FramepaC_default_mempool) ;
   gc_in_progress = false ;
   return ;
}

//----------------------------------------------------------------------
// return any blocks on the global freelist to the system's memory allocator

static bool FramepaC_reclaim_free_blocks()
{
   bool reclaimed = FramepaC_default_mempool.reclaimFreeBlocks() ;
#if defined(FrREPLACE_MALLOC)
   if (big_reclaim())
      return true ;
#endif /* FrREPLACE_MALLOC */
   return reclaimed ;
}

//----------------------------------------------------------------------

void FramepaC_gc()
{
   if (gc_in_progress)
      return ;
   gc_in_progress = true ;
#ifdef FrMEMWRITE_CHECKS
   if (!FramepaC_memory_chain_OK() ||
       !check_FrMalloc(&FramepaC_default_mempool))
      FrProgError("memory corruption detected while starting GC!") ;
#endif /* FrMEMWRITE_CHECKS */
   if (FramepaC_gc_handler)
      FramepaC_gc_handler() ;
   compact_Malloc(&FramepaC_default_mempool) ;
   FramepaC_reclaim_free_blocks() ;
#ifdef FrMEMWRITE_CHECKS
   if (!FramepaC_memory_chain_OK() ||
       !check_FrMalloc(&FramepaC_default_mempool))
      FrProgError("memory corruption detected at end of GC!") ;
#endif /* FrMEMWRITE_CHECKS */
   gc_in_progress = false ;
   return ;
}

//----------------------------------------------------------------------

void FrMalloc_gc()
{
   void (*old_gc)() = FramepaC_gc_handler ;
   FramepaC_gc_handler = 0 ;
   FramepaC_gc() ;
   FramepaC_gc_handler = old_gc ;
   return ;
}

/************************************************************************/
/*	Methods for class FrSubAllocator				*/
/************************************************************************/

FrSubAllocator::FrSubAllocator(int size, const char *name,
			       FrCompactFunc *func)
   : FrAllocator(name,size,func)
{
   offset = FrALIGN_SIZE ;
   setAllocFunc() ;
   return ;
}

/************************************************************************/
/*	Methods for class FrMemoryPool					*/
/************************************************************************/

FrMemoryPool::FrMemoryPool(const char *name, bool subclass)
{
   init(name) ;
   mempool_subclass = subclass ;
   if (!subclass)
      {
      FrCRITSECT_ENTER(Malloc_mutex) ;
      m_next = FramepaC_memory_pools ;
      FramepaC_memory_pools = this ;
      if (m_next)
	 m_next->m_prev = this ;
      FrCRITSECT_LEAVE(Malloc_mutex) ;
      }
   return ;
}

//----------------------------------------------------------------------

void FrMemoryPool::setName(const char *name)
{
   if (name)
      {
      char *tname = m_typename ;
      strncpy(m_typename,name,sizeof(m_typename)) ;
      tname[sizeof(m_typename)-1] = '\0' ;
      }
   else
      m_typename[0] = '\0' ;
   return ;
}

//----------------------------------------------------------------------

void FrMemoryPool::init(const char *name)
{
   FrMemoryPoolInfo::init() ;
   setName(name) ;
   m_prev = 0 ;
   VALGRIND_CREATE_MEMPOOL(this,0,0) ;
   VALGRIND_MAKE_MEM_DEFINED(this,sizeof(FrMemoryPool)) ;
   return ;
}

//----------------------------------------------------------------------

FrMemoryPool::~FrMemoryPool()
{
   FrCRITSECT_ENTER(Malloc_mutex) ;
   VALGRIND_DESTROY_MEMPOOL(this) ;
   if (nextPool())
      nextPool()->m_prev = prevPool() ;
   if (!mempool_subclass)
      {
      if (prevPool())
	 prevPool()->m_next = nextPool() ;
      else
	 FramepaC_memory_pools = nextPool() ;
      }
   FrCRITSECT_LEAVE(Malloc_mutex) ;
   return ;
}

//----------------------------------------------------------------------

void *FrMemoryPool::allocate(size_t size)
{
   if (size <= MAX_AUTO_SUBALLOC)
      {
      if (!auto_suballocators_alloc && !new_suballoc())
	 {
	 errno = ENOMEM ;
	 return 0 ;
	 }
      size_t bin = suballoc_bin(size) ;
      void *blk = auto_suballocators[bin]->allocate() ;
      HDRMARKUSED(blk) ;
      return blk ;
      }
   if_MEMUSE_STATS(FrMalloc_requests++) ;
   if_MEMUSE_STATS(FrMalloc_bytes += size) ;
   if (size <= MAX_SMALL_ALLOC)
      {
      size_t user_size = size ;
#if defined(FrMEMWRITE_CHECKS)
      if (!check_FrMalloc(this))
	 FrProgError("memory corruption detected by FrMalloc!") ;
#endif /* FrMEMWRITE_CHECKS */
      // round request up to necessary alignment size
      size = round_up(user_size + HDRSIZE,FrALIGN_SIZE) ;
      void *block = this->pop(size) ;
      int freesize ;
      if (!block)
	 {
	 FrObjArray *newblock = allocate_block("in FrMalloc()") ;
	 if (!newblock)
	    {
	    errno = ENOMEM ;
	    return 0 ;
	    }
	 this->addBlock(newblock) ;
	 block = (FrFreeHdr*)(newblock->objs + FrALIGN_SIZE) ;
#define last (((sizeof(newblock->objs)/FrALIGN_SIZE) - 1) * FrALIGN_SIZE)
	 HDR(block).prevsize = 0 ;
	 char *lastelt = ((char*)block) + last ;
	 HDRSETSIZEUSED(block,last) ;
	 HDRSETSIZEUSED(lastelt,0) ;     // end marker
	 freesize = last ;
	 HDR(lastelt).prevsize = (unsigned short)last ;
#undef last
	 }
      else // (block != 0)
	 {
	 freesize = HDRBLKSIZE(block) ;
	 ASSERT((size_t)freesize >= size,"found too-small block") ;
	 }
      // we now have a block big enough to hold the requested allocation, so
      // split it and store the left-over fragment on the appropriate free list
      FrMemoryPoolInfo::splitblock(freesize,size) ;
      // split off excess if possible
      if (size < (size_t)freesize)
	 {
//	 FrCRITSECT_ENTER(this->mutex()) ;
	 make_fragment(block,freesize,size,this) ;
	 // set block's size, mark as used
	 HDRSETSIZEUSED(block,size) ;
//	 FrCRITSECT_LEAVE(this->mutex()) ;
	 }
//!      VALGRIND_MEMPOOL_ALLOC(this,block,user_size) ;
      return block ;
      }
   else // size > MAX_SMALL_ALLOC
      {
      size += BIGHDRSIZE ;
      void *blk = big_malloc(size) ;
      if (!blk)
	 blk = malloc_reclaimed_block(size) ;
      if (blk)
	 {
	 blk = (((char*)blk)+BIGHDRSIZE) ;
	 HDR(blk).prevsize = 0 ;       		// insert a FrMalloc header
	 HDR(blk).size = FRFREEHDR_BIGBLOCK ; 	// flag it as a system block
	 BIGHDR(blk).size = size ;
	 }
      return blk ;
      }
}

//----------------------------------------------------------------------

#if defined(_MSC_VER) && _MSC_VER >= 800
// turn off Visual C++'s complaint about short += (short)int losing data....
#pragma warning(disable : 4244)
#endif /* _MSC_VER */

void *FrMemoryPool::reallocate(void *block,size_t newsize, bool copydata)
{
   if (block)
      {
      if_MEMUSE_STATS(FrRealloc_requests++) ;
      check_alignment(block,FrRealloc_str,0) ;
      check_in_heap(block,FrRealloc_str,block) ;
      unsigned int oldsize = HDRBLKSIZE(block) ;
      if (oldsize == FRFREEHDR_BIGBLOCK)  // big blocks must always get new alloc
	 {
#ifdef FrREPLACE_MALLOC
	 if (newsize > MAX_SMALL_ALLOC)
	    {
	    FrBigAllocHdr *hdr = (FrBigAllocHdr*)(((char*)block)-BIGHDRSIZE
						  -sizeof(FrBigAllocHdr)) ;
	    newsize += BIGHDRSIZE ;
	    void *cp = big_realloc(hdr,newsize) ;
	    if (cp)
	       {
	       cp = (void*)(((char*)cp) + BIGHDRSIZE) ;
	       BIGHDR(cp).size = newsize ;
	       }
	    return cp ;
	    }
#elif defined(FrTHREE_ARG_NEW)
	 // some versions of Gnu C have a special three-arg new() which will
	 // realloc a block
	 if (newsize > MAX_SMALL_ALLOC)
	    {
	    char *cp = new(((char*)block)-BIGHDRSIZE,newsize+BIGHDRSIZE) char ;
	    cp += BIGHDRSIZE ;
	    return cp ;
	    }
#endif /* FrREPLACE_MALLOC */
	 // get true size from header
	 oldsize = BIGHDR(block).size - BIGHDRSIZE ;
	 }
      else if (HDRBLKUSED(block) == 0)
	 {
	 check_free_or_bad(this,FrRealloc_str,block) ;
	 errno = EFAULT ;
	 return 0 ;
	 }
      else if (newsize <= MAX_AUTO_SUBALLOC &&
	       oldsize <= MAX_AUTO_SUBALLOC)
	 {
	 if (suballoc_bin(oldsize) == suballoc_bin(newsize))
	    {
	    return block ;
	    }
	 }
      else if ((newsize <= MAX_AUTO_SUBALLOC &&
		oldsize > MAX_AUTO_SUBALLOC)
	       ||
	       (newsize > MAX_AUTO_SUBALLOC &&
		oldsize <= MAX_AUTO_SUBALLOC))
	 {
	 // switching between auto_suballoc and normal FrMalloc means
	 //    we have to perform a fresh allocation (below)....
	 }
      else // if (0) //FIXME
	 {
	 // round request up to necessary alignment size, ensuring minimum size
	 //  requirement is met
	 size_t user_size = newsize ;
	 if (newsize < MIN_ALLOC-HDRSIZE)
	    newsize = round_up(MIN_ALLOC,FrALIGN_SIZE) ;
	 else
	    newsize = round_up(user_size+HDRSIZE,FrALIGN_SIZE) ;
	 if (newsize == (size_t)oldsize)
	    {
//!	    VALGRIND_MEMPOOL_CHANGE(this,block,block,user_size) ;
	    return block ;
	    }
	 FrFreeHdr *next = (FrFreeHdr*)(((char *)block) + oldsize) ;
#ifdef FrMEMORY_CHECKS
	 if (HDR(next).prevsize != oldsize)
	    {
	    check_free_or_bad(this,FrRealloc_str,block) ;
	    errno = EFAULT ;
	    return 0 ;
	    }
#endif /* FrMEMORY_CHECKS */
	 unsigned int nextsize = this->removeIfFree(next) ;
	 if (nextsize > 0)     // merge in free block after ours
	    {
	    FrFreeHdr *nextnext = (FrFreeHdr*)(((char*)next)+nextsize) ;
	    oldsize += (unsigned int)nextsize ;
	    // add other block's size to ours
	    FrCRITSECT_ENTER(this->mutex()) ;
	    HDRSETSIZEUSED(block,oldsize) ;
	    HDR(nextnext).prevsize = oldsize ;
	    FrCRITSECT_LEAVE(this->mutex()) ;
	    }
	 if (newsize <= (size_t)oldsize)     // possible to resize as desired?
	    {
	    FrMemoryPoolInfo::splitblock(oldsize,newsize) ;
	    // split off excess if possible
	    if (newsize < (size_t)oldsize)
	       {
//	       FrCRITSECT_ENTER(this->mutex()) ;
	       make_fragment(block,oldsize,newsize,this) ;
	       // set block's size, mark as used
	       HDRSETSIZEUSED(block,newsize) ;
//	       FrCRITSECT_LEAVE(this->mutex()) ;
	       }
//!	    VALGRIND_MEMPOOL_CHANGE(this,block,block,user_size) ;
	    return block ;
	    }
	 }
      // if we get here, we were unable to resize the existing block
      void *newblock ;
      if ((newblock = allocate(newsize)) == 0)
	 {
	 return 0 ;			// errno already set to ENOMEM
	 }
      if (copydata)
	 {
	 if (newsize < (size_t)oldsize)
	    oldsize = newsize ;
	 memcpy(newblock,block,oldsize) ;
	 }
      release(block) ;
      return newblock ;
      }
   else // block == 0
      {
      return allocate(newsize) ;
      }
}

#if defined(_MSC_VER) && _MSC_VER >= 800
// re-enable Visual C++'s loss-of-data complaint for short += int
#pragma warning(enable : 4244)
#endif /* _MSC_VER */

//----------------------------------------------------------------------

void FrMemoryPool::release(void *block)
{
   if (block)
      {
      check_alignment(block,FrFree_str,) ;
      check_in_heap(block,FrFree_str,) ;
      unsigned size = HDR(block).size ;
      if (size == FRFREEHDR_BIGBLOCK)
	 big_free((FrBigAllocHdr*)((char*)block-BIGHDRSIZE-
				   sizeof(FrBigAllocHdr))) ;
      else if ((size & FRFREEHDR_USED_BIT) != 0)// make sure block is in use...
	 {
	 size &= FRFREEHDR_SIZE_MASK ;
	 if (size <= MAX_AUTO_SUBALLOC)
	    {
	    size_t bin = suballoc_bin(size) ;
	    HDRMARKFREE(block) ;
	    if (auto_suballocators[bin])
	       auto_suballocators[bin]->release(block) ;
	    else
	       FrProgErrorVA("attempted to free small block (size %d) for which\n"
			     "no suballocator has been set up!",(int)size) ;
	    return ;
	    }
	 // mark the block free
	 FrFreeHdr *next = (FrFreeHdr*)(((char*)block) + size) ;
//!	 VALGRIND_MEMPOOL_FREE(this,block) ;
#ifdef FrMEMORY_CHECKS
	 if (HDR(next).prevsize != size)
	    {
	    check_free_or_bad(this,FrFree_str,block) ;
	    errno = EFAULT ;
	    return ;
	    }
#endif /* FrMEMORY_CHECKS */
	 // merge with the following block if it is also free
	 unsigned nextsize = this->removeIfFree(next) ;
	 FrCRITSECT_ENTER(this->mutex()) ;
	 if (nextsize > 0)
	    {
	    next = (FrFreeHdr*)(((char*)next) + nextsize) ;
	    size += nextsize ;
	    HDRSETSIZEUSED(block,size) ;
	    HDR(next).prevsize = size ;
	    }
	 unsigned prevsize = HDR(block).prevsize ;
	 // coalesce with previous block if it is also free
	 if (prevsize != 0)
	    {
	    FrFreeHdr *prev = (FrFreeHdr*)(((char*)block) - prevsize) ;
	    unsigned int psize = HDR(prev).size ;
	    if (psize == prevsize)
	       {
	       this->remove(prev,this->bin(prevsize)) ;
	       HDR(next).prevsize += (unsigned short)prevsize ;
	       HDR(prev).size += size ;
	       block = prev ;
	       }
#ifdef FrMEMORY_CHECKS
	    else if ((psize & FRFREEHDR_SIZE_MASK) != prevsize)
	       {
	       check_free_or_bad(this,FrFree_str,block) ;
	       errno = EFAULT ;
	       FrCRITSECT_LEAVE(this->mutex()) ;
	       return ;
	       }
#endif /* FrMEMORY_CHECKS */
	    }
	 FrCRITSECT_LEAVE(this->mutex()) ;
	 this->add((FrFreeHdr*)block) ;
	 return ;
	 }
      else			// the block is already free or bad...
	 {
	 if (size <= MAX_AUTO_SUBALLOC)
	    {
	    FramepaC_bad_pointer(block,"",FrFree_str) ;
	    return ;
	    }
	 check_free_or_bad(this,FrFree_str,block) ;
	 return ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

long FrMemoryPool::bytes_allocated() const
{
   return numBlocks() * FrBLOCKING_SIZE ;
}

/************************************************************************/
/*	class FrAllocator						*/
/************************************************************************/

FrAllocator::FrAllocator(const char *name, int size, FrCompactFunc *func)
   : FrMemoryPool(name,true)
{
   if (size < (int)sizeof(FrFreeList))
      size = sizeof(FrFreeList) ;
   objsize = size ;
   offset = 0 ;
   freelist = 0 ;
   mempool_subclass = true ;
   compact_func = func ;
   gc_func = 0 ;
   async_gc_func = 0 ;
   compacting = false ;
   total_requests = 0 ;
   allocate_objblock = &alloc_obj_block ;
   FrCRITSECT_ENTER(Malloc_mutex) ;
   m_next = FramepaC_allocators ;
   if (nextPool())
      ((FrAllocator*)nextPool())->m_prev = this ;
   else if (!FramepaC_gc_handler)
      {
      FramepaC_gc_handler = FramepaC_gc_handler_func ;
      FramepaC_auto_gc_handler = FramepaC_auto_gc_handler_func ;
      }
   FramepaC_allocators = this ;
   FrCRITSECT_LEAVE(Malloc_mutex) ;
   return ;
}

//----------------------------------------------------------------------

FrAllocator::~FrAllocator()
{
   freelist = 0 ;
   FrCRITSECT_ENTER(Malloc_mutex) ;
   if (nextPool())
      ((FrAllocator*)nextPool())->m_prev = prevPool() ;
   if (prevPool())
      ((FrAllocator*)prevPool())->m_next = nextPool() ;
   else
      FramepaC_allocators = (FrAllocator*)nextPool() ;
   FrCRITSECT_LEAVE(Malloc_mutex) ;
   return ;
}

//----------------------------------------------------------------------

void *FrAllocator::allocate_more()
{
   //PRECONDITION: m_critsect acquired by caller
   FrObjArray *newblock ;
   if (m_freeblocks)
      {
      newblock = m_freeblocks ;
      m_freeblocks = m_freeblocks->next ;
      }
   else
      newblock = allocate_block(0) ;
   if (newblock)
      {
      freelist = (*allocate_objblock)(newblock,freelist,objsize) ;
      addBlock(newblock) ;
      }
   if (!freelist)
      FrNoMemoryVA("in %s::new",typeName()) ;
   return freelist ;
}

//----------------------------------------------------------------------

size_t FrAllocator::objects_allocated() const
{
   int per_block = FrBLOCKING_SIZE / objsize ;
   return numBlocks() * per_block ;
}

//----------------------------------------------------------------------

size_t FrAllocator::freelist_length() const
{
   int count = 0 ;
   FrFreeList *fl = freelist ;
   FrFreeList *trailer = freelist ;

   while (fl)
      {
      count++ ;
      fl = fl->next ;
      if (trailer == fl)
	 (void)FrAssertionFailed("loop in free list",__FILE__,__LINE__) ;
      if (fl)
	 {
	 count++ ;
	 fl = fl->next ;
	 if (trailer == fl)
	    (void)FrAssertionFailed("loop in free list",__FILE__,__LINE__) ;
	 trailer = trailer->next ;
	 }
      }
   return count ;
}

//----------------------------------------------------------------------

void FrAllocator::set_gc_funcs(FrGCFunc *gc_fn, FrGCFunc *async_gc_fn)
{
   gc_func = gc_fn ;
   async_gc_func = async_gc_fn ;
   return ;
}

//----------------------------------------------------------------------

int FrAllocator::async_gc()
{
   int reclaimed = 0 ;
   if (async_gc_func)
      reclaimed = async_gc_func(this) ;
   return reclaimed ;			// indicate number of objects freed
}

//----------------------------------------------------------------------

int FrAllocator::gc()
{
   int reclaimed = 0 ;
   if (gc_func)
      reclaimed = gc_func(this) ;
   return reclaimed ;			// indicate number of objects freed
}

//----------------------------------------------------------------------

int FrAllocator::compact(bool force)
{
   if (compacting)	// avoid reentering ourself if the user's compaction
      return 0 ;	//   function causes another compaction
   if (objsize < sizeof(FrFreeList) ||
       (offset && objsize < sizeof(FrFreeList) + sizeof(short)))
      return 0 ;			// sorry, can't compact -- too small
   compacting = true ;
   // mark all the free items so that they can be recognized during compaction
   for (FrFreeList *fl = freelist ; fl ; fl = fl->next)
      {
      fl->marker = &free_cell ;
      }
   int totalfree = 0 ;
   int numfreed = 0 ;
   FrObjArray *prv = 0 ;
   FrObjArray *block = (FrObjArray*)blocklist() ;
   FrObjArray *curr ;
   const char *obj, *last ;

   // count up how many free items are in each block, and total free items
   while (block)
      {
      int count = 0 ;
      int inuse = 0 ;
      last = &block->objs[FrBLOCKING_SIZE-objsize] ;
      for (obj = block->objs + offset ; obj <= last ; obj += objsize)
	 {
	 if (((FrFreeList*)obj)->marker == &free_cell)
	    count++ ;
	 else
	    inuse++ ;
	 }
      // entirely empty block?
      if (!inuse)
	 {
	 // mark all cells in the block for reclamation
	 for (obj = block->objs + offset ; obj <= last ; obj += objsize)
	    ((FrFreeList*)obj)->marker = &freed_cell ;
	 // give the block back to the system
	 curr = block ;
	 block = block->next ;
	 removeBlock(curr,prv) ;
	 numfreed++ ;
	 }
      else
	 {
	 totalfree += count ;
	 prv = block ;
	 block = block->next ;
	 }
      }
   // don't bother doing the actual compaction unless we can free a block
   // by compacting the cells which are in use, unless we've been told to
   // force the compaction (e.g. the compaction function frees some items)
   FrObjArray *freedblocks = 0 ;
   if (compact_func && (force || totalfree >= (int)(FrBLOCKING_SIZE/objsize)))
      {
      compact_func(this,&freelist,&freedblocks);
      // mark all cells in the freed block(s) for reclamation
      for (curr = freedblocks ; curr ; curr = curr->next)
	 {
	 last = &curr->objs[FrBLOCKING_SIZE-objsize] ;
	 for (obj = curr->objs + offset ; obj <= last ; obj += objsize)
	    ((FrFreeList*)obj)->marker = &freed_cell ;
	 numfreed++ ;
	 }
      // any blocks to be freed get put back on the global free list
      while (freedblocks)
	 {
	 numfreed++ ;
	 m_blocks-- ;
	 curr = freedblocks ;
	 freedblocks = freedblocks->next ;
	 FramepaC_default_mempool.addFreeBlock(curr) ;
	 }
      }
   if (numfreed > 0)
      {
      // remove the elements of the freelist which are in blocks that have been
      //   freed
      FrFreeList *f1 = 0 ;
      // atomically grap the entire freelist to keep Helgrind et al happy
      FrFreeList *orig_freelist = m_critsect.swap(freelist,f1) ;
      FrFreeList *f2 = orig_freelist ;
      while (f2)
	 {
	 if (f2->marker == &freed_cell)
	    {
	    f2 = f2->next ;
	    if (f1)
	       f1->next = f2 ;
	    else
	       orig_freelist = f2 ;
	    }
	 else
	    {
	    f1 = f2 ;
	    f2 = f2->next ;
	    }
	 }
      (void)m_critsect.swap(freelist,orig_freelist) ;
      }
#ifdef FrMEMWRITE_CHECKS
   // restore markers on all the free items for overwrite checks during
   //   allocation calls
   for (FrFreeList *fl = freelist ; fl ; fl = fl->next)
      {
      fl->marker = 0 ;
      }
#endif /* FrMEMWRITE_CHECKS */
   compacting = false ;
   return numfreed ;
}

//----------------------------------------------------------------------

size_t FrAllocator::reclaimFreeBlocks()
{
   size_t reclaimed = 0 ;
   if (this != &FramepaC_default_mempool)
      {
      while (m_freeblocks)
	 {
	 FrObjArray *block = m_freeblocks ;
	 m_freeblocks = m_freeblocks->next ;
	 FramepaC_default_mempool.addFreeBlock(block) ;
	 }
      }
   return reclaimed ;
}

//----------------------------------------------------------------------

int FrAllocator::zapAll()
{
#if defined(VALGRIND) || defined(PURIFY)
   return 0 ;
#else
   if (compacting)	// avoid reentering ourself if the user's compaction
      return 0 ;	//   function causes another compaction
   FrCRITSECT_ENTER(Malloc_mutex) ;
   compacting = true ;
   size_t numfreed = numBlocks() ;
   removeAllBlocks() ;
   freelist = 0 ;
   FrMemoryPoolInfo::init() ;		// zap all freelists
   compacting = false ;
   FrCRITSECT_LEAVE(Malloc_mutex) ;
   return numfreed ;
#endif /* VALGRIND || PURIFY */
}

//----------------------------------------------------------------------

void FrAllocator::preAllocate()
{
   m_critsect.acquire() ;
   (void)allocate_more() ;
   m_critsect.release() ;
   return ;
}

//----------------------------------------------------------------------

bool FrAllocator::iterateVA(FrMemIterFunc *func, va_list args)
{
   if (!func)
      return true ;			// trivially successful
   // mark all the free items so that they can be recognized during iteration
   for (FrFreeList *fl = freelist ; fl ; fl = fl->next)
      fl->marker = &free_cell ;
   bool success = true ;
   for (const FrObjArray *block = blocklist() ; block ; block = block->next)
      {
      const char *last = &block->objs[FrBLOCKING_SIZE-objsize] ;
      for (char *obj = (char*)block->objs + offset ;
	   obj <= last ;
	   obj += objsize)
	 {
	 if (((FrFreeList*)obj)->marker != &free_cell)
	    {
	    FrSafeVAList(args) ;
	    success = func(obj,FrSafeVarArgs(args)) ;
	    FrSafeVAListEnd(args) ;
	    if (!success)
	       break ;
	    }
	 }
      }
   return success ;
}

//----------------------------------------------------------------------

bool FrAllocator::iterate(FrMemIterFunc *func, ...)
{
   va_list args ;
   va_start(args,func) ;
   bool success = this ? iterateVA(func,args) : true ;
   va_end(args) ;
   return success ;
}

// end of file frmemp.cpp //
