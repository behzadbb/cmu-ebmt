/****************************** -*- C++ -*- *****************************/
/*									*/
/*  FramepaC  -- frame manipulation in C++				*/
/*  Version 1.99							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File frmem.cpp		memory allocation routines		*/
/*  LastEdit: 04mar10							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,1999,2000,2001,2002,2003,	*/
/*		 2004,2005,2006,2007,2009,2010 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#if __GNUC__ >= 3
namespace std {
#include <sys/types.h>		    	// needed by new.h
}
using namespace std ;
#endif /* __GNUC__ >= 3 */

#include <errno.h>
#include <memory.h>		        // for GCC 4.3
#include <sys/types.h>			// for sbrk() [on most systems]
#include "fr_mem.h"
#include "frmembin.h"			// template FrMemoryBinnedFreelist
#include "framerr.h"
#ifndef NDEBUG
//#  define NDEBUG			// comment out to enable assertions
#endif /* !NDEBUG */
#include "frassert.h"
#include "frlru.h"
#include "frprintf.h"
#include "memcheck.h"

#ifdef FrMMAP_SUPPORTED
#ifdef unix
#  include <sys/mman.h>
#elif defined(__WINDOWS__) || defined(__NT__)
#  include <windows.h>
#endif /* unix, Windows|NT */
#endif /* FrMMAP_SUPPORTED */

#ifdef FrSTRICT_CPLUSPLUS
#  include <cstdio>
#  include <cstdlib>
#  include <new>
#  include <string>			// needed on SunOS, others?
#else
#  include <new.h>
#  include <stdio.h>
#  include <stdlib.h>
#  include <string.h>			// needed on SunOS, others?
#endif /* FrSTRICT_CPLUSPLUS */

#ifdef __BORLANDC__
#include <alloc.h>	  		// for sbrk()
#endif /* __BORLANDC__ */

#ifdef _AIX
#include <unistd.h>			// for sbrk()
#endif /* _AIX */

#if defined(__GNUC__) && __GNUC__ < 3
#include <unistd.h>			// for sbrk()
#endif

#if defined(__SUNOS__) || defined(__SOLARIS__) || defined(__alpha__)
// the Sun man page says sbrk() is declared in sys/types.h, but it isn't!
extern "C" caddr_t sbrk(int incr) ;
#endif /* __SUNOS__ || __SOLARIS__ */

#if defined(__linux__) && __GNUC__ == 3 && __GNUC_MINOR__ < 3
extern "C" caddr_t sbrk(int incr) ;
#endif /* __linux__ && !__886__ */

// support for using mmap() when sbrk() space is exhausted
#if !defined(MAP_ANONYMOUS) && defined(MAP_ANON)
#  define MAP_ANONYMOUS MAP_ANON
#endif
#ifndef MAP_FAILED
#  define MAP_FAILED ((char*)-1)
#endif /* ! MAP_FAILED */
#ifdef MAP_ANONYMOUS
#  define ALLOC_MMAP(where, size, prot, flags) \
	mmap((where),(size),(prot),MAP_ANONYMOUS|(flags),-1,0)
#endif

#ifndef NDEBUG
# undef _FrCURRENT_FILE
static const char _FrCURRENT_FILE[] = __FILE__ ; // save memory
#endif /* NDEBUG */

// if frmem.h redefines the following, undefine them
#undef FrMalloc
#undef FrCalloc
#undef FrRealloc
#undef FrFree

/************************************************************************/
/*	Readability macros						*/
/************************************************************************/

/************************************************************************/
/*	Portability definitions						*/
/************************************************************************/

// BorlandC uses a weird type for the __new_handler pointer
// and also calls it by a slightly different name than GNU C++ v2.5.8
#ifdef __BORLANDC__
typedef pvf new_handler_t ;
#define __new_handler _new_handler

// Watcom C++ uses yet another type for the new handler....
#elif defined(__WATCOMC__)
typedef PFV new_handler_t ;

#elif defined(_MSC_VER)
typedef _PNH new_handler_t ;

// newer versions of GNU C++ 2.x switched types on us, then 3.0 went back....
#elif (__GNUC__ == 2 && __GNUC_MINOR__ >= 70 && __GNUC_MINOR__ < 95)
typedef fvoid_t *new_handler_t ;

#elif defined(__GNUC__)
typedef void (*new_handler_t)() ;

// if not Borland/Watcom/Gnu, define the new handler's type from scratch
#else
typedef void (*new_handler_t)() ;
#endif /* __BORLANDC__ ... */

// Porting between different behavior handling lack of memory:
// BorlandC's builtin ::new loops until either _new_handler is 0 or
// the memory allocation succeeds (if _new_handler is 0, it returns 0).
// Gnu C++ 2.5.8's builtin ::new merely calls the _new_handler and
// returns whatever it happens to return.
#ifdef __GNUC__
void *dummy_new_handler() { return 0 ; }
#  define FR_NEW_HANDLER ((new_handler_t)dummy_new_handler)
#else
#  define FR_NEW_HANDLER ((new_handler_t)0)
#endif

#ifdef FrREPLACE_MALLOC
//  inline new_handler_t set_new_handler(new_handler_t handler)
//     { (void)handler ; return 0 ; }
#elif defined(_MSC_VER)
  inline new_handler_t set_new_handler(new_handler_t handler)
     { return (new_handler_t)_set_new_handler((_PNH)handler) ; }
#elif defined(FrNEW_THROWS_EXCEPTIONS)
  // won't be using set_new_handler....
#elif !defined(__WATCOMC__)
  inline new_handler_t set_new_handler(new_handler_t handler)
     {
     new_handler_t orig_handler = __new_handler ;
     __new_handler = handler ;
     return orig_handler ;
     }
#endif /* !__WATCOMC__ */

#if defined(__WATCOMC__) || defined(_MSC_VER) || defined(SHARED)
// this variant is needed if memory allocated via sbrk() or equivalent could
// ever have an address lower than the address of initialized data
#define BAD_NEXT_LINK(block,next) \
	(((next<block || next>=FramepaC_memory_end) && \
	  next!=FramepaC_bigalloc_pool.freelistHead())|| \
	 next->prev != block)
#define BAD_PREV_LINK(block,prev) \
	(((prev >= block || prev < memory_start) && \
	  prev != FramepaC_bigalloc_pool.freelistHead()) || \
	 prev->next != block)
#else
// this variant should only be used if allocated memory is always at higher
// addresses than initialized data
#define BAD_NEXT_LINK(block,next) \
	((next < block && next != FramepaC_bigalloc_pool.freelistHead()) || \
	 next >= FramepaC_memory_end || next->prev != block)
#define BAD_PREV_LINK(block,prev) \
	(prev > block || (prev < memory_start && \
			  prev != FramepaC_bigalloc_pool.freelistHead()) || \
	 prev->next != block)
#endif /* __WATCOMC__ */

#ifdef _MSC_VER
#include <windows.h>
void *sbrk(int size)
{
   if (size > 0)
      return HeapAlloc(GetProcessHeap(),0,size) ;
   else
      return (void*)-1 ;
}
#endif /* _MSC_VER */

/************************************************************************/
/*	Manifest constants for this module				*/
/************************************************************************/

/************************************************************************/
/*	 Global Data for this module					*/
/************************************************************************/

#ifdef FrMULTITHREAD
size_t FrCriticalSection::s_collisions = 0 ;
#endif

#if defined(FrREPLACE_MALLOC) && defined(FrMEMORY_CHECKS)
static const char big_malloc_str[] = "big_malloc" ;
static const char big_free_str[] = "big_free" ;
static const char big_realloc_str[] = "big_realloc" ;
#endif /* FrREPLACE_MALLOC && FrMEMORY_CHECKS */

#if defined(FrMEMORY_CHECKS) && defined(FrPOINTERS_MUST_ALIGN)
static const char misaligned_str[] = "(misaligned)" ;
#endif /* FrMEMORY_CHECKS && FrPOINTERS_MUST_ALIGN */
#if defined(FrREPLACE_MALLOC)
static const char outside_heap_str[] = " (outside heap)" ;
#endif /* FrREPLACE_MALLOC */
static const char FrRealloc_str[] = "FrRealloc" ;
static const char FrFree_str[] = "FrFree" ;

/************************************************************************/
/*	 Global Variables for this module				*/
/************************************************************************/

bool memory_errors_are_fatal = FrMEM_ERRS_FATAL ;

int FramepaC_symbol_blocks = 0 ;
FrMemoryPool *FramepaC_memory_pools = 0 ;

//----------------------------------------------------------------------
// global variables for big_malloc

#ifdef FrREPLACE_MALLOC
FrBigAllocHdr *FramepaC_memory_end = 0 ;
static size_t total_allocations = 0 ;

FrMemoryBinnedFreelist<FrBigAllocHdr,FrBIGPOOLINFO_FACTOR>
   FramepaC_bigalloc_pool(FrALLOC_GRANULARITY, FrALLOC_BIGMAX,
			  FrALLOC_GRANULARITY) ;
#endif /* FrREPLACE_MALLOC */

// end big_malloc globals
//----------------------------------------------------------------------

//----------------------------------------------------------------------
// global variables for FrMalloc

FrMemoryPool FramepaC_default_mempool("FrMalloc") ;

// end FrMalloc globals
//----------------------------------------------------------------------

// Watcom C++ v11.x places some variables into the modules containing malloc()
// and free() which are referenced from elsewhere, thus causing linker warnings
// about duplicated functions
#if defined(__WATCOMC__) && __WATCOMC__ >= 1100 && defined(FrREPLACE_MALLOC)
extern "C" {
void *__nheapbeg = 0 ;
void *__MiniHeapRover = 0 ;
void *__MiniHeapFreeRover = 0 ;
size_t __LargestSizeB4MiniHeapRover = 0 ;
}
#endif /* __WATCOMC__ >= 1100 && FrREPLACE_MALLOC */

/************************************************************************/
/*	Static members for class FrMemoryBinnedFreelist			*/
/************************************************************************/

template<class T_hdr, unsigned N_factor>
size_t FrMemoryBinnedFreelist<T_hdr,N_factor>::m_maxbin = 0 ;
template<class T_hdr, unsigned N_factor>
size_t FrMemoryBinnedFreelist<T_hdr,N_factor>::m_granularity = 1 ;
template<class T_hdr, unsigned N_factor>
size_t FrMemoryBinnedFreelist<T_hdr,N_factor>::m_binsizes[FrMEMPOOLINFO_BINS+1] ;

/************************************************************************/
/*	Forward declarations						*/
/************************************************************************/

/************************************************************************/
/*	Error reporting							*/
/************************************************************************/

static void mem_err(const char *msg)
{
   if (memory_errors_are_fatal)
      FrProgError(msg) ;
   else
      FrWarningVA("Memory Error: %s",msg) ;
}

// to prevent automatic inlining by Watcom C++ or Visual C++ and to permit
// possible extensions with other handlers, we indirect mem_err() through a
// pointer
void (*FramepaC_mem_err)(const char *msg) = mem_err ;

//----------------------------------------------------------------------

void FramepaC_bad_pointer(void *ptr, const char *comment, const char *where)
{
   char buf[200] ;
   Fr_sprintf(buf,sizeof(buf),"%s got bad pointer 0x%lX%s.",
	      where, (long int)ptr, comment) ;
   FramepaC_mem_err(buf) ;
   return ;
}

/************************************************************************/
/*	FramepaC replacements for standard memory allocation functions	*/
/************************************************************************/

#if defined(FrREPLACE_MALLOC) && !defined(PURIFY) && !(defined(VALGRIND) && defined(VALGRIND_BROKEN))

#if !defined(FrBUGFIX_XLIB_ALLOC)
# if defined(_MSC_VER)
_CRTIMP void * __cdecl malloc(size_t size) { return FrMalloc(size) ; }
_CRTIMP void * __cdecl realloc(void *blk, size_t size) { return FrRealloc(blk,size) ; }
_CRTIMP void * __cdecl calloc(size_t n, size_t size) { return FrCalloc(n,size) ; }
_CRTIMP int    __cdecl cfree(void *blk) { FrFree(blk) ; return 1 ; }

# else // !_MSC_VER

#if __WATCOMC__ >= 1200 // OpenWatcom
namespace std {
#endif /* __WATCOMC__ */

extern "C" void *malloc(size_t size) __THROW _fnattr_malloc ;
void *malloc(size_t size) __THROW
   { return FrMalloc(size) ; }

extern "C" void *realloc(void *blk, size_t size) __THROW ;
void *realloc(void *blk, size_t size) __THROW
{ return FrRealloc(blk,size,true) ; }

extern "C" void *calloc(size_t n, size_t size) __THROW _fnattr_malloc ;
void *calloc(size_t n, size_t size) __THROW
   { return FrCalloc(n,size) ; }

#ifndef __linux__
extern "C" int cfree(void *blk) ;
int cfree(void *blk) { FrFree(blk) ; return 1 ; }
#endif /* !__linux */

extern "C" void free(void *blk) ;

#if __WATCOMC__ >= 1200 // OpenWatcom
}
#endif /* __WATCOMC__ */

# endif /* _MSC_VER */

#endif /* FrBUGFIX_XLIB_ALLOC */

#ifdef __WATCOMC__
// Watcom C 10.0a's runtime lib frees non-dynamic memory on exit!
#ifndef FrBUGFIX_XLIB_ALLOC
#if __WATCOMC__ >= 1200 // OpenWatcom
namespace std {
#endif /* __WATCOMC__ */
void free(void *blk) { if ((char*)blk >= (char*)memory_start) FrFree(blk) ; }
#if __WATCOMC__ >= 1200 // OpenWatcom
}
#endif /* __WATCOMC__ */
#endif /* FrBUGFIX_XLIB_ALLOC */

// _nmalloc and _nfree are aliases for malloc and free located in the same
// object modules in the Watcom run-time library.
extern "C" void *_nmalloc(size_t) ;
extern "C" void _nfree(void*) ;
void *_nmalloc(size_t size) { return FrMalloc(size) ; }
void _nfree(void *blk) { FrFree(blk) ; }

#else

#ifndef FrBUGFIX_XLIB_ALLOC
#  ifdef _MSC_VER
   _CRTIMP void __cdecl free(void *blk) { FrFree(blk) ; }
#  else
   void free(void *blk) { FrFree(blk) ; }
#  endif /* _MSC_VER */
#endif /* FrBUGFIX_XLIB_ALLOC */

#endif /* __WATCOMC__ */
#endif /* FrREPLACE_MALLOC && !PURIFY */

/************************************************************************/
/*	FramepaC equivalents for standard malloc() family		*/
/************************************************************************/

static void memory_corrupted(const void *blk, bool in_near, const char *where)
{
   FrProgErrorVA("Memory chain corrupted %s 0x%lX! (found by %s)\n"
		 "  This is typically the result of dereferencing a bad pointer or\n"
		 "  overrunning an array.",
		 in_near ? "in block" : "near",
		 (long int)blk, where) ;
   exit(127) ;
}

// to prevent automatic inlining by Watcom C++ or Visual C++ and to permit
// possible extensions with other handlers, we indirect memory_corrupted()
// through a pointer
void (*FramepaC_memory_corrupted)(const void *blk, bool, const char *)
    = memory_corrupted ;

//----------------------------------------------------------------------

bool FramepaC_memory_freelist_OK()
{
   bool OK = true ;
#ifdef FrREPLACE_MALLOC
   FrCRITSECT_ENTER(FramepaC_bigalloc_pool.mutex()) ;
   // check the freelist
   FrBigAllocHdr *head = FramepaC_bigalloc_pool.freelistHead() ;
   for (const FrBigAllocHdr *block = head->nextFree() ;
	block && block != head ;
	block = block->nextfree)
      {
      // is the block at a valid address?
      if (block < memory_start || block >= FramepaC_memory_end)
	 {
	 OK = false ; // chain corrupted!
	 break ;
	 }
      FrBigAllocHdr *nextfree = block->nextfree ;
      FrBigAllocHdr *prevfree = block->prevfree ;
      // are the forward and backward links correct?
      // must be non-NULL, must point at a block that points back at us,
      //  and can't point at ourself (except for the list head, which is
      //  never processed here)
      if (!nextfree || !prevfree || nextfree->prevfree != block ||
	  prevfree->nextfree != block ||
	 nextfree == block || prevfree == block)
	 {
	 OK =  false ; // chain corrupted!
	 break ;
	 }
      }
   FrCRITSECT_LEAVE(FramepaC_bigalloc_pool.mutex()) ;
#endif /* FrREPLACE_MALLOC */
   return OK ;
}

//----------------------------------------------------------------------

bool FramepaC_memory_chain_OK()
{
#ifdef FrREPLACE_MALLOC
   size_t freeblocks = 0 ;
   size_t alloc = 0 ;
   bool OK = true ;

   FrCRITSECT_ENTER(FramepaC_bigalloc_pool.mutex()) ;
   FrBigAllocHdr *next ;
   FrBigAllocHdr *head = FramepaC_bigalloc_pool.freelistHead() ;
   FrBigAllocHdr *block = head->next ;
   for ( ; block && block != head ; block = next)
      {
      next = block->next ;
      FrBigAllocHdr *prev = block->prev ;
      // are the forward and backward links correct?
      if (BAD_NEXT_LINK(block,next) || BAD_PREV_LINK(block,prev))
	 {
	 OK = false ;			// chain corrupted!
	 break ;
	 }
      // range checks
      if (block->first > (unsigned char)1 || block->free > (unsigned char)1 ||
	  block->suballocated > (unsigned char)1 ||
	  block->memsource > (unsigned char)MEMSRC_LASTSRC ||
	  ((next > block && block->size > (uintptr_t)next-(uintptr_t)block)) ||
	  block->size > total_allocations-alloc)
	 {
	 OK = false ;			// chain corrupted!
	 break ;
	 }
      if (next && next != head)
	 {
	 // is the current block's size actually correct?
	 if (next->first == (unsigned char)0 &&
	     ((char*)block)+block->size != (char*)next)
	    {
	    OK = false ;		// chain corrupted!
	    break ;
	    }
	 }
      else
	 {
	 // does memory_last actually point at last block?
	 if (next != head || block != memory_last)
	    {
	    OK = false ;		// chain corrupted!
	    break ;
	    }
	 }
      if (block->free == (unsigned char)1)
	 freeblocks++ ;
      alloc += block->size ;
      }
   if (alloc != total_allocations)
      {
      OK = false ;			// internal inconsistency!
      }
   FrCRITSECT_LEAVE(FramepaC_bigalloc_pool.mutex()) ;
   if (alloc && !block)			// memory chain is supposed to end
      {					//   with FramepaC_bigalloc_pool!
      OK = false ;
      }
   if (!OK)
      return false ;
#endif /* FrREPLACE_MALLOC */
   return FramepaC_memory_freelist_OK() ;
}

//----------------------------------------------------------------------

#if defined(FrREPLACE_MALLOC) && defined(FrMEMORY_CHECKS)
static void _check_memory(void *blk, const char *caller, const char *where)
{
   if ((char*)blk < (char*)memory_start ||
       (char*)blk >= (char*)FramepaC_memory_end)
      {
      FramepaC_bad_pointer(blk,outside_heap_str,caller) ;
      if (memory_errors_are_fatal)
	 exit(127) ;
      }
   else if (!FramepaC_memory_chain_OK())
      FramepaC_memory_corrupted(blk,false,where) ;
}

// to prevent automatic inlining by Watcom C++ or Visual C++ and to permit
// possible extensions with other handlers, we indirect check_memory() through
// a pointer
static void (*check_memory)(void *blk, const char *,const char *) = _check_memory ;
#endif /* FrREPLACE_MALLOC && FrMEMORY_CHECKS */

//----------------------------------------------------------------------

#ifdef FrREPLACE_MALLOC
static FrBigAllocHdr *find_predecessor(FrBigAllocHdr *block)
{
   if (block)
      {
      FrBigAllocHdr *pred = FramepaC_bigalloc_pool.freelistHead()->next ;
      while (pred && pred < block && pred->next && pred->next < block)
	 pred = pred->next ;
      if (pred && pred < block)
	 return pred ;
      }
   // not found
   return 0 ;
}
#endif /* FrREPLACE_MALLOC */

//----------------------------------------------------------------------
// Prerequisite: caller has acquired FramepaC_bigalloc_pool.mutex()

#ifdef FrREPLACE_MALLOC
inline FrBigAllocHdr *merge_last_free_chunk(FrBigAllocHdr *&last,
					    FrBigAllocHdr *block,
					    size_t &size)
{
   if (last->free)
      {
      // OK, merge the new allocation with the free fragment
      size += last->size ;
      // temporarily remove the final free fragment from memory area
      FrBigAllocHdr *next = last->next ;
      FrBigAllocHdr *prev = last->prev ;
      total_allocations -= last->size ;
      // unhook the block from the global block list
      next->prev = prev ;
      prev->next = next ;
      FramepaC_bigalloc_pool.remove(last) ;
      block = last ;
      last = prev ;
      }
   return block ;
}
#endif /* FrREPLACE_MALLOC */

//----------------------------------------------------------------------

#ifdef FrREPLACE_MALLOC
static void split_off_fragment(FrBigAllocHdr *block, size_t size)
{
   size_t leftover = block->size - size ;
   if (leftover >= FrALLOC_GRANULARITY)
      {
      FrBigAllocHdr *next = block->next ;
      FrBigAllocHdr *rest = (FrBigAllocHdr*)(((char*)block)+size) ;
      block->size = size ;
      block->next = rest ;		// block's succ. is new fragment
      rest->size = leftover ;
      rest->prev = block ;		// pred. is blk from which split
      rest->next = next ;		// succ is block's successor
      rest->free = (unsigned char)0 ;  	// block is not yet free
      rest->first = (unsigned char)0 ; 	// contiguous with predecessor
      rest->suballocated = (unsigned char)0 ;
      rest->memsource = block->memsource ;
      next->prev = rest ;		// fragment successor's pred.
					//   is now the new fragment
      FramepaC_bigalloc_pool.add(rest) ;
      }
   return ;
}
#endif /* FrREPLACE_MALLOC */

//----------------------------------------------------------------------
// Prerequisite: caller has acquired FramepaC_bigalloc_pool.mutex()

#ifdef FrREPLACE_MALLOC
static void merge_with_free_successor(FrBigAllocHdr *block)
{
   FrBigAllocHdr *next = block->next ;
   if (next->free != (unsigned char)0 && next->first == (unsigned char)0)
      {
      // merge with following block, removing following block from freelist
      block->size += next->size ;
      FramepaC_bigalloc_pool.remove(next) ;
      next = next->next ;
#ifdef FrMEMORY_CHECKS
      if (next != FramepaC_bigalloc_pool.freelistHead() &&
	  (uintptr_t)block->size > (uintptr_t)next - (uintptr_t)block)
	 FramepaC_memory_corrupted(block,false,big_free_str) ;
#endif /* FrMEMORY_CHECKS */
      block->next = next ;
      next->prev = block ;
      }
   return ;
}
#endif /* FrREPLACE_MALLOC */

//----------------------------------------------------------------------

#ifdef FrREPLACE_MALLOC
static FrBigAllocHdr *adjust_sbrk(FrBigAllocHdr *block)
{
   int adjust = (((long int)block)&(FrALIGN_SIZE-1)) ;
   if (adjust)			// misaligned block?
      {
      block = (FrBigAllocHdr*)(((char*)block) + adjust) ;
      if (sbrk(FrALIGN_SIZE - adjust) == (void*)-1)
	 {
	 errno = ENOMEM ;
	 return 0 ;
	 }
      }
   block->first = (unsigned char)1 ;
   return block ;
}
#endif /* FrREPLACE_MALLOC */

//----------------------------------------------------------------------

#ifdef FrREPLACE_MALLOC
void *big_malloc(size_t size)
{
   if (!FramepaC_bigalloc_pool.initialized())
      FramepaC_bigalloc_pool.init(FrALLOC_GRANULARITY, FrALLOC_BIGMAX,
				  FrALLOC_GRANULARITY) ;
   size = round_up(size+sizeof(FrBigAllocHdr),FrALLOC_GRANULARITY) ;
   // grab a block of the appropriate size off of our free list, if available
   FrBigAllocHdr *block = FramepaC_bigalloc_pool.pop(size) ;
   if (block)
      {
      block->free = (unsigned char)0 ;    // no longer free
      split_off_fragment(block,size) ;
      block++ ;		     	// skip header, return the body
      return (void*)block ;
      }
   // if we get to this point, there was no free block large enough, so get
   // some more memory from the system
   size_t realsize = size ;
#if FrALIGN_SIZE_SBRK > FrALLOC_GRANULARITY
   size = round_up(size,FrALIGN_SIZE_SBRK) ;
#endif
   FrCRITSECT_ENTER(FramepaC_bigalloc_pool.mutex()) ;
   block = (FrBigAllocHdr*)sbrk(size) ;
   bool already_linked = false ;
   if ((void*)block != (void*)-1)
      {
      // was the new allocation below an existing one?  (!@$% Windows XP)
      if (block < FramepaC_memory_end)
	 {
	 // check whether we are contiguous with some prior allocation
	 FrBigAllocHdr *pred = find_predecessor(block) ;
	 if (pred && ((char*)pred) + pred->size == (char*)block)
	    {
	    block->first = (unsigned char)0 ;
	    block = merge_last_free_chunk(pred,block,size) ;
	    }
	 // if not, set things up as a discontiguous block
	 else
	    {
	    if ((block = adjust_sbrk(block)) == 0)
	       {
	       FrCRITSECT_LEAVE(FramepaC_bigalloc_pool.mutex()) ;
	       return 0 ;
	       }
	    }
	 if (pred)
	    {
	    // add to linked list of all memory blocks
	    FrBigAllocHdr *nxt = pred->next ;
	    block->next = nxt ;
	    block->prev = pred ;
	    pred->next = block ;
	    if (nxt)
	       nxt->prev = block ;
	    already_linked = true ;
	    }
	 }
      // was the new allocation contiguous with the last one?
      else if (block > FramepaC_memory_end)
	 {
	 if ((block = adjust_sbrk(block)) == 0)
	    {
	    FrCRITSECT_LEAVE(FramepaC_bigalloc_pool.mutex()) ;
	    return 0 ;
	    }
	 FramepaC_memory_end = (FrBigAllocHdr*)(((char*)block) + size) ;
	 }
      else
	 {
	 // check whether the last allocation (with which we are contiguous)
	 // has a final fragment which is currently free
	 block->first = (unsigned char)0 ;
	 FrBigAllocHdr *pred = memory_last ;
	 block = merge_last_free_chunk(pred,block,size) ;
	 FramepaC_memory_end = (FrBigAllocHdr*)(((char*)block) + size) ;
	 }
      block->memsource = MEMSRC_SBRK ;
      }
   else
      {
#if defined(ALLOC_MMAP)
      size = round_up(size,FrMMAP_GRANULARITY) ;
      block = (FrBigAllocHdr*)ALLOC_MMAP(0, size, PROT_READ|PROT_WRITE,
					 MAP_PRIVATE) ;
      if (block != MAP_FAILED)
	 {
	 block->memsource = MEMSRC_MMAP ;
	 block->first = (unsigned char)1 ;
	 FrBigAllocHdr *new_end = (FrBigAllocHdr*)(((char*)block) + size) ;
	 if (new_end > FramepaC_memory_end)
	    FramepaC_memory_end = new_end ;
	 else
	    {
	    FrBigAllocHdr *pred = find_predecessor(block) ;
	    if (pred)
	       {
	       FrBigAllocHdr *nxt = pred->next ;
	       block->next = nxt ;
	       block->prev = pred ;
	       pred->next = block ;
	       if (nxt)
		  nxt->prev = block ;
	       already_linked = true ;
	       }		
	    }
	 }
      else
#endif /* ALLOC_MMAP */
	 {
	 errno = ENOMEM ;
	 FrCRITSECT_LEAVE(FramepaC_bigalloc_pool.mutex()) ;
	 return 0 ;		// unable to allocate more memory
	 }
      }
   total_allocations += size ;
   block->size = size ;
   block->free = (unsigned char)0 ;  // it's in use
   block->suballocated = (unsigned char)0 ;
   block->setNextFree(0) ;
   block->setPrevFree(0) ;
   if (!already_linked)
      {
      FrBigAllocHdr *head = FramepaC_bigalloc_pool.freelistHead() ;
      block->next = head ;
      block->prev = head->prev ;
      head->prev->next = block ;
      head->prev = block ;
      }
   FrCRITSECT_LEAVE(FramepaC_bigalloc_pool.mutex()) ;
   split_off_fragment(block,realsize) ;
   block++ ;				 // skip the header, return the body
//!   VALGRIND_MEMPOOL_ALLOC(&FramepaC_bigalloc_pool,block,realsize) ;
   return (void*)block ;
}
#else /* !defined(FrREPLACE_MALLOC) */
void *big_malloc(size_t size)
  {
    void *blk ;
#if defined(FrNEW_THROWS_EXCEPTIONS)
     try
	{
	blk = ::new char[size] ;
	}
     catch (void*)
	{
	blk = 0 ;
	}
#else
    new_handler_t orig_handler = set_new_handler(FR_NEW_HANDLER) ;
    blk = ::new char[size] ;
    set_new_handler(orig_handler) ;
#endif /* FrNEW_THROWS_EXCEPTIONS */
    return blk ;
  }
#endif /* FrREPLACE_MALLOC */

//----------------------------------------------------------------------

#ifdef FrREPLACE_MALLOC
void big_free(FrBigAllocHdr *block)
{
   FrBigAllocHdr *prev = block->prev ;
#ifdef FrMEMORY_CHECKS
   {
   FrBigAllocHdr *next = block->next ;
   size_t blocksize = block->size ;
   if (block->free != (unsigned char)0 ||
       blocksize < sizeof(FrBigAllocHdr) ||
       (next != FramepaC_bigalloc_pool.freelistHead() && blocksize >
	(uintptr_t)next - (uintptr_t)block) ||
       BAD_PREV_LINK(block,prev) || BAD_NEXT_LINK(block,next))
      {
      check_memory(&block[1],FrFree_str,big_free_str) ;
      return ;
      }
   }
#endif /* FrMEMORY_CHECKS */
//!   VALGRIND_MEMPOOL_FREE(&FramepaC_bigalloc_pool,block) ;
   FrCRITSECT_ENTER(FramepaC_bigalloc_pool.mutex()) ;
   merge_with_free_successor(block) ;
   if (block->first == (unsigned char)0 && prev->free != (unsigned char)0)
      {
      // remove preceding block from freelist
      FramepaC_bigalloc_pool.remove(prev) ;
      // merge with preceding block
      FrBigAllocHdr *next = block->next ;
      prev->size += block->size ;
      prev->next = next ;
      next->prev = prev ;
      block = prev ;
      }
   FrCRITSECT_LEAVE(FramepaC_bigalloc_pool.mutex()) ;
   // add block to freelist
   FramepaC_bigalloc_pool.add(block) ;
   return ;
}
#else /* !defined(FrREPLACE_MALLOC) */
void big_free(FrBigAllocHdr *blk)
{ 
   ::delete [] ((char*)(blk+1)) ;
   return ;
}
#endif /* FrREPLACE_MALLOC */

//----------------------------------------------------------------------

#ifdef FrREPLACE_MALLOC
void *big_realloc(FrBigAllocHdr *block,size_t newsize)
{
   if (!FramepaC_bigalloc_pool.initialized())
      FramepaC_bigalloc_pool.init(FrALLOC_GRANULARITY, FrALLOC_BIGMAX,
				      FrALLOC_GRANULARITY) ;
#ifdef FrMEMORY_CHECKS
   FrBigAllocHdr *next = block->next ;
   FrBigAllocHdr *prevblk = block->prev ;
   if (block->free != (unsigned char)0 ||
       BAD_NEXT_LINK(block,next) || BAD_PREV_LINK(block,prevblk) ||
       (next != FramepaC_bigalloc_pool.freelistHead() &&
	(uintptr_t)block->size > (uintptr_t)next - (uintptr_t)block))
      {
      check_memory(&block[1],FrRealloc_str,big_realloc_str) ;
      errno = EFAULT ;
      return 0 ;
      }
#endif /* FrMEMORY_CHECKS */
   // merge block with following one, if free
   FrCRITSECT_ENTER(FramepaC_bigalloc_pool.mutex()) ;
   merge_with_free_successor(block) ;
   FrCRITSECT_LEAVE(FramepaC_bigalloc_pool.mutex()) ;
   // check whether expanded block is big enough to hold requested size
   size_t size = round_up(newsize + sizeof(FrBigAllocHdr),
			  FrALLOC_GRANULARITY) ;
   if (block->size >= size)
      {
      split_off_fragment(block,size) ;
      block++ ;				// skip header, return the body
//!      VALGRIND_MEMPOOL_CHANGE(&FramepaC_bigalloc_pool,block,block,size) ; 
      return block ;
      }
   else if (!block->next && block->memsource == MEMSRC_SBRK)
      {					// last memory block?
      size_t remainder = size - block->size ;
#if FrALIGN_SIZE_SBRK > FrALIGN_SIZE
      remainder = round_up(remainder,FrALIGN_SIZE_SBRK) ;
#endif
      FrCRITSECT_ENTER(FramepaC_bigalloc_pool.mutex()) ;
      void *newblk = sbrk(remainder) ;
      if (newblk == FramepaC_memory_end) // contiguous with the existing block?
	 {
	 block->size += remainder ;
	 total_allocations += remainder ;
	 FramepaC_memory_end = (FrBigAllocHdr*)((char*)block + block->size) ;
	 FrCRITSECT_LEAVE(FramepaC_bigalloc_pool.mutex()) ;
	 block++ ;		// skip header, return the body
//!	 VALGRIND_MEMPOOL_CHANGE(&FramepaC_bigalloc_pool,block,block,size) ; 
	 return block ;
	 }
      else if (newblk != (void*)-1)
	 {
	 // not contiguous, so try to return to system
	 if (sbrk(-remainder) == (void*)-1)
	    {
	    // if unable to return to system, make into a free memory block
	    FrBigAllocHdr *blk = (FrBigAllocHdr*)newblk ;
	    block->next = blk ;
	    blk->next = 0 ;
	    blk->prev = block ;
	    blk->size = remainder ;
	    blk->free = (unsigned char)1 ;
	    blk->first = (unsigned char)0 ;
	    blk->suballocated = (unsigned char)0 ;
	    blk->memsource = block->memsource ;
	    FramepaC_bigalloc_pool.add(blk) ;
	    }
	 }
      FrCRITSECT_LEAVE(FramepaC_bigalloc_pool.mutex()) ;
      }
   // if we get here, we were unable to resize the existing block, so allocate
   // a new one and copy over the contents
   void *newblock = big_malloc(newsize) ;
   if (newblock)
      {
      if (size > (size_t)block->size)
	 size = block->size - sizeof(FrBigAllocHdr) ;
      memcpy(newblock,&block[1],size) ;
      big_free(block) ;
      }
   return newblock ;
}
#endif /* FrREPLACE_MALLOC */

//----------------------------------------------------------------------

#ifdef FrREPLACE_MALLOC
bool big_reclaim()
{
   bool reclaimed = false ;
   FrCRITSECT_ENTER(FramepaC_bigalloc_pool.mutex()) ;
#if defined(ALLOC_MMAP)
   // scan down the list of free blocks, looking for those which have
   //   MEMSRC_MMAP, are first blocks, and do not have a non-first immediate
   //   successor
   FrBigAllocHdr *prev ;
   FrBigAllocHdr *head = FramepaC_bigalloc_pool.freelistHead() ;
   for (FrBigAllocHdr *block = head->prevfree ;
	block && block != head ;
	block = prev)
      {
      prev = block->prevfree ;
      if (block->memsource == MEMSRC_MMAP && block->free && block->first &&
	  (block->next == head || !block->next->first))
	 {
	 size_t size = block->size ;
	 if (size >= FrMMAP_GRANULARITY)
	    {
	    total_allocations -= size ;
	    // unlink the block from our memory lists
	    block->free = (unsigned char)1 ;
	    FramepaC_bigalloc_pool.remove(block) ;
	    block->unlink() ;
	    // return the memory to the operating system
	    munmap(block,block->size) ;
	    }
	 }
      }
#endif /* ALLOC_MMAP */
   // check if we can reduce our sbrk() memory size -- requires that the
   //  highest large memory block be free
   if (memory_last->free != 0)
      {
      FrBigAllocHdr *block = memory_last ;
      // grab all the values we need out of the block's header, since we
      // won't have access to them once the sbrk() returns the block to the
      // system
      size_t size = block->size ;
      FrBigAllocHdr *next = block->next ;
      FrBigAllocHdr *prev = block->prev ;
      // reduce memory allocation
      // we must check the return value because some systems (e.g. DOS/4GW)
      // will not honor negative increments to sbrk()
      if (block->memsource == MEMSRC_SBRK)
	 {
	 FramepaC_bigalloc_pool.remove(block) ;
	 if (sbrk(-((long int)size)) != (void*)-1)
	    {
	    // adjust the various end-of-memory markers
	    total_allocations -= size ;
	    FramepaC_memory_end = (FrBigAllocHdr*)(((char*)prev) + prev->size) ;
	    // unhook the block from the global block list
	    next->prev = prev ;
	    prev->next = next ;
	    // indicate success
	    reclaimed = true ;
	    }
	 else
	    {
	    // unable to release to OS, so add back to our own free list
	    FramepaC_bigalloc_pool.add(block) ;
	    }
	 }
      }
   FrCRITSECT_LEAVE(FramepaC_bigalloc_pool.mutex()) ;
   return reclaimed ;
}
#endif /* FrREPLACE_MALLOC */

//----------------------------------------------------------------------

void *FrMalloc(size_t size)
{
   if (!FramepaC_default_mempool.initialized())
      FramepaC_default_mempool.init("FrMalloc") ;
   return FramepaC_default_mempool.allocate(size) ;
}

//----------------------------------------------------------------------

void *_FrMallocDebug(size_t size, const char *file, size_t line)
{
   void *blk = FrMalloc(size) ;
   if (!blk)
      FrWarningVA("out of memory at line %lu of %s",(unsigned long)line,file) ;
   return blk ;
}

//----------------------------------------------------------------------

void *FrCalloc(size_t nitems, size_t size, FrMemoryPool *mp)
{
   size_t blocksize = nitems*size ;
   void *block = mp->allocate(blocksize) ;

   if (block)
      {
      memset(block,'\0',blocksize) ;
      }
   return block ;
}

//----------------------------------------------------------------------

void *FrCalloc(size_t nitems, size_t size)
{
   size_t blocksize = nitems*size ;
   void *block = FrMalloc(blocksize) ;
   if (block)
      {
      memset(block,'\0',blocksize) ;
      }
   return block ;
}

//----------------------------------------------------------------------

void *_FrCallocDebug(size_t n,size_t size, const char *file, size_t line)
{
   void *blk = FrCalloc(n,size) ;
   if (!blk)
      FrWarningVA("out of memory at line %lu of %s",(unsigned long)line,file) ;
   return blk ;
}

//----------------------------------------------------------------------

void *FrRealloc(void *block, size_t newsize, bool copydata)
{
   if (!FramepaC_default_mempool.initialized())
      FramepaC_default_mempool.init("FrMalloc") ;
   return FramepaC_default_mempool.reallocate(block,newsize,copydata) ;
}

//----------------------------------------------------------------------
// support for Purify builds

void *realloc3(void *block, size_t newsize, bool copydata)
{
   (void)copydata ;
   return realloc(block,newsize) ;
}

//----------------------------------------------------------------------

void *_FrReallocDebug(void *blk, size_t size, bool copy,
		      const char *file, size_t line)
{
   void *new_blk = FrRealloc(blk,size,copy) ;
   if (!new_blk)
      FrWarningVA("out of memory at line %lu of %s",(unsigned long)line,file) ;
   return new_blk ;
}

//----------------------------------------------------------------------

void FrFree(void *block)
{
   if (!FramepaC_default_mempool.initialized())
      FramepaC_default_mempool.init("FrMalloc") ;
   return FramepaC_default_mempool.release(block) ;
}

//----------------------------------------------------------------------

void _FrFreeDebug(void *blk, const char *file, size_t line)
{
   (void)file; (void)line;
   FrFree(blk) ;
   return ;
}

/************************************************************************/
/*	Methods for class FrBigAllocHdr					*/
/************************************************************************/

void FrBigAllocHdr::initEmpty()
{
   next = this ;
   prev = this ;
   nextfree = this ;
   prevfree = this ;
   size = sizeof(*this) ;
   free = (unsigned char)0 ;
   first = (unsigned char)1 ;
   suballocated = (unsigned char)0 ;
   memsource = MEMSRC_SBRK ;
   return ;
}

/************************************************************************/
/*	Methods for class FrMemoryPoolInfo				*/
/************************************************************************/

#if FrMAX_AUTO_SUBALLOC > 32
#define MPI_MIN_BINSIZE FrMAX_AUTO_SUBALLOC
#else
#define MPI_MIN_BINSIZE 32
#endif

//----------------------------------------------------------------------

FrMemoryPoolInfo::FrMemoryPoolInfo()
   : FrMemoryBinnedFreelist<FrFreeHdr,FrMEMPOOLINFO_FACTOR>(MPI_MIN_BINSIZE,
							    MAX_SMALL_BLOCK,
							    FrALIGN_SIZE)
{
   // the default memory pool might get forcibly initialized before its
   //   constructor has a chance to run, so don't run the initialization
   //   again if that happens
   if (this != &FramepaC_default_mempool || !initialized())
      init() ;
   return ;
}

//----------------------------------------------------------------------

FrMemoryPoolInfo::~FrMemoryPoolInfo()
{
   removeAllBlocks() ;
   reclaimFreeBlocks() ;
   return ;
}

//----------------------------------------------------------------------

void FrMemoryPoolInfo::init()
{
   m_blocks = 0 ;
   m_blocklist = 0 ;
   m_freeblocks = 0 ;
   FrMemoryBinnedFreelist<FrFreeHdr,FrMEMPOOLINFO_FACTOR>::init(MPI_MIN_BINSIZE,
								MAX_SMALL_BLOCK,
								FrALIGN_SIZE) ;
   return ;
}

//----------------------------------------------------------------------

static void check_idx(uint16_t *idx, FrFreeHdr **ptrs, FrFreeHdr *list,
		      size_t maxbin)
{
   for (size_t i = 1 ; i <= maxbin ; i++)
      {
      if(!(idx[i] == i || (idx[i] > i && idx[i-1] != i)))
	 (void)FrAssertionFailed("bad index",__FILE__,__LINE__) ;
      }
   for (size_t i = 0 ; i <= maxbin ; i++)
      {
      if (ptrs[idx[i]] != list)
	 {
	 size_t b = FrMemoryPoolInfo::bin(HDRBLKSIZE(ptrs[idx[i]])) ;
	 if (!(b == idx[i]))
	    (void)FrAssertionFailed("bad size",__FILE__,__LINE__) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void FrMemoryPoolInfo::check()
{
   for (FrFreeHdr *free = m_freelist.next ;
	free && free != &m_freelist ;
	free = free->next)
      {
      for (FrFreeHdr *other = free->next ;
	   other && other != &m_freelist ;
	   other = other->next)
	 {
	 ASSERT(free != other,"duplicate") ;
	 }
      }
   check_idx(m_index,m_freelist_ptrs,&m_freelist,maximumBin()) ;
   return ;
}

//----------------------------------------------------------------------

void FrMemoryPoolInfo::addBlock(FrObjArray *newblock)
{
   enterCritical() ;
   newblock->next = m_blocklist ;
   m_blocklist = newblock ;
   m_blocks++ ;
   leaveCritical() ;
   return ;
}

//----------------------------------------------------------------------
// Prerequisite: caller has entered pool's critical section

void FrMemoryPoolInfo::removeBlock(FrObjArray *oldblock,
				   FrObjArray *pred)
{
   if (oldblock)
      {
      if (pred)
	 pred->next = oldblock->next ;
      else
	 m_blocklist = oldblock->next ;
      m_blocks-- ;
      // add the old block to the free list
      oldblock->next = m_freeblocks ;
      m_freeblocks = oldblock ;
      }
   return ;
}

//----------------------------------------------------------------------

void FrMemoryPoolInfo::removeAllBlocks()
{
   // grab the entire list of used blocks at once in the critical section;
   //   we can then process them at our leisure without needing to block
   //   other threads
   enterCritical() ;
   FrObjArray *blocks = m_blocklist ;
   m_blocklist = 0 ;
   m_blocks = 0 ;
   leaveCritical() ;
   while (blocks)
      {
      FrObjArray *block = blocks ;
      blocks = block->next ;
      FramepaC_default_mempool.addFreeBlock(block) ;
      }
   return ;
}

//----------------------------------------------------------------------

void FrMemoryPoolInfo::addFreeBlock(FrObjArray *freeblock)
{
   enterCritical() ;
   freeblock->next = m_freeblocks ;
   m_freeblocks = freeblock ;
   leaveCritical() ;
   return ;
}

//----------------------------------------------------------------------

FrObjArray *FrMemoryPoolInfo::popFreeBlock()
{
   enterCritical() ;
   FrObjArray *block = m_freeblocks ;
   if (block)
      {
      m_freeblocks = block->next ;
      block->next = 0 ;
      }
   leaveCritical() ;
   return block ;
}

//----------------------------------------------------------------------

size_t FrMemoryPoolInfo::numFreeBlocks() const
{
   size_t count = 0 ;
   for (const FrObjArray *fl = m_freeblocks ; fl ; fl = fl->next)
      count++ ;
   return count ;
}

//----------------------------------------------------------------------

bool FrMemoryPoolInfo::reclaimFreeBlocks()
{
   // grab the entire list of free blocks at once in the critical section;
   //   we can then process them at our leisure without needing to block
   //   other threads
   FrObjArray *block = atomicSwap(m_freeblocks,(FrObjArray*)0) ;
   bool reclaimed = false ;
   FrObjArray *next ;
   for ( ; block ; block = next)
      {
      next = block->next ;
      FrBigAllocHdr *hdr = ((FrBigAllocHdr*)block) - 1 ;
#ifdef FrREPLACE_MALLOC
      hdr->free = (unsigned char)0 ;
      hdr->suballocated = (unsigned char)0 ;
#endif /* FrREPLACE_MALLOC */
      big_free(hdr) ;
      reclaimed = true ;
      }	
   return reclaimed ;
}

//----------------------------------------------------------------------

bool FrMemoryPoolInfo::checkFreelist()
{
   const FrFreeHdr *next ;
   enterCritical() ;
   bool OK = true ;
   for (const FrFreeHdr *flist = m_freelist.next ;
	flist && flist != &m_freelist ;
	flist = next)
      {
#ifdef FrREPLACE_MALLOC
      if (flist < (void*)memory_start ||
	  flist >= (void*)FramepaC_memory_end)
	 {
	 OK = false ;
	 break ;
	 }
#endif /* FrREPLACE_MALLOC */
      next = flist->next ;
      const FrFreeHdr *prev = flist->prev ;
      // do we have valid forward and backward links?
      if (!next || next->prev != flist ||
	  !prev || prev->next != flist)
	 {
	 OK = false ; // freelist corrupted!
	 break ;
	 }
      }
   leaveCritical() ;
   return OK ;
}

//----------------------------------------------------------------------

size_t FrMaxSmallAlloc()
{
   return MAX_SMALL_ALLOC ;
}

/************************************************************************/
/*	Specializations of template FrMemoryBinnedFreelist		*/
/************************************************************************/

template <>
size_t FrMemoryBinnedFreelist<FrFreeHdr,FrMEMPOOLINFO_FACTOR>::blockSize(const FrFreeHdr *block)
{
   return HDRBLKSIZE(block) ;
}

//----------------------------------------------------------------------

template <>
size_t FrMemoryBinnedFreelist<FrBigAllocHdr,FrBIGPOOLINFO_FACTOR>::blockSize(const FrBigAllocHdr *block)
{
   return block->size ;
}

//----------------------------------------------------------------------

template <>
void FrMemoryBinnedFreelist<FrFreeHdr,FrMEMPOOLINFO_FACTOR>::markAsUsed(FrFreeHdr *block)
{
   HDRMARKUSED(block) ;
   return ;
}

//----------------------------------------------------------------------

template < >
void FrMemoryBinnedFreelist<FrBigAllocHdr,FrBIGPOOLINFO_FACTOR>::markAsUsed(FrBigAllocHdr *block){
   block->free = (unsigned char)0 ;
   return ;
}

//----------------------------------------------------------------------

template < >
void FrMemoryBinnedFreelist<FrFreeHdr,FrMEMPOOLINFO_FACTOR>::markAsFree(FrFreeHdr *block)
{
   HDRMARKFREE(block) ;
   return ;
}

//----------------------------------------------------------------------

template < >
void FrMemoryBinnedFreelist<FrBigAllocHdr,FrBIGPOOLINFO_FACTOR>::markAsFree(FrBigAllocHdr *block){
   block->free = (unsigned char)1 ;
   return ;
}

//----------------------------------------------------------------------

template < >
bool FrMemoryBinnedFreelist<FrFreeHdr,FrMEMPOOLINFO_FACTOR>::blockInUse(const FrFreeHdr *block)
{
   return HDRBLKUSED(block) != 0 ;
}

//----------------------------------------------------------------------

template < >
bool FrMemoryBinnedFreelist<FrBigAllocHdr,FrBIGPOOLINFO_FACTOR>::blockInUse(const FrBigAllocHdr *block)
{
   return block->free == 0 ;
}

// end of file frmem.cpp //
