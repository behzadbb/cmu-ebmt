/************************************************************************/
/*									*/
/*  FramepaC  -- frame manipulation in C++				*/
/*  Version 1.99							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File fr_mem.h		private memory allocation declarations	*/
/*  LastEdit: 04mar10							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,2004,2006,2007,2009,2010	*/
/*		 Ralf Brown						*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __FR_MEM_H_INCLUDED
#define __FR_MEM_H_INCLUDED

#ifndef __FRMEM_H_INCLUDED
#include "frmem.h"
#endif

/************************************************************************/
/*    Manifest constants						*/
/************************************************************************/

#define FrMALLOC_BINS	11   // # of separate sizes to report for memory stats

#define MEMSRC_SBRK	0
#define MEMSRC_MMAP	1
#define MEMSRC_LASTSRC  MEMSRC_MMAP

#define MAX_SMALL_ALLOC (FrBLOCKING_SIZE-2*FrALIGN_SIZE-HDRSIZE)
#define MAX_SMALL_BLOCK (FrBLOCKING_SIZE-FrALIGN_SIZE)

#define MAX_AUTO_SUBALLOC ((int)(FrMAX_AUTO_SUBALLOC - sizeof(short)))

/************************************************************************/
/*	Types								*/
/************************************************************************/

class FrBigAllocHdr
   {
   public:
      FrBigAllocHdr *next, *prev ;
      FrBigAllocHdr *nextfree, *prevfree ;
      size_t size ;
      unsigned char free ;
      unsigned char first ;
      unsigned char suballocated ;
      unsigned char memsource ;		// 0 = sbrk, 1 = mmap
   public: // methods
      void initEmpty() ;
      FrBigAllocHdr *nextFree() const { return nextfree ; }
      FrBigAllocHdr *prevFree() const { return prevfree ; }
      void setNextFree(FrBigAllocHdr *n) { nextfree = n ; }
      void setPrevFree(FrBigAllocHdr *p) { prevfree = p ; }
      void insertInList(FrBigAllocHdr *pred)
	 {
	 prev = pred ;
	 next = pred->next ;
	 pred->next = this ;
	 next->prev = this ;
	 }
      void insertInFreelist(FrBigAllocHdr *pred)
	 {
	 prevfree = pred ;
	 nextfree = pred->nextFree() ;
	 pred->nextfree = this ;
	 nextfree->prevfree = this ;
	 }
      void unlink()
	 {
	 next->prev = prev ;
	 prev->next = next ;
	 }
      void unlinkFromFreelist()
	 {
	 nextfree->prevfree = prevFree() ;
	 prevfree->nextfree = nextFree() ;
	 }
      void replaceInFreelist(FrBigAllocHdr *other)
	 {
	 other->nextfree = nextFree() ;
	 other->prevfree = prevFree() ;
	 nextfree->prevfree = other ;
	 prevfree->nextfree = other ;
	 }
   } ;

//----------------------------------------------------------------------

class FrMallocHdr
   {
   public:
      unsigned short prevsize ;
      unsigned short size ;   // low bit indicate whether block is in use
   } ;

//----------------------------------------------------------------------

class FrMallocBigHdr
   {
   public:
      int size ;
   } ;

/************************************************************************/
/*    Procedural interface to memory allocation				*/
/************************************************************************/

extern void (*FramepaC_gc_handler)() ;
extern void (*FramepaC_auto_gc_handler)() ;

extern FrMemoryPool *FramepaC_memory_pools ;
extern FrBigAllocHdr *FramepaC_memory_end ;
extern FrAllocator *FramepaC_allocators ;
extern int FramepaC_symbol_blocks ;
#ifdef FrREPLACE_MALLOC
extern FrMemoryBinnedFreelist<FrBigAllocHdr,FrBIGPOOLINFO_FACTOR>
	    FramepaC_bigalloc_pool ;
#endif /* FrREPLACE_MALLOC */

/************************************************************************/
/*    Convenience Macros						*/
/************************************************************************/

#define memory_start (FramepaC_bigalloc_pool.freelistHead())
#define memory_last (FramepaC_bigalloc_pool.freelistHead()->prev)

#define HDRSIZE sizeof(FrMallocHdr)
#define HDR(ptr) (((FrMallocHdr*)(ptr))[-1])
#define HDRADDR(ptr) (((FrMallocHdr*)(ptr))-1)
#define HDRBLKSIZE(ptr) (HDR(ptr).size & FRFREEHDR_SIZE_MASK)
#define HDRBLKUSED(ptr) (HDR(ptr).size & FRFREEHDR_USED_BIT)
#define HDRSETSIZE(ptr,sz) (HDR(ptr).size = (unsigned short)(sz))
#define HDRSETSIZEUSED(ptr,sz)(HDR(ptr).size = (unsigned short)(sz) | FRFREEHDR_USED_BIT)
#define HDRMARKUSED(ptr) (HDR(ptr).size |= FRFREEHDR_USED_BIT)
#define HDRMARKFREE(ptr) (HDR(ptr).size &= ~FRFREEHDR_USED_BIT)

#define MIN_ALLOC (HDRSIZE + 2*sizeof(void*))
#define FRFREEHDR_USED_BIT (1)
#define FRFREEHDR_SIZE_MASK (~ FRFREEHDR_USED_BIT)
#define FRFREEHDR_BIGBLOCK (USHRT_MAX & FRFREEHDR_SIZE_MASK)

#define BIGHDRSIZE (round_up(HDRSIZE+sizeof(FrMallocBigHdr),FrALIGN_SIZE))
#define BIGHDR(ptr) (((FrMallocBigHdr*)(((char*)ptr)-HDRSIZE))[-1])

#endif /* !__FR_MEM_H_INCLUDED */

// end of file fr_mem.h //
